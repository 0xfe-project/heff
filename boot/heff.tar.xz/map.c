// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_map_2eempty_val;
static int g_map_2eempty_st;
static V g_map_2eempty_init(void) {
  return NTAG(TAG_Tip);
}
V g_map_2eempty_get(void) {
  if (g_map_2eempty_st == 2) return g_map_2eempty_val;
  if (g_map_2eempty_st == 1) heff_fail("defined by itself");
  g_map_2eempty_st = 1;
  g_map_2eempty_val = heff_tr(g_map_2eempty_init());
  g_map_2eempty_st = 2;
  return g_map_2eempty_val;
}
Clo g_map_2ebalance_clo = {{0x80000000u, K_CLO, 0}, g_map_2ebalance_entry, 4, 0};

V g_map_2ebalance(V v_k_240, V v_v_241, V v_l_242, V v_r_243) {
top: ;
  V v_a_249;
  switch (heff_tag_of(v_l_242)) {
  case TAG_Tip: {
    v_a_249 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_244 = heff_dup(heff_field(v_l_242, 0));
    v_a_249 = v_h_244;
    break;
  }
  default: heff_nomatch(v_l_242);
  }
  V v_t_2415;
  switch (heff_tag_of(v_r_243)) {
  case TAG_Tip: {
    v_t_2415 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_2410 = heff_dup(heff_field(v_r_243, 0));
    v_t_2415 = v_h_2410;
    break;
  }
  default: heff_nomatch(v_r_243);
  }
  V v_b_2416 = heff_intAdd(v_t_2415, MK_INT(1LL));
  V v_t_2417 = heff_intLt(v_b_2416, v_a_249);
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop(v_t_2417);
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      heff_drop(v_k_240);
      heff_drop(v_v_241);
      heff_drop(v_l_242);
      heff_drop(v_r_243);
      return heff_abandon();
    }
    case TAG_Bin: {
      V v_lk_2419 = heff_field(v_l_242, 1);
      V v_lv_2420 = heff_field(v_l_242, 2);
      V v_ll_2421 = heff_field(v_l_242, 3);
      V v_lr_2422 = heff_field(v_l_242, 4);
      V v_ru_24l_242_24Bin = heff_take_reuse(v_l_242, 30ULL);
      V v_a_2428;
      switch (heff_tag_of(v_ll_2421)) {
      case TAG_Tip: {
        v_a_2428 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2423 = heff_dup(heff_field(v_ll_2421, 0));
        v_a_2428 = v_h_2423;
        break;
      }
      default: heff_nomatch(v_ll_2421);
      }
      V v_b_2434;
      switch (heff_tag_of(v_lr_2422)) {
      case TAG_Tip: {
        v_b_2434 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2429 = heff_dup(heff_field(v_lr_2422, 0));
        v_b_2434 = v_h_2429;
        break;
      }
      default: heff_nomatch(v_lr_2422);
      }
      V v_t_2435 = heff_intLe(v_b_2434, v_a_2428);
      switch (heff_tag_of(v_t_2435)) {
      case TAG_True: {
        heff_drop(v_t_2435);
        V v_a_2441;
        switch (heff_tag_of(v_lr_2422)) {
        case TAG_Tip: {
          v_a_2441 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2436 = heff_dup(heff_field(v_lr_2422, 0));
          v_a_2441 = v_h_2436;
          break;
        }
        default: heff_nomatch(v_lr_2422);
        }
        V v_b_2447;
        switch (heff_tag_of(v_r_243)) {
        case TAG_Tip: {
          v_b_2447 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2442 = heff_dup(heff_field(v_r_243, 0));
          v_b_2447 = v_h_2442;
          break;
        }
        default: heff_nomatch(v_r_243);
        }
        V v_t_2448 = heff_intLe(heff_dup(v_a_2441), heff_dup(v_b_2447));
        V v_t_2449;
        switch (heff_tag_of(v_t_2448)) {
        case TAG_True: {
          heff_drop(v_a_2441);
          heff_drop(v_t_2448);
          v_t_2449 = v_b_2447;
          break;
        }
        case TAG_False: {
          heff_drop(v_b_2447);
          heff_drop(v_t_2448);
          v_t_2449 = v_a_2441;
          break;
        }
        default: heff_nomatch(v_t_2448);
        }
        V v_r_2450 = heff_tag_at(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2449), v_k_240, v_v_241, v_lr_2422, v_r_243});
        V v_a_2456;
        switch (heff_tag_of(v_ll_2421)) {
        case TAG_Tip: {
          v_a_2456 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2451 = heff_dup(heff_field(v_ll_2421, 0));
          v_a_2456 = v_h_2451;
          break;
        }
        default: heff_nomatch(v_ll_2421);
        }
        V v_b_2462;
        switch (heff_tag_of(v_r_2450)) {
        case TAG_Tip: {
          v_b_2462 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2457 = heff_dup(heff_field(v_r_2450, 0));
          v_b_2462 = v_h_2457;
          break;
        }
        default: heff_nomatch(v_r_2450);
        }
        V v_t_2463 = heff_intLe(heff_dup(v_a_2456), heff_dup(v_b_2462));
        V v_t_2464;
        switch (heff_tag_of(v_t_2463)) {
        case TAG_True: {
          heff_drop(v_a_2456);
          heff_drop(v_t_2463);
          v_t_2464 = v_b_2462;
          break;
        }
        case TAG_False: {
          heff_drop(v_b_2462);
          heff_drop(v_t_2463);
          v_t_2464 = v_a_2456;
          break;
        }
        default: heff_nomatch(v_t_2463);
        }
        return heff_tag(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2464), v_lk_2419, v_lv_2420, v_ll_2421, v_r_2450});
      }
      case TAG_False: {
        heff_drop(v_t_2435);
        switch (heff_tag_of(v_lr_2422)) {
        case TAG_Tip: {
          heff_drop(v_k_240);
          heff_drop(v_v_241);
          heff_drop(v_r_243);
          heff_drop(v_lk_2419);
          heff_drop(v_lv_2420);
          heff_drop(v_ll_2421);
          heff_drop(v_lr_2422);
          heff_drop(v_ru_24l_242_24Bin);
          return heff_abandon();
        }
        case TAG_Bin: {
          V v_mk_2466 = heff_field(v_lr_2422, 1);
          V v_mv_2467 = heff_field(v_lr_2422, 2);
          V v_ml_2468 = heff_field(v_lr_2422, 3);
          V v_mr_2469 = heff_field(v_lr_2422, 4);
          V v_ru_24lr_2422_24Bin = heff_take_reuse(v_lr_2422, 30ULL);
          V v_a_2475;
          switch (heff_tag_of(v_ll_2421)) {
          case TAG_Tip: {
            v_a_2475 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2470 = heff_dup(heff_field(v_ll_2421, 0));
            v_a_2475 = v_h_2470;
            break;
          }
          default: heff_nomatch(v_ll_2421);
          }
          V v_b_2481;
          switch (heff_tag_of(v_ml_2468)) {
          case TAG_Tip: {
            v_b_2481 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2476 = heff_dup(heff_field(v_ml_2468, 0));
            v_b_2481 = v_h_2476;
            break;
          }
          default: heff_nomatch(v_ml_2468);
          }
          V v_t_2482 = heff_intLe(heff_dup(v_a_2475), heff_dup(v_b_2481));
          V v_t_2483;
          switch (heff_tag_of(v_t_2482)) {
          case TAG_True: {
            heff_drop(v_a_2475);
            heff_drop(v_t_2482);
            v_t_2483 = v_b_2481;
            break;
          }
          case TAG_False: {
            heff_drop(v_b_2481);
            heff_drop(v_t_2482);
            v_t_2483 = v_a_2475;
            break;
          }
          default: heff_nomatch(v_t_2482);
          }
          V v_l_2484 = heff_tag_at(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2483), v_lk_2419, v_lv_2420, v_ll_2421, v_ml_2468});
          V v_a_2490;
          switch (heff_tag_of(v_mr_2469)) {
          case TAG_Tip: {
            v_a_2490 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2485 = heff_dup(heff_field(v_mr_2469, 0));
            v_a_2490 = v_h_2485;
            break;
          }
          default: heff_nomatch(v_mr_2469);
          }
          V v_b_2496;
          switch (heff_tag_of(v_r_243)) {
          case TAG_Tip: {
            v_b_2496 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2491 = heff_dup(heff_field(v_r_243, 0));
            v_b_2496 = v_h_2491;
            break;
          }
          default: heff_nomatch(v_r_243);
          }
          V v_t_2497 = heff_intLe(heff_dup(v_a_2490), heff_dup(v_b_2496));
          V v_t_2498;
          switch (heff_tag_of(v_t_2497)) {
          case TAG_True: {
            heff_drop(v_a_2490);
            heff_drop(v_t_2497);
            v_t_2498 = v_b_2496;
            break;
          }
          case TAG_False: {
            heff_drop(v_b_2496);
            heff_drop(v_t_2497);
            v_t_2498 = v_a_2490;
            break;
          }
          default: heff_nomatch(v_t_2497);
          }
          V v_r_2499 = heff_tag_at(v_ru_24lr_2422_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2498), v_k_240, v_v_241, v_mr_2469, v_r_243});
          V v_a_24105;
          switch (heff_tag_of(v_l_2484)) {
          case TAG_Tip: {
            v_a_24105 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24100 = heff_dup(heff_field(v_l_2484, 0));
            v_a_24105 = v_h_24100;
            break;
          }
          default: heff_nomatch(v_l_2484);
          }
          V v_b_24111;
          switch (heff_tag_of(v_r_2499)) {
          case TAG_Tip: {
            v_b_24111 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24106 = heff_dup(heff_field(v_r_2499, 0));
            v_b_24111 = v_h_24106;
            break;
          }
          default: heff_nomatch(v_r_2499);
          }
          V v_t_24112 = heff_intLe(heff_dup(v_a_24105), heff_dup(v_b_24111));
          V v_t_24113;
          switch (heff_tag_of(v_t_24112)) {
          case TAG_True: {
            heff_drop(v_a_24105);
            heff_drop(v_t_24112);
            v_t_24113 = v_b_24111;
            break;
          }
          case TAG_False: {
            heff_drop(v_b_24111);
            heff_drop(v_t_24112);
            v_t_24113 = v_a_24105;
            break;
          }
          default: heff_nomatch(v_t_24112);
          }
          return heff_tag(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24113), v_mk_2466, v_mv_2467, v_l_2484, v_r_2499});
        }
        default: return heff_nomatch(v_lr_2422);
        }
      }
      default: return heff_nomatch(v_t_2435);
      }
    }
    default: return heff_nomatch(v_l_242);
    }
  }
  case TAG_False: {
    heff_drop(v_t_2417);
    V v_a_24119;
    switch (heff_tag_of(v_r_243)) {
    case TAG_Tip: {
      v_a_24119 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_24114 = heff_dup(heff_field(v_r_243, 0));
      v_a_24119 = v_h_24114;
      break;
    }
    default: heff_nomatch(v_r_243);
    }
    V v_t_24125;
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      v_t_24125 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_24120 = heff_dup(heff_field(v_l_242, 0));
      v_t_24125 = v_h_24120;
      break;
    }
    default: heff_nomatch(v_l_242);
    }
    V v_b_24126 = heff_intAdd(v_t_24125, MK_INT(1LL));
    V v_t_24127 = heff_intLt(v_b_24126, v_a_24119);
    switch (heff_tag_of(v_t_24127)) {
    case TAG_True: {
      heff_drop(v_t_24127);
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        heff_drop(v_k_240);
        heff_drop(v_v_241);
        heff_drop(v_l_242);
        heff_drop(v_r_243);
        return heff_abandon();
      }
      case TAG_Bin: {
        V v_rk_24129 = heff_field(v_r_243, 1);
        V v_rv_24130 = heff_field(v_r_243, 2);
        V v_rl_24131 = heff_field(v_r_243, 3);
        V v_rr_24132 = heff_field(v_r_243, 4);
        V v_ru_24r_243_24Bin = heff_take_reuse(v_r_243, 30ULL);
        V v_a_24138;
        switch (heff_tag_of(v_rr_24132)) {
        case TAG_Tip: {
          v_a_24138 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24133 = heff_dup(heff_field(v_rr_24132, 0));
          v_a_24138 = v_h_24133;
          break;
        }
        default: heff_nomatch(v_rr_24132);
        }
        V v_b_24144;
        switch (heff_tag_of(v_rl_24131)) {
        case TAG_Tip: {
          v_b_24144 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24139 = heff_dup(heff_field(v_rl_24131, 0));
          v_b_24144 = v_h_24139;
          break;
        }
        default: heff_nomatch(v_rl_24131);
        }
        V v_t_24145 = heff_intLe(v_b_24144, v_a_24138);
        switch (heff_tag_of(v_t_24145)) {
        case TAG_True: {
          heff_drop(v_t_24145);
          V v_a_24151;
          switch (heff_tag_of(v_l_242)) {
          case TAG_Tip: {
            v_a_24151 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24146 = heff_dup(heff_field(v_l_242, 0));
            v_a_24151 = v_h_24146;
            break;
          }
          default: heff_nomatch(v_l_242);
          }
          V v_b_24157;
          switch (heff_tag_of(v_rl_24131)) {
          case TAG_Tip: {
            v_b_24157 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24152 = heff_dup(heff_field(v_rl_24131, 0));
            v_b_24157 = v_h_24152;
            break;
          }
          default: heff_nomatch(v_rl_24131);
          }
          V v_t_24158 = heff_intLe(heff_dup(v_a_24151), heff_dup(v_b_24157));
          V v_t_24159;
          switch (heff_tag_of(v_t_24158)) {
          case TAG_True: {
            heff_drop(v_a_24151);
            heff_drop(v_t_24158);
            v_t_24159 = v_b_24157;
            break;
          }
          case TAG_False: {
            heff_drop(v_b_24157);
            heff_drop(v_t_24158);
            v_t_24159 = v_a_24151;
            break;
          }
          default: heff_nomatch(v_t_24158);
          }
          V v_l_24160 = heff_tag_at(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24159), v_k_240, v_v_241, v_l_242, v_rl_24131});
          V v_a_24166;
          switch (heff_tag_of(v_l_24160)) {
          case TAG_Tip: {
            v_a_24166 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24161 = heff_dup(heff_field(v_l_24160, 0));
            v_a_24166 = v_h_24161;
            break;
          }
          default: heff_nomatch(v_l_24160);
          }
          V v_b_24172;
          switch (heff_tag_of(v_rr_24132)) {
          case TAG_Tip: {
            v_b_24172 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24167 = heff_dup(heff_field(v_rr_24132, 0));
            v_b_24172 = v_h_24167;
            break;
          }
          default: heff_nomatch(v_rr_24132);
          }
          V v_t_24173 = heff_intLe(heff_dup(v_a_24166), heff_dup(v_b_24172));
          V v_t_24174;
          switch (heff_tag_of(v_t_24173)) {
          case TAG_True: {
            heff_drop(v_a_24166);
            heff_drop(v_t_24173);
            v_t_24174 = v_b_24172;
            break;
          }
          case TAG_False: {
            heff_drop(v_b_24172);
            heff_drop(v_t_24173);
            v_t_24174 = v_a_24166;
            break;
          }
          default: heff_nomatch(v_t_24173);
          }
          return heff_tag(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24174), v_rk_24129, v_rv_24130, v_l_24160, v_rr_24132});
        }
        case TAG_False: {
          heff_drop(v_t_24145);
          switch (heff_tag_of(v_rl_24131)) {
          case TAG_Tip: {
            heff_drop(v_k_240);
            heff_drop(v_v_241);
            heff_drop(v_l_242);
            heff_drop(v_rk_24129);
            heff_drop(v_rv_24130);
            heff_drop(v_rl_24131);
            heff_drop(v_rr_24132);
            heff_drop(v_ru_24r_243_24Bin);
            return heff_abandon();
          }
          case TAG_Bin: {
            V v_mk_24176 = heff_field(v_rl_24131, 1);
            V v_mv_24177 = heff_field(v_rl_24131, 2);
            V v_ml_24178 = heff_field(v_rl_24131, 3);
            V v_mr_24179 = heff_field(v_rl_24131, 4);
            V v_ru_24rl_24131_24Bin = heff_take_reuse(v_rl_24131, 30ULL);
            V v_a_24185;
            switch (heff_tag_of(v_l_242)) {
            case TAG_Tip: {
              v_a_24185 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24180 = heff_dup(heff_field(v_l_242, 0));
              v_a_24185 = v_h_24180;
              break;
            }
            default: heff_nomatch(v_l_242);
            }
            V v_b_24191;
            switch (heff_tag_of(v_ml_24178)) {
            case TAG_Tip: {
              v_b_24191 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24186 = heff_dup(heff_field(v_ml_24178, 0));
              v_b_24191 = v_h_24186;
              break;
            }
            default: heff_nomatch(v_ml_24178);
            }
            V v_t_24192 = heff_intLe(heff_dup(v_a_24185), heff_dup(v_b_24191));
            V v_t_24193;
            switch (heff_tag_of(v_t_24192)) {
            case TAG_True: {
              heff_drop(v_a_24185);
              heff_drop(v_t_24192);
              v_t_24193 = v_b_24191;
              break;
            }
            case TAG_False: {
              heff_drop(v_b_24191);
              heff_drop(v_t_24192);
              v_t_24193 = v_a_24185;
              break;
            }
            default: heff_nomatch(v_t_24192);
            }
            V v_l_24194 = heff_tag_at(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24193), v_k_240, v_v_241, v_l_242, v_ml_24178});
            V v_a_24200;
            switch (heff_tag_of(v_mr_24179)) {
            case TAG_Tip: {
              v_a_24200 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24195 = heff_dup(heff_field(v_mr_24179, 0));
              v_a_24200 = v_h_24195;
              break;
            }
            default: heff_nomatch(v_mr_24179);
            }
            V v_b_24206;
            switch (heff_tag_of(v_rr_24132)) {
            case TAG_Tip: {
              v_b_24206 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24201 = heff_dup(heff_field(v_rr_24132, 0));
              v_b_24206 = v_h_24201;
              break;
            }
            default: heff_nomatch(v_rr_24132);
            }
            V v_t_24207 = heff_intLe(heff_dup(v_a_24200), heff_dup(v_b_24206));
            V v_t_24208;
            switch (heff_tag_of(v_t_24207)) {
            case TAG_True: {
              heff_drop(v_a_24200);
              heff_drop(v_t_24207);
              v_t_24208 = v_b_24206;
              break;
            }
            case TAG_False: {
              heff_drop(v_b_24206);
              heff_drop(v_t_24207);
              v_t_24208 = v_a_24200;
              break;
            }
            default: heff_nomatch(v_t_24207);
            }
            V v_r_24209 = heff_tag_at(v_ru_24rl_24131_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24208), v_rk_24129, v_rv_24130, v_mr_24179, v_rr_24132});
            V v_a_24215;
            switch (heff_tag_of(v_l_24194)) {
            case TAG_Tip: {
              v_a_24215 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24210 = heff_dup(heff_field(v_l_24194, 0));
              v_a_24215 = v_h_24210;
              break;
            }
            default: heff_nomatch(v_l_24194);
            }
            V v_b_24221;
            switch (heff_tag_of(v_r_24209)) {
            case TAG_Tip: {
              v_b_24221 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24216 = heff_dup(heff_field(v_r_24209, 0));
              v_b_24221 = v_h_24216;
              break;
            }
            default: heff_nomatch(v_r_24209);
            }
            V v_t_24222 = heff_intLe(heff_dup(v_a_24215), heff_dup(v_b_24221));
            V v_t_24223;
            switch (heff_tag_of(v_t_24222)) {
            case TAG_True: {
              heff_drop(v_a_24215);
              heff_drop(v_t_24222);
              v_t_24223 = v_b_24221;
              break;
            }
            case TAG_False: {
              heff_drop(v_b_24221);
              heff_drop(v_t_24222);
              v_t_24223 = v_a_24215;
              break;
            }
            default: heff_nomatch(v_t_24222);
            }
            return heff_tag(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24223), v_mk_24176, v_mv_24177, v_l_24194, v_r_24209});
          }
          default: return heff_nomatch(v_rl_24131);
          }
        }
        default: return heff_nomatch(v_t_24145);
        }
      }
      default: return heff_nomatch(v_r_243);
      }
    }
    case TAG_False: {
      heff_drop(v_t_24127);
      V v_a_24229;
      switch (heff_tag_of(v_l_242)) {
      case TAG_Tip: {
        v_a_24229 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24224 = heff_dup(heff_field(v_l_242, 0));
        v_a_24229 = v_h_24224;
        break;
      }
      default: heff_nomatch(v_l_242);
      }
      V v_b_24235;
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        v_b_24235 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24230 = heff_dup(heff_field(v_r_243, 0));
        v_b_24235 = v_h_24230;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_24236 = heff_intLe(heff_dup(v_a_24229), heff_dup(v_b_24235));
      V v_t_24237;
      switch (heff_tag_of(v_t_24236)) {
      case TAG_True: {
        heff_drop(v_a_24229);
        heff_drop(v_t_24236);
        v_t_24237 = v_b_24235;
        break;
      }
      case TAG_False: {
        heff_drop(v_b_24235);
        heff_drop(v_t_24236);
        v_t_24237 = v_a_24229;
        break;
      }
      default: heff_nomatch(v_t_24236);
      }
      return heff_tag(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24237), v_k_240, v_v_241, v_l_242, v_r_243});
    }
    default: return heff_nomatch(v_t_24127);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_map_2ebalance_entry(V self, V *a) {
  (void)self;
  return g_map_2ebalance(a[0], a[1], a[2], a[3]);
}
Clo g_map_2efindMin_clo = {{0x80000000u, K_CLO, 0}, g_map_2efindMin_entry, 1, 0};

V g_map_2efindMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_abandon();
  }
  case TAG_Bin: {
    V v_k_242 = heff_field(v_x1_240, 1);
    V v_v_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_k_242), heff_dup(v_v_243)});
    }
    case TAG_Bin: {
      V t_0 = v_x14_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2efindMin_entry(V self, V *a) {
  (void)self;
  V r = g_map_2efindMin(a[0]); heff_drop(a[0]); return r;
}
Clo g_map_2edeleteMin_clo = {{0x80000000u, K_CLO, 0}, g_map_2edeleteMin_entry, 1, 0};

V g_map_2edeleteMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_dup(v_r_245);
    }
    case TAG_Bin: {
      V v_t_2411 = (g_map_2edeleteMin(v_x14_244));
      return (g_map_2ebalance(heff_dup(v_x12_242), heff_dup(v_x13_243), v_t_2411, heff_dup(v_r_245)));
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2edeleteMin_entry(V self, V *a) {
  (void)self;
  V r = g_map_2edeleteMin(a[0]); heff_drop(a[0]); return r;
}
Clo g_map_2etoListOnto_clo = {{0x80000000u, K_CLO, 0}, g_map_2etoListOnto_entry, 2, 0};

V g_map_2etoListOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return v_acc_241;
  }
  case TAG_Bin: {
    V v_k_243 = heff_field(v_x1_240, 1);
    V v_v_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_k_243), heff_dup(v_v_244)}), (g_map_2etoListOnto(v_r_246, v_acc_241))});
    V t_0 = v_l_245;
    V t_1 = v_t_247;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2etoListOnto_entry(V self, V *a) {
  (void)self;
  V r = g_map_2etoListOnto(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_map_2esize_clo = {{0x80000000u, K_CLO, 0}, g_map_2esize_entry, 1, 0};

V g_map_2esize(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return MK_INT(0LL);
  }
  case TAG_Bin: {
    V v_l_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_t_246 = (g_map_2esize(v_l_244));
    V v_t_247 = (g_map_2esize(v_r_245));
    return heff_intAdd(heff_intAdd(v_t_246, MK_INT(1LL)), v_t_247);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2esize_entry(V self, V *a) {
  (void)self;
  V r = g_map_2esize(a[0]); heff_drop(a[0]); return r;
}
Clo g_map_2einsert_24s7_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s7_entry, 3, 0};

V g_map_2einsert_24s7(V v_k_240, V v_v_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    heff_drop(v_x4_242);
    return heff_tag(TAG_Bin, 5, (V[]){MK_INT(1LL), v_k_240, v_v_241, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x4_242, 0);
    V v_k_27_244 = heff_field(v_x4_242, 1);
    V v_v_27_245 = heff_field(v_x4_242, 2);
    V v_l_246 = heff_field(v_x4_242, 3);
    V v_r_247 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse(v_x4_242, 31ULL);
    V v_t_248 = heff_strLt(heff_dup(v_k_240), heff_dup(v_k_27_244));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_h_243);
      heff_drop(v_ru_24x4_242_24Bin);
      heff_drop(v_t_248);
      V v_t_249 = (g_map_2einsert_24s7(v_k_240, v_v_241, v_l_246));
      return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_t_249, v_r_247));
    }
    case TAG_False: {
      heff_drop(v_t_248);
      V v_t_2410 = heff_strEq(heff_dup(v_k_240), heff_dup(v_k_27_244));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        heff_drop(v_t_2410);
        return heff_tag_at(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_240, v_v_241, v_l_246, v_r_247});
      }
      case TAG_False: {
        heff_drop(v_h_243);
        heff_drop(v_ru_24x4_242_24Bin);
        heff_drop(v_t_2410);
        V v_t_2411 = (g_map_2einsert_24s7(v_k_240, v_v_241, v_r_247));
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_t_2411));
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s7_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s7(a[0], a[1], a[2]);
}
Clo g_map_2elookup_24s8_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s8_entry, 2, 0};

V g_map_2elookup_24s8(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_t_247 = heff_strLt(heff_dup(v_k_240), heff_dup(v_k_27_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_247);
      V v_t_248 = heff_strEq(heff_dup(v_k_240), heff_dup(v_k_27_243));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_k_240);
        heff_drop(v_t_248);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      }
      case TAG_False: {
        heff_drop(v_t_248);
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s8_entry(V self, V *a) {
  (void)self;
  V r = g_map_2elookup_24s8(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_map_2elookup_24s9_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s9_entry, 2, 0};

V g_map_2elookup_24s9(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_t_247 = heff_strLt(heff_dup(v_k_240), heff_dup(v_k_27_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_247);
      V v_t_248 = heff_strEq(heff_dup(v_k_240), heff_dup(v_k_27_243));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_k_240);
        heff_drop(v_t_248);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      }
      case TAG_False: {
        heff_drop(v_t_248);
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s9_entry(V self, V *a) {
  (void)self;
  V r = g_map_2elookup_24s9(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_map_2elookup_24s12_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s12_entry, 2, 0};

V g_map_2elookup_24s12(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_t_247 = heff_intLt(heff_dup(v_k_240), heff_dup(v_k_27_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_247);
      V v_t_248 = heff_intEq(heff_dup(v_k_240), heff_dup(v_k_27_243));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_k_240);
        heff_drop(v_t_248);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      }
      case TAG_False: {
        heff_drop(v_t_248);
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s12_entry(V self, V *a) {
  (void)self;
  V r = g_map_2elookup_24s12(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_map_2einsert_24s214_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s214_entry, 3, 0};

V g_map_2einsert_24s214(V v_k_240, V v_v_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    heff_drop(v_x4_242);
    return heff_tag(TAG_Bin, 5, (V[]){MK_INT(1LL), v_k_240, v_v_241, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x4_242, 0);
    V v_k_27_244 = heff_field(v_x4_242, 1);
    V v_v_27_245 = heff_field(v_x4_242, 2);
    V v_l_246 = heff_field(v_x4_242, 3);
    V v_r_247 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse(v_x4_242, 31ULL);
    V v_t_248 = heff_intLt(heff_dup(v_k_240), heff_dup(v_k_27_244));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_h_243);
      heff_drop(v_ru_24x4_242_24Bin);
      heff_drop(v_t_248);
      V v_t_249 = (g_map_2einsert_24s214(v_k_240, v_v_241, v_l_246));
      return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_t_249, v_r_247));
    }
    case TAG_False: {
      heff_drop(v_t_248);
      V v_t_2410 = heff_intEq(heff_dup(v_k_240), heff_dup(v_k_27_244));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        heff_drop(v_t_2410);
        return heff_tag_at(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_240, v_v_241, v_l_246, v_r_247});
      }
      case TAG_False: {
        heff_drop(v_h_243);
        heff_drop(v_ru_24x4_242_24Bin);
        heff_drop(v_t_2410);
        V v_t_2411 = (g_map_2einsert_24s214(v_k_240, v_v_241, v_r_247));
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_t_2411));
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s214_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s214(a[0], a[1], a[2]);
}
Clo g_map_2elookup_24s413_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s413_entry, 2, 0};

V g_map_2elookup_24s413(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_t_247 = heff_intLt(heff_dup(v_k_240), heff_dup(v_k_27_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_247);
      V v_t_248 = heff_intEq(heff_dup(v_k_240), heff_dup(v_k_27_243));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_k_240);
        heff_drop(v_t_248);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      }
      case TAG_False: {
        heff_drop(v_t_248);
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s413_entry(V self, V *a) {
  (void)self;
  V r = g_map_2elookup_24s413(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_map_2edelete_24s831_clo = {{0x80000000u, K_CLO, 0}, g_map_2edelete_24s831_entry, 2, 0};

V g_map_2edelete_24s831(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_t_247 = heff_strLt(heff_dup(v_k_240), heff_dup(v_k_27_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      V v_t_248 = (g_map_2edelete_24s831(v_k_240, v_l_245));
      return (g_map_2ebalance(heff_dup(v_k_27_243), heff_dup(v_v_27_244), v_t_248, heff_dup(v_r_246)));
    }
    case TAG_False: {
      heff_drop(v_t_247);
      V v_t_249 = heff_strEq(heff_dup(v_k_240), heff_dup(v_k_27_243));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_k_240);
        heff_drop(v_t_249);
        switch (heff_tag_of(v_r_246)) {
        case TAG_Tip: {
          return heff_dup(v_l_245);
        }
        case TAG_Bin: {
          V v_t_2415 = (g_map_2efindMin(v_r_246));
          switch (heff_tag_of(v_t_2415)) {
          case TAG_MkPair: {
            V v_k_2416 = heff_field(v_t_2415, 0);
            V v_v_2417 = heff_field(v_t_2415, 1);
            heff_take(v_t_2415, 3ULL);
            V v_t_2418 = (g_map_2edeleteMin(v_r_246));
            return (g_map_2ebalance(v_k_2416, v_v_2417, heff_dup(v_l_245), v_t_2418));
          }
          default: return heff_nomatch(v_t_2415);
          }
        }
        default: return heff_nomatch(v_r_246);
        }
      }
      case TAG_False: {
        heff_drop(v_t_249);
        V v_t_2419 = (g_map_2edelete_24s831(v_k_240, v_r_246));
        return (g_map_2ebalance(heff_dup(v_k_27_243), heff_dup(v_v_27_244), heff_dup(v_l_245), v_t_2419));
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2edelete_24s831_entry(V self, V *a) {
  (void)self;
  V r = g_map_2edelete_24s831(a[0], a[1]); heff_drop(a[1]); return r;
}