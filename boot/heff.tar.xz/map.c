// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_Tip 31527
V g_map_2ebalance(V, V, V, V);
V g_map_2ebalance_entry(V self, V *a);
extern Clo g_map_2ebalance_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2edeleteMin(V);
V g_map_2edeleteMin_entry(V self, V *a);
extern Clo g_map_2edeleteMin_clo;
V g_map_2eempty_get(void);
V g_map_2efindMin(V);
V g_map_2efindMin_entry(V self, V *a);
extern Clo g_map_2efindMin_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2emapValues(V, V);
V g_map_2emapValues_entry(V self, V *a);
extern Clo g_map_2emapValues_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;

static V g_map_2eempty_val;
static HEFF_ONCE g_map_2eempty_st;
static V g_map_2eempty_init(void) {
  return NTAG(TAG_Tip);
}
V g_map_2eempty_get(void) {
  if (HEFF_DONE(g_map_2eempty_st)) return g_map_2eempty_val;
  return heff_global(&g_map_2eempty_val, &g_map_2eempty_st, g_map_2eempty_init);
}
Clo g_map_2ebalance_clo = {{0x80000000u, K_CLO, 0}, g_map_2ebalance_entry, 4, 0};

V g_map_2ebalance(V v_k_240, V v_v_241, V v_l_242, V v_r_243) {
top: ;
  V v_a_249;
  switch (heff_tag_of(v_l_242)) {
  case TAG_Tip: {
    v_a_249 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_244 = heff_dup(heff_field(v_l_242, 0));
    v_a_249 = v_h_244;
    break;
  }
  default: heff_nomatch(v_l_242);
  }
  V v_t_2415;
  switch (heff_tag_of(v_r_243)) {
  case TAG_Tip: {
    v_t_2415 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_2410 = heff_dup(heff_field(v_r_243, 0));
    v_t_2415 = v_h_2410;
    break;
  }
  default: heff_nomatch(v_r_243);
  }
  V v_b_2416 = heff_intAdd(v_t_2415, MK_INT(1LL));
  if (heff_intLt_c(v_b_2416, v_a_249)) {
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      heff_drop(v_k_240);
      heff_drop(v_v_241);
      heff_drop(v_r_243);
      return heff_abandon();
    }
    case TAG_Bin: {
      V v_lk_2419 = heff_field(v_l_242, 1);
      V v_lv_2420 = heff_field(v_l_242, 2);
      V v_ll_2421 = heff_field(v_l_242, 3);
      V v_lr_2422 = heff_field(v_l_242, 4);
      V v_ru_24l_242_24Bin = heff_take_reuse_n(v_l_242, 30ULL, 5);
      V v_a_2428;
      switch (heff_tag_of(v_ll_2421)) {
      case TAG_Tip: {
        v_a_2428 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2423 = heff_dup(heff_field(v_ll_2421, 0));
        v_a_2428 = v_h_2423;
        break;
      }
      default: heff_nomatch(v_ll_2421);
      }
      V v_b_2434;
      switch (heff_tag_of(v_lr_2422)) {
      case TAG_Tip: {
        v_b_2434 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2429 = heff_dup(heff_field(v_lr_2422, 0));
        v_b_2434 = v_h_2429;
        break;
      }
      default: heff_nomatch(v_lr_2422);
      }
      if (heff_intLe_c(v_b_2434, v_a_2428)) {
        V v_a_2441;
        switch (heff_tag_of(v_lr_2422)) {
        case TAG_Tip: {
          v_a_2441 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2436 = heff_dup(heff_field(v_lr_2422, 0));
          v_a_2441 = v_h_2436;
          break;
        }
        default: heff_nomatch(v_lr_2422);
        }
        V v_b_2447;
        switch (heff_tag_of(v_r_243)) {
        case TAG_Tip: {
          v_b_2447 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2442 = heff_dup(heff_field(v_r_243, 0));
          v_b_2447 = v_h_2442;
          break;
        }
        default: heff_nomatch(v_r_243);
        }
        V v_t_2449;
        if (heff_intLe_c(heff_dup(v_a_2441), heff_dup(v_b_2447))) {
          heff_drop(v_a_2441);
          v_t_2449 = v_b_2447;
        } else {
          heff_drop(v_b_2447);
          v_t_2449 = v_a_2441;
        }
        V v_r_2450 = heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2449), v_k_240, v_v_241, v_lr_2422, v_r_243});
        V v_a_2456;
        switch (heff_tag_of(v_ll_2421)) {
        case TAG_Tip: {
          v_a_2456 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2451 = heff_dup(heff_field(v_ll_2421, 0));
          v_a_2456 = v_h_2451;
          break;
        }
        default: heff_nomatch(v_ll_2421);
        }
        V v_b_2462;
        switch (heff_tag_of(v_r_2450)) {
        case TAG_Tip: {
          v_b_2462 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2457 = heff_dup(heff_field(v_r_2450, 0));
          v_b_2462 = v_h_2457;
          break;
        }
        default: heff_nomatch(v_r_2450);
        }
        V v_t_2464;
        if (heff_intLe_c(heff_dup(v_a_2456), heff_dup(v_b_2462))) {
          heff_drop(v_a_2456);
          v_t_2464 = v_b_2462;
        } else {
          heff_drop(v_b_2462);
          v_t_2464 = v_a_2456;
        }
        return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2464), v_lk_2419, v_lv_2420, v_ll_2421, v_r_2450});
      } else {
        switch (heff_tag_of(v_lr_2422)) {
        case TAG_Tip: {
          heff_drop(v_k_240);
          heff_drop(v_v_241);
          heff_drop(v_r_243);
          heff_drop(v_lk_2419);
          heff_drop(v_lv_2420);
          heff_drop(v_ll_2421);
          heff_drop_cell(v_ru_24l_242_24Bin, 5);
          return heff_abandon();
        }
        case TAG_Bin: {
          V v_mk_2466 = heff_field(v_lr_2422, 1);
          V v_mv_2467 = heff_field(v_lr_2422, 2);
          V v_ml_2468 = heff_field(v_lr_2422, 3);
          V v_mr_2469 = heff_field(v_lr_2422, 4);
          V v_ru_24lr_2422_24Bin = heff_take_reuse_n(v_lr_2422, 30ULL, 5);
          V v_a_2475;
          switch (heff_tag_of(v_ll_2421)) {
          case TAG_Tip: {
            v_a_2475 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2470 = heff_dup(heff_field(v_ll_2421, 0));
            v_a_2475 = v_h_2470;
            break;
          }
          default: heff_nomatch(v_ll_2421);
          }
          V v_b_2481;
          switch (heff_tag_of(v_ml_2468)) {
          case TAG_Tip: {
            v_b_2481 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2476 = heff_dup(heff_field(v_ml_2468, 0));
            v_b_2481 = v_h_2476;
            break;
          }
          default: heff_nomatch(v_ml_2468);
          }
          V v_t_2483;
          if (heff_intLe_c(heff_dup(v_a_2475), heff_dup(v_b_2481))) {
            heff_drop(v_a_2475);
            v_t_2483 = v_b_2481;
          } else {
            heff_drop(v_b_2481);
            v_t_2483 = v_a_2475;
          }
          V v_l_2484 = heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2483), v_lk_2419, v_lv_2420, v_ll_2421, v_ml_2468});
          V v_a_2490;
          switch (heff_tag_of(v_mr_2469)) {
          case TAG_Tip: {
            v_a_2490 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2485 = heff_dup(heff_field(v_mr_2469, 0));
            v_a_2490 = v_h_2485;
            break;
          }
          default: heff_nomatch(v_mr_2469);
          }
          V v_b_2496;
          switch (heff_tag_of(v_r_243)) {
          case TAG_Tip: {
            v_b_2496 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2491 = heff_dup(heff_field(v_r_243, 0));
            v_b_2496 = v_h_2491;
            break;
          }
          default: heff_nomatch(v_r_243);
          }
          V v_t_2498;
          if (heff_intLe_c(heff_dup(v_a_2490), heff_dup(v_b_2496))) {
            heff_drop(v_a_2490);
            v_t_2498 = v_b_2496;
          } else {
            heff_drop(v_b_2496);
            v_t_2498 = v_a_2490;
          }
          V v_r_2499 = heff_tag_at_n(v_ru_24lr_2422_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2498), v_k_240, v_v_241, v_mr_2469, v_r_243});
          V v_a_24105;
          switch (heff_tag_of(v_l_2484)) {
          case TAG_Tip: {
            v_a_24105 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24100 = heff_dup(heff_field(v_l_2484, 0));
            v_a_24105 = v_h_24100;
            break;
          }
          default: heff_nomatch(v_l_2484);
          }
          V v_b_24111;
          switch (heff_tag_of(v_r_2499)) {
          case TAG_Tip: {
            v_b_24111 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24106 = heff_dup(heff_field(v_r_2499, 0));
            v_b_24111 = v_h_24106;
            break;
          }
          default: heff_nomatch(v_r_2499);
          }
          V v_t_24113;
          if (heff_intLe_c(heff_dup(v_a_24105), heff_dup(v_b_24111))) {
            heff_drop(v_a_24105);
            v_t_24113 = v_b_24111;
          } else {
            heff_drop(v_b_24111);
            v_t_24113 = v_a_24105;
          }
          return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24113), v_mk_2466, v_mv_2467, v_l_2484, v_r_2499});
        }
        default: return heff_nomatch(v_lr_2422);
        }
      }
    }
    default: return heff_nomatch(v_l_242);
    }
  } else {
    V v_a_24119;
    switch (heff_tag_of(v_r_243)) {
    case TAG_Tip: {
      v_a_24119 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_24114 = heff_dup(heff_field(v_r_243, 0));
      v_a_24119 = v_h_24114;
      break;
    }
    default: heff_nomatch(v_r_243);
    }
    V v_t_24125;
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      v_t_24125 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_24120 = heff_dup(heff_field(v_l_242, 0));
      v_t_24125 = v_h_24120;
      break;
    }
    default: heff_nomatch(v_l_242);
    }
    V v_b_24126 = heff_intAdd(v_t_24125, MK_INT(1LL));
    if (heff_intLt_c(v_b_24126, v_a_24119)) {
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        heff_drop(v_k_240);
        heff_drop(v_v_241);
        heff_drop(v_l_242);
        return heff_abandon();
      }
      case TAG_Bin: {
        V v_rk_24129 = heff_field(v_r_243, 1);
        V v_rv_24130 = heff_field(v_r_243, 2);
        V v_rl_24131 = heff_field(v_r_243, 3);
        V v_rr_24132 = heff_field(v_r_243, 4);
        V v_ru_24r_243_24Bin = heff_take_reuse_n(v_r_243, 30ULL, 5);
        V v_a_24138;
        switch (heff_tag_of(v_rr_24132)) {
        case TAG_Tip: {
          v_a_24138 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24133 = heff_dup(heff_field(v_rr_24132, 0));
          v_a_24138 = v_h_24133;
          break;
        }
        default: heff_nomatch(v_rr_24132);
        }
        V v_b_24144;
        switch (heff_tag_of(v_rl_24131)) {
        case TAG_Tip: {
          v_b_24144 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24139 = heff_dup(heff_field(v_rl_24131, 0));
          v_b_24144 = v_h_24139;
          break;
        }
        default: heff_nomatch(v_rl_24131);
        }
        if (heff_intLe_c(v_b_24144, v_a_24138)) {
          V v_a_24151;
          switch (heff_tag_of(v_l_242)) {
          case TAG_Tip: {
            v_a_24151 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24146 = heff_dup(heff_field(v_l_242, 0));
            v_a_24151 = v_h_24146;
            break;
          }
          default: heff_nomatch(v_l_242);
          }
          V v_b_24157;
          switch (heff_tag_of(v_rl_24131)) {
          case TAG_Tip: {
            v_b_24157 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24152 = heff_dup(heff_field(v_rl_24131, 0));
            v_b_24157 = v_h_24152;
            break;
          }
          default: heff_nomatch(v_rl_24131);
          }
          V v_t_24159;
          if (heff_intLe_c(heff_dup(v_a_24151), heff_dup(v_b_24157))) {
            heff_drop(v_a_24151);
            v_t_24159 = v_b_24157;
          } else {
            heff_drop(v_b_24157);
            v_t_24159 = v_a_24151;
          }
          V v_l_24160 = heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24159), v_k_240, v_v_241, v_l_242, v_rl_24131});
          V v_a_24166;
          switch (heff_tag_of(v_l_24160)) {
          case TAG_Tip: {
            v_a_24166 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24161 = heff_dup(heff_field(v_l_24160, 0));
            v_a_24166 = v_h_24161;
            break;
          }
          default: heff_nomatch(v_l_24160);
          }
          V v_b_24172;
          switch (heff_tag_of(v_rr_24132)) {
          case TAG_Tip: {
            v_b_24172 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24167 = heff_dup(heff_field(v_rr_24132, 0));
            v_b_24172 = v_h_24167;
            break;
          }
          default: heff_nomatch(v_rr_24132);
          }
          V v_t_24174;
          if (heff_intLe_c(heff_dup(v_a_24166), heff_dup(v_b_24172))) {
            heff_drop(v_a_24166);
            v_t_24174 = v_b_24172;
          } else {
            heff_drop(v_b_24172);
            v_t_24174 = v_a_24166;
          }
          return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24174), v_rk_24129, v_rv_24130, v_l_24160, v_rr_24132});
        } else {
          switch (heff_tag_of(v_rl_24131)) {
          case TAG_Tip: {
            heff_drop(v_k_240);
            heff_drop(v_v_241);
            heff_drop(v_l_242);
            heff_drop(v_rk_24129);
            heff_drop(v_rv_24130);
            heff_drop(v_rr_24132);
            heff_drop_cell(v_ru_24r_243_24Bin, 5);
            return heff_abandon();
          }
          case TAG_Bin: {
            V v_mk_24176 = heff_field(v_rl_24131, 1);
            V v_mv_24177 = heff_field(v_rl_24131, 2);
            V v_ml_24178 = heff_field(v_rl_24131, 3);
            V v_mr_24179 = heff_field(v_rl_24131, 4);
            V v_ru_24rl_24131_24Bin = heff_take_reuse_n(v_rl_24131, 30ULL, 5);
            V v_a_24185;
            switch (heff_tag_of(v_l_242)) {
            case TAG_Tip: {
              v_a_24185 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24180 = heff_dup(heff_field(v_l_242, 0));
              v_a_24185 = v_h_24180;
              break;
            }
            default: heff_nomatch(v_l_242);
            }
            V v_b_24191;
            switch (heff_tag_of(v_ml_24178)) {
            case TAG_Tip: {
              v_b_24191 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24186 = heff_dup(heff_field(v_ml_24178, 0));
              v_b_24191 = v_h_24186;
              break;
            }
            default: heff_nomatch(v_ml_24178);
            }
            V v_t_24193;
            if (heff_intLe_c(heff_dup(v_a_24185), heff_dup(v_b_24191))) {
              heff_drop(v_a_24185);
              v_t_24193 = v_b_24191;
            } else {
              heff_drop(v_b_24191);
              v_t_24193 = v_a_24185;
            }
            V v_l_24194 = heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24193), v_k_240, v_v_241, v_l_242, v_ml_24178});
            V v_a_24200;
            switch (heff_tag_of(v_mr_24179)) {
            case TAG_Tip: {
              v_a_24200 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24195 = heff_dup(heff_field(v_mr_24179, 0));
              v_a_24200 = v_h_24195;
              break;
            }
            default: heff_nomatch(v_mr_24179);
            }
            V v_b_24206;
            switch (heff_tag_of(v_rr_24132)) {
            case TAG_Tip: {
              v_b_24206 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24201 = heff_dup(heff_field(v_rr_24132, 0));
              v_b_24206 = v_h_24201;
              break;
            }
            default: heff_nomatch(v_rr_24132);
            }
            V v_t_24208;
            if (heff_intLe_c(heff_dup(v_a_24200), heff_dup(v_b_24206))) {
              heff_drop(v_a_24200);
              v_t_24208 = v_b_24206;
            } else {
              heff_drop(v_b_24206);
              v_t_24208 = v_a_24200;
            }
            V v_r_24209 = heff_tag_at_n(v_ru_24rl_24131_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24208), v_rk_24129, v_rv_24130, v_mr_24179, v_rr_24132});
            V v_a_24215;
            switch (heff_tag_of(v_l_24194)) {
            case TAG_Tip: {
              v_a_24215 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24210 = heff_dup(heff_field(v_l_24194, 0));
              v_a_24215 = v_h_24210;
              break;
            }
            default: heff_nomatch(v_l_24194);
            }
            V v_b_24221;
            switch (heff_tag_of(v_r_24209)) {
            case TAG_Tip: {
              v_b_24221 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24216 = heff_dup(heff_field(v_r_24209, 0));
              v_b_24221 = v_h_24216;
              break;
            }
            default: heff_nomatch(v_r_24209);
            }
            V v_t_24223;
            if (heff_intLe_c(heff_dup(v_a_24215), heff_dup(v_b_24221))) {
              heff_drop(v_a_24215);
              v_t_24223 = v_b_24221;
            } else {
              heff_drop(v_b_24221);
              v_t_24223 = v_a_24215;
            }
            return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24223), v_mk_24176, v_mv_24177, v_l_24194, v_r_24209});
          }
          default: return heff_nomatch(v_rl_24131);
          }
        }
      }
      default: return heff_nomatch(v_r_243);
      }
    } else {
      V v_a_24229;
      switch (heff_tag_of(v_l_242)) {
      case TAG_Tip: {
        v_a_24229 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24224 = heff_dup(heff_field(v_l_242, 0));
        v_a_24229 = v_h_24224;
        break;
      }
      default: heff_nomatch(v_l_242);
      }
      V v_b_24235;
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        v_b_24235 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24230 = heff_dup(heff_field(v_r_243, 0));
        v_b_24235 = v_h_24230;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_24237;
      if (heff_intLe_c(heff_dup(v_a_24229), heff_dup(v_b_24235))) {
        heff_drop(v_a_24229);
        v_t_24237 = v_b_24235;
      } else {
        heff_drop(v_b_24235);
        v_t_24237 = v_a_24229;
      }
      return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24237), v_k_240, v_v_241, v_l_242, v_r_243});
    }
  }
}
V g_map_2ebalance_entry(V self, V *a) {
  (void)self;
  return g_map_2ebalance(a[0], a[1], a[2], a[3]);
}
Clo g_map_2efindMin_clo = {{0x80000000u, K_CLO, 0}, g_map_2efindMin_entry, 1, 0};

V g_map_2efindMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return heff_abandon();
  }
  case TAG_Bin: {
    V v_k_242 = heff_field(v_x1_240, 1);
    V v_v_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_242), heff_dup(v_v_243)});
    }
    case TAG_Bin: {
      V t_0 = v_x14_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2efindMin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2efindMin(a0); heff_drop(a0); return r;
}
Clo g_map_2edeleteMin_clo = {{0x80000000u, K_CLO, 0}, g_map_2edeleteMin_entry, 1, 0};

V g_map_2edeleteMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_dup(v_r_245);
    }
    case TAG_Bin: {
      V v_t_2411 = (g_map_2edeleteMin(v_x14_244));
      return (g_map_2ebalance(heff_dup(v_x12_242), heff_dup(v_x13_243), v_t_2411, heff_dup(v_r_245)));
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2edeleteMin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2edeleteMin(a0); heff_drop(a0); return r;
}
Clo g_map_2etoListOnto_clo = {{0x80000000u, K_CLO, 0}, g_map_2etoListOnto_entry, 2, 0};

V g_map_2etoListOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return v_acc_241;
  }
  case TAG_Bin: {
    V v_k_243 = heff_field(v_x1_240, 1);
    V v_v_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_243), heff_dup(v_v_244)}), (g_map_2etoListOnto(v_r_246, v_acc_241))});
    V t_0 = v_l_245;
    V t_1 = v_t_247;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2etoListOnto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2etoListOnto(a0, a[1]); heff_drop(a0); return r;
}
Clo g_map_2esize_clo = {{0x80000000u, K_CLO, 0}, g_map_2esize_entry, 1, 0};

V g_map_2esize(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return MK_INT(0LL);
  }
  case TAG_Bin: {
    V v_l_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_t_246 = (g_map_2esize(v_l_244));
    V v_t_247 = (g_map_2esize(v_r_245));
    return heff_intAdd(heff_intAdd(v_t_246, MK_INT(1LL)), v_t_247);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2esize_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2esize(a0); heff_drop(a0); return r;
}
Clo g_map_2emapValues_clo = {{0x80000000u, K_CLO, 0}, g_map_2emapValues_entry, 2, 0};

V g_map_2emapValues(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_241, 0);
    V v_k_243 = heff_field(v_x2_241, 1);
    V v_v_244 = heff_field(v_x2_241, 2);
    V v_l_245 = heff_field(v_x2_241, 3);
    V v_r_246 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_244}));
    V v_t_248 = (g_map_2emapValues(heff_dup(v_f_240), v_l_245));
    return heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, v_t_247, v_t_248, (g_map_2emapValues(v_f_240, v_r_246))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_map_2emapValues_entry(V self, V *a) {
  (void)self;
  return g_map_2emapValues(a[0], a[1]);
}
Clo g_map_2einsert_24s1341440536x470972936_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s1341440536x470972936_entry, 3, 0};

V g_map_2einsert_24s1341440536x470972936(V v_k_240, V v_v_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_k_240, v_v_241, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x4_242, 0);
    V v_k_27_244 = heff_field(v_x4_242, 1);
    V v_v_27_245 = heff_field(v_x4_242, 2);
    V v_l_246 = heff_field(v_x4_242, 3);
    V v_r_247 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    if (heff_strLt_c(heff_dup(v_k_240), heff_dup(v_k_27_244))) {
      heff_drop(v_h_243);
      heff_drop_cell(v_ru_24x4_242_24Bin, 5);
      V v_t_249 = (g_map_2einsert_24s1341440536x470972936(v_k_240, v_v_241, v_l_246));
      return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_t_249, v_r_247));
    } else {
      if (heff_strEq_c(heff_dup(v_k_240), heff_dup(v_k_27_244))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_240, v_v_241, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(v_k_240, v_v_241, v_r_247));
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_t_2411));
      }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s1341440536x470972936(a[0], a[1], a[2]);
}
Clo g_map_2elookup_24s1546226666x2146984184_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s1546226666x2146984184_entry, 2, 0};

V g_map_2elookup_24s1546226666x2146984184(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    if (heff_strLt_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_strEq_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s1546226666x2146984184(a[0], a1); heff_drop(a1); return r;
}
Clo g_map_2elookup_24s659669741x1036301430_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s659669741x1036301430_entry, 2, 0};

V g_map_2elookup_24s659669741x1036301430(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    if (heff_strLt_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_strEq_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s659669741x1036301430(a[0], a1); heff_drop(a1); return r;
}
Clo g_map_2elookup_24s567992785x1569911877_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s567992785x1569911877_entry, 2, 0};

V g_map_2elookup_24s567992785x1569911877(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    if (heff_intLt_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s567992785x1569911877(a[0], a1); heff_drop(a1); return r;
}
Clo g_map_2edelete_24s805420727x38051515_clo = {{0x80000000u, K_CLO, 0}, g_map_2edelete_24s805420727x38051515_entry, 2, 0};

V g_map_2edelete_24s805420727x38051515(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    if (heff_strLt_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
      V v_t_248 = (g_map_2edelete_24s805420727x38051515(v_k_240, v_l_245));
      return (g_map_2ebalance(heff_dup(v_k_27_243), heff_dup(v_v_27_244), v_t_248, heff_dup(v_r_246)));
    } else {
      if (heff_strEq_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
        heff_drop(v_k_240);
        switch (heff_tag_of(v_r_246)) {
        case TAG_Tip: {
          return heff_dup(v_l_245);
        }
        case TAG_Bin: {
          V v_t_2415 = (g_map_2efindMin(v_r_246));
          switch (heff_tag_of(v_t_2415)) {
          case TAG_MkPair: {
            V v_k_2416 = heff_field(v_t_2415, 0);
            V v_v_2417 = heff_field(v_t_2415, 1);
            heff_take_n(v_t_2415, 3ULL, 2);
            V v_t_2418 = (g_map_2edeleteMin(v_r_246));
            return (g_map_2ebalance(v_k_2416, v_v_2417, heff_dup(v_l_245), v_t_2418));
          }
          default: return heff_nomatch(v_t_2415);
          }
        }
        default: return heff_nomatch(v_r_246);
        }
      } else {
        V v_t_2419 = (g_map_2edelete_24s805420727x38051515(v_k_240, v_r_246));
        return (g_map_2ebalance(heff_dup(v_k_27_243), heff_dup(v_v_27_244), heff_dup(v_l_245), v_t_2419));
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2edelete_24s805420727x38051515(a[0], a1); heff_drop(a1); return r;
}
Clo g_map_2einsert_24s1689409319x1710080871_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s1689409319x1710080871_entry, 3, 0};

V g_map_2einsert_24s1689409319x1710080871(V v_k_240, V v_v_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_k_240, v_v_241, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x4_242, 0);
    V v_k_27_244 = heff_field(v_x4_242, 1);
    V v_v_27_245 = heff_field(v_x4_242, 2);
    V v_l_246 = heff_field(v_x4_242, 3);
    V v_r_247 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    if (heff_intLt_c(heff_dup(v_k_240), heff_dup(v_k_27_244))) {
      heff_drop(v_h_243);
      heff_drop_cell(v_ru_24x4_242_24Bin, 5);
      V v_t_249 = (g_map_2einsert_24s1689409319x1710080871(v_k_240, v_v_241, v_l_246));
      return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_t_249, v_r_247));
    } else {
      if (heff_intEq_c(heff_dup(v_k_240), heff_dup(v_k_27_244))) {
        heff_drop(v_k_27_244);
        heff_drop(v_v_27_245);
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_240, v_v_241, v_l_246, v_r_247});
      } else {
        heff_drop(v_h_243);
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        V v_t_2411 = (g_map_2einsert_24s1689409319x1710080871(v_k_240, v_v_241, v_r_247));
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_t_2411));
      }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s1689409319x1710080871(a[0], a[1], a[2]);
}
Clo g_map_2elookup_24s1338854231x236594845_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s1338854231x236594845_entry, 2, 0};

V g_map_2elookup_24s1338854231x236594845(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    if (heff_intLt_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s1338854231x236594845(a[0], a1); heff_drop(a1); return r;
}