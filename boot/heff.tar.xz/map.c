// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_EQ 8989
#define TAG_GT 9054
#define TAG_LT 9209
#define TAG_Tip 31527
V g_map_2ebalance(V, V, V, V);
V g_map_2ebalance_entry(V self, V *a);
extern Clo g_map_2ebalance_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2edeleteMin(V);
V g_map_2edeleteMin_entry(V self, V *a);
extern Clo g_map_2edeleteMin_clo;
V g_map_2eempty_get(void);
V g_map_2efindMin(V);
V g_map_2efindMin_entry(V self, V *a);
extern Clo g_map_2efindMin_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1687968944x933869791(V, V, V);
V g_map_2einsert_24s1687968944x933869791_entry(V self, V *a);
extern Clo g_map_2einsert_24s1687968944x933869791_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2einsert_24s1705770630x2073956475(V, V, V);
V g_map_2einsert_24s1705770630x2073956475_entry(V self, V *a);
extern Clo g_map_2einsert_24s1705770630x2073956475_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2emapValues(V, V);
V g_map_2emapValues_entry(V self, V *a);
extern Clo g_map_2emapValues_clo;
V g_map_2emapValues_24dps(V, V, V);
V g_map_2emapValues_24dps_entry(V self, V *a);
extern Clo g_map_2emapValues_24dps_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;

static V g_map_2eempty_val;
static HEFF_ONCE g_map_2eempty_st;
static V g_map_2eempty_init(void) {
  return NTAG(TAG_Tip);
}
V g_map_2eempty_get(void) {
  if (HEFF_DONE(g_map_2eempty_st)) return g_map_2eempty_val;
  return heff_global(&g_map_2eempty_val, &g_map_2eempty_st, g_map_2eempty_init);
}
Clo g_map_2ebalance_clo = {{0x80000000u, K_CLO, 0}, g_map_2ebalance_entry, 4, 0};

V g_map_2ebalance(V v_k_240, V v_v_241, V v_l_242, V v_r_243) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_r_243)) {
  case TAG_Tip: {
    v_t_249 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_244 = heff_dup(heff_field(v_r_243, 0));
    v_t_249 = v_h_244;
    break;
  }
  default: heff_nomatch(v_r_243);
  }
  V v_t_2415;
  switch (heff_tag_of(v_l_242)) {
  case TAG_Tip: {
    v_t_2415 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_2410 = heff_dup(heff_field(v_l_242, 0));
    v_t_2415 = v_h_2410;
    break;
  }
  default: heff_nomatch(v_l_242);
  }
  if (heff_intLt_c(heff_intAdd(v_t_249, MK_INT(1LL)), v_t_2415)) {
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      heff_drop(v_k_240);
      heff_drop(v_v_241);
      heff_drop(v_r_243);
      return heff_abandon();
    }
    case TAG_Bin: {
      V v_lk_2418 = heff_field(v_l_242, 1);
      V v_lv_2419 = heff_field(v_l_242, 2);
      V v_ll_2420 = heff_field(v_l_242, 3);
      V v_lr_2421 = heff_field(v_l_242, 4);
      V v_ru_24l_242_24Bin = heff_take_reuse_n(v_l_242, 30ULL, 5);
      V v_t_2427;
      switch (heff_tag_of(v_lr_2421)) {
      case TAG_Tip: {
        v_t_2427 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2422 = heff_dup(heff_field(v_lr_2421, 0));
        v_t_2427 = v_h_2422;
        break;
      }
      default: heff_nomatch(v_lr_2421);
      }
      V v_t_2433;
      switch (heff_tag_of(v_ll_2420)) {
      case TAG_Tip: {
        v_t_2433 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2428 = heff_dup(heff_field(v_ll_2420, 0));
        v_t_2433 = v_h_2428;
        break;
      }
      default: heff_nomatch(v_ll_2420);
      }
      if (heff_intLe_c(v_t_2427, v_t_2433)) {
        V v_x_2440;
        switch (heff_tag_of(v_lr_2421)) {
        case TAG_Tip: {
          v_x_2440 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2435 = heff_dup(heff_field(v_lr_2421, 0));
          v_x_2440 = v_h_2435;
          break;
        }
        default: heff_nomatch(v_lr_2421);
        }
        V v_y_2446;
        switch (heff_tag_of(v_r_243)) {
        case TAG_Tip: {
          v_y_2446 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2441 = heff_dup(heff_field(v_r_243, 0));
          v_y_2446 = v_h_2441;
          break;
        }
        default: heff_nomatch(v_r_243);
        }
        V v_t_2448;
        if (heff_intLe_c(heff_dup(v_x_2440), heff_dup(v_y_2446))) {
          heff_drop(v_x_2440);
          v_t_2448 = v_y_2446;
        } else {
          heff_drop(v_y_2446);
          v_t_2448 = v_x_2440;
        }
        V v_r_2449 = heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2448), v_k_240, v_v_241, v_lr_2421, v_r_243});
        V v_x_2455;
        switch (heff_tag_of(v_ll_2420)) {
        case TAG_Tip: {
          v_x_2455 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2450 = heff_dup(heff_field(v_ll_2420, 0));
          v_x_2455 = v_h_2450;
          break;
        }
        default: heff_nomatch(v_ll_2420);
        }
        V v_y_2461;
        switch (heff_tag_of(v_r_2449)) {
        case TAG_Tip: {
          v_y_2461 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_2456 = heff_dup(heff_field(v_r_2449, 0));
          v_y_2461 = v_h_2456;
          break;
        }
        default: heff_nomatch(v_r_2449);
        }
        V v_t_2463;
        if (heff_intLe_c(heff_dup(v_x_2455), heff_dup(v_y_2461))) {
          heff_drop(v_x_2455);
          v_t_2463 = v_y_2461;
        } else {
          heff_drop(v_y_2461);
          v_t_2463 = v_x_2455;
        }
        return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2463), v_lk_2418, v_lv_2419, v_ll_2420, v_r_2449});
      } else {
        switch (heff_tag_of(v_lr_2421)) {
        case TAG_Tip: {
          heff_drop(v_k_240);
          heff_drop(v_v_241);
          heff_drop(v_r_243);
          heff_drop(v_lk_2418);
          heff_drop(v_lv_2419);
          heff_drop(v_ll_2420);
          heff_drop_cell(v_ru_24l_242_24Bin, 5);
          return heff_abandon();
        }
        case TAG_Bin: {
          V v_mk_2465 = heff_field(v_lr_2421, 1);
          V v_mv_2466 = heff_field(v_lr_2421, 2);
          V v_ml_2467 = heff_field(v_lr_2421, 3);
          V v_mr_2468 = heff_field(v_lr_2421, 4);
          V v_ru_24lr_2421_24Bin = heff_take_reuse_n(v_lr_2421, 30ULL, 5);
          V v_x_2474;
          switch (heff_tag_of(v_ll_2420)) {
          case TAG_Tip: {
            v_x_2474 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2469 = heff_dup(heff_field(v_ll_2420, 0));
            v_x_2474 = v_h_2469;
            break;
          }
          default: heff_nomatch(v_ll_2420);
          }
          V v_y_2480;
          switch (heff_tag_of(v_ml_2467)) {
          case TAG_Tip: {
            v_y_2480 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2475 = heff_dup(heff_field(v_ml_2467, 0));
            v_y_2480 = v_h_2475;
            break;
          }
          default: heff_nomatch(v_ml_2467);
          }
          V v_t_2482;
          if (heff_intLe_c(heff_dup(v_x_2474), heff_dup(v_y_2480))) {
            heff_drop(v_x_2474);
            v_t_2482 = v_y_2480;
          } else {
            heff_drop(v_y_2480);
            v_t_2482 = v_x_2474;
          }
          V v_l_2483 = heff_tag_at_n(v_ru_24l_242_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2482), v_lk_2418, v_lv_2419, v_ll_2420, v_ml_2467});
          V v_x_2489;
          switch (heff_tag_of(v_mr_2468)) {
          case TAG_Tip: {
            v_x_2489 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2484 = heff_dup(heff_field(v_mr_2468, 0));
            v_x_2489 = v_h_2484;
            break;
          }
          default: heff_nomatch(v_mr_2468);
          }
          V v_y_2495;
          switch (heff_tag_of(v_r_243)) {
          case TAG_Tip: {
            v_y_2495 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2490 = heff_dup(heff_field(v_r_243, 0));
            v_y_2495 = v_h_2490;
            break;
          }
          default: heff_nomatch(v_r_243);
          }
          V v_t_2497;
          if (heff_intLe_c(heff_dup(v_x_2489), heff_dup(v_y_2495))) {
            heff_drop(v_x_2489);
            v_t_2497 = v_y_2495;
          } else {
            heff_drop(v_y_2495);
            v_t_2497 = v_x_2489;
          }
          V v_r_2498 = heff_tag_at_n(v_ru_24lr_2421_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_2497), v_k_240, v_v_241, v_mr_2468, v_r_243});
          V v_x_24104;
          switch (heff_tag_of(v_l_2483)) {
          case TAG_Tip: {
            v_x_24104 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_2499 = heff_dup(heff_field(v_l_2483, 0));
            v_x_24104 = v_h_2499;
            break;
          }
          default: heff_nomatch(v_l_2483);
          }
          V v_y_24110;
          switch (heff_tag_of(v_r_2498)) {
          case TAG_Tip: {
            v_y_24110 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24105 = heff_dup(heff_field(v_r_2498, 0));
            v_y_24110 = v_h_24105;
            break;
          }
          default: heff_nomatch(v_r_2498);
          }
          V v_t_24112;
          if (heff_intLe_c(heff_dup(v_x_24104), heff_dup(v_y_24110))) {
            heff_drop(v_x_24104);
            v_t_24112 = v_y_24110;
          } else {
            heff_drop(v_y_24110);
            v_t_24112 = v_x_24104;
          }
          return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24112), v_mk_2465, v_mv_2466, v_l_2483, v_r_2498});
        }
        default: return heff_nomatch(v_lr_2421);
        }
      }
    }
    default: return heff_nomatch(v_l_242);
    }
  } else {
    V v_t_24118;
    switch (heff_tag_of(v_l_242)) {
    case TAG_Tip: {
      v_t_24118 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_24113 = heff_dup(heff_field(v_l_242, 0));
      v_t_24118 = v_h_24113;
      break;
    }
    default: heff_nomatch(v_l_242);
    }
    V v_t_24124;
    switch (heff_tag_of(v_r_243)) {
    case TAG_Tip: {
      v_t_24124 = MK_INT(0LL);
      break;
    }
    case TAG_Bin: {
      V v_h_24119 = heff_dup(heff_field(v_r_243, 0));
      v_t_24124 = v_h_24119;
      break;
    }
    default: heff_nomatch(v_r_243);
    }
    if (heff_intLt_c(heff_intAdd(v_t_24118, MK_INT(1LL)), v_t_24124)) {
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        heff_drop(v_k_240);
        heff_drop(v_v_241);
        heff_drop(v_l_242);
        return heff_abandon();
      }
      case TAG_Bin: {
        V v_rk_24127 = heff_field(v_r_243, 1);
        V v_rv_24128 = heff_field(v_r_243, 2);
        V v_rl_24129 = heff_field(v_r_243, 3);
        V v_rr_24130 = heff_field(v_r_243, 4);
        V v_ru_24r_243_24Bin = heff_take_reuse_n(v_r_243, 30ULL, 5);
        V v_t_24136;
        switch (heff_tag_of(v_rl_24129)) {
        case TAG_Tip: {
          v_t_24136 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24131 = heff_dup(heff_field(v_rl_24129, 0));
          v_t_24136 = v_h_24131;
          break;
        }
        default: heff_nomatch(v_rl_24129);
        }
        V v_t_24142;
        switch (heff_tag_of(v_rr_24130)) {
        case TAG_Tip: {
          v_t_24142 = MK_INT(0LL);
          break;
        }
        case TAG_Bin: {
          V v_h_24137 = heff_dup(heff_field(v_rr_24130, 0));
          v_t_24142 = v_h_24137;
          break;
        }
        default: heff_nomatch(v_rr_24130);
        }
        if (heff_intLe_c(v_t_24136, v_t_24142)) {
          V v_x_24149;
          switch (heff_tag_of(v_l_242)) {
          case TAG_Tip: {
            v_x_24149 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24144 = heff_dup(heff_field(v_l_242, 0));
            v_x_24149 = v_h_24144;
            break;
          }
          default: heff_nomatch(v_l_242);
          }
          V v_y_24155;
          switch (heff_tag_of(v_rl_24129)) {
          case TAG_Tip: {
            v_y_24155 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24150 = heff_dup(heff_field(v_rl_24129, 0));
            v_y_24155 = v_h_24150;
            break;
          }
          default: heff_nomatch(v_rl_24129);
          }
          V v_t_24157;
          if (heff_intLe_c(heff_dup(v_x_24149), heff_dup(v_y_24155))) {
            heff_drop(v_x_24149);
            v_t_24157 = v_y_24155;
          } else {
            heff_drop(v_y_24155);
            v_t_24157 = v_x_24149;
          }
          V v_l_24158 = heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24157), v_k_240, v_v_241, v_l_242, v_rl_24129});
          V v_x_24164;
          switch (heff_tag_of(v_l_24158)) {
          case TAG_Tip: {
            v_x_24164 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24159 = heff_dup(heff_field(v_l_24158, 0));
            v_x_24164 = v_h_24159;
            break;
          }
          default: heff_nomatch(v_l_24158);
          }
          V v_y_24170;
          switch (heff_tag_of(v_rr_24130)) {
          case TAG_Tip: {
            v_y_24170 = MK_INT(0LL);
            break;
          }
          case TAG_Bin: {
            V v_h_24165 = heff_dup(heff_field(v_rr_24130, 0));
            v_y_24170 = v_h_24165;
            break;
          }
          default: heff_nomatch(v_rr_24130);
          }
          V v_t_24172;
          if (heff_intLe_c(heff_dup(v_x_24164), heff_dup(v_y_24170))) {
            heff_drop(v_x_24164);
            v_t_24172 = v_y_24170;
          } else {
            heff_drop(v_y_24170);
            v_t_24172 = v_x_24164;
          }
          return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24172), v_rk_24127, v_rv_24128, v_l_24158, v_rr_24130});
        } else {
          switch (heff_tag_of(v_rl_24129)) {
          case TAG_Tip: {
            heff_drop(v_k_240);
            heff_drop(v_v_241);
            heff_drop(v_l_242);
            heff_drop(v_rk_24127);
            heff_drop(v_rv_24128);
            heff_drop(v_rr_24130);
            heff_drop_cell(v_ru_24r_243_24Bin, 5);
            return heff_abandon();
          }
          case TAG_Bin: {
            V v_mk_24174 = heff_field(v_rl_24129, 1);
            V v_mv_24175 = heff_field(v_rl_24129, 2);
            V v_ml_24176 = heff_field(v_rl_24129, 3);
            V v_mr_24177 = heff_field(v_rl_24129, 4);
            V v_ru_24rl_24129_24Bin = heff_take_reuse_n(v_rl_24129, 30ULL, 5);
            V v_x_24183;
            switch (heff_tag_of(v_l_242)) {
            case TAG_Tip: {
              v_x_24183 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24178 = heff_dup(heff_field(v_l_242, 0));
              v_x_24183 = v_h_24178;
              break;
            }
            default: heff_nomatch(v_l_242);
            }
            V v_y_24189;
            switch (heff_tag_of(v_ml_24176)) {
            case TAG_Tip: {
              v_y_24189 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24184 = heff_dup(heff_field(v_ml_24176, 0));
              v_y_24189 = v_h_24184;
              break;
            }
            default: heff_nomatch(v_ml_24176);
            }
            V v_t_24191;
            if (heff_intLe_c(heff_dup(v_x_24183), heff_dup(v_y_24189))) {
              heff_drop(v_x_24183);
              v_t_24191 = v_y_24189;
            } else {
              heff_drop(v_y_24189);
              v_t_24191 = v_x_24183;
            }
            V v_l_24192 = heff_tag_at_n(v_ru_24r_243_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24191), v_k_240, v_v_241, v_l_242, v_ml_24176});
            V v_x_24198;
            switch (heff_tag_of(v_mr_24177)) {
            case TAG_Tip: {
              v_x_24198 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24193 = heff_dup(heff_field(v_mr_24177, 0));
              v_x_24198 = v_h_24193;
              break;
            }
            default: heff_nomatch(v_mr_24177);
            }
            V v_y_24204;
            switch (heff_tag_of(v_rr_24130)) {
            case TAG_Tip: {
              v_y_24204 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24199 = heff_dup(heff_field(v_rr_24130, 0));
              v_y_24204 = v_h_24199;
              break;
            }
            default: heff_nomatch(v_rr_24130);
            }
            V v_t_24206;
            if (heff_intLe_c(heff_dup(v_x_24198), heff_dup(v_y_24204))) {
              heff_drop(v_x_24198);
              v_t_24206 = v_y_24204;
            } else {
              heff_drop(v_y_24204);
              v_t_24206 = v_x_24198;
            }
            V v_r_24207 = heff_tag_at_n(v_ru_24rl_24129_24Bin, TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24206), v_rk_24127, v_rv_24128, v_mr_24177, v_rr_24130});
            V v_x_24213;
            switch (heff_tag_of(v_l_24192)) {
            case TAG_Tip: {
              v_x_24213 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24208 = heff_dup(heff_field(v_l_24192, 0));
              v_x_24213 = v_h_24208;
              break;
            }
            default: heff_nomatch(v_l_24192);
            }
            V v_y_24219;
            switch (heff_tag_of(v_r_24207)) {
            case TAG_Tip: {
              v_y_24219 = MK_INT(0LL);
              break;
            }
            case TAG_Bin: {
              V v_h_24214 = heff_dup(heff_field(v_r_24207, 0));
              v_y_24219 = v_h_24214;
              break;
            }
            default: heff_nomatch(v_r_24207);
            }
            V v_t_24221;
            if (heff_intLe_c(heff_dup(v_x_24213), heff_dup(v_y_24219))) {
              heff_drop(v_x_24213);
              v_t_24221 = v_y_24219;
            } else {
              heff_drop(v_y_24219);
              v_t_24221 = v_x_24213;
            }
            return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24221), v_mk_24174, v_mv_24175, v_l_24192, v_r_24207});
          }
          default: return heff_nomatch(v_rl_24129);
          }
        }
      }
      default: return heff_nomatch(v_r_243);
      }
    } else {
      V v_x_24227;
      switch (heff_tag_of(v_l_242)) {
      case TAG_Tip: {
        v_x_24227 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24222 = heff_dup(heff_field(v_l_242, 0));
        v_x_24227 = v_h_24222;
        break;
      }
      default: heff_nomatch(v_l_242);
      }
      V v_y_24233;
      switch (heff_tag_of(v_r_243)) {
      case TAG_Tip: {
        v_y_24233 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_24228 = heff_dup(heff_field(v_r_243, 0));
        v_y_24233 = v_h_24228;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_24235;
      if (heff_intLe_c(heff_dup(v_x_24227), heff_dup(v_y_24233))) {
        heff_drop(v_x_24227);
        v_t_24235 = v_y_24233;
      } else {
        heff_drop(v_y_24233);
        v_t_24235 = v_x_24227;
      }
      return heff_tag_n(TAG_Bin, 5, (V[]){heff_intAdd(MK_INT(1LL), v_t_24235), v_k_240, v_v_241, v_l_242, v_r_243});
    }
  }
}
V g_map_2ebalance_entry(V self, V *a) {
  (void)self;
  return g_map_2ebalance(a[0], a[1], a[2], a[3]);
}
Clo g_map_2efindMin_clo = {{0x80000000u, K_CLO, 0}, g_map_2efindMin_entry, 1, 0};

V g_map_2efindMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_242 = heff_field(v_x1_240, 1);
    V v_v_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_242), heff_dup(v_v_243)})});
    }
    case TAG_Bin: {
      V t_0 = v_x14_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2efindMin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2efindMin(a0); heff_drop(a0); return r;
}
Clo g_map_2edeleteMin_clo = {{0x80000000u, K_CLO, 0}, g_map_2edeleteMin_entry, 1, 0};

V g_map_2edeleteMin(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_x13_243 = heff_field(v_x1_240, 2);
    V v_x14_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    switch (heff_tag_of(v_x14_244)) {
    case TAG_Tip: {
      return heff_dup(v_r_245);
    }
    case TAG_Bin: {
      V v_t_2411 = (g_map_2edeleteMin(v_x14_244));
      return (g_map_2ebalance(heff_dup(v_x12_242), heff_dup(v_x13_243), v_t_2411, heff_dup(v_r_245)));
    }
    default: return heff_nomatch(v_x14_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2edeleteMin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2edeleteMin(a0); heff_drop(a0); return r;
}
Clo g_map_2etoListOnto_clo = {{0x80000000u, K_CLO, 0}, g_map_2etoListOnto_entry, 2, 0};

V g_map_2etoListOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return v_acc_241;
  }
  case TAG_Bin: {
    V v_k_243 = heff_field(v_x1_240, 1);
    V v_v_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_t_247 = (g_map_2etoListOnto(v_r_246, v_acc_241));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_243), heff_dup(v_v_244)}), v_t_247});
    V t_0 = v_l_245;
    V t_1 = v_t_248;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2etoListOnto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2etoListOnto(a0, a[1]); heff_drop(a0); return r;
}
Clo g_map_2esize_clo = {{0x80000000u, K_CLO, 0}, g_map_2esize_entry, 1, 0};

V g_map_2esize(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return MK_INT(0LL);
  }
  case TAG_Bin: {
    V v_l_244 = heff_field(v_x1_240, 3);
    V v_r_245 = heff_field(v_x1_240, 4);
    V v_t_246 = (g_map_2esize(v_l_244));
    V v_t_247 = (g_map_2esize(v_r_245));
    return heff_intAdd(heff_intAdd(v_t_246, MK_INT(1LL)), v_t_247);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_map_2esize_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_map_2esize(a0); heff_drop(a0); return r;
}
Clo g_map_2emapValues_clo = {{0x80000000u, K_CLO, 0}, g_map_2emapValues_entry, 2, 0};

V g_map_2emapValues(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_h_242 = heff_field(v_x2_241, 0);
    V v_k_243 = heff_field(v_x2_241, 1);
    V v_v_244 = heff_field(v_x2_241, 2);
    V v_l_245 = heff_field(v_x2_241, 3);
    V v_r_246 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_244}));
    V v_t_248 = (g_map_2emapValues(heff_dup(v_f_240), v_l_245));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_242, v_k_243, v_t_247, v_t_248, heff_hole()});
    V v_u_2410 = (g_map_2emapValues_24dps(v_f_240, v_r_246, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_map_2emapValues_entry(V self, V *a) {
  (void)self;
  return g_map_2emapValues(a[0], a[1]);
}
Clo g_map_2emapValues_24dps_clo = {{0x80000000u, K_CLO, 0}, g_map_2emapValues_24dps_entry, 3, 0};

V g_map_2emapValues_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Tip: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, MK_INT(4LL), NTAG(TAG_Tip));
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x2_241, 0);
    V v_k_244 = heff_field(v_x2_241, 1);
    V v_v_245 = heff_field(v_x2_241, 2);
    V v_l_246 = heff_field(v_x2_241, 3);
    V v_r_247 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24Bin = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_v_245}));
    V v_t_249 = (g_map_2emapValues(heff_dup(v_f_240), v_l_246));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_k_244, v_t_248, v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_242, MK_INT(4LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_f_240;
    V t_1 = v_r_247;
    V t_2 = v_cell_2410;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_map_2emapValues_24dps_entry(V self, V *a) {
  (void)self;
  return g_map_2emapValues_24dps(a[0], a[1], a[2]);
}
Clo g_map_2einsert_24s1341440536x470972936_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s1341440536x470972936_entry, 3, 0};

V g_map_2einsert_24s1341440536x470972936(V v_key_240, V v_value_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_240, v_value_241, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x4_242, 0);
    V v_k_27_244 = heff_field(v_x4_242, 1);
    V v_v_27_245 = heff_field(v_x4_242, 2);
    V v_l_246 = heff_field(v_x4_242, 3);
    V v_r_247 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_240, v_k_27_244, 0);
    V v_t_2411;
    if (heff_intLt_c(heff_dup(v_a_248), MK_INT(0LL))) {
      heff_drop(v_a_248);
      v_t_2411 = NTAG(TAG_LT);
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        v_t_2411 = NTAG(TAG_EQ);
      } else {
        v_t_2411 = NTAG(TAG_GT);
      }
    }
    switch (heff_tag_of(v_t_2411)) {
    case TAG_LT: {
      heff_drop(v_h_243);
      V v_l2_2412 = (g_map_2einsert_24s1341440536x470972936(v_key_240, v_value_241, v_l_246));
      V v_a_2418;
      switch (heff_tag_of(v_l2_2412)) {
      case TAG_Tip: {
        v_a_2418 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2413 = heff_dup(heff_field(v_l2_2412, 0));
        v_a_2418 = v_h_2413;
        break;
      }
      default: heff_nomatch(v_l2_2412);
      }
      V v_b_2424;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2424 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2419 = heff_dup(heff_field(v_r_247, 0));
        v_b_2424 = v_h_2419;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2429;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2424), MK_INT(1LL)), heff_dup(v_a_2418))) {
        heff_drop(v_a_2418);
        heff_drop(v_b_2424);
        v_h_2429 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2418), MK_INT(1LL)), heff_dup(v_b_2424))) {
          heff_drop(v_a_2418);
          heff_drop(v_b_2424);
          v_h_2429 = MK_INT(0LL);
        } else {
          V v_t_2428;
          if (heff_intLe_c(heff_dup(v_a_2418), heff_dup(v_b_2424))) {
            heff_drop(v_a_2418);
            v_t_2428 = v_b_2424;
          } else {
            heff_drop(v_b_2424);
            v_t_2428 = v_a_2418;
          }
          v_h_2429 = heff_intAdd(MK_INT(1LL), v_t_2428);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2429), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2429);
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l2_2412, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2429, v_k_27_244, v_v_27_245, v_l2_2412, v_r_247});
      }
    }
    case TAG_EQ: {
      heff_drop(v_k_27_244);
      heff_drop(v_v_27_245);
      return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_240, v_value_241, v_l_246, v_r_247});
    }
    case TAG_GT: {
      heff_drop(v_h_243);
      V v_r2_2431 = (g_map_2einsert_24s1341440536x470972936(v_key_240, v_value_241, v_r_247));
      V v_a_2437;
      switch (heff_tag_of(v_l_246)) {
      case TAG_Tip: {
        v_a_2437 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2432 = heff_dup(heff_field(v_l_246, 0));
        v_a_2437 = v_h_2432;
        break;
      }
      default: heff_nomatch(v_l_246);
      }
      V v_b_2443;
      switch (heff_tag_of(v_r2_2431)) {
      case TAG_Tip: {
        v_b_2443 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2438 = heff_dup(heff_field(v_r2_2431, 0));
        v_b_2443 = v_h_2438;
        break;
      }
      default: heff_nomatch(v_r2_2431);
      }
      V v_h_2448;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2443), MK_INT(1LL)), heff_dup(v_a_2437))) {
        heff_drop(v_a_2437);
        heff_drop(v_b_2443);
        v_h_2448 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2437), MK_INT(1LL)), heff_dup(v_b_2443))) {
          heff_drop(v_a_2437);
          heff_drop(v_b_2443);
          v_h_2448 = MK_INT(0LL);
        } else {
          V v_t_2447;
          if (heff_intLe_c(heff_dup(v_a_2437), heff_dup(v_b_2443))) {
            heff_drop(v_a_2437);
            v_t_2447 = v_b_2443;
          } else {
            heff_drop(v_b_2443);
            v_t_2447 = v_a_2437;
          }
          v_h_2448 = heff_intAdd(MK_INT(1LL), v_t_2447);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2448), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2448);
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2431));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2448, v_k_27_244, v_v_27_245, v_l_246, v_r2_2431});
      }
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s1341440536x470972936(a[0], a[1], a[2]);
}
Clo g_map_2elookup_24s1546226666x2146984184_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s1546226666x2146984184_entry, 2, 0};

V g_map_2elookup_24s1546226666x2146984184(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_a_247 = heff_strCompare_lent(v_k_240, v_k_27_243, 0);
    if (heff_intLt_c(heff_dup(v_a_247), MK_INT(0LL))) {
      heff_drop(v_a_247);
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s1546226666x2146984184(a[0], a1); heff_drop(a1); return r;
}
Clo g_map_2elookup_24s659669741x1036301430_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s659669741x1036301430_entry, 2, 0};

V g_map_2elookup_24s659669741x1036301430(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_a_247 = heff_strCompare_lent(v_k_240, v_k_27_243, 0);
    if (heff_intLt_c(heff_dup(v_a_247), MK_INT(0LL))) {
      heff_drop(v_a_247);
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s659669741x1036301430(a[0], a1); heff_drop(a1); return r;
}
Clo g_map_2elookup_24s567992785x1569911877_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s567992785x1569911877_entry, 2, 0};

V g_map_2elookup_24s567992785x1569911877(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    if (heff_intLt_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s567992785x1569911877(a[0], a1); heff_drop(a1); return r;
}
Clo g_map_2edelete_24s805420727x38051515_clo = {{0x80000000u, K_CLO, 0}, g_map_2edelete_24s805420727x38051515_entry, 2, 0};

V g_map_2edelete_24s805420727x38051515(V v_key_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_key_240);
    return NTAG(TAG_Tip);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    V v_ru_24x3_241_24Bin = heff_take_reuse_n(v_x3_241, 30ULL, 5);
    V v_a_247 = heff_strCompare_lent(v_key_240, v_k_27_243, 0);
    V v_t_2410;
    if (heff_intLt_c(heff_dup(v_a_247), MK_INT(0LL))) {
      heff_drop(v_a_247);
      v_t_2410 = NTAG(TAG_LT);
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        v_t_2410 = NTAG(TAG_EQ);
      } else {
        v_t_2410 = NTAG(TAG_GT);
      }
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_LT: {
      V v_l2_2411 = (g_map_2edelete_24s805420727x38051515(v_key_240, v_l_245));
      V v_a_2417;
      switch (heff_tag_of(v_l2_2411)) {
      case TAG_Tip: {
        v_a_2417 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2412 = heff_dup(heff_field(v_l2_2411, 0));
        v_a_2417 = v_h_2412;
        break;
      }
      default: heff_nomatch(v_l2_2411);
      }
      V v_b_2423;
      switch (heff_tag_of(v_r_246)) {
      case TAG_Tip: {
        v_b_2423 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2418 = heff_dup(heff_field(v_r_246, 0));
        v_b_2423 = v_h_2418;
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_h_2428;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2423), MK_INT(1LL)), heff_dup(v_a_2417))) {
        heff_drop(v_a_2417);
        heff_drop(v_b_2423);
        v_h_2428 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2417), MK_INT(1LL)), heff_dup(v_b_2423))) {
          heff_drop(v_a_2417);
          heff_drop(v_b_2423);
          v_h_2428 = MK_INT(0LL);
        } else {
          V v_t_2427;
          if (heff_intLe_c(heff_dup(v_a_2417), heff_dup(v_b_2423))) {
            heff_drop(v_a_2417);
            v_t_2427 = v_b_2423;
          } else {
            heff_drop(v_b_2423);
            v_t_2427 = v_a_2417;
          }
          v_h_2428 = heff_intAdd(MK_INT(1LL), v_t_2427);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2428), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x3_241_24Bin, 5);
        heff_drop(v_h_2428);
        return (g_map_2ebalance(v_k_27_243, v_v_27_244, v_l2_2411, v_r_246));
      } else {
        return heff_tag_at_n(v_ru_24x3_241_24Bin, TAG_Bin, 5, (V[]){v_h_2428, v_k_27_243, v_v_27_244, v_l2_2411, v_r_246});
      }
    }
    case TAG_EQ: {
      heff_drop(v_key_240);
      heff_drop(v_k_27_243);
      heff_drop(v_v_27_244);
      heff_drop_cell(v_ru_24x3_241_24Bin, 5);
      V v_it_2430 = (g_map_2efindMin(v_r_246));
      switch (heff_tag_of(v_it_2430)) {
      case TAG_Nothing: {
        heff_drop(v_r_246);
        return v_l_245;
      }
      case TAG_Just: {
        V v_it1_2431 = heff_field(v_it_2430, 0);
        heff_take_n(v_it_2430, 1ULL, 1);
        switch (heff_tag_of(v_it1_2431)) {
        case TAG_MkPair: {
          V v_k_2432 = heff_field(v_it1_2431, 0);
          V v_v_2433 = heff_field(v_it1_2431, 1);
          heff_take_n(v_it1_2431, 3ULL, 2);
          V v_t_2434 = ({ V a_0 = v_r_246; V r_ = (g_map_2edeleteMin(a_0)); heff_drop(v_r_246); r_; });
          return (g_map_2ebalance(v_k_2432, v_v_2433, v_l_245, v_t_2434));
        }
        default: return heff_nomatch(v_it1_2431);
        }
      }
      default: return heff_nomatch(v_it_2430);
      }
    }
    case TAG_GT: {
      V v_r2_2435 = (g_map_2edelete_24s805420727x38051515(v_key_240, v_r_246));
      V v_a_2441;
      switch (heff_tag_of(v_l_245)) {
      case TAG_Tip: {
        v_a_2441 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2436 = heff_dup(heff_field(v_l_245, 0));
        v_a_2441 = v_h_2436;
        break;
      }
      default: heff_nomatch(v_l_245);
      }
      V v_b_2447;
      switch (heff_tag_of(v_r2_2435)) {
      case TAG_Tip: {
        v_b_2447 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2442 = heff_dup(heff_field(v_r2_2435, 0));
        v_b_2447 = v_h_2442;
        break;
      }
      default: heff_nomatch(v_r2_2435);
      }
      V v_h_2452;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2447), MK_INT(1LL)), heff_dup(v_a_2441))) {
        heff_drop(v_a_2441);
        heff_drop(v_b_2447);
        v_h_2452 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2441), MK_INT(1LL)), heff_dup(v_b_2447))) {
          heff_drop(v_a_2441);
          heff_drop(v_b_2447);
          v_h_2452 = MK_INT(0LL);
        } else {
          V v_t_2451;
          if (heff_intLe_c(heff_dup(v_a_2441), heff_dup(v_b_2447))) {
            heff_drop(v_a_2441);
            v_t_2451 = v_b_2447;
          } else {
            heff_drop(v_b_2447);
            v_t_2451 = v_a_2441;
          }
          v_h_2452 = heff_intAdd(MK_INT(1LL), v_t_2451);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2452), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x3_241_24Bin, 5);
        heff_drop(v_h_2452);
        return (g_map_2ebalance(v_k_27_243, v_v_27_244, v_l_245, v_r2_2435));
      } else {
        return heff_tag_at_n(v_ru_24x3_241_24Bin, TAG_Bin, 5, (V[]){v_h_2452, v_k_27_243, v_v_27_244, v_l_245, v_r2_2435});
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a) {
  (void)self;
  return g_map_2edelete_24s805420727x38051515(a[0], a[1]);
}
Clo g_map_2einsert_24s1689409319x1710080871_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s1689409319x1710080871_entry, 3, 0};

V g_map_2einsert_24s1689409319x1710080871(V v_key_240, V v_value_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_240, v_value_241, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x4_242, 0);
    V v_k_27_244 = heff_field(v_x4_242, 1);
    V v_v_27_245 = heff_field(v_x4_242, 2);
    V v_l_246 = heff_field(v_x4_242, 3);
    V v_r_247 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    V v_t_2410;
    if (heff_intLt_c(heff_dup(v_key_240), heff_dup(v_k_27_244))) {
      v_t_2410 = NTAG(TAG_LT);
    } else {
      if (heff_intEq_c(heff_dup(v_key_240), heff_dup(v_k_27_244))) {
        v_t_2410 = NTAG(TAG_EQ);
      } else {
        v_t_2410 = NTAG(TAG_GT);
      }
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_LT: {
      heff_drop(v_h_243);
      V v_l2_2411 = (g_map_2einsert_24s1689409319x1710080871(v_key_240, v_value_241, v_l_246));
      V v_a_2417;
      switch (heff_tag_of(v_l2_2411)) {
      case TAG_Tip: {
        v_a_2417 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2412 = heff_dup(heff_field(v_l2_2411, 0));
        v_a_2417 = v_h_2412;
        break;
      }
      default: heff_nomatch(v_l2_2411);
      }
      V v_b_2423;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2423 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2418 = heff_dup(heff_field(v_r_247, 0));
        v_b_2423 = v_h_2418;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2428;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2423), MK_INT(1LL)), heff_dup(v_a_2417))) {
        heff_drop(v_a_2417);
        heff_drop(v_b_2423);
        v_h_2428 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2417), MK_INT(1LL)), heff_dup(v_b_2423))) {
          heff_drop(v_a_2417);
          heff_drop(v_b_2423);
          v_h_2428 = MK_INT(0LL);
        } else {
          V v_t_2427;
          if (heff_intLe_c(heff_dup(v_a_2417), heff_dup(v_b_2423))) {
            heff_drop(v_a_2417);
            v_t_2427 = v_b_2423;
          } else {
            heff_drop(v_b_2423);
            v_t_2427 = v_a_2417;
          }
          v_h_2428 = heff_intAdd(MK_INT(1LL), v_t_2427);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2428), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2428);
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l2_2411, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2428, v_k_27_244, v_v_27_245, v_l2_2411, v_r_247});
      }
    }
    case TAG_EQ: {
      heff_drop(v_k_27_244);
      heff_drop(v_v_27_245);
      return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_240, v_value_241, v_l_246, v_r_247});
    }
    case TAG_GT: {
      heff_drop(v_h_243);
      V v_r2_2430 = (g_map_2einsert_24s1689409319x1710080871(v_key_240, v_value_241, v_r_247));
      V v_a_2436;
      switch (heff_tag_of(v_l_246)) {
      case TAG_Tip: {
        v_a_2436 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2431 = heff_dup(heff_field(v_l_246, 0));
        v_a_2436 = v_h_2431;
        break;
      }
      default: heff_nomatch(v_l_246);
      }
      V v_b_2442;
      switch (heff_tag_of(v_r2_2430)) {
      case TAG_Tip: {
        v_b_2442 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2437 = heff_dup(heff_field(v_r2_2430, 0));
        v_b_2442 = v_h_2437;
        break;
      }
      default: heff_nomatch(v_r2_2430);
      }
      V v_h_2447;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2442), MK_INT(1LL)), heff_dup(v_a_2436))) {
        heff_drop(v_a_2436);
        heff_drop(v_b_2442);
        v_h_2447 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2436), MK_INT(1LL)), heff_dup(v_b_2442))) {
          heff_drop(v_a_2436);
          heff_drop(v_b_2442);
          v_h_2447 = MK_INT(0LL);
        } else {
          V v_t_2446;
          if (heff_intLe_c(heff_dup(v_a_2436), heff_dup(v_b_2442))) {
            heff_drop(v_a_2436);
            v_t_2446 = v_b_2442;
          } else {
            heff_drop(v_b_2442);
            v_t_2446 = v_a_2436;
          }
          v_h_2447 = heff_intAdd(MK_INT(1LL), v_t_2446);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2447), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2447);
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2430));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2447, v_k_27_244, v_v_27_245, v_l_246, v_r2_2430});
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s1689409319x1710080871(a[0], a[1], a[2]);
}
Clo g_map_2einsert_24s1687968944x933869791_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s1687968944x933869791_entry, 3, 0};

V g_map_2einsert_24s1687968944x933869791(V v_key_240, V v_value_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_240, v_value_241, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_x4_242, 0);
    V v_k_27_244 = heff_field(v_x4_242, 1);
    V v_v_27_245 = heff_field(v_x4_242, 2);
    V v_l_246 = heff_field(v_x4_242, 3);
    V v_r_247 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    V v_a_248 = heff_strCompare_lent(v_key_240, v_k_27_244, 0);
    V v_t_2411;
    if (heff_intLt_c(heff_dup(v_a_248), MK_INT(0LL))) {
      heff_drop(v_a_248);
      v_t_2411 = NTAG(TAG_LT);
    } else {
      if (heff_intEq_c(v_a_248, MK_INT(0LL))) {
        v_t_2411 = NTAG(TAG_EQ);
      } else {
        v_t_2411 = NTAG(TAG_GT);
      }
    }
    switch (heff_tag_of(v_t_2411)) {
    case TAG_LT: {
      heff_drop(v_h_243);
      V v_l2_2412 = (g_map_2einsert_24s1687968944x933869791(v_key_240, v_value_241, v_l_246));
      V v_a_2418;
      switch (heff_tag_of(v_l2_2412)) {
      case TAG_Tip: {
        v_a_2418 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2413 = heff_dup(heff_field(v_l2_2412, 0));
        v_a_2418 = v_h_2413;
        break;
      }
      default: heff_nomatch(v_l2_2412);
      }
      V v_b_2424;
      switch (heff_tag_of(v_r_247)) {
      case TAG_Tip: {
        v_b_2424 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2419 = heff_dup(heff_field(v_r_247, 0));
        v_b_2424 = v_h_2419;
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_h_2429;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2424), MK_INT(1LL)), heff_dup(v_a_2418))) {
        heff_drop(v_a_2418);
        heff_drop(v_b_2424);
        v_h_2429 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2418), MK_INT(1LL)), heff_dup(v_b_2424))) {
          heff_drop(v_a_2418);
          heff_drop(v_b_2424);
          v_h_2429 = MK_INT(0LL);
        } else {
          V v_t_2428;
          if (heff_intLe_c(heff_dup(v_a_2418), heff_dup(v_b_2424))) {
            heff_drop(v_a_2418);
            v_t_2428 = v_b_2424;
          } else {
            heff_drop(v_b_2424);
            v_t_2428 = v_a_2418;
          }
          v_h_2429 = heff_intAdd(MK_INT(1LL), v_t_2428);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2429), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2429);
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l2_2412, v_r_247));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2429, v_k_27_244, v_v_27_245, v_l2_2412, v_r_247});
      }
    }
    case TAG_EQ: {
      heff_drop(v_k_27_244);
      heff_drop(v_v_27_245);
      return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_243, v_key_240, v_value_241, v_l_246, v_r_247});
    }
    case TAG_GT: {
      heff_drop(v_h_243);
      V v_r2_2431 = (g_map_2einsert_24s1687968944x933869791(v_key_240, v_value_241, v_r_247));
      V v_a_2437;
      switch (heff_tag_of(v_l_246)) {
      case TAG_Tip: {
        v_a_2437 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2432 = heff_dup(heff_field(v_l_246, 0));
        v_a_2437 = v_h_2432;
        break;
      }
      default: heff_nomatch(v_l_246);
      }
      V v_b_2443;
      switch (heff_tag_of(v_r2_2431)) {
      case TAG_Tip: {
        v_b_2443 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2438 = heff_dup(heff_field(v_r2_2431, 0));
        v_b_2443 = v_h_2438;
        break;
      }
      default: heff_nomatch(v_r2_2431);
      }
      V v_h_2448;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2443), MK_INT(1LL)), heff_dup(v_a_2437))) {
        heff_drop(v_a_2437);
        heff_drop(v_b_2443);
        v_h_2448 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2437), MK_INT(1LL)), heff_dup(v_b_2443))) {
          heff_drop(v_a_2437);
          heff_drop(v_b_2443);
          v_h_2448 = MK_INT(0LL);
        } else {
          V v_t_2447;
          if (heff_intLe_c(heff_dup(v_a_2437), heff_dup(v_b_2443))) {
            heff_drop(v_a_2437);
            v_t_2447 = v_b_2443;
          } else {
            heff_drop(v_b_2443);
            v_t_2447 = v_a_2437;
          }
          v_h_2448 = heff_intAdd(MK_INT(1LL), v_t_2447);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2448), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2448);
        return (g_map_2ebalance(v_k_27_244, v_v_27_245, v_l_246, v_r2_2431));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2448, v_k_27_244, v_v_27_245, v_l_246, v_r2_2431});
      }
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s1687968944x933869791_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s1687968944x933869791(a[0], a[1], a[2]);
}
Clo g_map_2elookup_24s1338854231x236594845_clo = {{0x80000000u, K_CLO, 0}, g_map_2elookup_24s1338854231x236594845_entry, 2, 0};

V g_map_2elookup_24s1338854231x236594845(V v_k_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Tip: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Bin: {
    V v_k_27_243 = heff_field(v_x3_241, 1);
    V v_v_27_244 = heff_field(v_x3_241, 2);
    V v_l_245 = heff_field(v_x3_241, 3);
    V v_r_246 = heff_field(v_x3_241, 4);
    if (heff_intLt_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
      V t_0 = v_k_240;
      V t_1 = v_l_245;
      v_k_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      if (heff_intEq_c(heff_dup(v_k_240), heff_dup(v_k_27_243))) {
        heff_drop(v_k_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_27_244)});
      } else {
        V t_0 = v_k_240;
        V t_1 = v_r_246;
        v_k_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_map_2elookup_24s1338854231x236594845(a[0], a1); heff_drop(a1); return r;
}
V g_map_2einsert_24s1705770630x2073956475_lam0(V self, V *args);
V g_map_2einsert_24s1705770630x2073956475_lam1(V self, V *args);
Clo g_map_2einsert_24s1705770630x2073956475_clo = {{0x80000000u, K_CLO, 0}, g_map_2einsert_24s1705770630x2073956475_entry, 3, 0};

V g_map_2einsert_24s1705770630x2073956475(V v_lit_240, V v_key_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Tip: {
    return heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_key_241, heff_clo_n(g_map_2einsert_24s1705770630x2073956475_lam0, 1, 1, (V[]){v_lit_240}), NTAG(TAG_Tip), NTAG(TAG_Tip)});
  }
  case TAG_Bin: {
    V v_h_244 = heff_field(v_x4_242, 0);
    V v_k_27_245 = heff_field(v_x4_242, 1);
    V v_v_27_246 = heff_field(v_x4_242, 2);
    V v_l_247 = heff_field(v_x4_242, 3);
    V v_r_248 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24Bin = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    V v_a_249 = heff_strCompare_lent(v_key_241, v_k_27_245, 0);
    V v_t_2412;
    if (heff_intLt_c(heff_dup(v_a_249), MK_INT(0LL))) {
      heff_drop(v_a_249);
      v_t_2412 = NTAG(TAG_LT);
    } else {
      if (heff_intEq_c(v_a_249, MK_INT(0LL))) {
        v_t_2412 = NTAG(TAG_EQ);
      } else {
        v_t_2412 = NTAG(TAG_GT);
      }
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_LT: {
      heff_drop(v_h_244);
      V v_l2_2413 = (g_map_2einsert_24s1705770630x2073956475(v_lit_240, v_key_241, v_l_247));
      V v_a_2419;
      switch (heff_tag_of(v_l2_2413)) {
      case TAG_Tip: {
        v_a_2419 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2414 = heff_dup(heff_field(v_l2_2413, 0));
        v_a_2419 = v_h_2414;
        break;
      }
      default: heff_nomatch(v_l2_2413);
      }
      V v_b_2425;
      switch (heff_tag_of(v_r_248)) {
      case TAG_Tip: {
        v_b_2425 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2420 = heff_dup(heff_field(v_r_248, 0));
        v_b_2425 = v_h_2420;
        break;
      }
      default: heff_nomatch(v_r_248);
      }
      V v_h_2430;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2425), MK_INT(1LL)), heff_dup(v_a_2419))) {
        heff_drop(v_a_2419);
        heff_drop(v_b_2425);
        v_h_2430 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2419), MK_INT(1LL)), heff_dup(v_b_2425))) {
          heff_drop(v_a_2419);
          heff_drop(v_b_2425);
          v_h_2430 = MK_INT(0LL);
        } else {
          V v_t_2429;
          if (heff_intLe_c(heff_dup(v_a_2419), heff_dup(v_b_2425))) {
            heff_drop(v_a_2419);
            v_t_2429 = v_b_2425;
          } else {
            heff_drop(v_b_2425);
            v_t_2429 = v_a_2419;
          }
          v_h_2430 = heff_intAdd(MK_INT(1LL), v_t_2429);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2430), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2430);
        return (g_map_2ebalance(v_k_27_245, v_v_27_246, v_l2_2413, v_r_248));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2430, v_k_27_245, v_v_27_246, v_l2_2413, v_r_248});
      }
    }
    case TAG_EQ: {
      heff_drop(v_k_27_245);
      heff_drop(v_v_27_246);
      return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_244, v_key_241, heff_clo_n(g_map_2einsert_24s1705770630x2073956475_lam1, 1, 1, (V[]){v_lit_240}), v_l_247, v_r_248});
    }
    case TAG_GT: {
      heff_drop(v_h_244);
      V v_r2_2433 = (g_map_2einsert_24s1705770630x2073956475(v_lit_240, v_key_241, v_r_248));
      V v_a_2439;
      switch (heff_tag_of(v_l_247)) {
      case TAG_Tip: {
        v_a_2439 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2434 = heff_dup(heff_field(v_l_247, 0));
        v_a_2439 = v_h_2434;
        break;
      }
      default: heff_nomatch(v_l_247);
      }
      V v_b_2445;
      switch (heff_tag_of(v_r2_2433)) {
      case TAG_Tip: {
        v_b_2445 = MK_INT(0LL);
        break;
      }
      case TAG_Bin: {
        V v_h_2440 = heff_dup(heff_field(v_r2_2433, 0));
        v_b_2445 = v_h_2440;
        break;
      }
      default: heff_nomatch(v_r2_2433);
      }
      V v_h_2450;
      if (heff_intLt_c(heff_intAdd(heff_dup(v_b_2445), MK_INT(1LL)), heff_dup(v_a_2439))) {
        heff_drop(v_a_2439);
        heff_drop(v_b_2445);
        v_h_2450 = MK_INT(0LL);
      } else {
        if (heff_intLt_c(heff_intAdd(heff_dup(v_a_2439), MK_INT(1LL)), heff_dup(v_b_2445))) {
          heff_drop(v_a_2439);
          heff_drop(v_b_2445);
          v_h_2450 = MK_INT(0LL);
        } else {
          V v_t_2449;
          if (heff_intLe_c(heff_dup(v_a_2439), heff_dup(v_b_2445))) {
            heff_drop(v_a_2439);
            v_t_2449 = v_b_2445;
          } else {
            heff_drop(v_b_2445);
            v_t_2449 = v_a_2439;
          }
          v_h_2450 = heff_intAdd(MK_INT(1LL), v_t_2449);
        }
      }
      if (heff_intEq_c(heff_dup(v_h_2450), MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x4_242_24Bin, 5);
        heff_drop(v_h_2450);
        return (g_map_2ebalance(v_k_27_245, v_v_27_246, v_l_247, v_r2_2433));
      } else {
        return heff_tag_at_n(v_ru_24x4_242_24Bin, TAG_Bin, 5, (V[]){v_h_2450, v_k_27_245, v_v_27_246, v_l_247, v_r2_2433});
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_map_2einsert_24s1705770630x2073956475_entry(V self, V *a) {
  (void)self;
  return g_map_2einsert_24s1705770630x2073956475(a[0], a[1], a[2]);
}
V g_map_2einsert_24s1705770630x2073956475_lam0(V self, V *args) {
  V v_a_243 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_243);
  return v_lit_240;
}
V g_map_2einsert_24s1705770630x2073956475_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2432);
  return v_lit_240;
}