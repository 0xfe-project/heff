// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_MkArmJs 44527
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_decls 296817955
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_groups 709681407
#define LBL_gs 10067
#define LBL_info 9732469
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_jss 315076
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_module 878357911
#define LBL_names 305943394
#define LBL_output 941629484
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_prims 308293287
#define LBL_refs 9991943
#define LBL_self 10021907
#define LBL_simplified 1686448252
#define LBL_source 1050636102
#define LBL_used 10094724
#define LBL_ver 326173
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_info[] = {LBL_info};
static uint32_t shape_output__groups__copies__jss[] = {LBL_output, LBL_groups, LBL_copies, LBL_jss};
static uint32_t shape_params__body[] = {LBL_params, LBL_body};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452(V, V, V);
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_clo;
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V, V, V, V);
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo;
V g_heff_2ecompile_2eemit_2earmBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2ebindName_24cpr(V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_clo;
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo;
V g_heff_2ecompile_2eemit_2eboolCode(V);
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eboolCode_clo;
V g_heff_2ecompile_2eemit_2ecallName(V, V);
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallName_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo;
V g_heff_2ecompile_2eemit_2econdCode(V);
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdCode_clo;
HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_clo;
V g_heff_2ecompile_2eemit_2edeclsOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_clo;
HeffT2 g_heff_2ecompile_2eemit_2eemitKept_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2eescAt(V, V);
V g_heff_2ecompile_2eemit_2eescAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eescAt_clo;
HeffT2 g_heff_2ecompile_2eemit_2efindProv_24cpr(V, V);
V g_heff_2ecompile_2eemit_2eglobalJsH(V, V, V);
V g_heff_2ecompile_2eemit_2eglobalJsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eglobalJsH_clo;
V g_heff_2ecompile_2eemit_2eglobalOfPart(V);
V g_heff_2ecompile_2eemit_2eglobalOfPart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eglobalOfPart_clo;
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2eisIdent(V);
V g_heff_2ecompile_2eemit_2eisIdent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eisIdent_clo;
V g_heff_2ecompile_2eemit_2eisWordCode(V);
V g_heff_2ecompile_2eemit_2eisWordCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eisWordCode_clo;
V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246(V, V);
V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_clo;
V g_heff_2ecompile_2eemit_2ekeptOutput(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ekeptOutput_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptOutput_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
HeffT2 g_heff_2ecompile_2eemit_2eletBound_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations(V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo;
V g_heff_2ecompile_2eemit_2enamesIn(V, V);
V g_heff_2ecompile_2eemit_2enamesIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamesIn_clo;
V g_heff_2ecompile_2eemit_2enubGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
V g_heff_2ecompile_2eemit_2eprimBin(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimBin_clo;
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimOp_24cpr(V);
V g_heff_2ecompile_2eemit_2eprimRel(V);
V g_heff_2ecompile_2eemit_2eprimRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimRel_clo;
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_24dps_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereturnCond(V, V);
V g_heff_2ecompile_2eemit_2ereturnCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnCond_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
HeffT2 g_heff_2ecompile_2eemit_2esetStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo(V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esharedGo_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrWhen(V, V);
V g_heff_2ecompile_2eemit_2etrWhen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etrWhen_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2euncurryGo(V, V);
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2euncurryGo_clo;
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
HeffT2 g_heff_2ecompile_2eemit_2ewordOf_24cpr(V);
V g_heff_2ecompile_2eemit_2eworldStr_get(void);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
HeffT3 g_heff_2ecompile_2elower_2elowerFused_24cpr(V, V, V);
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1455783996x1449538216(V);
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_clo;
V g_list_2emap_24s1585362143x1323498048(V);
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s679881967x35917574(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s679881967x35917574_entry(V self, V *a);
extern Clo g_list_2emap_24s679881967x35917574_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2emaybe_24s1822328499x1781525065(V, V);
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a);
extern Clo g_prelude_2emaybe_24s1822328499x1781525065_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enubGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemit_2enubGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_seen_240));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_seen_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enubGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str0, 2, "\\\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str1, 2, "\\\\");
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str2, 2, "\\n");
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str3, 2, "\\r");
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str4, 2, "\\t");
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str5, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str6, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemit_2eescAt_str7, 2, "\\x");
Clo g_heff_2ecompile_2eemit_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eescAt_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eescAt(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
    heff_drop(v_i_241);
    return ((V)&g_heff_2ecompile_2eemit_2eescAt_str0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
      heff_drop(v_i_241);
      return ((V)&g_heff_2ecompile_2eemit_2eescAt_str1);
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)10ULL))) {
        heff_drop(v_i_241);
        return ((V)&g_heff_2ecompile_2eemit_2eescAt_str2);
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)13ULL))) {
          heff_drop(v_i_241);
          return ((V)&g_heff_2ecompile_2eemit_2eescAt_str3);
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)9ULL))) {
            heff_drop(v_i_241);
            return ((V)&g_heff_2ecompile_2eemit_2eescAt_str4);
          } else {
            if ((((int64_t)128ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
              int64_t v_d_248 = heff_word_div(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)), ((int64_t)16ULL));
              V v_t_249 = heff_strSlice(((V)&g_heff_2ecompile_2eemit_2eescAt_str5), heff_box_word(v_d_248), heff_box_word((v_d_248 + ((int64_t)1ULL))));
              int64_t v_d_2410 = heff_word_mod(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 2)), ((int64_t)16ULL));
              V v_t_2411 = heff_strSlice(((V)&g_heff_2ecompile_2eemit_2eescAt_str6), heff_box_word(v_d_2410), heff_box_word((v_d_2410 + ((int64_t)1ULL))));
              return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eescAt_str7), heff_strAppend(v_t_249, v_t_2411));
            } else {
              return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))));
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2eescAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eescAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str0, 4, "plus");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str1, 5, "minus");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str2, 5, "times");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str3, 5, "slash");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str4, 7, "percent");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str5, 2, "eq");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str6, 2, "lt");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str7, 2, "gt");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str8, 3, "amp");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str9, 3, "bar");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str10, 4, "bang");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str11, 5, "caret");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str12, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str13, 2, "at");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str14, 4, "hash");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str15, 6, "dollar");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str16, 5, "tilde");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str17, 5, "colon");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str18, 3, "dot");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str19, 9, "backslash");

HeffT2 g_heff_2ecompile_2eemit_2ewordOf_24cpr(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((v_c_240 == ((int64_t)43ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str0)}});
  } else {
    if ((v_c_240 == ((int64_t)45ULL))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str1)}});
    } else {
      if ((v_c_240 == ((int64_t)42ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str2)}});
      } else {
        if ((v_c_240 == ((int64_t)47ULL))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str3)}});
        } else {
          if ((v_c_240 == ((int64_t)37ULL))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str4)}});
          } else {
            if ((v_c_240 == ((int64_t)61ULL))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str5)}});
            } else {
              if ((v_c_240 == ((int64_t)60ULL))) {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str6)}});
              } else {
                if ((v_c_240 == ((int64_t)62ULL))) {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str7)}});
                } else {
                  if ((v_c_240 == ((int64_t)38ULL))) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str8)}});
                  } else {
                    if ((v_c_240 == ((int64_t)124ULL))) {
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str9)}});
                    } else {
                      if ((v_c_240 == ((int64_t)33ULL))) {
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str10)}});
                      } else {
                        if ((v_c_240 == ((int64_t)94ULL))) {
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str11)}});
                        } else {
                          if ((v_c_240 == ((int64_t)63ULL))) {
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str12)}});
                          } else {
                            if ((v_c_240 == ((int64_t)64ULL))) {
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str13)}});
                            } else {
                              if ((v_c_240 == ((int64_t)35ULL))) {
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str14)}});
                              } else {
                                if ((v_c_240 == ((int64_t)36ULL))) {
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str15)}});
                                } else {
                                  if ((v_c_240 == ((int64_t)126ULL))) {
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str16)}});
                                  } else {
                                    if ((v_c_240 == ((int64_t)58ULL))) {
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str17)}});
                                    } else {
                                      if ((v_c_240 == ((int64_t)46ULL))) {
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str18)}});
                                      } else {
                                        if ((v_c_240 == ((int64_t)92ULL))) {
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str19)}});
                                        } else {
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2eemit_2eisWordCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eisWordCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eisWordCode(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)57ULL)) || (v_c_240 == ((int64_t)95ULL))) : heff_intEq_c(heff_box_word(v_c_240), MK_INT(95LL)))) : (heff_intLe_c(MK_INT(48LL), heff_box_word(v_c_240)) ? (heff_intLe_c(heff_box_word(v_c_240), MK_INT(57LL)) || heff_intEq_c(heff_box_word(v_c_240), MK_INT(95LL))) : heff_intEq_c(heff_box_word(v_c_240), MK_INT(95LL))))) : ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)57ULL)) || (v_c_240 == ((int64_t)95ULL))) : heff_intEq_c(heff_box_word(v_c_240), MK_INT(95LL)))) : ((((int64_t)48ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)57ULL)) || (v_c_240 == ((int64_t)95ULL))) : (v_c_240 == ((int64_t)95ULL))))));
  return v_ret_24bool;
}
V g_heff_2ecompile_2eemit_2eisWordCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eisWordCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esafeChars_str0, 1, "_");
Clo g_heff_2ecompile_2eemit_2esafeChars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esafeChars_entry, 3, 0};

V g_heff_2ecompile_2eemit_2esafeChars(V v_x_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_t_244 = (g_heff_2ecompile_2eemit_2eisWordCode(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)));
    V v_t_245;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_245 = heff_strSlice_lent(v_x_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    } else {
      heff_drop(v_t_244);
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2esafeChars_str0);
    }
    V t_0 = v_x_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_acc_242, v_t_245);
    v_x_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2esafeChars(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V v_env_240, V v_x_241, V v_base_242, V v_i_243) {
top: ;
  V v_t_245;
  if (heff_intEq_c_lent(v_i_243, MK_INT(0LL), 2)) {
    v_t_245 = heff_dup(v_base_242);
  } else {
    v_t_245 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
  }
  HeffT2 v_t_246 = ({ V a_0 = heff_rfield(v_env_240, 2); V a_1 = v_t_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_248;
      heff_drop(v_x_2410);
      V t_0 = v_env_240;
      V t_1 = v_x_241;
      V t_2 = v_base_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      v_env_240 = t_0;
      v_x_241 = t_1;
      v_base_242 = t_2;
      v_i_243 = t_3;
      goto top;
    } else {
      heff_drop(v_field_248);
      V v_f_2412;
      if (heff_intEq_c_lent(v_i_243, MK_INT(0LL), 2)) {
        v_f_2412 = heff_dup(v_base_242);
      } else {
        v_f_2412 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
      }
      V v_v_2414;
      if (heff_intEq_c_lent(v_i_243, MK_INT(0LL), 2)) {
        heff_drop(v_i_243);
        v_v_2414 = v_base_242;
      } else {
        v_v_2414 = heff_strAppend(v_base_242, heff_intShow(v_i_243));
      }
      V v_t_2415 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_env_240, 1), v_x_241, heff_dup(v_v_2414)));
      V v_t_2416 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_env_240, 2), v_v_2414, NTAG(TAG_MkUnit)));
      V v_f_2417 = ({ V rv_1 = v_t_2415; V rv_2 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_env_240, 25ULL, 5, shape_gs__names__used__self__inl, 963u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      return ((HeffT2){{v_f_2412, v_f_2417}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str2, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str3, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str4, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str5, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str6, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str7, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str8, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str9, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str10, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str11, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str12, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str13, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str14, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str15, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str16, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str17, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str18, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str19, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str20, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str21, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str22, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str23, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str24, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str25, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str26, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str27, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str28, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str29, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str30, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str31, 2, "<=");

HeffT2 g_heff_2ecompile_2eemit_2eprimOp_24cpr(V v_x1_240) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str0), 2)) {
    V v_f_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str1)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str2), 2)) {
      V v_f_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str3)}));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
    } else {
      if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str4), 2)) {
        V v_f_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str5)}));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
      } else {
        if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str6), 2)) {
          V v_f_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str7)}));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
        } else {
          if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str8), 2)) {
            V v_f_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str9)}));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
          } else {
            if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str10), 2)) {
              V v_f_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str11)}));
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
            } else {
              if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str12), 2)) {
                V v_f_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str13)}));
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
              } else {
                if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str14), 2)) {
                  V v_f_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str15)}));
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
                } else {
                  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str16), 2)) {
                    V v_f_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str17)}));
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
                  } else {
                    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str18), 2)) {
                      V v_f_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str19)}));
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
                    } else {
                      if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str20), 2)) {
                        V v_f_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str21)}));
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
                      } else {
                        if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str22), 2)) {
                          V v_f_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str23)}));
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
                        } else {
                          if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str24), 2)) {
                            V v_f_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str25)}));
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
                          } else {
                            if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str26), 2)) {
                              V v_f_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str27)}));
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
                            } else {
                              if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str28), 2)) {
                                V v_f_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str29)}));
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
                              } else {
                                if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str30), 2)) {
                                  V v_f_2432 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str31)}));
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
                                } else {
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str0, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str1, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str2, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str3, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str4, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str5, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str6, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str8, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str9, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str10, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str11, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str12, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str13, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str14, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str15, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str16, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str17, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str18, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str19, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str20, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_str21, 2, "<=");
Clo g_heff_2ecompile_2eemit_2eprimRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimRel_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eprimRel(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str0), 2)) {
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str1)});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str2), 2)) {
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str3)});
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str4), 2)) {
        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str5)});
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str6), 2)) {
          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str7)});
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str8), 2)) {
            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str9)});
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str10), 2)) {
              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str11)});
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str12), 2)) {
                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str13)});
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str14), 2)) {
                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str15)});
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str16), 2)) {
                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str17)});
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str18), 2)) {
                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str19)});
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemit_2eprimRel_str20), 2)) {
                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str21)});
                      } else {
                        V v_t_2412 = (g_heff_2eelab_2efixed_2efixedPrimOf(v_p_240));
                        return (g_prelude_2emaybe_24s1822328499x1781525065(NTAG(TAG_Nothing), v_t_2412));
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimRel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprimRel(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str4, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str5, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str6, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str7, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str8, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str11, 1, "}");
Clo g_heff_2ecompile_2eemit_2earmBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmBound_entry, 5, 0};

V g_heff_2ecompile_2eemit_2earmBound(V v_sc_240, V v_ind_241, V v_tag_242, V v_lines_243, V v_rb_244) {
top: ;
  V v_x2_245 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2earmBound_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = (g_heff_2ecompile_2eemit_2equoteGo(v_tag_242, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2earmBound_str3)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2earmBound_str4), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2earmBound_str5)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2earmBound_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2earmBound_str7)));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, v_t_2411), NTAG(TAG_Nil)});
  V v_t_2413 = (g_heff_2ecompile_2eemit_2edeclsOf(heff_get_n(v_sc_240, 0, 3), heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL)), heff_take_field(v_rb_244, 0), MK_INT(0LL)));
  V v_t_2414 = heff_tr(heff_call(v_lines_243, 2, (V[]){heff_get_n(v_rb_244, 1, 2), heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL))}));
  V v_x2_2415 = (g_list_2ereplicate(heff_intAdd(v_ind_241, MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2earmBound_str8)));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str10); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2earmBound_str11)), NTAG(TAG_Nil)});
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2419));
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2420));
  V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2421));
  return heff_tag_n(TAG_MkArmJs, 3, (V[]){v_tag_242, NTAG(TAG_False), v_t_2422});
}
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2earmBound(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str3, 5, ".$) {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str4, 8, "switch (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str8, 1, "}");
Clo g_heff_2ecompile_2eemit_2eswitchLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eswitchLines_entry, 5, 0};

V g_heff_2ecompile_2eemit_2eswitchLines(V v_sc_240, V v_ind_241, V v_arms_242, V v_inside_243, V v_after_244) {
top: ;
  V v_x2_245 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(heff_take_field(v_sc_240, 0), ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str3));
  V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eswitchLines_str4), v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = (g_heff_2ecompile_2eemit_2esharedGo(heff_dup(v_ind_241), NTAG(TAG_Nil), v_arms_242));
  V v_x2_2413 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str5)));
  V v_t_2416;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_xs_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str7); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str8)), v_after_244});
  V v_t_2418 = (g_prelude_2e_2b_2b(v_inside_243, v_t_2417));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2418));
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2419));
  return (g_prelude_2e_2b_2b(heff_get_n(v_sc_240, 2, 3), v_t_2420));
}
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eswitchLines(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str3, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str4, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str8, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str11, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str12, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str13, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str16, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str17, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str18, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str21, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str24, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str25, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str26, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str29, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str30, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str31, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str34, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str37, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str38, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str39, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str41, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str42, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str43, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str44, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str45, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str47, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str49, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str50, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str51, 8, "} else {");
Clo g_heff_2ecompile_2eemit_2eifLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eifLines_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eifLines(V v_ind_240, V v_c_241, V v_t_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_c_241)) {
  case TAG_JTrue: {
    heff_drop(v_f_243);
    return heff_tail(v_t_242, 1, (V[]){v_ind_240});
  }
  case TAG_JFalse: {
    heff_drop(v_t_242);
    return heff_tail(v_f_243, 1, (V[]){v_ind_240});
  }
  case TAG_JRel: {
    V v_t_245 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_246 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_245));
    V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str0)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2412 = heff_strAppend(heff_get_n(v_t_2411, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eifLines_str3));
    V v_t_2413 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eifLines_str4), v_t_2412));
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2415 = heff_tr(heff_call(v_t_242, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2416 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str5)));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str7); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2420 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2421 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eifLines_str8)));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str10); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2eifLines_str11)), NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2425));
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2eifLines_str12)), v_t_2426});
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2427));
    V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2428));
    return (g_prelude_2e_2b_2b(v_t_246, v_t_2429));
  }
  case TAG_JNot: {
    V v_t_2431 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2432 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2431));
    V v_x2_2433 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str13)));
    V v_t_2436;
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_Nil: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      V v_xs_2435 = heff_field(v_x2_2433, 1);
      heff_take_n(v_x2_2433, 3ULL, 2);
      v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str15); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2433);
    }
    V v_t_2437 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eifLines_str16));
    V v_t_2439 = heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eifLines_str17), v_t_2438));
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
    V v_t_2441 = heff_tr(heff_call(v_t_242, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2442 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str18)));
    V v_t_2445;
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_Nil: {
      v_t_2445 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      V v_xs_2444 = heff_field(v_x2_2442, 1);
      heff_take_n(v_x2_2442, 3ULL, 2);
      v_t_2445 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str20); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2442);
    }
    V v_t_2446 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2447 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eifLines_str21)));
    V v_t_2450;
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_Nil: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_xs_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      v_t_2450 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str23); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2447);
    }
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemit_2eifLines_str24)), NTAG(TAG_Nil)});
    V v_t_2452 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2451));
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemit_2eifLines_str25)), v_t_2452});
    V v_t_2454 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2453));
    V v_t_2455 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2454));
    return (g_prelude_2e_2b_2b(v_t_2432, v_t_2455));
  }
  case TAG_JIf: {
    V v_t_2459 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2460 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2459));
    V v_x2_2461 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str26)));
    V v_t_2464;
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_Nil: {
      v_t_2464 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str27);
      break;
    }
    case TAG_Cons: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_xs_2463 = heff_field(v_x2_2461, 1);
      heff_take_n(v_x2_2461, 3ULL, 2);
      v_t_2464 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str28); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2461);
    }
    V v_t_2465 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2466 = heff_strAppend(heff_get_n(v_t_2465, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eifLines_str29));
    V v_t_2467 = heff_strAppend(v_t_2464, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eifLines_str30), v_t_2466));
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_t_2469 = heff_tr(heff_call(v_t_242, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2470 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str31)));
    V v_t_2473;
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_Nil: {
      v_t_2473 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str32);
      break;
    }
    case TAG_Cons: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_xs_2472 = heff_field(v_x2_2470, 1);
      heff_take_n(v_x2_2470, 3ULL, 2);
      v_t_2473 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str33); V a_1 = v_x_2471; V a_2 = v_xs_2472; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2472); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2470);
    }
    V v_t_2474 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2475 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eifLines_str34)));
    V v_t_2478;
    switch (heff_tag_of(v_x2_2475)) {
    case TAG_Nil: {
      v_t_2478 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2476 = heff_field(v_x2_2475, 0);
      V v_xs_2477 = heff_field(v_x2_2475, 1);
      heff_take_n(v_x2_2475, 3ULL, 2);
      v_t_2478 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str36); V a_1 = v_x_2476; V a_2 = v_xs_2477; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2477); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2475);
    }
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2478, ((V)&g_heff_2ecompile_2eemit_2eifLines_str37)), NTAG(TAG_Nil)});
    V v_t_2480 = (g_prelude_2e_2b_2b(v_t_2474, v_t_2479));
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2473, ((V)&g_heff_2ecompile_2eemit_2eifLines_str38)), v_t_2480});
    V v_t_2482 = (g_prelude_2e_2b_2b(v_t_2469, v_t_2481));
    V v_t_2483 = (g_prelude_2e_2b_2b(v_t_2468, v_t_2482));
    return (g_prelude_2e_2b_2b(v_t_2460, v_t_2483));
  }
  case TAG_JSeq: {
    V v_t_2487 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2488 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2487));
    V v_x2_2489 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str39)));
    V v_t_2492;
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_Nil: {
      v_t_2492 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str40);
      break;
    }
    case TAG_Cons: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_xs_2491 = heff_field(v_x2_2489, 1);
      heff_take_n(v_x2_2489, 3ULL, 2);
      v_t_2492 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str41); V a_1 = v_x_2490; V a_2 = v_xs_2491; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2491); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2489);
    }
    V v_t_2493 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eifLines_str42));
    V v_t_2495 = heff_strAppend(v_t_2492, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eifLines_str43), v_t_2494));
    V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
    V v_t_2497 = heff_tr(heff_call(v_t_242, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2498 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str44)));
    V v_t_24101;
    switch (heff_tag_of(v_x2_2498)) {
    case TAG_Nil: {
      v_t_24101 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str45);
      break;
    }
    case TAG_Cons: {
      V v_x_2499 = heff_field(v_x2_2498, 0);
      V v_xs_24100 = heff_field(v_x2_2498, 1);
      heff_take_n(v_x2_2498, 3ULL, 2);
      v_t_24101 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str46); V a_1 = v_x_2499; V a_2 = v_xs_24100; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24100); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2498);
    }
    V v_t_24102 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_24103 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eifLines_str47)));
    V v_t_24106;
    switch (heff_tag_of(v_x2_24103)) {
    case TAG_Nil: {
      v_t_24106 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str48);
      break;
    }
    case TAG_Cons: {
      V v_x_24104 = heff_field(v_x2_24103, 0);
      V v_xs_24105 = heff_field(v_x2_24103, 1);
      heff_take_n(v_x2_24103, 3ULL, 2);
      v_t_24106 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str49); V a_1 = v_x_24104; V a_2 = v_xs_24105; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24105); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24103);
    }
    V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24106, ((V)&g_heff_2ecompile_2eemit_2eifLines_str50)), NTAG(TAG_Nil)});
    V v_t_24108 = (g_prelude_2e_2b_2b(v_t_24102, v_t_24107));
    V v_t_24109 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24101, ((V)&g_heff_2ecompile_2eemit_2eifLines_str51)), v_t_24108});
    V v_t_24110 = (g_prelude_2e_2b_2b(v_t_2497, v_t_24109));
    V v_t_24111 = (g_prelude_2e_2b_2b(v_t_2496, v_t_24110));
    return (g_prelude_2e_2b_2b(v_t_2488, v_t_24111));
  }
  default: return heff_nomatch(v_c_241);
  }
}
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eifLines(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str4, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str5, 6, "const ");

HeffT2 g_heff_2ecompile_2eemit_2eletBound_24cpr(V v_ind_240, V v_st_241, V v_nb_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), heff_take_field(v_st_241, 1)));
  V v_x2_244 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_get_n(heff_get_n(v_st_241, 0, 2), 0, 2);
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str3), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str4)));
  V v_t_2410 = heff_strAppend(heff_take_field(v_nb_242, 0), v_t_249);
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str5), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_f_2413 = (g_prelude_2e_2b_2b(v_t_243, v_t_2412));
  V v_f_2414 = heff_get_n(v_nb_242, 1, 2);
  return ((HeffT2){{v_f_2413, v_f_2414}});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str5, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str6, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str7, 1, ";");

HeffT2 g_heff_2ecompile_2eemit_2esetStmt_24cpr(V v_ind_240, V v_st_241, V v_x_242, V v_env_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), heff_dup(heff_rfield(v_st_241, 1))));
  V v_x2_245 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - ((int64_t)1ULL));
  V v_t_2410 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x_242, heff_box_word(v_t_249)));
  V v_t_2411 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_s_2412 = ({ V a_0 = v_t_2411; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str3); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V v_t_2414;
  if (heff_strEq_c_lent(v_s_2412, ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str4), 2)) {
    heff_drop(v_s_2412);
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str5);
  } else {
    v_t_2414 = v_s_2412;
  }
  V v_d_2415 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2414));
  HeffT2 v_t_2416 = ({ V a_0 = heff_rfield(v_env_243, 1); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_x_242); r_; });
  V v_t_2421;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      heff_drop(v_d_2415);
      V v_x_2420 = v_field_2418;
      v_t_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2418);
      v_t_2421 = v_d_2415;
    }
  }
  V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_st_241, 0)), 0, 2);
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str6), heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str7)));
  V v_t_2424 = heff_strAppend(v_t_248, heff_strAppend(v_t_2421, v_t_2423));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  V v_f_2426 = (g_prelude_2e_2b_2b(v_t_244, v_t_2425));
  V v_f_2427 = ({ V a_0 = v_env_243; V b_1 = heff_get_n(v_st_241, 1, 2); V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, b_1)); heff_drop(b_1); r_; });
  return ((HeffT2){{v_f_2426, v_f_2427}});
}
Clo g_heff_2ecompile_2eemit_2eatomGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eatomGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eatomGo(V v_c_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_c_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_t_243 = (g_heff_2ecompile_2eemit_2eisWordCode(heff_strByteAt_lent(v_c_240, heff_box_word(v_i_241), 2)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_c_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_c_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_243);
      if ((heff_unbox_word(heff_strByteAt_lent(v_c_240, heff_box_word(v_i_241), 2)) == ((int64_t)36ULL))) {
        V t_0 = v_c_240;
        int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
        v_c_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eatomGo(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str3, 10, "return $T;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str7, 10, "return $F;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str8, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str13, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str14, 11, " \? $T : $F;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str15, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str19, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str20, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str21, 11, " \? $T : $F;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str26, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str27, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str28, 11, " \? $T : $F;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str29, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str30, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str32, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str33, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str34, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str35, 11, " \? $T : $F;");
Clo g_heff_2ecompile_2eemit_2ereturnCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ereturnCond_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ereturnCond(V v_ind_240, V v_c_241) {
top: ;
  switch (heff_tag_of(v_c_241)) {
  case TAG_JTrue: {
    V v_x2_242 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str0)));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str2); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str3)), NTAG(TAG_Nil)});
  }
  case TAG_JFalse: {
    V v_x2_246 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str4)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str6); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str7)), NTAG(TAG_Nil)});
  }
  case TAG_JRel: {
    V v_t_2411 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2412 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2411));
    V v_x2_2413 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str8)));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str10); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    HeffT2 v_t_2417 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_241));
    V v_t_2421;
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      if (heff_intLt_c(v_field_2419, MK_INT(1LL))) {
        v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str11), heff_strAppend(v_field_2418, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str12)));
      } else {
        v_t_2421 = v_field_2418;
      }
    }
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str13), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str14)));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, v_t_2422), NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2412, v_t_2423);
  }
  case TAG_JNot: {
    V v_t_2425 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2426 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2425));
    V v_x2_2427 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str15)));
    V v_t_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str17); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    HeffT2 v_t_2431 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_241));
    V v_t_2435;
    {
      V v_field_2432 = v_t_2431.f[0];
      V v_field_2433 = v_t_2431.f[1];
      if (heff_intLt_c(v_field_2433, MK_INT(1LL))) {
        v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str18), heff_strAppend(v_field_2432, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str19)));
      } else {
        v_t_2435 = v_field_2432;
      }
    }
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str20), heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str21)));
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2430, v_t_2436), NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2426, v_t_2437);
  }
  case TAG_JIf: {
    V v_t_2441 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2442 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2441));
    V v_x2_2443 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str22)));
    V v_t_2446;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      v_t_2446 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str23);
      break;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      v_t_2446 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str24); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    HeffT2 v_t_2447 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_241));
    V v_t_2451;
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      if (heff_intLt_c(v_field_2449, MK_INT(1LL))) {
        v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str25), heff_strAppend(v_field_2448, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str26)));
      } else {
        v_t_2451 = v_field_2448;
      }
    }
    V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str27), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str28)));
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2446, v_t_2452), NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2442, v_t_2453);
  }
  case TAG_JSeq: {
    V v_t_2457 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2458 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2457));
    V v_x2_2459 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str29)));
    V v_t_2462;
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_Nil: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str30);
      break;
    }
    case TAG_Cons: {
      V v_x_2460 = heff_field(v_x2_2459, 0);
      V v_xs_2461 = heff_field(v_x2_2459, 1);
      heff_take_n(v_x2_2459, 3ULL, 2);
      v_t_2462 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str31); V a_1 = v_x_2460; V a_2 = v_xs_2461; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2459);
    }
    HeffT2 v_t_2463 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_241));
    V v_t_2467;
    {
      V v_field_2464 = v_t_2463.f[0];
      V v_field_2465 = v_t_2463.f[1];
      if (heff_intLt_c(v_field_2465, MK_INT(1LL))) {
        v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str32), heff_strAppend(v_field_2464, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str33)));
      } else {
        v_t_2467 = v_field_2464;
      }
    }
    V v_t_2468 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str34), heff_strAppend(v_t_2467, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str35)));
    V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2462, v_t_2468), NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2458, v_t_2469);
  }
  default: return heff_nomatch(v_c_241);
  }
}
V g_heff_2ecompile_2eemit_2ereturnCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ereturnCond(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str2, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str6, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str7, 2, "{\012");
Clo g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  V v_x2_243 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str2)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str6)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str7), heff_strAppend(v_t_246, v_t_2411));
}
V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str2, 1, ")");
Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_TSeq: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  case TAG_TReturn: {
    V v_o_245 = heff_field(v_t_242, 0);
    V v_t_2420;
    switch (heff_tag_of(v_o_245)) {
    case TAG_OSimple: {
      v_t_2420 = NTAG(TAG_True);
      break;
    }
    case TAG_OCall: {
      V v_g_247 = heff_field(v_o_245, 0);
      HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_env_240, 0), v_g_247));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        v_t_2420 = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) ? ({ V v_i_2413 = heff_dup(v_field_2411); int c_ = ({ V v_t_2414 = heff_dup(heff_rfield(v_i_2413, 3)); int c_ = !(heff_dup(v_t_2414) == NTAG(TAG_True)); heff_drop(v_t_2414); c_; }); heff_drop(v_i_2413); c_; }) : 1));
        heff_drop(v_field_2411);
      }
      break;
    }
    case TAG_OApply: {
      v_t_2420 = NTAG(TAG_False);
      break;
    }
    case TAG_OPrim: {
      v_t_2420 = NTAG(TAG_True);
      break;
    }
    case TAG_OAbandon: {
      v_t_2420 = NTAG(TAG_True);
      break;
    }
    case TAG_OBool: {
      v_t_2420 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_o_245);
    }
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      V v_t_2421 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_245));
      V v_c_2422 = heff_get_n(v_t_2421, 0, 2);
      if (heff_strEq_c(heff_strSlice_lent(v_c_2422, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str0))) {
        return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str1), heff_strAppend(v_c_2422, ((V)&g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str2)));
      } else {
        return v_c_2422;
      }
    } else {
      heff_drop(v_t_2420);
      HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
    }
  }
  case TAG_TLoop: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  case TAG_TIf: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  case TAG_TCase: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str0, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str2, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str5, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str9, 13, ".$ === \"True\"");
Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry, 3, 0};

V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_PTrue: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return NTAG(TAG_JTrue);
  }
  case TAG_PFalse: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return NTAG(TAG_JFalse);
  }
  case TAG_PRel: {
    V v_p_243 = heff_field(v_x4_242, 0);
    V v_a_244 = heff_field(v_x4_242, 1);
    V v_b_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_c_246 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_a_244; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_244); r_; });
    V v_t_249;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_246, 1)), MK_INT(2LL))) {
      V v_t_248 = heff_strAppend(heff_get_n(v_c_246, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str0));
      v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str1), v_t_248);
    } else {
      v_t_249 = heff_get_n(v_c_246, 0, 2);
    }
    V v_x2_2410 = ({ V a_0 = v_p_243; V r_ = (g_heff_2ecompile_2eemit_2eprimRel(a_0)); heff_drop(v_p_243); r_; });
    V v_t_2412;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str2);
      break;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      heff_take_n(v_x2_2410, 1ULL, 1);
      v_t_2412 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_c_2413 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_b_245; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_b_245); r_; });
    V v_t_2416;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2413, 1)), MK_INT(2LL))) {
      V v_t_2415 = heff_strAppend(heff_get_n(v_c_2413, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str3));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str4), v_t_2415);
    } else {
      v_t_2416 = heff_get_n(v_c_2413, 0, 2);
    }
    V v_t_2417 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str5), v_t_2416));
    V v_t_2418 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str6), v_t_2417));
    return heff_tag_n(TAG_JRel, 1, (V[]){v_t_2418});
  }
  case TAG_PBool: {
    V v_v_2419 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_c_2420 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2419; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2419); r_; });
    V v_t_2423;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2420, 1)), MK_INT(3LL))) {
      V v_t_2422 = heff_strAppend(heff_get_n(v_c_2420, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str7));
      v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str8), v_t_2422);
    } else {
      v_t_2423 = heff_get_n(v_c_2420, 0, 2);
    }
    return heff_tag_at_n(v_ru_24x4_242_24PBool, TAG_JRel, 1, (V[]){heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str9))});
  }
  case TAG_PNot: {
    V v_c_2424 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PNot = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_cell_2425 = heff_tag_at_n(v_ru_24x4_242_24PNot, TAG_JNot, 1, (V[]){heff_hole()});
    V v_u_2426 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(v_env_240, v_ind_241, v_c_2424, heff_dup(v_cell_2425), MK_INT(0LL)));
    heff_drop(v_u_2426);
    return v_cell_2425;
  }
  case TAG_PIf: {
    V v_a_2427 = heff_field(v_x4_242, 0);
    V v_b_2428 = heff_field(v_x4_242, 1);
    V v_c_2429 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2430 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_a_2427));
    V v_t_2431 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_b_2428));
    V v_cell_2432 = heff_tag_at_n(v_ru_24x4_242_24PIf, TAG_JIf, 3, (V[]){v_t_2430, v_t_2431, heff_hole()});
    V v_u_2433 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(v_env_240, v_ind_241, v_c_2429, heff_dup(v_cell_2432), MK_INT(2LL)));
    heff_drop(v_u_2433);
    return v_cell_2432;
  }
  case TAG_PLet: {
    V v_x_2434 = heff_field(v_x4_242, 0);
    V v_o_2435 = heff_field(v_x4_242, 1);
    V v_c_2436 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PLet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2437 = (g_heff_2ecompile_2eemit_2ebindName_24cpr(heff_dup(v_env_240), v_x_2434));
    {
      V v_field_2438 = v_t_2437.f[0];
      V v_field_2439 = v_t_2437.f[1];
      V v_t_2440 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_o_2435; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_2435); r_; });
      V v_cell_2441 = heff_tag_at_n(v_ru_24x4_242_24PLet, TAG_JSeq, 3, (V[]){v_field_2438, heff_get_n(v_t_2440, 0, 2), heff_hole()});
      V v_u_2442 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(v_field_2439, v_ind_241, v_c_2436, heff_dup(v_cell_2441), MK_INT(2LL)));
      heff_drop(v_u_2442);
      return v_cell_2441;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str0, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str2, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str5, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str9, 13, ".$ === \"True\"");
Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_entry, 5, 0};

V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(V v_env_240, V v_ind_241, V v_x4_242, V v_d_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_PTrue: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return heff_setField(v_d_243, v_i_244, NTAG(TAG_JTrue));
  }
  case TAG_PFalse: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return heff_setField(v_d_243, v_i_244, NTAG(TAG_JFalse));
  }
  case TAG_PRel: {
    V v_p_245 = heff_field(v_x4_242, 0);
    V v_a_246 = heff_field(v_x4_242, 1);
    V v_b_247 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_c_248 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_a_246; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_246); r_; });
    V v_t_2411;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_248, 1)), MK_INT(2LL))) {
      V v_t_2410 = heff_strAppend(heff_get_n(v_c_248, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str0));
      v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str1), v_t_2410);
    } else {
      v_t_2411 = heff_get_n(v_c_248, 0, 2);
    }
    V v_x2_2412 = ({ V a_0 = v_p_245; V r_ = (g_heff_2ecompile_2eemit_2eprimRel(a_0)); heff_drop(v_p_245); r_; });
    V v_t_2414;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nothing: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str2);
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      heff_take_n(v_x2_2412, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_c_2415 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_b_247; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_b_247); r_; });
    V v_t_2418;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2415, 1)), MK_INT(2LL))) {
      V v_t_2417 = heff_strAppend(heff_get_n(v_c_2415, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str3));
      v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str4), v_t_2417);
    } else {
      v_t_2418 = heff_get_n(v_c_2415, 0, 2);
    }
    V v_t_2419 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str5), v_t_2418));
    V v_t_2420 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str6), v_t_2419));
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_JRel, 1, (V[]){v_t_2420}));
  }
  case TAG_PBool: {
    V v_v_2421 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_c_2422 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2421; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2421); r_; });
    V v_t_2425;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2422, 1)), MK_INT(3LL))) {
      V v_t_2424 = heff_strAppend(heff_get_n(v_c_2422, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str7));
      v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str8), v_t_2424);
    } else {
      v_t_2425 = heff_get_n(v_c_2422, 0, 2);
    }
    V v_t_2426 = heff_tag_at_n(v_ru_24x4_242_24PBool, TAG_JRel, 1, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str9))});
    return heff_setField(v_d_243, v_i_244, v_t_2426);
  }
  case TAG_PNot: {
    V v_c_2427 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PNot = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_cell_2428 = heff_tag_at_n(v_ru_24x4_242_24PNot, TAG_JNot, 1, (V[]){heff_hole()});
    V v_u_2429 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2428));
    heff_drop(v_u_2429);
    V t_0 = v_env_240;
    V t_1 = v_ind_241;
    V t_2 = v_c_2427;
    V t_3 = v_cell_2428;
    V t_4 = MK_INT(0LL);
    v_env_240 = t_0;
    v_ind_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2430 = heff_field(v_x4_242, 0);
    V v_b_2431 = heff_field(v_x4_242, 1);
    V v_c_2432 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2433 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_a_2430));
    V v_t_2434 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_b_2431));
    V v_cell_2435 = heff_tag_at_n(v_ru_24x4_242_24PIf, TAG_JIf, 3, (V[]){v_t_2433, v_t_2434, heff_hole()});
    V v_u_2436 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2435));
    heff_drop(v_u_2436);
    V t_0 = v_env_240;
    V t_1 = v_ind_241;
    V t_2 = v_c_2432;
    V t_3 = v_cell_2435;
    V t_4 = MK_INT(2LL);
    v_env_240 = t_0;
    v_ind_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_PLet: {
    V v_x_2437 = heff_field(v_x4_242, 0);
    V v_o_2438 = heff_field(v_x4_242, 1);
    V v_c_2439 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PLet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2440 = (g_heff_2ecompile_2eemit_2ebindName_24cpr(heff_dup(v_env_240), v_x_2437));
    {
      V v_field_2441 = v_t_2440.f[0];
      V v_field_2442 = v_t_2440.f[1];
      V v_t_2443 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_o_2438; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_2438); r_; });
      V v_cell_2444 = heff_tag_at_n(v_ru_24x4_242_24PLet, TAG_JSeq, 3, (V[]){v_field_2441, heff_get_n(v_t_2443, 0, 2), heff_hole()});
      V v_u_2445 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2444));
      heff_drop(v_u_2445);
      V t_0 = v_field_2442;
      V t_1 = v_ind_241;
      V t_2 = v_c_2439;
      V t_3 = v_cell_2444;
      V t_4 = MK_INT(2LL);
      v_env_240 = t_0;
      v_ind_241 = t_1;
      v_x4_242 = t_2;
      v_d_243 = t_3;
      v_i_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str1, 7, "$force(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str7, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str9, 7, "$force(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str10, 10, "$abandon()");
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_x4_242, 0);
    HEFF_LAST return g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_243);
  }
  case TAG_OCall: {
    V v_g_244 = heff_field(v_x4_242, 0);
    V v_as_245 = heff_field(v_x4_242, 1);
    V v_t_2435;
    switch (heff_tag_of(v_as_245)) {
    case TAG_Nil: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_246 = heff_field(v_as_245, 0);
      V v_x12_247 = heff_field(v_as_245, 1);
      switch (heff_tag_of(v_x11_246)) {
      case TAG_SVar: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2420 = heff_field(v_x11_246, 0);
        V v_x112_2421 = heff_field(v_x11_246, 1);
        switch (heff_tag_of(v_x112_2421)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_247)) {
          case TAG_Nil: {
            v_t_2435 = heff_strEq_lent(v_t_2420, ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str0), 2);
            break;
          }
          case TAG_Cons: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_247);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2435 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2421);
        }
        break;
      }
      case TAG_SRec: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_246);
      }
      break;
    }
    default: heff_nomatch(v_as_245);
    }
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_ind_241);
      heff_drop(v_t_2435);
      V v_t_2436 = (g_heff_2ecompile_2eemit_2ecallName(v_env_240, heff_dup(v_g_244)));
      V v_code_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str1), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str2)));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2437, MK_INT(3LL)});
    } else {
      heff_drop(v_t_2435);
      HeffT2 v_t_2438 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_env_240, 0), v_g_244));
      V v_t_2443;
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          V v_i_2442 = v_field_2440;
          v_t_2443 = heff_get_n(v_i_2442, 3, 4);
        } else {
          heff_drop(v_field_2440);
          v_t_2443 = NTAG(TAG_False);
        }
      }
      V v_t_2444 = (g_heff_2ecompile_2eemit_2ecallName(heff_dup(v_env_240), heff_dup(v_g_244)));
      V v_x2_2447 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_as_245)));
      V v_t_2450;
      switch (heff_tag_of(v_x2_2447)) {
      case TAG_Nil: {
        v_t_2450 = ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2448 = heff_field(v_x2_2447, 0);
        V v_xs_2449 = heff_field(v_x2_2447, 1);
        heff_take_n(v_x2_2447, 3ULL, 2);
        v_t_2450 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str4); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2447);
      }
      V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str5), heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str6)));
      V v_code_2452 = ({ V a_0 = v_t_2443; V a_1 = heff_strAppend(v_t_2444, v_t_2451); V r_ = (g_heff_2ecompile_2eemit_2etrWhen(a_0, a_1)); heff_drop(v_t_2443); r_; });
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2452, MK_INT(3LL)});
    }
  }
  case TAG_OApply: {
    V v_f_2453 = heff_field(v_x4_242, 0);
    V v_as_2454 = heff_field(v_x4_242, 1);
    V v_t_2484;
    switch (heff_tag_of(v_as_2454)) {
    case TAG_Nil: {
      v_t_2484 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2455 = heff_field(v_as_2454, 0);
      V v_x12_2456 = heff_field(v_as_2454, 1);
      switch (heff_tag_of(v_x11_2455)) {
      case TAG_SVar: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2469 = heff_field(v_x11_2455, 0);
        V v_x112_2470 = heff_field(v_x11_2455, 1);
        switch (heff_tag_of(v_x112_2470)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2456)) {
          case TAG_Nil: {
            v_t_2484 = heff_strEq_lent(v_t_2469, ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str7), 2);
            break;
          }
          case TAG_Cons: {
            v_t_2484 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2456);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2484 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2470);
        }
        break;
      }
      case TAG_SRec: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2455);
      }
      break;
    }
    default: heff_nomatch(v_as_2454);
    }
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      V v_t_2485 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_f_2453));
      V v_t_2486 = heff_strAppend(heff_get_n(v_t_2485, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str8));
      V v_code_2487 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str9), v_t_2486);
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2487, MK_INT(3LL)});
    } else {
      heff_drop(v_t_2484);
      V v_t_2488 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(heff_dup(v_env_240), heff_dup(v_ind_241), v_f_2453));
      return (g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(v_env_240, v_ind_241, v_t_2488, v_as_2454));
    }
  }
  case TAG_OPrim: {
    V v_p_2489 = heff_field(v_x4_242, 0);
    V v_as_2490 = heff_field(v_x4_242, 1);
    V v_t_2492 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam1, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_as_2490)));
    return (g_heff_2ecompile_2eemit_2eprimCall(heff_dup(v_p_2489), v_t_2492));
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str10), MK_INT(3LL)});
  }
  case TAG_OBool: {
    V v_c_2493 = heff_field(v_x4_242, 0);
    V v_t_2494 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(v_env_240, v_ind_241, heff_dup(v_c_2493)));
    return (g_heff_2ecompile_2eemit_2eboolCode(v_t_2494));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam0(V self, V *args) {
  V v_a_2445 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_2445; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_2445); r_; });
  return heff_get_n(v_t_2446, 0, 2);
}
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam1(V self, V *args) {
  V v_v_2491 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2491; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2491); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str3, 18, "return $abandon();");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str7, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str8, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str10, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str11, 10, " continue;");
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452(V v_env_240, V v_ind_241, V v_as_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_env_240, 3));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_as_242);
    V v_x2_244 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str3)), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_s_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x2_249 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str4)));
    V v_t_2412;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_xs_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str6); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_x2_2417 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_lam0, 2, 2, (V[]){v_env_240, v_ind_241}), heff_get_n(v_s_248, 1, 2), v_as_242));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str10); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(v_t_2412, heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str11)));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_a_2414 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_2414; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_2414); r_; });
  V v_t_2416 = heff_strAppend(heff_get_n(v_t_2415, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str7));
  return heff_strAppend(v_p_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_str8), v_t_2416));
}
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str0, 10, "$fromBytes");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str1, 286, "const $fromBytes = typeof Buffer === \"function\" \? (b) => (Buffer.isBuffer(b) \? b : Buffer.from(b)).toString(\"latin1\") : (b) => { const u = new Uint8Array(b); let s = \"\"; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return s; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str2, 8, "$toBytes");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str3, 132, "const $toBytes = typeof Buffer === \"function\" \? (s) => Buffer.from(s, \"latin1\") : (s) => Uint8Array.from(s, (c) => c.charCodeAt(0));");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str4, 7, "$fromJs");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str5, 345, "const $fromJs = typeof Buffer === \"function\" \? (t) => /^[\\x00-\\x7f]*$/.test(t) \? t : Buffer.from(t, \"utf8\").toString(\"latin1\") : (t) => { if (/^[\\x00-\\x7f]*$/.test(t)) return t; const b = new TextEncoder().encode(t); let s = \"\"; for (let i = 0; i < b.length; i += 8192) s += String.fromCharCode.apply(null, b.subarray(i, i + 8192)); return s; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str6, 5, "$toJs");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str7, 262, "const $toJs = typeof Buffer === \"function\" \? (s) => /^[\\x00-\\x7f]*$/.test(s) \? s : Buffer.from(s, \"latin1\").toString(\"utf8\") : (s) => /^[\\x00-\\x7f]*$/.test(s) \? s : new TextDecoder(\"utf-8\", { ignoreBOM: true }).decode(Uint8Array.from(s, (c) => c.charCodeAt(0)));");

static V g_heff_2ecompile_2eemit_2estrHelpers_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2estrHelpers_st;
static V g_heff_2ecompile_2eemit_2estrHelpers_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str0), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str2), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str4), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str5)}), v_t_241});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str6), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str7)}), v_t_242});
}
V g_heff_2ecompile_2eemit_2estrHelpers_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2estrHelpers_st)) return g_heff_2ecompile_2eemit_2estrHelpers_val;
  return heff_global(&g_heff_2ecompile_2eemit_2estrHelpers_val, &g_heff_2ecompile_2eemit_2estrHelpers_st, g_heff_2ecompile_2eemit_2estrHelpers_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2etrampolineStr_str0, 206, "let $dep = 0; function $Bnc(f, a) { this.f = f; this.a = a; } const $trs = (r) => { do { $dep = 0; r = r.f(r.a); } while (r instanceof $Bnc); return r; }; const $tr = (r) => r instanceof $Bnc \? $trs(r) : r;");

static V g_heff_2ecompile_2eemit_2etrampolineStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2etrampolineStr_st;
static V g_heff_2ecompile_2eemit_2etrampolineStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2etrampolineStr_str0);
}
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2etrampolineStr_st)) return g_heff_2ecompile_2eemit_2etrampolineStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2etrampolineStr_val, &g_heff_2ecompile_2eemit_2etrampolineStr_st, g_heff_2ecompile_2eemit_2etrampolineStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2euncurryGo_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2euncurryGo_str1, 5, ") => ");
Clo g_heff_2ecompile_2eemit_2euncurryGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2euncurryGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2euncurryGo(V v_ps_240, V v_s_241) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2euncurryGo_str0))) {
    V v_t_243 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
    V v_j_244 = heff_strFind(((V)&g_heff_2ecompile_2eemit_2euncurryGo_str1), v_t_243, MK_INT(0LL));
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
      return heff_rec_n(2, shape_params__body, (V[]){v_t_246, v_s_241});
    } else {
      V v_t_247 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
      V v_t_248 = (g_heff_2ecompile_2eemit_2eisIdent(heff_strSlice_lent(v_t_247, MK_INT(0LL), v_j_244, 3)));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_t_249, MK_INT(0LL), v_j_244, 3), v_ps_240});
        V v_t_2411 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
        int64_t v_t_2412 = (heff_unbox_word(heff_strLength(v_s_241)) - ((int64_t)1ULL));
        V v_t_2413 = heff_strSlice(v_t_2411, heff_intAdd(v_j_244, MK_INT(5LL)), heff_box_word(v_t_2412));
        V t_0 = v_t_2410;
        V t_1 = v_t_2413;
        v_ps_240 = t_0;
        v_s_241 = t_1;
        goto top;
      } else {
        heff_drop(v_j_244);
        heff_drop(v_t_248);
        V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
        return heff_rec_n(2, shape_params__body, (V[]){v_t_2414, v_s_241});
      }
    }
  } else {
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
    return heff_rec_n(2, shape_params__body, (V[]){v_t_2415, v_s_241});
  }
}
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2euncurryGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eglobalJsH_str0, 0, "");
Clo g_heff_2ecompile_2eemit_2eglobalJsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eglobalJsH_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eglobalJsH(V v_p_240, V v_g_241, V v_rest_242) {
top: ;
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_p_240, 0, 1); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_i_247 = v_field_245;
      V v_t_248 = heff_tag_n(TAG_HS, 1, (V[]){heff_take_field(v_i_247, 0)});
      V v_t_249 = heff_tag_n(TAG_HN, 1, (V[]){heff_take_field(v_i_247, 1)});
      V v_t_2410 = heff_take_field(v_i_247, 2);
      V v_t_2411;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        v_t_2411 = MK_INT(1LL);
      } else {
        heff_drop(v_t_2410);
        v_t_2411 = MK_INT(0LL);
      }
      V v_t_2412 = heff_get_n(v_i_247, 3, 4);
      V v_t_2413;
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = MK_INT(1LL);
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = MK_INT(0LL);
      }
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2413}), v_rest_242});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2411}), v_t_2414});
      V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2415})});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2416});
    } else {
      heff_drop(v_field_245);
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eglobalJsH_str0)}), v_rest_242});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2417});
    }
  }
}
V g_heff_2ecompile_2eemit_2eglobalJsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eglobalJsH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2eglobalOfPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eglobalOfPart_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eglobalOfPart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PartVal: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24PartVal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_SVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      V v_g_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24PartVal, TAG_Just, 1, (V[]){v_g_243});
    }
    case TAG_SInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24PartVal, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  case TAG_PartOp: {
    V v_x11_2425 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24PartOp = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2425)) {
    case TAG_OSimple: {
      heff_take_n(v_x11_2425, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartOp, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OCall: {
      V v_g_2427 = heff_field(v_x11_2425, 0);
      heff_take_n(v_x11_2425, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24PartOp, TAG_Just, 1, (V[]){v_g_2427});
    }
    case TAG_OApply: {
      heff_take_n(v_x11_2425, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24PartOp, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OPrim: {
      heff_take_n(v_x11_2425, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24PartOp, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OAbandon: {
      heff_drop_cell(v_ru_24x1_240_24PartOp, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OBool: {
      heff_take_n(v_x11_2425, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24PartOp, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_2425);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eglobalOfPart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eglobalOfPart(a[0]);
}
V g_heff_2ecompile_2eemit_2enamesIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2enamesIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamesIn_entry, 2, 0};

V g_heff_2ecompile_2eemit_2enamesIn(V v_p_240, V v_d_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_k_242 = heff_field(v_d_241, 0);
    v_t_245 = heff_dup(v_k_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_t_2414;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_x13_248 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_x13_248)) {
    case TAG_DefFun: {
      V v_x132_2410 = heff_field(v_x13_248, 1);
      switch (heff_tag_of(v_x132_2410)) {
      case TAG_MkBlock: {
        V v_t_2411 = heff_field(v_x132_2410, 0);
        v_t_2414 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2411, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x132_2410);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x131_2412 = heff_field(v_x13_248, 0);
      switch (heff_tag_of(v_x131_2412)) {
      case TAG_MkBlock: {
        V v_t_2413 = heff_field(v_x131_2412, 0);
        v_t_2414 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2413, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x131_2412);
      }
      break;
    }
    default: heff_nomatch(v_x13_248);
    }
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_t_2415 = (g_list_2emap_24s1455783996x1449538216(v_t_2414));
  V v_t_2416 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2415));
  V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2enamesIn_lam0, 1, 1, (V[]){v_p_240}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2416})));
  V v_xs_2424 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2423));
  return ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2424; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_xs_2424); r_; });
}
V g_heff_2ecompile_2eemit_2enamesIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2enamesIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemit_2enamesIn_lam0(V self, V *args) {
  V v_g_2417 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2418 = ({ V b_0 = heff_get_n(v_p_240, 0, 1); V a_1 = v_g_2417; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_2417); r_; });
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_i_2422 = v_field_2420;
      return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_i_2422, 0, 4)});
    } else {
      heff_drop(v_field_2420);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246(V v_v_240, V v_d_241) {
top: ;
  V v_t_2410;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_x13_244 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_x13_244)) {
    case TAG_DefFun: {
      V v_x132_246 = heff_field(v_x13_244, 1);
      switch (heff_tag_of(v_x132_246)) {
      case TAG_MkBlock: {
        V v_t_247 = heff_field(v_x132_246, 0);
        v_t_2410 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_247, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x132_246);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x131_248 = heff_field(v_x13_244, 0);
      switch (heff_tag_of(v_x131_248)) {
      case TAG_MkBlock: {
        V v_t_249 = heff_field(v_x131_248, 0);
        v_t_2410 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_249, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x131_248);
      }
      break;
    }
    default: heff_nomatch(v_x13_244);
    }
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_t_2411 = (g_list_2emap_24s1585362143x1323498048(v_t_2410));
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
  V v_t_2421;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_x13_2415 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_x13_2415)) {
    case TAG_DefFun: {
      V v_x132_2417 = heff_field(v_x13_2415, 1);
      switch (heff_tag_of(v_x132_2417)) {
      case TAG_MkBlock: {
        V v_t_2418 = heff_field(v_x132_2417, 0);
        v_t_2421 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2418, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x132_2417);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x131_2419 = heff_field(v_x13_2415, 0);
      switch (heff_tag_of(v_x131_2419)) {
      case TAG_MkBlock: {
        V v_t_2420 = heff_field(v_x131_2419, 0);
        v_t_2421 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2420, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x131_2419);
      }
      break;
    }
    default: heff_nomatch(v_x13_2415);
    }
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_m_2422 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s398854970x1533504811(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
  V v_t_2424 = (g_list_2emap_24s1937570095x2110149801(v_t_2423));
  return heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_v_240, NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2412, v_t_2424});
}
V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_24cpr_str4, 1, "x");
V g_heff_2ecompile_2eemit_2eemitKept_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2eemitKept_24cpr(V v_facts_240, V v_defs_241, V v_roots_242, V v_kept_243) {
top: ;
  V v_keys_244 = (g_list_2emap_24s1835183789x486277886(heff_dup(v_defs_241)));
  V v_shorts_245 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2eemitKept_24cpr_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2eemitKept_24cpr_str1); V b_3 = MK_INT(0LL); V a_4 = MK_INT(1LL); V a_5 = MK_INT(0LL); V a_6 = ((V)&g_heff_2ecompile_2eemit_2eemitKept_24cpr_str2); V b_7 = ((V)&g_heff_2ecompile_2eemit_2eemitKept_24cpr_str3); V a_8 = ((V)&g_heff_2ecompile_2eemit_2eemitKept_24cpr_str4); V a_9 = heff_dup(v_keys_244); V r_ = (g_list_2emap_24s679881967x35917574(b_0, a_1, b_2, b_3, a_4, a_5, a_6, b_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_7); r_; });
  V v_t_248 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eemitKept_24cpr_lam0, 2, 2, (V[]){v_shorts_245, v_facts_240}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_keys_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_keys_244); r_; });
  return ({ V a_0 = heff_rec_n(1, shape_info, (V[]){v_t_248}); V a_1 = v_defs_241; V a_2 = v_roots_242; V a_3 = v_kept_243; HeffT2 r_ = (g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemit_2eemitKept_24cpr_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_k_247 = args[1];
  V v_shorts_245 = heff_env(self)[0];
  V v_facts_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_shorts_245; V a_1 = v_facts_240; V a_2 = v_acc_246; V a_3 = v_k_247; V r_ = (g_heff_2ecompile_2eemit_2einfoOne(a_0, a_1, a_2, a_3)); heff_drop(v_shorts_245); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str0, 5, "})();");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str1, 105, "    release: (i) => { const t = at(i); things.delete(i); numbers.delete(t.x); if (t.free) t.free(t.x); },");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str2, 4, "  };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str3, 145, "    hold: (x, free) => { let i = numbers.get(x); if (i === undefined) { i = next++; numbers.set(x, i); things.set(i, { x, free }); } return i; },");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str4, 24, "    get: (i) => at(i).x,");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str5, 131, "  const at = (i) => { const t = things.get(i); if (!t) throw new Error(\"heff: the world holds nothing numbered \" + i); return t; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str6, 10, "  return {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str7, 48, "  const things = new Map(), numbers = new Map();");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str8, 16, "  let next = 0n;");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str9, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eworldStr_str10, 23, "const $world = (() => {");

static V g_heff_2ecompile_2eemit_2eworldStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2eworldStr_st;
static V g_heff_2ecompile_2eemit_2eworldStr_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eworldStr_str9); V a_1 = ((V)&g_heff_2ecompile_2eemit_2eworldStr_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ecompile_2eemit_2eworldStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2eworldStr_st)) return g_heff_2ecompile_2eemit_2eworldStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2eworldStr_val, &g_heff_2ecompile_2eemit_2eworldStr_st, g_heff_2ecompile_2eemit_2eworldStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ehostLineOf_str0, 22, "export const $host = \"");
HEFF_LIT(g_heff_2ecompile_2eemit_2ehostLineOf_str1, 1, "\"");
Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ehostLineOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ehostLineOf(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_heff_2ecompile_2eemit_2ehostLineOf_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_l_240), MK_INT(22LL), heff_strLength_lent(v_l_240, 0));
    V v_j_243 = heff_strFind(((V)&g_heff_2ecompile_2eemit_2ehostLineOf_str1), v_t_242, MK_INT(0LL));
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      V v_t_245 = heff_strSlice(heff_dup(v_l_240), MK_INT(22LL), heff_strLength_lent(v_l_240, 0));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      V v_t_246 = heff_strSlice(heff_dup(v_l_240), MK_INT(22LL), heff_intAdd(MK_INT(22LL), v_j_243));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
    }
  } else {
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2ehostLineOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovIndexGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprovIndexGo(V v_i_240, V v_md_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(v_md_241))) {
      return v_i_240;
    } else {
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_md_241;
      V t_2 = v_rest_244;
      v_i_240 = t_0;
      v_md_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eprovIndexGo(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eemit_2eprovsForGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprovsForGo_24dps(V v_available_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_available_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_md_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = ({ V a_0 = v_md_243; V a_1 = heff_dup(v_available_240); HeffT2 r_ = (g_heff_2ecompile_2eemit_2efindProv_24cpr(a_0, a_1)); heff_drop(v_md_243); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_p_249 = v_field_247;
        V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_p_249, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = v_available_240;
        V t_1 = v_rest_244;
        V t_2 = v_cell_2410;
        v_available_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_247);
        V t_0 = v_available_240;
        V t_1 = v_rest_244;
        V t_2 = v_d_242;
        v_available_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprovsForGo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2ekeptOutput_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ekeptOutput_entry, 5, 0};

V g_heff_2ecompile_2eemit_2ekeptOutput(V v_provs_240, V v_eff_241, V v_key_242, V v_kept_243, V v_sk_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_247 = (g_heff_2ecompile_2elower_2efusedOf(v_t_246, heff_take_field(v_sk_244, 0)));
  HeffT3 v_t_248 = (g_heff_2ecompile_2elower_2elowerFused_24cpr(v_t_245, heff_take_field(v_sk_244, 1), v_t_247));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    HeffT2 v_t_2413 = (g_heff_2ecompile_2eemit_2eemitKept_24cpr(v_field_2410, v_field_249, v_t_2412, v_kept_243));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_t_2416 = (g_heff_2ecompile_2eemit_2erunSource(v_provs_240, v_eff_241, v_key_242, v_field_2414));
      return heff_rec_n(4, shape_output__groups__copies__jss, (V[]){heff_rec_n(2, shape_source__errors, (V[]){v_t_2416, v_field_2411}), heff_dup(heff_rfield(v_sk_244, 2)), heff_get_n(v_sk_244, 3, 4), v_field_2415});
    }
  }
}
V g_heff_2ecompile_2eemit_2ekeptOutput_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2ekeptOutput(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}