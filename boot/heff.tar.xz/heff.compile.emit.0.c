// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_FloatAdd 6390
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatLe 13237
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatSub 24213
#define TAG_IntAdd 18227
#define TAG_IntEq 36665
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMul 30294
#define TAG_IntSub 36050
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_MkArmJs 44527
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_StrAppend 34515
#define TAG_StrEq 12955
#define TAG_StrLt 13175
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_env 310119
#define LBL_gs 10067
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_module 878357911
#define LBL_names 305943394
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_self 10021907
#define LBL_tail 10047767
#define LBL_used 10094724
#define LBL_val 326043
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_params__body[] = {LBL_params, LBL_body};
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V, V, V, V);
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo;
V g_heff_2ecompile_2eemit_2earmBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_clo;
V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_clo;
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo;
V g_heff_2ecompile_2eemit_2eboolCode(V);
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eboolCode_clo;
V g_heff_2ecompile_2eemit_2ebounceGive_24tok2(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_24tok2_clo;
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo;
V g_heff_2ecompile_2eemit_2ecellVal(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecellVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellVal_clo;
V g_heff_2ecompile_2eemit_2econdCode(V);
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdCode_clo;
HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_clo;
V g_heff_2ecompile_2eemit_2edeclsOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_clo;
HeffT2 g_heff_2ecompile_2eemit_2efindProv_24cpr(V, V);
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
HeffT2 g_heff_2ecompile_2eemit_2eletBound_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations(V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo;
V g_heff_2ecompile_2eemit_2enubGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
V g_heff_2ecompile_2eemit_2eprimBin(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimBin_clo;
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimOp_24cpr(V);
HeffT2 g_heff_2ecompile_2eemit_2eprimRel_24cpr(V);
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_24dps_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereturnCond(V, V);
V g_heff_2ecompile_2eemit_2ereturnCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnCond_clo;
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
HeffT2 g_heff_2ecompile_2eemit_2esetStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo(V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esharedGo_clo;
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2euncurryGo(V, V);
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2euncurryGo_clo;
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
HeffT2 g_heff_2ecompile_2eemit_2ewordOf_24cpr(V);
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecatMaybesL_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2enubGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enubGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemit_2enubGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1006624359x760861690(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2enubGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enubGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str0, 4, "plus");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str1, 5, "minus");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str2, 5, "times");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str3, 5, "slash");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str4, 7, "percent");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str5, 2, "eq");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str6, 2, "lt");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str7, 2, "gt");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str8, 3, "amp");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str9, 3, "bar");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str10, 4, "bang");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str11, 5, "caret");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str12, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str13, 2, "at");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str14, 4, "hash");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str15, 6, "dollar");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str16, 5, "tilde");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str17, 5, "colon");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str18, 3, "dot");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewordOf_24cpr_str19, 9, "backslash");

HeffT2 g_heff_2ecompile_2eemit_2ewordOf_24cpr(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((v_c_240 == ((int64_t)43ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str0)}});
  } else {
    if ((v_c_240 == ((int64_t)45ULL))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str1)}});
    } else {
      if ((v_c_240 == ((int64_t)42ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str2)}});
      } else {
        if ((v_c_240 == ((int64_t)47ULL))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str3)}});
        } else {
          if ((v_c_240 == ((int64_t)37ULL))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str4)}});
          } else {
            if ((v_c_240 == ((int64_t)61ULL))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str5)}});
            } else {
              if ((v_c_240 == ((int64_t)60ULL))) {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str6)}});
              } else {
                if ((v_c_240 == ((int64_t)62ULL))) {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str7)}});
                } else {
                  if ((v_c_240 == ((int64_t)38ULL))) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str8)}});
                  } else {
                    if ((v_c_240 == ((int64_t)124ULL))) {
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str9)}});
                    } else {
                      if ((v_c_240 == ((int64_t)33ULL))) {
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str10)}});
                      } else {
                        if ((v_c_240 == ((int64_t)94ULL))) {
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str11)}});
                        } else {
                          if ((v_c_240 == ((int64_t)63ULL))) {
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str12)}});
                          } else {
                            if ((v_c_240 == ((int64_t)64ULL))) {
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str13)}});
                            } else {
                              if ((v_c_240 == ((int64_t)35ULL))) {
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str14)}});
                              } else {
                                if ((v_c_240 == ((int64_t)36ULL))) {
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str15)}});
                                } else {
                                  if ((v_c_240 == ((int64_t)126ULL))) {
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str16)}});
                                  } else {
                                    if ((v_c_240 == ((int64_t)58ULL))) {
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str17)}});
                                    } else {
                                      if ((v_c_240 == ((int64_t)46ULL))) {
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str18)}});
                                      } else {
                                        if ((v_c_240 == ((int64_t)92ULL))) {
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2ewordOf_24cpr_str19)}});
                                        } else {
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esafeChars_str0, 1, "_");
Clo g_heff_2ecompile_2eemit_2esafeChars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esafeChars_entry, 3, 0};

V g_heff_2ecompile_2eemit_2esafeChars(V v_x_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_c_243 = heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2);
    V v_t_244;
    if ((((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_243) == ((int64_t)95ULL)))))) {
      heff_drop(v_c_243);
      v_t_244 = heff_strSlice_lent(v_x_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    } else {
      heff_drop(v_c_243);
      v_t_244 = ((V)&g_heff_2ecompile_2eemit_2esafeChars_str0);
    }
    V t_0 = v_x_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_x_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2esafeChars(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V v_env_240, V v_x_241, V v_base_242, V v_i_243) {
top: ;
  V v_t_244;
  if (heff_intEq_c_lent(v_i_243, MK_INT(0LL), 2)) {
    v_t_244 = heff_dup(v_base_242);
  } else {
    v_t_244 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
  }
  HeffT2 v_t_245 = ({ V a_0 = heff_rfield(v_env_240, 2); V a_1 = v_t_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      heff_drop(v_x_248);
      V t_0 = v_env_240;
      V t_1 = v_x_241;
      V t_2 = v_base_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      v_env_240 = t_0;
      v_x_241 = t_1;
      v_base_242 = t_2;
      v_i_243 = t_3;
      goto top;
    } else {
      heff_drop(v_field_247);
      V v_f_249;
      if (heff_intEq_c_lent(v_i_243, MK_INT(0LL), 2)) {
        v_f_249 = heff_dup(v_base_242);
      } else {
        v_f_249 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
      }
      V v_v_2410;
      if (heff_intEq_c_lent(v_i_243, MK_INT(0LL), 2)) {
        heff_drop(v_i_243);
        v_v_2410 = v_base_242;
      } else {
        v_v_2410 = heff_strAppend(v_base_242, heff_intShow(v_i_243));
      }
      V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_env_240, 1), v_x_241, heff_dup(v_v_2410)));
      V v_t_2412 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_env_240, 2), v_v_2410, NTAG(TAG_MkUnit)));
      V v_f_2413 = ({ V rv_1 = v_t_2411; V rv_2 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_env_240, 25ULL, 5, shape_gs__names__used__self__inl, 963u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      return ((HeffT2){{v_f_249, v_f_2413}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str3, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str4, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str5, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str6, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str7, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str8, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str9, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str10, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str11, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str12, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str13, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str14, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_24cpr_str15, 1, "<");

HeffT2 g_heff_2ecompile_2eemit_2eprimOp_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntAdd: {
    V v_f_241 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str0)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_241}});
  }
  case TAG_IntSub: {
    V v_f_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str1)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_IntMul: {
    V v_f_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str2)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
  }
  case TAG_IntEq: {
    V v_f_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str3)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
  }
  case TAG_IntLt: {
    V v_f_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str4)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
  }
  case TAG_IntLe: {
    V v_f_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str5)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
  }
  case TAG_FloatAdd: {
    V v_f_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str6)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
  }
  case TAG_FloatSub: {
    V v_f_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str7)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  }
  case TAG_FloatMul: {
    V v_f_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str8)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
  }
  case TAG_FloatDiv: {
    V v_f_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str9)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
  }
  case TAG_FloatEq: {
    V v_f_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str10)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
  }
  case TAG_FloatLt: {
    V v_f_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str11)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
  }
  case TAG_FloatLe: {
    V v_f_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str12)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
  }
  case TAG_StrAppend: {
    V v_f_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str13)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
  }
  case TAG_StrEq: {
    V v_f_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str14)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
  }
  case TAG_StrLt: {
    V v_f_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_24cpr_str15)}));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
  }
  default: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str0, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str1, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str2, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str3, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str4, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str7, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str8, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str9, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str10, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str11, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str12, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str13, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str14, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str15, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str16, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str17, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str18, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str19, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_str20, 9, "undefined");
Clo g_heff_2ecompile_2eemit_2ecellVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecellVal_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ecellVal(V v_r_240, V v_env_241, V v_ind_242, V v_args_243) {
top: ;
  switch (heff_tag_of(v_args_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 6);
    heff_drop(v_env_241);
    heff_drop(v_ind_242);
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str0), MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_args_243, 0);
    V v_args2_245 = heff_field(v_args_243, 1);
    switch (heff_tag_of(v_args2_245)) {
    case TAG_Nil: {
      heff_drop_rec(v_r_240, 6);
      heff_drop(v_env_241);
      heff_drop(v_ind_242);
      return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str1), MK_INT(3LL)});
    }
    case TAG_Cons: {
      V v_args21_246 = heff_field(v_args2_245, 0);
      V v_args22_247 = heff_field(v_args2_245, 1);
      switch (heff_tag_of(v_args21_246)) {
      case TAG_SVar: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str2), MK_INT(3LL)});
      }
      case TAG_SGlobal: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str3), MK_INT(3LL)});
      }
      case TAG_SInt: {
        V v_k_2410 = heff_field(v_args21_246, 0);
        switch (heff_tag_of(v_args22_247)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_240, 6);
          heff_drop(v_env_241);
          heff_drop(v_ind_242);
          return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str4), MK_INT(3LL)});
        }
        case TAG_Cons: {
          V v_v_2411 = heff_field(v_args22_247, 0);
          V v_args222_2412 = heff_field(v_args22_247, 1);
          switch (heff_tag_of(v_args222_2412)) {
          case TAG_Nil: {
            V v_c_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), heff_dup(v_d_244)}));
            V v_prec_2414 = heff_take_field(v_c_2413, 1);
            V v_code_2415 = heff_get_n(v_c_2413, 0, 2);
            V v_t_2416;
            if (heff_intLt_c(v_prec_2414, MK_INT(3LL))) {
              v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecellVal_str5), v_code_2415), ((V)&g_heff_2ecompile_2eemit_2ecellVal_str6));
            } else {
              v_t_2416 = v_code_2415;
            }
            V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ecellVal_str7)), heff_intShow(heff_dup(v_k_2410)));
            V v_c_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, heff_dup(v_v_2411)}));
            V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2ecellVal_str8)), heff_get_n(v_c_2418, 0, 2));
            return heff_rec_n(2, shape_code__prec, (V[]){v_t_2419, MK_INT(0LL)});
          }
          case TAG_Cons: {
            heff_drop_rec(v_r_240, 6);
            heff_drop(v_env_241);
            heff_drop(v_ind_242);
            return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str9), MK_INT(3LL)});
          }
          default: return heff_nomatch(v_args222_2412);
          }
        }
        default: return heff_nomatch(v_args22_247);
        }
      }
      case TAG_SFloat: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str10), MK_INT(3LL)});
      }
      case TAG_SStr: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str11), MK_INT(3LL)});
      }
      case TAG_SBytes: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str12), MK_INT(3LL)});
      }
      case TAG_SFixed: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str13), MK_INT(3LL)});
      }
      case TAG_SFloat32: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str14), MK_INT(3LL)});
      }
      case TAG_SPrimFn: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str15), MK_INT(3LL)});
      }
      case TAG_SLam: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str16), MK_INT(3LL)});
      }
      case TAG_STag: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str17), MK_INT(3LL)});
      }
      case TAG_SRec: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str18), MK_INT(3LL)});
      }
      case TAG_SProj: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str19), MK_INT(3LL)});
      }
      case TAG_SPrim: {
        heff_drop_rec(v_r_240, 6);
        heff_drop(v_env_241);
        heff_drop(v_ind_242);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_str20), MK_INT(3LL)});
      }
      default: return heff_nomatch(v_args21_246);
      }
    }
    default: return heff_nomatch(v_args2_245);
    }
  }
  default: return heff_nomatch(v_args_243);
  }
}
V g_heff_2ecompile_2eemit_2ecellVal_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2ecellVal(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str3, 8, "default:");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str5, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str6, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str7, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str8, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str9, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str10, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2earmBound_str13, 1, "}");
Clo g_heff_2ecompile_2eemit_2earmBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmBound_entry, 5, 0};

V g_heff_2ecompile_2eemit_2earmBound(V v_sc_240, V v_ind_241, V v_tag_242, V v_lines_243, V v_rb_244) {
top: ;
  V v_js_245 = heff_take_field(v_rb_244, 0);
  V v_env_246 = heff_get_n(v_rb_244, 1, 2);
  V v_x2_247 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2earmBound_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2413;
  if (heff_strEq_c(heff_dup(v_tag_242), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
    v_t_2413 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str3);
  } else {
    V v_t_2411 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_tag_242), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2earmBound_str4)));
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2earmBound_str5), v_t_2411), ((V)&g_heff_2ecompile_2eemit_2earmBound_str6));
    v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2earmBound_str7), v_t_2412), ((V)&g_heff_2ecompile_2eemit_2earmBound_str8));
  }
  V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2410, v_t_2413), ((V)&g_heff_2ecompile_2eemit_2earmBound_str9));
  V v_t_2415 = (g_heff_2ecompile_2eemit_2edeclsOf(heff_get_n(v_sc_240, 0, 3), heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL)), v_js_245, MK_INT(0LL)));
  V v_t_2416 = heff_tr(heff_call(v_lines_243, 2, (V[]){v_env_246, heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL))}));
  V v_x2_2417 = (g_list_2ereplicate(heff_intAdd(v_ind_241, MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2earmBound_str10)));
  V v_t_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str11);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2earmBound_str12); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemit_2earmBound_str13)), NTAG(TAG_Nil)});
  V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2421));
  V v_ys_2423 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2422));
  return heff_tag_n(TAG_MkArmJs, 3, (V[]){v_tag_242, NTAG(TAG_False), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_ys_2423})});
}
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2earmBound(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str3, 8, "switch (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str4, 5, ".$) {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eswitchLines_str8, 1, "}");
Clo g_heff_2ecompile_2eemit_2eswitchLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eswitchLines_entry, 5, 0};

V g_heff_2ecompile_2eemit_2eswitchLines(V v_sc_240, V v_ind_241, V v_arms_242, V v_inside_243, V v_after_244) {
top: ;
  V v_pre_245 = heff_take_field(v_sc_240, 2);
  V v_js_246 = heff_get_n(v_sc_240, 0, 3);
  V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str3)), v_js_246);
  V v_t_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str4));
  V v_t_2413 = (g_heff_2ecompile_2eemit_2esharedGo(heff_dup(v_ind_241), NTAG(TAG_Nil), v_arms_242));
  V v_x2_2414 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str5)));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str7); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2eswitchLines_str8)), v_after_244});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_inside_243, v_t_2418));
  V v_ys_2420 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2419));
  return (g_prelude_2e_2b_2b(v_pre_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_ys_2420})));
}
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eswitchLines(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str3, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str4, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str8, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str11, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemit_2eifLines_str12, 8, "} else {");
Clo g_heff_2ecompile_2eemit_2eifLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eifLines_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eifLines(V v_ind_240, V v_c_241, V v_t_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_c_241)) {
  case TAG_JTrue: {
    heff_drop(v_f_243);
    return heff_tail(v_t_242, 1, (V[]){v_ind_240});
  }
  case TAG_JFalse: {
    heff_drop(v_t_242);
    return heff_tail(v_f_243, 1, (V[]){v_ind_240});
  }
  default: {
    V v_t_244 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_245 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_244));
    V v_x2_246 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2eifLines_str3)), heff_get_n(v_t_2410, 0, 2));
    V v_t_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eifLines_str4));
    V v_t_2413 = heff_tr(heff_call(v_t_242, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2414 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2eifLines_str5)));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str7); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_t_2418 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL))}));
    V v_x2_2419 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eifLines_str8)));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eifLines_str10); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemit_2eifLines_str11)), NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2423));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2eifLines_str12)), v_t_2424});
    V v_ys_2426 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2425));
    return (g_prelude_2e_2b_2b(v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_ys_2426})));
  }
  }
}
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eifLines(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletBound_24cpr_str5, 1, ";");

HeffT2 g_heff_2ecompile_2eemit_2eletBound_24cpr(V v_ind_240, V v_st_241, V v_nb_242) {
top: ;
  V v_js_243 = heff_take_field(v_nb_242, 0);
  V v_env_244 = heff_get_n(v_nb_242, 1, 2);
  V v_decls_245 = heff_take_field(v_st_241, 1);
  V v_code_246 = heff_get_n(v_st_241, 0, 2);
  V v_t_247 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_decls_245));
  V v_x2_248 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str0)));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str3)), v_js_243);
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str4)), heff_get_n(v_code_246, 0, 2));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2eletBound_24cpr_str5)), NTAG(TAG_Nil)});
  V v_f_2415 = (g_prelude_2e_2b_2b(v_t_247, v_t_2414));
  V v_f_2416 = v_env_244;
  return ((HeffT2){{v_f_2415, v_f_2416}});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_24cpr_str4, 1, ";");

HeffT2 g_heff_2ecompile_2eemit_2esetStmt_24cpr(V v_ind_240, V v_st_241, V v_x_242, V v_env_243) {
top: ;
  V v_decls_244 = heff_take_field(v_st_241, 1);
  V v_code_245 = heff_get_n(v_st_241, 0, 2);
  V v_t_246 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), heff_dup(v_decls_244)));
  V v_x2_247 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_d_2411 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_x_242)));
  HeffT2 v_t_2412 = ({ V a_0 = heff_rfield(v_env_243, 1); V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_242); r_; });
  V v_t_2416;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_d_2411);
      V v_x_2415 = v_field_2414;
      v_t_2416 = v_x_2415;
    } else {
      heff_drop(v_field_2414);
      v_t_2416 = v_d_2411;
    }
  }
  V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2410, v_t_2416), ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str3));
  V v_t_2418 = heff_strAppend(v_t_2417, heff_get_n(v_code_245, 0, 2));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2esetStmt_24cpr_str4)), NTAG(TAG_Nil)});
  V v_f_2420 = (g_prelude_2e_2b_2b(v_t_246, v_t_2419));
  V v_f_2421 = ({ V a_0 = v_env_243; V a_1 = v_decls_244; V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, a_1)); heff_drop(v_decls_244); r_; });
  return ((HeffT2){{v_f_2420, v_f_2421}});
}
Clo g_heff_2ecompile_2eemit_2eatomGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eatomGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eatomGo(V v_c_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_c_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_c_242 = heff_strByteAt_lent(v_c_240, heff_box_word(v_i_241), 2);
    V v_t_243 = heff_bool((((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))))));
    heff_drop(v_c_242);
    if (((heff_dup(v_t_243) == NTAG(TAG_True)) || (heff_unbox_word(heff_strByteAt_lent(v_c_240, heff_box_word(v_i_241), 2)) == ((int64_t)36ULL)))) {
      heff_drop(v_t_243);
      V t_0 = v_c_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_c_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eatomGo(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str3, 10, "return $T;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str7, 10, "return $F;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str8, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str13, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnCond_str14, 11, " \? $T : $F;");
Clo g_heff_2ecompile_2eemit_2ereturnCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ereturnCond_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ereturnCond(V v_ind_240, V v_c_241) {
top: ;
  switch (heff_tag_of(v_c_241)) {
  case TAG_JTrue: {
    V v_x2_242 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str0)));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str2); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str3)), NTAG(TAG_Nil)});
  }
  case TAG_JFalse: {
    V v_x2_246 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str4)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str6); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str7)), NTAG(TAG_Nil)});
  }
  default: {
    V v_t_2410 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2411 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2410));
    V v_x2_2412 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str8)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str10); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    HeffT2 v_t_2416 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_241));
    V v_t_2419;
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      if (heff_intLt_c(v_field_2418, MK_INT(1LL))) {
        v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnCond_str11), v_field_2417), ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str12));
      } else {
        v_t_2419 = v_field_2417;
      }
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str13)), v_t_2419);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemit_2ereturnCond_str14)), NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2411, v_t_2421);
  }
  }
}
V g_heff_2ecompile_2eemit_2ereturnCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ereturnCond(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str2, 2, "{\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str3, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_str7, 1, "}");
Clo g_heff_2ecompile_2eemit_2eblockOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eblockOf(V v_r_240, V v_env_241, V v_ind_242, V v_t_243) {
top: ;
  V v_x2_244 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 6), 3, (V[]){v_env_241, heff_intAdd(heff_dup(v_ind_242), MK_INT(1LL)), v_t_243}));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_str2), v_t_247), ((V)&g_heff_2ecompile_2eemit_2eblockOf_str3));
  V v_x2_249 = (g_list_2ereplicate(v_ind_242, ((V)&g_heff_2ecompile_2eemit_2eblockOf_str4)));
  V v_t_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_str6); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  return heff_strAppend(heff_strAppend(v_t_248, v_t_2412), ((V)&g_heff_2ecompile_2eemit_2eblockOf_str7));
}
V g_heff_2ecompile_2eemit_2eblockOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eblockOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str2, 2, "{\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str3, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str7, 1, "}");
Clo g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  V v_x2_243 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str2), v_t_246), ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str3));
  V v_x2_248 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str4)));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str6); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  return heff_strAppend(heff_strAppend(v_t_247, v_t_2411), ((V)&g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_str7));
}
V g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str2, 1, ")");
Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V v_env_240, V v_ind_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_TSeq: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  case TAG_TReturn: {
    V v_o_245 = heff_dup(heff_field(v_t_242, 0));
    V v_t_2418;
    switch (heff_tag_of(v_o_245)) {
    case TAG_OSimple: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_OCall: {
      V v_g_247 = heff_dup(heff_field(v_o_245, 0));
      HeffT2 v_t_249 = ({ V a_0 = heff_rfield(v_env_240, 0); V a_1 = v_g_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_247); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_i_2412 = v_field_2411;
          v_t_2418 = heff_bool(!(heff_dup(heff_rfield(v_i_2412, 3)) == NTAG(TAG_True)));
          heff_drop_rec(v_i_2412, 4);
        } else {
          heff_drop(v_field_2411);
          v_t_2418 = NTAG(TAG_True);
        }
      }
      break;
    }
    case TAG_OApply: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_OPrim: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_OAbandon: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_OBool: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_o_245);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop_tag(v_t_242, 1);
      heff_drop(v_t_2418);
      V v_t_2419 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_245; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_245); r_; });
      V v_c_2420 = heff_get_n(v_t_2419, 0, 2);
      if (heff_strEq_c(heff_strSlice_lent(v_c_2420, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str0))) {
        return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str1), v_c_2420), ((V)&g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_str2));
      } else {
        return v_c_2420;
      }
    } else {
      heff_drop(v_o_245);
      heff_drop(v_t_2418);
      HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
    }
  }
  case TAG_TLoop: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  case TAG_TIf: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  case TAG_TCase: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockOf_24s1175195204x325875634(v_env_240, v_ind_241, v_t_242);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str2, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str9, 13, ".$ === \"True\"");
Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry, 3, 0};

V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_PTrue: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return NTAG(TAG_JTrue);
  }
  case TAG_PFalse: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return NTAG(TAG_JFalse);
  }
  case TAG_PRel: {
    V v_p_243 = heff_field(v_x4_242, 0);
    V v_a_244 = heff_field(v_x4_242, 1);
    V v_b_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_c_246 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_a_244; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_244); r_; });
    V v_prec_247 = heff_take_field(v_c_246, 1);
    V v_code_248 = heff_get_n(v_c_246, 0, 2);
    V v_t_249;
    if (heff_intLt_c(v_prec_247, MK_INT(2LL))) {
      v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str0), v_code_248), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str1));
    } else {
      v_t_249 = v_code_248;
    }
    HeffT2 v_t_2410 = ({ V a_0 = v_p_243; HeffT2 r_ = (g_heff_2ecompile_2eemit_2eprimRel_24cpr(a_0)); heff_drop(v_p_243); r_; });
    V v_t_2414;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2412;
        v_t_2414 = v_x_2413;
      } else {
        heff_drop(v_field_2412);
        v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str2);
      }
    }
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str3)), v_t_2414);
    V v_c_2416 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_b_245; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_b_245); r_; });
    V v_prec_2417 = heff_take_field(v_c_2416, 1);
    V v_code_2418 = heff_get_n(v_c_2416, 0, 2);
    V v_t_2419;
    if (heff_intLt_c(v_prec_2417, MK_INT(2LL))) {
      v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str4), v_code_2418), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str5));
    } else {
      v_t_2419 = v_code_2418;
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str6)), v_t_2419);
    return heff_tag_n(TAG_JRel, 1, (V[]){v_t_2420});
  }
  case TAG_PBool: {
    V v_v_2421 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_c_2422 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2421; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2421); r_; });
    V v_prec_2423 = heff_take_field(v_c_2422, 1);
    V v_code_2424 = heff_get_n(v_c_2422, 0, 2);
    V v_t_2425;
    if (heff_intLt_c(v_prec_2423, MK_INT(3LL))) {
      v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str7), v_code_2424), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str8));
    } else {
      v_t_2425 = v_code_2424;
    }
    return heff_tag_at_n(v_ru_24x4_242_24PBool, TAG_JRel, 1, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_str9))});
  }
  case TAG_PNot: {
    V v_c_2426 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PNot = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_cell_2427 = heff_tag_at_n(v_ru_24x4_242_24PNot, TAG_JNot, 1, (V[]){heff_hole()});
    V v_u_2428 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(v_env_240, v_ind_241, v_c_2426, heff_dup(v_cell_2427), MK_INT(0LL)));
    heff_drop(v_u_2428);
    return v_cell_2427;
  }
  case TAG_PIf: {
    V v_a_2429 = heff_field(v_x4_242, 0);
    V v_b_2430 = heff_field(v_x4_242, 1);
    V v_c_2431 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2432 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_a_2429));
    V v_t_2433 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_b_2430));
    V v_cell_2434 = heff_tag_at_n(v_ru_24x4_242_24PIf, TAG_JIf, 3, (V[]){v_t_2432, v_t_2433, heff_hole()});
    V v_u_2435 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(v_env_240, v_ind_241, v_c_2431, heff_dup(v_cell_2434), MK_INT(2LL)));
    heff_drop(v_u_2435);
    return v_cell_2434;
  }
  case TAG_PLet: {
    V v_x_2436 = heff_field(v_x4_242, 0);
    V v_o_2437 = heff_field(v_x4_242, 1);
    V v_c_2438 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PLet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2439 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2436), MK_INT(0LL)));
    V v_t_2440 = (g_heff_2ecompile_2eemit_2esafe(v_t_2439));
    HeffT2 v_t_2441 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(heff_dup(v_env_240), v_x_2436, v_t_2440, MK_INT(0LL)));
    {
      V v_field_2442 = v_t_2441.f[0];
      V v_field_2443 = v_t_2441.f[1];
      V v_t_2444 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_o_2437; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_2437); r_; });
      V v_cell_2445 = heff_tag_at_n(v_ru_24x4_242_24PLet, TAG_JSeq, 3, (V[]){v_field_2442, heff_get_n(v_t_2444, 0, 2), heff_hole()});
      V v_u_2446 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(v_field_2443, v_ind_241, v_c_2438, heff_dup(v_cell_2445), MK_INT(2LL)));
      heff_drop(v_u_2446);
      return v_cell_2445;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str2, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str9, 13, ".$ === \"True\"");
Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_entry, 5, 0};

V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(V v_env_240, V v_ind_241, V v_x4_242, V v_d_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_PTrue: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return heff_setField(v_d_243, v_i_244, NTAG(TAG_JTrue));
  }
  case TAG_PFalse: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return heff_setField(v_d_243, v_i_244, NTAG(TAG_JFalse));
  }
  case TAG_PRel: {
    V v_p_245 = heff_field(v_x4_242, 0);
    V v_a_246 = heff_field(v_x4_242, 1);
    V v_b_247 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_c_248 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_a_246; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_246); r_; });
    V v_prec_249 = heff_take_field(v_c_248, 1);
    V v_code_2410 = heff_get_n(v_c_248, 0, 2);
    V v_t_2411;
    if (heff_intLt_c(v_prec_249, MK_INT(2LL))) {
      v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str0), v_code_2410), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str1));
    } else {
      v_t_2411 = v_code_2410;
    }
    HeffT2 v_t_2412 = ({ V a_0 = v_p_245; HeffT2 r_ = (g_heff_2ecompile_2eemit_2eprimRel_24cpr(a_0)); heff_drop(v_p_245); r_; });
    V v_t_2416;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2414;
        v_t_2416 = v_x_2415;
      } else {
        heff_drop(v_field_2414);
        v_t_2416 = ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str2);
      }
    }
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str3)), v_t_2416);
    V v_c_2418 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_b_247; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_b_247); r_; });
    V v_prec_2419 = heff_take_field(v_c_2418, 1);
    V v_code_2420 = heff_get_n(v_c_2418, 0, 2);
    V v_t_2421;
    if (heff_intLt_c(v_prec_2419, MK_INT(2LL))) {
      v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str4), v_code_2420), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str5));
    } else {
      v_t_2421 = v_code_2420;
    }
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str6)), v_t_2421);
    return heff_setField(v_d_243, v_i_244, heff_tag_n(TAG_JRel, 1, (V[]){v_t_2422}));
  }
  case TAG_PBool: {
    V v_v_2423 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_c_2424 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2423; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2423); r_; });
    V v_prec_2425 = heff_take_field(v_c_2424, 1);
    V v_code_2426 = heff_get_n(v_c_2424, 0, 2);
    V v_t_2427;
    if (heff_intLt_c(v_prec_2425, MK_INT(3LL))) {
      v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str7), v_code_2426), ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str8));
    } else {
      v_t_2427 = v_code_2426;
    }
    V v_t_2428 = heff_tag_at_n(v_ru_24x4_242_24PBool, TAG_JRel, 1, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_str9))});
    return heff_setField(v_d_243, v_i_244, v_t_2428);
  }
  case TAG_PNot: {
    V v_c_2429 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24PNot = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_cell_2430 = heff_tag_at_n(v_ru_24x4_242_24PNot, TAG_JNot, 1, (V[]){heff_hole()});
    V v_u_2431 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2430));
    heff_drop(v_u_2431);
    V t_0 = v_env_240;
    V t_1 = v_ind_241;
    V t_2 = v_c_2429;
    V t_3 = v_cell_2430;
    V t_4 = MK_INT(0LL);
    v_env_240 = t_0;
    v_ind_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2432 = heff_field(v_x4_242, 0);
    V v_b_2433 = heff_field(v_x4_242, 1);
    V v_c_2434 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2435 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_a_2432));
    V v_t_2436 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), v_b_2433));
    V v_cell_2437 = heff_tag_at_n(v_ru_24x4_242_24PIf, TAG_JIf, 3, (V[]){v_t_2435, v_t_2436, heff_hole()});
    V v_u_2438 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2437));
    heff_drop(v_u_2438);
    V t_0 = v_env_240;
    V t_1 = v_ind_241;
    V t_2 = v_c_2434;
    V t_3 = v_cell_2437;
    V t_4 = MK_INT(2LL);
    v_env_240 = t_0;
    v_ind_241 = t_1;
    v_x4_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_PLet: {
    V v_x_2439 = heff_field(v_x4_242, 0);
    V v_o_2440 = heff_field(v_x4_242, 1);
    V v_c_2441 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24PLet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2442 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2439), MK_INT(0LL)));
    V v_t_2443 = (g_heff_2ecompile_2eemit_2esafe(v_t_2442));
    HeffT2 v_t_2444 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(heff_dup(v_env_240), v_x_2439, v_t_2443, MK_INT(0LL)));
    {
      V v_field_2445 = v_t_2444.f[0];
      V v_field_2446 = v_t_2444.f[1];
      V v_t_2447 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_o_2440; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_2440); r_; });
      V v_cell_2448 = heff_tag_at_n(v_ru_24x4_242_24PLet, TAG_JSeq, 3, (V[]){v_field_2445, heff_get_n(v_t_2447, 0, 2), heff_hole()});
      V v_u_2449 = heff_setField(v_d_243, v_i_244, heff_dup(v_cell_2448));
      heff_drop(v_u_2449);
      V t_0 = v_field_2446;
      V t_1 = v_ind_241;
      V t_2 = v_c_2441;
      V t_3 = v_cell_2448;
      V t_4 = MK_INT(2LL);
      v_env_240 = t_0;
      v_ind_241 = t_1;
      v_x4_242 = t_2;
      v_d_243 = t_3;
      v_i_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str1, 7, "$force(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str3, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str5, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str6, 7, "$force(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str8, 10, "$abandon()");
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_x4_242, 0);
    HEFF_LAST return g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_243);
  }
  case TAG_OCall: {
    V v_g_244 = heff_field(v_x4_242, 0);
    V v_args_245 = heff_field(v_x4_242, 1);
    V v_t_2435;
    switch (heff_tag_of(v_args_245)) {
    case TAG_Nil: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_246 = heff_field(v_args_245, 0);
      V v_x12_247 = heff_field(v_args_245, 1);
      switch (heff_tag_of(v_x11_246)) {
      case TAG_SVar: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2420 = heff_field(v_x11_246, 0);
        V v_x112_2421 = heff_field(v_x11_246, 1);
        switch (heff_tag_of(v_x112_2421)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_247)) {
          case TAG_Nil: {
            v_t_2435 = heff_bool(heff_strEq_c_lent(v_t_2420, ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str0), 2));
            break;
          }
          case TAG_Cons: {
            v_t_2435 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_247);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2435 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2421);
        }
        break;
      }
      case TAG_SRec: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_246);
      }
      break;
    }
    default: heff_nomatch(v_args_245);
    }
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_ind_241);
      heff_drop(v_t_2435);
      HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_env_240, 0, 5); V a_1 = v_g_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2440;
      {
        V v_field_2438 = v_t_2436.f[1];
        int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
        if ((v_tag_2437 == ((int64_t)0ULL))) {
          V v_i_2439 = v_field_2438;
          v_t_2440 = heff_get_n(v_i_2439, 0, 4);
        } else {
          heff_drop(v_field_2438);
          v_t_2440 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_g_244)));
        }
      }
      V v_code_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str1), v_t_2440), ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str2));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2441, MK_INT(3LL)});
    } else {
      heff_drop(v_t_2435);
      HeffT2 v_t_2442 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_240, 0), v_g_244));
      V v_code_2449;
      {
        V v_field_2444 = v_t_2442.f[1];
        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
        if ((v_tag_2443 == ((int64_t)0ULL))) {
          V v_i_2445 = v_field_2444;
          V v_c_2446 = (g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(v_env_240, v_ind_241, heff_dup(v_g_244), heff_dup(v_args_245)));
          V v_t_2447 = heff_get_n(v_i_2445, 3, 4);
          if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
            heff_drop(v_t_2447);
            v_code_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str3), v_c_2446), ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str4));
          } else {
            heff_drop(v_t_2447);
            v_code_2449 = v_c_2446;
          }
        } else {
          heff_drop(v_field_2444);
          V v_c_2448 = (g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(v_env_240, v_ind_241, heff_dup(v_g_244), heff_dup(v_args_245)));
          v_code_2449 = v_c_2448;
        }
      }
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2449, MK_INT(3LL)});
    }
  }
  case TAG_OApply: {
    V v_f_2450 = heff_field(v_x4_242, 0);
    V v_args_2451 = heff_field(v_x4_242, 1);
    V v_t_2481;
    switch (heff_tag_of(v_args_2451)) {
    case TAG_Nil: {
      v_t_2481 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2452 = heff_field(v_args_2451, 0);
      V v_x12_2453 = heff_field(v_args_2451, 1);
      switch (heff_tag_of(v_x11_2452)) {
      case TAG_SVar: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2466 = heff_field(v_x11_2452, 0);
        V v_x112_2467 = heff_field(v_x11_2452, 1);
        switch (heff_tag_of(v_x112_2467)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2453)) {
          case TAG_Nil: {
            v_t_2481 = heff_bool(heff_strEq_c_lent(v_t_2466, ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str5), 2));
            break;
          }
          case TAG_Cons: {
            v_t_2481 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2453);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2481 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2467);
        }
        break;
      }
      case TAG_SRec: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2481 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2452);
      }
      break;
    }
    default: heff_nomatch(v_args_2451);
    }
    if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
      heff_drop(v_t_2481);
      V v_t_2482 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_f_2450));
      V v_t_2483 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str6), heff_get_n(v_t_2482, 0, 2));
      V v_code_2484 = heff_strAppend(v_t_2483, ((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str7));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2484, MK_INT(3LL)});
    } else {
      heff_drop(v_t_2481);
      V v_t_2485 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(heff_dup(v_env_240), heff_dup(v_ind_241), v_f_2450));
      return (g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(v_env_240, v_ind_241, v_t_2485, v_args_2451));
    }
  }
  case TAG_OPrim: {
    V v_p_2486 = heff_field(v_x4_242, 0);
    V v_args_2487 = heff_field(v_x4_242, 1);
    V v_t_2489 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_args_2487)));
    return (g_heff_2ecompile_2eemit_2eprimCall(v_p_2486, v_t_2489));
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_str8), MK_INT(3LL)});
  }
  case TAG_OBool: {
    V v_c_2490 = heff_field(v_x4_242, 0);
    V v_t_2491 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(v_env_240, v_ind_241, heff_dup(v_c_2490)));
    return (g_heff_2ecompile_2eemit_2eboolCode(v_t_2491));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_lam0(V self, V *args) {
  V v_v_2488 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2488; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2488); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str0, 10, "$fromBytes");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str1, 286, "const $fromBytes = typeof Buffer === \"function\" \? (b) => (Buffer.isBuffer(b) \? b : Buffer.from(b)).toString(\"latin1\") : (b) => { const u = new Uint8Array(b); let s = \"\"; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return s; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str2, 8, "$toBytes");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str3, 132, "const $toBytes = typeof Buffer === \"function\" \? (s) => Buffer.from(s, \"latin1\") : (s) => Uint8Array.from(s, (c) => c.charCodeAt(0));");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str4, 7, "$fromJs");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str5, 345, "const $fromJs = typeof Buffer === \"function\" \? (t) => /^[\\x00-\\x7f]*$/.test(t) \? t : Buffer.from(t, \"utf8\").toString(\"latin1\") : (t) => { if (/^[\\x00-\\x7f]*$/.test(t)) return t; const b = new TextEncoder().encode(t); let s = \"\"; for (let i = 0; i < b.length; i += 8192) s += String.fromCharCode.apply(null, b.subarray(i, i + 8192)); return s; };");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str6, 5, "$toJs");
HEFF_LIT(g_heff_2ecompile_2eemit_2estrHelpers_str7, 262, "const $toJs = typeof Buffer === \"function\" \? (s) => /^[\\x00-\\x7f]*$/.test(s) \? s : Buffer.from(s, \"latin1\").toString(\"utf8\") : (s) => /^[\\x00-\\x7f]*$/.test(s) \? s : new TextDecoder(\"utf-8\", { ignoreBOM: true }).decode(Uint8Array.from(s, (c) => c.charCodeAt(0)));");

static V g_heff_2ecompile_2eemit_2estrHelpers_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2estrHelpers_st;
static V g_heff_2ecompile_2eemit_2estrHelpers_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str0), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str2), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str4), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str5)}), v_t_241});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str6), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str7)}), v_t_242});
}
V g_heff_2ecompile_2eemit_2estrHelpers_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2estrHelpers_st)) return g_heff_2ecompile_2eemit_2estrHelpers_val;
  return heff_global(&g_heff_2ecompile_2eemit_2estrHelpers_val, &g_heff_2ecompile_2eemit_2estrHelpers_st, g_heff_2ecompile_2eemit_2estrHelpers_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2etrampolineStr_str0, 206, "let $dep = 0; function $Bnc(f, a) { this.f = f; this.a = a; } const $trs = (r) => { do { $dep = 0; r = r.f(r.a); } while (r instanceof $Bnc); return r; }; const $tr = (r) => r instanceof $Bnc \? $trs(r) : r;");

static V g_heff_2ecompile_2eemit_2etrampolineStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2etrampolineStr_st;
static V g_heff_2ecompile_2eemit_2etrampolineStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2etrampolineStr_str0);
}
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2etrampolineStr_st)) return g_heff_2ecompile_2eemit_2etrampolineStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2etrampolineStr_val, &g_heff_2ecompile_2eemit_2etrampolineStr_st, g_heff_2ecompile_2eemit_2etrampolineStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2euncurryGo_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2euncurryGo_str1, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2euncurryGo_str2, 0, "");
Clo g_heff_2ecompile_2eemit_2euncurryGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2euncurryGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2euncurryGo(V v_ps_240, V v_s_241) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2euncurryGo_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
    V v_j_243 = heff_strFind(((V)&g_heff_2ecompile_2eemit_2euncurryGo_str1), v_t_242, MK_INT(0LL));
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
      return heff_rec_n(2, shape_params__body, (V[]){v_t_244, v_s_241});
    } else {
      V v_t_245 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
      V v_x_246 = heff_strSlice_lent(v_t_245, MK_INT(0LL), v_j_243, 3);
      if ((heff_strEq_c_lent(v_x_246, ((V)&g_heff_2ecompile_2eemit_2euncurryGo_str2), 2) ? 0 : ({ V v_t_2414 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_x_246))); int c_ = heff_strEq_c_lent(v_t_2414, v_x_246, 0); heff_drop(v_t_2414); c_; }))) {
        heff_drop(v_x_246);
        V v_t_247 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_t_247, MK_INT(0LL), v_j_243, 3), v_ps_240});
        V v_t_249 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength_lent(v_s_241, 0));
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength(v_s_241)) - ((int64_t)1ULL));
        V v_t_2411 = heff_strSlice(v_t_249, heff_intAdd(v_j_243, MK_INT(5LL)), heff_box_word(v_t_2410));
        V t_0 = v_t_248;
        V t_1 = v_t_2411;
        v_ps_240 = t_0;
        v_s_241 = t_1;
        goto top;
      } else {
        heff_drop(v_j_243);
        heff_drop(v_x_246);
        V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
        return heff_rec_n(2, shape_params__body, (V[]){v_t_2412, v_s_241});
      }
    }
  } else {
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
    return heff_rec_n(2, shape_params__body, (V[]){v_t_2413, v_s_241});
  }
}
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2euncurryGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovIndexGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprovIndexGo(V v_i_240, V v_md_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(v_md_241))) {
      return v_i_240;
    } else {
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_md_241;
      V t_2 = v_rest_244;
      v_i_240 = t_0;
      v_md_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eprovIndexGo(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eemit_2eprovsForGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprovsForGo_24dps(V v_available_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_md_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = ({ V a_0 = v_md_243; V a_1 = v_available_240; HeffT2 r_ = (g_heff_2ecompile_2eemit_2efindProv_24cpr(a_0, a_1)); heff_drop(v_md_243); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_p_248 = v_field_247;
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_p_248, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_available_240;
        V t_1 = v_rest_244;
        V t_2 = v_cell_249;
        v_available_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_247);
        V t_0 = v_available_240;
        V t_1 = v_rest_244;
        V t_2 = v_d_242;
        v_available_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprovsForGo_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str3, 16, "return ++$dep > ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str4, 3, "500");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str5, 12, " \? new $Bnc(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str7, 4, ") : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str9, 2, ");");
Clo g_heff_2ecompile_2eemit_2ebounceGive_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebounceGive_24tok2_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ebounceGive_24tok2(V v_tok_240, V v_ind_241, V v_f_242, V v_a_243) {
top: ;
  V v_pre_244 = heff_take_field(v_a_243, 1);
  V v_js_245 = heff_get_n(v_a_243, 0, 3);
  V v_pre_246 = heff_take_field(v_f_242, 1);
  V v_js_247 = heff_get_n(v_f_242, 0, 3);
  V v_x2_248 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str0)));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str3)), ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str4));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str5)), heff_dup(v_js_247));
  V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str6)), heff_dup(v_js_245));
  V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str7)), v_js_247);
  V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str8)), v_js_245);
  V v_t_2417 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_24tok2_str9)), NTAG(TAG_Nil)});
  V v_t_2418 = (g_prelude_2e_2b_2b(v_pre_244, v_t_2417));
  return (g_prelude_2e_2b_2b(v_pre_246, v_t_2418));
}
V g_heff_2ecompile_2eemit_2ebounceGive_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebounceGive_24tok2(a[0], a[1], a[2], a[3]);
}