// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_hash 9690581
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064(V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_clo;
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698(V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_clo;
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_clo;
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_get(void);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711(V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_clo;
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_clo;
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259(V, V, V);
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_clo;
HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V);
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422(V, V, V);
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
HeffT2 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_list_2efoldl_24s1788498486x1573409871(V, V, V);
V g_list_2efoldl_24s1788498486x1573409871_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1788498486x1573409871_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str2, 1, "1");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str3, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str4, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str5, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str6, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str7, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str8, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str9, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str11, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str13, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str14, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str15, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str16, 3, "): ");
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_entry, 3, 0};

V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422(V v_path_240, V v_v_241, V v_dir_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_dir_242, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str0), v_t_243), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str1), heff_dup(v_v_241)), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str3), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str5), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str7), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str8), v_t_249});
  return heff_clo_n(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam0, 2, 3, (V[]){v_t_2410, v_path_240, v_v_241});
}
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam1(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_ended_2426 = heff_take_field(v_x_2425, 0);
  V v_err_2427 = heff_get_n(v_x_2425, 2, 3);
  V v_t_2430;
  switch (heff_tag_of(v_ended_2426)) {
  case TAG_Exited: {
    V v_n_2428 = heff_field(v_ended_2426, 0);
    heff_take_n(v_ended_2426, 1ULL, 1);
    v_t_2430 = heff_bool(heff_intEq_c_lent(v_n_2428, MK_INT(0LL), 2));
    heff_drop(v_n_2428);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2426, 0ULL, 1);
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2426);
  }
  V v_x_2442;
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop(v_path_240);
    heff_drop(v_v_241);
    heff_drop(v_err_2427);
    heff_drop(v_t_2430);
    v_x_2442 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2430);
    V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str11), heff_dup(v_path_240)), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str12));
    V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, heff_dup(v_v_241)), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str13));
    V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_v_241), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str14));
    V v_t_2434 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
    V v_t_2435 = heff_strAppend(v_t_2433, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str15), v_t_2434));
    V v_s_2436 = v_err_2427;
    V v_t_2437 = (g_prelude_2eskipSpaces(v_s_2436, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2438 = (heff_unbox_word(heff_strLength_lent(v_s_2436, 0)) - ((int64_t)1ULL));
    V v_t_2439 = (g_prelude_2eskipSpaces(v_s_2436, heff_box_word(v_t_2438), MK_INT(-1LL)));
    V v_t_2440 = heff_strSlice(v_s_2436, v_t_2437, heff_intAdd(v_t_2439, MK_INT(1LL)));
    V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str16)), v_t_2440);
    v_x_2442 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
  }
  V f_ = v_k_2412;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2413 = heff_take_field(v_hd_2411, 1);
  V v_malg_2414 = heff_get_n(v_hd_2411, 2, 3);
  V v_t_2415 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str9), v_t_2410, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_str10), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam1_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(v_malg_2414, 1, (V[]){v_t_2423}));
  V f_ = v_bind_2413;
  args[0] = v_t_2424;
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_lam2, 1, 3, (V[]){v_path_240, v_v_241, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str0, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str4, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str5, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str6, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str7, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str8, 23, ": its commit is another");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str9, 24, ": its tag has been moved");
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_entry, 6, 0};

V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_require_246 = heff_take_field(v_root_241, 2);
  V v_replace_247 = heff_get_n(v_root_241, 3, 4);
  V v_t_248 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_244, v_require_246));
  V v_t_2414;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_replace_247);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 2);
    V v_t_2411 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_249, v_replace_247));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2412, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_c_2415 = (g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_lam0, 2, 6, (V[]){v_c_2415, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2442 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_d_2443 = heff_dup(heff_rfield(v_ps_240, 0));
    V v_st_2444 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2445 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_d_2443));
    V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_d_2442));
    V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
    V v_t_2448 = ({ V a_0 = v_st_2444; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2447); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_240, v_t_2448, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2416);
    V v_t_2420 = heff_strAppend(heff_strAppend(v_by_243, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str0)), v_path_244);
    V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str1)), v_v_245);
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str2)), v_why_2419);
    V f_ = v_k_2417;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2422});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2423 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2424 = (g_list_2ekeepIf_24s25507577x707942422(v_path_244, v_v_245, v_sums_242));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop(v_h_2423);
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      V v_t_2425 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
      V v_t_2426 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_240, v_t_2425, v_path_244));
      V f_ = v_t_2426;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      V v_s_2427 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 2);
      V v_want_2429 = heff_get_n(v_s_2427, 2, 3);
      if (heff_strEq_c_lent(v_h_2423, v_want_2429, 0)) {
        heff_drop(v_h_2423);
        heff_drop_cell(v_ru_24x_2418_24Right, 1);
        heff_drop(v_want_2429);
        V v_t_2430 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2431 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_240, v_t_2430, v_path_244));
        V f_ = v_t_2431;
        heff_room[0] = v_hd_2416;
        heff_room[1] = v_k_2417;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_2416);
        V v_t_2432 = heff_strAppend(heff_strAppend(v_path_244, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str3)), heff_dup(v_v_245));
        V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str4)), v_h_2423);
        V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str5)), v_want_2429);
        V v_t_2435 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str6); V a_1 = v_v_245; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str7), v_v_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_v_245); r_; });
        HeffT2 v_t_2436 = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(v_t_2435));
        V v_t_2440;
        {
          V v_field_2438 = v_t_2436.f[1];
          int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
          if ((v_tag_2437 == ((int64_t)0ULL))) {
            V v_x_2439 = v_field_2438;
            heff_drop(v_x_2439);
            v_t_2440 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str8);
          } else {
            heff_drop(v_field_2438);
            v_t_2440 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_str9);
          }
        }
        V v_x_2441 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2434, v_t_2440)});
        V f_ = v_k_2417;
        args[0] = v_x_2441;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_lam1, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2417, v_sums_242, v_ps_240, v_hd_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str4, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str5, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str7, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str8, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str11, 1, "\012");
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam2(V self, V *args); static Clo g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam2, 1, 0};
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_entry, 3, 0};

V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259(V v_path_240, V v_p_241, V v_p_242) {
top: ;
  V v_bind_243 = heff_take_field(v_p_241, 1);
  V v_malg_244 = heff_get_n(v_p_241, 2, 3);
  V v_t_246 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str0), heff_dup(v_path_240)), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(v_malg_244), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})}));
  return heff_tail(heff_dup(v_bind_243), 2, (V[]){v_t_248, heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam1, 1, 4, (V[]){v_path_240, v_malg_244, v_bind_243, v_p_242})});
}
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam0(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam2(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_ended_2425 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_err_2426 = heff_env(self)[2];
  V v_out_2427 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_t_2434;
  switch (heff_tag_of(v_ended_2425)) {
  case TAG_Exited: {
    V v_n_2432 = heff_field(v_ended_2425, 0);
    heff_take_n(v_ended_2425, 1ULL, 1);
    v_t_2434 = heff_bool(!heff_intEq_c_lent(v_n_2432, MK_INT(0LL), 2));
    heff_drop(v_n_2432);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2425, 0ULL, 1);
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2425);
  }
  V v_x_2446;
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_out_2427);
    heff_drop(v_t_2434);
    V v_t_2435 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str7), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str8), v_t_2435));
    V v_s_2437 = v_err_2426;
    V v_t_2438 = (g_prelude_2eskipSpaces(v_s_2437, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_s_2437, 0)) - ((int64_t)1ULL));
    V v_t_2440 = (g_prelude_2eskipSpaces(v_s_2437, heff_box_word(v_t_2439), MK_INT(-1LL)));
    V v_t_2441 = heff_strSlice(v_s_2437, v_t_2438, heff_intAdd(v_t_2440, MK_INT(1LL)));
    V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str9)), v_t_2441);
    v_x_2446 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2442});
  } else {
    heff_drop(v_err_2426);
    heff_drop(v_t_2434);
    V v_s_2443 = v_out_2427;
    V v_t_2444 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str10); V a_1 = v_s_2443; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str11), v_s_2443, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2443); r_; });
    V v_t_2445 = ({ V a_0 = v_path_240; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2444; V r_ = (g_list_2efoldl_24s1788498486x1573409871(a_0, a_1, a_2)); heff_drop(v_t_2444); r_; });
    v_x_2446 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2445});
  }
  V f_ = v_p_242;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_malg_244 = heff_env(self)[1];
  V v_bind_243 = heff_env(self)[2];
  V v_path_240 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_ended_2425 = heff_take_field(v_x_2424, 0);
  V v_err_2426 = heff_take_field(v_x_2424, 2);
  V v_out_2427 = heff_get_n(v_x_2424, 1, 3);
  V v_t_2428 = heff_tag_n(TAG_End, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(v_malg_244, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
  V f_ = v_bind_243;
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam4, 1, 5, (V[]){v_ended_2425, v_path_240, v_err_2426, v_out_2427, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_malg_244 = heff_env(self)[1];
  V v_bind_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str1), v_t_2410), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str3), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str4), v_t_2412});
  V v_t_2414 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str5), v_t_2413, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_str6), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(v_malg_244), 1, (V[]){v_t_2422}));
  V f_ = heff_dup(v_bind_243);
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259_lam3, 1, 5, (V[]){v_x_249, v_malg_244, v_bind_243, v_path_240, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str1, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str3, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str7, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str8, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str9, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str10, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str11, 1, "\012");
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam15(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam16(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam3(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_entry, 1, 0};

V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711(V v_spec_240) {
top: ;
  V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str0)));
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_241); r_; });
  V v_a_244 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam0_clo)});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_c_2417 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam3, 2, 2, (V[]){v_c_2417, v_spec_240});
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711(a[0]);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2412 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2412})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2413));
  }
  case TAG_Right: {
    V v_x_2414 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam2, 2, 1, (V[]){v_x_2414});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2418, v_k_2419));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2418, v_k_2419));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam7(V self, V *args) {
  V v_x_2458 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2458);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2418, v_k_2419));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam8(V self, V *args) {
  V v_x_2476 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2476);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2418, v_k_2419));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam12(V self, V *args) {
  V v_x_2494 = args[0];
  V v_k_2493 = heff_env(self)[0];
  V v_x_2480 = heff_env(self)[1];
  V v_path_2491 = heff_env(self)[2];
  V v_hd_2492 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2494)) {
  case TAG_Left: {
    V v_why_2495 = heff_field(v_x_2494, 0);
    heff_take_n(v_x_2494, 1ULL, 1);
    heff_drop(v_x_2480);
    heff_drop(v_path_2491);
    heff_drop(v_hd_2492);
    V f_ = v_k_2493;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_2495});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_it1_2496 = heff_field(v_x_2494, 0);
    heff_take_n(v_x_2494, 1ULL, 1);
    switch (heff_tag_of(v_it1_2496)) {
    case TAG_Nothing: {
      V v_t_2497 = (g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064(v_x_2480, v_path_2491, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str7)));
      V f_ = v_t_2497;
      heff_room[0] = v_hd_2492;
      heff_room[1] = v_k_2493;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_v_2498 = heff_field(v_it1_2496, 0);
      heff_take_n(v_it1_2496, 1ULL, 1);
      heff_drop(v_x_2480);
      heff_drop(v_path_2491);
      heff_drop(v_hd_2492);
      V f_ = v_k_2493;
      args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_2498});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_it1_2496);
    }
  }
  default: return heff_nomatch(v_x_2494);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam11(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_path_2491 = heff_env(self)[0];
  V v_x_2480 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2efetch_2enewestTag_24s346852544x1869820259(heff_dup(v_path_2491), heff_dup(v_hd_2492), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam12, 1, 4, (V[]){v_k_2493, v_x_2480, v_path_2491, v_hd_2492})));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam13(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_rev_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24111);
  V f_ = v_k_24112;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_rev_2499});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam15(V self, V *args) {
  V v_x_24127 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24127);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2418, v_k_2419));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam16(V self, V *args) {
  V v_x_24136 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_24136) == NTAG(TAG_True))) {
    heff_drop(v_x_24136);
    V f_ = heff_dup(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_get());
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24136);
    heff_drop_rec(v_hd_2418, 3);
    V f_ = v_k_2419;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam14(V self, V *args) {
  V v_x_24116 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  V v_s_2460 = heff_env(self)[2];
  V v_x_2480 = heff_env(self)[3];
  V v_y_2431 = heff_env(self)[4];
  V v_pk_2459 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_24116)) {
  case TAG_Left: {
    V v_why_24117 = heff_field(v_x_24116, 0);
    V v_ru_24x_24116_24Left = heff_take_reuse_n(v_x_24116, 1ULL, 1);
    heff_drop(v_s_2460);
    heff_drop(v_x_2480);
    heff_drop(v_y_2431);
    heff_drop(v_pk_2459);
    V v_t_24118 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str10), v_why_24117), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str11));
    V v_t_24119 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24118, NTAG(TAG_MkUnit)});
    V v_t_24120 = heff_tag_at_n(v_ru_24x_24116_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2418, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24125})}));
    V f_ = heff_dup(heff_rfield(v_hd_2418, 1));
    heff_room[0] = v_t_24126;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam15, 1, 2, (V[]){v_hd_2418, v_k_2419});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ver_24128 = heff_field(v_x_24116, 0);
    heff_take_n(v_x_24116, 1ULL, 1);
    HeffT2 v_t_24129 = (g_heff_2ebuild_2efetch_2especOf_24cpr(v_s_2460));
    V v_t_24134;
    {
      V v_field_24130 = v_t_24129.f[0];
      V v_field_24131 = v_t_24129.f[1];
      V v_x_24132 = v_field_24130;
      V v_y_24133 = v_field_24131;
      heff_drop(v_y_24133);
      v_t_24134 = v_x_24132;
    }
    V v_c_24135 = (g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532(v_x_2480, v_y_2431, v_pk_2459, v_t_24134, v_ver_24128));
    V f_ = v_c_24135;
    heff_room[0] = heff_dup(v_hd_2418);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam16, 1, 2, (V[]){v_hd_2418, v_k_2419});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24116);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam10(V self, V *args) {
  V v_x_2480 = args[0];
  V v_s_2460 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  V v_y_2431 = heff_env(self)[3];
  V v_pk_2459 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2481 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2460)));
  {
    V v_field_2482 = v_t_2481.f[0];
    V v_field_2483 = v_t_2481.f[1];
    V v_x_2484 = v_field_2482;
    heff_drop(v_x_2484);
    V v_y_2485 = v_field_2483;
    V v_c_24115;
    switch (heff_tag_of(v_y_2485)) {
    case TAG_Nothing: {
      HeffT2 v_t_2486 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2460)));
      {
        V v_field_2487 = v_t_2486.f[0];
        V v_field_2488 = v_t_2486.f[1];
        V v_x_2489 = v_field_2487;
        V v_y_2490 = v_field_2488;
        heff_drop(v_y_2490);
        V v_path_2491 = v_x_2489;
        v_c_24115 = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam11, 2, 2, (V[]){v_path_2491, heff_dup(v_x_2480)});
      }
      break;
    }
    case TAG_Just: {
      V v_rev_2499 = heff_field(v_y_2485, 0);
      heff_take_n(v_y_2485, 1ULL, 1);
      HeffT2 v_t_24100 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2460)));
      {
        V v_field_24101 = v_t_24100.f[0];
        V v_field_24102 = v_t_24100.f[1];
        V v_t_24103 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str8); V a_1 = v_rev_2499; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str9), v_rev_2499, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_24104 = (g_heff_2ebuild_2eproject_2epseudoParts(v_t_24103));
        HeffT2 v_t_24105 = ({ V a_0 = v_rev_2499; V a_1 = v_t_24104; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_24104); r_; });
        V v_t_24110;
        {
          V v_field_24106 = v_t_24105.f[0];
          V v_field_24107 = v_t_24105.f[1];
          V v_x_24108 = v_field_24106;
          V v_y_24109 = v_field_24107;
          heff_drop(v_y_24109);
          v_t_24110 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24108; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24108); r_; });
        }
        if (heff_intEq_c(v_t_24110, MK_INT(3LL))) {
          heff_drop(v_field_24101);
          heff_drop(v_field_24102);
          v_c_24115 = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam13, 2, 1, (V[]){v_rev_2499});
        } else {
          V v_x_24113 = v_field_24101;
          V v_y_24114 = v_field_24102;
          heff_drop(v_y_24114);
          v_c_24115 = (g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064(heff_dup(v_x_2480), v_x_24113, v_rev_2499));
        }
      }
      break;
    }
    default: heff_nomatch(v_y_2485);
    }
    V f_ = v_c_24115;
    heff_room[0] = heff_dup(v_hd_2418);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam14, 1, 6, (V[]){v_hd_2418, v_k_2419, v_s_2460, v_x_2480, v_y_2431, v_pk_2459});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam9(V self, V *args) {
  V v_x_2478 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_s_2460 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  V v_y_2431 = heff_env(self)[3];
  V v_pk_2459 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2479 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_x_2478, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str6)));
  V f_ = v_c_2479;
  heff_room[0] = heff_dup(v_hd_2418);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam10, 1, 5, (V[]){v_s_2460, v_hd_2418, v_k_2419, v_y_2431, v_pk_2459});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  V v_spec_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 0ULL, 1);
    heff_drop(v_spec_240);
    V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str1), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2418, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
    V f_ = heff_dup(heff_rfield(v_hd_2418, 1));
    heff_room[0] = v_t_2429;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam5, 1, 2, (V[]){v_hd_2418, v_k_2419});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    HeffT2 v_t_2432 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_y_2431)));
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((v_tag_2433 == ((int64_t)0ULL))) {
        heff_drop(v_spec_240);
        heff_drop(v_y_2431);
        V v_p_2435 = v_field_2434;
        heff_drop(v_p_2435);
        V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str2), NTAG(TAG_MkUnit)});
        V v_t_2437 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
        V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
        V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
        V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
        V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2418, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})}));
        V f_ = heff_dup(heff_rfield(v_hd_2418, 1));
        heff_room[0] = v_t_2443;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam6, 1, 2, (V[]){v_hd_2418, v_k_2419});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        V v_x_2445 = v_field_2434;
        HeffT2 v_t_2446 = ({ V a_0 = v_x_2445; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2445); r_; });
        {
          V v_field_2448 = v_t_2446.f[1];
          int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
          if ((v_tag_2447 == ((int64_t)0ULL))) {
            heff_drop(v_spec_240);
            heff_drop(v_y_2431);
            V v_x_2449 = v_field_2448;
            heff_drop(v_x_2449);
            V v_t_2450 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str3), NTAG(TAG_MkUnit)});
            V v_t_2451 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
            V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
            V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
            V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
            V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
            V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
            V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2418, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})}));
            V f_ = heff_dup(heff_rfield(v_hd_2418, 1));
            heff_room[0] = v_t_2457;
            heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam7, 1, 2, (V[]){v_hd_2418, v_k_2419});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            V v_pk_2459 = v_field_2448;
            switch (heff_tag_of(v_spec_240)) {
            case TAG_Nothing: {
              heff_drop(v_y_2431);
              heff_drop_cell(v_ru_24x_2420_24Right, 1);
              heff_drop(v_pk_2459);
              V f_ = heff_dup(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_get());
              heff_room[0] = v_hd_2418;
              heff_room[1] = v_k_2419;
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
            case TAG_Just: {
              V v_s_2460 = heff_field(v_spec_240, 0);
              V v_ru_24spec_240_24Just = heff_take_reuse_n(v_spec_240, 1ULL, 1);
              HeffT2 v_t_2461 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2460)));
              V v_t_2466;
              {
                V v_field_2462 = v_t_2461.f[0];
                V v_field_2463 = v_t_2461.f[1];
                V v_x_2464 = v_field_2462;
                V v_y_2465 = v_field_2463;
                heff_drop(v_y_2465);
                v_t_2466 = v_x_2464;
              }
              if (heff_strEq_c(v_t_2466, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                heff_drop(v_y_2431);
                heff_drop(v_pk_2459);
                heff_drop(v_s_2460);
                V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str4), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_str5));
                V v_t_2468 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2467, NTAG(TAG_MkUnit)});
                V v_t_2469 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24spec_240_24Just, TAG_InL, 1, (V[]){v_t_2468})});
                V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
                V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
                V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
                V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
                V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
                V v_t_2475 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2418, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})}));
                V f_ = heff_dup(heff_rfield(v_hd_2418, 1));
                heff_room[0] = v_t_2475;
                heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam8, 1, 2, (V[]){v_hd_2418, v_k_2419});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                heff_drop_cell(v_ru_24x_2420_24Right, 1);
                heff_drop_cell(v_ru_24spec_240_24Just, 1);
                V v_c_2477 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
                V f_ = v_c_2477;
                heff_room[0] = heff_dup(v_hd_2418);
                heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam9, 1, 5, (V[]){v_hd_2418, v_s_2460, v_k_2419, v_y_2431, v_pk_2459});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
            default: return heff_nomatch(v_spec_240);
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_spec_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1144315391x707605711_lam4, 1, 3, (V[]){v_hd_2418, v_k_2419, v_spec_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}