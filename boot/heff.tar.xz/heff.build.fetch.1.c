// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_hash 9690581
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383(V, V, V);
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_clo;
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520(V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_clo;
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012(V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_clo;
V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_clo;
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262(V, V, V);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_clo;
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271(V, V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_clo;
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_clo;
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368(V, V, V, V);
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_clo;
V g_heff_2ebuild_2efetch_2erevSaid(V);
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2erevSaid_clo;
HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V);
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906(V, V, V, V);
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V, V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(V, V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053(V, V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_clo;
V g_heff_2ebuild_2eload_2eversionsGo(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisMajorPart(V);
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo;
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
HeffT3 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24s2098427539x1767581560(V, V, V, V);
V g_list_2emap_24s2098427539x1767581560_entry(V self, V *a);
extern Clo g_list_2emap_24s2098427539x1767581560_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2esortOn_24s1704298248x384812646(V, V, V, V, V, V, V);
V g_list_2esortOn_24s1704298248x384812646_entry(V self, V *a);
extern Clo g_list_2esortOn_24s1704298248x384812646_clo;
V g_prelude_2einstanceOrderPair_24s566030815x71064266_get(void);
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str0, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str2, 9, " (commit ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str4, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str5, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str7, 13, "--no-checkout");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str8, 18, "--filter=blob:none");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str9, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str10, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str11, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str16, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str17, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str19, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str20, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str21, 8, "--detach");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str22, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str23, 8, "checkout");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str24, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str25, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str26, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str30, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str31, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str32, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str33, 14, "no such commit");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str34, 17, "the commit is of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str35, 6, ", not ");
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam3, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_entry, 6, 0};

V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039(V v_e_240, V v_path_241, V v_v_242, V v_time_243, V v_hash_244, V v_dir_245) {
top: ;
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str0), heff_dup(v_path_241)), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str1));
  V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, v_v_242), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str2));
  V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, heff_dup(v_hash_244)), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str3));
  V v_t_249 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_2410 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str4), v_t_249));
  V v_x_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str5));
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam0, 2, 6, (V[]){v_path_241, v_dir_245, v_e_240, v_x_2411, v_hash_244, v_time_243});
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam1(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam3(V self, V *args) {
  V v_r_2456 = args[0];
  return v_r_2456;
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam5(V self, V *args) {
  V v_x_2468 = args[0];
  V v_ended_2465 = heff_env(self)[0];
  V v_err_2466 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_time_243 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2472;
  switch (heff_tag_of(v_ended_2465)) {
  case TAG_Exited: {
    V v_n_2469 = heff_dup(heff_field(v_ended_2465, 0));
    v_t_2472 = heff_bool(!heff_intEq_c_lent(v_n_2469, MK_INT(0LL), 2));
    heff_drop(v_n_2469);
    break;
  }
  case TAG_Signalled: {
    v_t_2472 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2472 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2472 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2465);
  }
  V v_x_2492;
  if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
    heff_drop(v_x_2468);
    heff_drop(v_time_243);
    heff_drop(v_t_2472);
    V v_t_2481;
    switch (heff_tag_of(v_ended_2465)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2465, 0ULL, 1);
      v_t_2481 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str27);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2465, 0ULL, 1);
      v_t_2481 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str28);
      break;
    }
    case TAG_TimedOut: {
      v_t_2481 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str29);
      break;
    }
    case TAG_NotRun: {
      V v_err_2475 = heff_field(v_ended_2465, 0);
      heff_take_n(v_ended_2465, 1ULL, 1);
      V v_path_2476 = heff_take_field(v_err_2475, 3);
      V v_name_2477 = heff_take_field(v_err_2475, 1);
      V v_message_2478 = heff_get_n(v_err_2475, 2, 4);
      V v_t_2479 = heff_strAppend(heff_strAppend(v_path_2476, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str30)), v_name_2477);
      V v_t_2480 = heff_strAppend(heff_strAppend(v_t_2479, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str31)), v_message_2478);
      v_t_2481 = heff_strAppend(v_t_2480, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str32));
      break;
    }
    default: heff_nomatch(v_ended_2465);
    }
    V v_s_2482 = heff_strAppend(v_t_2481, v_err_2466);
    V v_t_2483 = (g_prelude_2eskipSpaces(v_s_2482, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2484 = (heff_unbox_word(heff_strLength_lent(v_s_2482, 0)) - ((int64_t)1ULL));
    V v_t_2485 = (g_prelude_2eskipSpaces(v_s_2482, heff_box_word(v_t_2484), MK_INT(-1LL)));
    V v_t_2486 = heff_strSlice(v_s_2482, v_t_2483, heff_intAdd(v_t_2485, MK_INT(1LL)));
    v_x_2492 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2411, v_t_2486)});
  } else {
    heff_drop(v_ended_2465);
    heff_drop(v_err_2466);
    heff_drop(v_t_2472);
    switch (heff_tag_of(v_x_2468)) {
    case TAG_Nothing: {
      heff_drop(v_time_243);
      v_x_2492 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2411, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str33))});
      break;
    }
    case TAG_Just: {
      V v_it1_2487 = heff_field(v_x_2468, 0);
      V v_ru_24x_2468_24Just = heff_take_reuse_n(v_x_2468, 1ULL, 1);
      switch (heff_tag_of(v_it1_2487)) {
      case TAG_MkPair: {
        V v_t_2488 = heff_field(v_it1_2487, 0);
        heff_take_n(v_it1_2487, 1ULL, 2);
        if (heff_strEq_c_lent(v_t_2488, v_time_243, 0)) {
          heff_drop(v_x_2411);
          heff_drop(v_time_243);
          heff_drop_cell(v_ru_24x_2468_24Just, 1);
          heff_drop(v_t_2488);
          v_x_2492 = NTAG(TAG_Nothing);
        } else {
          V v_t_2490 = heff_strAppend(heff_strAppend(v_x_2411, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str34)), v_t_2488);
          V v_t_2491 = heff_strAppend(heff_strAppend(v_t_2490, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str35)), v_time_243);
          v_x_2492 = heff_tag_at_n(v_ru_24x_2468_24Just, TAG_Just, 1, (V[]){v_t_2491});
        }
        break;
      }
      default: heff_nomatch(v_it1_2487);
      }
      break;
    }
    default: heff_nomatch(v_x_2468);
    }
  }
  V f_ = v_k_2413;
  args[0] = v_x_2492;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam4(V self, V *args) {
  V v_x_2464 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_time_243 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_ended_2465 = heff_take_field(v_x_2464, 0);
  V v_err_2466 = heff_get_n(v_x_2464, 2, 3);
  V v_c_2467 = (g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383(v_e_240, v_dir_245, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str26)));
  V f_ = v_c_2467;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam5, 1, 5, (V[]){v_ended_2465, v_err_2466, v_x_2411, v_time_243, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_dir_245 = heff_env(self)[2];
  V v_hash_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_time_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_ended_2429 = heff_take_field(v_x_2428, 0);
  V v_err_2430 = heff_get_n(v_x_2428, 2, 3);
  V v_t_2434;
  switch (heff_tag_of(v_ended_2429)) {
  case TAG_Exited: {
    V v_n_2431 = heff_dup(heff_field(v_ended_2429, 0));
    v_t_2434 = heff_bool(!heff_intEq_c_lent(v_n_2431, MK_INT(0LL), 2));
    heff_drop(v_n_2431);
    break;
  }
  case TAG_Signalled: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2429);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_dir_245);
    heff_drop(v_hash_244);
    heff_drop(v_e_240);
    heff_drop(v_hd_2412);
    heff_drop(v_time_243);
    heff_drop(v_t_2434);
    V v_t_2443;
    switch (heff_tag_of(v_ended_2429)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2429, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str13);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2429, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str14);
      break;
    }
    case TAG_TimedOut: {
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str15);
      break;
    }
    case TAG_NotRun: {
      V v_err_2437 = heff_field(v_ended_2429, 0);
      heff_take_n(v_ended_2429, 1ULL, 1);
      V v_path_2438 = heff_take_field(v_err_2437, 3);
      V v_name_2439 = heff_take_field(v_err_2437, 1);
      V v_message_2440 = heff_get_n(v_err_2437, 2, 4);
      V v_t_2441 = heff_strAppend(heff_strAppend(v_path_2438, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str16)), v_name_2439);
      V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str17)), v_message_2440);
      v_t_2443 = heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str18));
      break;
    }
    default: heff_nomatch(v_ended_2429);
    }
    V v_s_2444 = heff_strAppend(v_t_2443, v_err_2430);
    V v_t_2445 = (g_prelude_2eskipSpaces(v_s_2444, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2446 = (heff_unbox_word(heff_strLength_lent(v_s_2444, 0)) - ((int64_t)1ULL));
    V v_t_2447 = (g_prelude_2eskipSpaces(v_s_2444, heff_box_word(v_t_2446), MK_INT(-1LL)));
    V v_t_2448 = heff_strSlice(v_s_2444, v_t_2445, heff_intAdd(v_t_2447, MK_INT(1LL)));
    V v_x_2449 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2411, v_t_2448)});
    V f_ = v_k_2413;
    args[0] = v_x_2449;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_ended_2429);
    heff_drop(v_err_2430);
    heff_drop(v_t_2434);
    V v_t_2450 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_245)));
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_hash_244, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str19)), NTAG(TAG_Nil)});
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str20), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str21), v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str22), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str23), v_t_2452})});
    V v_t_2454 = ({ V a_0 = v_t_2450; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2450); r_; });
    V v_t_2455 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str24), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str25), v_t_2453}), v_t_2454, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2457 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2455, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam3_clo)});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam4, 1, 6, (V[]){v_e_240, v_dir_245, v_hd_2412, v_x_2411, v_time_243, v_k_2413})));
  }
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_path_241 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_hash_244 = heff_env(self)[4];
  V v_time_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_dir_245), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str6), v_t_2414), v_t_2415});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str8), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str10), v_t_2417})});
  V v_t_2419 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str11), v_t_2418, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_str12), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam1_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2427, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_lam2, 1, 7, (V[]){v_x_2411, v_k_2413, v_dir_245, v_hash_244, v_e_240, v_hd_2412, v_time_243})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str0, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str4, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str5, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str6, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str7, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str8, 23, ": its commit is another");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str9, 24, ": its tag has been moved");
V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_entry, 7, 0};

V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420(V v_e_240, V v_ps_241, V v_root_242, V v_sums_243, V v_by_244, V v_path_245, V v_v_246) {
top: ;
  V v_require_247 = heff_take_field(v_root_242, 2);
  V v_replace_248 = heff_get_n(v_root_242, 3, 4);
  V v_t_249 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_245, v_require_247));
  V v_t_2415;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    heff_drop(v_replace_248);
    v_t_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 2);
    V v_t_2412 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2410, v_replace_248));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nil: {
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 2);
      v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2413, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    V v_c_2416 = (g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_path_245), heff_dup(v_v_246)));
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_lam0, 2, 7, (V[]){v_c_2416, v_by_244, v_path_245, v_v_246, v_sums_243, v_ps_241, v_e_240});
  }
  case TAG_Just: {
    V v_d_2444 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    heff_drop(v_sums_243);
    heff_drop(v_by_244);
    heff_drop(v_v_246);
    V v_d_2445 = heff_dup(heff_rfield(v_ps_241, 0));
    V v_st_2446 = heff_dup(heff_rfield(v_ps_241, 5));
    V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2446), v_d_2445));
    V v_t_2448 = (g_std_2epath_2eparse(heff_dup(v_st_2446), v_d_2444));
    V v_t_2449 = (g_std_2epath_2ejoin(v_t_2447, v_t_2448));
    V v_t_2450 = ({ V a_0 = v_st_2446; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2446); heff_drop(v_t_2449); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(v_e_240, v_ps_241, v_t_2450, v_path_245));
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_by_244 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_v_246 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_hd_2417 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_why_2420 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_drop(v_sums_243);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_e_240);
    heff_drop(v_hd_2417);
    V v_t_2421 = heff_strAppend(heff_strAppend(v_by_244, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str0)), v_path_245);
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str1)), v_v_246);
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str2)), v_why_2420);
    V f_ = v_k_2418;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2423});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2424 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_drop(v_by_244);
    V v_t_2425 = (g_list_2ekeepIf_24s25507577x707942422(v_path_245, v_v_246, v_sums_243));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nil: {
      heff_drop(v_h_2424);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      V v_t_2426 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
      V v_t_2427 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(v_e_240, v_ps_241, v_t_2426, v_path_245));
      V f_ = v_t_2427;
      heff_room[0] = v_hd_2417;
      heff_room[1] = v_k_2418;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      V v_s_2428 = heff_field(v_t_2425, 0);
      V v_ru_24t_2425_24Cons = heff_take_reuse_n(v_t_2425, 1ULL, 2);
      V v_want_2430 = heff_get_n(v_s_2428, 2, 3);
      if (heff_strEq_c_lent(v_h_2424, v_want_2430, 0)) {
        heff_drop(v_h_2424);
        heff_drop_cell(v_ru_24x_2419_24Right, 1);
        heff_drop_cell(v_ru_24t_2425_24Cons, 2);
        heff_drop(v_want_2430);
        V v_t_2431 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
        V v_t_2432 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(v_e_240, v_ps_241, v_t_2431, v_path_245));
        V f_ = v_t_2432;
        heff_room[0] = v_hd_2417;
        heff_room[1] = v_k_2418;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_e_240);
        heff_drop(v_hd_2417);
        V v_t_2433 = heff_strAppend(heff_strAppend(v_path_245, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str3)), heff_dup(v_v_246));
        V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str4)), v_h_2424);
        V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str5)), v_want_2430);
        V v_t_2436 = ({ V a_0 = v_v_246; V b_1 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str7), v_v_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_v_246); heff_drop(b_1); r_; });
        HeffT3 v_t_2437 = ({ V a_0 = v_t_2436; HeffT3 r_ = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(a_0)); heff_drop(v_t_2436); r_; });
        V v_t_2442;
        {
          V v_field_2439 = v_t_2437.f[1];
          V v_field_2440 = v_t_2437.f[2];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            V v_x_2441 = heff_tag_at_n(v_ru_24t_2425_24Cons, TAG_MkPair, 2, (V[]){v_field_2439, v_field_2440});
            heff_drop_tag(v_x_2441, 2);
            v_t_2442 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str8);
          } else {
            heff_drop_cell(v_ru_24t_2425_24Cons, 2);
            heff_drop(v_field_2439);
            heff_drop(v_field_2440);
            v_t_2442 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_str9);
          }
        }
        V v_x_2443 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2435, v_t_2442)});
        V f_ = v_k_2418;
        args[0] = v_x_2443;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_by_244 = heff_env(self)[1];
  V v_path_245 = heff_env(self)[2];
  V v_v_246 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420_lam1, 1, 8, (V[]){v_by_244, v_path_245, v_v_246, v_k_2418, v_sums_243, v_ps_241, v_e_240, v_hd_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str3, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str4, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str5, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str8, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str9, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str10, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str13, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str18, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str19, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str20, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str22, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str23, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str24, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str27, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str28, 32, "heff get: cannot write heff.sum\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str29, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str30, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str31, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str32, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str33, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str35, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str36, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str37, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str40, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str41, 36, " packages, none fetched: no heff.sum");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str42, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str43, 1, "\012");
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam2(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam2, 3, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam11(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam11, 2, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam12(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam12, 3, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam17(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam20(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam19(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam18(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam16(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam15(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_entry, 3, 0};

V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(heff_dup(v_e_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam0, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam7(V self, V *args) {
  V v_x_2468 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2468);
  V v_t_2469 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam8(V self, V *args) {
  V v_by_2479 = args[0];
  V v_path_2480 = args[1];
  V v_v_2481 = args[2];
  V v_e_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_root_2456 = heff_env(self)[2];
  V v_sums_2476 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2efetch_2efetchedPkg_24s612234693x1397893420(v_e_240, v_x_245, v_root_2456, v_sums_2476, v_by_2479, v_path_2480, v_v_2481));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam11(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k_2495 = args[1];
  heff_drop(v_hd_2494);
  V f_ = v_k_2495;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam12(V self, V *args) {
  V v_x_24104 = args[0];
  V v_hd_24105 = args[1];
  V v_k_24106 = args[2];
  heff_drop(v_hd_24105);
  V f_ = v_k_24106;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24104});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam14(V self, V *args) {
  V v_x_24110 = args[0];
  V v_k_24109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24113;
  switch (heff_tag_of(v_x_24110)) {
  case TAG_Left: {
    heff_take_n(v_x_24110, 0ULL, 1);
    v_t_24113 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_24110, 0ULL, 1);
    v_t_24113 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_24110);
  }
  V f_ = v_k_24109;
  args[0] = v_t_24113;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam13(V self, V *args) {
  V v_hd_24108 = args[0];
  V v_k_24109 = args[1];
  V v_c_24107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24107;
  args[0] = v_hd_24108;
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam14, 1, 1, (V[]){v_k_24109});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam17(V self, V *args) {
  V v_x_24134 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24134);
  V v_t_24135 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})});
  V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
  V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
  V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
  V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
  V v_t_24141 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24140})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24141}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam20(V self, V *args) {
  V v_x_24155 = args[0];
  V v_seen_24153 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24155; V a_1 = v_seen_24153; V r_ = (g_list_2efoldl_24s1910320727x339655847(a_0, a_1)); heff_drop(v_seen_24153); r_; });
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam19(V self, V *args) {
  V v_x_24143 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2483 = heff_env(self)[3];
  V v_x_2488 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_intLt_c(MK_INT(0LL), v_x_24143)) {
    heff_drop(v_x_2483);
    heff_drop(v_x_2488);
    V v_t_24144 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
    V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
    V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
    V v_t_24150 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24149})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24150}), v_hd_241, v_k_242));
  } else {
    V v_seen_24153;
    switch (heff_tag_of(v_x_2483)) {
    case TAG_MkPair: {
      V v_x_24151 = heff_field(v_x_2483, 0);
      heff_take_n(v_x_2483, 1ULL, 2);
      v_seen_24153 = v_x_24151;
      break;
    }
    default: heff_nomatch(v_x_2483);
    }
    V v_t_24154 = (g_list_2efoldl_24s422700624x1171050237(NTAG(TAG_Nil), heff_dup(v_seen_24153)));
    V v_t_24156 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam20, 1, 1, (V[]){v_seen_24153}); V a_3 = v_t_24154; V r_ = (g_list_2efoldl_24f556306710x2087456230(a_0, a_1, a_2, a_3)); heff_drop(v_t_24154); r_; });
    V v_t_24157 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str31), heff_intShow(v_t_24156));
    V v_t_24158 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str32); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str33); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str34); V a_5 = heff_dup(g_prelude_2einstanceOrderPair_24s566030815x71064266_get()); V a_6 = v_x_2488; V r_ = (g_list_2esortOn_24s1704298248x384812646(b_0, a_1, b_2, b_3, b_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
    V v_x2_24159 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str35), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str36), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str37), v_t_24158));
    V v_t_24162;
    switch (heff_tag_of(v_x2_24159)) {
    case TAG_Nil: {
      v_t_24162 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str38);
      break;
    }
    case TAG_Cons: {
      V v_x_24160 = heff_field(v_x2_24159, 0);
      V v_xs_24161 = heff_field(v_x2_24159, 1);
      heff_take_n(v_x2_24159, 3ULL, 2);
      v_t_24162 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str39); V a_1 = v_x_24160; V a_2 = v_xs_24161; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24161); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24159);
    }
    V v_t_24163;
    if (heff_strEq_c(v_t_24162, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str40))) {
      v_t_24163 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str41);
    } else {
      v_t_24163 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str42);
    }
    V v_str_24164 = heff_strAppend(v_t_24157, v_t_24163);
    V v_t_24165 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24164, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str43)), NTAG(TAG_MkUnit)});
    V v_t_24166 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24165})});
    V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
    V v_t_24168 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24167})});
    V v_t_24169 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24168})});
    V v_t_24170 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24169})});
    V v_t_24171 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24170})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24171}), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam18(V self, V *args) {
  V v_x_24142 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2483 = heff_env(self)[3];
  V v_x_2488 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str30), heff_get_n(v_x_24142, 1, 5), MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam19, 1, 5, (V[]){v_e_240, v_hd_241, v_k_242, v_x_2483, v_x_2488})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam16(V self, V *args) {
  V v_x_24119 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_24115 = heff_env(self)[3];
  V v_x_2483 = heff_env(self)[4];
  V v_x_2488 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_intLt_c(MK_INT(0LL), v_x_24119)) {
    heff_drop(v_x_24115);
    heff_drop(v_x_2483);
    heff_drop(v_x_2488);
    V v_t_24120 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24125})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24126}), v_hd_241, v_k_242));
  } else {
    if (!(heff_dup(v_x_24115) == NTAG(TAG_True))) {
      heff_drop(v_x_24115);
      heff_drop(v_x_2483);
      heff_drop(v_x_2488);
      V v_t_24127 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str28), NTAG(TAG_MkUnit)});
      V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
      V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
      V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
      V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
      V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
      V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24132})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24133}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam17, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
    } else {
      heff_drop(v_x_24115);
      return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str29), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam18, 1, 5, (V[]){v_e_240, v_hd_241, v_k_242, v_x_2483, v_x_2488})));
    }
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam15(V self, V *args) {
  V v_x_24115 = args[0];
  V v_x_2483 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_x_2488 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24118;
  switch (heff_tag_of(v_x_2483)) {
  case TAG_MkPair: {
    V v_y_24117 = heff_dup(heff_field(v_x_2483, 1));
    v_t_24118 = v_y_24117;
    break;
  }
  default: heff_nomatch(v_x_2483);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str27), v_t_24118, MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam16, 1, 6, (V[]){v_e_240, v_hd_241, v_k_242, v_x_24115, v_x_2483, v_x_2488})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam10(V self, V *args) {
  V v_x_2488 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2483 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2489 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str9); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str10); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str11); V a_5 = heff_dup(g_prelude_2einstanceOrderPair_24s566030815x71064266_get()); V a_6 = heff_dup(v_x_2488); V r_ = (g_list_2esortOn_24s1704298248x384812646(b_0, a_1, b_2, b_3, b_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
  V v_x2_2490 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str12), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str13), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str14), v_t_2489));
  V v_t_2493;
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_Nil: {
    v_t_2493 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str15);
    break;
  }
  case TAG_Cons: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_xs_2492 = heff_field(v_x2_2490, 1);
    heff_take_n(v_x2_2490, 3ULL, 2);
    v_t_2493 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str16); V a_1 = v_x_2491; V a_2 = v_xs_2492; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2492); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2490);
  }
  V v_c_24114;
  if (heff_strEq_c(v_t_2493, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str17))) {
    v_c_24114 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam11_clo);
  } else {
    V v_path_2496 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str18)));
    V v_t_2497 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str19); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str20); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str21); V a_5 = heff_dup(g_prelude_2einstanceOrderPair_24s566030815x71064266_get()); V a_6 = heff_dup(v_x_2488); V r_ = (g_list_2esortOn_24s1704298248x384812646(b_0, a_1, b_2, b_3, b_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
    V v_x2_2498 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str22), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str23), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str24), v_t_2497));
    V v_text_24101;
    switch (heff_tag_of(v_x2_2498)) {
    case TAG_Nil: {
      v_text_24101 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2499 = heff_field(v_x2_2498, 0);
      V v_xs_24100 = heff_field(v_x2_2498, 1);
      heff_take_n(v_x2_2498, 3ULL, 2);
      v_text_24101 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str26); V a_1 = v_x_2499; V a_2 = v_xs_24100; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24100); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2498);
    }
    V v_c_24102 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2496; V a_2 = v_text_24101; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2496); r_; });
    V v_t_24103 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_24107 = heff_tr(heff_call(v_c_24102, 2, (V[]){v_t_24103, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam12_clo)}));
    v_c_24114 = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam13, 2, 1, (V[]){v_c_24107});
  }
  V f_ = v_c_24114;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam15, 1, 5, (V[]){v_x_2483, v_e_240, v_hd_241, v_k_242, v_x_2488});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam9(V self, V *args) {
  V v_x_2483 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_root_2456 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2486;
  switch (heff_tag_of(v_x_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_dup(heff_field(v_x_2483, 0));
    v_t_2486 = v_x_2484;
    break;
  }
  default: heff_nomatch(v_x_2483);
  }
  V v_c_2487 = (g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906(heff_dup(v_e_240), v_x_245, v_root_2456, v_t_2486));
  V f_ = v_c_2487;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam10, 1, 4, (V[]){v_e_240, v_hd_241, v_x_2483, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_root_2456 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Left: {
    V v_why_2459 = heff_field(v_x_2458, 0);
    V v_ru_24x_2458_24Left = heff_take_reuse_n(v_x_2458, 1ULL, 1);
    heff_drop_rec(v_root_2456, 4);
    heff_drop(v_x_245);
    V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str5), v_why_2459), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str6));
    V v_t_2461 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2460, NTAG(TAG_MkUnit)});
    V v_t_2462 = heff_tag_at_n(v_ru_24x_2458_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam7, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_sums_2476 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    V v_t_2477;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2456, 0)), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str7))) {
      v_t_2477 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str8);
    } else {
      v_t_2477 = heff_dup(heff_rfield(v_root_2456, 0));
    }
    V v_t_2478 = (g_list_2emap_24s675147852x248982264(v_t_2477, heff_dup(heff_rfield(v_root_2456, 2))));
    V v_c_2482 = (g_heff_2ebuild_2eload_2eversionsGo(v_e_240, heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam8, 3, 4, (V[]){heff_dup(v_e_240), heff_dup(v_x_245), heff_dup(v_root_2456), v_sums_2476}), heff_rfield(v_root_2456, 0), v_t_2478, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V f_ = v_c_2482;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam9, 1, 5, (V[]){v_e_240, v_x_245, v_root_2456, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2458);
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    v_t_2416 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str2);
    break;
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  HeffT2 v_t_2417 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_t_2416));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      heff_drop(v_x_245);
      V v_p_2420 = v_field_2419;
      heff_drop(v_p_2420);
      V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str3), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam4, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
    } else {
      V v_x_2436 = v_field_2419;
      HeffT2 v_t_2437 = ({ V a_0 = v_x_2436; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2436); r_; });
      {
        V v_field_2439 = v_t_2437.f[1];
        int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
        if ((v_tag_2438 == ((int64_t)0ULL))) {
          heff_drop(v_x_245);
          V v_x_2440 = v_field_2439;
          heff_drop(v_x_2440);
          V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str4), NTAG(TAG_MkUnit)});
          V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
          V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
          V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
          V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
          V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
          V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
          return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam5, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
        } else {
          V v_root_2456 = v_field_2439;
          V v_c_2457 = (g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053(heff_dup(v_e_240), heff_dup(v_x_245)));
          V f_ = v_c_2457;
          heff_room[0] = heff_dup(v_hd_241);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam6, 1, 5, (V[]){v_e_240, v_hd_241, v_k_242, v_root_2456, v_x_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    }
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str1)));
  V v_c_247 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_246; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_246); r_; });
  V v_t_248 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2412 = heff_tr(heff_call(v_c_247, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam2_clo)}));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam3, 1, 4, (V[]){v_e_240, v_hd_241, v_k_242, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_244 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), v_x_243, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_str0)));
  V f_ = v_c_244;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str0, 7, "commits");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str1, 12, "finding the ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str4, 6, "--bare");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str5, 15, "--filter=tree:0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str6, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str8, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str10, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str11, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str12, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str13, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str14, 27, "cannot list the commits of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str15, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str19, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str22, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str23, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str24, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str25, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str26, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str27, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str28, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str29, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str30, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str31, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str32, 1, "0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str33, 5, ".0.0-");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str34, 1, "-");
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam1, 3, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam3, 3, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam5(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam5, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam7(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam7, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam9(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam9, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam10(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam10, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam11(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam11, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam12(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam12, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam14(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam14, 3, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam16(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam15(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_entry, 4, 0};

V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520(V v_e_240, V v_ps_241, V v_path_242, V v_rev_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str0)));
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam0, 2, 5, (V[]){v_x_244, v_e_240, v_ps_241, v_rev_243, v_path_242});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2432 = args[1];
  V v_k_2433 = args[2];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam5(V self, V *args) {
  V v_t_2439 = args[0];
  return v_t_2439;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam7(V self, V *args) {
  V v_r_2449 = args[0];
  return v_r_2449;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam9(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam10(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  heff_drop(v_hd_2468);
  V f_ = v_k_2469;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam11(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  heff_drop(v_hd_2470);
  V f_ = v_k_2471;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam12(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  heff_drop(v_hd_2473);
  V f_ = v_k_2474;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam14(V self, V *args) {
  V v_x_2480 = args[0];
  V v_hd_2481 = args[1];
  V v_k_2482 = args[2];
  heff_drop(v_hd_2481);
  V f_ = v_k_2482;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2480});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam16(V self, V *args) {
  V v_x_2487 = args[0];
  V v_ended_2458 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_err_2459 = heff_env(self)[2];
  V v_x_2476 = heff_env(self)[3];
  V v_rev_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2487);
  V v_t_2491;
  switch (heff_tag_of(v_ended_2458)) {
  case TAG_Exited: {
    V v_n_2488 = heff_dup(heff_field(v_ended_2458, 0));
    v_t_2491 = heff_bool(!heff_intEq_c_lent(v_n_2488, MK_INT(0LL), 2));
    heff_drop(v_n_2488);
    break;
  }
  case TAG_Signalled: {
    v_t_2491 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2491 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2491 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2458);
  }
  V v_x_24138;
  if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
    heff_drop(v_x_2476);
    heff_drop(v_rev_243);
    heff_drop(v_t_2491);
    V v_t_2492 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
    V v_t_2493 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str14), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str15), v_t_2492));
    V v_t_24102;
    switch (heff_tag_of(v_ended_2458)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2458, 0ULL, 1);
      v_t_24102 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str16);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2458, 0ULL, 1);
      v_t_24102 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str17);
      break;
    }
    case TAG_TimedOut: {
      v_t_24102 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str18);
      break;
    }
    case TAG_NotRun: {
      V v_err_2496 = heff_field(v_ended_2458, 0);
      heff_take_n(v_ended_2458, 1ULL, 1);
      V v_path_2497 = heff_take_field(v_err_2496, 3);
      V v_name_2498 = heff_take_field(v_err_2496, 1);
      V v_message_2499 = heff_get_n(v_err_2496, 2, 4);
      V v_t_24100 = heff_strAppend(heff_strAppend(v_path_2497, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str19)), v_name_2498);
      V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str20)), v_message_2499);
      v_t_24102 = heff_strAppend(v_t_24101, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str21));
      break;
    }
    default: heff_nomatch(v_ended_2458);
    }
    V v_s_24103 = heff_strAppend(v_t_24102, v_err_2459);
    V v_t_24104 = (g_prelude_2eskipSpaces(v_s_24103, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24105 = (heff_unbox_word(heff_strLength_lent(v_s_24103, 0)) - ((int64_t)1ULL));
    V v_t_24106 = (g_prelude_2eskipSpaces(v_s_24103, heff_box_word(v_t_24105), MK_INT(-1LL)));
    V v_t_24107 = heff_strSlice(v_s_24103, v_t_24104, heff_intAdd(v_t_24106, MK_INT(1LL)));
    V v_t_24108 = heff_strAppend(heff_strAppend(v_t_2493, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str22)), v_t_24107);
    v_x_24138 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24108});
  } else {
    heff_drop(v_ended_2458);
    heff_drop(v_err_2459);
    heff_drop(v_t_2491);
    switch (heff_tag_of(v_x_2476)) {
    case TAG_Nothing: {
      V v_t_24109 = (g_heff_2ebuild_2efetch_2erevSaid(v_rev_243));
      V v_t_24110 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str23), v_t_24109), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str24));
      V v_t_24111 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
      V v_t_24112 = heff_strAppend(v_t_24110, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str25), v_t_24111));
      v_x_24138 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24112});
      break;
    }
    case TAG_Just: {
      V v_it1_24113 = heff_field(v_x_2476, 0);
      V v_ru_24x_2476_24Just = heff_take_reuse_n(v_x_2476, 1ULL, 1);
      heff_drop(v_rev_243);
      switch (heff_tag_of(v_it1_24113)) {
      case TAG_MkPair: {
        V v_time_24114 = heff_field(v_it1_24113, 0);
        V v_hash_24115 = heff_field(v_it1_24113, 1);
        heff_take_n(v_it1_24113, 3ULL, 2);
        V v_path_24116 = v_path_242;
        V v_time_24117 = v_time_24114;
        V v_hash_24118 = v_hash_24115;
        V v_xs_24119 = ({ V a_0 = v_path_24116; V b_1 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str26); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str27), v_path_24116, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
        V v_t_24120 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24119));
        V v_t_24123;
        switch (heff_tag_of(v_t_24120)) {
        case TAG_Nil: {
          v_t_24123 = heff_dup(v_path_24116);
          break;
        }
        case TAG_Cons: {
          V v_x_24121 = heff_field(v_t_24120, 0);
          heff_take_n(v_t_24120, 1ULL, 2);
          v_t_24123 = v_x_24121;
          break;
        }
        default: heff_nomatch(v_t_24120);
        }
        V v_t_24124 = ({ V a_0 = v_t_24123; V r_ = (g_heff_2ebuild_2eproject_2eisMajorPart(a_0)); heff_drop(v_t_24123); r_; });
        V v_t_24135;
        if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
          heff_drop(v_t_24124);
          V v_xs_24125 = ({ V a_0 = v_path_24116; V b_1 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str28); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str29), v_path_24116, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
          V v_t_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24125));
          V v_t_24129;
          switch (heff_tag_of(v_t_24126)) {
          case TAG_Nil: {
            v_t_24129 = heff_dup(v_path_24116);
            break;
          }
          case TAG_Cons: {
            V v_x_24127 = heff_field(v_t_24126, 0);
            heff_take_n(v_t_24126, 1ULL, 2);
            v_t_24129 = v_x_24127;
            break;
          }
          default: heff_nomatch(v_t_24126);
          }
          V v_xs_24130 = ({ V a_0 = v_path_24116; V b_1 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str30); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str31), v_path_24116, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
          V v_t_24131 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24130));
          V v_t_24134;
          switch (heff_tag_of(v_t_24131)) {
          case TAG_Nil: {
            v_t_24134 = v_path_24116;
            break;
          }
          case TAG_Cons: {
            V v_x_24132 = heff_field(v_t_24131, 0);
            heff_take_n(v_t_24131, 1ULL, 2);
            heff_drop(v_path_24116);
            v_t_24134 = v_x_24132;
            break;
          }
          default: heff_nomatch(v_t_24131);
          }
          v_t_24135 = heff_strSlice(v_t_24129, MK_INT(1LL), heff_strLength(v_t_24134));
        } else {
          heff_drop(v_path_24116);
          heff_drop(v_t_24124);
          v_t_24135 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str32);
        }
        V v_t_24136 = heff_strAppend(heff_strAppend(v_t_24135, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str33)), v_time_24117);
        V v_t_24137 = heff_strAppend(heff_strAppend(v_t_24136, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str34)), heff_strSlice(v_hash_24118, MK_INT(0LL), MK_INT(12LL)));
        v_x_24138 = heff_tag_at_n(v_ru_24x_2476_24Just, TAG_Right, 1, (V[]){v_t_24137});
        break;
      }
      default: heff_nomatch(v_it1_24113);
      }
      break;
    }
    default: heff_nomatch(v_x_2476);
    }
  }
  V f_ = v_k_246;
  args[0] = v_x_24138;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam15(V self, V *args) {
  V v_x_2484 = args[0];
  V v_x_2442 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_ended_2458 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_err_2459 = heff_env(self)[5];
  V v_x_2476 = heff_env(self)[6];
  V v_rev_243 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2484);
  V v_t_2485 = heff_tag_n(TAG_End, 2, (V[]){v_x_2442, NTAG(TAG_MkUnit)});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2486}), v_hd_245, heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam16, 1, 6, (V[]){v_ended_2458, v_path_242, v_err_2459, v_x_2476, v_rev_243, v_k_246})));
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam13(V self, V *args) {
  V v_x_2476 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_2442 = heff_env(self)[3];
  V v_ended_2458 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_err_2459 = heff_env(self)[6];
  V v_rev_243 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_path_2477 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_244));
  V v_c_2478 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2477; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2477); r_; });
  V v_t_2479 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2483 = heff_tr(heff_call(v_c_2478, 2, (V[]){v_t_2479, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam14_clo)}));
  V f_ = v_c_2483;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam15, 1, 9, (V[]){v_x_2442, v_e_240, v_hd_245, v_ended_2458, v_path_242, v_err_2459, v_x_2476, v_rev_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam8(V self, V *args) {
  V v_x_2457 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_2442 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_ended_2458 = heff_take_field(v_x_2457, 0);
  V v_err_2459 = heff_get_n(v_x_2457, 2, 3);
  V v_c_2475;
  switch (heff_tag_of(v_ended_2458)) {
  case TAG_Exited: {
    V v_n_2460 = heff_dup(heff_field(v_ended_2458, 0));
    if (heff_intEq_c(v_n_2460, MK_INT(0LL))) {
      V v_rev_2461 = heff_dup(v_rev_243);
      V v_t_2464;
      if (heff_strEq_c_lent(v_rev_2461, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str10), 2)) {
        v_t_2464 = v_rev_2461;
      } else {
        if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_2461, 0)))) {
          if ((heff_unbox_word(heff_strLength_lent(v_rev_2461, 0)) <= ((int64_t)40ULL))) {
            V v_t_2462 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_2461, 0)));
            V v_t_2463 = ({ V a_0 = v_rev_2461; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_2462; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2462); r_; });
            if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
              heff_drop(v_t_2463);
              v_t_2464 = v_rev_2461;
            } else {
              heff_drop(v_t_2463);
              v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str11), v_rev_2461);
            }
          } else {
            v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str12), v_rev_2461);
          }
        } else {
          v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str13), v_rev_2461);
        }
      }
      v_c_2475 = (g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383(heff_dup(v_e_240), heff_dup(v_x_244), v_t_2464));
    } else {
      v_c_2475 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam9_clo);
    }
    break;
  }
  case TAG_Signalled: {
    v_c_2475 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam10_clo);
    break;
  }
  case TAG_TimedOut: {
    v_c_2475 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam11_clo);
    break;
  }
  case TAG_NotRun: {
    v_c_2475 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam12_clo);
    break;
  }
  default: heff_nomatch(v_ended_2458);
  }
  V f_ = v_c_2475;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam13, 1, 9, (V[]){v_x_244, v_e_240, v_hd_245, v_x_2442, v_ended_2458, v_path_242, v_err_2459, v_rev_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_rev_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str3), v_t_2443), v_t_2444});
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str5), v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str7), v_t_2446})});
  V v_t_2448 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str8), v_t_2447, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str9), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2448, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam7_clo)})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2456, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam8, 1, 7, (V[]){v_rev_243, v_e_240, v_x_244, v_hd_245, v_x_2442, v_path_242, v_k_246})));
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2435);
  V v_t_2436 = (g_heff_2ebuild_2efetch_2erevSaid(heff_dup(v_rev_243)));
  V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str1), v_t_2436), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_str2));
  V v_name_2438 = heff_strAppend(v_t_2437, heff_dup(v_path_242));
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_name_2438, MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam5_clo)})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2441, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam6, 1, 6, (V[]){v_path_242, v_x_244, v_e_240, v_hd_245, v_rev_243, v_k_246})));
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_rev_243 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2414);
  V v_st_2415 = heff_get_n(v_ps_241, 5, 6);
  HeffT3 v_t_2416 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2415), heff_dup(v_x_244)));
  V v_t_2426;
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2418 = v_t_2416.f[1];
    V v_field_2419 = v_t_2416.f[2];
    V v_d_2420 = v_field_2417;
    V v_a_2421 = v_field_2418;
    V v_xs_2422 = v_field_2419;
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2422));
    V v_xs_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2423; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    v_t_2426 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2420, v_a_2421, v_t_2425});
  }
  V v_s_2427 = ({ V a_0 = v_st_2415; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2426); r_; });
  V v_path_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2427));
  V v_c_2429 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2428; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2428); r_; });
  V v_t_2430 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2434 = heff_tr(heff_call(v_c_2429, 2, (V[]){v_t_2430, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam3_clo)}));
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam4, 1, 6, (V[]){v_rev_243, v_path_242, v_e_240, v_hd_245, v_x_244, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_244)));
  V v_c_248 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_247; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_247); r_; });
  V v_t_249 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2413 = heff_tr(heff_call(v_c_248, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam1_clo)}));
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520_lam2, 1, 7, (V[]){v_ps_241, v_x_244, v_e_240, v_hd_245, v_rev_243, v_path_242, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str1, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str3, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str7, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str8, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str9, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str10, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str11, 1, "\012");
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam0, 3, 0};
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_entry, 2, 0};

V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271(V v_e_240, V v_spec_241) {
top: ;
  V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str0)));
  V v_c_243 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_242; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_242); r_; });
  V v_t_244 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_248 = heff_tr(heff_call(v_c_243, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam1, 2, 3, (V[]){v_c_248, v_e_240, v_spec_241});
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271(a[0], a[1]);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_246 = args[1];
  V v_k_247 = args[2];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam5(V self, V *args) {
  V v_x_2460 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2460);
  V v_t_2461 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam6(V self, V *args) {
  V v_x_2484 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2484);
  V v_t_2485 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2491}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam10(V self, V *args) {
  V v_x_24108 = args[0];
  V v_k_24107 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2494 = heff_env(self)[2];
  V v_path_24105 = heff_env(self)[3];
  V v_hd_24106 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_24108)) {
  case TAG_Left: {
    V v_why_24109 = heff_field(v_x_24108, 0);
    heff_take_n(v_x_24108, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_x_2494);
    heff_drop(v_path_24105);
    heff_drop(v_hd_24106);
    V f_ = v_k_24107;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_24109});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_it1_24110 = heff_field(v_x_24108, 0);
    heff_take_n(v_x_24108, 1ULL, 1);
    switch (heff_tag_of(v_it1_24110)) {
    case TAG_Nothing: {
      V v_t_24111 = (g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520(v_e_240, v_x_2494, v_path_24105, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str7)));
      V f_ = v_t_24111;
      heff_room[0] = v_hd_24106;
      heff_room[1] = v_k_24107;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_v_24112 = heff_field(v_it1_24110, 0);
      heff_take_n(v_it1_24110, 1ULL, 1);
      heff_drop(v_e_240);
      heff_drop(v_x_2494);
      heff_drop(v_path_24105);
      heff_drop(v_hd_24106);
      V f_ = v_k_24107;
      args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_24112});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_it1_24110);
    }
  }
  default: return heff_nomatch(v_x_24108);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam9(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k_24107 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_path_24105 = heff_env(self)[1];
  V v_x_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368(heff_dup(v_e_240), heff_dup(v_path_24105), heff_dup(v_hd_24106), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam10, 1, 5, (V[]){v_k_24107, v_e_240, v_x_2494, v_path_24105, v_hd_24106})));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam11(V self, V *args) {
  V v_hd_24125 = args[0];
  V v_k_24126 = args[1];
  V v_rev_24113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24125);
  V f_ = v_k_24126;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_rev_24113});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam13(V self, V *args) {
  V v_x_24140 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24140);
  V v_t_24141 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24141})});
  V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
  V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
  V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
  V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24146})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24147}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam14(V self, V *args) {
  V v_x_24156 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24156) == NTAG(TAG_True))) {
    heff_drop(v_x_24156);
    return (g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262(v_e_240, v_hd_249, v_k_2410));
  } else {
    heff_drop(v_x_24156);
    heff_drop(v_e_240);
    heff_drop(v_hd_249);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam12(V self, V *args) {
  V v_x_24130 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_s_2469 = heff_env(self)[3];
  V v_x_2494 = heff_env(self)[4];
  V v_y_2428 = heff_env(self)[5];
  V v_pk_2468 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_24130)) {
  case TAG_Left: {
    V v_why_24131 = heff_field(v_x_24130, 0);
    V v_ru_24x_24130_24Left = heff_take_reuse_n(v_x_24130, 1ULL, 1);
    heff_drop(v_s_2469);
    heff_drop(v_x_2494);
    heff_drop(v_y_2428);
    heff_drop(v_pk_2468);
    V v_t_24132 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str10), v_why_24131), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str11));
    V v_t_24133 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24132, NTAG(TAG_MkUnit)});
    V v_t_24134 = heff_tag_at_n(v_ru_24x_24130_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
    V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
    V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24138})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24139}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam13, 1, 3, (V[]){v_e_240, v_hd_249, v_k_2410})));
  }
  case TAG_Right: {
    V v_ver_24148 = heff_field(v_x_24130, 0);
    heff_take_n(v_x_24130, 1ULL, 1);
    HeffT2 v_t_24149 = (g_heff_2ebuild_2efetch_2especOf_24cpr(v_s_2469));
    V v_t_24154;
    {
      V v_field_24150 = v_t_24149.f[0];
      V v_field_24151 = v_t_24149.f[1];
      V v_x_24152 = v_field_24150;
      V v_y_24153 = v_field_24151;
      heff_drop(v_y_24153);
      v_t_24154 = v_x_24152;
    }
    V v_c_24155 = (g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479(heff_dup(v_e_240), v_x_2494, v_y_2428, v_pk_2468, v_t_24154, v_ver_24148));
    V f_ = v_c_24155;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam14, 1, 3, (V[]){v_e_240, v_hd_249, v_k_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24130);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam8(V self, V *args) {
  V v_x_2494 = args[0];
  V v_s_2469 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  V v_pk_2468 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2495 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2469)));
  {
    V v_field_2496 = v_t_2495.f[0];
    V v_field_2497 = v_t_2495.f[1];
    V v_x_2498 = v_field_2496;
    heff_drop(v_x_2498);
    V v_y_2499 = v_field_2497;
    V v_c_24129;
    switch (heff_tag_of(v_y_2499)) {
    case TAG_Nothing: {
      HeffT2 v_t_24100 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2469)));
      {
        V v_field_24101 = v_t_24100.f[0];
        V v_field_24102 = v_t_24100.f[1];
        V v_x_24103 = v_field_24101;
        V v_y_24104 = v_field_24102;
        heff_drop(v_y_24104);
        V v_path_24105 = v_x_24103;
        v_c_24129 = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam9, 2, 3, (V[]){heff_dup(v_e_240), v_path_24105, heff_dup(v_x_2494)});
      }
      break;
    }
    case TAG_Just: {
      V v_rev_24113 = heff_field(v_y_2499, 0);
      heff_take_n(v_y_2499, 1ULL, 1);
      HeffT2 v_t_24114 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2469)));
      {
        V v_field_24115 = v_t_24114.f[0];
        V v_field_24116 = v_t_24114.f[1];
        V v_t_24117 = ({ V a_0 = v_rev_24113; V b_1 = ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str8); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str9), v_rev_24113, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
        V v_t_24118 = ({ V a_0 = v_t_24117; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_24117); r_; });
        HeffT2 v_t_24119 = ({ V a_0 = v_rev_24113; V a_1 = v_t_24118; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_24118); r_; });
        V v_t_24124;
        {
          V v_field_24120 = v_t_24119.f[0];
          V v_field_24121 = v_t_24119.f[1];
          V v_x_24122 = v_field_24120;
          V v_y_24123 = v_field_24121;
          heff_drop(v_y_24123);
          v_t_24124 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24122; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24122); r_; });
        }
        if (heff_intEq_c(v_t_24124, MK_INT(3LL))) {
          heff_drop(v_field_24115);
          heff_drop(v_field_24116);
          v_c_24129 = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam11, 2, 1, (V[]){v_rev_24113});
        } else {
          V v_x_24127 = v_field_24115;
          V v_y_24128 = v_field_24116;
          heff_drop(v_y_24128);
          v_c_24129 = (g_heff_2ebuild_2efetch_2ecommitVersion_24s1282197199x1409352520(heff_dup(v_e_240), heff_dup(v_x_2494), v_x_24127, v_rev_24113));
        }
      }
      break;
    }
    default: heff_nomatch(v_y_2499);
    }
    V f_ = v_c_24129;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam12, 1, 7, (V[]){v_e_240, v_hd_249, v_k_2410, v_s_2469, v_x_2494, v_y_2428, v_pk_2468});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam7(V self, V *args) {
  V v_x_2492 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_s_2469 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  V v_pk_2468 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2493 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), v_x_2492, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str6)));
  V f_ = v_c_2493;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam8, 1, 6, (V[]){v_s_2469, v_e_240, v_hd_249, v_k_2410, v_y_2428, v_pk_2468});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_spec_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 0ULL, 1);
    heff_drop(v_spec_241);
    V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str1), NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam3, 1, 3, (V[]){v_e_240, v_hd_249, v_k_2410})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Right = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    HeffT2 v_t_2429 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_y_2428)));
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        heff_drop(v_spec_241);
        heff_drop(v_y_2428);
        V v_p_2432 = v_field_2431;
        heff_drop(v_p_2432);
        V v_t_2433 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str2), NTAG(TAG_MkUnit)});
        V v_t_2434 = heff_tag_at_n(v_ru_24x_2411_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
        V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
        V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
        return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam4, 1, 3, (V[]){v_e_240, v_hd_249, v_k_2410})));
      } else {
        V v_x_2448 = v_field_2431;
        HeffT2 v_t_2449 = ({ V a_0 = v_x_2448; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2448); r_; });
        {
          V v_field_2451 = v_t_2449.f[1];
          int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
          if ((v_tag_2450 == ((int64_t)0ULL))) {
            heff_drop(v_spec_241);
            heff_drop(v_y_2428);
            V v_x_2452 = v_field_2451;
            heff_drop(v_x_2452);
            V v_t_2453 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str3), NTAG(TAG_MkUnit)});
            V v_t_2454 = heff_tag_at_n(v_ru_24x_2411_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
            V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
            V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
            V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
            V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
            V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
            return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam5, 1, 3, (V[]){v_e_240, v_hd_249, v_k_2410})));
          } else {
            V v_pk_2468 = v_field_2451;
            switch (heff_tag_of(v_spec_241)) {
            case TAG_Nothing: {
              heff_drop(v_y_2428);
              heff_drop_cell(v_ru_24x_2411_24Right, 1);
              heff_drop(v_pk_2468);
              return (g_heff_2ebuild_2efetch_2egetAll_24s920269202x1126145262(v_e_240, v_hd_249, v_k_2410));
            }
            case TAG_Just: {
              V v_s_2469 = heff_field(v_spec_241, 0);
              V v_ru_24spec_241_24Just = heff_take_reuse_n(v_spec_241, 1ULL, 1);
              HeffT2 v_t_2470 = (g_heff_2ebuild_2efetch_2especOf_24cpr(heff_dup(v_s_2469)));
              V v_t_2475;
              {
                V v_field_2471 = v_t_2470.f[0];
                V v_field_2472 = v_t_2470.f[1];
                V v_x_2473 = v_field_2471;
                V v_y_2474 = v_field_2472;
                heff_drop(v_y_2474);
                v_t_2475 = v_x_2473;
              }
              if (heff_strEq_c(v_t_2475, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                heff_drop(v_y_2428);
                heff_drop(v_pk_2468);
                heff_drop(v_s_2469);
                V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str4), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_str5));
                V v_t_2477 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2476, NTAG(TAG_MkUnit)});
                V v_t_2478 = heff_tag_at_n(v_ru_24x_2411_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24spec_241_24Just, TAG_InL, 1, (V[]){v_t_2477})});
                V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
                V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
                V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
                V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
                V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
                return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2483}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam6, 1, 3, (V[]){v_e_240, v_hd_249, v_k_2410})));
              } else {
                heff_drop_cell(v_ru_24x_2411_24Right, 1);
                heff_drop_cell(v_ru_24spec_241_24Just, 1);
                return (g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(heff_dup(v_e_240), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam7, 1, 6, (V[]){v_e_240, v_hd_249, v_s_2469, v_k_2410, v_y_2428, v_pk_2468})));
              }
            }
            default: return heff_nomatch(v_spec_241);
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_spec_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_lam2, 1, 4, (V[]){v_e_240, v_hd_249, v_k_2410, v_spec_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}