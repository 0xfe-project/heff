// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadFieldSet 46507
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Right 62770
#define TAG_SWarning 44190
#define TAG_SetField 47531
#define TAG_Sig 30557
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_f 320
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_implicits 1321238867
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_toks 10061290
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_eqns__end[] = {LBL_eqns, LBL_end};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V, V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnsUnder(V, V);
V g_heff_2esyntax_2esurface_2eeqnsUnder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnsUnder_clo;
V g_heff_2esyntax_2esurface_2efixDiagsOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo;
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esigL(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigL_clo;
V g_heff_2esyntax_2esurface_2esymAtom(V);
V g_heff_2esyntax_2esurface_2esymAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esymAtom_clo;
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
Clo g_heff_2esyntax_2esurface_2ewithScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewithScope_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ewithScope(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V v_sc_244 = (g_heff_2esyntax_2esurface_2eappendS(v_xs_240, heff_dup(heff_rfield(v_st_242, 1))));
  V v_t_245 = heff_rec_n(8, shape_toks__scope__known__binders__patVars__fix__lenient__at, (V[]){heff_take_field(v_st_242, 0), v_sc_244, heff_take_field(v_st_242, 2), heff_take_field(v_st_242, 3), heff_take_field(v_st_242, 4), heff_take_field(v_st_242, 5), heff_take_field(v_st_242, 6), heff_take_field(v_st_242, 7)});
  V v_x1_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_245});
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop_rec(v_st_242, 8);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      heff_take_n(v_x11_247, 0ULL, 1);
      V v_x1_2411 = heff_tr(heff_call(v_p_241, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_MkPair: {
        V v_x11_2412 = heff_field(v_x1_2411, 0);
        V v_st_2413 = heff_field(v_x1_2411, 1);
        heff_take_n(v_x1_2411, 3ULL, 2);
        switch (heff_tag_of(v_x11_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x11_2412, 0);
          heff_take_n(v_x11_2412, 1ULL, 1);
          heff_drop_rec(v_st_242, 8);
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x11_2412, 0);
          heff_take_n(v_x11_2412, 1ULL, 1);
          V v_t_2416 = ({ V rv_1 = heff_get_n(v_st_242, 1, 8); V rr_ = heff_rec_reuse_nf(v_st_2413, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2415}), v_t_2416});
        }
        default: return heff_nomatch(v_x11_2412);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewithScope(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eblock_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eblock(V v_f_240, V v_xs_241, V v_st_242) {
top: ;
  V v_m_243 = (g_heff_2esyntax_2esurface_2etraverseS(v_f_240, v_xs_241));
  V v_x1_244 = heff_tr(heff_call(v_m_243, 1, (V[]){heff_dup(v_st_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_st_242, 8);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      V v_t_249 = ({ V rv_1 = heff_get_n(v_st_242, 1, 8); V rr_ = heff_rec_reuse_nf(v_st_246, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_248}), v_t_249});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eblock(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eboundBy_24dps(V v_pv_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_244));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_241, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 1)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str2))) {
          V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
          V v_t_2412 = (g_list_2eany(v_t_2411, v_pv_240));
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
            return heff_setField(v_d_242, MK_INT(1LL), v_t_2413);
          } else {
            heff_drop(v_t_2412);
            return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
          }
        } else {
          return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
        }
      } else {
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
        return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str3))) {
        V v_t_2416 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
        V v_t_2417 = (g_list_2eany(v_t_2416, v_pv_240));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_t_2417);
          V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
          return heff_setField(v_d_242, MK_INT(1LL), v_t_2418);
        } else {
          heff_drop(v_t_2417);
          return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
        }
      } else {
        return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  case TAG_PParen: {
    V v_q_2420 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2420;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2423 = heff_field(v_x2_241, 1);
    V v_t_2427 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2423));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2427);
  }
  case TAG_POp: {
    V v_l_2428 = heff_field(v_x2_241, 0);
    V v_q_2430 = heff_field(v_x2_241, 2);
    V v_t_2431 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2428));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2430));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2431, v_t_2432));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2433);
  }
  case TAG_PRec: {
    V v_fs_2435 = heff_field(v_x2_241, 1);
    V v_t_2439 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2435));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2439);
  }
  case TAG_PField: {
    V v_q_2442 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2442;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2443 = heff_field(v_x2_241, 0);
    V v_q_2445 = heff_field(v_x2_241, 2);
    V v_cell_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2443, 1)), heff_hole()});
    V v_u_2447 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2446));
    heff_drop(v_u_2447);
    V t_0 = v_pv_240;
    V t_1 = v_q_2445;
    V t_2 = v_cell_2446;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy_24dps(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args) {
  V v_q_2426 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2426; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2426); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args) {
  V v_q_2438 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2438; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2438); r_; });
}
Clo g_heff_2esyntax_2esurface_2easNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2easNameE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_EVar, 1, (V[]){v_x_245}), v_sp_242});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EFloat: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easNameE(a[0]);
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eeqnsUnder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnsUnder_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eeqnsUnder(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Sig: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_f_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Eqn: {
      V v_g_249 = heff_field(v_x21_242, 0);
      V v_e_2410 = heff_field(v_x21_242, 1);
      V v_esp_2411 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      if (heff_strEq_c(heff_dup(v_f_240), v_g_249)) {
        V v_x3_2413 = (g_heff_2esyntax_2esurface_2eeqnsUnder(v_f_240, v_rest_243));
        V v_t_2421;
        switch (heff_tag_of(v_x3_2413)) {
        case TAG_Nothing: {
          V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2410, NTAG(TAG_Nil)});
          v_t_2421 = heff_rec_n(2, shape_eqns__end, (V[]){v_t_2414, heff_get_n(v_esp_2411, 1, 2)});
          break;
        }
        case TAG_Just: {
          V v_rest_2415 = heff_field(v_x3_2413, 0);
          heff_take_n(v_x3_2413, 1ULL, 1);
          V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2410, heff_dup(heff_rfield(v_rest_2415, 0))});
          V v_a_2417 = heff_get_n(v_esp_2411, 1, 2);
          V v_b_2418 = heff_get_n(v_rest_2415, 1, 2);
          V v_t_2420;
          if (heff_intLt_c(heff_dup(v_a_2417), heff_dup(v_b_2418))) {
            heff_drop(v_a_2417);
            v_t_2420 = v_b_2418;
          } else {
            heff_drop(v_b_2418);
            v_t_2420 = v_a_2417;
          }
          v_t_2421 = heff_rec_n(2, shape_eqns__end, (V[]){v_t_2416, v_t_2420});
          break;
        }
        default: heff_nomatch(v_x3_2413);
        }
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
      } else {
        heff_drop(v_f_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_e_2410);
        heff_drop_rec(v_esp_2411, 2);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_Whole: {
      V v_d_2422 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2445;
      switch (heff_tag_of(v_d_2422)) {
      case TAG_At: {
        V v_x11_2423 = heff_field(v_d_2422, 0);
        heff_take_n(v_d_2422, 1ULL, 2);
        switch (heff_tag_of(v_x11_2423)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2423, 0ULL, 5);
          v_t_2445 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2423, 0ULL, 5);
          v_t_2445 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2423, 0ULL, 4);
          v_t_2445 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2423, 0ULL, 3);
          v_t_2445 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2423, 0ULL, 2);
          v_t_2445 = NTAG(TAG_False);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2423, 0ULL, 1);
          v_t_2445 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2423);
        }
        break;
      }
      default: heff_nomatch(v_d_2422);
      }
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_f_240);
        heff_drop(v_rest_243);
        heff_drop(v_t_2445);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_t_2445);
        V t_0 = v_f_240;
        V t_1 = v_rest_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_Doc: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_rest_243;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eeqnsUnder_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eeqnsUnder(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esymAtom_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2esymAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esymAtom_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esymAtom(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Atom = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2esurface_2esymAtom_str0))) {
      return heff_tag_at_n(v_ru_24x1_240_24Atom, TAG_Just, 1, (V[]){v_t_241});
    } else {
      heff_drop_rec(v_t_241, 9);
      heff_drop_cell(v_ru_24x1_240_24Atom, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_Nothing);
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_Nothing);
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esymAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esymAtom(a[0]);
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam28(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esettingL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esettingL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esettingL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam1, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam2, 1, 1, (V[]){v_m_2433});
  }
  case TAG_Tup: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam3, 1, 1, (V[]){v_m_2448});
  }
  case TAG_Braces: {
    V v_m_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam4, 1, 1, (V[]){v_m_2463});
  }
  case TAG_Update: {
    V v_m_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam5, 1, 1, (V[]){v_m_2480});
  }
  case TAG_EUSet: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam6, 1, 1, (V[]){v_m_2494});
  }
  case TAG_InstB: {
    V v_m_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam7, 1, 1, (V[]){v_m_24110});
  }
  case TAG_EFSet: {
    V v_x_24121 = heff_field(v_e_241, 0);
    V v_e3_24123 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 5ULL, 3);
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e3_24123}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam8, 1, 2, (V[]){v_m_24124, v_x_24121});
  }
  case TAG_EFDefault: {
    V v_m_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam9, 1, 1, (V[]){v_m_24141});
  }
  case TAG_Sum: {
    V v_m_24157 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam10, 1, 1, (V[]){v_m_24157});
  }
  case TAG_ECon: {
    V v_m_24170 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam11, 1, 1, (V[]){v_m_24170});
  }
  case TAG_EField: {
    V v_m_24183 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam12, 1, 1, (V[]){v_m_24183});
  }
  case TAG_ENeg: {
    V v_m_24196 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam13, 1, 1, (V[]){v_m_24196});
  }
  case TAG_App: {
    V v_m_24209 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam14, 1, 1, (V[]){v_m_24209});
  }
  case TAG_Op: {
    V v_m_24223 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam15, 1, 1, (V[]){v_m_24223});
  }
  case TAG_Ops: {
    V v_m_24236 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam16, 1, 1, (V[]){v_m_24236});
  }
  case TAG_OpRhs: {
    V v_m_24249 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam17, 1, 1, (V[]){v_m_24249});
  }
  case TAG_Ann: {
    V v_m_24263 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam18, 1, 1, (V[]){v_m_24263});
  }
  case TAG_BVar: {
    V v_m_24275 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam19, 1, 1, (V[]){v_m_24275});
  }
  case TAG_BImp: {
    V v_m_24289 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam20, 1, 1, (V[]){v_m_24289});
  }
  case TAG_BAnn: {
    V v_m_24305 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam21, 1, 1, (V[]){v_m_24305});
  }
  case TAG_Lam: {
    V v_m_24320 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam22, 1, 1, (V[]){v_m_24320});
  }
  case TAG_Case: {
    V v_m_24335 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam23, 1, 1, (V[]){v_m_24335});
  }
  case TAG_EAlt: {
    V v_m_24349 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam24, 1, 1, (V[]){v_m_24349});
  }
  case TAG_If: {
    V v_m_24366 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam25, 1, 1, (V[]){v_m_24366});
  }
  case TAG_Do: {
    V v_m_24379 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam26, 1, 1, (V[]){v_m_24379});
  }
  case TAG_ESBind: {
    V v_m_24393 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam27, 1, 1, (V[]){v_m_24393});
  }
  case TAG_ELet: {
    V v_m_24410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam28, 1, 1, (V[]){v_m_24410});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esettingL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_x_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_x_2413 = heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_249}), v_t_2412});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_x_2413}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_x_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_x_2427 = heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_2423}), v_t_2426});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_Right, 1, (V[]){v_x_2427}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      heff_take_n(v_x11_2436, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_x_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_x_2439, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_x_2439);
      }
      V v_x_2443 = heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_2439}), v_t_2442});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_Right, 1, (V[]){v_x_2443}), v_st_2437});
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam3(V self, V *args) {
  V v_st_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2449}));
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_MkPair: {
    V v_x11_2451 = heff_field(v_x1_2450, 0);
    V v_st_2452 = heff_field(v_x1_2450, 1);
    V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_Left: {
      V v_e_2453 = heff_field(v_x11_2451, 0);
      heff_take_n(v_x11_2451, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_x11_2451, 0);
      V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_x_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_x_2458 = heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_2454}), v_t_2457});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_Right, 1, (V[]){v_x_2458}), v_st_2452});
    }
    default: return heff_nomatch(v_x11_2451);
    }
  }
  default: return heff_nomatch(v_x1_2450);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam4(V self, V *args) {
  V v_st_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_st_2464}));
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_MkPair: {
    V v_x11_2466 = heff_field(v_x1_2465, 0);
    V v_st_2467 = heff_field(v_x1_2465, 1);
    V v_ru_24x1_2465_24MkPair = heff_take_reuse_n(v_x1_2465, 3ULL, 2);
    switch (heff_tag_of(v_x11_2466)) {
    case TAG_Left: {
      V v_e_2468 = heff_field(v_x11_2466, 0);
      heff_take_n(v_x11_2466, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2468}), v_st_2467});
    }
    case TAG_Right: {
      V v_x_2469 = heff_field(v_x11_2466, 0);
      V v_ru_24x11_2466_24Right = heff_take_reuse_n(v_x11_2466, 1ULL, 1);
      V v_t_2472;
      switch (heff_tag_of(v_x_2469)) {
      case TAG_At: {
        V v_s_2471 = heff_dup(heff_field(v_x_2469, 1));
        v_t_2472 = v_s_2471;
        break;
      }
      default: heff_nomatch(v_x_2469);
      }
      V v_x_2473 = heff_tag_at_n(v_ru_24x1_2465_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_2469}), v_t_2472});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2466_24Right, TAG_Right, 1, (V[]){v_x_2473}), v_st_2467});
    }
    default: return heff_nomatch(v_x11_2466);
    }
  }
  default: return heff_nomatch(v_x1_2465);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam5(V self, V *args) {
  V v_st_2481 = args[0];
  V v_m_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2482 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_st_2481}));
  switch (heff_tag_of(v_x1_2482)) {
  case TAG_MkPair: {
    V v_x11_2483 = heff_field(v_x1_2482, 0);
    V v_st_2484 = heff_field(v_x1_2482, 1);
    V v_ru_24x1_2482_24MkPair = heff_take_reuse_n(v_x1_2482, 3ULL, 2);
    switch (heff_tag_of(v_x11_2483)) {
    case TAG_Left: {
      V v_e_2485 = heff_field(v_x11_2483, 0);
      heff_take_n(v_x11_2483, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2485}), v_st_2484});
    }
    case TAG_Right: {
      V v_x_2486 = heff_field(v_x11_2483, 0);
      V v_ru_24x11_2483_24Right = heff_take_reuse_n(v_x11_2483, 1ULL, 1);
      V v_t_2489;
      switch (heff_tag_of(v_x_2486)) {
      case TAG_At: {
        V v_s_2488 = heff_dup(heff_field(v_x_2486, 1));
        v_t_2489 = v_s_2488;
        break;
      }
      default: heff_nomatch(v_x_2486);
      }
      V v_x_2490 = heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_2486}), v_t_2489});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2483_24Right, TAG_Right, 1, (V[]){v_x_2490}), v_st_2484});
    }
    default: return heff_nomatch(v_x11_2483);
    }
  }
  default: return heff_nomatch(v_x1_2482);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam6(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24103;
      switch (heff_tag_of(v_x_24100)) {
      case TAG_At: {
        V v_s_24102 = heff_dup(heff_field(v_x_24100, 1));
        v_t_24103 = v_s_24102;
        break;
      }
      default: heff_nomatch(v_x_24100);
      }
      V v_x_24104 = heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24100}), v_t_24103});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_Right, 1, (V[]){v_x_24104}), v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam7(V self, V *args) {
  V v_st_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_st_24111}));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_MkPair: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_st_24114 = heff_field(v_x1_24112, 1);
    V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_Left: {
      V v_e_24115 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
    }
    case TAG_Right: {
      V v_x_24116 = heff_field(v_x11_24113, 0);
      V v_ru_24x11_24113_24Right = heff_take_reuse_n(v_x11_24113, 1ULL, 1);
      V v_t_24119;
      switch (heff_tag_of(v_x_24116)) {
      case TAG_At: {
        V v_s_24118 = heff_dup(heff_field(v_x_24116, 1));
        v_t_24119 = v_s_24118;
        break;
      }
      default: heff_nomatch(v_x_24116);
      }
      V v_x_24120 = heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24116}), v_t_24119});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24113_24Right, TAG_Right, 1, (V[]){v_x_24120}), v_st_24114});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam8(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  V v_x_24121 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      heff_drop_rec(v_x_24121, 9);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24131 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24121, 3)), heff_take_field(v_x_24121, 4)});
      V v_t_24132 = heff_tag_n(TAG_SetField, 3, (V[]){heff_take_field(v_x_24121, 1), v_t_24131, heff_dup(v_x_24130)});
      V v_b_24135;
      switch (heff_tag_of(v_x_24130)) {
      case TAG_At: {
        V v_s_24134 = heff_field(v_x_24130, 1);
        heff_take_n(v_x_24130, 2ULL, 2);
        v_b_24135 = v_s_24134;
        break;
      }
      default: heff_nomatch(v_x_24130);
      }
      V v_t_24136 = ({ V rv_0 = heff_get_n(v_x_24121, 3, 9); V rr_ = heff_rec_reuse_nf(v_b_24135, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x_24137 = heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_At, 2, (V[]){v_t_24132, v_t_24136});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_Right, 1, (V[]){v_x_24137}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam9(V self, V *args) {
  V v_st_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24143 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_st_24142}));
  switch (heff_tag_of(v_x1_24143)) {
  case TAG_MkPair: {
    V v_x11_24144 = heff_field(v_x1_24143, 0);
    V v_st_24145 = heff_field(v_x1_24143, 1);
    V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
    switch (heff_tag_of(v_x11_24144)) {
    case TAG_Left: {
      V v_e_24146 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
    }
    case TAG_Right: {
      V v_x_24147 = heff_field(v_x11_24144, 0);
      V v_ru_24x11_24144_24Right = heff_take_reuse_n(v_x11_24144, 1ULL, 1);
      V v_t_24150;
      switch (heff_tag_of(v_x_24147)) {
      case TAG_At: {
        V v_s_24149 = heff_dup(heff_field(v_x_24147, 1));
        v_t_24150 = v_s_24149;
        break;
      }
      default: heff_nomatch(v_x_24147);
      }
      V v_x_24151 = heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24147}), v_t_24150});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24144_24Right, TAG_Right, 1, (V[]){v_x_24151}), v_st_24145});
    }
    default: return heff_nomatch(v_x11_24144);
    }
  }
  default: return heff_nomatch(v_x1_24143);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam10(V self, V *args) {
  V v_st_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_st_24158}));
  switch (heff_tag_of(v_x1_24159)) {
  case TAG_MkPair: {
    V v_x11_24160 = heff_field(v_x1_24159, 0);
    V v_st_24161 = heff_field(v_x1_24159, 1);
    V v_ru_24x1_24159_24MkPair = heff_take_reuse_n(v_x1_24159, 3ULL, 2);
    switch (heff_tag_of(v_x11_24160)) {
    case TAG_Left: {
      V v_e_24162 = heff_field(v_x11_24160, 0);
      heff_take_n(v_x11_24160, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24162}), v_st_24161});
    }
    case TAG_Right: {
      V v_x_24163 = heff_field(v_x11_24160, 0);
      V v_ru_24x11_24160_24Right = heff_take_reuse_n(v_x11_24160, 1ULL, 1);
      V v_t_24166;
      switch (heff_tag_of(v_x_24163)) {
      case TAG_At: {
        V v_s_24165 = heff_dup(heff_field(v_x_24163, 1));
        v_t_24166 = v_s_24165;
        break;
      }
      default: heff_nomatch(v_x_24163);
      }
      V v_x_24167 = heff_tag_at_n(v_ru_24x1_24159_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24163}), v_t_24166});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24160_24Right, TAG_Right, 1, (V[]){v_x_24167}), v_st_24161});
    }
    default: return heff_nomatch(v_x11_24160);
    }
  }
  default: return heff_nomatch(v_x1_24159);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam11(V self, V *args) {
  V v_st_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_st_24171}));
  switch (heff_tag_of(v_x1_24172)) {
  case TAG_MkPair: {
    V v_x11_24173 = heff_field(v_x1_24172, 0);
    V v_st_24174 = heff_field(v_x1_24172, 1);
    V v_ru_24x1_24172_24MkPair = heff_take_reuse_n(v_x1_24172, 3ULL, 2);
    switch (heff_tag_of(v_x11_24173)) {
    case TAG_Left: {
      V v_e_24175 = heff_field(v_x11_24173, 0);
      heff_take_n(v_x11_24173, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24175}), v_st_24174});
    }
    case TAG_Right: {
      V v_x_24176 = heff_field(v_x11_24173, 0);
      V v_ru_24x11_24173_24Right = heff_take_reuse_n(v_x11_24173, 1ULL, 1);
      V v_t_24179;
      switch (heff_tag_of(v_x_24176)) {
      case TAG_At: {
        V v_s_24178 = heff_dup(heff_field(v_x_24176, 1));
        v_t_24179 = v_s_24178;
        break;
      }
      default: heff_nomatch(v_x_24176);
      }
      V v_x_24180 = heff_tag_at_n(v_ru_24x1_24172_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24176}), v_t_24179});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24173_24Right, TAG_Right, 1, (V[]){v_x_24180}), v_st_24174});
    }
    default: return heff_nomatch(v_x11_24173);
    }
  }
  default: return heff_nomatch(v_x1_24172);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam12(V self, V *args) {
  V v_st_24184 = args[0];
  V v_m_24183 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24185 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_st_24184}));
  switch (heff_tag_of(v_x1_24185)) {
  case TAG_MkPair: {
    V v_x11_24186 = heff_field(v_x1_24185, 0);
    V v_st_24187 = heff_field(v_x1_24185, 1);
    V v_ru_24x1_24185_24MkPair = heff_take_reuse_n(v_x1_24185, 3ULL, 2);
    switch (heff_tag_of(v_x11_24186)) {
    case TAG_Left: {
      V v_e_24188 = heff_field(v_x11_24186, 0);
      heff_take_n(v_x11_24186, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24185_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24188}), v_st_24187});
    }
    case TAG_Right: {
      V v_x_24189 = heff_field(v_x11_24186, 0);
      V v_ru_24x11_24186_24Right = heff_take_reuse_n(v_x11_24186, 1ULL, 1);
      V v_t_24192;
      switch (heff_tag_of(v_x_24189)) {
      case TAG_At: {
        V v_s_24191 = heff_dup(heff_field(v_x_24189, 1));
        v_t_24192 = v_s_24191;
        break;
      }
      default: heff_nomatch(v_x_24189);
      }
      V v_x_24193 = heff_tag_at_n(v_ru_24x1_24185_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24189}), v_t_24192});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24186_24Right, TAG_Right, 1, (V[]){v_x_24193}), v_st_24187});
    }
    default: return heff_nomatch(v_x11_24186);
    }
  }
  default: return heff_nomatch(v_x1_24185);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam13(V self, V *args) {
  V v_st_24197 = args[0];
  V v_m_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24198 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_st_24197}));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_x11_24199 = heff_field(v_x1_24198, 0);
    V v_st_24200 = heff_field(v_x1_24198, 1);
    V v_ru_24x1_24198_24MkPair = heff_take_reuse_n(v_x1_24198, 3ULL, 2);
    switch (heff_tag_of(v_x11_24199)) {
    case TAG_Left: {
      V v_e_24201 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
    }
    case TAG_Right: {
      V v_x_24202 = heff_field(v_x11_24199, 0);
      V v_ru_24x11_24199_24Right = heff_take_reuse_n(v_x11_24199, 1ULL, 1);
      V v_t_24205;
      switch (heff_tag_of(v_x_24202)) {
      case TAG_At: {
        V v_s_24204 = heff_dup(heff_field(v_x_24202, 1));
        v_t_24205 = v_s_24204;
        break;
      }
      default: heff_nomatch(v_x_24202);
      }
      V v_x_24206 = heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24202}), v_t_24205});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24199_24Right, TAG_Right, 1, (V[]){v_x_24206}), v_st_24200});
    }
    default: return heff_nomatch(v_x11_24199);
    }
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam14(V self, V *args) {
  V v_st_24210 = args[0];
  V v_m_24209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24211 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_st_24210}));
  switch (heff_tag_of(v_x1_24211)) {
  case TAG_MkPair: {
    V v_x11_24212 = heff_field(v_x1_24211, 0);
    V v_st_24213 = heff_field(v_x1_24211, 1);
    V v_ru_24x1_24211_24MkPair = heff_take_reuse_n(v_x1_24211, 3ULL, 2);
    switch (heff_tag_of(v_x11_24212)) {
    case TAG_Left: {
      V v_e_24214 = heff_field(v_x11_24212, 0);
      heff_take_n(v_x11_24212, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24214}), v_st_24213});
    }
    case TAG_Right: {
      V v_x_24215 = heff_field(v_x11_24212, 0);
      V v_ru_24x11_24212_24Right = heff_take_reuse_n(v_x11_24212, 1ULL, 1);
      V v_t_24218;
      switch (heff_tag_of(v_x_24215)) {
      case TAG_At: {
        V v_s_24217 = heff_dup(heff_field(v_x_24215, 1));
        v_t_24218 = v_s_24217;
        break;
      }
      default: heff_nomatch(v_x_24215);
      }
      V v_x_24219 = heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24215}), v_t_24218});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24212_24Right, TAG_Right, 1, (V[]){v_x_24219}), v_st_24213});
    }
    default: return heff_nomatch(v_x11_24212);
    }
  }
  default: return heff_nomatch(v_x1_24211);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam15(V self, V *args) {
  V v_st_24224 = args[0];
  V v_m_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24225 = heff_tr(heff_call(v_m_24223, 1, (V[]){v_st_24224}));
  switch (heff_tag_of(v_x1_24225)) {
  case TAG_MkPair: {
    V v_x11_24226 = heff_field(v_x1_24225, 0);
    V v_st_24227 = heff_field(v_x1_24225, 1);
    V v_ru_24x1_24225_24MkPair = heff_take_reuse_n(v_x1_24225, 3ULL, 2);
    switch (heff_tag_of(v_x11_24226)) {
    case TAG_Left: {
      V v_e_24228 = heff_field(v_x11_24226, 0);
      heff_take_n(v_x11_24226, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24228}), v_st_24227});
    }
    case TAG_Right: {
      V v_x_24229 = heff_field(v_x11_24226, 0);
      V v_ru_24x11_24226_24Right = heff_take_reuse_n(v_x11_24226, 1ULL, 1);
      V v_t_24232;
      switch (heff_tag_of(v_x_24229)) {
      case TAG_At: {
        V v_s_24231 = heff_dup(heff_field(v_x_24229, 1));
        v_t_24232 = v_s_24231;
        break;
      }
      default: heff_nomatch(v_x_24229);
      }
      V v_x_24233 = heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24229}), v_t_24232});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24226_24Right, TAG_Right, 1, (V[]){v_x_24233}), v_st_24227});
    }
    default: return heff_nomatch(v_x11_24226);
    }
  }
  default: return heff_nomatch(v_x1_24225);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam16(V self, V *args) {
  V v_st_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_st_24237}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_MkPair: {
    V v_x11_24239 = heff_field(v_x1_24238, 0);
    V v_st_24240 = heff_field(v_x1_24238, 1);
    V v_ru_24x1_24238_24MkPair = heff_take_reuse_n(v_x1_24238, 3ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_Left: {
      V v_e_24241 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24241}), v_st_24240});
    }
    case TAG_Right: {
      V v_x_24242 = heff_field(v_x11_24239, 0);
      V v_ru_24x11_24239_24Right = heff_take_reuse_n(v_x11_24239, 1ULL, 1);
      V v_t_24245;
      switch (heff_tag_of(v_x_24242)) {
      case TAG_At: {
        V v_s_24244 = heff_dup(heff_field(v_x_24242, 1));
        v_t_24245 = v_s_24244;
        break;
      }
      default: heff_nomatch(v_x_24242);
      }
      V v_x_24246 = heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24242}), v_t_24245});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24239_24Right, TAG_Right, 1, (V[]){v_x_24246}), v_st_24240});
    }
    default: return heff_nomatch(v_x11_24239);
    }
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam17(V self, V *args) {
  V v_st_24250 = args[0];
  V v_m_24249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24251 = heff_tr(heff_call(v_m_24249, 1, (V[]){v_st_24250}));
  switch (heff_tag_of(v_x1_24251)) {
  case TAG_MkPair: {
    V v_x11_24252 = heff_field(v_x1_24251, 0);
    V v_st_24253 = heff_field(v_x1_24251, 1);
    V v_ru_24x1_24251_24MkPair = heff_take_reuse_n(v_x1_24251, 3ULL, 2);
    switch (heff_tag_of(v_x11_24252)) {
    case TAG_Left: {
      V v_e_24254 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24254}), v_st_24253});
    }
    case TAG_Right: {
      V v_x_24255 = heff_field(v_x11_24252, 0);
      V v_ru_24x11_24252_24Right = heff_take_reuse_n(v_x11_24252, 1ULL, 1);
      V v_t_24258;
      switch (heff_tag_of(v_x_24255)) {
      case TAG_At: {
        V v_s_24257 = heff_dup(heff_field(v_x_24255, 1));
        v_t_24258 = v_s_24257;
        break;
      }
      default: heff_nomatch(v_x_24255);
      }
      V v_x_24259 = heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24255}), v_t_24258});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24252_24Right, TAG_Right, 1, (V[]){v_x_24259}), v_st_24253});
    }
    default: return heff_nomatch(v_x11_24252);
    }
  }
  default: return heff_nomatch(v_x1_24251);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam18(V self, V *args) {
  V v_st_24264 = args[0];
  V v_m_24263 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24265 = heff_tr(heff_call(v_m_24263, 1, (V[]){v_st_24264}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_MkPair: {
    V v_x11_24266 = heff_field(v_x1_24265, 0);
    V v_st_24267 = heff_field(v_x1_24265, 1);
    V v_ru_24x1_24265_24MkPair = heff_take_reuse_n(v_x1_24265, 3ULL, 2);
    switch (heff_tag_of(v_x11_24266)) {
    case TAG_Left: {
      V v_e_24268 = heff_field(v_x11_24266, 0);
      heff_take_n(v_x11_24266, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24268}), v_st_24267});
    }
    case TAG_Right: {
      V v_x_24269 = heff_field(v_x11_24266, 0);
      V v_ru_24x11_24266_24Right = heff_take_reuse_n(v_x11_24266, 1ULL, 1);
      V v_t_24272;
      switch (heff_tag_of(v_x_24269)) {
      case TAG_At: {
        V v_s_24271 = heff_dup(heff_field(v_x_24269, 1));
        v_t_24272 = v_s_24271;
        break;
      }
      default: heff_nomatch(v_x_24269);
      }
      V v_x_24273 = heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24269}), v_t_24272});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24266_24Right, TAG_Right, 1, (V[]){v_x_24273}), v_st_24267});
    }
    default: return heff_nomatch(v_x11_24266);
    }
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam19(V self, V *args) {
  V v_st_24276 = args[0];
  V v_m_24275 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24277 = heff_tr(heff_call(v_m_24275, 1, (V[]){v_st_24276}));
  switch (heff_tag_of(v_x1_24277)) {
  case TAG_MkPair: {
    V v_x11_24278 = heff_field(v_x1_24277, 0);
    V v_st_24279 = heff_field(v_x1_24277, 1);
    V v_ru_24x1_24277_24MkPair = heff_take_reuse_n(v_x1_24277, 3ULL, 2);
    switch (heff_tag_of(v_x11_24278)) {
    case TAG_Left: {
      V v_e_24280 = heff_field(v_x11_24278, 0);
      heff_take_n(v_x11_24278, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24280}), v_st_24279});
    }
    case TAG_Right: {
      V v_x_24281 = heff_field(v_x11_24278, 0);
      V v_ru_24x11_24278_24Right = heff_take_reuse_n(v_x11_24278, 1ULL, 1);
      V v_t_24284;
      switch (heff_tag_of(v_x_24281)) {
      case TAG_At: {
        V v_s_24283 = heff_dup(heff_field(v_x_24281, 1));
        v_t_24284 = v_s_24283;
        break;
      }
      default: heff_nomatch(v_x_24281);
      }
      V v_x_24285 = heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24281}), v_t_24284});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24278_24Right, TAG_Right, 1, (V[]){v_x_24285}), v_st_24279});
    }
    default: return heff_nomatch(v_x11_24278);
    }
  }
  default: return heff_nomatch(v_x1_24277);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam20(V self, V *args) {
  V v_st_24290 = args[0];
  V v_m_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24291 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_st_24290}));
  switch (heff_tag_of(v_x1_24291)) {
  case TAG_MkPair: {
    V v_x11_24292 = heff_field(v_x1_24291, 0);
    V v_st_24293 = heff_field(v_x1_24291, 1);
    V v_ru_24x1_24291_24MkPair = heff_take_reuse_n(v_x1_24291, 3ULL, 2);
    switch (heff_tag_of(v_x11_24292)) {
    case TAG_Left: {
      V v_e_24294 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24294}), v_st_24293});
    }
    case TAG_Right: {
      V v_x_24295 = heff_field(v_x11_24292, 0);
      V v_ru_24x11_24292_24Right = heff_take_reuse_n(v_x11_24292, 1ULL, 1);
      V v_t_24298;
      switch (heff_tag_of(v_x_24295)) {
      case TAG_At: {
        V v_s_24297 = heff_dup(heff_field(v_x_24295, 1));
        v_t_24298 = v_s_24297;
        break;
      }
      default: heff_nomatch(v_x_24295);
      }
      V v_x_24299 = heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24295}), v_t_24298});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24292_24Right, TAG_Right, 1, (V[]){v_x_24299}), v_st_24293});
    }
    default: return heff_nomatch(v_x11_24292);
    }
  }
  default: return heff_nomatch(v_x1_24291);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam21(V self, V *args) {
  V v_st_24306 = args[0];
  V v_m_24305 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24307 = heff_tr(heff_call(v_m_24305, 1, (V[]){v_st_24306}));
  switch (heff_tag_of(v_x1_24307)) {
  case TAG_MkPair: {
    V v_x11_24308 = heff_field(v_x1_24307, 0);
    V v_st_24309 = heff_field(v_x1_24307, 1);
    V v_ru_24x1_24307_24MkPair = heff_take_reuse_n(v_x1_24307, 3ULL, 2);
    switch (heff_tag_of(v_x11_24308)) {
    case TAG_Left: {
      V v_e_24310 = heff_field(v_x11_24308, 0);
      heff_take_n(v_x11_24308, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24307_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24310}), v_st_24309});
    }
    case TAG_Right: {
      V v_x_24311 = heff_field(v_x11_24308, 0);
      V v_ru_24x11_24308_24Right = heff_take_reuse_n(v_x11_24308, 1ULL, 1);
      V v_t_24314;
      switch (heff_tag_of(v_x_24311)) {
      case TAG_At: {
        V v_s_24313 = heff_dup(heff_field(v_x_24311, 1));
        v_t_24314 = v_s_24313;
        break;
      }
      default: heff_nomatch(v_x_24311);
      }
      V v_x_24315 = heff_tag_at_n(v_ru_24x1_24307_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24311}), v_t_24314});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24308_24Right, TAG_Right, 1, (V[]){v_x_24315}), v_st_24309});
    }
    default: return heff_nomatch(v_x11_24308);
    }
  }
  default: return heff_nomatch(v_x1_24307);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam22(V self, V *args) {
  V v_st_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_st_24321}));
  switch (heff_tag_of(v_x1_24322)) {
  case TAG_MkPair: {
    V v_x11_24323 = heff_field(v_x1_24322, 0);
    V v_st_24324 = heff_field(v_x1_24322, 1);
    V v_ru_24x1_24322_24MkPair = heff_take_reuse_n(v_x1_24322, 3ULL, 2);
    switch (heff_tag_of(v_x11_24323)) {
    case TAG_Left: {
      V v_e_24325 = heff_field(v_x11_24323, 0);
      heff_take_n(v_x11_24323, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24325}), v_st_24324});
    }
    case TAG_Right: {
      V v_x_24326 = heff_field(v_x11_24323, 0);
      V v_ru_24x11_24323_24Right = heff_take_reuse_n(v_x11_24323, 1ULL, 1);
      V v_t_24329;
      switch (heff_tag_of(v_x_24326)) {
      case TAG_At: {
        V v_s_24328 = heff_dup(heff_field(v_x_24326, 1));
        v_t_24329 = v_s_24328;
        break;
      }
      default: heff_nomatch(v_x_24326);
      }
      V v_x_24330 = heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24326}), v_t_24329});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24323_24Right, TAG_Right, 1, (V[]){v_x_24330}), v_st_24324});
    }
    default: return heff_nomatch(v_x11_24323);
    }
  }
  default: return heff_nomatch(v_x1_24322);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam23(V self, V *args) {
  V v_st_24336 = args[0];
  V v_m_24335 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24337 = heff_tr(heff_call(v_m_24335, 1, (V[]){v_st_24336}));
  switch (heff_tag_of(v_x1_24337)) {
  case TAG_MkPair: {
    V v_x11_24338 = heff_field(v_x1_24337, 0);
    V v_st_24339 = heff_field(v_x1_24337, 1);
    V v_ru_24x1_24337_24MkPair = heff_take_reuse_n(v_x1_24337, 3ULL, 2);
    switch (heff_tag_of(v_x11_24338)) {
    case TAG_Left: {
      V v_e_24340 = heff_field(v_x11_24338, 0);
      heff_take_n(v_x11_24338, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24340}), v_st_24339});
    }
    case TAG_Right: {
      V v_x_24341 = heff_field(v_x11_24338, 0);
      V v_ru_24x11_24338_24Right = heff_take_reuse_n(v_x11_24338, 1ULL, 1);
      V v_t_24344;
      switch (heff_tag_of(v_x_24341)) {
      case TAG_At: {
        V v_s_24343 = heff_dup(heff_field(v_x_24341, 1));
        v_t_24344 = v_s_24343;
        break;
      }
      default: heff_nomatch(v_x_24341);
      }
      V v_x_24345 = heff_tag_at_n(v_ru_24x1_24337_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24341}), v_t_24344});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24338_24Right, TAG_Right, 1, (V[]){v_x_24345}), v_st_24339});
    }
    default: return heff_nomatch(v_x11_24338);
    }
  }
  default: return heff_nomatch(v_x1_24337);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam24(V self, V *args) {
  V v_st_24350 = args[0];
  V v_m_24349 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24351 = heff_tr(heff_call(v_m_24349, 1, (V[]){v_st_24350}));
  switch (heff_tag_of(v_x1_24351)) {
  case TAG_MkPair: {
    V v_x11_24352 = heff_field(v_x1_24351, 0);
    V v_st_24353 = heff_field(v_x1_24351, 1);
    V v_ru_24x1_24351_24MkPair = heff_take_reuse_n(v_x1_24351, 3ULL, 2);
    switch (heff_tag_of(v_x11_24352)) {
    case TAG_Left: {
      V v_e_24354 = heff_field(v_x11_24352, 0);
      heff_take_n(v_x11_24352, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24354}), v_st_24353});
    }
    case TAG_Right: {
      V v_x_24355 = heff_field(v_x11_24352, 0);
      V v_ru_24x11_24352_24Right = heff_take_reuse_n(v_x11_24352, 1ULL, 1);
      V v_t_24358;
      switch (heff_tag_of(v_x_24355)) {
      case TAG_At: {
        V v_s_24357 = heff_dup(heff_field(v_x_24355, 1));
        v_t_24358 = v_s_24357;
        break;
      }
      default: heff_nomatch(v_x_24355);
      }
      V v_x_24359 = heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24355}), v_t_24358});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24352_24Right, TAG_Right, 1, (V[]){v_x_24359}), v_st_24353});
    }
    default: return heff_nomatch(v_x11_24352);
    }
  }
  default: return heff_nomatch(v_x1_24351);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam25(V self, V *args) {
  V v_st_24367 = args[0];
  V v_m_24366 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24368 = heff_tr(heff_call(v_m_24366, 1, (V[]){v_st_24367}));
  switch (heff_tag_of(v_x1_24368)) {
  case TAG_MkPair: {
    V v_x11_24369 = heff_field(v_x1_24368, 0);
    V v_st_24370 = heff_field(v_x1_24368, 1);
    V v_ru_24x1_24368_24MkPair = heff_take_reuse_n(v_x1_24368, 3ULL, 2);
    switch (heff_tag_of(v_x11_24369)) {
    case TAG_Left: {
      V v_e_24371 = heff_field(v_x11_24369, 0);
      heff_take_n(v_x11_24369, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24368_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24371}), v_st_24370});
    }
    case TAG_Right: {
      V v_x_24372 = heff_field(v_x11_24369, 0);
      V v_ru_24x11_24369_24Right = heff_take_reuse_n(v_x11_24369, 1ULL, 1);
      V v_t_24375;
      switch (heff_tag_of(v_x_24372)) {
      case TAG_At: {
        V v_s_24374 = heff_dup(heff_field(v_x_24372, 1));
        v_t_24375 = v_s_24374;
        break;
      }
      default: heff_nomatch(v_x_24372);
      }
      V v_x_24376 = heff_tag_at_n(v_ru_24x1_24368_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24372}), v_t_24375});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24369_24Right, TAG_Right, 1, (V[]){v_x_24376}), v_st_24370});
    }
    default: return heff_nomatch(v_x11_24369);
    }
  }
  default: return heff_nomatch(v_x1_24368);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam26(V self, V *args) {
  V v_st_24380 = args[0];
  V v_m_24379 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24381 = heff_tr(heff_call(v_m_24379, 1, (V[]){v_st_24380}));
  switch (heff_tag_of(v_x1_24381)) {
  case TAG_MkPair: {
    V v_x11_24382 = heff_field(v_x1_24381, 0);
    V v_st_24383 = heff_field(v_x1_24381, 1);
    V v_ru_24x1_24381_24MkPair = heff_take_reuse_n(v_x1_24381, 3ULL, 2);
    switch (heff_tag_of(v_x11_24382)) {
    case TAG_Left: {
      V v_e_24384 = heff_field(v_x11_24382, 0);
      heff_take_n(v_x11_24382, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24384}), v_st_24383});
    }
    case TAG_Right: {
      V v_x_24385 = heff_field(v_x11_24382, 0);
      V v_ru_24x11_24382_24Right = heff_take_reuse_n(v_x11_24382, 1ULL, 1);
      V v_t_24388;
      switch (heff_tag_of(v_x_24385)) {
      case TAG_At: {
        V v_s_24387 = heff_dup(heff_field(v_x_24385, 1));
        v_t_24388 = v_s_24387;
        break;
      }
      default: heff_nomatch(v_x_24385);
      }
      V v_x_24389 = heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24385}), v_t_24388});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24382_24Right, TAG_Right, 1, (V[]){v_x_24389}), v_st_24383});
    }
    default: return heff_nomatch(v_x11_24382);
    }
  }
  default: return heff_nomatch(v_x1_24381);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam27(V self, V *args) {
  V v_st_24394 = args[0];
  V v_m_24393 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24395 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_st_24394}));
  switch (heff_tag_of(v_x1_24395)) {
  case TAG_MkPair: {
    V v_x11_24396 = heff_field(v_x1_24395, 0);
    V v_st_24397 = heff_field(v_x1_24395, 1);
    V v_ru_24x1_24395_24MkPair = heff_take_reuse_n(v_x1_24395, 3ULL, 2);
    switch (heff_tag_of(v_x11_24396)) {
    case TAG_Left: {
      V v_e_24398 = heff_field(v_x11_24396, 0);
      heff_take_n(v_x11_24396, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24398}), v_st_24397});
    }
    case TAG_Right: {
      V v_x_24399 = heff_field(v_x11_24396, 0);
      V v_ru_24x11_24396_24Right = heff_take_reuse_n(v_x11_24396, 1ULL, 1);
      V v_t_24402;
      switch (heff_tag_of(v_x_24399)) {
      case TAG_At: {
        V v_s_24401 = heff_dup(heff_field(v_x_24399, 1));
        v_t_24402 = v_s_24401;
        break;
      }
      default: heff_nomatch(v_x_24399);
      }
      V v_x_24403 = heff_tag_at_n(v_ru_24x1_24395_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24399}), v_t_24402});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24396_24Right, TAG_Right, 1, (V[]){v_x_24403}), v_st_24397});
    }
    default: return heff_nomatch(v_x11_24396);
    }
  }
  default: return heff_nomatch(v_x1_24395);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam28(V self, V *args) {
  V v_st_24411 = args[0];
  V v_m_24410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24412 = heff_tr(heff_call(v_m_24410, 1, (V[]){v_st_24411}));
  switch (heff_tag_of(v_x1_24412)) {
  case TAG_MkPair: {
    V v_x11_24413 = heff_field(v_x1_24412, 0);
    V v_st_24414 = heff_field(v_x1_24412, 1);
    V v_ru_24x1_24412_24MkPair = heff_take_reuse_n(v_x1_24412, 3ULL, 2);
    switch (heff_tag_of(v_x11_24413)) {
    case TAG_Left: {
      V v_e_24415 = heff_field(v_x11_24413, 0);
      heff_take_n(v_x11_24413, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24415}), v_st_24414});
    }
    case TAG_Right: {
      V v_x_24416 = heff_field(v_x11_24413, 0);
      V v_ru_24x11_24413_24Right = heff_take_reuse_n(v_x11_24413, 1ULL, 1);
      V v_t_24419;
      switch (heff_tag_of(v_x_24416)) {
      case TAG_At: {
        V v_s_24418 = heff_dup(heff_field(v_x_24416, 1));
        v_t_24419 = v_s_24418;
        break;
      }
      default: heff_nomatch(v_x_24416);
      }
      V v_x_24420 = heff_tag_at_n(v_ru_24x1_24412_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_24416}), v_t_24419});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24413_24Right, TAG_Right, 1, (V[]){v_x_24420}), v_st_24414});
    }
    default: return heff_nomatch(v_x11_24413);
    }
  }
  default: return heff_nomatch(v_x1_24412);
  }
}
Clo g_heff_2esyntax_2esurface_2esigL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigL_entry, 6, 0};

V g_heff_2esyntax_2esurface_2esigL(V v_r_240, V v_declared_241, V v_start_242, V v_names_243, V v_ty_244, V v_z_245) {
top: ;
  V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_ty_244)}));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_declared_241);
      heff_drop(v_start_242);
      heff_drop(v_ty_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2413 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_243));
      V v_f_2414 = heff_get_n(v_t_2413, 0, 2);
      V v_names_2415 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_x_2411)));
      V v_implicits_2416 = (g_heff_2esyntax_2esurface_2epiImplicits(heff_dup(v_x_2411)));
      V v_t_2417 = (g_heff_2esyntax_2esurface_2eaddBinders(heff_rec_n(3, shape_f__names__implicits, (V[]){v_f_2414, v_names_2415, v_implicits_2416}), v_st_249));
      V v_x1_2418 = heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, v_t_2417});
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_declared_241);
          heff_drop(v_start_242);
          heff_drop(v_ty_244);
          heff_drop(v_x_2411);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          V v_ru_24x11_2419_24Right = heff_take_reuse_n(v_x11_2419, 0ULL, 1);
          V v_t_2423 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_243));
          V v_t_2424 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_243));
          V v_t_2425 = (g_heff_2esyntax_2ecst_2elastE(v_ty_244));
          V v_b_2426 = heff_get_n(v_t_2425, 4, 9);
          V v_t_2427 = heff_tag_n(TAG_Sig, 5, (V[]){v_declared_241, heff_get_n(v_t_2423, 0, 2), heff_get_n(v_t_2424, 1, 2), v_x_2411, heff_rec_n(2, shape_start__end, (V[]){v_start_242, v_b_2426})});
          V v_x_2428 = heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2419_24Right, TAG_Right, 1, (V[]){v_x_2428}), v_st_2420});
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2esigL_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2esigL(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_x_241, 2)), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eedgesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eedgesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eedgesOf(V v_scope_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 1);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_scope_240, 2);
    heff_drop_rec(v_d_241, 8);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_op_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam0, 1, 2, (V[]){heff_dup(v_scope_240), heff_dup(v_op_243)}), heff_take_field(v_d_241, 2)));
    V v_t_2412 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2411));
    V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam2, 1, 1, (V[]){heff_dup(v_scope_240)}), heff_get_n(v_d_241, 3, 8)));
    V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam4, 1, 2, (V[]){v_scope_240, v_op_243}), v_t_2419));
    V v_t_2427 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2426));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2412, v_t_2427);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eedgesOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args) {
  V v_g_246 = args[0];
  V v_r_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_245, 1, 7)}));
  return ({ V a_0 = v_t_247; V b_1 = heff_get_n(v_g_246, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args) {
  V v_r_245 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_248 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam1, 1, 1, (V[]){v_r_245}); V b_1 = heff_get_n(v_scope_240, 0, 2); V r_ = (g_heff_2esyntax_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    heff_drop_rec(v_op_243, 7);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_g_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Just = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    V v_t_2410 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_op_243, 1, 7), heff_get_n(v_g_249, 0, 5)});
    return heff_tag_at_n(v_ru_24x2_248_24Just, TAG_Just, 1, (V[]){v_t_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args) {
  V v_g_2414 = args[0];
  V v_r_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2413, 1, 7)}));
  return ({ V a_0 = v_t_2415; V b_1 = heff_get_n(v_g_2414, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args) {
  V v_r_2413 = args[0];
  V v_scope_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam3, 1, 1, (V[]){v_r_2413}); V b_1 = heff_get_n(v_scope_240, 0, 2); V r_ = (g_heff_2esyntax_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2418;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nothing: {
    v_x1_2418 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_g_2417 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_x1_2418 = heff_get_n(v_g_2417, 3, 5);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
  heff_drop(v_x1_2418);
  return v_ret_24bool;
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args) {
  V v_g_2421 = args[0];
  V v_r_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2420, 1, 7)}));
  return ({ V a_0 = v_t_2422; V b_1 = heff_get_n(v_g_2421, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args) {
  V v_r_2420 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam5, 1, 1, (V[]){v_r_2420}); V b_1 = heff_get_n(v_scope_240, 0, 2); V r_ = (g_heff_2esyntax_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nothing: {
    heff_drop_rec(v_op_243, 7);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_g_2424 = heff_field(v_x2_2423, 0);
    V v_ru_24x2_2423_24Just = heff_take_reuse_n(v_x2_2423, 1ULL, 1);
    V v_t_2425 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_g_2424, 0, 5), heff_get_n(v_op_243, 1, 7)});
    return heff_tag_at_n(v_ru_24x2_2423_24Just, TAG_Just, 1, (V[]){v_t_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V v_c_240, V v_args_241) {
top: ;
  V v_m_242 = (g_heff_2esyntax_2esurface_2etraverseS(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 0)), v_args_241));
  return heff_clo_n(g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0, 1, 2, (V[]){v_m_242, v_c_240});
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_c_240, 9);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_t_249 = heff_tag_at_n(v_ru_24x11_245_24Right, TAG_ETag, 1, (V[]){heff_dup(heff_rfield(v_c_240, 1))});
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_240, 3), heff_get_n(v_c_240, 4, 9)});
      V v_x_2411 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_At, 2, (V[]){v_t_249, v_t_2410}), v_x_248));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2411}), v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V v_decls_240, V v_groups_241, V v_edges_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_241)));
  V v_t_244 = (g_heff_2esyntax_2efixity_2enubByG(v_t_243));
  V v_t_245 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_246 = (g_heff_2esyntax_2efixity_2enubByE(v_t_245));
  V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_241)));
  V v_t_248 = (g_heff_2esyntax_2efixity_2enubByG(v_t_247));
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_edges_242)));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByE(v_t_249));
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_clo), 2, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_t_244, v_t_246}), heff_rec_n(2, shape_groups__above, (V[]){v_t_248, v_t_2410})}));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2econcatMapS(v_t_2411, v_decls_240));
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_241, v_edges_242}), v_t_2412});
}
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_s_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_s_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0), v_t_246, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1)})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(a[0], a[1]);
}