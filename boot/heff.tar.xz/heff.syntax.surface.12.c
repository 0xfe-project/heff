// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadFieldSet 46507
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_f 320
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_implicits 1321238867
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_name__span__ty__eqns__whole[] = {LBL_name, LBL_span, LBL_ty, LBL_eqns, LBL_whole};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V, V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V);
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo;
V g_heff_2esyntax_2esurface_2eknotOf(V, V);
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotOf_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V, V);
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24s1266236307x1641993968_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2104173076x1668056829(V);
V g_list_2emap_24s2104173076x1668056829_entry(V self, V *a);
extern Clo g_list_2emap_24s2104173076x1668056829_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);

HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  V v_sc_243 = (g_heff_2esyntax_2esurface_2eappendS(v_xs_240, heff_dup(heff_rfield(v_st_242, 1))));
  V v_t_244 = heff_rec_n(9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, (V[]){heff_take_field(v_st_242, 0), v_sc_243, heff_take_field(v_st_242, 2), heff_take_field(v_st_242, 3), heff_take_field(v_st_242, 4), heff_take_field(v_st_242, 5), heff_take_field(v_st_242, 6), heff_take_field(v_st_242, 7), heff_take_field(v_st_242, 8)});
  V v_x1_245 = heff_tr(heff_call(v_p_241, 1, (V[]){v_t_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Left = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      heff_drop_rec(v_st_242, 9);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_246_24Left, TAG_Left, 1, (V[]){v_e_248}), v_st_247}});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_f_2410 = ({ V rv_1 = heff_get_n(v_st_242, 1, 9); V rr_ = heff_rec_reuse_nf(v_st_247, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_x_249}), v_f_2410}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
  }
}
Clo g_heff_2esyntax_2esurface_2ewithScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewithScope_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ewithScope(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_xs_240, v_p_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewithScope(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eblock_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eblock(V v_f_240, V v_xs_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2eblock_24cpr(v_f_240, v_xs_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eblock(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eboundBy_24dps(V v_pv_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_244));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_241, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 1)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str2))) {
          V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
          V v_t_2412 = (g_list_2eany(v_t_2411, v_pv_240));
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
            return heff_setField(v_d_242, MK_INT(1LL), v_t_2413);
          } else {
            heff_drop(v_t_2412);
            return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
          }
        } else {
          return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
        }
      } else {
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
        return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str3))) {
        V v_t_2416 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
        V v_t_2417 = (g_list_2eany(v_t_2416, v_pv_240));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_t_2417);
          V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
          return heff_setField(v_d_242, MK_INT(1LL), v_t_2418);
        } else {
          heff_drop(v_t_2417);
          return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
        }
      } else {
        return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  case TAG_PParen: {
    V v_q_2420 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2420;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2423 = heff_field(v_x2_241, 1);
    V v_t_2427 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2423));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2427);
  }
  case TAG_POp: {
    V v_l_2428 = heff_field(v_x2_241, 0);
    V v_q_2430 = heff_field(v_x2_241, 2);
    V v_t_2431 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2428));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2430));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2431, v_t_2432));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2433);
  }
  case TAG_PRec: {
    V v_fs_2435 = heff_field(v_x2_241, 1);
    V v_t_2439 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2435));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2439);
  }
  case TAG_PField: {
    V v_q_2442 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2442;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2443 = heff_field(v_x2_241, 0);
    V v_q_2445 = heff_field(v_x2_241, 2);
    V v_cell_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2443, 1)), heff_hole()});
    V v_u_2447 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2446));
    heff_drop(v_u_2447);
    V t_0 = v_pv_240;
    V t_1 = v_q_2445;
    V t_2 = v_cell_2446;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2448 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2448;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy_24dps(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args) {
  V v_q_2426 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2426; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2426); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args) {
  V v_q_2438 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2438; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2438); r_; });
}
Clo g_heff_2esyntax_2esurface_2easNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2easNameE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_EVar, 1, (V[]){v_x_245}), v_sp_242});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EBreak: {
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EContinue: {
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_EIfLet: {
      heff_take_n(v_e1_241, 0ULL, 4);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      return v_e_240;
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easNameE(a[0]);
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EParen: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Named: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Tup: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Seg: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Braces: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Update: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_InstB: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Sum: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ECon: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EField: {
    V v_e_2449 = heff_field(v_x1_240, 0);
    V v_f_2450 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EField = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_e_2449;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24EField, TAG_Cons, 2, (V[]){v_f_2450, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_App: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Op: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Ops: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Ann: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_BVar: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_BImp: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Lam: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Case: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_If: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Do: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ELet: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EFor: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EJump: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ENest: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ELetCond: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ETry: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam40(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esettingL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esettingL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esettingL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam1, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam2, 1, 1, (V[]){v_m_2433});
  }
  case TAG_Tup: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam3, 1, 1, (V[]){v_m_2448});
  }
  case TAG_Seg: {
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam4, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Braces: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam5, 1, 1, (V[]){v_m_2477});
  }
  case TAG_Update: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam6, 1, 1, (V[]){v_m_2494});
  }
  case TAG_EUSet: {
    V v_m_24108 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam7, 1, 1, (V[]){v_m_24108});
  }
  case TAG_InstB: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam8, 1, 1, (V[]){v_m_24124});
  }
  case TAG_EFSet: {
    V v_x_24135 = heff_field(v_x2_241, 0);
    V v_e_24137 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_m_24138 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24137}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam9, 1, 2, (V[]){v_m_24138, v_x_24135});
  }
  case TAG_EFDefault: {
    V v_m_24155 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam10, 1, 1, (V[]){v_m_24155});
  }
  case TAG_Sum: {
    V v_m_24171 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam11, 1, 1, (V[]){v_m_24171});
  }
  case TAG_ECon: {
    V v_m_24184 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam12, 1, 1, (V[]){v_m_24184});
  }
  case TAG_EField: {
    V v_m_24197 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam13, 1, 1, (V[]){v_m_24197});
  }
  case TAG_ENeg: {
    V v_m_24210 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam14, 1, 1, (V[]){v_m_24210});
  }
  case TAG_App: {
    V v_m_24223 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam15, 1, 1, (V[]){v_m_24223});
  }
  case TAG_Op: {
    V v_m_24237 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam16, 1, 1, (V[]){v_m_24237});
  }
  case TAG_Ops: {
    V v_m_24250 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam17, 1, 1, (V[]){v_m_24250});
  }
  case TAG_OpRhs: {
    V v_m_24263 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam18, 1, 1, (V[]){v_m_24263});
  }
  case TAG_Ann: {
    V v_m_24277 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam19, 1, 1, (V[]){v_m_24277});
  }
  case TAG_BVar: {
    V v_m_24289 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam20, 1, 1, (V[]){v_m_24289});
  }
  case TAG_BImp: {
    V v_m_24303 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam21, 1, 1, (V[]){v_m_24303});
  }
  case TAG_BAnn: {
    V v_m_24319 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam22, 1, 1, (V[]){v_m_24319});
  }
  case TAG_Lam: {
    V v_m_24334 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam23, 1, 1, (V[]){v_m_24334});
  }
  case TAG_Case: {
    V v_m_24349 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam24, 1, 1, (V[]){v_m_24349});
  }
  case TAG_EAlt: {
    V v_m_24363 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam25, 1, 1, (V[]){v_m_24363});
  }
  case TAG_If: {
    V v_m_24380 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam26, 1, 1, (V[]){v_m_24380});
  }
  case TAG_Do: {
    V v_m_24393 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam27, 1, 1, (V[]){v_m_24393});
  }
  case TAG_ESBind: {
    V v_m_24407 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam28, 1, 1, (V[]){v_m_24407});
  }
  case TAG_ELet: {
    V v_m_24424 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam29, 1, 1, (V[]){v_m_24424});
  }
  case TAG_ELetMut: {
    V v_m_24441 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam30, 1, 1, (V[]){v_m_24441});
  }
  case TAG_EAssign: {
    V v_m_24455 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam31, 1, 1, (V[]){v_m_24455});
  }
  case TAG_EWhile: {
    V v_m_24470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam32, 1, 1, (V[]){v_m_24470});
  }
  case TAG_EFor: {
    V v_m_24487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam33, 1, 1, (V[]){v_m_24487});
  }
  case TAG_EJump: {
    V v_m_24499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam34, 1, 1, (V[]){v_m_24499});
  }
  case TAG_EReturn: {
    V v_m_24512 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam35, 1, 1, (V[]){v_m_24512});
  }
  case TAG_ENest: {
    V v_m_24527 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam36, 1, 1, (V[]){v_m_24527});
  }
  case TAG_IfThen: {
    V v_m_24542 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam37, 1, 1, (V[]){v_m_24542});
  }
  case TAG_ELetCond: {
    V v_m_24557 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam38, 1, 1, (V[]){v_m_24557});
  }
  case TAG_ETry: {
    V v_m_24572 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam39, 1, 1, (V[]){v_m_24572});
  }
  case TAG_ECatch: {
    V v_m_24587 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam40, 1, 1, (V[]){v_m_24587});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esettingL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_x_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_BadFieldSet, 1, (V[]){v_x_249}), v_t_2412});
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_x_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2423}), v_t_2426});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      heff_take_n(v_x11_2436, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_x_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_x_2439, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_x_2439);
      }
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2439}), v_t_2442});
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_st_2437});
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam3(V self, V *args) {
  V v_st_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2449}));
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_MkPair: {
    V v_x11_2451 = heff_field(v_x1_2450, 0);
    V v_st_2452 = heff_field(v_x1_2450, 1);
    V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_Left: {
      V v_e_2453 = heff_field(v_x11_2451, 0);
      heff_take_n(v_x11_2451, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_x11_2451, 0);
      V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_x_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2454}), v_t_2457});
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_st_2452});
    }
    default: return heff_nomatch(v_x11_2451);
    }
  }
  default: return heff_nomatch(v_x1_2450);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      V v_ru_24x11_2465_24Right = heff_take_reuse_n(v_x11_2465, 1ULL, 1);
      V v_t_2471;
      switch (heff_tag_of(v_x_2468)) {
      case TAG_At: {
        V v_s_2470 = heff_dup(heff_field(v_x_2468, 1));
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_x_2468);
      }
      V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2465_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2468}), v_t_2471});
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2472}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam5(V self, V *args) {
  V v_st_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_st_2478}));
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_MkPair: {
    V v_x11_2480 = heff_field(v_x1_2479, 0);
    V v_st_2481 = heff_field(v_x1_2479, 1);
    V v_ru_24x1_2479_24MkPair = heff_take_reuse_n(v_x1_2479, 3ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_Left: {
      V v_e_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2482}), v_st_2481});
    }
    case TAG_Right: {
      V v_x_2483 = heff_field(v_x11_2480, 0);
      V v_ru_24x11_2480_24Right = heff_take_reuse_n(v_x11_2480, 1ULL, 1);
      V v_t_2486;
      switch (heff_tag_of(v_x_2483)) {
      case TAG_At: {
        V v_s_2485 = heff_dup(heff_field(v_x_2483, 1));
        v_t_2486 = v_s_2485;
        break;
      }
      default: heff_nomatch(v_x_2483);
      }
      V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2480_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2483}), v_t_2486});
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2487}), v_st_2481});
    }
    default: return heff_nomatch(v_x11_2480);
    }
  }
  default: return heff_nomatch(v_x1_2479);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam6(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24103;
      switch (heff_tag_of(v_x_24100)) {
      case TAG_At: {
        V v_s_24102 = heff_dup(heff_field(v_x_24100, 1));
        v_t_24103 = v_s_24102;
        break;
      }
      default: heff_nomatch(v_x_24100);
      }
      V v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24100}), v_t_24103});
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24104}), v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam7(V self, V *args) {
  V v_st_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_24109}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_MkPair: {
    V v_x11_24111 = heff_field(v_x1_24110, 0);
    V v_st_24112 = heff_field(v_x1_24110, 1);
    V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
    switch (heff_tag_of(v_x11_24111)) {
    case TAG_Left: {
      V v_e_24113 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
    }
    case TAG_Right: {
      V v_x_24114 = heff_field(v_x11_24111, 0);
      V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 1ULL, 1);
      V v_t_24117;
      switch (heff_tag_of(v_x_24114)) {
      case TAG_At: {
        V v_s_24116 = heff_dup(heff_field(v_x_24114, 1));
        v_t_24117 = v_s_24116;
        break;
      }
      default: heff_nomatch(v_x_24114);
      }
      V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24114}), v_t_24117});
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24118}), v_st_24112});
    }
    default: return heff_nomatch(v_x11_24111);
    }
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam8(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24133;
      switch (heff_tag_of(v_x_24130)) {
      case TAG_At: {
        V v_s_24132 = heff_dup(heff_field(v_x_24130, 1));
        v_t_24133 = v_s_24132;
        break;
      }
      default: heff_nomatch(v_x_24130);
      }
      V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24130}), v_t_24133});
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24134}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam9(V self, V *args) {
  V v_st_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  V v_x_24135 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_st_24139}));
  switch (heff_tag_of(v_x1_24140)) {
  case TAG_MkPair: {
    V v_x11_24141 = heff_field(v_x1_24140, 0);
    V v_st_24142 = heff_field(v_x1_24140, 1);
    V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
    switch (heff_tag_of(v_x11_24141)) {
    case TAG_Left: {
      V v_e_24143 = heff_field(v_x11_24141, 0);
      heff_take_n(v_x11_24141, 1ULL, 1);
      heff_drop_rec(v_x_24135, 9);
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24143}), v_st_24142});
    }
    case TAG_Right: {
      V v_x_24144 = heff_field(v_x11_24141, 0);
      V v_ru_24x11_24141_24Right = heff_take_reuse_n(v_x11_24141, 1ULL, 1);
      V v_t_24145 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24135, 3)), heff_take_field(v_x_24135, 4)});
      V v_t_24146 = heff_tag_n(TAG_SetField, 3, (V[]){heff_take_field(v_x_24135, 1), v_t_24145, heff_dup(v_x_24144)});
      V v_t_24149;
      switch (heff_tag_of(v_x_24144)) {
      case TAG_At: {
        V v_s_24148 = heff_field(v_x_24144, 1);
        heff_take_n(v_x_24144, 2ULL, 2);
        v_t_24149 = v_s_24148;
        break;
      }
      default: heff_nomatch(v_x_24144);
      }
      V v_t_24150 = ({ V rv_0 = heff_get_n(v_x_24135, 3, 9); V rr_ = heff_rec_reuse_nf(v_t_24149, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24151 = heff_tag_at_n(v_ru_24x11_24141_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24146, v_t_24150})});
      return heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_MkPair, 2, (V[]){v_t_24151, v_st_24142});
    }
    default: return heff_nomatch(v_x11_24141);
    }
  }
  default: return heff_nomatch(v_x1_24140);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam10(V self, V *args) {
  V v_st_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_st_24156}));
  switch (heff_tag_of(v_x1_24157)) {
  case TAG_MkPair: {
    V v_x11_24158 = heff_field(v_x1_24157, 0);
    V v_st_24159 = heff_field(v_x1_24157, 1);
    V v_ru_24x1_24157_24MkPair = heff_take_reuse_n(v_x1_24157, 3ULL, 2);
    switch (heff_tag_of(v_x11_24158)) {
    case TAG_Left: {
      V v_e_24160 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24160}), v_st_24159});
    }
    case TAG_Right: {
      V v_x_24161 = heff_field(v_x11_24158, 0);
      V v_ru_24x11_24158_24Right = heff_take_reuse_n(v_x11_24158, 1ULL, 1);
      V v_t_24164;
      switch (heff_tag_of(v_x_24161)) {
      case TAG_At: {
        V v_s_24163 = heff_dup(heff_field(v_x_24161, 1));
        v_t_24164 = v_s_24163;
        break;
      }
      default: heff_nomatch(v_x_24161);
      }
      V v_t_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24158_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24161}), v_t_24164});
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24165}), v_st_24159});
    }
    default: return heff_nomatch(v_x11_24158);
    }
  }
  default: return heff_nomatch(v_x1_24157);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam11(V self, V *args) {
  V v_st_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24173 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_st_24172}));
  switch (heff_tag_of(v_x1_24173)) {
  case TAG_MkPair: {
    V v_x11_24174 = heff_field(v_x1_24173, 0);
    V v_st_24175 = heff_field(v_x1_24173, 1);
    V v_ru_24x1_24173_24MkPair = heff_take_reuse_n(v_x1_24173, 3ULL, 2);
    switch (heff_tag_of(v_x11_24174)) {
    case TAG_Left: {
      V v_e_24176 = heff_field(v_x11_24174, 0);
      heff_take_n(v_x11_24174, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24176}), v_st_24175});
    }
    case TAG_Right: {
      V v_x_24177 = heff_field(v_x11_24174, 0);
      V v_ru_24x11_24174_24Right = heff_take_reuse_n(v_x11_24174, 1ULL, 1);
      V v_t_24180;
      switch (heff_tag_of(v_x_24177)) {
      case TAG_At: {
        V v_s_24179 = heff_dup(heff_field(v_x_24177, 1));
        v_t_24180 = v_s_24179;
        break;
      }
      default: heff_nomatch(v_x_24177);
      }
      V v_t_24181 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24174_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24177}), v_t_24180});
      return heff_tag_at_n(v_ru_24x1_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24181}), v_st_24175});
    }
    default: return heff_nomatch(v_x11_24174);
    }
  }
  default: return heff_nomatch(v_x1_24173);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam12(V self, V *args) {
  V v_st_24185 = args[0];
  V v_m_24184 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24186 = heff_tr(heff_call(v_m_24184, 1, (V[]){v_st_24185}));
  switch (heff_tag_of(v_x1_24186)) {
  case TAG_MkPair: {
    V v_x11_24187 = heff_field(v_x1_24186, 0);
    V v_st_24188 = heff_field(v_x1_24186, 1);
    V v_ru_24x1_24186_24MkPair = heff_take_reuse_n(v_x1_24186, 3ULL, 2);
    switch (heff_tag_of(v_x11_24187)) {
    case TAG_Left: {
      V v_e_24189 = heff_field(v_x11_24187, 0);
      heff_take_n(v_x11_24187, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24186_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24189}), v_st_24188});
    }
    case TAG_Right: {
      V v_x_24190 = heff_field(v_x11_24187, 0);
      V v_ru_24x11_24187_24Right = heff_take_reuse_n(v_x11_24187, 1ULL, 1);
      V v_t_24193;
      switch (heff_tag_of(v_x_24190)) {
      case TAG_At: {
        V v_s_24192 = heff_dup(heff_field(v_x_24190, 1));
        v_t_24193 = v_s_24192;
        break;
      }
      default: heff_nomatch(v_x_24190);
      }
      V v_t_24194 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24187_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24190}), v_t_24193});
      return heff_tag_at_n(v_ru_24x1_24186_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24194}), v_st_24188});
    }
    default: return heff_nomatch(v_x11_24187);
    }
  }
  default: return heff_nomatch(v_x1_24186);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam13(V self, V *args) {
  V v_st_24198 = args[0];
  V v_m_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24199 = heff_tr(heff_call(v_m_24197, 1, (V[]){v_st_24198}));
  switch (heff_tag_of(v_x1_24199)) {
  case TAG_MkPair: {
    V v_x11_24200 = heff_field(v_x1_24199, 0);
    V v_st_24201 = heff_field(v_x1_24199, 1);
    V v_ru_24x1_24199_24MkPair = heff_take_reuse_n(v_x1_24199, 3ULL, 2);
    switch (heff_tag_of(v_x11_24200)) {
    case TAG_Left: {
      V v_e_24202 = heff_field(v_x11_24200, 0);
      heff_take_n(v_x11_24200, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24199_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24202}), v_st_24201});
    }
    case TAG_Right: {
      V v_x_24203 = heff_field(v_x11_24200, 0);
      V v_ru_24x11_24200_24Right = heff_take_reuse_n(v_x11_24200, 1ULL, 1);
      V v_t_24206;
      switch (heff_tag_of(v_x_24203)) {
      case TAG_At: {
        V v_s_24205 = heff_dup(heff_field(v_x_24203, 1));
        v_t_24206 = v_s_24205;
        break;
      }
      default: heff_nomatch(v_x_24203);
      }
      V v_t_24207 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24200_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24203}), v_t_24206});
      return heff_tag_at_n(v_ru_24x1_24199_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24207}), v_st_24201});
    }
    default: return heff_nomatch(v_x11_24200);
    }
  }
  default: return heff_nomatch(v_x1_24199);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam14(V self, V *args) {
  V v_st_24211 = args[0];
  V v_m_24210 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24212 = heff_tr(heff_call(v_m_24210, 1, (V[]){v_st_24211}));
  switch (heff_tag_of(v_x1_24212)) {
  case TAG_MkPair: {
    V v_x11_24213 = heff_field(v_x1_24212, 0);
    V v_st_24214 = heff_field(v_x1_24212, 1);
    V v_ru_24x1_24212_24MkPair = heff_take_reuse_n(v_x1_24212, 3ULL, 2);
    switch (heff_tag_of(v_x11_24213)) {
    case TAG_Left: {
      V v_e_24215 = heff_field(v_x11_24213, 0);
      heff_take_n(v_x11_24213, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24212_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24215}), v_st_24214});
    }
    case TAG_Right: {
      V v_x_24216 = heff_field(v_x11_24213, 0);
      V v_ru_24x11_24213_24Right = heff_take_reuse_n(v_x11_24213, 1ULL, 1);
      V v_t_24219;
      switch (heff_tag_of(v_x_24216)) {
      case TAG_At: {
        V v_s_24218 = heff_dup(heff_field(v_x_24216, 1));
        v_t_24219 = v_s_24218;
        break;
      }
      default: heff_nomatch(v_x_24216);
      }
      V v_t_24220 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24213_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24216}), v_t_24219});
      return heff_tag_at_n(v_ru_24x1_24212_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24220}), v_st_24214});
    }
    default: return heff_nomatch(v_x11_24213);
    }
  }
  default: return heff_nomatch(v_x1_24212);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam15(V self, V *args) {
  V v_st_24224 = args[0];
  V v_m_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24225 = heff_tr(heff_call(v_m_24223, 1, (V[]){v_st_24224}));
  switch (heff_tag_of(v_x1_24225)) {
  case TAG_MkPair: {
    V v_x11_24226 = heff_field(v_x1_24225, 0);
    V v_st_24227 = heff_field(v_x1_24225, 1);
    V v_ru_24x1_24225_24MkPair = heff_take_reuse_n(v_x1_24225, 3ULL, 2);
    switch (heff_tag_of(v_x11_24226)) {
    case TAG_Left: {
      V v_e_24228 = heff_field(v_x11_24226, 0);
      heff_take_n(v_x11_24226, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24228}), v_st_24227});
    }
    case TAG_Right: {
      V v_x_24229 = heff_field(v_x11_24226, 0);
      V v_ru_24x11_24226_24Right = heff_take_reuse_n(v_x11_24226, 1ULL, 1);
      V v_t_24232;
      switch (heff_tag_of(v_x_24229)) {
      case TAG_At: {
        V v_s_24231 = heff_dup(heff_field(v_x_24229, 1));
        v_t_24232 = v_s_24231;
        break;
      }
      default: heff_nomatch(v_x_24229);
      }
      V v_t_24233 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24226_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24229}), v_t_24232});
      return heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24233}), v_st_24227});
    }
    default: return heff_nomatch(v_x11_24226);
    }
  }
  default: return heff_nomatch(v_x1_24225);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam16(V self, V *args) {
  V v_st_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24239 = heff_tr(heff_call(v_m_24237, 1, (V[]){v_st_24238}));
  switch (heff_tag_of(v_x1_24239)) {
  case TAG_MkPair: {
    V v_x11_24240 = heff_field(v_x1_24239, 0);
    V v_st_24241 = heff_field(v_x1_24239, 1);
    V v_ru_24x1_24239_24MkPair = heff_take_reuse_n(v_x1_24239, 3ULL, 2);
    switch (heff_tag_of(v_x11_24240)) {
    case TAG_Left: {
      V v_e_24242 = heff_field(v_x11_24240, 0);
      heff_take_n(v_x11_24240, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24242}), v_st_24241});
    }
    case TAG_Right: {
      V v_x_24243 = heff_field(v_x11_24240, 0);
      V v_ru_24x11_24240_24Right = heff_take_reuse_n(v_x11_24240, 1ULL, 1);
      V v_t_24246;
      switch (heff_tag_of(v_x_24243)) {
      case TAG_At: {
        V v_s_24245 = heff_dup(heff_field(v_x_24243, 1));
        v_t_24246 = v_s_24245;
        break;
      }
      default: heff_nomatch(v_x_24243);
      }
      V v_t_24247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24240_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24243}), v_t_24246});
      return heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24247}), v_st_24241});
    }
    default: return heff_nomatch(v_x11_24240);
    }
  }
  default: return heff_nomatch(v_x1_24239);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam17(V self, V *args) {
  V v_st_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_st_24251}));
  switch (heff_tag_of(v_x1_24252)) {
  case TAG_MkPair: {
    V v_x11_24253 = heff_field(v_x1_24252, 0);
    V v_st_24254 = heff_field(v_x1_24252, 1);
    V v_ru_24x1_24252_24MkPair = heff_take_reuse_n(v_x1_24252, 3ULL, 2);
    switch (heff_tag_of(v_x11_24253)) {
    case TAG_Left: {
      V v_e_24255 = heff_field(v_x11_24253, 0);
      heff_take_n(v_x11_24253, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24255}), v_st_24254});
    }
    case TAG_Right: {
      V v_x_24256 = heff_field(v_x11_24253, 0);
      V v_ru_24x11_24253_24Right = heff_take_reuse_n(v_x11_24253, 1ULL, 1);
      V v_t_24259;
      switch (heff_tag_of(v_x_24256)) {
      case TAG_At: {
        V v_s_24258 = heff_dup(heff_field(v_x_24256, 1));
        v_t_24259 = v_s_24258;
        break;
      }
      default: heff_nomatch(v_x_24256);
      }
      V v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24253_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24256}), v_t_24259});
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24260}), v_st_24254});
    }
    default: return heff_nomatch(v_x11_24253);
    }
  }
  default: return heff_nomatch(v_x1_24252);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam18(V self, V *args) {
  V v_st_24264 = args[0];
  V v_m_24263 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24265 = heff_tr(heff_call(v_m_24263, 1, (V[]){v_st_24264}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_MkPair: {
    V v_x11_24266 = heff_field(v_x1_24265, 0);
    V v_st_24267 = heff_field(v_x1_24265, 1);
    V v_ru_24x1_24265_24MkPair = heff_take_reuse_n(v_x1_24265, 3ULL, 2);
    switch (heff_tag_of(v_x11_24266)) {
    case TAG_Left: {
      V v_e_24268 = heff_field(v_x11_24266, 0);
      heff_take_n(v_x11_24266, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24268}), v_st_24267});
    }
    case TAG_Right: {
      V v_x_24269 = heff_field(v_x11_24266, 0);
      V v_ru_24x11_24266_24Right = heff_take_reuse_n(v_x11_24266, 1ULL, 1);
      V v_t_24272;
      switch (heff_tag_of(v_x_24269)) {
      case TAG_At: {
        V v_s_24271 = heff_dup(heff_field(v_x_24269, 1));
        v_t_24272 = v_s_24271;
        break;
      }
      default: heff_nomatch(v_x_24269);
      }
      V v_t_24273 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24266_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24269}), v_t_24272});
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24273}), v_st_24267});
    }
    default: return heff_nomatch(v_x11_24266);
    }
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam19(V self, V *args) {
  V v_st_24278 = args[0];
  V v_m_24277 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24279 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_st_24278}));
  switch (heff_tag_of(v_x1_24279)) {
  case TAG_MkPair: {
    V v_x11_24280 = heff_field(v_x1_24279, 0);
    V v_st_24281 = heff_field(v_x1_24279, 1);
    V v_ru_24x1_24279_24MkPair = heff_take_reuse_n(v_x1_24279, 3ULL, 2);
    switch (heff_tag_of(v_x11_24280)) {
    case TAG_Left: {
      V v_e_24282 = heff_field(v_x11_24280, 0);
      heff_take_n(v_x11_24280, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24282}), v_st_24281});
    }
    case TAG_Right: {
      V v_x_24283 = heff_field(v_x11_24280, 0);
      V v_ru_24x11_24280_24Right = heff_take_reuse_n(v_x11_24280, 1ULL, 1);
      V v_t_24286;
      switch (heff_tag_of(v_x_24283)) {
      case TAG_At: {
        V v_s_24285 = heff_dup(heff_field(v_x_24283, 1));
        v_t_24286 = v_s_24285;
        break;
      }
      default: heff_nomatch(v_x_24283);
      }
      V v_t_24287 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24280_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24283}), v_t_24286});
      return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24287}), v_st_24281});
    }
    default: return heff_nomatch(v_x11_24280);
    }
  }
  default: return heff_nomatch(v_x1_24279);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam20(V self, V *args) {
  V v_st_24290 = args[0];
  V v_m_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24291 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_st_24290}));
  switch (heff_tag_of(v_x1_24291)) {
  case TAG_MkPair: {
    V v_x11_24292 = heff_field(v_x1_24291, 0);
    V v_st_24293 = heff_field(v_x1_24291, 1);
    V v_ru_24x1_24291_24MkPair = heff_take_reuse_n(v_x1_24291, 3ULL, 2);
    switch (heff_tag_of(v_x11_24292)) {
    case TAG_Left: {
      V v_e_24294 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24294}), v_st_24293});
    }
    case TAG_Right: {
      V v_x_24295 = heff_field(v_x11_24292, 0);
      V v_ru_24x11_24292_24Right = heff_take_reuse_n(v_x11_24292, 1ULL, 1);
      V v_t_24298;
      switch (heff_tag_of(v_x_24295)) {
      case TAG_At: {
        V v_s_24297 = heff_dup(heff_field(v_x_24295, 1));
        v_t_24298 = v_s_24297;
        break;
      }
      default: heff_nomatch(v_x_24295);
      }
      V v_t_24299 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24292_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24295}), v_t_24298});
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24299}), v_st_24293});
    }
    default: return heff_nomatch(v_x11_24292);
    }
  }
  default: return heff_nomatch(v_x1_24291);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam21(V self, V *args) {
  V v_st_24304 = args[0];
  V v_m_24303 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24305 = heff_tr(heff_call(v_m_24303, 1, (V[]){v_st_24304}));
  switch (heff_tag_of(v_x1_24305)) {
  case TAG_MkPair: {
    V v_x11_24306 = heff_field(v_x1_24305, 0);
    V v_st_24307 = heff_field(v_x1_24305, 1);
    V v_ru_24x1_24305_24MkPair = heff_take_reuse_n(v_x1_24305, 3ULL, 2);
    switch (heff_tag_of(v_x11_24306)) {
    case TAG_Left: {
      V v_e_24308 = heff_field(v_x11_24306, 0);
      heff_take_n(v_x11_24306, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24305_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24308}), v_st_24307});
    }
    case TAG_Right: {
      V v_x_24309 = heff_field(v_x11_24306, 0);
      V v_ru_24x11_24306_24Right = heff_take_reuse_n(v_x11_24306, 1ULL, 1);
      V v_t_24312;
      switch (heff_tag_of(v_x_24309)) {
      case TAG_At: {
        V v_s_24311 = heff_dup(heff_field(v_x_24309, 1));
        v_t_24312 = v_s_24311;
        break;
      }
      default: heff_nomatch(v_x_24309);
      }
      V v_t_24313 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24306_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24309}), v_t_24312});
      return heff_tag_at_n(v_ru_24x1_24305_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24313}), v_st_24307});
    }
    default: return heff_nomatch(v_x11_24306);
    }
  }
  default: return heff_nomatch(v_x1_24305);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam22(V self, V *args) {
  V v_st_24320 = args[0];
  V v_m_24319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24321 = heff_tr(heff_call(v_m_24319, 1, (V[]){v_st_24320}));
  switch (heff_tag_of(v_x1_24321)) {
  case TAG_MkPair: {
    V v_x11_24322 = heff_field(v_x1_24321, 0);
    V v_st_24323 = heff_field(v_x1_24321, 1);
    V v_ru_24x1_24321_24MkPair = heff_take_reuse_n(v_x1_24321, 3ULL, 2);
    switch (heff_tag_of(v_x11_24322)) {
    case TAG_Left: {
      V v_e_24324 = heff_field(v_x11_24322, 0);
      heff_take_n(v_x11_24322, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24324}), v_st_24323});
    }
    case TAG_Right: {
      V v_x_24325 = heff_field(v_x11_24322, 0);
      V v_ru_24x11_24322_24Right = heff_take_reuse_n(v_x11_24322, 1ULL, 1);
      V v_t_24328;
      switch (heff_tag_of(v_x_24325)) {
      case TAG_At: {
        V v_s_24327 = heff_dup(heff_field(v_x_24325, 1));
        v_t_24328 = v_s_24327;
        break;
      }
      default: heff_nomatch(v_x_24325);
      }
      V v_t_24329 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24322_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24325}), v_t_24328});
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24329}), v_st_24323});
    }
    default: return heff_nomatch(v_x11_24322);
    }
  }
  default: return heff_nomatch(v_x1_24321);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam23(V self, V *args) {
  V v_st_24335 = args[0];
  V v_m_24334 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24336 = heff_tr(heff_call(v_m_24334, 1, (V[]){v_st_24335}));
  switch (heff_tag_of(v_x1_24336)) {
  case TAG_MkPair: {
    V v_x11_24337 = heff_field(v_x1_24336, 0);
    V v_st_24338 = heff_field(v_x1_24336, 1);
    V v_ru_24x1_24336_24MkPair = heff_take_reuse_n(v_x1_24336, 3ULL, 2);
    switch (heff_tag_of(v_x11_24337)) {
    case TAG_Left: {
      V v_e_24339 = heff_field(v_x11_24337, 0);
      heff_take_n(v_x11_24337, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24336_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24339}), v_st_24338});
    }
    case TAG_Right: {
      V v_x_24340 = heff_field(v_x11_24337, 0);
      V v_ru_24x11_24337_24Right = heff_take_reuse_n(v_x11_24337, 1ULL, 1);
      V v_t_24343;
      switch (heff_tag_of(v_x_24340)) {
      case TAG_At: {
        V v_s_24342 = heff_dup(heff_field(v_x_24340, 1));
        v_t_24343 = v_s_24342;
        break;
      }
      default: heff_nomatch(v_x_24340);
      }
      V v_t_24344 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24337_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24340}), v_t_24343});
      return heff_tag_at_n(v_ru_24x1_24336_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24344}), v_st_24338});
    }
    default: return heff_nomatch(v_x11_24337);
    }
  }
  default: return heff_nomatch(v_x1_24336);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam24(V self, V *args) {
  V v_st_24350 = args[0];
  V v_m_24349 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24351 = heff_tr(heff_call(v_m_24349, 1, (V[]){v_st_24350}));
  switch (heff_tag_of(v_x1_24351)) {
  case TAG_MkPair: {
    V v_x11_24352 = heff_field(v_x1_24351, 0);
    V v_st_24353 = heff_field(v_x1_24351, 1);
    V v_ru_24x1_24351_24MkPair = heff_take_reuse_n(v_x1_24351, 3ULL, 2);
    switch (heff_tag_of(v_x11_24352)) {
    case TAG_Left: {
      V v_e_24354 = heff_field(v_x11_24352, 0);
      heff_take_n(v_x11_24352, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24354}), v_st_24353});
    }
    case TAG_Right: {
      V v_x_24355 = heff_field(v_x11_24352, 0);
      V v_ru_24x11_24352_24Right = heff_take_reuse_n(v_x11_24352, 1ULL, 1);
      V v_t_24358;
      switch (heff_tag_of(v_x_24355)) {
      case TAG_At: {
        V v_s_24357 = heff_dup(heff_field(v_x_24355, 1));
        v_t_24358 = v_s_24357;
        break;
      }
      default: heff_nomatch(v_x_24355);
      }
      V v_t_24359 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24352_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24355}), v_t_24358});
      return heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24359}), v_st_24353});
    }
    default: return heff_nomatch(v_x11_24352);
    }
  }
  default: return heff_nomatch(v_x1_24351);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam25(V self, V *args) {
  V v_st_24364 = args[0];
  V v_m_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24365 = heff_tr(heff_call(v_m_24363, 1, (V[]){v_st_24364}));
  switch (heff_tag_of(v_x1_24365)) {
  case TAG_MkPair: {
    V v_x11_24366 = heff_field(v_x1_24365, 0);
    V v_st_24367 = heff_field(v_x1_24365, 1);
    V v_ru_24x1_24365_24MkPair = heff_take_reuse_n(v_x1_24365, 3ULL, 2);
    switch (heff_tag_of(v_x11_24366)) {
    case TAG_Left: {
      V v_e_24368 = heff_field(v_x11_24366, 0);
      heff_take_n(v_x11_24366, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24365_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24368}), v_st_24367});
    }
    case TAG_Right: {
      V v_x_24369 = heff_field(v_x11_24366, 0);
      V v_ru_24x11_24366_24Right = heff_take_reuse_n(v_x11_24366, 1ULL, 1);
      V v_t_24372;
      switch (heff_tag_of(v_x_24369)) {
      case TAG_At: {
        V v_s_24371 = heff_dup(heff_field(v_x_24369, 1));
        v_t_24372 = v_s_24371;
        break;
      }
      default: heff_nomatch(v_x_24369);
      }
      V v_t_24373 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24366_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24369}), v_t_24372});
      return heff_tag_at_n(v_ru_24x1_24365_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24373}), v_st_24367});
    }
    default: return heff_nomatch(v_x11_24366);
    }
  }
  default: return heff_nomatch(v_x1_24365);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam26(V self, V *args) {
  V v_st_24381 = args[0];
  V v_m_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24382 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_st_24381}));
  switch (heff_tag_of(v_x1_24382)) {
  case TAG_MkPair: {
    V v_x11_24383 = heff_field(v_x1_24382, 0);
    V v_st_24384 = heff_field(v_x1_24382, 1);
    V v_ru_24x1_24382_24MkPair = heff_take_reuse_n(v_x1_24382, 3ULL, 2);
    switch (heff_tag_of(v_x11_24383)) {
    case TAG_Left: {
      V v_e_24385 = heff_field(v_x11_24383, 0);
      heff_take_n(v_x11_24383, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24382_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24385}), v_st_24384});
    }
    case TAG_Right: {
      V v_x_24386 = heff_field(v_x11_24383, 0);
      V v_ru_24x11_24383_24Right = heff_take_reuse_n(v_x11_24383, 1ULL, 1);
      V v_t_24389;
      switch (heff_tag_of(v_x_24386)) {
      case TAG_At: {
        V v_s_24388 = heff_dup(heff_field(v_x_24386, 1));
        v_t_24389 = v_s_24388;
        break;
      }
      default: heff_nomatch(v_x_24386);
      }
      V v_t_24390 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24383_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24386}), v_t_24389});
      return heff_tag_at_n(v_ru_24x1_24382_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24390}), v_st_24384});
    }
    default: return heff_nomatch(v_x11_24383);
    }
  }
  default: return heff_nomatch(v_x1_24382);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam27(V self, V *args) {
  V v_st_24394 = args[0];
  V v_m_24393 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24395 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_st_24394}));
  switch (heff_tag_of(v_x1_24395)) {
  case TAG_MkPair: {
    V v_x11_24396 = heff_field(v_x1_24395, 0);
    V v_st_24397 = heff_field(v_x1_24395, 1);
    V v_ru_24x1_24395_24MkPair = heff_take_reuse_n(v_x1_24395, 3ULL, 2);
    switch (heff_tag_of(v_x11_24396)) {
    case TAG_Left: {
      V v_e_24398 = heff_field(v_x11_24396, 0);
      heff_take_n(v_x11_24396, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24398}), v_st_24397});
    }
    case TAG_Right: {
      V v_x_24399 = heff_field(v_x11_24396, 0);
      V v_ru_24x11_24396_24Right = heff_take_reuse_n(v_x11_24396, 1ULL, 1);
      V v_t_24402;
      switch (heff_tag_of(v_x_24399)) {
      case TAG_At: {
        V v_s_24401 = heff_dup(heff_field(v_x_24399, 1));
        v_t_24402 = v_s_24401;
        break;
      }
      default: heff_nomatch(v_x_24399);
      }
      V v_t_24403 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24396_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24399}), v_t_24402});
      return heff_tag_at_n(v_ru_24x1_24395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24403}), v_st_24397});
    }
    default: return heff_nomatch(v_x11_24396);
    }
  }
  default: return heff_nomatch(v_x1_24395);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam28(V self, V *args) {
  V v_st_24408 = args[0];
  V v_m_24407 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24409 = heff_tr(heff_call(v_m_24407, 1, (V[]){v_st_24408}));
  switch (heff_tag_of(v_x1_24409)) {
  case TAG_MkPair: {
    V v_x11_24410 = heff_field(v_x1_24409, 0);
    V v_st_24411 = heff_field(v_x1_24409, 1);
    V v_ru_24x1_24409_24MkPair = heff_take_reuse_n(v_x1_24409, 3ULL, 2);
    switch (heff_tag_of(v_x11_24410)) {
    case TAG_Left: {
      V v_e_24412 = heff_field(v_x11_24410, 0);
      heff_take_n(v_x11_24410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24412}), v_st_24411});
    }
    case TAG_Right: {
      V v_x_24413 = heff_field(v_x11_24410, 0);
      V v_ru_24x11_24410_24Right = heff_take_reuse_n(v_x11_24410, 1ULL, 1);
      V v_t_24416;
      switch (heff_tag_of(v_x_24413)) {
      case TAG_At: {
        V v_s_24415 = heff_dup(heff_field(v_x_24413, 1));
        v_t_24416 = v_s_24415;
        break;
      }
      default: heff_nomatch(v_x_24413);
      }
      V v_t_24417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24410_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24413}), v_t_24416});
      return heff_tag_at_n(v_ru_24x1_24409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24417}), v_st_24411});
    }
    default: return heff_nomatch(v_x11_24410);
    }
  }
  default: return heff_nomatch(v_x1_24409);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam29(V self, V *args) {
  V v_st_24425 = args[0];
  V v_m_24424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24426 = heff_tr(heff_call(v_m_24424, 1, (V[]){v_st_24425}));
  switch (heff_tag_of(v_x1_24426)) {
  case TAG_MkPair: {
    V v_x11_24427 = heff_field(v_x1_24426, 0);
    V v_st_24428 = heff_field(v_x1_24426, 1);
    V v_ru_24x1_24426_24MkPair = heff_take_reuse_n(v_x1_24426, 3ULL, 2);
    switch (heff_tag_of(v_x11_24427)) {
    case TAG_Left: {
      V v_e_24429 = heff_field(v_x11_24427, 0);
      heff_take_n(v_x11_24427, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24429}), v_st_24428});
    }
    case TAG_Right: {
      V v_x_24430 = heff_field(v_x11_24427, 0);
      V v_ru_24x11_24427_24Right = heff_take_reuse_n(v_x11_24427, 1ULL, 1);
      V v_t_24433;
      switch (heff_tag_of(v_x_24430)) {
      case TAG_At: {
        V v_s_24432 = heff_dup(heff_field(v_x_24430, 1));
        v_t_24433 = v_s_24432;
        break;
      }
      default: heff_nomatch(v_x_24430);
      }
      V v_t_24434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24427_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24430}), v_t_24433});
      return heff_tag_at_n(v_ru_24x1_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24434}), v_st_24428});
    }
    default: return heff_nomatch(v_x11_24427);
    }
  }
  default: return heff_nomatch(v_x1_24426);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam30(V self, V *args) {
  V v_st_24442 = args[0];
  V v_m_24441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24443 = heff_tr(heff_call(v_m_24441, 1, (V[]){v_st_24442}));
  switch (heff_tag_of(v_x1_24443)) {
  case TAG_MkPair: {
    V v_x11_24444 = heff_field(v_x1_24443, 0);
    V v_st_24445 = heff_field(v_x1_24443, 1);
    V v_ru_24x1_24443_24MkPair = heff_take_reuse_n(v_x1_24443, 3ULL, 2);
    switch (heff_tag_of(v_x11_24444)) {
    case TAG_Left: {
      V v_e_24446 = heff_field(v_x11_24444, 0);
      heff_take_n(v_x11_24444, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24446}), v_st_24445});
    }
    case TAG_Right: {
      V v_x_24447 = heff_field(v_x11_24444, 0);
      V v_ru_24x11_24444_24Right = heff_take_reuse_n(v_x11_24444, 1ULL, 1);
      V v_t_24450;
      switch (heff_tag_of(v_x_24447)) {
      case TAG_At: {
        V v_s_24449 = heff_dup(heff_field(v_x_24447, 1));
        v_t_24450 = v_s_24449;
        break;
      }
      default: heff_nomatch(v_x_24447);
      }
      V v_t_24451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24444_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24447}), v_t_24450});
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24451}), v_st_24445});
    }
    default: return heff_nomatch(v_x11_24444);
    }
  }
  default: return heff_nomatch(v_x1_24443);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam31(V self, V *args) {
  V v_st_24456 = args[0];
  V v_m_24455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24457 = heff_tr(heff_call(v_m_24455, 1, (V[]){v_st_24456}));
  switch (heff_tag_of(v_x1_24457)) {
  case TAG_MkPair: {
    V v_x11_24458 = heff_field(v_x1_24457, 0);
    V v_st_24459 = heff_field(v_x1_24457, 1);
    V v_ru_24x1_24457_24MkPair = heff_take_reuse_n(v_x1_24457, 3ULL, 2);
    switch (heff_tag_of(v_x11_24458)) {
    case TAG_Left: {
      V v_e_24460 = heff_field(v_x11_24458, 0);
      heff_take_n(v_x11_24458, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24460}), v_st_24459});
    }
    case TAG_Right: {
      V v_x_24461 = heff_field(v_x11_24458, 0);
      V v_ru_24x11_24458_24Right = heff_take_reuse_n(v_x11_24458, 1ULL, 1);
      V v_t_24464;
      switch (heff_tag_of(v_x_24461)) {
      case TAG_At: {
        V v_s_24463 = heff_dup(heff_field(v_x_24461, 1));
        v_t_24464 = v_s_24463;
        break;
      }
      default: heff_nomatch(v_x_24461);
      }
      V v_t_24465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24458_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24461}), v_t_24464});
      return heff_tag_at_n(v_ru_24x1_24457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24465}), v_st_24459});
    }
    default: return heff_nomatch(v_x11_24458);
    }
  }
  default: return heff_nomatch(v_x1_24457);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam32(V self, V *args) {
  V v_st_24471 = args[0];
  V v_m_24470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24472 = heff_tr(heff_call(v_m_24470, 1, (V[]){v_st_24471}));
  switch (heff_tag_of(v_x1_24472)) {
  case TAG_MkPair: {
    V v_x11_24473 = heff_field(v_x1_24472, 0);
    V v_st_24474 = heff_field(v_x1_24472, 1);
    V v_ru_24x1_24472_24MkPair = heff_take_reuse_n(v_x1_24472, 3ULL, 2);
    switch (heff_tag_of(v_x11_24473)) {
    case TAG_Left: {
      V v_e_24475 = heff_field(v_x11_24473, 0);
      heff_take_n(v_x11_24473, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24475}), v_st_24474});
    }
    case TAG_Right: {
      V v_x_24476 = heff_field(v_x11_24473, 0);
      V v_ru_24x11_24473_24Right = heff_take_reuse_n(v_x11_24473, 1ULL, 1);
      V v_t_24479;
      switch (heff_tag_of(v_x_24476)) {
      case TAG_At: {
        V v_s_24478 = heff_dup(heff_field(v_x_24476, 1));
        v_t_24479 = v_s_24478;
        break;
      }
      default: heff_nomatch(v_x_24476);
      }
      V v_t_24480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24473_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24476}), v_t_24479});
      return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24480}), v_st_24474});
    }
    default: return heff_nomatch(v_x11_24473);
    }
  }
  default: return heff_nomatch(v_x1_24472);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam33(V self, V *args) {
  V v_st_24488 = args[0];
  V v_m_24487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24489 = heff_tr(heff_call(v_m_24487, 1, (V[]){v_st_24488}));
  switch (heff_tag_of(v_x1_24489)) {
  case TAG_MkPair: {
    V v_x11_24490 = heff_field(v_x1_24489, 0);
    V v_st_24491 = heff_field(v_x1_24489, 1);
    V v_ru_24x1_24489_24MkPair = heff_take_reuse_n(v_x1_24489, 3ULL, 2);
    switch (heff_tag_of(v_x11_24490)) {
    case TAG_Left: {
      V v_e_24492 = heff_field(v_x11_24490, 0);
      heff_take_n(v_x11_24490, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24492}), v_st_24491});
    }
    case TAG_Right: {
      V v_x_24493 = heff_field(v_x11_24490, 0);
      V v_ru_24x11_24490_24Right = heff_take_reuse_n(v_x11_24490, 1ULL, 1);
      V v_t_24496;
      switch (heff_tag_of(v_x_24493)) {
      case TAG_At: {
        V v_s_24495 = heff_dup(heff_field(v_x_24493, 1));
        v_t_24496 = v_s_24495;
        break;
      }
      default: heff_nomatch(v_x_24493);
      }
      V v_t_24497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24490_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24493}), v_t_24496});
      return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24497}), v_st_24491});
    }
    default: return heff_nomatch(v_x11_24490);
    }
  }
  default: return heff_nomatch(v_x1_24489);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam34(V self, V *args) {
  V v_st_24500 = args[0];
  V v_m_24499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24501 = heff_tr(heff_call(v_m_24499, 1, (V[]){v_st_24500}));
  switch (heff_tag_of(v_x1_24501)) {
  case TAG_MkPair: {
    V v_x11_24502 = heff_field(v_x1_24501, 0);
    V v_st_24503 = heff_field(v_x1_24501, 1);
    V v_ru_24x1_24501_24MkPair = heff_take_reuse_n(v_x1_24501, 3ULL, 2);
    switch (heff_tag_of(v_x11_24502)) {
    case TAG_Left: {
      V v_e_24504 = heff_field(v_x11_24502, 0);
      heff_take_n(v_x11_24502, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24501_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24504}), v_st_24503});
    }
    case TAG_Right: {
      V v_x_24505 = heff_field(v_x11_24502, 0);
      V v_ru_24x11_24502_24Right = heff_take_reuse_n(v_x11_24502, 1ULL, 1);
      V v_t_24508;
      switch (heff_tag_of(v_x_24505)) {
      case TAG_At: {
        V v_s_24507 = heff_dup(heff_field(v_x_24505, 1));
        v_t_24508 = v_s_24507;
        break;
      }
      default: heff_nomatch(v_x_24505);
      }
      V v_t_24509 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24502_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24505}), v_t_24508});
      return heff_tag_at_n(v_ru_24x1_24501_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24509}), v_st_24503});
    }
    default: return heff_nomatch(v_x11_24502);
    }
  }
  default: return heff_nomatch(v_x1_24501);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam35(V self, V *args) {
  V v_st_24513 = args[0];
  V v_m_24512 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24514 = heff_tr(heff_call(v_m_24512, 1, (V[]){v_st_24513}));
  switch (heff_tag_of(v_x1_24514)) {
  case TAG_MkPair: {
    V v_x11_24515 = heff_field(v_x1_24514, 0);
    V v_st_24516 = heff_field(v_x1_24514, 1);
    V v_ru_24x1_24514_24MkPair = heff_take_reuse_n(v_x1_24514, 3ULL, 2);
    switch (heff_tag_of(v_x11_24515)) {
    case TAG_Left: {
      V v_e_24517 = heff_field(v_x11_24515, 0);
      heff_take_n(v_x11_24515, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24517}), v_st_24516});
    }
    case TAG_Right: {
      V v_x_24518 = heff_field(v_x11_24515, 0);
      V v_ru_24x11_24515_24Right = heff_take_reuse_n(v_x11_24515, 1ULL, 1);
      V v_t_24521;
      switch (heff_tag_of(v_x_24518)) {
      case TAG_At: {
        V v_s_24520 = heff_dup(heff_field(v_x_24518, 1));
        v_t_24521 = v_s_24520;
        break;
      }
      default: heff_nomatch(v_x_24518);
      }
      V v_t_24522 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24515_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24518}), v_t_24521});
      return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24522}), v_st_24516});
    }
    default: return heff_nomatch(v_x11_24515);
    }
  }
  default: return heff_nomatch(v_x1_24514);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam36(V self, V *args) {
  V v_st_24528 = args[0];
  V v_m_24527 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24529 = heff_tr(heff_call(v_m_24527, 1, (V[]){v_st_24528}));
  switch (heff_tag_of(v_x1_24529)) {
  case TAG_MkPair: {
    V v_x11_24530 = heff_field(v_x1_24529, 0);
    V v_st_24531 = heff_field(v_x1_24529, 1);
    V v_ru_24x1_24529_24MkPair = heff_take_reuse_n(v_x1_24529, 3ULL, 2);
    switch (heff_tag_of(v_x11_24530)) {
    case TAG_Left: {
      V v_e_24532 = heff_field(v_x11_24530, 0);
      heff_take_n(v_x11_24530, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24529_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24532}), v_st_24531});
    }
    case TAG_Right: {
      V v_x_24533 = heff_field(v_x11_24530, 0);
      V v_ru_24x11_24530_24Right = heff_take_reuse_n(v_x11_24530, 1ULL, 1);
      V v_t_24536;
      switch (heff_tag_of(v_x_24533)) {
      case TAG_At: {
        V v_s_24535 = heff_dup(heff_field(v_x_24533, 1));
        v_t_24536 = v_s_24535;
        break;
      }
      default: heff_nomatch(v_x_24533);
      }
      V v_t_24537 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24530_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24533}), v_t_24536});
      return heff_tag_at_n(v_ru_24x1_24529_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24537}), v_st_24531});
    }
    default: return heff_nomatch(v_x11_24530);
    }
  }
  default: return heff_nomatch(v_x1_24529);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam37(V self, V *args) {
  V v_st_24543 = args[0];
  V v_m_24542 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24544 = heff_tr(heff_call(v_m_24542, 1, (V[]){v_st_24543}));
  switch (heff_tag_of(v_x1_24544)) {
  case TAG_MkPair: {
    V v_x11_24545 = heff_field(v_x1_24544, 0);
    V v_st_24546 = heff_field(v_x1_24544, 1);
    V v_ru_24x1_24544_24MkPair = heff_take_reuse_n(v_x1_24544, 3ULL, 2);
    switch (heff_tag_of(v_x11_24545)) {
    case TAG_Left: {
      V v_e_24547 = heff_field(v_x11_24545, 0);
      heff_take_n(v_x11_24545, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24544_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24547}), v_st_24546});
    }
    case TAG_Right: {
      V v_x_24548 = heff_field(v_x11_24545, 0);
      V v_ru_24x11_24545_24Right = heff_take_reuse_n(v_x11_24545, 1ULL, 1);
      V v_t_24551;
      switch (heff_tag_of(v_x_24548)) {
      case TAG_At: {
        V v_s_24550 = heff_dup(heff_field(v_x_24548, 1));
        v_t_24551 = v_s_24550;
        break;
      }
      default: heff_nomatch(v_x_24548);
      }
      V v_t_24552 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24545_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24548}), v_t_24551});
      return heff_tag_at_n(v_ru_24x1_24544_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24552}), v_st_24546});
    }
    default: return heff_nomatch(v_x11_24545);
    }
  }
  default: return heff_nomatch(v_x1_24544);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam38(V self, V *args) {
  V v_st_24558 = args[0];
  V v_m_24557 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24559 = heff_tr(heff_call(v_m_24557, 1, (V[]){v_st_24558}));
  switch (heff_tag_of(v_x1_24559)) {
  case TAG_MkPair: {
    V v_x11_24560 = heff_field(v_x1_24559, 0);
    V v_st_24561 = heff_field(v_x1_24559, 1);
    V v_ru_24x1_24559_24MkPair = heff_take_reuse_n(v_x1_24559, 3ULL, 2);
    switch (heff_tag_of(v_x11_24560)) {
    case TAG_Left: {
      V v_e_24562 = heff_field(v_x11_24560, 0);
      heff_take_n(v_x11_24560, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24562}), v_st_24561});
    }
    case TAG_Right: {
      V v_x_24563 = heff_field(v_x11_24560, 0);
      V v_ru_24x11_24560_24Right = heff_take_reuse_n(v_x11_24560, 1ULL, 1);
      V v_t_24566;
      switch (heff_tag_of(v_x_24563)) {
      case TAG_At: {
        V v_s_24565 = heff_dup(heff_field(v_x_24563, 1));
        v_t_24566 = v_s_24565;
        break;
      }
      default: heff_nomatch(v_x_24563);
      }
      V v_t_24567 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24560_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24563}), v_t_24566});
      return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24567}), v_st_24561});
    }
    default: return heff_nomatch(v_x11_24560);
    }
  }
  default: return heff_nomatch(v_x1_24559);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam39(V self, V *args) {
  V v_st_24573 = args[0];
  V v_m_24572 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24574 = heff_tr(heff_call(v_m_24572, 1, (V[]){v_st_24573}));
  switch (heff_tag_of(v_x1_24574)) {
  case TAG_MkPair: {
    V v_x11_24575 = heff_field(v_x1_24574, 0);
    V v_st_24576 = heff_field(v_x1_24574, 1);
    V v_ru_24x1_24574_24MkPair = heff_take_reuse_n(v_x1_24574, 3ULL, 2);
    switch (heff_tag_of(v_x11_24575)) {
    case TAG_Left: {
      V v_e_24577 = heff_field(v_x11_24575, 0);
      heff_take_n(v_x11_24575, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24574_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24577}), v_st_24576});
    }
    case TAG_Right: {
      V v_x_24578 = heff_field(v_x11_24575, 0);
      V v_ru_24x11_24575_24Right = heff_take_reuse_n(v_x11_24575, 1ULL, 1);
      V v_t_24581;
      switch (heff_tag_of(v_x_24578)) {
      case TAG_At: {
        V v_s_24580 = heff_dup(heff_field(v_x_24578, 1));
        v_t_24581 = v_s_24580;
        break;
      }
      default: heff_nomatch(v_x_24578);
      }
      V v_t_24582 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24575_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24578}), v_t_24581});
      return heff_tag_at_n(v_ru_24x1_24574_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24582}), v_st_24576});
    }
    default: return heff_nomatch(v_x11_24575);
    }
  }
  default: return heff_nomatch(v_x1_24574);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam40(V self, V *args) {
  V v_st_24588 = args[0];
  V v_m_24587 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24589 = heff_tr(heff_call(v_m_24587, 1, (V[]){v_st_24588}));
  switch (heff_tag_of(v_x1_24589)) {
  case TAG_MkPair: {
    V v_x11_24590 = heff_field(v_x1_24589, 0);
    V v_st_24591 = heff_field(v_x1_24589, 1);
    V v_ru_24x1_24589_24MkPair = heff_take_reuse_n(v_x1_24589, 3ULL, 2);
    switch (heff_tag_of(v_x11_24590)) {
    case TAG_Left: {
      V v_e_24592 = heff_field(v_x11_24590, 0);
      heff_take_n(v_x11_24590, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24589_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24592}), v_st_24591});
    }
    case TAG_Right: {
      V v_x_24593 = heff_field(v_x11_24590, 0);
      V v_ru_24x11_24590_24Right = heff_take_reuse_n(v_x11_24590, 1ULL, 1);
      V v_t_24596;
      switch (heff_tag_of(v_x_24593)) {
      case TAG_At: {
        V v_s_24595 = heff_dup(heff_field(v_x_24593, 1));
        v_t_24596 = v_s_24595;
        break;
      }
      default: heff_nomatch(v_x_24593);
      }
      V v_t_24597 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24590_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24593}), v_t_24596});
      return heff_tag_at_n(v_ru_24x1_24589_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24597}), v_st_24591});
    }
    default: return heff_nomatch(v_x11_24590);
    }
  }
  default: return heff_nomatch(v_x1_24589);
  }
}

HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24s1266236307x1641993968_24cpr(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411}});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        heff_take_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2418_24Left, TAG_Left, 1, (V[]){v_e_2420}), v_st_2419}});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_f_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return ((HeffT2){{v_f_2425, v_st_2419}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2418)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2417)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2410)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0, 77, "a segment of a binary pattern holds a name, `_`, a number, a string or a rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1, 101, "only the last segment takes what is left: say this one's size, `x::binary-size(n)`, `x::bits-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V v_r_240, V v_last_241, V v_sp_242, V v_p_243) {
top: ;
  V v_x2_244 = (g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0, 1, 2, (V[]){v_x2_244, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1, 2, 4, (V[]){v_r_240, v_p_243, v_sp_242, heff_dup(v_last_241)})});
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_x2_244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x2_244) == NTAG(TAG_True))) {
    heff_drop(v_x2_244);
    heff_drop(v_sp_242);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_p_245});
  } else {
    heff_drop(v_x2_244);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_p_245});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_z_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_last_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_248);
  V v_m_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_249}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_last_241);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_t_2435;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_x11_2416 = heff_dup(heff_field(v_x_2415, 0));
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2416, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2416, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2425 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          v_t_2435 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_IntValue, 1, (V[]){v_v_2425});
          break;
        }
        case TAG_PatFloat: {
          heff_take_na(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_FloatValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_RuneValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2416, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2416);
        }
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      HeffT2 v_t_2436 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_242); V a_2 = v_x_2415; V a_3 = v_t_2435; V a_4 = v_st_2413; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1266236307x1641993968_24cpr(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      {
        V v_field_2437 = v_t_2436.f[0];
        V v_field_2438 = v_t_2436.f[1];
        V v_x11_2439 = v_field_2437;
        V v_st_2440 = v_field_2438;
        switch (heff_tag_of(v_x11_2439)) {
        case TAG_Left: {
          V v_e_2441 = heff_field(v_x11_2439, 0);
          heff_take_n(v_x11_2439, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_last_241);
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2441}), v_st_2440});
        }
        case TAG_Right: {
          V v_x_2442 = heff_field(v_x11_2439, 0);
          heff_take_n(v_x11_2439, 1ULL, 1);
          if ((heff_dup(v_last_241) == NTAG(TAG_True))) {
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2442}), v_st_2440});
          } else {
            heff_drop(v_last_241);
            V v_t_2445;
            switch (heff_tag_of(v_x_2442)) {
            case TAG_At: {
              V v_x_2443 = heff_dup(heff_field(v_x_2442, 0));
              v_t_2445 = v_x_2443;
              break;
            }
            default: heff_nomatch(v_x_2442);
            }
            V v_t_2446 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2445); r_; });
            if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
              heff_drop(v_x_2442);
              heff_drop(v_t_2446);
              V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1), v_sp_242, NTAG(TAG_Nothing)});
              return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2447}), v_st_2440});
            } else {
              heff_drop(v_sp_242);
              heff_drop(v_t_2446);
              return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2442}), v_st_2440});
            }
          }
        }
        default: return heff_nomatch(v_x11_2439);
        }
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_x_241, 2)), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V v_r_240, V v_names_241, V v_pats_242, V v_rhs_243, V v_w_244, V v_st_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_f_247 = heff_get_n(v_t_246, 0, 2);
  HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_st_245, 3); V a_1 = v_f_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_t_2413;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2410;
      v_t_2413 = v_x_2412;
    } else {
      heff_drop(v_field_2410);
      v_t_2413 = NTAG(TAG_Nil);
    }
    V v_pv_2414 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2413));
    V v_m_2415 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(v_r_240, 1)), heff_dup(v_pats_242)));
    V v_t_2416 = ({ V rv_4 = v_pv_2414; V rr_ = heff_rec_reuse_nf(v_st_245, 495ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_x1_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_t_2416}));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_MkPair: {
      V v_x11_2418 = heff_field(v_x1_2417, 0);
      V v_st_2419 = heff_field(v_x1_2417, 1);
      heff_take_n(v_x1_2417, 3ULL, 2);
      switch (heff_tag_of(v_x11_2418)) {
      case TAG_Left: {
        V v_e_2420 = heff_field(v_x11_2418, 0);
        V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_pats_242);
        heff_drop(v_rhs_243);
        heff_drop(v_t_2413);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2418_24Left, TAG_Left, 1, (V[]){v_e_2420}), v_st_2419}});
      }
      case TAG_Right: {
        V v_x_2421 = heff_field(v_x11_2418, 0);
        heff_take_n(v_x11_2418, 1ULL, 1);
        V v_t_2422 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2413));
        V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2422}));
        V v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = v_pats_242; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_242); r_; });
        V v_t_2425 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2413); r_; });
        V v_t_2426 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2424, v_t_2425));
        V v_m_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_243}));
        V v_t_2428 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2419, 495ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2426, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0, 1, 5, (V[]){v_m_2427, heff_dup(v_w_244), v_r_240, heff_dup(v_names_241), v_x_2421}), v_t_2428));
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2418)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2417)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args) {
  V v_st_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2435});
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args) {
  V v_rhs_27_2440 = args[0];
  V v_z_2441 = args[1];
  V v_names_241 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_t_2443 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_t_2444 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_t_2445 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2443, 0, 2), heff_get_n(v_t_2444, 1, 2), v_x_2421, heff_dup(v_rhs_27_2440)});
  V v_t_2448;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2446 = heff_dup(heff_field(v_names_241, 0));
    v_t_2448 = heff_get_n(v_t_2446, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2451;
  switch (heff_tag_of(v_rhs_27_2440)) {
  case TAG_At: {
    V v_s_2450 = heff_dup(heff_field(v_rhs_27_2440, 1));
    v_t_2451 = v_s_2450;
    break;
  }
  default: heff_nomatch(v_rhs_27_2440);
  }
  V v_t_2452 = ({ V rv_0 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_t_2451, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2455;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_2455 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2453 = heff_field(v_names_241, 0);
    heff_take_n(v_names_241, 1ULL, 2);
    v_t_2455 = heff_get_n(v_t_2453, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2458;
  switch (heff_tag_of(v_rhs_27_2440)) {
  case TAG_At: {
    V v_s_2457 = heff_field(v_rhs_27_2440, 1);
    heff_take_n(v_rhs_27_2440, 2ULL, 2);
    v_t_2458 = v_s_2457;
    break;
  }
  default: heff_nomatch(v_rhs_27_2440);
  }
  V v_t_2459 = ({ V rv_0 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_t_2458, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2460 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2442, 0, 2), heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_t_2452}), v_t_2459});
  V v_x_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2461}), v_z_2441});
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args) {
  V v_st_2429 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_w_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_names_241 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2430 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2429}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_MkPair: {
    V v_x11_2431 = heff_field(v_x1_2430, 0);
    V v_st_2432 = heff_field(v_x1_2430, 1);
    V v_ru_24x1_2430_24MkPair = heff_take_reuse_n(v_x1_2430, 3ULL, 2);
    switch (heff_tag_of(v_x11_2431)) {
    case TAG_Left: {
      V v_e_2433 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      heff_drop(v_w_244);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_names_241);
      heff_drop(v_x_2421);
      return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2433}), v_st_2432});
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2430_24MkPair, 2);
      V v_t_2439;
      switch (heff_tag_of(v_w_244)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 3);
        v_t_2439 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1, 1, 1, (V[]){v_x_2434});
        break;
      }
      case TAG_Just: {
        V v_it1_2436 = heff_field(v_w_244, 0);
        heff_take_n(v_w_244, 1ULL, 1);
        switch (heff_tag_of(v_it1_2436)) {
        case TAG_MkPair: {
          V v_kw_2437 = heff_field(v_it1_2436, 0);
          V v_ds_2438 = heff_field(v_it1_2436, 1);
          heff_take_n(v_it1_2436, 3ULL, 2);
          v_t_2439 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_clo), 4, (V[]){v_r_240, v_kw_2437, v_ds_2438, v_x_2434}));
          break;
        }
        default: heff_nomatch(v_it1_2436);
        }
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      return (g_heff_2esyntax_2esurface_2ebind(v_t_2439, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2, 2, 2, (V[]){v_names_241, v_x_2421}), v_st_2432));
    }
    default: return heff_nomatch(v_x11_2431);
    }
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Sig: {
      V v_f_245 = heff_field(v_x11_242, 1);
      V v_fsp_246 = heff_field(v_x11_242, 2);
      V v_ty_247 = heff_field(v_x11_242, 3);
      V v_sp_248 = heff_field(v_x11_242, 4);
      heff_take_n(v_x11_242, 30ULL, 5);
      HeffT2 v_t_249 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_245, heff_dup(v_rest_243)));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_es_2413 = v_field_2411;
          V v_a_2414 = heff_take_field(v_sp_248, 1);
          V v_b_2415 = heff_take_field(v_es_2413, 1);
          V v_t_2417;
          if (heff_intLt_c_lent(v_a_2414, v_b_2415, 0)) {
            heff_drop(v_a_2414);
            v_t_2417 = v_b_2415;
          } else {
            heff_drop(v_b_2415);
            v_t_2417 = v_a_2414;
          }
          V v_t_2418 = ({ V rv_1 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_sp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2419 = heff_rec_n(5, shape_name__span__ty__eqns__whole, (V[]){v_f_245, v_fsp_246, v_ty_247, heff_get_n(v_es_2413, 0, 2), v_t_2418});
          V v_cell_2420 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2419}), heff_hole()});
          V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
          heff_drop(v_u_2421);
          V t_0 = v_rest_243;
          V t_1 = v_cell_2420;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_f_245);
          heff_drop(v_fsp_246);
          heff_drop(v_ty_247);
          heff_drop_rec(v_sp_248, 2);
          heff_drop(v_field_2411);
          V t_0 = v_rest_243;
          V t_1 = v_d_241;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
      }
    }
    case TAG_Eqn: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Whole: {
      V v_cell_2426 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2427 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2426));
      heff_drop(v_u_2427);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2426;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Doc: {
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2430 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2429));
      heff_drop(v_u_2430);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2429;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualDefs_24dps(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eedgesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eedgesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eedgesOf(V v_scope_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 1);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_scope_240, 2);
    heff_drop_rec(v_d_241, 8);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_op_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam0, 1, 2, (V[]){heff_dup(v_scope_240), heff_dup(v_op_243)}), heff_take_field(v_d_241, 2)));
    V v_t_2415 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2414));
    V v_t_2425 = (g_list_2efilter(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam2, 1, 1, (V[]){heff_dup(v_scope_240)}), heff_get_n(v_d_241, 3, 8)));
    V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam4, 1, 2, (V[]){v_scope_240, v_op_243}), v_t_2425));
    V v_t_2436 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2435));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2415, v_t_2436);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eedgesOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args) {
  V v_g_246 = args[0];
  V v_r_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_245, 1, 7)}));
  return ({ V a_0 = v_t_247; V b_1 = heff_get_n(v_g_246, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args) {
  V v_r_245 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_248 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam1, 1, 1, (V[]){v_r_245}), heff_get_n(v_scope_240, 0, 2)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_g_2412 = v_field_2410;
      V v_t_2413 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_op_243, 1, 7), heff_get_n(v_g_2412, 0, 5)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
    } else {
      heff_drop_rec(v_op_243, 7);
      heff_drop(v_field_2410);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args) {
  V v_g_2417 = args[0];
  V v_r_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2416, 1, 7)}));
  return ({ V a_0 = v_t_2418; V b_1 = heff_get_n(v_g_2417, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_scope_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam3, 1, 1, (V[]){v_r_2416}), heff_get_n(v_scope_240, 0, 2)));
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2420 == ((int64_t)0ULL)) ? ({ V v_g_2423 = heff_dup(v_field_2421); int c_ = ({ V v_t_2424 = heff_dup(heff_rfield(v_g_2423, 3)); int c_ = !(heff_dup(v_t_2424) == NTAG(TAG_True)); heff_drop(v_t_2424); c_; }); heff_drop(v_g_2423); c_; }) : 1));
    heff_drop(v_field_2421);
    return v_ret_24bool;
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args) {
  V v_g_2427 = args[0];
  V v_r_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2426, 1, 7)}));
  return ({ V a_0 = v_t_2428; V b_1 = heff_get_n(v_g_2427, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args) {
  V v_r_2426 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2429 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam5, 1, 1, (V[]){v_r_2426}), heff_get_n(v_scope_240, 0, 2)));
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_g_2433 = v_field_2431;
      V v_t_2434 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_g_2433, 0, 5), heff_get_n(v_op_243, 1, 7)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2434});
    } else {
      heff_drop_rec(v_op_243, 7);
      heff_drop(v_field_2431);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(V v_declared_240, V v_start_241, V v_names_242, V v_ty_243, V v_st_244) {
top: ;
  V v_x1_245 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_243), v_st_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Left = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      heff_drop(v_declared_240);
      heff_drop(v_start_241);
      heff_drop(v_ty_243);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_246_24Left, TAG_Left, 1, (V[]){v_e_248}), v_st_247}});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_242));
      V v_f_2411 = heff_get_n(v_t_2410, 0, 2);
      V v_names_2412 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_x_249)));
      V v_implicits_2413 = (g_heff_2esyntax_2esurface_2epiImplicits(heff_dup(v_x_249)));
      V v_t_2414 = (g_heff_2esyntax_2esurface_2eaddBinders(heff_rec_n(3, shape_f__names__implicits, (V[]){v_f_2411, v_names_2412, v_implicits_2413}), v_st_247));
      V v_t_2415 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_242));
      V v_t_2416 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_242));
      V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(v_ty_243));
      V v_b_2418 = heff_get_n(v_t_2417, 4, 9);
      V v_t_2419 = heff_tag_n(TAG_Sig, 5, (V[]){v_declared_240, heff_get_n(v_t_2415, 0, 2), heff_get_n(v_t_2416, 1, 2), v_x_249, heff_rec_n(2, shape_start__end, (V[]){v_start_241, v_b_2418})});
      V v_x_2420 = heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_x_2420}), v_t_2414}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
  }
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V v_c_240, V v_args_241) {
top: ;
  V v_m_242 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 0)), v_args_241));
  return heff_clo_n(g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0, 1, 2, (V[]){v_m_242, v_c_240});
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_c_240, 9);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_t_249 = heff_tag_at_n(v_ru_24x11_245_24Right, TAG_ETag, 1, (V[]){heff_dup(heff_rfield(v_c_240, 1))});
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_240, 3), heff_get_n(v_c_240, 4, 9)});
      V v_x_2411 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2410}), v_x_248));
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2411}), v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V v_k_240, V v_ds_241, V v_st_242) {
top: ;
  V v_k_243 = (g_heff_2esyntax_2esurface_2eknotOf(v_k_240, v_ds_241));
  V v_t_244 = ({ V rv_8 = v_k_243; V rr_ = heff_rec_reuse_nf(v_st_242, 255ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), v_ds_241, v_t_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_x11_248 = v_field_246;
    V v_st_249 = v_field_247;
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Left, TAG_Left, 1, (V[]){v_e_2410}), v_st_249}});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = ({ V rv_8 = heff_dup(g_std_2emap_2eempty_get()); V rr_ = heff_rec_reuse_nf(v_st_249, 255ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
      V v_items_2413 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2411));
      V v_t_2414 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2418 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0, 2, 1, (V[]){heff_dup(v_t_2412)}); V a_1 = v_t_2414; V a_2 = v_items_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2413); r_; });
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2418, 3, 4)));
      V v_items_2420 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2411));
      V v_t_2421 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2422 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2420));
      V v_t_2423 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2420));
      V v_t_2424 = ({ V a_0 = v_t_2421; V a_1 = v_t_2422; V a_2 = v_t_2423; V a_3 = v_items_2420; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); heff_drop(v_t_2422); heff_drop(v_t_2423); r_; });
      V v_t_2425 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2424));
      V v_t_2426 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2419, v_t_2425));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Nil: {
        V v_x_2427 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2411); r_; });
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){v_x_2427}), v_t_2412}});
      }
      case TAG_Cons: {
        V v_d_2428 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 2);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24x11_248_24Right, 1);
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2428}), v_t_2412}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2426)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_248)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args) {
  V v_d_2415 = args[0];
  V v_it_2416 = args[1];
  V v_t_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2415, 2)), v_it_2416));
  return ({ V a_0 = heff_get_n(v_t_2412, 7, 9); V a_1 = v_d_2415; V a_2 = v_t_2417; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V v_kw_240, V v_ds_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(heff_dup(v_ds_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_f1_247 = v_field_245;
      HeffT2 v_t_248 = (g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0), heff_dup(v_f1_247)), heff_dup(v_ds_241), v_z_242));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x11_2411 = v_field_249;
        V v_st_2412 = v_field_2410;
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_Left: {
          V v_e_2413 = heff_field(v_x11_2411, 0);
          V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
          heff_drop_rec(v_kw_240, 9);
          heff_drop(v_ds_241);
          heff_drop(v_f1_247);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2411_24Left, TAG_Left, 1, (V[]){v_e_2413}), v_st_2412}});
        }
        case TAG_Right: {
          V v_x_2414 = heff_field(v_x11_2411, 0);
          V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
          V v_t_2415 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2414)));
          V v_t_2416 = (g_list_2emap_24s2104173076x1668056829(v_t_2415));
          V v_t_2417 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2416));
          switch (heff_tag_of(v_t_2417)) {
          case TAG_Nil: {
            V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_240, 3)), heff_dup(heff_rfield(v_kw_240, 4))});
            V v_x1_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
            V v_e_2423;
            switch (heff_tag_of(v_x1_2419)) {
            case TAG_Nil: {
              v_e_2423 = heff_dup(heff_rfield(v_kw_240, 4));
              break;
            }
            case TAG_Cons: {
              V v_x_2420 = heff_field(v_x1_2419, 0);
              heff_take_n(v_x1_2419, 1ULL, 2);
              V v_t_2422 = (g_heff_2esyntax_2ecst_2elastD(v_x_2420));
              v_e_2423 = heff_get_n(v_t_2422, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2419);
            }
            V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2423});
            V v_t_2425 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2414));
            V v_x_2426 = (g_heff_2esyntax_2esurface_2emutualOut(v_t_2418, v_t_2424, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1), heff_dup(v_f1_247)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2), v_f1_247), v_t_2425));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2412}});
          }
          case TAG_Cons: {
            V v_d_2427 = heff_field(v_t_2417, 0);
            heff_take_n(v_t_2417, 1ULL, 2);
            heff_drop_rec(v_kw_240, 9);
            heff_drop(v_ds_241);
            heff_drop(v_f1_247);
            heff_drop(v_x_2414);
            heff_drop_cell(v_ru_24x11_2411_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2427}), v_st_2412}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2417)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2411)}});
        }
      }
    } else {
      heff_drop(v_ds_241);
      heff_drop(v_field_245);
      V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_kw_240, 3), heff_get_n(v_kw_240, 4, 9)});
      V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3), v_t_2429, NTAG(TAG_Nothing)});
      V v_f_2431 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2430});
      return ((HeffT2){{v_f_2431, v_z_242}});
    }
  }
}
Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V v_decls_240, V v_groups_241, V v_edges_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_241)));
  V v_t_244 = (g_heff_2esyntax_2efixity_2enubByG(v_t_243));
  V v_t_245 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_246 = (g_heff_2esyntax_2efixity_2enubByE(v_t_245));
  V v_t_247 = heff_rec_n(2, shape_groups__above, (V[]){v_t_244, v_t_246});
  V v_t_248 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_241)));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByG(v_t_248));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_edges_242)));
  V v_t_2411 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2410));
  V v_t_2412 = heff_rec_n(2, shape_groups__above, (V[]){v_t_249, v_t_2411});
  V v_t_2413 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_t_247, v_t_2412, v_decls_240));
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_241, v_edges_242}), v_t_2413});
}
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_s_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_s_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0), v_t_246, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1)})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(a[0], a[1]);
}