// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_BadFieldSet 46507
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_f 320
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_implicits 1321238867
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_fixities__diags[] = {LBL_fixities, LBL_diags};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_name__span__ty__eqns__whole[] = {LBL_name, LBL_span, LBL_ty, LBL_eqns, LBL_whole};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V, V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V);
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo;
V g_heff_2esyntax_2esurface_2eknotOf(V, V);
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotOf_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V, V);
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24s1266236307x1641993968_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryFieldOne_24s1473805472x1314815828_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f2041933216x1458595349(V, V, V, V, V);
V g_list_2emap_24f2041933216x1458595349_entry(V self, V *a);
extern Clo g_list_2emap_24f2041933216x1458595349_clo;
V g_list_2emap_24s2081681776x559624592(V);
V g_list_2emap_24s2081681776x559624592_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s348263401x2104816219(V);
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  V v_scope_243 = heff_take_field(v_st_242, 1);
  V v_toks_244 = heff_take_field(v_st_242, 0);
  V v_known_245 = heff_take_field(v_st_242, 2);
  V v_binders_246 = heff_take_field(v_st_242, 3);
  V v_patVars_247 = heff_take_field(v_st_242, 4);
  V v_fix_248 = heff_take_field(v_st_242, 5);
  V v_lenient_249 = heff_take_field(v_st_242, 6);
  V v_at_2410 = heff_take_field(v_st_242, 7);
  V v_knot_2411 = heff_get_n(v_st_242, 8, 9);
  V v_t_2412 = heff_dup(v_scope_243);
  V v_sc_2413 = (g_heff_2esyntax_2esurface_2eappendS(v_xs_240, v_scope_243));
  V v_x1_2414 = heff_tr(heff_call(v_p_241, 1, (V[]){heff_rec_n(9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, (V[]){v_toks_244, v_sc_2413, v_known_245, v_binders_246, v_patVars_247, v_fix_248, v_lenient_249, v_at_2410, v_knot_2411})}));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_MkPair: {
    V v_x11_2415 = heff_field(v_x1_2414, 0);
    V v_st_2416 = heff_field(v_x1_2414, 1);
    heff_take_n(v_x1_2414, 3ULL, 2);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      V v_e_2417 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      heff_drop(v_t_2412);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416}});
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      V v_f_2419 = ({ V rv_1 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_st_2416, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){v_x_2418}), v_f_2419}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2415)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2414)}});
  }
}
Clo g_heff_2esyntax_2esurface_2ewithScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewithScope_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ewithScope(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_xs_240, v_p_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewithScope(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eblock_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eblock(V v_f_240, V v_xs_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2eblock_24cpr(v_f_240, v_xs_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eblock(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eboundBy_24dps(V v_pv_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_244));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_241, 0);
    V v_kind_248 = heff_dup(heff_rfield(v_t_247, 0));
    V v_text_249 = heff_dup(heff_rfield(v_t_247, 1));
    if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str0), 2) && !heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str1), 2))) {
      heff_drop(v_kind_248);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_249, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
    } else {
      if (heff_strEq_c(v_kind_248, ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str2))) {
        V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_249)}));
        V v_t_2412 = (g_list_2eany(v_t_2411, v_pv_240));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_249, NTAG(TAG_Nil)});
          return heff_setField(v_d_242, MK_INT(1LL), v_t_2413);
        } else {
          heff_drop(v_text_249);
          heff_drop(v_t_2412);
          return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
        }
      } else {
        heff_drop(v_text_249);
        return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  case TAG_PParen: {
    V v_q_2415 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2415;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2418 = heff_field(v_x2_241, 1);
    V v_t_2422 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2418));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2422);
  }
  case TAG_POp: {
    V v_l_2423 = heff_field(v_x2_241, 0);
    V v_q_2425 = heff_field(v_x2_241, 2);
    V v_t_2426 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2423));
    V v_t_2427 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2425));
    V v_t_2428 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2426, v_t_2427));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
  }
  case TAG_PRec: {
    V v_fs_2430 = heff_field(v_x2_241, 1);
    V v_t_2434 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2430));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2434);
  }
  case TAG_PField: {
    V v_q_2437 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2437;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2438 = heff_field(v_x2_241, 0);
    V v_q_2440 = heff_field(v_x2_241, 2);
    V v_cell_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2438, 1)), heff_hole()});
    V v_u_2442 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2441));
    heff_drop(v_u_2442);
    V t_0 = v_pv_240;
    V t_1 = v_q_2440;
    V t_2 = v_cell_2441;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2443 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2443;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy_24dps(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args) {
  V v_q_2421 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2421; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2421); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args) {
  V v_q_2433 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2433; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2433); r_; });
}
Clo g_heff_2esyntax_2esurface_2easNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2easNameE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_sp_247 = heff_field(v_e_240, 1);
        V v_ru_24e_240_24At = heff_take_reuse_n(v_e_240, 2ULL, 2);
        return heff_tag_at_n(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_EVar, 1, (V[]){v_x_245}), v_sp_247});
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return v_e_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EBreak: {
      return v_e_240;
    }
    case TAG_EContinue: {
      return v_e_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return v_e_240;
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easNameE(a[0]);
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EParen: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Named: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Tup: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Seg: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Braces: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Update: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_InstB: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Sum: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ECon: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EField: {
    V v_e_2449 = heff_field(v_x1_240, 0);
    V v_f_2450 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EField = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_e_2449;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24EField, TAG_Cons, 2, (V[]){v_f_2450, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ETilde: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_App: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Op: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Ops: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Ann: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_BVar: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_BImp: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_BPat: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Lam: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Case: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_If: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_Do: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ELet: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ELetElse: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EFor: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EJump: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ENest: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EArrow: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ETry: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_EWith: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam44(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esettingL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esettingL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esettingL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam1, 1, 1, (V[]){v_m_2417});
  }
  case TAG_Named: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam2, 1, 1, (V[]){v_m_2433});
  }
  case TAG_Tup: {
    V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam3, 1, 1, (V[]){v_m_2448});
  }
  case TAG_Seg: {
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam4, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Braces: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam5, 1, 1, (V[]){v_m_2477});
  }
  case TAG_Update: {
    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam6, 1, 1, (V[]){v_m_2494});
  }
  case TAG_EUSet: {
    V v_m_24108 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam7, 1, 1, (V[]){v_m_24108});
  }
  case TAG_InstB: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam8, 1, 1, (V[]){v_m_24124});
  }
  case TAG_EFSet: {
    V v_x_24135 = heff_field(v_x2_241, 0);
    V v_e_24137 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_text_24138 = heff_take_field(v_x_24135, 1);
    V v_start_24139 = heff_take_field(v_x_24135, 3);
    V v_end_24140 = heff_get_n(v_x_24135, 4, 9);
    V v_m_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24137}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam9, 1, 4, (V[]){v_m_24141, v_text_24138, v_start_24139, v_end_24140});
  }
  case TAG_EFDefault: {
    V v_m_24157 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam10, 1, 1, (V[]){v_m_24157});
  }
  case TAG_Sum: {
    V v_m_24173 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam11, 1, 1, (V[]){v_m_24173});
  }
  case TAG_ECon: {
    V v_m_24186 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam12, 1, 1, (V[]){v_m_24186});
  }
  case TAG_EField: {
    V v_m_24199 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam13, 1, 1, (V[]){v_m_24199});
  }
  case TAG_ENeg: {
    V v_m_24212 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam14, 1, 1, (V[]){v_m_24212});
  }
  case TAG_ETilde: {
    V v_m_24225 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam15, 1, 1, (V[]){v_m_24225});
  }
  case TAG_App: {
    V v_m_24238 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam16, 1, 1, (V[]){v_m_24238});
  }
  case TAG_Op: {
    V v_m_24252 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam17, 1, 1, (V[]){v_m_24252});
  }
  case TAG_Ops: {
    V v_m_24265 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam18, 1, 1, (V[]){v_m_24265});
  }
  case TAG_OpRhs: {
    V v_m_24278 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam19, 1, 1, (V[]){v_m_24278});
  }
  case TAG_Ann: {
    V v_m_24292 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam20, 1, 1, (V[]){v_m_24292});
  }
  case TAG_BVar: {
    V v_m_24304 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam21, 1, 1, (V[]){v_m_24304});
  }
  case TAG_BImp: {
    V v_m_24318 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam22, 1, 1, (V[]){v_m_24318});
  }
  case TAG_BAnn: {
    V v_m_24334 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam23, 1, 1, (V[]){v_m_24334});
  }
  case TAG_BPat: {
    V v_m_24346 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam24, 1, 1, (V[]){v_m_24346});
  }
  case TAG_Lam: {
    V v_m_24361 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam25, 1, 1, (V[]){v_m_24361});
  }
  case TAG_Case: {
    V v_m_24376 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam26, 1, 1, (V[]){v_m_24376});
  }
  case TAG_EAlt: {
    V v_m_24390 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam27, 1, 1, (V[]){v_m_24390});
  }
  case TAG_If: {
    V v_m_24407 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam28, 1, 1, (V[]){v_m_24407});
  }
  case TAG_Do: {
    V v_m_24420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam29, 1, 1, (V[]){v_m_24420});
  }
  case TAG_ESBind: {
    V v_m_24434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam30, 1, 1, (V[]){v_m_24434});
  }
  case TAG_ELet: {
    V v_m_24451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam31, 1, 1, (V[]){v_m_24451});
  }
  case TAG_ELetElse: {
    V v_m_24469 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam32, 1, 1, (V[]){v_m_24469});
  }
  case TAG_ELetMut: {
    V v_m_24486 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam33, 1, 1, (V[]){v_m_24486});
  }
  case TAG_EAssign: {
    V v_m_24500 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam34, 1, 1, (V[]){v_m_24500});
  }
  case TAG_EWhile: {
    V v_m_24515 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam35, 1, 1, (V[]){v_m_24515});
  }
  case TAG_EFor: {
    V v_m_24532 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam36, 1, 1, (V[]){v_m_24532});
  }
  case TAG_EJump: {
    V v_m_24544 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam37, 1, 1, (V[]){v_m_24544});
  }
  case TAG_EReturn: {
    V v_m_24557 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam38, 1, 1, (V[]){v_m_24557});
  }
  case TAG_ENest: {
    V v_m_24572 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam39, 1, 1, (V[]){v_m_24572});
  }
  case TAG_EArrow: {
    V v_m_24585 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam40, 1, 1, (V[]){v_m_24585});
  }
  case TAG_IfThen: {
    V v_m_24600 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam41, 1, 1, (V[]){v_m_24600});
  }
  case TAG_ETry: {
    V v_m_24615 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam42, 1, 1, (V[]){v_m_24615});
  }
  case TAG_ECatch: {
    V v_m_24630 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam43, 1, 1, (V[]){v_m_24630});
  }
  case TAG_EWith: {
    V v_m_24647 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam44, 1, 1, (V[]){v_m_24647});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esettingL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_x_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_BadFieldSet, 1, (V[]){v_x_249}), v_t_2412});
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2418}));
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_MkPair: {
    V v_x11_2420 = heff_field(v_x1_2419, 0);
    V v_st_2421 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    switch (heff_tag_of(v_x11_2420)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x11_2420, 0);
      heff_take_n(v_x11_2420, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x11_2420, 0);
      V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_x_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2423}), v_t_2426});
      return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_st_2421});
    }
    default: return heff_nomatch(v_x11_2420);
    }
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam2(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_MkPair: {
    V v_x11_2436 = heff_field(v_x1_2435, 0);
    V v_st_2437 = heff_field(v_x1_2435, 1);
    V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
    switch (heff_tag_of(v_x11_2436)) {
    case TAG_Left: {
      V v_e_2438 = heff_field(v_x11_2436, 0);
      heff_take_n(v_x11_2436, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2438}), v_st_2437});
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_x11_2436, 0);
      V v_ru_24x11_2436_24Right = heff_take_reuse_n(v_x11_2436, 1ULL, 1);
      V v_t_2442;
      switch (heff_tag_of(v_x_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_x_2439, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_x_2439);
      }
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2436_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2439}), v_t_2442});
      return heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_st_2437});
    }
    default: return heff_nomatch(v_x11_2436);
    }
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam3(V self, V *args) {
  V v_st_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2449}));
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_MkPair: {
    V v_x11_2451 = heff_field(v_x1_2450, 0);
    V v_st_2452 = heff_field(v_x1_2450, 1);
    V v_ru_24x1_2450_24MkPair = heff_take_reuse_n(v_x1_2450, 3ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_Left: {
      V v_e_2453 = heff_field(v_x11_2451, 0);
      heff_take_n(v_x11_2451, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2453}), v_st_2452});
    }
    case TAG_Right: {
      V v_x_2454 = heff_field(v_x11_2451, 0);
      V v_ru_24x11_2451_24Right = heff_take_reuse_n(v_x11_2451, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_x_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2451_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2454}), v_t_2457});
      return heff_tag_at_n(v_ru_24x1_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_st_2452});
    }
    default: return heff_nomatch(v_x11_2451);
    }
  }
  default: return heff_nomatch(v_x1_2450);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      V v_ru_24x11_2465_24Right = heff_take_reuse_n(v_x11_2465, 1ULL, 1);
      V v_t_2471;
      switch (heff_tag_of(v_x_2468)) {
      case TAG_At: {
        V v_s_2470 = heff_dup(heff_field(v_x_2468, 1));
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_x_2468);
      }
      V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2465_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2468}), v_t_2471});
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2472}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam5(V self, V *args) {
  V v_st_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_st_2478}));
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_MkPair: {
    V v_x11_2480 = heff_field(v_x1_2479, 0);
    V v_st_2481 = heff_field(v_x1_2479, 1);
    V v_ru_24x1_2479_24MkPair = heff_take_reuse_n(v_x1_2479, 3ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_Left: {
      V v_e_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2482}), v_st_2481});
    }
    case TAG_Right: {
      V v_x_2483 = heff_field(v_x11_2480, 0);
      V v_ru_24x11_2480_24Right = heff_take_reuse_n(v_x11_2480, 1ULL, 1);
      V v_t_2486;
      switch (heff_tag_of(v_x_2483)) {
      case TAG_At: {
        V v_s_2485 = heff_dup(heff_field(v_x_2483, 1));
        v_t_2486 = v_s_2485;
        break;
      }
      default: heff_nomatch(v_x_2483);
      }
      V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2480_24Right, TAG_BadFieldSet, 1, (V[]){v_x_2483}), v_t_2486});
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2487}), v_st_2481});
    }
    default: return heff_nomatch(v_x11_2480);
    }
  }
  default: return heff_nomatch(v_x1_2479);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam6(V self, V *args) {
  V v_st_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_st_2495}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_MkPair: {
    V v_x11_2497 = heff_field(v_x1_2496, 0);
    V v_st_2498 = heff_field(v_x1_2496, 1);
    V v_ru_24x1_2496_24MkPair = heff_take_reuse_n(v_x1_2496, 3ULL, 2);
    switch (heff_tag_of(v_x11_2497)) {
    case TAG_Left: {
      V v_e_2499 = heff_field(v_x11_2497, 0);
      heff_take_n(v_x11_2497, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2499}), v_st_2498});
    }
    case TAG_Right: {
      V v_x_24100 = heff_field(v_x11_2497, 0);
      V v_ru_24x11_2497_24Right = heff_take_reuse_n(v_x11_2497, 1ULL, 1);
      V v_t_24103;
      switch (heff_tag_of(v_x_24100)) {
      case TAG_At: {
        V v_s_24102 = heff_dup(heff_field(v_x_24100, 1));
        v_t_24103 = v_s_24102;
        break;
      }
      default: heff_nomatch(v_x_24100);
      }
      V v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2497_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24100}), v_t_24103});
      return heff_tag_at_n(v_ru_24x1_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24104}), v_st_2498});
    }
    default: return heff_nomatch(v_x11_2497);
    }
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam7(V self, V *args) {
  V v_st_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_24109}));
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_MkPair: {
    V v_x11_24111 = heff_field(v_x1_24110, 0);
    V v_st_24112 = heff_field(v_x1_24110, 1);
    V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
    switch (heff_tag_of(v_x11_24111)) {
    case TAG_Left: {
      V v_e_24113 = heff_field(v_x11_24111, 0);
      heff_take_n(v_x11_24111, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
    }
    case TAG_Right: {
      V v_x_24114 = heff_field(v_x11_24111, 0);
      V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 1ULL, 1);
      V v_t_24117;
      switch (heff_tag_of(v_x_24114)) {
      case TAG_At: {
        V v_s_24116 = heff_dup(heff_field(v_x_24114, 1));
        v_t_24117 = v_s_24116;
        break;
      }
      default: heff_nomatch(v_x_24114);
      }
      V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24114}), v_t_24117});
      return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24118}), v_st_24112});
    }
    default: return heff_nomatch(v_x11_24111);
    }
  }
  default: return heff_nomatch(v_x1_24110);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam8(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      V v_ru_24x11_24127_24Right = heff_take_reuse_n(v_x11_24127, 1ULL, 1);
      V v_t_24133;
      switch (heff_tag_of(v_x_24130)) {
      case TAG_At: {
        V v_s_24132 = heff_dup(heff_field(v_x_24130, 1));
        v_t_24133 = v_s_24132;
        break;
      }
      default: heff_nomatch(v_x_24130);
      }
      V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24127_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24130}), v_t_24133});
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24134}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam9(V self, V *args) {
  V v_st_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  V v_text_24138 = heff_env(self)[1];
  V v_start_24139 = heff_env(self)[2];
  V v_end_24140 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24143 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_st_24142}));
  switch (heff_tag_of(v_x1_24143)) {
  case TAG_MkPair: {
    V v_x11_24144 = heff_field(v_x1_24143, 0);
    V v_st_24145 = heff_field(v_x1_24143, 1);
    V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
    switch (heff_tag_of(v_x11_24144)) {
    case TAG_Left: {
      V v_e_24146 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      heff_drop(v_text_24138);
      heff_drop(v_start_24139);
      heff_drop(v_end_24140);
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
    }
    case TAG_Right: {
      V v_x_24147 = heff_field(v_x11_24144, 0);
      V v_ru_24x11_24144_24Right = heff_take_reuse_n(v_x11_24144, 1ULL, 1);
      V v_t_24148 = heff_tag_n(TAG_SetField, 3, (V[]){v_text_24138, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_24139), v_end_24140}), heff_dup(v_x_24147)});
      V v_t_24151;
      switch (heff_tag_of(v_x_24147)) {
      case TAG_At: {
        V v_s_24150 = heff_field(v_x_24147, 1);
        heff_take_n(v_x_24147, 2ULL, 2);
        v_t_24151 = v_s_24150;
        break;
      }
      default: heff_nomatch(v_x_24147);
      }
      V v_t_24152 = ({ V rv_0 = v_start_24139; V rr_ = heff_rec_reuse_nf(v_t_24151, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24153 = heff_tag_at_n(v_ru_24x11_24144_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24148, v_t_24152})});
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){v_t_24153, v_st_24145});
    }
    default: return heff_nomatch(v_x11_24144);
    }
  }
  default: return heff_nomatch(v_x1_24143);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam10(V self, V *args) {
  V v_st_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_st_24158}));
  switch (heff_tag_of(v_x1_24159)) {
  case TAG_MkPair: {
    V v_x11_24160 = heff_field(v_x1_24159, 0);
    V v_st_24161 = heff_field(v_x1_24159, 1);
    V v_ru_24x1_24159_24MkPair = heff_take_reuse_n(v_x1_24159, 3ULL, 2);
    switch (heff_tag_of(v_x11_24160)) {
    case TAG_Left: {
      V v_e_24162 = heff_field(v_x11_24160, 0);
      heff_take_n(v_x11_24160, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24162}), v_st_24161});
    }
    case TAG_Right: {
      V v_x_24163 = heff_field(v_x11_24160, 0);
      V v_ru_24x11_24160_24Right = heff_take_reuse_n(v_x11_24160, 1ULL, 1);
      V v_t_24166;
      switch (heff_tag_of(v_x_24163)) {
      case TAG_At: {
        V v_s_24165 = heff_dup(heff_field(v_x_24163, 1));
        v_t_24166 = v_s_24165;
        break;
      }
      default: heff_nomatch(v_x_24163);
      }
      V v_t_24167 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24160_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24163}), v_t_24166});
      return heff_tag_at_n(v_ru_24x1_24159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24167}), v_st_24161});
    }
    default: return heff_nomatch(v_x11_24160);
    }
  }
  default: return heff_nomatch(v_x1_24159);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam11(V self, V *args) {
  V v_st_24174 = args[0];
  V v_m_24173 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24175 = heff_tr(heff_call(v_m_24173, 1, (V[]){v_st_24174}));
  switch (heff_tag_of(v_x1_24175)) {
  case TAG_MkPair: {
    V v_x11_24176 = heff_field(v_x1_24175, 0);
    V v_st_24177 = heff_field(v_x1_24175, 1);
    V v_ru_24x1_24175_24MkPair = heff_take_reuse_n(v_x1_24175, 3ULL, 2);
    switch (heff_tag_of(v_x11_24176)) {
    case TAG_Left: {
      V v_e_24178 = heff_field(v_x11_24176, 0);
      heff_take_n(v_x11_24176, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24175_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24178}), v_st_24177});
    }
    case TAG_Right: {
      V v_x_24179 = heff_field(v_x11_24176, 0);
      V v_ru_24x11_24176_24Right = heff_take_reuse_n(v_x11_24176, 1ULL, 1);
      V v_t_24182;
      switch (heff_tag_of(v_x_24179)) {
      case TAG_At: {
        V v_s_24181 = heff_dup(heff_field(v_x_24179, 1));
        v_t_24182 = v_s_24181;
        break;
      }
      default: heff_nomatch(v_x_24179);
      }
      V v_t_24183 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24176_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24179}), v_t_24182});
      return heff_tag_at_n(v_ru_24x1_24175_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24183}), v_st_24177});
    }
    default: return heff_nomatch(v_x11_24176);
    }
  }
  default: return heff_nomatch(v_x1_24175);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam12(V self, V *args) {
  V v_st_24187 = args[0];
  V v_m_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24188 = heff_tr(heff_call(v_m_24186, 1, (V[]){v_st_24187}));
  switch (heff_tag_of(v_x1_24188)) {
  case TAG_MkPair: {
    V v_x11_24189 = heff_field(v_x1_24188, 0);
    V v_st_24190 = heff_field(v_x1_24188, 1);
    V v_ru_24x1_24188_24MkPair = heff_take_reuse_n(v_x1_24188, 3ULL, 2);
    switch (heff_tag_of(v_x11_24189)) {
    case TAG_Left: {
      V v_e_24191 = heff_field(v_x11_24189, 0);
      heff_take_n(v_x11_24189, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24191}), v_st_24190});
    }
    case TAG_Right: {
      V v_x_24192 = heff_field(v_x11_24189, 0);
      V v_ru_24x11_24189_24Right = heff_take_reuse_n(v_x11_24189, 1ULL, 1);
      V v_t_24195;
      switch (heff_tag_of(v_x_24192)) {
      case TAG_At: {
        V v_s_24194 = heff_dup(heff_field(v_x_24192, 1));
        v_t_24195 = v_s_24194;
        break;
      }
      default: heff_nomatch(v_x_24192);
      }
      V v_t_24196 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24189_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24192}), v_t_24195});
      return heff_tag_at_n(v_ru_24x1_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24196}), v_st_24190});
    }
    default: return heff_nomatch(v_x11_24189);
    }
  }
  default: return heff_nomatch(v_x1_24188);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam13(V self, V *args) {
  V v_st_24200 = args[0];
  V v_m_24199 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24201 = heff_tr(heff_call(v_m_24199, 1, (V[]){v_st_24200}));
  switch (heff_tag_of(v_x1_24201)) {
  case TAG_MkPair: {
    V v_x11_24202 = heff_field(v_x1_24201, 0);
    V v_st_24203 = heff_field(v_x1_24201, 1);
    V v_ru_24x1_24201_24MkPair = heff_take_reuse_n(v_x1_24201, 3ULL, 2);
    switch (heff_tag_of(v_x11_24202)) {
    case TAG_Left: {
      V v_e_24204 = heff_field(v_x11_24202, 0);
      heff_take_n(v_x11_24202, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24201_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24204}), v_st_24203});
    }
    case TAG_Right: {
      V v_x_24205 = heff_field(v_x11_24202, 0);
      V v_ru_24x11_24202_24Right = heff_take_reuse_n(v_x11_24202, 1ULL, 1);
      V v_t_24208;
      switch (heff_tag_of(v_x_24205)) {
      case TAG_At: {
        V v_s_24207 = heff_dup(heff_field(v_x_24205, 1));
        v_t_24208 = v_s_24207;
        break;
      }
      default: heff_nomatch(v_x_24205);
      }
      V v_t_24209 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24202_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24205}), v_t_24208});
      return heff_tag_at_n(v_ru_24x1_24201_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24209}), v_st_24203});
    }
    default: return heff_nomatch(v_x11_24202);
    }
  }
  default: return heff_nomatch(v_x1_24201);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam14(V self, V *args) {
  V v_st_24213 = args[0];
  V v_m_24212 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24214 = heff_tr(heff_call(v_m_24212, 1, (V[]){v_st_24213}));
  switch (heff_tag_of(v_x1_24214)) {
  case TAG_MkPair: {
    V v_x11_24215 = heff_field(v_x1_24214, 0);
    V v_st_24216 = heff_field(v_x1_24214, 1);
    V v_ru_24x1_24214_24MkPair = heff_take_reuse_n(v_x1_24214, 3ULL, 2);
    switch (heff_tag_of(v_x11_24215)) {
    case TAG_Left: {
      V v_e_24217 = heff_field(v_x11_24215, 0);
      heff_take_n(v_x11_24215, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24214_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24217}), v_st_24216});
    }
    case TAG_Right: {
      V v_x_24218 = heff_field(v_x11_24215, 0);
      V v_ru_24x11_24215_24Right = heff_take_reuse_n(v_x11_24215, 1ULL, 1);
      V v_t_24221;
      switch (heff_tag_of(v_x_24218)) {
      case TAG_At: {
        V v_s_24220 = heff_dup(heff_field(v_x_24218, 1));
        v_t_24221 = v_s_24220;
        break;
      }
      default: heff_nomatch(v_x_24218);
      }
      V v_t_24222 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24215_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24218}), v_t_24221});
      return heff_tag_at_n(v_ru_24x1_24214_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24222}), v_st_24216});
    }
    default: return heff_nomatch(v_x11_24215);
    }
  }
  default: return heff_nomatch(v_x1_24214);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam15(V self, V *args) {
  V v_st_24226 = args[0];
  V v_m_24225 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24227 = heff_tr(heff_call(v_m_24225, 1, (V[]){v_st_24226}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_MkPair: {
    V v_x11_24228 = heff_field(v_x1_24227, 0);
    V v_st_24229 = heff_field(v_x1_24227, 1);
    V v_ru_24x1_24227_24MkPair = heff_take_reuse_n(v_x1_24227, 3ULL, 2);
    switch (heff_tag_of(v_x11_24228)) {
    case TAG_Left: {
      V v_e_24230 = heff_field(v_x11_24228, 0);
      heff_take_n(v_x11_24228, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24230}), v_st_24229});
    }
    case TAG_Right: {
      V v_x_24231 = heff_field(v_x11_24228, 0);
      V v_ru_24x11_24228_24Right = heff_take_reuse_n(v_x11_24228, 1ULL, 1);
      V v_t_24234;
      switch (heff_tag_of(v_x_24231)) {
      case TAG_At: {
        V v_s_24233 = heff_dup(heff_field(v_x_24231, 1));
        v_t_24234 = v_s_24233;
        break;
      }
      default: heff_nomatch(v_x_24231);
      }
      V v_t_24235 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24228_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24231}), v_t_24234});
      return heff_tag_at_n(v_ru_24x1_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24235}), v_st_24229});
    }
    default: return heff_nomatch(v_x11_24228);
    }
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam16(V self, V *args) {
  V v_st_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_st_24239}));
  switch (heff_tag_of(v_x1_24240)) {
  case TAG_MkPair: {
    V v_x11_24241 = heff_field(v_x1_24240, 0);
    V v_st_24242 = heff_field(v_x1_24240, 1);
    V v_ru_24x1_24240_24MkPair = heff_take_reuse_n(v_x1_24240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24241)) {
    case TAG_Left: {
      V v_e_24243 = heff_field(v_x11_24241, 0);
      heff_take_n(v_x11_24241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24243}), v_st_24242});
    }
    case TAG_Right: {
      V v_x_24244 = heff_field(v_x11_24241, 0);
      V v_ru_24x11_24241_24Right = heff_take_reuse_n(v_x11_24241, 1ULL, 1);
      V v_t_24247;
      switch (heff_tag_of(v_x_24244)) {
      case TAG_At: {
        V v_s_24246 = heff_dup(heff_field(v_x_24244, 1));
        v_t_24247 = v_s_24246;
        break;
      }
      default: heff_nomatch(v_x_24244);
      }
      V v_t_24248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24241_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24244}), v_t_24247});
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24248}), v_st_24242});
    }
    default: return heff_nomatch(v_x11_24241);
    }
  }
  default: return heff_nomatch(v_x1_24240);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam17(V self, V *args) {
  V v_st_24253 = args[0];
  V v_m_24252 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24254 = heff_tr(heff_call(v_m_24252, 1, (V[]){v_st_24253}));
  switch (heff_tag_of(v_x1_24254)) {
  case TAG_MkPair: {
    V v_x11_24255 = heff_field(v_x1_24254, 0);
    V v_st_24256 = heff_field(v_x1_24254, 1);
    V v_ru_24x1_24254_24MkPair = heff_take_reuse_n(v_x1_24254, 3ULL, 2);
    switch (heff_tag_of(v_x11_24255)) {
    case TAG_Left: {
      V v_e_24257 = heff_field(v_x11_24255, 0);
      heff_take_n(v_x11_24255, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24254_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24257}), v_st_24256});
    }
    case TAG_Right: {
      V v_x_24258 = heff_field(v_x11_24255, 0);
      V v_ru_24x11_24255_24Right = heff_take_reuse_n(v_x11_24255, 1ULL, 1);
      V v_t_24261;
      switch (heff_tag_of(v_x_24258)) {
      case TAG_At: {
        V v_s_24260 = heff_dup(heff_field(v_x_24258, 1));
        v_t_24261 = v_s_24260;
        break;
      }
      default: heff_nomatch(v_x_24258);
      }
      V v_t_24262 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24255_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24258}), v_t_24261});
      return heff_tag_at_n(v_ru_24x1_24254_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24262}), v_st_24256});
    }
    default: return heff_nomatch(v_x11_24255);
    }
  }
  default: return heff_nomatch(v_x1_24254);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam18(V self, V *args) {
  V v_st_24266 = args[0];
  V v_m_24265 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24267 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_st_24266}));
  switch (heff_tag_of(v_x1_24267)) {
  case TAG_MkPair: {
    V v_x11_24268 = heff_field(v_x1_24267, 0);
    V v_st_24269 = heff_field(v_x1_24267, 1);
    V v_ru_24x1_24267_24MkPair = heff_take_reuse_n(v_x1_24267, 3ULL, 2);
    switch (heff_tag_of(v_x11_24268)) {
    case TAG_Left: {
      V v_e_24270 = heff_field(v_x11_24268, 0);
      heff_take_n(v_x11_24268, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24270}), v_st_24269});
    }
    case TAG_Right: {
      V v_x_24271 = heff_field(v_x11_24268, 0);
      V v_ru_24x11_24268_24Right = heff_take_reuse_n(v_x11_24268, 1ULL, 1);
      V v_t_24274;
      switch (heff_tag_of(v_x_24271)) {
      case TAG_At: {
        V v_s_24273 = heff_dup(heff_field(v_x_24271, 1));
        v_t_24274 = v_s_24273;
        break;
      }
      default: heff_nomatch(v_x_24271);
      }
      V v_t_24275 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24268_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24271}), v_t_24274});
      return heff_tag_at_n(v_ru_24x1_24267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24275}), v_st_24269});
    }
    default: return heff_nomatch(v_x11_24268);
    }
  }
  default: return heff_nomatch(v_x1_24267);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam19(V self, V *args) {
  V v_st_24279 = args[0];
  V v_m_24278 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24280 = heff_tr(heff_call(v_m_24278, 1, (V[]){v_st_24279}));
  switch (heff_tag_of(v_x1_24280)) {
  case TAG_MkPair: {
    V v_x11_24281 = heff_field(v_x1_24280, 0);
    V v_st_24282 = heff_field(v_x1_24280, 1);
    V v_ru_24x1_24280_24MkPair = heff_take_reuse_n(v_x1_24280, 3ULL, 2);
    switch (heff_tag_of(v_x11_24281)) {
    case TAG_Left: {
      V v_e_24283 = heff_field(v_x11_24281, 0);
      heff_take_n(v_x11_24281, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24280_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24283}), v_st_24282});
    }
    case TAG_Right: {
      V v_x_24284 = heff_field(v_x11_24281, 0);
      V v_ru_24x11_24281_24Right = heff_take_reuse_n(v_x11_24281, 1ULL, 1);
      V v_t_24287;
      switch (heff_tag_of(v_x_24284)) {
      case TAG_At: {
        V v_s_24286 = heff_dup(heff_field(v_x_24284, 1));
        v_t_24287 = v_s_24286;
        break;
      }
      default: heff_nomatch(v_x_24284);
      }
      V v_t_24288 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24281_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24284}), v_t_24287});
      return heff_tag_at_n(v_ru_24x1_24280_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24288}), v_st_24282});
    }
    default: return heff_nomatch(v_x11_24281);
    }
  }
  default: return heff_nomatch(v_x1_24280);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam20(V self, V *args) {
  V v_st_24293 = args[0];
  V v_m_24292 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24294 = heff_tr(heff_call(v_m_24292, 1, (V[]){v_st_24293}));
  switch (heff_tag_of(v_x1_24294)) {
  case TAG_MkPair: {
    V v_x11_24295 = heff_field(v_x1_24294, 0);
    V v_st_24296 = heff_field(v_x1_24294, 1);
    V v_ru_24x1_24294_24MkPair = heff_take_reuse_n(v_x1_24294, 3ULL, 2);
    switch (heff_tag_of(v_x11_24295)) {
    case TAG_Left: {
      V v_e_24297 = heff_field(v_x11_24295, 0);
      heff_take_n(v_x11_24295, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24294_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24297}), v_st_24296});
    }
    case TAG_Right: {
      V v_x_24298 = heff_field(v_x11_24295, 0);
      V v_ru_24x11_24295_24Right = heff_take_reuse_n(v_x11_24295, 1ULL, 1);
      V v_t_24301;
      switch (heff_tag_of(v_x_24298)) {
      case TAG_At: {
        V v_s_24300 = heff_dup(heff_field(v_x_24298, 1));
        v_t_24301 = v_s_24300;
        break;
      }
      default: heff_nomatch(v_x_24298);
      }
      V v_t_24302 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24295_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24298}), v_t_24301});
      return heff_tag_at_n(v_ru_24x1_24294_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24302}), v_st_24296});
    }
    default: return heff_nomatch(v_x11_24295);
    }
  }
  default: return heff_nomatch(v_x1_24294);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam21(V self, V *args) {
  V v_st_24305 = args[0];
  V v_m_24304 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24306 = heff_tr(heff_call(v_m_24304, 1, (V[]){v_st_24305}));
  switch (heff_tag_of(v_x1_24306)) {
  case TAG_MkPair: {
    V v_x11_24307 = heff_field(v_x1_24306, 0);
    V v_st_24308 = heff_field(v_x1_24306, 1);
    V v_ru_24x1_24306_24MkPair = heff_take_reuse_n(v_x1_24306, 3ULL, 2);
    switch (heff_tag_of(v_x11_24307)) {
    case TAG_Left: {
      V v_e_24309 = heff_field(v_x11_24307, 0);
      heff_take_n(v_x11_24307, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24309}), v_st_24308});
    }
    case TAG_Right: {
      V v_x_24310 = heff_field(v_x11_24307, 0);
      V v_ru_24x11_24307_24Right = heff_take_reuse_n(v_x11_24307, 1ULL, 1);
      V v_t_24313;
      switch (heff_tag_of(v_x_24310)) {
      case TAG_At: {
        V v_s_24312 = heff_dup(heff_field(v_x_24310, 1));
        v_t_24313 = v_s_24312;
        break;
      }
      default: heff_nomatch(v_x_24310);
      }
      V v_t_24314 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24307_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24310}), v_t_24313});
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24314}), v_st_24308});
    }
    default: return heff_nomatch(v_x11_24307);
    }
  }
  default: return heff_nomatch(v_x1_24306);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam22(V self, V *args) {
  V v_st_24319 = args[0];
  V v_m_24318 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24320 = heff_tr(heff_call(v_m_24318, 1, (V[]){v_st_24319}));
  switch (heff_tag_of(v_x1_24320)) {
  case TAG_MkPair: {
    V v_x11_24321 = heff_field(v_x1_24320, 0);
    V v_st_24322 = heff_field(v_x1_24320, 1);
    V v_ru_24x1_24320_24MkPair = heff_take_reuse_n(v_x1_24320, 3ULL, 2);
    switch (heff_tag_of(v_x11_24321)) {
    case TAG_Left: {
      V v_e_24323 = heff_field(v_x11_24321, 0);
      heff_take_n(v_x11_24321, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24323}), v_st_24322});
    }
    case TAG_Right: {
      V v_x_24324 = heff_field(v_x11_24321, 0);
      V v_ru_24x11_24321_24Right = heff_take_reuse_n(v_x11_24321, 1ULL, 1);
      V v_t_24327;
      switch (heff_tag_of(v_x_24324)) {
      case TAG_At: {
        V v_s_24326 = heff_dup(heff_field(v_x_24324, 1));
        v_t_24327 = v_s_24326;
        break;
      }
      default: heff_nomatch(v_x_24324);
      }
      V v_t_24328 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24321_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24324}), v_t_24327});
      return heff_tag_at_n(v_ru_24x1_24320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24328}), v_st_24322});
    }
    default: return heff_nomatch(v_x11_24321);
    }
  }
  default: return heff_nomatch(v_x1_24320);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam23(V self, V *args) {
  V v_st_24335 = args[0];
  V v_m_24334 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24336 = heff_tr(heff_call(v_m_24334, 1, (V[]){v_st_24335}));
  switch (heff_tag_of(v_x1_24336)) {
  case TAG_MkPair: {
    V v_x11_24337 = heff_field(v_x1_24336, 0);
    V v_st_24338 = heff_field(v_x1_24336, 1);
    V v_ru_24x1_24336_24MkPair = heff_take_reuse_n(v_x1_24336, 3ULL, 2);
    switch (heff_tag_of(v_x11_24337)) {
    case TAG_Left: {
      V v_e_24339 = heff_field(v_x11_24337, 0);
      heff_take_n(v_x11_24337, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24336_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24339}), v_st_24338});
    }
    case TAG_Right: {
      V v_x_24340 = heff_field(v_x11_24337, 0);
      V v_ru_24x11_24337_24Right = heff_take_reuse_n(v_x11_24337, 1ULL, 1);
      V v_t_24343;
      switch (heff_tag_of(v_x_24340)) {
      case TAG_At: {
        V v_s_24342 = heff_dup(heff_field(v_x_24340, 1));
        v_t_24343 = v_s_24342;
        break;
      }
      default: heff_nomatch(v_x_24340);
      }
      V v_t_24344 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24337_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24340}), v_t_24343});
      return heff_tag_at_n(v_ru_24x1_24336_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24344}), v_st_24338});
    }
    default: return heff_nomatch(v_x11_24337);
    }
  }
  default: return heff_nomatch(v_x1_24336);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam24(V self, V *args) {
  V v_st_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_st_24347}));
  switch (heff_tag_of(v_x1_24348)) {
  case TAG_MkPair: {
    V v_x11_24349 = heff_field(v_x1_24348, 0);
    V v_st_24350 = heff_field(v_x1_24348, 1);
    V v_ru_24x1_24348_24MkPair = heff_take_reuse_n(v_x1_24348, 3ULL, 2);
    switch (heff_tag_of(v_x11_24349)) {
    case TAG_Left: {
      V v_e_24351 = heff_field(v_x11_24349, 0);
      heff_take_n(v_x11_24349, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24348_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24351}), v_st_24350});
    }
    case TAG_Right: {
      V v_x_24352 = heff_field(v_x11_24349, 0);
      V v_ru_24x11_24349_24Right = heff_take_reuse_n(v_x11_24349, 1ULL, 1);
      V v_t_24355;
      switch (heff_tag_of(v_x_24352)) {
      case TAG_At: {
        V v_s_24354 = heff_dup(heff_field(v_x_24352, 1));
        v_t_24355 = v_s_24354;
        break;
      }
      default: heff_nomatch(v_x_24352);
      }
      V v_t_24356 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24349_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24352}), v_t_24355});
      return heff_tag_at_n(v_ru_24x1_24348_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24356}), v_st_24350});
    }
    default: return heff_nomatch(v_x11_24349);
    }
  }
  default: return heff_nomatch(v_x1_24348);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam25(V self, V *args) {
  V v_st_24362 = args[0];
  V v_m_24361 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24363 = heff_tr(heff_call(v_m_24361, 1, (V[]){v_st_24362}));
  switch (heff_tag_of(v_x1_24363)) {
  case TAG_MkPair: {
    V v_x11_24364 = heff_field(v_x1_24363, 0);
    V v_st_24365 = heff_field(v_x1_24363, 1);
    V v_ru_24x1_24363_24MkPair = heff_take_reuse_n(v_x1_24363, 3ULL, 2);
    switch (heff_tag_of(v_x11_24364)) {
    case TAG_Left: {
      V v_e_24366 = heff_field(v_x11_24364, 0);
      heff_take_n(v_x11_24364, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24366}), v_st_24365});
    }
    case TAG_Right: {
      V v_x_24367 = heff_field(v_x11_24364, 0);
      V v_ru_24x11_24364_24Right = heff_take_reuse_n(v_x11_24364, 1ULL, 1);
      V v_t_24370;
      switch (heff_tag_of(v_x_24367)) {
      case TAG_At: {
        V v_s_24369 = heff_dup(heff_field(v_x_24367, 1));
        v_t_24370 = v_s_24369;
        break;
      }
      default: heff_nomatch(v_x_24367);
      }
      V v_t_24371 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24364_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24367}), v_t_24370});
      return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24371}), v_st_24365});
    }
    default: return heff_nomatch(v_x11_24364);
    }
  }
  default: return heff_nomatch(v_x1_24363);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam26(V self, V *args) {
  V v_st_24377 = args[0];
  V v_m_24376 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24378 = heff_tr(heff_call(v_m_24376, 1, (V[]){v_st_24377}));
  switch (heff_tag_of(v_x1_24378)) {
  case TAG_MkPair: {
    V v_x11_24379 = heff_field(v_x1_24378, 0);
    V v_st_24380 = heff_field(v_x1_24378, 1);
    V v_ru_24x1_24378_24MkPair = heff_take_reuse_n(v_x1_24378, 3ULL, 2);
    switch (heff_tag_of(v_x11_24379)) {
    case TAG_Left: {
      V v_e_24381 = heff_field(v_x11_24379, 0);
      heff_take_n(v_x11_24379, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24378_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24381}), v_st_24380});
    }
    case TAG_Right: {
      V v_x_24382 = heff_field(v_x11_24379, 0);
      V v_ru_24x11_24379_24Right = heff_take_reuse_n(v_x11_24379, 1ULL, 1);
      V v_t_24385;
      switch (heff_tag_of(v_x_24382)) {
      case TAG_At: {
        V v_s_24384 = heff_dup(heff_field(v_x_24382, 1));
        v_t_24385 = v_s_24384;
        break;
      }
      default: heff_nomatch(v_x_24382);
      }
      V v_t_24386 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24379_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24382}), v_t_24385});
      return heff_tag_at_n(v_ru_24x1_24378_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24386}), v_st_24380});
    }
    default: return heff_nomatch(v_x11_24379);
    }
  }
  default: return heff_nomatch(v_x1_24378);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam27(V self, V *args) {
  V v_st_24391 = args[0];
  V v_m_24390 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24392 = heff_tr(heff_call(v_m_24390, 1, (V[]){v_st_24391}));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_MkPair: {
    V v_x11_24393 = heff_field(v_x1_24392, 0);
    V v_st_24394 = heff_field(v_x1_24392, 1);
    V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
    switch (heff_tag_of(v_x11_24393)) {
    case TAG_Left: {
      V v_e_24395 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
    }
    case TAG_Right: {
      V v_x_24396 = heff_field(v_x11_24393, 0);
      V v_ru_24x11_24393_24Right = heff_take_reuse_n(v_x11_24393, 1ULL, 1);
      V v_t_24399;
      switch (heff_tag_of(v_x_24396)) {
      case TAG_At: {
        V v_s_24398 = heff_dup(heff_field(v_x_24396, 1));
        v_t_24399 = v_s_24398;
        break;
      }
      default: heff_nomatch(v_x_24396);
      }
      V v_t_24400 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24393_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24396}), v_t_24399});
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24400}), v_st_24394});
    }
    default: return heff_nomatch(v_x11_24393);
    }
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam28(V self, V *args) {
  V v_st_24408 = args[0];
  V v_m_24407 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24409 = heff_tr(heff_call(v_m_24407, 1, (V[]){v_st_24408}));
  switch (heff_tag_of(v_x1_24409)) {
  case TAG_MkPair: {
    V v_x11_24410 = heff_field(v_x1_24409, 0);
    V v_st_24411 = heff_field(v_x1_24409, 1);
    V v_ru_24x1_24409_24MkPair = heff_take_reuse_n(v_x1_24409, 3ULL, 2);
    switch (heff_tag_of(v_x11_24410)) {
    case TAG_Left: {
      V v_e_24412 = heff_field(v_x11_24410, 0);
      heff_take_n(v_x11_24410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24412}), v_st_24411});
    }
    case TAG_Right: {
      V v_x_24413 = heff_field(v_x11_24410, 0);
      V v_ru_24x11_24410_24Right = heff_take_reuse_n(v_x11_24410, 1ULL, 1);
      V v_t_24416;
      switch (heff_tag_of(v_x_24413)) {
      case TAG_At: {
        V v_s_24415 = heff_dup(heff_field(v_x_24413, 1));
        v_t_24416 = v_s_24415;
        break;
      }
      default: heff_nomatch(v_x_24413);
      }
      V v_t_24417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24410_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24413}), v_t_24416});
      return heff_tag_at_n(v_ru_24x1_24409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24417}), v_st_24411});
    }
    default: return heff_nomatch(v_x11_24410);
    }
  }
  default: return heff_nomatch(v_x1_24409);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam29(V self, V *args) {
  V v_st_24421 = args[0];
  V v_m_24420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24422 = heff_tr(heff_call(v_m_24420, 1, (V[]){v_st_24421}));
  switch (heff_tag_of(v_x1_24422)) {
  case TAG_MkPair: {
    V v_x11_24423 = heff_field(v_x1_24422, 0);
    V v_st_24424 = heff_field(v_x1_24422, 1);
    V v_ru_24x1_24422_24MkPair = heff_take_reuse_n(v_x1_24422, 3ULL, 2);
    switch (heff_tag_of(v_x11_24423)) {
    case TAG_Left: {
      V v_e_24425 = heff_field(v_x11_24423, 0);
      heff_take_n(v_x11_24423, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24425}), v_st_24424});
    }
    case TAG_Right: {
      V v_x_24426 = heff_field(v_x11_24423, 0);
      V v_ru_24x11_24423_24Right = heff_take_reuse_n(v_x11_24423, 1ULL, 1);
      V v_t_24429;
      switch (heff_tag_of(v_x_24426)) {
      case TAG_At: {
        V v_s_24428 = heff_dup(heff_field(v_x_24426, 1));
        v_t_24429 = v_s_24428;
        break;
      }
      default: heff_nomatch(v_x_24426);
      }
      V v_t_24430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24423_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24426}), v_t_24429});
      return heff_tag_at_n(v_ru_24x1_24422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24430}), v_st_24424});
    }
    default: return heff_nomatch(v_x11_24423);
    }
  }
  default: return heff_nomatch(v_x1_24422);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam30(V self, V *args) {
  V v_st_24435 = args[0];
  V v_m_24434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24436 = heff_tr(heff_call(v_m_24434, 1, (V[]){v_st_24435}));
  switch (heff_tag_of(v_x1_24436)) {
  case TAG_MkPair: {
    V v_x11_24437 = heff_field(v_x1_24436, 0);
    V v_st_24438 = heff_field(v_x1_24436, 1);
    V v_ru_24x1_24436_24MkPair = heff_take_reuse_n(v_x1_24436, 3ULL, 2);
    switch (heff_tag_of(v_x11_24437)) {
    case TAG_Left: {
      V v_e_24439 = heff_field(v_x11_24437, 0);
      heff_take_n(v_x11_24437, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24439}), v_st_24438});
    }
    case TAG_Right: {
      V v_x_24440 = heff_field(v_x11_24437, 0);
      V v_ru_24x11_24437_24Right = heff_take_reuse_n(v_x11_24437, 1ULL, 1);
      V v_t_24443;
      switch (heff_tag_of(v_x_24440)) {
      case TAG_At: {
        V v_s_24442 = heff_dup(heff_field(v_x_24440, 1));
        v_t_24443 = v_s_24442;
        break;
      }
      default: heff_nomatch(v_x_24440);
      }
      V v_t_24444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24437_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24440}), v_t_24443});
      return heff_tag_at_n(v_ru_24x1_24436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24444}), v_st_24438});
    }
    default: return heff_nomatch(v_x11_24437);
    }
  }
  default: return heff_nomatch(v_x1_24436);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam31(V self, V *args) {
  V v_st_24452 = args[0];
  V v_m_24451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24453 = heff_tr(heff_call(v_m_24451, 1, (V[]){v_st_24452}));
  switch (heff_tag_of(v_x1_24453)) {
  case TAG_MkPair: {
    V v_x11_24454 = heff_field(v_x1_24453, 0);
    V v_st_24455 = heff_field(v_x1_24453, 1);
    V v_ru_24x1_24453_24MkPair = heff_take_reuse_n(v_x1_24453, 3ULL, 2);
    switch (heff_tag_of(v_x11_24454)) {
    case TAG_Left: {
      V v_e_24456 = heff_field(v_x11_24454, 0);
      heff_take_n(v_x11_24454, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24456}), v_st_24455});
    }
    case TAG_Right: {
      V v_x_24457 = heff_field(v_x11_24454, 0);
      V v_ru_24x11_24454_24Right = heff_take_reuse_n(v_x11_24454, 1ULL, 1);
      V v_t_24460;
      switch (heff_tag_of(v_x_24457)) {
      case TAG_At: {
        V v_s_24459 = heff_dup(heff_field(v_x_24457, 1));
        v_t_24460 = v_s_24459;
        break;
      }
      default: heff_nomatch(v_x_24457);
      }
      V v_t_24461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24454_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24457}), v_t_24460});
      return heff_tag_at_n(v_ru_24x1_24453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24461}), v_st_24455});
    }
    default: return heff_nomatch(v_x11_24454);
    }
  }
  default: return heff_nomatch(v_x1_24453);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam32(V self, V *args) {
  V v_st_24470 = args[0];
  V v_m_24469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24471 = heff_tr(heff_call(v_m_24469, 1, (V[]){v_st_24470}));
  switch (heff_tag_of(v_x1_24471)) {
  case TAG_MkPair: {
    V v_x11_24472 = heff_field(v_x1_24471, 0);
    V v_st_24473 = heff_field(v_x1_24471, 1);
    V v_ru_24x1_24471_24MkPair = heff_take_reuse_n(v_x1_24471, 3ULL, 2);
    switch (heff_tag_of(v_x11_24472)) {
    case TAG_Left: {
      V v_e_24474 = heff_field(v_x11_24472, 0);
      heff_take_n(v_x11_24472, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24474}), v_st_24473});
    }
    case TAG_Right: {
      V v_x_24475 = heff_field(v_x11_24472, 0);
      V v_ru_24x11_24472_24Right = heff_take_reuse_n(v_x11_24472, 1ULL, 1);
      V v_t_24478;
      switch (heff_tag_of(v_x_24475)) {
      case TAG_At: {
        V v_s_24477 = heff_dup(heff_field(v_x_24475, 1));
        v_t_24478 = v_s_24477;
        break;
      }
      default: heff_nomatch(v_x_24475);
      }
      V v_t_24479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24472_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24475}), v_t_24478});
      return heff_tag_at_n(v_ru_24x1_24471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24479}), v_st_24473});
    }
    default: return heff_nomatch(v_x11_24472);
    }
  }
  default: return heff_nomatch(v_x1_24471);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam33(V self, V *args) {
  V v_st_24487 = args[0];
  V v_m_24486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24488 = heff_tr(heff_call(v_m_24486, 1, (V[]){v_st_24487}));
  switch (heff_tag_of(v_x1_24488)) {
  case TAG_MkPair: {
    V v_x11_24489 = heff_field(v_x1_24488, 0);
    V v_st_24490 = heff_field(v_x1_24488, 1);
    V v_ru_24x1_24488_24MkPair = heff_take_reuse_n(v_x1_24488, 3ULL, 2);
    switch (heff_tag_of(v_x11_24489)) {
    case TAG_Left: {
      V v_e_24491 = heff_field(v_x11_24489, 0);
      heff_take_n(v_x11_24489, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24491}), v_st_24490});
    }
    case TAG_Right: {
      V v_x_24492 = heff_field(v_x11_24489, 0);
      V v_ru_24x11_24489_24Right = heff_take_reuse_n(v_x11_24489, 1ULL, 1);
      V v_t_24495;
      switch (heff_tag_of(v_x_24492)) {
      case TAG_At: {
        V v_s_24494 = heff_dup(heff_field(v_x_24492, 1));
        v_t_24495 = v_s_24494;
        break;
      }
      default: heff_nomatch(v_x_24492);
      }
      V v_t_24496 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24489_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24492}), v_t_24495});
      return heff_tag_at_n(v_ru_24x1_24488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24496}), v_st_24490});
    }
    default: return heff_nomatch(v_x11_24489);
    }
  }
  default: return heff_nomatch(v_x1_24488);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam34(V self, V *args) {
  V v_st_24501 = args[0];
  V v_m_24500 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24502 = heff_tr(heff_call(v_m_24500, 1, (V[]){v_st_24501}));
  switch (heff_tag_of(v_x1_24502)) {
  case TAG_MkPair: {
    V v_x11_24503 = heff_field(v_x1_24502, 0);
    V v_st_24504 = heff_field(v_x1_24502, 1);
    V v_ru_24x1_24502_24MkPair = heff_take_reuse_n(v_x1_24502, 3ULL, 2);
    switch (heff_tag_of(v_x11_24503)) {
    case TAG_Left: {
      V v_e_24505 = heff_field(v_x11_24503, 0);
      heff_take_n(v_x11_24503, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24502_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24505}), v_st_24504});
    }
    case TAG_Right: {
      V v_x_24506 = heff_field(v_x11_24503, 0);
      V v_ru_24x11_24503_24Right = heff_take_reuse_n(v_x11_24503, 1ULL, 1);
      V v_t_24509;
      switch (heff_tag_of(v_x_24506)) {
      case TAG_At: {
        V v_s_24508 = heff_dup(heff_field(v_x_24506, 1));
        v_t_24509 = v_s_24508;
        break;
      }
      default: heff_nomatch(v_x_24506);
      }
      V v_t_24510 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24503_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24506}), v_t_24509});
      return heff_tag_at_n(v_ru_24x1_24502_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24510}), v_st_24504});
    }
    default: return heff_nomatch(v_x11_24503);
    }
  }
  default: return heff_nomatch(v_x1_24502);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam35(V self, V *args) {
  V v_st_24516 = args[0];
  V v_m_24515 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24517 = heff_tr(heff_call(v_m_24515, 1, (V[]){v_st_24516}));
  switch (heff_tag_of(v_x1_24517)) {
  case TAG_MkPair: {
    V v_x11_24518 = heff_field(v_x1_24517, 0);
    V v_st_24519 = heff_field(v_x1_24517, 1);
    V v_ru_24x1_24517_24MkPair = heff_take_reuse_n(v_x1_24517, 3ULL, 2);
    switch (heff_tag_of(v_x11_24518)) {
    case TAG_Left: {
      V v_e_24520 = heff_field(v_x11_24518, 0);
      heff_take_n(v_x11_24518, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24517_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24520}), v_st_24519});
    }
    case TAG_Right: {
      V v_x_24521 = heff_field(v_x11_24518, 0);
      V v_ru_24x11_24518_24Right = heff_take_reuse_n(v_x11_24518, 1ULL, 1);
      V v_t_24524;
      switch (heff_tag_of(v_x_24521)) {
      case TAG_At: {
        V v_s_24523 = heff_dup(heff_field(v_x_24521, 1));
        v_t_24524 = v_s_24523;
        break;
      }
      default: heff_nomatch(v_x_24521);
      }
      V v_t_24525 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24518_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24521}), v_t_24524});
      return heff_tag_at_n(v_ru_24x1_24517_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24525}), v_st_24519});
    }
    default: return heff_nomatch(v_x11_24518);
    }
  }
  default: return heff_nomatch(v_x1_24517);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam36(V self, V *args) {
  V v_st_24533 = args[0];
  V v_m_24532 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24534 = heff_tr(heff_call(v_m_24532, 1, (V[]){v_st_24533}));
  switch (heff_tag_of(v_x1_24534)) {
  case TAG_MkPair: {
    V v_x11_24535 = heff_field(v_x1_24534, 0);
    V v_st_24536 = heff_field(v_x1_24534, 1);
    V v_ru_24x1_24534_24MkPair = heff_take_reuse_n(v_x1_24534, 3ULL, 2);
    switch (heff_tag_of(v_x11_24535)) {
    case TAG_Left: {
      V v_e_24537 = heff_field(v_x11_24535, 0);
      heff_take_n(v_x11_24535, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24534_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24537}), v_st_24536});
    }
    case TAG_Right: {
      V v_x_24538 = heff_field(v_x11_24535, 0);
      V v_ru_24x11_24535_24Right = heff_take_reuse_n(v_x11_24535, 1ULL, 1);
      V v_t_24541;
      switch (heff_tag_of(v_x_24538)) {
      case TAG_At: {
        V v_s_24540 = heff_dup(heff_field(v_x_24538, 1));
        v_t_24541 = v_s_24540;
        break;
      }
      default: heff_nomatch(v_x_24538);
      }
      V v_t_24542 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24535_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24538}), v_t_24541});
      return heff_tag_at_n(v_ru_24x1_24534_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24542}), v_st_24536});
    }
    default: return heff_nomatch(v_x11_24535);
    }
  }
  default: return heff_nomatch(v_x1_24534);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam37(V self, V *args) {
  V v_st_24545 = args[0];
  V v_m_24544 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24546 = heff_tr(heff_call(v_m_24544, 1, (V[]){v_st_24545}));
  switch (heff_tag_of(v_x1_24546)) {
  case TAG_MkPair: {
    V v_x11_24547 = heff_field(v_x1_24546, 0);
    V v_st_24548 = heff_field(v_x1_24546, 1);
    V v_ru_24x1_24546_24MkPair = heff_take_reuse_n(v_x1_24546, 3ULL, 2);
    switch (heff_tag_of(v_x11_24547)) {
    case TAG_Left: {
      V v_e_24549 = heff_field(v_x11_24547, 0);
      heff_take_n(v_x11_24547, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24546_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24549}), v_st_24548});
    }
    case TAG_Right: {
      V v_x_24550 = heff_field(v_x11_24547, 0);
      V v_ru_24x11_24547_24Right = heff_take_reuse_n(v_x11_24547, 1ULL, 1);
      V v_t_24553;
      switch (heff_tag_of(v_x_24550)) {
      case TAG_At: {
        V v_s_24552 = heff_dup(heff_field(v_x_24550, 1));
        v_t_24553 = v_s_24552;
        break;
      }
      default: heff_nomatch(v_x_24550);
      }
      V v_t_24554 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24547_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24550}), v_t_24553});
      return heff_tag_at_n(v_ru_24x1_24546_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24554}), v_st_24548});
    }
    default: return heff_nomatch(v_x11_24547);
    }
  }
  default: return heff_nomatch(v_x1_24546);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam38(V self, V *args) {
  V v_st_24558 = args[0];
  V v_m_24557 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24559 = heff_tr(heff_call(v_m_24557, 1, (V[]){v_st_24558}));
  switch (heff_tag_of(v_x1_24559)) {
  case TAG_MkPair: {
    V v_x11_24560 = heff_field(v_x1_24559, 0);
    V v_st_24561 = heff_field(v_x1_24559, 1);
    V v_ru_24x1_24559_24MkPair = heff_take_reuse_n(v_x1_24559, 3ULL, 2);
    switch (heff_tag_of(v_x11_24560)) {
    case TAG_Left: {
      V v_e_24562 = heff_field(v_x11_24560, 0);
      heff_take_n(v_x11_24560, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24562}), v_st_24561});
    }
    case TAG_Right: {
      V v_x_24563 = heff_field(v_x11_24560, 0);
      V v_ru_24x11_24560_24Right = heff_take_reuse_n(v_x11_24560, 1ULL, 1);
      V v_t_24566;
      switch (heff_tag_of(v_x_24563)) {
      case TAG_At: {
        V v_s_24565 = heff_dup(heff_field(v_x_24563, 1));
        v_t_24566 = v_s_24565;
        break;
      }
      default: heff_nomatch(v_x_24563);
      }
      V v_t_24567 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24560_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24563}), v_t_24566});
      return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24567}), v_st_24561});
    }
    default: return heff_nomatch(v_x11_24560);
    }
  }
  default: return heff_nomatch(v_x1_24559);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam39(V self, V *args) {
  V v_st_24573 = args[0];
  V v_m_24572 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24574 = heff_tr(heff_call(v_m_24572, 1, (V[]){v_st_24573}));
  switch (heff_tag_of(v_x1_24574)) {
  case TAG_MkPair: {
    V v_x11_24575 = heff_field(v_x1_24574, 0);
    V v_st_24576 = heff_field(v_x1_24574, 1);
    V v_ru_24x1_24574_24MkPair = heff_take_reuse_n(v_x1_24574, 3ULL, 2);
    switch (heff_tag_of(v_x11_24575)) {
    case TAG_Left: {
      V v_e_24577 = heff_field(v_x11_24575, 0);
      heff_take_n(v_x11_24575, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24574_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24577}), v_st_24576});
    }
    case TAG_Right: {
      V v_x_24578 = heff_field(v_x11_24575, 0);
      V v_ru_24x11_24575_24Right = heff_take_reuse_n(v_x11_24575, 1ULL, 1);
      V v_t_24581;
      switch (heff_tag_of(v_x_24578)) {
      case TAG_At: {
        V v_s_24580 = heff_dup(heff_field(v_x_24578, 1));
        v_t_24581 = v_s_24580;
        break;
      }
      default: heff_nomatch(v_x_24578);
      }
      V v_t_24582 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24575_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24578}), v_t_24581});
      return heff_tag_at_n(v_ru_24x1_24574_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24582}), v_st_24576});
    }
    default: return heff_nomatch(v_x11_24575);
    }
  }
  default: return heff_nomatch(v_x1_24574);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam40(V self, V *args) {
  V v_st_24586 = args[0];
  V v_m_24585 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24587 = heff_tr(heff_call(v_m_24585, 1, (V[]){v_st_24586}));
  switch (heff_tag_of(v_x1_24587)) {
  case TAG_MkPair: {
    V v_x11_24588 = heff_field(v_x1_24587, 0);
    V v_st_24589 = heff_field(v_x1_24587, 1);
    V v_ru_24x1_24587_24MkPair = heff_take_reuse_n(v_x1_24587, 3ULL, 2);
    switch (heff_tag_of(v_x11_24588)) {
    case TAG_Left: {
      V v_e_24590 = heff_field(v_x11_24588, 0);
      heff_take_n(v_x11_24588, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24587_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24590}), v_st_24589});
    }
    case TAG_Right: {
      V v_x_24591 = heff_field(v_x11_24588, 0);
      V v_ru_24x11_24588_24Right = heff_take_reuse_n(v_x11_24588, 1ULL, 1);
      V v_t_24594;
      switch (heff_tag_of(v_x_24591)) {
      case TAG_At: {
        V v_s_24593 = heff_dup(heff_field(v_x_24591, 1));
        v_t_24594 = v_s_24593;
        break;
      }
      default: heff_nomatch(v_x_24591);
      }
      V v_t_24595 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24588_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24591}), v_t_24594});
      return heff_tag_at_n(v_ru_24x1_24587_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24595}), v_st_24589});
    }
    default: return heff_nomatch(v_x11_24588);
    }
  }
  default: return heff_nomatch(v_x1_24587);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam41(V self, V *args) {
  V v_st_24601 = args[0];
  V v_m_24600 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24602 = heff_tr(heff_call(v_m_24600, 1, (V[]){v_st_24601}));
  switch (heff_tag_of(v_x1_24602)) {
  case TAG_MkPair: {
    V v_x11_24603 = heff_field(v_x1_24602, 0);
    V v_st_24604 = heff_field(v_x1_24602, 1);
    V v_ru_24x1_24602_24MkPair = heff_take_reuse_n(v_x1_24602, 3ULL, 2);
    switch (heff_tag_of(v_x11_24603)) {
    case TAG_Left: {
      V v_e_24605 = heff_field(v_x11_24603, 0);
      heff_take_n(v_x11_24603, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24605}), v_st_24604});
    }
    case TAG_Right: {
      V v_x_24606 = heff_field(v_x11_24603, 0);
      V v_ru_24x11_24603_24Right = heff_take_reuse_n(v_x11_24603, 1ULL, 1);
      V v_t_24609;
      switch (heff_tag_of(v_x_24606)) {
      case TAG_At: {
        V v_s_24608 = heff_dup(heff_field(v_x_24606, 1));
        v_t_24609 = v_s_24608;
        break;
      }
      default: heff_nomatch(v_x_24606);
      }
      V v_t_24610 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24603_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24606}), v_t_24609});
      return heff_tag_at_n(v_ru_24x1_24602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24610}), v_st_24604});
    }
    default: return heff_nomatch(v_x11_24603);
    }
  }
  default: return heff_nomatch(v_x1_24602);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam42(V self, V *args) {
  V v_st_24616 = args[0];
  V v_m_24615 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24617 = heff_tr(heff_call(v_m_24615, 1, (V[]){v_st_24616}));
  switch (heff_tag_of(v_x1_24617)) {
  case TAG_MkPair: {
    V v_x11_24618 = heff_field(v_x1_24617, 0);
    V v_st_24619 = heff_field(v_x1_24617, 1);
    V v_ru_24x1_24617_24MkPair = heff_take_reuse_n(v_x1_24617, 3ULL, 2);
    switch (heff_tag_of(v_x11_24618)) {
    case TAG_Left: {
      V v_e_24620 = heff_field(v_x11_24618, 0);
      heff_take_n(v_x11_24618, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24617_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24620}), v_st_24619});
    }
    case TAG_Right: {
      V v_x_24621 = heff_field(v_x11_24618, 0);
      V v_ru_24x11_24618_24Right = heff_take_reuse_n(v_x11_24618, 1ULL, 1);
      V v_t_24624;
      switch (heff_tag_of(v_x_24621)) {
      case TAG_At: {
        V v_s_24623 = heff_dup(heff_field(v_x_24621, 1));
        v_t_24624 = v_s_24623;
        break;
      }
      default: heff_nomatch(v_x_24621);
      }
      V v_t_24625 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24618_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24621}), v_t_24624});
      return heff_tag_at_n(v_ru_24x1_24617_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24625}), v_st_24619});
    }
    default: return heff_nomatch(v_x11_24618);
    }
  }
  default: return heff_nomatch(v_x1_24617);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam43(V self, V *args) {
  V v_st_24631 = args[0];
  V v_m_24630 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24632 = heff_tr(heff_call(v_m_24630, 1, (V[]){v_st_24631}));
  switch (heff_tag_of(v_x1_24632)) {
  case TAG_MkPair: {
    V v_x11_24633 = heff_field(v_x1_24632, 0);
    V v_st_24634 = heff_field(v_x1_24632, 1);
    V v_ru_24x1_24632_24MkPair = heff_take_reuse_n(v_x1_24632, 3ULL, 2);
    switch (heff_tag_of(v_x11_24633)) {
    case TAG_Left: {
      V v_e_24635 = heff_field(v_x11_24633, 0);
      heff_take_n(v_x11_24633, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24635}), v_st_24634});
    }
    case TAG_Right: {
      V v_x_24636 = heff_field(v_x11_24633, 0);
      V v_ru_24x11_24633_24Right = heff_take_reuse_n(v_x11_24633, 1ULL, 1);
      V v_t_24639;
      switch (heff_tag_of(v_x_24636)) {
      case TAG_At: {
        V v_s_24638 = heff_dup(heff_field(v_x_24636, 1));
        v_t_24639 = v_s_24638;
        break;
      }
      default: heff_nomatch(v_x_24636);
      }
      V v_t_24640 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24633_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24636}), v_t_24639});
      return heff_tag_at_n(v_ru_24x1_24632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24640}), v_st_24634});
    }
    default: return heff_nomatch(v_x11_24633);
    }
  }
  default: return heff_nomatch(v_x1_24632);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam44(V self, V *args) {
  V v_st_24648 = args[0];
  V v_m_24647 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24649 = heff_tr(heff_call(v_m_24647, 1, (V[]){v_st_24648}));
  switch (heff_tag_of(v_x1_24649)) {
  case TAG_MkPair: {
    V v_x11_24650 = heff_field(v_x1_24649, 0);
    V v_st_24651 = heff_field(v_x1_24649, 1);
    V v_ru_24x1_24649_24MkPair = heff_take_reuse_n(v_x1_24649, 3ULL, 2);
    switch (heff_tag_of(v_x11_24650)) {
    case TAG_Left: {
      V v_e_24652 = heff_field(v_x11_24650, 0);
      heff_take_n(v_x11_24650, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24649_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24652}), v_st_24651});
    }
    case TAG_Right: {
      V v_x_24653 = heff_field(v_x11_24650, 0);
      V v_ru_24x11_24650_24Right = heff_take_reuse_n(v_x11_24650, 1ULL, 1);
      V v_t_24656;
      switch (heff_tag_of(v_x_24653)) {
      case TAG_At: {
        V v_s_24655 = heff_dup(heff_field(v_x_24653, 1));
        v_t_24656 = v_s_24655;
        break;
      }
      default: heff_nomatch(v_x_24653);
      }
      V v_t_24657 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24650_24Right, TAG_BadFieldSet, 1, (V[]){v_x_24653}), v_t_24656});
      return heff_tag_at_n(v_ru_24x1_24649_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24657}), v_st_24651});
    }
    default: return heff_nomatch(v_x11_24650);
    }
  }
  default: return heff_nomatch(v_x1_24649);
  }
}

HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24s1266236307x1641993968_24cpr(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411}});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        heff_take_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2418_24Left, TAG_Left, 1, (V[]){v_e_2420}), v_st_2419}});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_f_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return ((HeffT2){{v_f_2425, v_st_2419}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2418)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2417)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2410)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0, 77, "a segment of a binary pattern holds a name, `_`, a number, a string or a rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1, 101, "only the last segment takes what is left: say this one's size, `x::binary-size(n)`, `x::bits-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V v_r_240, V v_last_241, V v_sp_242, V v_p_243) {
top: ;
  V v_x2_244 = (g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0, 1, 2, (V[]){v_x2_244, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1, 2, 4, (V[]){v_r_240, v_p_243, v_sp_242, heff_dup(v_last_241)})});
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_x2_244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x2_244) == NTAG(TAG_True))) {
    heff_drop(v_x2_244);
    heff_drop(v_sp_242);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_p_245});
  } else {
    heff_drop(v_x2_244);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_p_245});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_z_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_last_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_248);
  V v_m_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_249}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_last_241);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_t_2435;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_x11_2416 = heff_dup(heff_field(v_x_2415, 0));
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2416, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2416, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2425 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          v_t_2435 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_IntValue, 1, (V[]){v_v_2425});
          break;
        }
        case TAG_PatFloat: {
          heff_take_na(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_FloatValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_RuneValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2416, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2416, 0ULL, 3);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          v_t_2435 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2416);
        }
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      HeffT2 v_t_2436 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_242); V a_2 = v_x_2415; V a_3 = v_t_2435; V a_4 = v_st_2413; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esegmentOf_24s1266236307x1641993968_24cpr(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      {
        V v_field_2437 = v_t_2436.f[0];
        V v_field_2438 = v_t_2436.f[1];
        V v_x11_2439 = v_field_2437;
        V v_st_2440 = v_field_2438;
        switch (heff_tag_of(v_x11_2439)) {
        case TAG_Left: {
          V v_e_2441 = heff_field(v_x11_2439, 0);
          heff_take_n(v_x11_2439, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_last_241);
          return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2441}), v_st_2440});
        }
        case TAG_Right: {
          V v_x_2442 = heff_field(v_x11_2439, 0);
          heff_take_n(v_x11_2439, 1ULL, 1);
          if (!(heff_dup(v_last_241) == NTAG(TAG_True))) {
            heff_drop(v_last_241);
            V v_t_2445;
            switch (heff_tag_of(v_x_2442)) {
            case TAG_At: {
              V v_x_2443 = heff_dup(heff_field(v_x_2442, 0));
              v_t_2445 = v_x_2443;
              break;
            }
            default: heff_nomatch(v_x_2442);
            }
            V v_t_2446 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2445); r_; });
            if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
              heff_drop(v_x_2442);
              heff_drop(v_t_2446);
              V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1), v_sp_242, NTAG(TAG_Nothing)});
              return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2447}), v_st_2440});
            } else {
              heff_drop(v_sp_242);
              heff_drop(v_t_2446);
              return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2442}), v_st_2440});
            }
          } else {
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2442}), v_st_2440});
          }
        }
        default: return heff_nomatch(v_x11_2439);
        }
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_x_241, 2)), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V v_r_240, V v_names_241, V v_pats_242, V v_rhs_243, V v_w_244, V v_st_245) {
top: ;
  V v_binders_246 = heff_take_field(v_st_245, 3);
  V v_toks_247 = heff_take_field(v_st_245, 0);
  V v_scope_248 = heff_take_field(v_st_245, 1);
  V v_known_249 = heff_take_field(v_st_245, 2);
  V v_fix_2410 = heff_take_field(v_st_245, 5);
  V v_lenient_2411 = heff_take_field(v_st_245, 6);
  V v_at_2412 = heff_take_field(v_st_245, 7);
  V v_knot_2413 = heff_get_n(v_st_245, 8, 9);
  V v_t_2414 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_241)));
  V v_f_2415 = heff_get_n(v_t_2414, 0, 2);
  HeffT2 v_t_2416 = ({ V a_0 = v_binders_246; V a_1 = v_f_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_f_2415); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_t_2420;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2418);
      v_t_2420 = NTAG(TAG_Nil);
    }
    V v_pv_2421 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2420));
    V v_m_2422 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(v_r_240, 1)), heff_dup(v_pats_242)));
    V v_x1_2423 = heff_tr(heff_call(v_m_2422, 1, (V[]){heff_rec_n(9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, (V[]){v_toks_247, v_scope_248, v_known_249, v_binders_246, v_pv_2421, v_fix_2410, v_lenient_2411, v_at_2412, v_knot_2413})}));
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_MkPair: {
      V v_x11_2424 = heff_field(v_x1_2423, 0);
      V v_st_2425 = heff_field(v_x1_2423, 1);
      V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
      switch (heff_tag_of(v_x11_2424)) {
      case TAG_Left: {
        V v_e_2426 = heff_field(v_x11_2424, 0);
        V v_ru_24x11_2424_24Left = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_names_241);
        heff_drop(v_pats_242);
        heff_drop(v_rhs_243);
        heff_drop(v_t_2420);
        heff_drop_cell(v_ru_24x1_2423_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2424_24Left, TAG_Left, 1, (V[]){v_e_2426}), v_st_2425}});
      }
      case TAG_Right: {
        V v_x_2427 = heff_field(v_x11_2424, 0);
        heff_take_n(v_x11_2424, 1ULL, 1);
        V v_t_2428 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2420));
        V v_t_2429 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2428}));
        V v_t_2430 = ({ V a_0 = v_t_2429; V a_1 = v_pats_242; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_242); r_; });
        V v_t_2431 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2420); r_; });
        V v_t_2432 = (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x1_2423_24MkPair, v_t_2430, v_t_2431));
        V v_m_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_243}));
        V v_t_2434 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2425, 495ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2432, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0, 1, 5, (V[]){v_m_2433, heff_dup(v_w_244), v_r_240, v_names_241, v_x_2427}), v_t_2434));
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2424)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2423)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args) {
  V v_st_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2440}), v_st_2441});
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args) {
  V v_rhs_27_2446 = args[0];
  V v_z_2447 = args[1];
  V v_names_241 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_241)));
  V v_t_2449 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_241)));
  V v_t_2450 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_241)));
  V v_t_2451 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2449, 0, 2), heff_get_n(v_t_2450, 1, 2), v_x_2427, heff_dup(v_rhs_27_2446)});
  V v_t_2454;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_2454 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2452 = heff_dup(heff_field(v_names_241, 0));
    v_t_2454 = heff_get_n(v_t_2452, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2457;
  switch (heff_tag_of(v_rhs_27_2446)) {
  case TAG_At: {
    V v_s_2456 = heff_dup(heff_field(v_rhs_27_2446, 1));
    v_t_2457 = v_s_2456;
    break;
  }
  default: heff_nomatch(v_rhs_27_2446);
  }
  V v_t_2458 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_t_2457, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2461;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_2461 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2459 = heff_field(v_names_241, 0);
    heff_take_n(v_names_241, 1ULL, 2);
    v_t_2461 = heff_get_n(v_t_2459, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2464;
  switch (heff_tag_of(v_rhs_27_2446)) {
  case TAG_At: {
    V v_s_2463 = heff_field(v_rhs_27_2446, 1);
    heff_take_n(v_rhs_27_2446, 2ULL, 2);
    v_t_2464 = v_s_2463;
    break;
  }
  default: heff_nomatch(v_rhs_27_2446);
  }
  V v_t_2465 = ({ V rv_0 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_t_2464, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2466 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2448, 0, 2), heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_t_2458}), v_t_2465});
  V v_x_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2467}), v_z_2447});
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args) {
  V v_st_2435 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_w_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_names_241 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2436 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2435}));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_MkPair: {
    V v_x11_2437 = heff_field(v_x1_2436, 0);
    V v_st_2438 = heff_field(v_x1_2436, 1);
    V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_Left: {
      V v_e_2439 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      heff_drop(v_w_244);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_names_241);
      heff_drop(v_x_2427);
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      V v_t_2445;
      switch (heff_tag_of(v_w_244)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 3);
        v_t_2445 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1, 1, 1, (V[]){v_x_2440});
        break;
      }
      case TAG_Just: {
        V v_it1_2442 = heff_field(v_w_244, 0);
        heff_take_n(v_w_244, 1ULL, 1);
        switch (heff_tag_of(v_it1_2442)) {
        case TAG_MkPair: {
          V v_kw_2443 = heff_field(v_it1_2442, 0);
          V v_ds_2444 = heff_field(v_it1_2442, 1);
          heff_take_n(v_it1_2442, 3ULL, 2);
          v_t_2445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_clo), 4, (V[]){v_r_240, v_kw_2443, v_ds_2444, v_x_2440}));
          break;
        }
        default: heff_nomatch(v_it1_2442);
        }
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_2436_24MkPair, v_t_2445, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2, 2, 2, (V[]){v_names_241, v_x_2427}), v_st_2438));
    }
    default: return heff_nomatch(v_x11_2437);
    }
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Sig: {
      V v_f_245 = heff_field(v_x11_242, 1);
      V v_fsp_246 = heff_field(v_x11_242, 2);
      V v_ty_247 = heff_field(v_x11_242, 3);
      V v_sp_248 = heff_field(v_x11_242, 4);
      heff_take_n(v_x11_242, 30ULL, 5);
      V v_end_249 = heff_take_field(v_sp_248, 1);
      V v_start_2410 = heff_get_n(v_sp_248, 0, 2);
      HeffT2 v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_245, heff_dup(v_rest_243)));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_es_2414 = v_field_2413;
          V v_eqns_2415 = heff_take_field(v_es_2414, 0);
          V v_end_2416 = heff_get_n(v_es_2414, 1, 2);
          V v_a_2417 = v_end_249;
          V v_b_2418 = v_end_2416;
          V v_t_2419;
          if (heff_intLt_c_lent(v_a_2417, v_b_2418, 0)) {
            heff_drop(v_a_2417);
            v_t_2419 = v_b_2418;
          } else {
            heff_drop(v_b_2418);
            v_t_2419 = v_a_2417;
          }
          V v_t_2420 = heff_rec_n(5, shape_name__span__ty__eqns__whole, (V[]){v_f_245, v_fsp_246, v_ty_247, v_eqns_2415, heff_rec_n(2, shape_start__end, (V[]){v_start_2410, v_t_2419})});
          V v_cell_2421 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), heff_hole()});
          V v_u_2422 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2421));
          heff_drop(v_u_2422);
          V t_0 = v_rest_243;
          V t_1 = v_cell_2421;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_f_245);
          heff_drop(v_fsp_246);
          heff_drop(v_ty_247);
          heff_drop(v_end_249);
          heff_drop(v_start_2410);
          heff_drop(v_field_2413);
          V t_0 = v_rest_243;
          V t_1 = v_d_241;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
      }
    }
    case TAG_Eqn: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Whole: {
      V v_cell_2427 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2428 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2427));
      heff_drop(v_u_2428);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2427;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Doc: {
      V v_cell_2430 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2431 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2430));
      heff_drop(v_u_2431);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2430;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualDefs_24dps(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eedgesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eedgesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eedgesOf(V v_scope_240, V v_d_241) {
top: ;
  V v_ops_242 = heff_take_field(v_d_241, 1);
  V v_above_243 = heff_take_field(v_d_241, 2);
  V v_below_244 = heff_get_n(v_d_241, 3, 8);
  switch (heff_tag_of(v_ops_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_scope_240, 2);
    heff_drop(v_above_243);
    heff_drop(v_below_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_op_245 = heff_field(v_ops_242, 0);
    V v_ru_24ops_242_24Cons = heff_take_reuse_n(v_ops_242, 1ULL, 2);
    V v_t_2415 = (g_list_2emap_24tok2(v_ru_24ops_242_24Cons, heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam0, 1, 2, (V[]){heff_dup(v_scope_240), heff_dup(v_op_245)}), v_above_243));
    V v_t_2416 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2415));
    V v_t_2424 = (g_list_2ekeepIf(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam2, 1, 1, (V[]){heff_dup(v_scope_240)}), v_below_244));
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam4, 1, 2, (V[]){v_scope_240, v_op_245}), v_t_2424));
    V v_t_2434 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2433));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2416, v_t_2434);
  }
  default: return heff_nomatch(v_ops_242);
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eedgesOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args) {
  V v_g_248 = args[0];
  V v_r_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_247, 1, 7)}));
  return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_g_248, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args) {
  V v_r_247 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam1, 1, 1, (V[]){v_r_247}), heff_get_n(v_scope_240, 0, 2)));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_g_2413 = v_field_2412;
      V v_t_2414 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_op_245, 1, 7), heff_get_n(v_g_2413, 0, 5)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    } else {
      heff_drop_rec(v_op_245, 7);
      heff_drop(v_field_2412);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_r_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2417, 1, 7)}));
  return ({ V a_0 = v_t_2419; V b_1 = heff_get_n(v_g_2418, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args) {
  V v_r_2417 = args[0];
  V v_scope_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2420 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam3, 1, 1, (V[]){v_r_2417}), heff_get_n(v_scope_240, 0, 2)));
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_g_2423 = v_field_2422;
      V v_ret_24bool = heff_bool(!(heff_dup(heff_rfield(v_g_2423, 3)) == NTAG(TAG_True)));
      heff_drop_rec(v_g_2423, 5);
      return v_ret_24bool;
    } else {
      heff_drop(v_field_2422);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args) {
  V v_g_2426 = args[0];
  V v_r_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2425, 1, 7)}));
  return ({ V a_0 = v_t_2427; V b_1 = heff_get_n(v_g_2426, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args) {
  V v_r_2425 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2428 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam5, 1, 1, (V[]){v_r_2425}), heff_get_n(v_scope_240, 0, 2)));
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_g_2431 = v_field_2430;
      V v_t_2432 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_g_2431, 0, 5), heff_get_n(v_op_245, 1, 7)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
    } else {
      heff_drop_rec(v_op_245, 7);
      heff_drop(v_field_2430);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(V v_declared_240, V v_start_241, V v_names_242, V v_ty_243, V v_z_244) {
top: ;
  V v_t_245 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_242)));
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_245));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_declared_240);
      heff_drop(v_start_241);
      heff_drop(v_names_242);
      heff_drop(v_ty_243);
      V v_d_249 = v_field_248;
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_249}), v_z_244}});
    } else {
      heff_drop(v_field_248);
      V v_x1_2410 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_243), v_z_244));
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_MkPair: {
        V v_x11_2411 = heff_field(v_x1_2410, 0);
        V v_st_2412 = heff_field(v_x1_2410, 1);
        heff_take_n(v_x1_2410, 3ULL, 2);
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_Left: {
          V v_e_2413 = heff_field(v_x11_2411, 0);
          V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
          heff_drop(v_declared_240);
          heff_drop(v_start_241);
          heff_drop(v_names_242);
          heff_drop(v_ty_243);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2411_24Left, TAG_Left, 1, (V[]){v_e_2413}), v_st_2412}});
        }
        case TAG_Right: {
          V v_x_2414 = heff_field(v_x11_2411, 0);
          V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
          V v_t_2415 = (g_list_2emap_24s348263401x2104816219(heff_dup(v_names_242)));
          V v_st_2421 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr_lam0, 2, 1, (V[]){heff_dup(v_x_2414)}); V a_1 = v_st_2412; V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
          V v_t_2422 = (g_heff_2esyntax_2ecst_2elastE(v_ty_243));
          V v_b_2423 = heff_get_n(v_t_2422, 4, 9);
          V v_x_2424 = (g_list_2emap_24f2041933216x1458595349(v_declared_240, v_x_2414, v_start_241, v_b_2423, v_names_242));
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){v_x_2424}), v_st_2421}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2411)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2410)}});
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr_lam0(V self, V *args) {
  V v_s_2416 = args[0];
  V v_n_2417 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_names_2418 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_x_2414)));
  V v_implicits_2419 = (g_heff_2esyntax_2esurface_2epiImplicits(v_x_2414));
  V v_t_2420 = heff_rec_n(3, shape_f__names__implicits, (V[]){heff_get_n(v_n_2417, 0, 2), v_names_2418, v_implicits_2419});
  return (g_heff_2esyntax_2esurface_2eaddBinders(v_t_2420, v_s_2416));
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V v_c_240, V v_args_241) {
top: ;
  V v_text_242 = heff_take_field(v_c_240, 1);
  V v_start_243 = heff_take_field(v_c_240, 3);
  V v_end_244 = heff_get_n(v_c_240, 4, 9);
  V v_m_245 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 0)), v_args_241));
  return heff_clo_n(g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0, 1, 4, (V[]){v_m_245, v_text_242, v_start_243, v_end_244});
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_text_242 = heff_env(self)[1];
  V v_start_243 = heff_env(self)[2];
  V v_end_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_text_242);
      heff_drop(v_start_243);
      heff_drop(v_end_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_248_24Right, TAG_ETag, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
      V v_x_2413 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2412, v_x_2411));
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2413}), v_st_249});
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}

HeffT2 g_heff_2esyntax_2esurface_2etheoryFieldOne_24s1473805472x1314815828_24cpr(V v_ty_240, V v_d_241, V v_x_242, V v_st_243) {
top: ;
  V v_text_244 = heff_take_field(v_x_242, 1);
  V v_start_245 = heff_take_field(v_x_242, 3);
  V v_end_246 = heff_get_n(v_x_242, 4, 9);
  V v_x1_247 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_ty_240, v_st_243));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_text_244);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Left, TAG_Left, 1, (V[]){v_e_2410}), v_st_249}});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_24cpr(v_d_241, v_st_249));
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_x11_2415 = v_field_2413;
        V v_st_2416 = v_field_2414;
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_text_244);
          heff_drop(v_start_245);
          heff_drop(v_end_246);
          heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416}});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_tag_n(TAG_DeclareField, 4, (V[]){heff_dup(v_text_244), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_245), v_end_246}), heff_dup(v_x_2411), heff_dup(v_x_2418)});
          V v_t_2421;
          switch (heff_tag_of(v_x_2418)) {
          case TAG_Nothing: {
            v_t_2421 = v_x_2411;
            break;
          }
          case TAG_Just: {
            V v_x_2420 = heff_field(v_x_2418, 0);
            heff_take_n(v_x_2418, 1ULL, 1);
            heff_drop(v_x_2411);
            v_t_2421 = v_x_2420;
            break;
          }
          default: heff_nomatch(v_x_2418);
          }
          V v_t_2424;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 2ULL, 2);
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          V v_t_2425 = ({ V rv_0 = v_start_245; V rr_ = heff_rec_reuse_nf(v_t_2424, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_f_2426 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_At, 2, (V[]){v_t_2419, v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_244, heff_take_field(v_st_2416, 1)});
          V v_f_2428 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_2416, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return ((HeffT2){{v_f_2426, v_f_2428}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2415)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V v_k_240, V v_ds_241, V v_st_242) {
top: ;
  V v_toks_243 = heff_take_field(v_st_242, 0);
  V v_scope_244 = heff_take_field(v_st_242, 1);
  V v_known_245 = heff_take_field(v_st_242, 2);
  V v_binders_246 = heff_take_field(v_st_242, 3);
  V v_patVars_247 = heff_take_field(v_st_242, 4);
  V v_fix_248 = heff_take_field(v_st_242, 5);
  V v_lenient_249 = heff_take_field(v_st_242, 6);
  V v_at_2410 = heff_get_n(v_st_242, 7, 9);
  V v_k_2411 = (g_heff_2esyntax_2esurface_2eknotOf(v_k_240, v_ds_241));
  HeffT2 v_t_2412 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), v_ds_241, heff_rec_n(9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, (V[]){v_toks_243, v_scope_244, v_known_245, v_binders_246, v_patVars_247, v_fix_248, v_lenient_249, v_at_2410, v_k_2411})));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_x11_2415 = v_field_2413;
    V v_st_2416 = v_field_2414;
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      V v_e_2417 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416}});
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      V v_st_2419 = ({ V rv_8 = heff_dup(g_std_2emap_2eempty_get()); V rr_ = heff_rec_reuse_nf(v_st_2416, 255ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
      V v_items_2420 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2418));
      V v_items_2421 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2420, NTAG(TAG_Nil)));
      V v_t_2422 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2426 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0, 2, 1, (V[]){heff_dup(v_st_2419)}); V a_1 = v_t_2422; V a_2 = v_items_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2421); r_; });
      V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2426, 3, 4)));
      V v_items_2428 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2418));
      V v_items_2429 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2428, NTAG(TAG_Nil)));
      V v_t_2430 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2431 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2429));
      V v_t_2432 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2429));
      V v_t_2433 = ({ V a_0 = v_t_2430; V a_1 = v_t_2431; V a_2 = v_t_2432; V a_3 = v_items_2429; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2430); heff_drop(v_t_2431); heff_drop(v_t_2432); r_; });
      V v_t_2434 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2433));
      V v_t_2435 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2427, v_t_2434));
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nil: {
        V v_items_2436 = ({ V a_0 = v_x_2418; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2418); r_; });
        V v_x_2437 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2436, NTAG(TAG_Nil)));
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){v_x_2437}), v_st_2419}});
      }
      case TAG_Cons: {
        V v_d_2438 = heff_field(v_t_2435, 0);
        heff_take_n(v_t_2435, 1ULL, 2);
        heff_drop(v_x_2418);
        heff_drop_cell(v_ru_24x11_2415_24Right, 1);
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2438}), v_st_2419}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2435)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2415)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args) {
  V v_d_2423 = args[0];
  V v_it_2424 = args[1];
  V v_st_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2423, 2)), v_it_2424));
  return ({ V a_0 = heff_get_n(v_st_2419, 7, 9); V a_1 = v_d_2423; V a_2 = v_t_2425; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V v_kw_240, V v_ds_241, V v_z_242) {
top: ;
  V v_start_243 = heff_take_field(v_kw_240, 3);
  V v_end_244 = heff_get_n(v_kw_240, 4, 9);
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(heff_dup(v_ds_241)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_f1_248 = v_field_247;
      HeffT2 v_t_249 = (g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0), heff_dup(v_f1_248)), heff_dup(v_ds_241), v_z_242));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x11_2412 = v_field_2410;
        V v_st_2413 = v_field_2411;
        switch (heff_tag_of(v_x11_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          heff_drop(v_ds_241);
          heff_drop(v_start_243);
          heff_drop(v_end_244);
          heff_drop(v_f1_248);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Left, TAG_Left, 1, (V[]){v_e_2414}), v_st_2413}});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          V v_t_2416 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2415)));
          V v_t_2417 = (g_list_2emap_24s2081681776x559624592(v_t_2416));
          V v_t_2418 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2417));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nil: {
            V v_x1_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
            V v_e_2423;
            switch (heff_tag_of(v_x1_2419)) {
            case TAG_Nil: {
              v_e_2423 = heff_dup(v_end_244);
              break;
            }
            case TAG_Cons: {
              V v_x_2420 = heff_field(v_x1_2419, 0);
              heff_take_n(v_x1_2419, 1ULL, 2);
              V v_t_2422 = (g_heff_2esyntax_2ecst_2elastD(v_x_2420));
              v_e_2423 = heff_get_n(v_t_2422, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2419);
            }
            V v_t_2424 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2415));
            V v_x_2425 = (g_heff_2esyntax_2esurface_2emutualOut(heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_243), v_end_244}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_e_2423}), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1), heff_dup(v_f1_248)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2), v_f1_248), v_t_2424));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){v_x_2425}), v_st_2413}});
          }
          case TAG_Cons: {
            V v_d_2426 = heff_field(v_t_2418, 0);
            heff_take_n(v_t_2418, 1ULL, 2);
            heff_drop(v_ds_241);
            heff_drop(v_start_243);
            heff_drop(v_end_244);
            heff_drop(v_f1_248);
            heff_drop(v_x_2415);
            heff_drop_cell(v_ru_24x11_2412_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2426}), v_st_2413}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2418)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
        }
      }
    } else {
      heff_drop(v_ds_241);
      heff_drop(v_field_247);
      V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244}), NTAG(TAG_Nothing)});
      V v_f_2429 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2428});
      return ((HeffT2){{v_f_2429, v_z_242}});
    }
  }
}
Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V v_decls_240, V v_groups_241, V v_edges_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_241)));
  V v_t_244 = (g_heff_2esyntax_2efixity_2enubByG(v_t_243));
  V v_t_245 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_246 = (g_heff_2esyntax_2efixity_2enubByE(v_t_245));
  V v_t_247 = heff_rec_n(2, shape_groups__above, (V[]){v_t_244, v_t_246});
  V v_t_248 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_241)));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByG(v_t_248));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_edges_242)));
  V v_t_2411 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2410));
  V v_t_2412 = heff_rec_n(2, shape_groups__above, (V[]){v_t_249, v_t_2411});
  V v_t_2413 = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(v_t_247, v_t_2412, v_decls_240));
  return heff_rec_n(2, shape_fixities__diags, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_groups_241, v_edges_242}), v_t_2413});
}
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_s_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_s_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0), v_t_246, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1)})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(a[0], a[1]);
}