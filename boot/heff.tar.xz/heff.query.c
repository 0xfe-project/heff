// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2equery_2ecatMaybesQ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ecatMaybesQ_entry, 1, 0};

V g_heff_2equery_2ecatMaybesQ(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x11_241);
      heff_drop(v_ru_24x1_240_24Cons);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take(v_x11_241, 1ULL);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2equery_2ecatMaybesQ(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2equery_2ecatMaybesQ_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ecatMaybesQ(a[0]);
}
Clo g_heff_2equery_2eisNameChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eisNameChar_entry, 1, 0};

V g_heff_2equery_2eisNameChar(V v_c_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_c_240), MK_INT(95LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_c_240);
    heff_drop(v_t_241);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_242 = heff_intEq(heff_dup(v_c_240), MK_INT(39LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      heff_drop(v_t_242);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_242);
      V v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(47LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_c_240);
        heff_drop(v_t_243);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_243);
        V v_t_244 = heff_intLe(MK_INT(97LL), heff_dup(v_c_240));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_t_244);
          V v_t_245 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_c_240);
            heff_drop(v_t_245);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            heff_drop(v_t_245);
            V v_t_246 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_t_246);
              V v_t_247 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_c_240);
                heff_drop(v_t_247);
                return NTAG(TAG_True);
              }
              case TAG_False: {
                heff_drop(v_t_247);
                V v_t_248 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  heff_drop(v_t_248);
                  return heff_intLe(v_c_240, MK_INT(57LL));
                }
                case TAG_False: {
                  heff_drop(v_c_240);
                  heff_drop(v_t_248);
                  return NTAG(TAG_False);
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            case TAG_False: {
              heff_drop(v_t_246);
              V v_t_249 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
              switch (heff_tag_of(v_t_249)) {
              case TAG_True: {
                heff_drop(v_t_249);
                return heff_intLe(v_c_240, MK_INT(57LL));
              }
              case TAG_False: {
                heff_drop(v_c_240);
                heff_drop(v_t_249);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_249);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        case TAG_False: {
          heff_drop(v_t_244);
          V v_t_2410 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            heff_drop(v_t_2410);
            V v_t_2411 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
            switch (heff_tag_of(v_t_2411)) {
            case TAG_True: {
              heff_drop(v_c_240);
              heff_drop(v_t_2411);
              return NTAG(TAG_True);
            }
            case TAG_False: {
              heff_drop(v_t_2411);
              V v_t_2412 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
              switch (heff_tag_of(v_t_2412)) {
              case TAG_True: {
                heff_drop(v_t_2412);
                return heff_intLe(v_c_240, MK_INT(57LL));
              }
              case TAG_False: {
                heff_drop(v_c_240);
                heff_drop(v_t_2412);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_2412);
              }
            }
            default: return heff_nomatch(v_t_2411);
            }
          }
          case TAG_False: {
            heff_drop(v_t_2410);
            V v_t_2413 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
            switch (heff_tag_of(v_t_2413)) {
            case TAG_True: {
              heff_drop(v_t_2413);
              return heff_intLe(v_c_240, MK_INT(57LL));
            }
            case TAG_False: {
              heff_drop(v_c_240);
              heff_drop(v_t_2413);
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_t_2413);
            }
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2equery_2eisNameChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eisNameChar(a[0]);
}
Clo g_heff_2equery_2ewordAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ewordAt_entry, 3, 0};

V g_heff_2equery_2ewordAt(V v_src_240, V v_p_241, V v_x_242) {
top: ;
  V v_t_243 = heff_intEq(heff_dup(v_p_241), MK_INT(0LL));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    V v_t_244 = heff_intAdd(v_p_241, heff_strLength(v_x_242));
    V v_x1_245 = (g_heff_2equery_2eisNameChar(heff_strCharCode(v_src_240, v_t_244)));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_True: {
      heff_drop(v_x1_245);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_x1_245);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_246 = heff_strCharCode(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL)));
    V v_x1_247 = (g_heff_2equery_2eisNameChar(v_t_246));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_p_241);
      heff_drop(v_x_242);
      heff_drop(v_x1_247);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_x1_247);
      V v_t_248 = heff_intAdd(v_p_241, heff_strLength(v_x_242));
      V v_x1_249 = (g_heff_2equery_2eisNameChar(heff_strCharCode(v_src_240, v_t_248)));
      switch (heff_tag_of(v_x1_249)) {
      case TAG_True: {
        heff_drop(v_x1_249);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        heff_drop(v_x1_249);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_249);
      }
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2equery_2ewordAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ewordAt(a[0], a[1], a[2]);
}
Clo g_heff_2equery_2enameInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2enameInGo_entry, 4, 0};

V g_heff_2equery_2enameInGo(V v_src_240, V v_x_241, V v_sp_242, V v_from_243) {
top: ;
  V v_t_244 = (g_prelude_2eindexFrom(heff_dup(v_x_241), heff_dup(v_src_240), v_from_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    heff_drop(v_x_241);
    heff_drop(v_t_244);
    return v_sp_242;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    V v_t_246 = heff_intAdd(heff_dup(v_p_245), heff_strLength(heff_dup(v_x_241)));
    V v_t_247 = heff_intLe(v_t_246, heff_get(heff_dup(v_sp_242), LBL_end));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      V v_t_248 = (g_heff_2equery_2ewordAt(heff_dup(v_src_240), heff_dup(v_p_245), heff_dup(v_x_241)));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_src_240);
        heff_drop(v_sp_242);
        heff_drop(v_t_248);
        V v_t_249 = heff_intAdd(heff_dup(v_p_245), heff_strLength(v_x_241));
        return heff_rec(2, shape_305_78, (V[]){v_p_245, v_t_249});
      }
      case TAG_False: {
        heff_drop(v_t_248);
        V t_0 = v_src_240;
        V t_1 = v_x_241;
        V t_2 = v_sp_242;
        V t_3 = heff_intAdd(v_p_245, MK_INT(1LL));
        v_src_240 = t_0;
        v_x_241 = t_1;
        v_sp_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_False: {
      heff_drop(v_src_240);
      heff_drop(v_x_241);
      heff_drop(v_p_245);
      heff_drop(v_t_247);
      return v_sp_242;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2equery_2enameInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2enameInGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2equery_2enubByStart_lam0(V self, V *args);
Clo g_heff_2equery_2enubByStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2enubByStart_entry, 1, 0};

V g_heff_2equery_2enubByStart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2enubByStart_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2equery_2enubByStart(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2equery_2enubByStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2enubByStart(a[0]);
}
V g_heff_2equery_2enubByStart_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_intEq(heff_get(v_y_243, LBL_start), heff_get(v_x_241, LBL_start));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2eatLine_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
Clo g_heff_2equery_2eatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eatLine_entry, 2, 0};

V g_heff_2equery_2eatLine(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = (g_heff_2erender_2elineColGo(heff_dup(v_src_240), heff_get(heff_dup(v_sp_241), LBL_start), MK_INT(0LL), MK_INT(0LL)));
  V v_t_243 = heff_intAdd(heff_get(v_t_242, LBL_line), MK_INT(1LL));
  V v_t_244 = (g_heff_2erender_2elineColGo(v_src_240, heff_get(v_sp_241, LBL_start), MK_INT(0LL), MK_INT(0LL)));
  V v_t_245 = heff_intAdd(heff_get(v_t_244, LBL_col), MK_INT(1LL));
  return heff_strAppend(heff_intShow(v_t_243), heff_strAppend(((V)&g_heff_2equery_2eatLine_str0), heff_intShow(v_t_245)));
}
V g_heff_2equery_2eatLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eatLine(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2equery_2eexplain_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2equery_2eexplain_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2equery_2eexplain_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 32, 101, 114, 114, 111, 114, 32, 32}};
V g_heff_2equery_2eexplain_lam0(V self, V *args);
V g_heff_2equery_2eexplain_lam1(V self, V *args);
Clo g_heff_2equery_2eexplain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eexplain_entry, 1, 0};

V g_heff_2equery_2eexplain(V v_c_240) {
top: ;
  V v_t_241 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_trace);
  V v_t_245 = (g_prelude_2emap(heff_clo(g_heff_2equery_2eexplain_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), v_t_241));
  V v_t_248 = (g_prelude_2emap(heff_clo(g_heff_2equery_2eexplain_lam1, 1, 1, (V[]){heff_dup(v_c_240)}), heff_get(v_c_240, LBL_diags)));
  return (g_prelude_2econcatList(v_t_245, v_t_248));
}
V g_heff_2equery_2eexplain_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eexplain(a[0]);
}
V g_heff_2equery_2eexplain_lam0(V self, V *args) {
  V v_ev_242 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_243 = (g_heff_2equery_2eatLine(heff_get(v_c_240, LBL_source), heff_get(heff_dup(v_ev_242), LBL_span)));
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_ev_242), LBL_text), 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2equery_2eexplain_str0), heff_strAppend(heff_get(v_ev_242, LBL_kind), heff_strAppend(((V)&g_heff_2equery_2eexplain_str1), v_t_244))));
}
V g_heff_2equery_2eexplain_lam1(V self, V *args) {
  V v_d_246 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_247 = (g_heff_2equery_2eatLine(heff_get(v_c_240, LBL_source), heff_get(heff_dup(v_d_246), LBL_span)));
  return heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2equery_2eexplain_str2), heff_get(v_d_246, LBL_msg)));
}
V g_heff_2equery_2einfoAt_lam0(V self, V *args);
Clo g_heff_2equery_2einfoAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2einfoAt_entry, 2, 0};

V g_heff_2equery_2einfoAt(V v_c_240, V v_off_241) {
top: ;
  V v_t_242 = heff_get(heff_get(v_c_240, LBL_top), LBL_infos);
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2einfoAt_lam0, 1, 1, (V[]){v_off_241}), v_t_242));
  V v_x1_2412 = (g_prelude_2esortBy_24s770(v_t_2411));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nil: {
    heff_drop(v_x1_2412);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take(v_x1_2412, 1ULL);
    return heff_tag(TAG_Just, 1, (V[]){v_x_2413});
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2equery_2einfoAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2einfoAt(a[0], a[1]);
}
V g_heff_2equery_2einfoAt_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_off_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_get(heff_get(heff_dup(v_i_243), LBL_span), LBL_end);
  V v_t_245 = heff_get(heff_get(heff_dup(v_i_243), LBL_span), LBL_start);
  V v_t_246 = heff_strLength(heff_get(heff_dup(v_i_243), LBL_name));
  V v_t_247 = heff_intLe(heff_intSub(v_t_244, v_t_245), heff_intAdd(v_t_246, MK_INT(1LL)));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_t_247);
    V v_t_248 = heff_get(heff_get(heff_dup(v_i_243), LBL_span), LBL_start);
    V v_t_249 = heff_intLe(v_t_248, heff_dup(v_off_241));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_t_249);
      V v_t_2410 = heff_get(heff_get(v_i_243, LBL_span), LBL_end);
      return heff_intLe(v_off_241, v_t_2410);
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop(v_off_241);
      heff_drop(v_t_249);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_False: {
    heff_drop(v_i_243);
    heff_drop(v_off_241);
    heff_drop(v_t_247);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2etypeAt_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2etypeAt_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2equery_2etypeAt_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 32, 32, 40, 108, 111, 99, 97, 108, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2equery_2etypeAt_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 32, 32, 40, 103, 108, 111, 98, 97, 108, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2equery_2etypeAt_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
Clo g_heff_2equery_2etypeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2etypeAt_entry, 2, 0};

V g_heff_2equery_2etypeAt(V v_c_240, V v_off_241) {
top: ;
  V v_t_242 = (g_heff_2equery_2einfoAt(v_c_240, v_off_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_t_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_i_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse(v_t_242, 1ULL);
    V v_x_244 = heff_get(heff_dup(v_i_243), LBL_name);
    V v_t_245 = (g_heff_2epsurface_2eisOperator(heff_dup(v_x_244)));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      v_t_246 = heff_strAppend(((V)&g_heff_2equery_2etypeAt_str0), heff_strAppend(v_x_244, ((V)&g_heff_2equery_2etypeAt_str1)));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_i_243), LBL_ty), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_248 = heff_get(v_i_243, LBL_key);
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_t_248);
      v_t_2410 = ((V)&g_heff_2equery_2etypeAt_str2);
      break;
    }
    case TAG_Just: {
      heff_take(v_t_248, 0ULL);
      v_t_2410 = ((V)&g_heff_2equery_2etypeAt_str3);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2411 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2equery_2etypeAt_str4), heff_strAppend(v_t_247, v_t_2410)));
    return heff_tag_at(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2equery_2etypeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2etypeAt(a[0], a[1]);
}
Clo g_heff_2equery_2eisTypedChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eisTypedChar_entry, 1, 0};

V g_heff_2equery_2eisTypedChar(V v_c_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_c_240), MK_INT(95LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_c_240);
    heff_drop(v_t_241);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_242 = heff_intEq(heff_dup(v_c_240), MK_INT(39LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      heff_drop(v_t_242);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_242);
      V v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(46LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_c_240);
        heff_drop(v_t_243);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_243);
        V v_t_244 = heff_intLe(MK_INT(97LL), heff_dup(v_c_240));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_t_244);
          V v_t_245 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_c_240);
            heff_drop(v_t_245);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            heff_drop(v_t_245);
            V v_t_246 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_t_246);
              V v_t_247 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_c_240);
                heff_drop(v_t_247);
                return NTAG(TAG_True);
              }
              case TAG_False: {
                heff_drop(v_t_247);
                V v_t_248 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  heff_drop(v_t_248);
                  return heff_intLe(v_c_240, MK_INT(57LL));
                }
                case TAG_False: {
                  heff_drop(v_c_240);
                  heff_drop(v_t_248);
                  return NTAG(TAG_False);
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            case TAG_False: {
              heff_drop(v_t_246);
              V v_t_249 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
              switch (heff_tag_of(v_t_249)) {
              case TAG_True: {
                heff_drop(v_t_249);
                return heff_intLe(v_c_240, MK_INT(57LL));
              }
              case TAG_False: {
                heff_drop(v_c_240);
                heff_drop(v_t_249);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_249);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        case TAG_False: {
          heff_drop(v_t_244);
          V v_t_2410 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            heff_drop(v_t_2410);
            V v_t_2411 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
            switch (heff_tag_of(v_t_2411)) {
            case TAG_True: {
              heff_drop(v_c_240);
              heff_drop(v_t_2411);
              return NTAG(TAG_True);
            }
            case TAG_False: {
              heff_drop(v_t_2411);
              V v_t_2412 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
              switch (heff_tag_of(v_t_2412)) {
              case TAG_True: {
                heff_drop(v_t_2412);
                return heff_intLe(v_c_240, MK_INT(57LL));
              }
              case TAG_False: {
                heff_drop(v_c_240);
                heff_drop(v_t_2412);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_2412);
              }
            }
            default: return heff_nomatch(v_t_2411);
            }
          }
          case TAG_False: {
            heff_drop(v_t_2410);
            V v_t_2413 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
            switch (heff_tag_of(v_t_2413)) {
            case TAG_True: {
              heff_drop(v_t_2413);
              return heff_intLe(v_c_240, MK_INT(57LL));
            }
            case TAG_False: {
              heff_drop(v_c_240);
              heff_drop(v_t_2413);
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_t_2413);
            }
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2equery_2eisTypedChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eisTypedChar(a[0]);
}
Clo g_heff_2equery_2etypedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2etypedFrom_entry, 2, 0};

V g_heff_2equery_2etypedFrom(V v_src_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLt(MK_INT(0LL), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    V v_t_243 = heff_strCharCode(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    V v_t_244 = (g_heff_2equery_2eisTypedChar(v_t_243));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_src_240);
      heff_drop(v_t_244);
      return v_i_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_src_240);
    heff_drop(v_t_242);
    return v_i_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2equery_2etypedFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2etypedFrom(a[0], a[1]);
}
Clo g_heff_2equery_2elastDot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2elastDot_entry, 2, 0};

V g_heff_2equery_2elastDot(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(46LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_t_243);
      return heff_tag(TAG_Just, 1, (V[]){v_i_241});
    }
    case TAG_False: {
      heff_drop(v_t_243);
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2equery_2elastDot_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2elastDot(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ecompletionDetail_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ecompletionDetail_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2equery_2ecompletionDetail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ecompletionDetail_entry, 2, 0};

V g_heff_2equery_2ecompletionDetail(V v_c_240, V v_x_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_243 = (g_heff_2eglobals_2elookupEntry(v_t_242, heff_dup(v_x_241)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_243);
    V v_t_244 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
    V v_t_245 = heff_strAppend(heff_get(heff_dup(v_c_240), LBL_module), heff_strAppend(((V)&g_heff_2equery_2ecompletionDetail_str0), v_x_241));
    V v_t_246 = (g_heff_2eglobals_2elookupEntry(v_t_244, v_t_245));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_c_240);
      heff_drop(v_t_246);
      return ((V)&g_heff_2equery_2ecompletionDetail_str1);
    }
    case TAG_Just: {
      V v_e_247 = heff_field(v_t_246, 0);
      heff_take(v_t_246, 1ULL);
      V v_t_248 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
      V v_t_249 = (g_heff_2ereadback_2ereadbTypeF_24s197(MK_INT(0LL), heff_get(v_e_247, LBL_type_5f)));
      return (g_heff_2edriver_2eshowTySx(v_t_248, v_t_249));
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_Just: {
    V v_e_2410 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    heff_drop(v_x_241);
    V v_t_2411 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
    V v_t_2412 = (g_heff_2ereadback_2ereadbTypeF_24s197(MK_INT(0LL), heff_get(v_e_2410, LBL_type_5f)));
    return (g_heff_2edriver_2eshowTySx(v_t_2411, v_t_2412));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2equery_2ecompletionDetail_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ecompletionDetail(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ecompletionOf_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ecompletionOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
Clo g_heff_2equery_2ecompletionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ecompletionOf_entry, 4, 0};

V g_heff_2equery_2ecompletionOf(V v_c_240, V v_typed_241, V v_qualifier_242, V v_x_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength(heff_dup(v_typed_241)));
  V v_t_245 = heff_strEq(v_t_244, v_typed_241);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_245);
    V v_t_246 = heff_strEq(heff_dup(v_qualifier_242), ((V)&g_heff_2equery_2ecompletionOf_str0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      V v_x3_247 = (g_prelude_2eindexFrom(((V)&g_heff_2equery_2ecompletionOf_str1), heff_dup(v_x_243), MK_INT(0LL)));
      V v_x1_249;
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop(v_x3_247);
        v_x1_249 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take(v_x3_247, 0ULL);
        v_x1_249 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
      switch (heff_tag_of(v_x1_249)) {
      case TAG_True: {
        heff_drop(v_c_240);
        heff_drop(v_qualifier_242);
        heff_drop(v_x_243);
        heff_drop(v_x1_249);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        heff_drop(v_x1_249);
        V v_t_2410 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength(heff_dup(v_qualifier_242)));
        V v_t_2411 = heff_strEq(v_t_2410, heff_dup(v_qualifier_242));
        V v_x2_2413;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_True: {
          heff_drop(v_t_2411);
          V v_t_2412 = heff_strSlice(heff_dup(v_x_243), heff_strLength(v_qualifier_242), heff_strLength(heff_dup(v_x_243)));
          v_x2_2413 = heff_tag(TAG_Just, 1, (V[]){v_t_2412});
          break;
        }
        case TAG_False: {
          heff_drop(v_qualifier_242);
          heff_drop(v_t_2411);
          v_x2_2413 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        V v_t_2415;
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_Nothing: {
          heff_drop(v_x2_2413);
          v_t_2415 = heff_dup(v_x_243);
          break;
        }
        case TAG_Just: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          heff_take(v_x2_2413, 1ULL);
          v_t_2415 = v_x_2414;
          break;
        }
        default: heff_nomatch(v_x2_2413);
        }
        V v_t_2416 = (g_heff_2equery_2ecompletionDetail(v_c_240, v_x_243));
        return heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_150_57, (V[]){v_t_2415, v_t_2416})});
      }
      default: return heff_nomatch(v_x1_249);
      }
    }
    case TAG_False: {
      heff_drop(v_t_246);
      V v_t_2417 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength(heff_dup(v_qualifier_242)));
      V v_t_2418 = heff_strEq(v_t_2417, heff_dup(v_qualifier_242));
      V v_x2_2420;
      switch (heff_tag_of(v_t_2418)) {
      case TAG_True: {
        heff_drop(v_t_2418);
        V v_t_2419 = heff_strSlice(heff_dup(v_x_243), heff_strLength(v_qualifier_242), heff_strLength(heff_dup(v_x_243)));
        v_x2_2420 = heff_tag(TAG_Just, 1, (V[]){v_t_2419});
        break;
      }
      case TAG_False: {
        heff_drop(v_qualifier_242);
        heff_drop(v_t_2418);
        v_x2_2420 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      V v_t_2422;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2420);
        v_t_2422 = heff_dup(v_x_243);
        break;
      }
      case TAG_Just: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        heff_take(v_x2_2420, 1ULL);
        v_t_2422 = v_x_2421;
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2423 = (g_heff_2equery_2ecompletionDetail(v_c_240, v_x_243));
      return heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_150_57, (V[]){v_t_2422, v_t_2423})});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_False: {
    heff_drop(v_c_240);
    heff_drop(v_qualifier_242);
    heff_drop(v_x_243);
    heff_drop(v_t_245);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2equery_2ecompletionOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ecompletionOf(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ecompletionsAt_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2equery_2ecompletionsAt_lam0(V self, V *args);
Clo g_heff_2equery_2ecompletionsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ecompletionsAt_entry, 2, 0};

V g_heff_2equery_2ecompletionsAt(V v_c_240, V v_offset_241) {
top: ;
  V v_t_242 = (g_prelude_2emap_24s451(heff_get(heff_dup(v_c_240), LBL_own)));
  V v_t_243 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_244 = ({ V b_0 = heff_get(v_t_243, LBL_aliases); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_prelude_2emap_24s5(v_t_244));
  V v_t_246 = (g_prelude_2econcatList(v_t_242, v_t_245));
  V v_t_247 = (g_heff_2edriver_2enubStrD(v_t_246));
  V v_t_2417 = (g_prelude_2emap(heff_clo(g_heff_2equery_2ecompletionsAt_lam0, 1, 2, (V[]){v_c_240, v_offset_241}), v_t_247));
  V v_t_2418 = (g_heff_2equery_2ecatMaybesQ(v_t_2417));
  return (g_prelude_2esortBy_24s772(v_t_2418));
}
V g_heff_2equery_2ecompletionsAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ecompletionsAt(a[0], a[1]);
}
V g_heff_2equery_2ecompletionsAt_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  V v_offset_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_249 = (g_heff_2equery_2etypedFrom(heff_get(heff_dup(v_c_240), LBL_source), heff_dup(v_offset_241)));
  V v_t_2410 = heff_strSlice(heff_get(heff_dup(v_c_240), LBL_source), v_t_249, heff_dup(v_offset_241));
  V v_t_2411 = (g_heff_2equery_2etypedFrom(heff_get(heff_dup(v_c_240), LBL_source), heff_dup(v_offset_241)));
  V v_typed_2412 = heff_strSlice(heff_get(heff_dup(v_c_240), LBL_source), v_t_2411, v_offset_241);
  V v_t_2413 = heff_intSub(heff_strLength(heff_dup(v_typed_2412)), MK_INT(1LL));
  V v_t_2414 = (g_heff_2equery_2elastDot(heff_dup(v_typed_2412), v_t_2413));
  V v_t_2416;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    heff_drop(v_typed_2412);
    heff_drop(v_t_2414);
    v_t_2416 = ((V)&g_heff_2equery_2ecompletionsAt_str0);
    break;
  }
  case TAG_Just: {
    V v_i_2415 = heff_field(v_t_2414, 0);
    heff_take(v_t_2414, 1ULL);
    v_t_2416 = heff_strSlice(v_typed_2412, MK_INT(0LL), heff_intAdd(v_i_2415, MK_INT(1LL)));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  return (g_heff_2equery_2ecompletionOf(v_c_240, v_t_2410, v_t_2416, v_x_248));
}
Clo g_heff_2equery_2eeqTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eeqTarget_entry, 2, 0};

V g_heff_2equery_2eeqTarget(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_strEq(heff_get(heff_dup(v_a_240), LBL_key), heff_get(heff_dup(v_b_241), LBL_key));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    V v_x2_243 = heff_get(heff_dup(v_b_241), LBL_member);
    V v_t_244 = heff_get(heff_dup(v_a_240), LBL_member);
    V v_t_248;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_t_244);
      switch (heff_tag_of(v_x2_243)) {
      case TAG_Nothing: {
        heff_drop(v_x2_243);
        v_t_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Just: {
        heff_take(v_x2_243, 0ULL);
        v_t_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x2_243);
      }
      break;
    }
    case TAG_Just: {
      V v_a_246 = heff_field(v_t_244, 0);
      heff_take(v_t_244, 1ULL);
      switch (heff_tag_of(v_x2_243)) {
      case TAG_Nothing: {
        heff_drop(v_x2_243);
        heff_drop(v_a_246);
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_b_247 = heff_field(v_x2_243, 0);
        heff_take(v_x2_243, 1ULL);
        v_t_248 = heff_strEq(v_a_246, v_b_247);
        break;
      }
      default: heff_nomatch(v_x2_243);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_t_248);
      V v_x2_249 = heff_get(v_b_241, LBL_local);
      V v_t_2410 = heff_get(v_a_240, LBL_local);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_t_2410);
        switch (heff_tag_of(v_x2_249)) {
        case TAG_Nothing: {
          heff_drop(v_x2_249);
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          heff_take(v_x2_249, 0ULL);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x2_249);
        }
      }
      case TAG_Just: {
        V v_a_2412 = heff_field(v_t_2410, 0);
        heff_take(v_t_2410, 1ULL);
        switch (heff_tag_of(v_x2_249)) {
        case TAG_Nothing: {
          heff_drop(v_x2_249);
          heff_drop(v_a_2412);
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_b_2413 = heff_field(v_x2_249, 0);
          heff_take(v_x2_249, 1ULL);
          V v_t_2414 = heff_intEq(heff_get(heff_dup(v_a_2412), LBL_start), heff_get(heff_dup(v_b_2413), LBL_start));
          switch (heff_tag_of(v_t_2414)) {
          case TAG_True: {
            heff_drop(v_t_2414);
            return heff_intEq(heff_get(v_a_2412, LBL_end), heff_get(v_b_2413, LBL_end));
          }
          case TAG_False: {
            heff_drop(v_a_2412);
            heff_drop(v_b_2413);
            heff_drop(v_t_2414);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_t_2414);
          }
        }
        default: return heff_nomatch(v_x2_249);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_False: {
      heff_drop(v_a_240);
      heff_drop(v_b_241);
      heff_drop(v_t_248);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_False: {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    heff_drop(v_t_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2equery_2eeqTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eeqTarget(a[0], a[1]);
}
V g_heff_2equery_2eglobalSites_lam0(V self, V *args);
V g_heff_2equery_2eglobalSites_lam1(V self, V *args);
Clo g_heff_2equery_2eglobalSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eglobalSites_entry, 3, 0};

V g_heff_2equery_2eglobalSites(V v_c_240, V v_x_241, V v_sps_242) {
top: ;
  V v_t_244 = ({ V a_0 = heff_clo(g_heff_2equery_2eglobalSites_lam0, 1, 1, (V[]){heff_dup(v_x_241)}); V b_1 = heff_get(v_c_240, LBL_own); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    heff_drop(v_sps_242);
    heff_drop(v_t_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_o_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    return (g_prelude_2emap(heff_clo(g_heff_2equery_2eglobalSites_lam1, 1, 2, (V[]){v_o_245, v_x_241}), v_sps_242));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2equery_2eglobalSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eglobalSites(a[0], a[1], a[2]);
}
V g_heff_2equery_2eglobalSites_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_o_243, LBL_name), v_x_241);
}
V g_heff_2equery_2eglobalSites_lam1(V self, V *args) {
  V v_sp_246 = args[0];
  V v_o_245 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_247 = heff_rec(3, shape_145_180_170, (V[]){heff_get(v_o_245, LBL_key), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_a_248 = heff_get(heff_dup(v_sp_246), LBL_start);
  V v_b_249 = heff_intSub(heff_get(heff_dup(v_sp_246), LBL_end), heff_strLength(heff_dup(v_x_241)));
  V v_t_2410 = heff_intLe(heff_dup(v_a_248), heff_dup(v_b_249));
  V v_s_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_a_248);
    heff_drop(v_t_2410);
    v_s_2411 = v_b_249;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_249);
    heff_drop(v_t_2410);
    v_s_2411 = v_a_248;
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2412 = heff_rec(2, shape_305_78, (V[]){v_s_2411, heff_get(v_sp_246, LBL_end)});
  return heff_rec(3, shape_318_190_299, (V[]){v_t_247, v_x_241, v_t_2412});
}
V g_heff_2equery_2ememberSites_lam0(V self, V *args);
V g_heff_2equery_2ememberSites_lam1(V self, V *args);
Clo g_heff_2equery_2ememberSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ememberSites_entry, 3, 0};

V g_heff_2equery_2ememberSites(V v_c_240, V v_x_241, V v_ms_242) {
top: ;
  V v_t_244 = ({ V a_0 = heff_clo(g_heff_2equery_2ememberSites_lam0, 1, 1, (V[]){v_x_241}); V b_1 = heff_get(v_c_240, LBL_own); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_244);
    v_t_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_o_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse(v_t_244, 1ULL);
    v_t_246 = heff_tag_at(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_get(v_o_245, LBL_key)});
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_ms_242);
    heff_drop(v_t_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_k_247 = heff_field(v_t_246, 0);
    heff_take(v_t_246, 1ULL);
    return (g_prelude_2emap(heff_clo(g_heff_2equery_2ememberSites_lam1, 1, 1, (V[]){v_k_247}), v_ms_242));
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2equery_2ememberSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ememberSites(a[0], a[1], a[2]);
}
V g_heff_2equery_2ememberSites_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_o_243, LBL_name), v_x_241);
}
V g_heff_2equery_2ememberSites_lam1(V self, V *args) {
  V v_m_248 = args[0];
  V v_k_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x_249 = heff_get(heff_dup(v_m_248), LBL_name);
  V v_sp_2410 = heff_get(heff_dup(v_m_248), LBL_span);
  V v_t_2411 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_m_248, LBL_name)});
  V v_t_2412 = heff_rec(3, shape_145_180_170, (V[]){v_k_247, v_t_2411, NTAG(TAG_Nothing)});
  V v_a_2413 = heff_get(heff_dup(v_sp_2410), LBL_start);
  V v_b_2414 = heff_intSub(heff_get(heff_dup(v_sp_2410), LBL_end), heff_strLength(heff_dup(v_x_249)));
  V v_t_2415 = heff_intLe(heff_dup(v_a_2413), heff_dup(v_b_2414));
  V v_s_2416;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_a_2413);
    heff_drop(v_t_2415);
    v_s_2416 = v_b_2414;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2414);
    heff_drop(v_t_2415);
    v_s_2416 = v_a_2413;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_t_2417 = heff_rec(2, shape_305_78, (V[]){v_s_2416, heff_get(v_sp_2410, LBL_end)});
  return heff_rec(3, shape_318_190_299, (V[]){v_t_2412, v_x_249, v_t_2417});
}
Clo g_heff_2equery_2esumTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2esumTags_entry, 1, 0};

V g_heff_2equery_2esumTags(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      V v_alts_2426 = heff_field(v_x11_241, 0);
      V v_t_2427 = (g_prelude_2emap_24s774(heff_dup(v_alts_2426)));
      return (g_heff_2equery_2ecatMaybesQ(v_t_2427));
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2equery_2esumTags_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2esumTags(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2equery_2edeclSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2edeclSites_entry, 2, 0};

V g_heff_2equery_2edeclSites(V v_c_240, V v_d_241) {
top: ;
  V v_it_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_it_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_it_244)) {
  case TAG_DeclEquations: {
    V v_f_245 = heff_field(v_it_244, 0);
    V v_fsp_246 = heff_field(v_it_244, 1);
    V v_eqs_248 = heff_field(v_it_244, 3);
    heff_take(v_it_244, 11ULL);
    V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_fsp_246, (g_prelude_2emap_24s775(v_eqs_248))});
    return (g_heff_2equery_2eglobalSites(v_c_240, v_f_245, v_t_249));
  }
  case TAG_DeclDefine: {
    V v_x_2410 = heff_field(v_it_244, 0);
    V v_xsp_2411 = heff_field(v_it_244, 1);
    V v_body_2414 = heff_field(v_it_244, 4);
    heff_take(v_it_244, 19ULL);
    V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_xsp_2411, NTAG(TAG_Nil)});
    V v_t_2416 = (g_heff_2equery_2eglobalSites(heff_dup(v_c_240), heff_dup(v_x_2410), v_t_2415));
    V v_t_2417 = ({ V a_0 = v_body_2414; V r_ = (g_heff_2equery_2esumTags(a_0)); heff_drop(v_body_2414); r_; });
    V v_t_2418 = (g_heff_2equery_2ememberSites(v_c_240, v_x_2410, v_t_2417));
    return (g_prelude_2econcatList(v_t_2416, v_t_2418));
  }
  case TAG_DeclTheory: {
    V v_x_2419 = heff_field(v_it_244, 0);
    V v_xsp_2420 = heff_field(v_it_244, 1);
    V v_it4_2422 = heff_field(v_it_244, 3);
    heff_take(v_it_244, 11ULL);
    switch (heff_tag_of(v_it4_2422)) {
    case TAG_At: {
      V v_it41_2423 = heff_field(v_it4_2422, 0);
      V v_ru_24it4_2422_24At = heff_take_reuse(v_it4_2422, 1ULL);
      switch (heff_tag_of(v_it41_2423)) {
      case TAG_EVar: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EImplicitVar: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_ETag: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EInt: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EFloat: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EString: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EWord: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EApp: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EProject: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_ENamed: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EPi: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_ELam: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EAnn: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_ESpec: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_ESig: {
        V v_fs_2447 = heff_field(v_it41_2423, 0);
        heff_take(v_it41_2423, 1ULL);
        V v_t_2448 = heff_tag_at(v_ru_24it4_2422_24At, TAG_Cons, 2, (V[]){v_xsp_2420, NTAG(TAG_Nil)});
        V v_t_2449 = (g_heff_2equery_2eglobalSites(heff_dup(v_c_240), heff_dup(v_x_2419), v_t_2448));
        V v_t_2450 = (g_prelude_2emap_24s776(v_fs_2447));
        V v_t_2451 = (g_heff_2equery_2ecatMaybesQ(v_t_2450));
        V v_t_2452 = (g_heff_2equery_2ememberSites(v_c_240, v_x_2419, v_t_2451));
        return (g_prelude_2econcatList(v_t_2449, v_t_2452));
      }
      case TAG_ESum: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EStruct: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EMatch: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_ELetIn: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EDo: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_ELocal: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      case TAG_EInvalid: {
        heff_take(v_it41_2423, 0ULL);
        heff_drop(v_c_240);
        heff_drop(v_x_2419);
        heff_drop(v_xsp_2420);
        heff_drop(v_ru_24it4_2422_24At);
        return NTAG(TAG_Nil);
      }
      default: return heff_nomatch(v_it41_2423);
      }
    }
    default: return heff_nomatch(v_it4_2422);
    }
  }
  case TAG_DeclPrimitive: {
    V v_x_2463 = heff_field(v_it_244, 0);
    V v_sp_2464 = heff_field(v_it_244, 1);
    heff_take(v_it_244, 3ULL);
    V v_t_2466 = heff_tag(TAG_Cons, 2, (V[]){v_sp_2464, NTAG(TAG_Nil)});
    return (g_heff_2equery_2eglobalSites(v_c_240, v_x_2463, v_t_2466));
  }
  case TAG_DeclTest: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_c_240);
    return NTAG(TAG_Nil);
  }
  case TAG_DeclWatch: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_c_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2equery_2edeclSites_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2edeclSites(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2equery_2edefinesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2edefinesGo_entry, 4, 0};

V g_heff_2equery_2edefinesGo(V v_k_240, V v_c_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_k_240);
      heff_drop(v_c_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        V v_t_2410 = heff_strEq(heff_get(heff_dup(v_o_244), LBL_key), heff_dup(v_k_240));
        switch (heff_tag_of(v_t_2410)) {
        case TAG_True: {
          heff_drop(v_k_240);
          heff_drop(v_t_2410);
          V v_t_2411 = heff_rec(3, shape_33_190_299, (V[]){v_c_241, heff_get(heff_dup(v_o_244), LBL_name), heff_dup(v_sp_249)});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2411});
        }
        case TAG_False: {
          heff_drop(v_t_2410);
          V t_0 = v_k_240;
          V t_1 = v_c_241;
          V t_2 = v_os_245;
          V t_3 = v_sps_247;
          v_k_240 = t_0;
          v_c_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_t_2410);
        }
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2equery_2edefinesGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2edefinesGo(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2equery_2edefinitionIn_lam0(V self, V *args);
V g_heff_2equery_2edefinitionIn_lam1(V self, V *args);
Clo g_heff_2equery_2edefinitionIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2edefinitionIn_entry, 3, 0};

V g_heff_2equery_2edefinitionIn(V v_i_240, V v_k_241, V v_d_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_d_242), LBL_c), LBL_path);
  V v_t_244 = heff_get(heff_get(heff_dup(v_d_242), LBL_c), LBL_source);
  V v_c_245 = heff_get(heff_dup(v_d_242), LBL_c);
  V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_c_245), LBL_decls)));
  V v_t_2410 = ({ V a_0 = heff_clo(g_heff_2equery_2edefinitionIn_lam0, 2, 1, (V[]){v_c_245}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2415 = ({ V a_0 = heff_clo(g_heff_2equery_2edefinitionIn_lam1, 1, 2, (V[]){heff_dup(v_i_240), v_k_241}); V a_1 = v_t_2410; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    heff_drop(v_t_2415);
    V v_sp_2416 = heff_get(heff_dup(v_d_242), LBL_span);
    V v_t_2417 = heff_get(heff_get(v_d_242, LBL_c), LBL_source);
    v_t_2419 = (g_heff_2equery_2enameInGo(v_t_2417, heff_get(v_i_240, LBL_name), heff_dup(v_sp_2416), heff_get(v_sp_2416, LBL_start)));
    break;
  }
  case TAG_Just: {
    V v_s_2418 = heff_field(v_t_2415, 0);
    heff_take(v_t_2415, 1ULL);
    heff_drop(v_i_240);
    heff_drop(v_d_242);
    v_t_2419 = heff_get(v_s_2418, LBL_span);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  return heff_rec(3, shape_228_296_299, (V[]){v_t_243, v_t_244, v_t_2419});
}
V g_heff_2equery_2edefinitionIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2edefinitionIn(a[0], a[1], a[2]);
}
V g_heff_2equery_2edefinitionIn_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_c_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_249 = ({ V a_0 = v_c_245; V a_1 = v_x_248; V r_ = (g_heff_2equery_2edeclSites(a_0, a_1)); heff_drop(v_x_248); r_; });
  return (g_prelude_2econcatList(v_t_249, v_acc_247));
}
V g_heff_2equery_2edefinitionIn_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_i_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2412 = heff_get(heff_dup(v_i_240), LBL_member);
  V v_t_2414;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_i_240, LBL_name)});
    v_t_2414 = heff_rec(3, shape_145_180_170, (V[]){v_k_241, v_t_2413, NTAG(TAG_Nothing)});
    break;
  }
  case TAG_False: {
    heff_drop(v_i_240);
    heff_drop(v_t_2412);
    v_t_2414 = heff_rec(3, shape_145_180_170, (V[]){v_k_241, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  return (g_heff_2equery_2eeqTarget(heff_get(v_s_2411, LBL_target), v_t_2414));
}
V g_heff_2equery_2edefinitionAt_lam0(V self, V *args);
Clo g_heff_2equery_2edefinitionAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2edefinitionAt_entry, 2, 0};

V g_heff_2equery_2edefinitionAt(V v_program_240, V v_off_241) {
top: ;
  V v_x1_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_program_240)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_x1_242);
    v_t_245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take(v_x1_242, 1ULL);
    v_t_245 = heff_tag(TAG_Just, 1, (V[]){v_x_243});
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_program_240);
    heff_drop(v_off_241);
    heff_drop(v_t_245);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse(v_t_245, 1ULL);
    V v_t_247 = (g_heff_2equery_2einfoAt(v_c_246, v_off_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_program_240);
      heff_drop(v_ru_24t_245_24Just);
      heff_drop(v_t_247);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_i_248 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      V v_t_249 = heff_get(heff_dup(v_i_248), LBL_key);
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop(v_program_240);
        heff_drop(v_ru_24t_245_24Just);
        heff_drop(v_i_248);
        heff_drop(v_t_249);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_k_2410 = heff_field(v_t_249, 0);
        heff_take(v_t_249, 1ULL);
        V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_program_240));
        V v_t_2414 = (g_prelude_2emap(heff_clo(g_heff_2equery_2edefinitionAt_lam0, 1, 1, (V[]){heff_dup(v_k_2410)}), v_t_2411));
        V v_x1_2415 = (g_heff_2equery_2ecatMaybesQ(v_t_2414));
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_Nil: {
          heff_drop(v_ru_24t_245_24Just);
          heff_drop(v_i_248);
          heff_drop(v_k_2410);
          heff_drop(v_x1_2415);
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_x_2416 = heff_field(v_x1_2415, 0);
          heff_take(v_x1_2415, 1ULL);
          return heff_tag_at(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){(g_heff_2equery_2edefinitionIn(v_i_248, v_k_2410, v_x_2416))});
        }
        default: return heff_nomatch(v_x1_2415);
        }
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2equery_2edefinitionAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2edefinitionAt(a[0], a[1]);
}
V g_heff_2equery_2edefinitionAt_lam0(V self, V *args) {
  V v_c2_2412 = args[0];
  V v_k_2410 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2413 = heff_get(heff_get(heff_dup(v_c2_2412), LBL_top), LBL_spans);
  return ({ V a_0 = v_k_2410; V a_1 = heff_dup(v_c2_2412); V b_2 = heff_get(v_c2_2412, LBL_own); V a_3 = v_t_2413; V r_ = (g_heff_2equery_2edefinesGo(a_0, a_1, b_2, a_3)); heff_drop(b_2); heff_drop(v_t_2413); r_; });
}
V g_heff_2equery_2eownNameOf_lam0(V self, V *args);
Clo g_heff_2equery_2eownNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eownNameOf_entry, 2, 0};

V g_heff_2equery_2eownNameOf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_245 = ({ V a_0 = heff_clo(g_heff_2equery_2eownNameOf_lam0, 1, 1, (V[]){heff_dup(v_k_241)}); V b_1 = heff_get(heff_dup(v_c_242), LBL_own); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop(v_t_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_o_246 = heff_field(v_t_245, 0);
      V v_ru_24t_245_24Just = heff_take_reuse(v_t_245, 1ULL);
      heff_drop(v_k_241);
      return heff_tag_at(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){heff_get(v_o_246, LBL_name)});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2equery_2eownNameOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2eownNameOf(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2equery_2eownNameOf_lam0(V self, V *args) {
  V v_o_244 = args[0];
  V v_k_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_o_244, LBL_key), v_k_241);
}
V g_heff_2equery_2esiteFound_lam0(V self, V *args);
V g_heff_2equery_2esiteFound_lam1(V self, V *args);
Clo g_heff_2equery_2esiteFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2esiteFound_entry, 3, 0};

V g_heff_2equery_2esiteFound(V v_program_240, V v_c_241, V v_off_242) {
top: ;
  V v_t_243 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_c_241), LBL_decls)));
  V v_t_247 = ({ V a_0 = heff_clo(g_heff_2equery_2esiteFound_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_2411 = ({ V a_0 = heff_clo(g_heff_2equery_2esiteFound_lam1, 1, 1, (V[]){v_off_242}); V a_1 = v_t_247; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_t_2411);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse(v_t_2411, 1ULL);
    V v_t_2413 = heff_get(v_s_2412, LBL_target);
    V v_t_2414 = heff_get(heff_dup(v_t_2413), LBL_member);
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      heff_drop(v_t_2414);
      V v_t_2415 = (g_heff_2equery_2eownNameOf(v_program_240, heff_get(heff_dup(v_t_2413), LBL_key)));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop(v_ru_24t_2411_24Just);
        heff_drop(v_t_2413);
        heff_drop(v_t_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_2416 = heff_field(v_t_2415, 0);
        heff_take(v_t_2415, 1ULL);
        return heff_tag_at(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_318_190, (V[]){v_t_2413, v_x_2416})});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_Just: {
      V v_m_2417 = heff_field(v_t_2414, 0);
      heff_take(v_t_2414, 1ULL);
      return heff_tag_at(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_318_190, (V[]){v_t_2413, v_m_2417})});
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2equery_2esiteFound_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2esiteFound(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2equery_2esiteFound_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246 = ({ V a_0 = v_c_241; V a_1 = v_x_245; V r_ = (g_heff_2equery_2edeclSites(a_0, a_1)); heff_drop(v_x_245); r_; });
  return (g_prelude_2econcatList(v_t_246, v_acc_244));
}
V g_heff_2equery_2esiteFound_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_off_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_sp_249 = heff_get(v_s_248, LBL_span);
  V v_t_2410 = heff_intLe(heff_get(heff_dup(v_sp_249), LBL_start), heff_dup(v_off_242));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    return heff_intLe(v_off_242, heff_get(v_sp_249, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_off_242);
    heff_drop(v_sp_249);
    heff_drop(v_t_2410);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2equery_2efieldFound_lam0(V self, V *args);
V g_heff_2equery_2efieldFound_lam1(V self, V *args);
V g_heff_2equery_2efieldFound_lam2(V self, V *args);
Clo g_heff_2equery_2efieldFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2efieldFound_entry, 4, 0};

V g_heff_2equery_2efieldFound(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  V v_t_247 = ({ V a_0 = heff_clo(g_heff_2equery_2efieldFound_lam0, 1, 1, (V[]){v_off_243}); V b_1 = heff_get(v_ls_242, LBL_fields); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_c_241);
    heff_drop(v_t_247);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_f_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse(v_t_247, 1ULL);
    V v_t_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_c_241), LBL_decls)));
    V v_t_2413 = ({ V a_0 = heff_clo(g_heff_2equery_2efieldFound_lam1, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
    V v_t_2418 = ({ V a_0 = heff_clo(g_heff_2equery_2efieldFound_lam2, 1, 1, (V[]){v_f_248}); V a_1 = v_t_2413; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_t_2413); r_; });
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      heff_drop(v_ru_24t_247_24Just);
      heff_drop(v_t_2418);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_s_2419 = heff_field(v_t_2418, 0);
      heff_take(v_t_2418, 1ULL);
      V v_t_2420 = heff_get(v_s_2419, LBL_target);
      V v_t_2421 = heff_get(heff_dup(v_t_2420), LBL_member);
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop(v_t_2421);
        V v_t_2422 = (g_heff_2equery_2eownNameOf(v_program_240, heff_get(heff_dup(v_t_2420), LBL_key)));
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          heff_drop(v_ru_24t_247_24Just);
          heff_drop(v_t_2420);
          heff_drop(v_t_2422);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_2423 = heff_field(v_t_2422, 0);
          heff_take(v_t_2422, 1ULL);
          return heff_tag_at(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_318_190, (V[]){v_t_2420, v_x_2423})});
        }
        default: return heff_nomatch(v_t_2422);
        }
      }
      case TAG_Just: {
        V v_m_2424 = heff_field(v_t_2421, 0);
        heff_take(v_t_2421, 1ULL);
        return heff_tag_at(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_318_190, (V[]){v_t_2420, v_m_2424})});
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2equery_2efieldFound_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2efieldFound(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2equery_2efieldFound_lam0(V self, V *args) {
  V v_f_244 = args[0];
  V v_off_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_sp_245 = heff_get(v_f_244, LBL_use);
  V v_t_246 = heff_intLe(heff_get(heff_dup(v_sp_245), LBL_start), heff_dup(v_off_243));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    return heff_intLe(v_off_243, heff_get(v_sp_245, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_off_243);
    heff_drop(v_sp_245);
    heff_drop(v_t_246);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2equery_2efieldFound_lam1(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2412 = ({ V a_0 = v_c_241; V a_1 = v_x_2411; V r_ = (g_heff_2equery_2edeclSites(a_0, a_1)); heff_drop(v_x_2411); r_; });
  return (g_prelude_2econcatList(v_t_2412, v_acc_2410));
}
V g_heff_2equery_2efieldFound_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_f_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_2415 = heff_get(v_s_2414, LBL_span);
  V v_b_2416 = heff_get(v_f_248, LBL_field);
  V v_t_2417 = heff_intEq(heff_get(heff_dup(v_a_2415), LBL_start), heff_get(heff_dup(v_b_2416), LBL_start));
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop(v_t_2417);
    return heff_intEq(heff_get(v_a_2415, LBL_end), heff_get(v_b_2416, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_a_2415);
    heff_drop(v_b_2416);
    heff_drop(v_t_2417);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2equery_2eatLocal_lam0(V self, V *args);
V g_heff_2equery_2eatLocal_lam1(V self, V *args);
Clo g_heff_2equery_2eatLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eatLocal_entry, 2, 0};

V g_heff_2equery_2eatLocal(V v_off_240, V v_l_241) {
top: ;
  V v_sp_242 = heff_get(heff_dup(v_l_241), LBL_binder);
  V v_t_243 = heff_intLe(heff_get(heff_dup(v_sp_242), LBL_start), heff_dup(v_off_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    V v_t_244 = heff_intLe(heff_dup(v_off_240), heff_get(v_sp_242, LBL_end));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_off_240);
      heff_drop(v_l_241);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_244);
      return ({ V a_0 = heff_clo(g_heff_2equery_2eatLocal_lam0, 1, 1, (V[]){v_off_240}); V b_1 = heff_get(v_l_241, LBL_uses); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_sp_242);
    heff_drop(v_t_243);
    return ({ V a_0 = heff_clo(g_heff_2equery_2eatLocal_lam1, 1, 1, (V[]){v_off_240}); V b_1 = heff_get(v_l_241, LBL_uses); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2equery_2eatLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eatLocal(a[0], a[1]);
}
V g_heff_2equery_2eatLocal_lam0(V self, V *args) {
  V v_sp_245 = args[0];
  V v_off_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246 = heff_intLe(heff_get(heff_dup(v_sp_245), LBL_start), heff_dup(v_off_240));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    return heff_intLe(v_off_240, heff_get(v_sp_245, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_sp_245);
    heff_drop(v_off_240);
    heff_drop(v_t_246);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2equery_2eatLocal_lam1(V self, V *args) {
  V v_sp_247 = args[0];
  V v_off_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_248 = heff_intLe(heff_get(heff_dup(v_sp_247), LBL_start), heff_dup(v_off_240));
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_t_248);
    return heff_intLe(v_off_240, heff_get(v_sp_247, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_sp_247);
    heff_drop(v_off_240);
    heff_drop(v_t_248);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2equery_2etargetIn_lam0(V self, V *args);
V g_heff_2equery_2etargetIn_lam1(V self, V *args);
Clo g_heff_2equery_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2etargetIn_entry, 4, 0};

V g_heff_2equery_2etargetIn(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  V v_t_244 = (g_heff_2equery_2einfoAt(heff_dup(v_c_241), heff_dup(v_off_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_244);
    V v_x1_245 = (g_heff_2equery_2esiteFound(v_program_240, heff_dup(v_c_241), heff_dup(v_off_243)));
    V v_x1_246 = (g_heff_2equery_2efieldFound(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
    V v_t_248 = ({ V a_0 = heff_clo(g_heff_2equery_2etargetIn_lam0, 1, 1, (V[]){v_off_243}); V b_1 = heff_get(v_ls_242, LBL_locals); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x2_2413;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_c_241);
      heff_drop(v_t_248);
      v_x2_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_l_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse(v_t_248, 1ULL);
      V v_t_2410 = heff_tag_at(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){heff_get(heff_dup(v_l_249), LBL_binder)});
      V v_t_2411 = heff_rec(3, shape_145_180_170, (V[]){heff_get(v_c_241, LBL_path), NTAG(TAG_Nothing), v_t_2410});
      V v_t_2412 = heff_rec(2, shape_318_190, (V[]){v_t_2411, heff_get(v_l_249, LBL_name)});
      v_x2_2413 = heff_tag(TAG_Just, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_x2_2415;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nothing: {
      heff_drop(v_x1_246);
      v_x2_2415 = v_x2_2413;
      break;
    }
    case TAG_Just: {
      V v_x_2414 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Just = heff_take_reuse(v_x1_246, 1ULL);
      heff_drop(v_x2_2413);
      v_x2_2415 = heff_tag_at(v_ru_24x1_246_24Just, TAG_Just, 1, (V[]){v_x_2414});
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nothing: {
      heff_drop(v_x1_245);
      return v_x2_2415;
    }
    case TAG_Just: {
      V v_x_2416 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24Just = heff_take_reuse(v_x1_245, 1ULL);
      heff_drop(v_x2_2415);
      return heff_tag_at(v_ru_24x1_245_24Just, TAG_Just, 1, (V[]){v_x_2416});
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  case TAG_Just: {
    V v_i_2417 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse(v_t_244, 1ULL);
    V v_t_2418 = heff_get(heff_dup(v_i_2417), LBL_key);
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      heff_drop(v_i_2417);
      heff_drop(v_t_2418);
      V v_x1_2419 = (g_heff_2equery_2esiteFound(v_program_240, heff_dup(v_c_241), heff_dup(v_off_243)));
      V v_x1_2420 = (g_heff_2equery_2efieldFound(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
      V v_t_2422 = ({ V a_0 = heff_clo(g_heff_2equery_2etargetIn_lam1, 1, 1, (V[]){v_off_243}); V b_1 = heff_get(v_ls_242, LBL_locals); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
      V v_x2_2427;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nothing: {
        heff_drop(v_c_241);
        heff_drop(v_ru_24t_244_24Just);
        heff_drop(v_t_2422);
        v_x2_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_l_2423 = heff_field(v_t_2422, 0);
        V v_ru_24t_2422_24Just = heff_take_reuse(v_t_2422, 1ULL);
        V v_t_2424 = heff_tag_at(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_get(heff_dup(v_l_2423), LBL_binder)});
        V v_t_2425 = heff_rec(3, shape_145_180_170, (V[]){heff_get(v_c_241, LBL_path), NTAG(TAG_Nothing), v_t_2424});
        V v_t_2426 = heff_rec(2, shape_318_190, (V[]){v_t_2425, heff_get(v_l_2423, LBL_name)});
        v_x2_2427 = heff_tag_at(v_ru_24t_2422_24Just, TAG_Just, 1, (V[]){v_t_2426});
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      V v_x2_2429;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_Nothing: {
        heff_drop(v_x1_2420);
        v_x2_2429 = v_x2_2427;
        break;
      }
      case TAG_Just: {
        V v_x_2428 = heff_field(v_x1_2420, 0);
        V v_ru_24x1_2420_24Just = heff_take_reuse(v_x1_2420, 1ULL);
        heff_drop(v_x2_2427);
        v_x2_2429 = heff_tag_at(v_ru_24x1_2420_24Just, TAG_Just, 1, (V[]){v_x_2428});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_Nothing: {
        heff_drop(v_x1_2419);
        return v_x2_2429;
      }
      case TAG_Just: {
        V v_x_2430 = heff_field(v_x1_2419, 0);
        V v_ru_24x1_2419_24Just = heff_take_reuse(v_x1_2419, 1ULL);
        heff_drop(v_x2_2429);
        return heff_tag_at(v_ru_24x1_2419_24Just, TAG_Just, 1, (V[]){v_x_2430});
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    case TAG_Just: {
      V v_k_2431 = heff_field(v_t_2418, 0);
      V v_ru_24t_2418_24Just = heff_take_reuse(v_t_2418, 1ULL);
      heff_drop(v_c_241);
      heff_drop(v_ls_242);
      heff_drop(v_off_243);
      V v_t_2432 = heff_get(heff_dup(v_i_2417), LBL_member);
      V v_t_2434;
      switch (heff_tag_of(v_t_2432)) {
      case TAG_True: {
        heff_drop(v_t_2432);
        V v_t_2433 = heff_tag_at(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_get(v_i_2417, LBL_name)});
        v_t_2434 = heff_rec(3, shape_145_180_170, (V[]){v_k_2431, v_t_2433, NTAG(TAG_Nothing)});
        break;
      }
      case TAG_False: {
        heff_drop(v_i_2417);
        heff_drop(v_ru_24t_244_24Just);
        heff_drop(v_t_2432);
        v_t_2434 = heff_rec(3, shape_145_180_170, (V[]){v_k_2431, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        break;
      }
      default: heff_nomatch(v_t_2432);
      }
      V v_t_2435 = heff_get(heff_dup(v_t_2434), LBL_member);
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nothing: {
        heff_drop(v_t_2435);
        V v_t_2436 = (g_heff_2equery_2eownNameOf(v_program_240, heff_get(heff_dup(v_t_2434), LBL_key)));
        switch (heff_tag_of(v_t_2436)) {
        case TAG_Nothing: {
          heff_drop(v_ru_24t_2418_24Just);
          heff_drop(v_t_2434);
          heff_drop(v_t_2436);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_2437 = heff_field(v_t_2436, 0);
          heff_take(v_t_2436, 1ULL);
          return heff_tag_at(v_ru_24t_2418_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_318_190, (V[]){v_t_2434, v_x_2437})});
        }
        default: return heff_nomatch(v_t_2436);
        }
      }
      case TAG_Just: {
        V v_m_2438 = heff_field(v_t_2435, 0);
        heff_take(v_t_2435, 1ULL);
        return heff_tag_at(v_ru_24t_2418_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_318_190, (V[]){v_t_2434, v_m_2438})});
      }
      default: return heff_nomatch(v_t_2435);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2equery_2etargetIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2etargetIn(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2equery_2etargetIn_lam0(V self, V *args) {
  V v_l_247 = args[0];
  V v_off_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2equery_2eatLocal(v_off_243, v_l_247));
}
V g_heff_2equery_2etargetIn_lam1(V self, V *args) {
  V v_l_2421 = args[0];
  V v_off_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2equery_2eatLocal(v_off_243, v_l_2421));
}
V g_heff_2equery_2etargetAt_lam0(V self, V *args);
Clo g_heff_2equery_2etargetAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2etargetAt_entry, 2, 0};

V g_heff_2equery_2etargetAt(V v_program_240, V v_off_241) {
top: ;
  V v_x1_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    heff_drop(v_off_241);
    heff_drop(v_x1_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take(v_x1_242, 1ULL);
    V v_found_245 = ({ V a_0 = heff_dup(g_heff_2elocals_2enone_get()); V b_1 = heff_get(heff_dup(v_x_243), LBL_decls); V r_ = (g_prelude_2efoldl_24s767(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_246 = (g_prelude_2efilter_24s764(heff_get(heff_dup(v_found_245), LBL_binders)));
    V v_t_248 = (g_prelude_2emap(heff_clo(g_heff_2equery_2etargetAt_lam0, 1, 1, (V[]){heff_dup(v_found_245)}), v_t_246));
    V v_t_249 = (g_prelude_2efilter_24s766(heff_get(v_found_245, LBL_uses)));
    V v_t_2410 = (g_prelude_2emap_24s765(v_t_249));
    return ({ V a_0 = v_program_240; V a_1 = v_x_243; V a_2 = heff_rec(2, shape_171_94, (V[]){v_t_248, v_t_2410}); V a_3 = v_off_241; V r_ = (g_heff_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_240); r_; });
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2equery_2etargetAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2etargetAt(a[0], a[1]);
}
V g_heff_2equery_2etargetAt_lam0(V self, V *args) {
  V v_b_247 = args[0];
  V v_found_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elocals_2emkLocal(heff_get(v_found_245, LBL_uses), v_b_247));
}
Clo g_heff_2equery_2euseOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2euseOf_entry, 3, 0};

V g_heff_2equery_2euseOf(V v_t_240, V v_name_241, V v_i_242) {
top: ;
  V v_x2_243 = heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_t_240), LBL_key)});
  V v_t_244 = heff_get(heff_dup(v_i_242), LBL_key);
  V v_t_248;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_244);
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      heff_drop(v_x2_243);
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take(v_x2_243, 0ULL);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    break;
  }
  case TAG_Just: {
    V v_a_246 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      heff_drop(v_x2_243);
      heff_drop(v_a_246);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_b_247 = heff_field(v_x2_243, 0);
      heff_take(v_x2_243, 1ULL);
      v_t_248 = heff_strEq(v_a_246, v_b_247);
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_t_248);
    V v_t_249 = heff_get(heff_dup(v_i_242), LBL_member);
    V v_t_2417;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_t_249);
      V v_x2_2410 = heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_i_242), LBL_name)});
      V v_t_2411 = heff_get(v_t_240, LBL_member);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_t_2411);
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nothing: {
          heff_drop(v_x2_2410);
          v_t_2417 = NTAG(TAG_True);
          break;
        }
        case TAG_Just: {
          heff_take(v_x2_2410, 0ULL);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        break;
      }
      case TAG_Just: {
        V v_a_2413 = heff_field(v_t_2411, 0);
        heff_take(v_t_2411, 1ULL);
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nothing: {
          heff_drop(v_x2_2410);
          heff_drop(v_a_2413);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_b_2414 = heff_field(v_x2_2410, 0);
          heff_take(v_x2_2410, 1ULL);
          v_t_2417 = heff_strEq(v_a_2413, v_b_2414);
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_t_249);
      V v_t_2415 = heff_get(v_t_240, LBL_member);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop(v_t_2415);
        v_t_2417 = NTAG(TAG_True);
        break;
      }
      case TAG_Just: {
        heff_take(v_t_2415, 0ULL);
        v_t_2417 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_t_2417);
      V v_a_2418 = heff_get(heff_get(heff_dup(v_i_242), LBL_span), LBL_start);
      V v_t_2419 = heff_get(heff_get(heff_dup(v_i_242), LBL_span), LBL_end);
      V v_b_2420 = heff_intSub(v_t_2419, heff_strLength(v_name_241));
      V v_t_2421 = heff_intLe(heff_dup(v_a_2418), heff_dup(v_b_2420));
      V v_s_2422;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        heff_drop(v_a_2418);
        heff_drop(v_t_2421);
        v_s_2422 = v_b_2420;
        break;
      }
      case TAG_False: {
        heff_drop(v_b_2420);
        heff_drop(v_t_2421);
        v_s_2422 = v_a_2418;
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      V v_t_2423 = heff_get(heff_get(v_i_242, LBL_span), LBL_end);
      return heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_305_78, (V[]){v_s_2422, v_t_2423})});
    }
    case TAG_False: {
      heff_drop(v_name_241);
      heff_drop(v_i_242);
      heff_drop(v_t_2417);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_False: {
    heff_drop(v_t_240);
    heff_drop(v_name_241);
    heff_drop(v_i_242);
    heff_drop(v_t_248);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2equery_2euseOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2euseOf(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ewordsOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ewordsOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2ewordsOf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2equery_2ewordsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ewordsOf_entry, 4, 0};

V g_heff_2equery_2ewordsOf(V v_base_240, V v_line_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_intLe(heff_strLength(heff_dup(v_line_241)), heff_dup(v_i_242));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_base_240);
    heff_drop(v_line_241);
    heff_drop(v_i_242);
    heff_drop(v_t_244);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_243));
  }
  case TAG_False: {
    heff_drop(v_t_244);
    V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_line_241), heff_dup(v_i_242)), MK_INT(32LL));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_acc_243;
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_x2_246 = (g_prelude_2eindexFrom(((V)&g_heff_2equery_2ewordsOf_str0), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_248;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nothing: {
        heff_drop(v_x2_246);
        v_t_248 = heff_strLength(heff_dup(v_line_241));
        break;
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x2_246, 0);
        heff_take(v_x2_246, 1ULL);
        v_t_248 = v_x_247;
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      V v_x2_249 = (g_prelude_2eindexFrom(((V)&g_heff_2equery_2ewordsOf_str1), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_2411;
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        heff_drop(v_x2_249);
        v_t_2411 = heff_strLength(heff_dup(v_line_241));
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take(v_x2_249, 1ULL);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
      V v_x2_2412 = (g_prelude_2eindexFrom(((V)&g_heff_2equery_2ewordsOf_str2), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2412);
        v_t_2414 = heff_strLength(heff_dup(v_line_241));
        break;
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take(v_x2_2412, 1ULL);
        v_t_2414 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_e_2415 = heff_intAdd(heff_dup(v_base_240), v_t_2414);
      V v_t_2416 = heff_rec(2, shape_305_78, (V[]){heff_intAdd(heff_dup(v_base_240), heff_dup(v_i_242)), v_e_2415});
      V v_t_2417 = heff_rec(2, shape_321_299, (V[]){heff_strSlice(heff_dup(v_line_241), v_i_242, v_t_2411), v_t_2416});
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = v_t_248;
      V t_3 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, v_acc_243});
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2equery_2ewordsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ewordsOf(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2equery_2efixityWords_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2equery_2efixityWords_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2equery_2efixityWords_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 102, 105, 120}};
V g_heff_2equery_2efixityWords_lam0(V self, V *args);
V g_heff_2equery_2efixityWords_lam1(V self, V *args);
V g_heff_2equery_2efixityWords_lam2(V self, V *args);
Clo g_heff_2equery_2efixityWords_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2efixityWords_entry, 2, 0};

V g_heff_2equery_2efixityWords(V v_name_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_ws_241)) {
  case TAG_Nil: {
    heff_drop(v_name_240);
    heff_drop(v_ws_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_w_242 = heff_dup(heff_field(v_ws_241, 0));
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_w_242), LBL_text), ((V)&g_heff_2equery_2efixityWords_str0));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_w_242);
      heff_drop(v_t_244);
      V v_t_246 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2efixityWords_lam0, 1, 1, (V[]){v_name_240}), v_ws_241));
      return (g_prelude_2emap_24s777(v_t_246));
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V v_t_247 = heff_strEq(heff_get(heff_dup(v_w_242), LBL_text), ((V)&g_heff_2equery_2efixityWords_str1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_w_242);
        heff_drop(v_t_247);
        V v_t_249 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2efixityWords_lam1, 1, 1, (V[]){v_name_240}), v_ws_241));
        return (g_prelude_2emap_24s777(v_t_249));
      }
      case TAG_False: {
        heff_drop(v_t_247);
        V v_t_2410 = heff_strEq(heff_get(v_w_242, LBL_text), ((V)&g_heff_2equery_2efixityWords_str2));
        switch (heff_tag_of(v_t_2410)) {
        case TAG_True: {
          heff_drop(v_t_2410);
          V v_t_2412 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2efixityWords_lam2, 1, 1, (V[]){v_name_240}), v_ws_241));
          return (g_prelude_2emap_24s777(v_t_2412));
        }
        case TAG_False: {
          heff_drop(v_name_240);
          heff_drop(v_ws_241);
          heff_drop(v_t_2410);
          return NTAG(TAG_Nil);
        }
        default: return heff_nomatch(v_t_2410);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_ws_241);
  }
}
V g_heff_2equery_2efixityWords_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2efixityWords(a[0], a[1]);
}
V g_heff_2equery_2efixityWords_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_name_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_x_245, LBL_text), v_name_240);
}
V g_heff_2equery_2efixityWords_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_name_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_x_248, LBL_text), v_name_240);
}
V g_heff_2equery_2efixityWords_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_name_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_x_2411, LBL_text), v_name_240);
}
Clo g_heff_2equery_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ewordsIn_entry, 5, 0};

V g_heff_2equery_2ewordsIn(V v_name_240, V v_src_241, V v_i_242, V v_to_243, V v_acc_244) {
top: ;
  V v_t_245 = (g_prelude_2eindexFrom(heff_dup(v_name_240), heff_dup(v_src_241), v_i_242));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_name_240);
    heff_drop(v_src_241);
    heff_drop(v_to_243);
    heff_drop(v_t_245);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_244));
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take(v_t_245, 1ULL);
    V v_t_247 = heff_intAdd(heff_dup(v_p_246), heff_strLength(heff_dup(v_name_240)));
    V v_t_248 = heff_intLe(v_t_247, heff_dup(v_to_243));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_t_248);
      V v_t_249 = (g_heff_2equery_2ewordAt(heff_dup(v_src_241), heff_dup(v_p_246), heff_dup(v_name_240)));
      V v_t_2411;
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_t_249);
        V v_t_2410 = heff_intAdd(heff_dup(v_p_246), heff_strLength(heff_dup(v_name_240)));
        v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_305_78, (V[]){heff_dup(v_p_246), v_t_2410}), v_acc_244});
        break;
      }
      case TAG_False: {
        heff_drop(v_t_249);
        v_t_2411 = v_acc_244;
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V t_0 = v_name_240;
      V t_1 = v_src_241;
      V t_2 = heff_intAdd(v_p_246, MK_INT(1LL));
      V t_3 = v_to_243;
      V t_4 = v_t_2411;
      v_name_240 = t_0;
      v_src_241 = t_1;
      v_i_242 = t_2;
      v_to_243 = t_3;
      v_acc_244 = t_4;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_name_240);
      heff_drop(v_src_241);
      heff_drop(v_to_243);
      heff_drop(v_p_246);
      heff_drop(v_t_248);
      return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_244));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2equery_2ewordsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2ewordsIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2equery_2eexpectedIn_lam0(V self, V *args);
Clo g_heff_2equery_2eexpectedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eexpectedIn_entry, 2, 0};

V g_heff_2equery_2eexpectedIn(V v_name_240, V v_c_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_c_241), LBL_top), LBL_watches);
  V v_t_243 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_242));
  return ({ V a_0 = heff_clo(g_heff_2equery_2eexpectedIn_lam0, 2, 2, (V[]){v_c_241, v_name_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_heff_2equery_2eexpectedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eexpectedIn(a[0], a[1]);
}
V g_heff_2equery_2eexpectedIn_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  V v_name_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_246 = heff_get(heff_get(heff_dup(v_x_245), LBL_span), LBL_end);
  V v_t_247 = (g_heff_2edriver_2eexpectation(heff_get(heff_dup(v_c_241), LBL_source), v_t_246));
  V v_t_248 = heff_get(heff_get(v_x_245, LBL_span), LBL_end);
  V v_t_249 = (g_heff_2edriver_2eexpectation(heff_get(heff_dup(v_c_241), LBL_source), v_t_248));
  V v_t_2410 = (g_heff_2equery_2ewordsIn(v_name_240, heff_get(v_c_241, LBL_source), heff_get(v_t_247, LBL_from), heff_get(v_t_249, LBL_to), NTAG(TAG_Nil)));
  return (g_prelude_2econcatList(v_t_2410, v_acc_244));
}
V g_heff_2equery_2efieldUsesOf_lam1(V self, V *args);
V g_heff_2equery_2efieldUsesOf_lam0(V self, V *args);
Clo g_heff_2equery_2efieldUsesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2efieldUsesOf_entry, 2, 0};

V g_heff_2equery_2efieldUsesOf(V v_ss_240, V v_ls_241) {
top: ;
  V v_t_247 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2efieldUsesOf_lam0, 1, 1, (V[]){heff_dup(v_ss_240)}), heff_get(v_ls_241, LBL_fields)));
  return (g_prelude_2emap_24s763(v_t_247));
}
V g_heff_2equery_2efieldUsesOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2efieldUsesOf(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2equery_2efieldUsesOf_lam1(V self, V *args) {
  V v_s_243 = args[0];
  V v_f_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_244 = heff_get(v_s_243, LBL_span);
  V v_b_245 = heff_get(v_f_242, LBL_field);
  V v_t_246 = heff_intEq(heff_get(heff_dup(v_a_244), LBL_start), heff_get(heff_dup(v_b_245), LBL_start));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    return heff_intEq(heff_get(v_a_244, LBL_end), heff_get(v_b_245, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_a_244);
    heff_drop(v_b_245);
    heff_drop(v_t_246);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2equery_2efieldUsesOf_lam0(V self, V *args) {
  V v_f_242 = args[0];
  V v_ss_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = heff_clo(g_heff_2equery_2efieldUsesOf_lam1, 1, 1, (V[]){v_f_242}); V a_1 = v_ss_240; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_ss_240); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2emoreIn_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2equery_2emoreIn_lam0(V self, V *args);
V g_heff_2equery_2emoreIn_lam1(V self, V *args);
Clo g_heff_2equery_2emoreIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2emoreIn_entry, 3, 0};

V g_heff_2equery_2emoreIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_x1_243 = (g_heff_2equery_2eisNameChar(heff_strCharCode(heff_dup(v_name_241), MK_INT(0LL))));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_True: {
    heff_drop(v_t_240);
    heff_drop(v_x1_243);
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_x1_243);
    V v_t_244 = heff_get(v_t_240, LBL_member);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_t_244);
      v_t_246 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take(v_t_244, 0ULL);
      v_t_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2423;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    V v_src_247 = heff_get(heff_dup(v_c_242), LBL_source);
    V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_src_247)), MK_INT(1LL));
    V v_t_249 = (g_prelude_2erange(MK_INT(0LL), v_t_248));
    V v_xs_2413 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2emoreIn_lam0, 1, 1, (V[]){v_src_247}), v_t_249));
    V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2413));
    v_t_2423 = ({ V a_0 = heff_clo(g_heff_2equery_2emoreIn_lam1, 2, 2, (V[]){heff_dup(v_c_242), heff_dup(v_name_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2414; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
    break;
  }
  case TAG_False: {
    heff_drop(v_t_246);
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_x1_2424 = (g_heff_2equery_2eisNameChar(heff_strCharCode(heff_dup(v_name_241), MK_INT(0LL))));
  V v_t_2425;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_True: {
    heff_drop(v_x1_2424);
    v_t_2425 = (g_heff_2equery_2eexpectedIn(v_name_241, v_c_242));
    break;
  }
  case TAG_False: {
    heff_drop(v_name_241);
    heff_drop(v_c_242);
    heff_drop(v_x1_2424);
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  return (g_prelude_2econcatList(v_t_2423, v_t_2425));
}
V g_heff_2equery_2emoreIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2emoreIn(a[0], a[1], a[2]);
}
V g_heff_2equery_2emoreIn_lam0(V self, V *args) {
  V v_p_2410 = args[0];
  V v_src_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2411 = heff_intEq(heff_dup(v_p_2410), MK_INT(0LL));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_p_2410);
    heff_drop(v_src_247);
    heff_drop(v_t_2411);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    heff_drop(v_t_2411);
    V v_t_2412 = heff_strCharCode(v_src_247, heff_intSub(v_p_2410, MK_INT(1LL)));
    return heff_intEq(v_t_2412, MK_INT(10LL));
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2equery_2emoreIn_lam1(V self, V *args) {
  V v_acc_2415 = args[0];
  V v_x_2416 = args[1];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_name_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_src_2417 = heff_get(v_c_242, LBL_source);
  V v_x2_2418 = (g_prelude_2eindexFrom(((V)&g_heff_2equery_2emoreIn_str0), heff_dup(v_src_2417), heff_dup(v_x_2416)));
  V v_t_2420;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2418);
    v_t_2420 = heff_strLength(heff_dup(v_src_2417));
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    heff_take(v_x2_2418, 1ULL);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2421 = (g_heff_2equery_2ewordsOf(heff_dup(v_x_2416), heff_strSlice(v_src_2417, v_x_2416, v_t_2420), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2422 = (g_heff_2equery_2efixityWords(v_name_241, v_t_2421));
  return (g_prelude_2econcatList(v_t_2422, v_acc_2415));
}
V g_heff_2equery_2einFileFound_lam1(V self, V *args);
V g_heff_2equery_2einFileFound_lam0(V self, V *args);
Clo g_heff_2equery_2einFileFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2einFileFound_entry, 5, 0};

V g_heff_2equery_2einFileFound(V v_t_240, V v_name_241, V v_c_242, V v_ss_243, V v_found_244) {
top: ;
  V v_defs_245 = (g_prelude_2emap_24s777(v_ss_243));
  V v_t_248;
  switch (heff_tag_of(v_found_244)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_name_241);
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    v_t_248 = (g_heff_2equery_2emoreIn(v_t_240, v_name_241, heff_dup(v_c_242)));
    break;
  }
  default: heff_nomatch(v_found_244);
  }
  V v_spans_249 = (g_prelude_2econcatList(v_found_244, v_t_248));
  V v_t_2410 = (g_prelude_2esortBy_24s768(v_spans_249));
  V v_t_2411 = (g_heff_2equery_2enubByStart(v_t_2410));
  return (g_prelude_2emap(heff_clo(g_heff_2equery_2einFileFound_lam0, 1, 2, (V[]){v_defs_245, v_c_242}), v_t_2411));
}
V g_heff_2equery_2einFileFound_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2einFileFound(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2equery_2einFileFound_lam1(V self, V *args) {
  V v_d_2413 = args[0];
  V v_sp_2412 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_intEq(heff_get(v_d_2413, LBL_start), heff_get(v_sp_2412, LBL_start));
}
V g_heff_2equery_2einFileFound_lam0(V self, V *args) {
  V v_sp_2412 = args[0];
  V v_defs_245 = heff_dup(heff_env(self)[0]);
  V v_c_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_defines_2414 = ({ V a_0 = heff_clo(g_heff_2equery_2einFileFound_lam1, 1, 1, (V[]){heff_dup(v_sp_2412)}); V a_1 = v_defs_245; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_defs_245); r_; });
  return heff_rec(4, shape_228_296_299_54, (V[]){heff_get(heff_dup(v_c_242), LBL_path), heff_get(v_c_242, LBL_source), v_sp_2412, v_defines_2414});
}
V g_heff_2equery_2einFileSites_lam0(V self, V *args);
V g_heff_2equery_2einFileSites_lam1(V self, V *args);
Clo g_heff_2equery_2einFileSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2einFileSites_entry, 4, 0};

V g_heff_2equery_2einFileSites(V v_t_240, V v_name_241, V v_c_242, V v_ss_243) {
top: ;
  V v_t_244 = heff_get(heff_get(heff_dup(v_c_242), LBL_top), LBL_infos);
  V v_t_246 = (g_prelude_2emap(heff_clo(g_heff_2equery_2einFileSites_lam0, 1, 2, (V[]){heff_dup(v_t_240), heff_dup(v_name_241)}), v_t_244));
  V v_t_247 = (g_heff_2equery_2ecatMaybesQ(v_t_246));
  V v_t_248 = (g_prelude_2emap_24s777(heff_dup(v_ss_243)));
  V v_found_249 = ({ V a_0 = heff_dup(g_heff_2elocals_2enone_get()); V b_1 = heff_get(heff_dup(v_c_242), LBL_decls); V r_ = (g_prelude_2efoldl_24s767(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2410 = (g_prelude_2efilter_24s764(heff_get(heff_dup(v_found_249), LBL_binders)));
  V v_t_2412 = (g_prelude_2emap(heff_clo(g_heff_2equery_2einFileSites_lam1, 1, 1, (V[]){heff_dup(v_found_249)}), v_t_2410));
  V v_t_2413 = (g_prelude_2efilter_24s766(heff_get(v_found_249, LBL_uses)));
  V v_t_2414 = (g_prelude_2emap_24s765(v_t_2413));
  V v_t_2415 = (g_heff_2equery_2efieldUsesOf(v_ss_243, heff_rec(2, shape_171_94, (V[]){v_t_2412, v_t_2414})));
  V v_t_2416 = (g_prelude_2econcatList(v_t_248, v_t_2415));
  V v_t_2417 = (g_prelude_2econcatList(v_t_247, v_t_2416));
  return (g_heff_2equery_2einFileFound(v_t_240, v_name_241, v_c_242, v_ss_243, v_t_2417));
}
V g_heff_2equery_2einFileSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2einFileSites(a[0], a[1], a[2], a[3]);
}
V g_heff_2equery_2einFileSites_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_t_240 = heff_dup(heff_env(self)[0]);
  V v_name_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2equery_2euseOf(v_t_240, v_name_241, v_i_245));
}
V g_heff_2equery_2einFileSites_lam1(V self, V *args) {
  V v_b_2411 = args[0];
  V v_found_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elocals_2emkLocal(heff_get(v_found_249, LBL_uses), v_b_2411));
}
V g_heff_2equery_2enubByPath_lam0(V self, V *args);
Clo g_heff_2equery_2enubByPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2enubByPath_entry, 1, 0};

V g_heff_2equery_2enubByPath(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2enubByPath_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_cs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_241, (g_heff_2equery_2enubByPath(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2equery_2enubByPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2enubByPath(a[0]);
}
V g_heff_2equery_2enubByPath_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(heff_get(v_d_243, LBL_path), heff_get(v_c_241, LBL_path));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2equery_2elocalOccurrences_lam0(V self, V *args);
V g_heff_2equery_2elocalOccurrences_lam1(V self, V *args);
V g_heff_2equery_2elocalOccurrences_lam2(V self, V *args);
Clo g_heff_2equery_2elocalOccurrences_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2elocalOccurrences_entry, 2, 0};

V g_heff_2equery_2elocalOccurrences(V v_c_240, V v_b_241) {
top: ;
  V v_found_242 = ({ V a_0 = heff_dup(g_heff_2elocals_2enone_get()); V b_1 = heff_get(heff_dup(v_c_240), LBL_decls); V r_ = (g_prelude_2efoldl_24s767(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_243 = (g_prelude_2efilter_24s764(heff_get(heff_dup(v_found_242), LBL_binders)));
  V v_t_245 = (g_prelude_2emap(heff_clo(g_heff_2equery_2elocalOccurrences_lam0, 1, 1, (V[]){heff_dup(v_found_242)}), v_t_243));
  V v_t_246 = (g_prelude_2efilter_24s766(heff_get(v_found_242, LBL_uses)));
  V v_t_247 = (g_prelude_2emap_24s765(v_t_246));
  V v_t_248 = heff_get(heff_rec(2, shape_171_94, (V[]){v_t_245, v_t_247}), LBL_locals);
  V v_t_2412 = ({ V a_0 = heff_clo(g_heff_2equery_2elocalOccurrences_lam1, 1, 1, (V[]){heff_dup(v_b_241)}); V a_1 = v_t_248; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_t_248); r_; });
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    heff_drop(v_c_240);
    heff_drop(v_b_241);
    heff_drop(v_t_2412);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_l_2413 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_l_2413), LBL_binder), heff_get(v_l_2413, LBL_uses)});
    V v_t_2415 = (g_prelude_2esortBy_24s768(v_t_2414));
    return (g_prelude_2emap(heff_clo(g_heff_2equery_2elocalOccurrences_lam2, 1, 2, (V[]){v_b_241, v_c_240}), v_t_2415));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2equery_2elocalOccurrences_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2elocalOccurrences(a[0], a[1]);
}
V g_heff_2equery_2elocalOccurrences_lam0(V self, V *args) {
  V v_b_244 = args[0];
  V v_found_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elocals_2emkLocal(heff_get(v_found_242, LBL_uses), v_b_244));
}
V g_heff_2equery_2elocalOccurrences_lam1(V self, V *args) {
  V v_l_249 = args[0];
  V v_b_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_2410 = heff_get(v_l_249, LBL_binder);
  V v_t_2411 = heff_intEq(heff_get(heff_dup(v_a_2410), LBL_start), heff_get(heff_dup(v_b_241), LBL_start));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_t_2411);
    return heff_intEq(heff_get(v_a_2410, LBL_end), heff_get(v_b_241, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_b_241);
    heff_drop(v_a_2410);
    heff_drop(v_t_2411);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2equery_2elocalOccurrences_lam2(V self, V *args) {
  V v_sp_2416 = args[0];
  V v_b_241 = heff_dup(heff_env(self)[0]);
  V v_c_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2417 = heff_intEq(heff_get(heff_dup(v_sp_2416), LBL_start), heff_get(heff_dup(v_b_241), LBL_start));
  V v_defines_2418;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop(v_t_2417);
    v_defines_2418 = heff_intEq(heff_get(heff_dup(v_sp_2416), LBL_end), heff_get(v_b_241, LBL_end));
    break;
  }
  case TAG_False: {
    heff_drop(v_b_241);
    heff_drop(v_t_2417);
    v_defines_2418 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  return heff_rec(4, shape_228_296_299_54, (V[]){heff_get(heff_dup(v_c_240), LBL_path), heff_get(v_c_240, LBL_source), v_sp_2416, v_defines_2418});
}
V g_heff_2equery_2eoccurrences_lam1(V self, V *args);
V g_heff_2equery_2eoccurrences_lam2(V self, V *args);
V g_heff_2equery_2eoccurrences_lam0(V self, V *args);
V g_heff_2equery_2eoccurrences_lam3(V self, V *args);
Clo g_heff_2equery_2eoccurrences_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eoccurrences_entry, 3, 0};

V g_heff_2equery_2eoccurrences(V v_program_240, V v_t_241, V v_name_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_t_241), LBL_local);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_243);
    V v_xs_244 = (g_heff_2equery_2enubByPath(v_program_240));
    V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_244));
    return ({ V a_0 = heff_clo(g_heff_2equery_2eoccurrences_lam0, 2, 2, (V[]){v_t_241, v_name_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  case TAG_Just: {
    V v_b_2416 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    heff_drop(v_name_242);
    V v_t_2418 = ({ V a_0 = heff_clo(g_heff_2equery_2eoccurrences_lam3, 1, 1, (V[]){v_t_241}); V a_1 = v_program_240; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_program_240); r_; });
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      heff_drop(v_b_2416);
      heff_drop(v_t_2418);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_c_2419 = heff_field(v_t_2418, 0);
      heff_take(v_t_2418, 1ULL);
      return (g_heff_2equery_2elocalOccurrences(v_c_2419, v_b_2416));
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2equery_2eoccurrences_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eoccurrences(a[0], a[1], a[2]);
}
V g_heff_2equery_2eoccurrences_lam1(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_x_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2411 = ({ V a_0 = v_x_247; V a_1 = v_x_2410; V r_ = (g_heff_2equery_2edeclSites(a_0, a_1)); heff_drop(v_x_2410); r_; });
  return (g_prelude_2econcatList(v_t_2411, v_acc_249));
}
V g_heff_2equery_2eoccurrences_lam2(V self, V *args) {
  V v_s_2413 = args[0];
  V v_t_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2equery_2eeqTarget(heff_get(v_s_2413, LBL_target), v_t_241));
}
V g_heff_2equery_2eoccurrences_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_t_241 = heff_dup(heff_env(self)[0]);
  V v_name_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_x_247), LBL_decls)));
  V v_t_2412 = ({ V a_0 = heff_clo(g_heff_2equery_2eoccurrences_lam1, 2, 1, (V[]){heff_dup(v_x_247)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2414 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2eoccurrences_lam2, 1, 1, (V[]){heff_dup(v_t_241)}), v_t_2412));
  V v_t_2415 = (g_heff_2equery_2einFileSites(v_t_241, v_name_242, v_x_247, v_t_2414));
  return (g_prelude_2econcatList(v_t_2415, v_acc_246));
}
V g_heff_2equery_2eoccurrences_lam3(V self, V *args) {
  V v_c_2417 = args[0];
  V v_t_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_c_2417, LBL_path), heff_get(v_t_241, LBL_key));
}
Clo g_heff_2equery_2epunctuation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2epunctuation_entry, 1, 0};

V g_heff_2equery_2epunctuation(V v_d_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_d_240), MK_INT(32LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_d_240);
    heff_drop(v_t_241);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_242 = heff_intEq(heff_dup(v_d_240), MK_INT(10LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_d_240);
      heff_drop(v_t_242);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_242);
      V v_t_243 = heff_intEq(heff_dup(v_d_240), MK_INT(40LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_d_240);
        heff_drop(v_t_243);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_243);
        V v_t_244 = heff_intEq(heff_dup(v_d_240), MK_INT(41LL));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_d_240);
          heff_drop(v_t_244);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          heff_drop(v_t_244);
          V v_t_245 = heff_intEq(heff_dup(v_d_240), MK_INT(91LL));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_d_240);
            heff_drop(v_t_245);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            heff_drop(v_t_245);
            V v_t_246 = heff_intEq(heff_dup(v_d_240), MK_INT(93LL));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_d_240);
              heff_drop(v_t_246);
              return NTAG(TAG_True);
            }
            case TAG_False: {
              heff_drop(v_t_246);
              V v_t_247 = heff_intEq(heff_dup(v_d_240), MK_INT(123LL));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_d_240);
                heff_drop(v_t_247);
                return NTAG(TAG_True);
              }
              case TAG_False: {
                heff_drop(v_t_247);
                V v_t_248 = heff_intEq(heff_dup(v_d_240), MK_INT(125LL));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  heff_drop(v_d_240);
                  heff_drop(v_t_248);
                  return NTAG(TAG_True);
                }
                case TAG_False: {
                  heff_drop(v_t_248);
                  V v_t_249 = heff_intEq(heff_dup(v_d_240), MK_INT(44LL));
                  switch (heff_tag_of(v_t_249)) {
                  case TAG_True: {
                    heff_drop(v_d_240);
                    heff_drop(v_t_249);
                    return NTAG(TAG_True);
                  }
                  case TAG_False: {
                    heff_drop(v_t_249);
                    V v_t_2410 = heff_intEq(heff_dup(v_d_240), MK_INT(34LL));
                    switch (heff_tag_of(v_t_2410)) {
                    case TAG_True: {
                      heff_drop(v_d_240);
                      heff_drop(v_t_2410);
                      return NTAG(TAG_True);
                    }
                    case TAG_False: {
                      heff_drop(v_t_2410);
                      return heff_intEq(v_d_240, MK_INT(96LL));
                    }
                    default: return heff_nomatch(v_t_2410);
                    }
                  }
                  default: return heff_nomatch(v_t_249);
                  }
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2equery_2epunctuation_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2epunctuation(a[0]);
}
Clo g_heff_2equery_2eallChars_24s778_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eallChars_24s778_entry, 2, 0};

V g_heff_2equery_2eallChars_24s778(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_242);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_d_243 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
    V v_t_244 = heff_intEq(heff_dup(v_d_243), MK_INT(47LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2equery_2eisNameChar(v_d_243));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_t_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_t_245);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2equery_2eallChars_24s778_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eallChars_24s778(a[0], a[1]);
}
Clo g_heff_2equery_2eallChars_24s779_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2eallChars_24s779_entry, 2, 0};

V g_heff_2equery_2eallChars_24s779(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_242);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_d_243 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
    V v_t_244 = heff_intEq(heff_dup(v_d_243), MK_INT(47LL));
    V v_x1_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      v_x1_245 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      v_x1_245 = (g_heff_2equery_2eisNameChar(heff_dup(v_d_243)));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    switch (heff_tag_of(v_x1_245)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_d_243);
      heff_drop(v_x1_245);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_x1_245);
      V v_x1_246 = (g_heff_2equery_2epunctuation(v_d_243));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_True: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_x1_246);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        heff_drop(v_x1_246);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2equery_2eallChars_24s779_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2eallChars_24s779(a[0], a[1]);
}
Clo g_heff_2equery_2enameClass_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2enameClass_entry, 1, 0};

V g_heff_2equery_2enameClass(V v_x_240) {
top: ;
  V v_t_241 = heff_intEq(heff_strLength(heff_dup(v_x_240)), MK_INT(0LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x_240);
    heff_drop(v_t_241);
    return MK_INT(0LL);
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_242 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)));
    V v_t_243;
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_t_242);
      v_t_243 = heff_intLe(heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(90LL));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_242);
      v_t_243 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_t_243);
      V v_t_244 = (g_heff_2equery_2eallChars_24s778(v_x_240, MK_INT(0LL)));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_t_244);
        return MK_INT(1LL);
      }
      case TAG_False: {
        heff_drop(v_t_244);
        return MK_INT(0LL);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_False: {
      heff_drop(v_t_243);
      V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(95LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_t_245);
        V v_t_246 = (g_heff_2equery_2eallChars_24s778(v_x_240, MK_INT(0LL)));
        switch (heff_tag_of(v_t_246)) {
        case TAG_True: {
          heff_drop(v_t_246);
          return MK_INT(2LL);
        }
        case TAG_False: {
          heff_drop(v_t_246);
          return MK_INT(0LL);
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      case TAG_False: {
        heff_drop(v_t_245);
        V v_t_247 = heff_intLe(MK_INT(97LL), heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_t_247);
          V v_t_248 = heff_intLe(heff_strCharCode(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(122LL));
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            heff_drop(v_t_248);
            V v_t_249 = (g_heff_2equery_2eallChars_24s778(v_x_240, MK_INT(0LL)));
            switch (heff_tag_of(v_t_249)) {
            case TAG_True: {
              heff_drop(v_t_249);
              return MK_INT(2LL);
            }
            case TAG_False: {
              heff_drop(v_t_249);
              return MK_INT(0LL);
            }
            default: return heff_nomatch(v_t_249);
            }
          }
          case TAG_False: {
            heff_drop(v_t_248);
            V v_t_2410 = (g_heff_2equery_2eallChars_24s779(v_x_240, MK_INT(0LL)));
            switch (heff_tag_of(v_t_2410)) {
            case TAG_True: {
              heff_drop(v_t_2410);
              return MK_INT(3LL);
            }
            case TAG_False: {
              heff_drop(v_t_2410);
              return MK_INT(0LL);
            }
            default: return heff_nomatch(v_t_2410);
            }
          }
          default: return heff_nomatch(v_t_248);
          }
        }
        case TAG_False: {
          heff_drop(v_t_247);
          V v_t_2411 = (g_heff_2equery_2eallChars_24s779(v_x_240, MK_INT(0LL)));
          switch (heff_tag_of(v_t_2411)) {
          case TAG_True: {
            heff_drop(v_t_2411);
            return MK_INT(3LL);
          }
          case TAG_False: {
            heff_drop(v_t_2411);
            return MK_INT(0LL);
          }
          default: return heff_nomatch(v_t_2411);
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2equery_2enameClass_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2enameClass(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2erenameRefused_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2erenameRefused_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2equery_2erenameRefused_str2 = {{0x80000000u, K_STR, 0}, 29, 29, {96, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 110, 97, 109, 101, 32, 111, 102, 32, 116, 104, 101, 32, 107, 105, 110, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2equery_2erenameRefused_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {96, 32, 105, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2erenameRefused_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2equery_2erenameRefused_str5 = {{0x80000000u, K_STR, 0}, 43, 43, {96, 32, 105, 115, 32, 97, 32, 112, 114, 105, 109, 105, 116, 105, 118, 101, 58, 32, 105, 116, 115, 32, 110, 97, 109, 101, 32, 105, 115, 32, 116, 104, 101, 32, 114, 117, 110, 116, 105, 109, 101, 39, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2erenameRefused_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2equery_2erenameRefused_str7 = {{0x80000000u, K_STR, 0}, 29, 29, {96, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 110, 97, 109, 101, 32, 111, 102, 32, 116, 104, 101, 32, 107, 105, 110, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2equery_2erenameRefused_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {96, 32, 105, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2equery_2erenameRefused_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2equery_2erenameRefused_str10 = {{0x80000000u, K_STR, 0}, 29, 29, {96, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 110, 97, 109, 101, 32, 111, 102, 32, 116, 104, 101, 32, 107, 105, 110, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2equery_2erenameRefused_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {96, 32, 105, 115}};
Clo g_heff_2equery_2erenameRefused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2erenameRefused_entry, 3, 0};

V g_heff_2equery_2erenameRefused(V v_t_240, V v_old_241, V v_new_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_t_240), LBL_member);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_243);
    V v_t_244 = heff_get(heff_dup(v_t_240), LBL_local);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_t_244);
      V v_x3_245 = (g_prelude_2eindexFrom(((V)&g_heff_2equery_2erenameRefused_str0), heff_get(v_t_240, LBL_key), MK_INT(0LL)));
      V v_x1_247;
      switch (heff_tag_of(v_x3_245)) {
      case TAG_Nothing: {
        heff_drop(v_x3_245);
        v_x1_247 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take(v_x3_245, 0ULL);
        v_x1_247 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_245);
      }
      switch (heff_tag_of(v_x1_247)) {
      case TAG_True: {
        heff_drop(v_x1_247);
        V v_a_248 = (g_heff_2equery_2enameClass(heff_dup(v_old_241)));
        V v_b_249 = (g_heff_2equery_2enameClass(heff_dup(v_new_242)));
        V v_t_2410 = heff_intEq(v_a_248, v_b_249);
        switch (heff_tag_of(v_t_2410)) {
        case TAG_True: {
          heff_drop(v_old_241);
          heff_drop(v_new_242);
          heff_drop(v_t_2410);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          heff_drop(v_t_2410);
          V v_t_2411 = heff_strAppend(((V)&g_heff_2equery_2erenameRefused_str1), heff_strAppend(v_new_242, heff_strAppend(((V)&g_heff_2equery_2erenameRefused_str2), heff_strAppend(v_old_241, ((V)&g_heff_2equery_2erenameRefused_str3)))));
          return heff_tag(TAG_Just, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_t_2410);
        }
      }
      case TAG_False: {
        heff_drop(v_new_242);
        heff_drop(v_x1_247);
        V v_t_2412 = heff_strAppend(((V)&g_heff_2equery_2erenameRefused_str4), heff_strAppend(v_old_241, ((V)&g_heff_2equery_2erenameRefused_str5)));
        return heff_tag(TAG_Just, 1, (V[]){v_t_2412});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse(v_t_244, 0ULL);
      heff_drop(v_t_240);
      V v_a_2414 = (g_heff_2equery_2enameClass(heff_dup(v_old_241)));
      V v_b_2415 = (g_heff_2equery_2enameClass(heff_dup(v_new_242)));
      V v_t_2416 = heff_intEq(v_a_2414, v_b_2415);
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_old_241);
        heff_drop(v_new_242);
        heff_drop(v_ru_24t_244_24Just);
        heff_drop(v_t_2416);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        heff_drop(v_t_2416);
        V v_t_2417 = heff_strAppend(((V)&g_heff_2equery_2erenameRefused_str6), heff_strAppend(v_new_242, heff_strAppend(((V)&g_heff_2equery_2erenameRefused_str7), heff_strAppend(v_old_241, ((V)&g_heff_2equery_2erenameRefused_str8)))));
        return heff_tag_at(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_2417});
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_ru_24t_243_24Just = heff_take_reuse(v_t_243, 0ULL);
    heff_drop(v_t_240);
    V v_a_2419 = (g_heff_2equery_2enameClass(heff_dup(v_old_241)));
    V v_b_2420 = (g_heff_2equery_2enameClass(heff_dup(v_new_242)));
    V v_t_2421 = heff_intEq(v_a_2419, v_b_2420);
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      heff_drop(v_old_241);
      heff_drop(v_new_242);
      heff_drop(v_ru_24t_243_24Just);
      heff_drop(v_t_2421);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      heff_drop(v_t_2421);
      V v_t_2422 = heff_strAppend(((V)&g_heff_2equery_2erenameRefused_str9), heff_strAppend(v_new_242, heff_strAppend(((V)&g_heff_2equery_2erenameRefused_str10), heff_strAppend(v_old_241, ((V)&g_heff_2equery_2erenameRefused_str11)))));
      return heff_tag_at(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_2422});
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2equery_2erenameRefused_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2erenameRefused(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2equery_2ebrokenSymbol_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {100, 97, 116, 97, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2equery_2ebrokenSymbol_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 104, 101, 111, 114, 121, 32}};
Clo g_heff_2equery_2ebrokenSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2ebrokenSymbol_entry, 2, 0};

V g_heff_2equery_2ebrokenSymbol(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_text_244 = heff_strSlice(heff_get(heff_dup(v_c_240), LBL_source), heff_get(heff_dup(v_sp_243), LBL_start), heff_get(heff_dup(v_sp_243), LBL_end));
    V v_t_245 = heff_strEq(heff_strSlice(heff_dup(v_text_244), MK_INT(0LL), MK_INT(5LL)), ((V)&g_heff_2equery_2ebrokenSymbol_str0));
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_text_244);
      heff_drop(v_t_245);
      v_t_248 = MK_INT(10LL);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_t_246 = heff_strEq(heff_strSlice(v_text_244, MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2equery_2ebrokenSymbol_str1));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_t_246);
        v_t_248 = MK_INT(11LL);
        break;
      }
      case TAG_False: {
        heff_drop(v_t_246);
        V v_x1_247 = (g_heff_2equery_2eisNameChar(heff_strCharCode(heff_dup(v_x_242), MK_INT(0LL))));
        switch (heff_tag_of(v_x1_247)) {
        case TAG_True: {
          heff_drop(v_x1_247);
          v_t_248 = MK_INT(12LL);
          break;
        }
        case TAG_False: {
          heff_drop(v_x1_247);
          v_t_248 = MK_INT(25LL);
          break;
        }
        default: heff_nomatch(v_x1_247);
        }
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_249 = (g_heff_2equery_2enameInGo(heff_get(v_c_240, LBL_source), heff_dup(v_x_242), heff_dup(v_sp_243), heff_get(heff_dup(v_sp_243), LBL_start)));
    return heff_rec(5, shape_190_147_299_281_39, (V[]){heff_dup(v_x_242), v_t_248, heff_dup(v_sp_243), v_t_249, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2equery_2ebrokenSymbol_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2ebrokenSymbol(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2equery_2elocalTermF_24s785_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2elocalTermF_24s785_entry, 1, 0};

V g_heff_2equery_2elocalTermF_24s785(V v_n_240) {
top: ;
  V v_it_243;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_n_240, 0);
    heff_take(v_n_240, 1ULL);
    v_it_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  switch (heff_tag_of(v_it_243)) {
  case TAG_EVar: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EImplicitVar: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EString: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EWord: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    V v_h_2411 = heff_field(v_it_243, 0);
    V v_args_2412 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 3ULL);
    V v_t_2413 = (g_heff_2equery_2elocalTermF_24s785(v_h_2411));
    V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_args_2412));
    V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_prelude_2efoldl_24s786(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return (g_prelude_2econcatList(v_t_2413, v_t_2415));
  }
  case TAG_EProject: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_ENamed: {
    V v_e_2418 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 2ULL);
    V t_0 = v_e_2418;
    v_n_240 = t_0;
    goto top;
  }
  case TAG_EPi: {
    V v_b_2419 = heff_field(v_it_243, 0);
    V v_cod_2420 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 3ULL);
    V v_t_2433;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_PiNamed: {
      V v_t_2423 = heff_field(v_b_2419, 2);
      heff_take(v_b_2419, 4ULL);
      v_t_2433 = (g_heff_2equery_2elocalTermF_24s785(v_t_2423));
      break;
    }
    case TAG_PiImplicit: {
      V v_t_2427 = heff_field(v_b_2419, 3);
      heff_take(v_b_2419, 8ULL);
      v_t_2433 = (g_heff_2equery_2elocalTermF_24s785(v_t_2427));
      break;
    }
    case TAG_PiInstance: {
      V v_t_2431 = heff_field(v_b_2419, 3);
      heff_take(v_b_2419, 8ULL);
      v_t_2433 = (g_heff_2equery_2elocalTermF_24s785(v_t_2431));
      break;
    }
    case TAG_PiAnon: {
      V v_t_2432 = heff_field(v_b_2419, 0);
      heff_take(v_b_2419, 1ULL);
      v_t_2433 = (g_heff_2equery_2elocalTermF_24s785(v_t_2432));
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    V v_t_2434 = (g_heff_2equery_2elocalTermF_24s785(v_cod_2420));
    return (g_prelude_2econcatList(v_t_2433, v_t_2434));
  }
  case TAG_ELam: {
    V v_b_2435 = heff_field(v_it_243, 0);
    V v_body_2436 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 3ULL);
    V v_t_2444;
    switch (heff_tag_of(v_b_2435)) {
    case TAG_LamName: {
      heff_take(v_b_2435, 0ULL);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_LamImplicit: {
      heff_take(v_b_2435, 0ULL);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_LamAnn: {
      V v_t_2443 = heff_field(v_b_2435, 2);
      heff_take(v_b_2435, 4ULL);
      v_t_2444 = (g_heff_2equery_2elocalTermF_24s785(v_t_2443));
      break;
    }
    default: heff_nomatch(v_b_2435);
    }
    V v_t_2445 = (g_heff_2equery_2elocalTermF_24s785(v_body_2436));
    return (g_prelude_2econcatList(v_t_2444, v_t_2445));
  }
  case TAG_EAnn: {
    V v_e_2446 = heff_field(v_it_243, 0);
    V v_t_2447 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 3ULL);
    V v_t_2448 = (g_heff_2equery_2elocalTermF_24s785(v_e_2446));
    V v_t_2449 = (g_heff_2equery_2elocalTermF_24s785(v_t_2447));
    return (g_prelude_2econcatList(v_t_2448, v_t_2449));
  }
  case TAG_ESpec: {
    V v_acc_2450 = heff_field(v_it_243, 0);
    V v_v_2453 = heff_field(v_it_243, 3);
    heff_take(v_it_243, 9ULL);
    V v_t_2454 = (g_heff_2equery_2elocalTermF_24s785(v_acc_2450));
    V v_t_2455 = (g_heff_2equery_2elocalTermF_24s785(v_v_2453));
    return (g_prelude_2econcatList(v_t_2454, v_t_2455));
  }
  case TAG_ESig: {
    V v_fs_2456 = heff_field(v_it_243, 0);
    heff_take(v_it_243, 1ULL);
    V v_t_2457 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_fs_2456));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2457; V r_ = (g_prelude_2efoldl_24s787(a_0, a_1)); heff_drop(v_t_2457); r_; });
  }
  case TAG_ESum: {
    V v_vs_2458 = heff_field(v_it_243, 0);
    heff_take(v_it_243, 1ULL);
    V v_t_2459 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_vs_2458));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2459; V r_ = (g_prelude_2efoldl_24s788(a_0, a_1)); heff_drop(v_t_2459); r_; });
  }
  case TAG_EStruct: {
    V v_fs_2460 = heff_field(v_it_243, 0);
    heff_take(v_it_243, 1ULL);
    V v_t_2461 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_fs_2460));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2461; V r_ = (g_prelude_2efoldl_24s789(a_0, a_1)); heff_drop(v_t_2461); r_; });
  }
  case TAG_EMatch: {
    V v_s_2462 = heff_field(v_it_243, 0);
    V v_alts_2463 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 3ULL);
    V v_t_2464 = (g_heff_2equery_2elocalTermF_24s785(v_s_2462));
    V v_t_2465 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_alts_2463));
    V v_t_2466 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2465; V r_ = (g_prelude_2efoldl_24s790(a_0, a_1)); heff_drop(v_t_2465); r_; });
    return (g_prelude_2econcatList(v_t_2464, v_t_2466));
  }
  case TAG_ELetIn: {
    V v_rhs_2467 = heff_field(v_it_243, 0);
    V v_it2_2468 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 3ULL);
    switch (heff_tag_of(v_it2_2468)) {
    case TAG_At: {
      V v_it21_2469 = heff_field(v_it2_2468, 0);
      heff_take(v_it2_2468, 1ULL);
      switch (heff_tag_of(v_it21_2469)) {
      case TAG_MkAlt: {
        V v_e_2472 = heff_field(v_it21_2469, 1);
        heff_take(v_it21_2469, 2ULL);
        V v_t_2473 = (g_heff_2equery_2elocalTermF_24s785(v_rhs_2467));
        V v_t_2474 = (g_heff_2equery_2elocalTermF_24s785(v_e_2472));
        return (g_prelude_2econcatList(v_t_2473, v_t_2474));
      }
      default: return heff_nomatch(v_it21_2469);
      }
    }
    default: return heff_nomatch(v_it2_2468);
    }
  }
  case TAG_EDo: {
    V v_stmts_2475 = heff_field(v_it_243, 0);
    heff_take(v_it_243, 1ULL);
    V v_t_2476 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_stmts_2475));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2476; V r_ = (g_prelude_2efoldl_24s791(a_0, a_1)); heff_drop(v_t_2476); r_; });
  }
  case TAG_ELocal: {
    V v_b_2477 = heff_field(v_it_243, 0);
    V v_defs_2478 = heff_field(v_it_243, 1);
    heff_take(v_it_243, 3ULL);
    V v_t_2479 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_defs_2478)));
    V v_t_2480 = (g_prelude_2efoldl_24s780(NTAG(TAG_Nil), v_t_2479));
    V v_t_2481 = (g_heff_2equery_2elocalTermF_24s785(v_b_2477));
    V v_t_2482 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_defs_2478));
    V v_t_2483 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2482; V r_ = (g_prelude_2efoldl_24s792(a_0, a_1)); heff_drop(v_t_2482); r_; });
    V v_t_2484 = (g_prelude_2econcatList(v_t_2481, v_t_2483));
    return (g_prelude_2econcatList(v_t_2480, v_t_2484));
  }
  case TAG_EInvalid: {
    heff_take(v_it_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2equery_2elocalTermF_24s785_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2elocalTermF_24s785(a[0]);
}
Clo g_heff_2equery_2elocalDeclF_24s783_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2elocalDeclF_24s783_entry, 1, 0};

V g_heff_2equery_2elocalDeclF_24s783(V v_d_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_d_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_DeclEquations: {
    V v_ty_246 = heff_field(v_t_243, 2);
    V v_eqs_247 = heff_field(v_t_243, 3);
    heff_take(v_t_243, 12ULL);
    V v_t_248 = (g_heff_2equery_2elocalTermF_24s785(v_ty_246));
    V v_t_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_eqs_247));
    V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_prelude_2efoldl_24s784(a_0, a_1)); heff_drop(v_t_249); r_; });
    return (g_prelude_2econcatList(v_t_248, v_t_2410));
  }
  case TAG_DeclDefine: {
    V v_ps_2413 = heff_field(v_t_243, 2);
    V v_u_2414 = heff_field(v_t_243, 3);
    V v_body_2415 = heff_field(v_t_243, 4);
    heff_take(v_t_243, 28ULL);
    V v_t_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_2413));
    V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_prelude_2efoldl_24s793(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_heff_2equery_2elocalTermF_24s785(v_u_2414));
    V v_t_2419 = (g_heff_2equery_2elocalTermF_24s785(v_body_2415));
    V v_t_2420 = (g_prelude_2econcatList(v_t_2418, v_t_2419));
    return (g_prelude_2econcatList(v_t_2417, v_t_2420));
  }
  case TAG_DeclTheory: {
    V v_ps_2423 = heff_field(v_t_243, 2);
    V v_body_2424 = heff_field(v_t_243, 3);
    heff_take(v_t_243, 12ULL);
    V v_t_2425 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_2423));
    V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_prelude_2efoldl_24s793(a_0, a_1)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_heff_2equery_2elocalTermF_24s785(v_body_2424));
    return (g_prelude_2econcatList(v_t_2426, v_t_2427));
  }
  case TAG_DeclPrimitive: {
    V v_t_2430 = heff_field(v_t_243, 2);
    heff_take(v_t_243, 4ULL);
    return (g_heff_2equery_2elocalTermF_24s785(v_t_2430));
  }
  case TAG_DeclTest: {
    heff_take(v_t_243, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_DeclWatch: {
    V v_e_2433 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    return (g_heff_2equery_2elocalTermF_24s785(v_e_2433));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2equery_2elocalDeclF_24s783_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2equery_2elocalDeclF_24s783(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2equery_2esymbolWith_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {100, 97, 116, 97, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2equery_2esymbolWith_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 104, 101, 111, 114, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2equery_2esymbolWith_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {100, 97, 116, 97, 32}};
V g_heff_2equery_2esymbolWith_lam0(V self, V *args);
V g_heff_2equery_2esymbolWith_lam1(V self, V *args);
Clo g_heff_2equery_2esymbolWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2esymbolWith_entry, 4, 0};

V g_heff_2equery_2esymbolWith(V v_c_240, V v_o_241, V v_sp_242, V v_own_243) {
top: ;
  V v_text_244 = heff_strSlice(heff_get(heff_dup(v_c_240), LBL_source), heff_get(heff_dup(v_sp_242), LBL_start), heff_get(heff_dup(v_sp_242), LBL_end));
  V v_t_245 = heff_strEq(heff_strSlice(heff_dup(v_text_244), MK_INT(0LL), MK_INT(5LL)), ((V)&g_heff_2equery_2esymbolWith_str0));
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_text_244);
    heff_drop(v_t_245);
    v_t_249 = MK_INT(10LL);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_t_246 = heff_strEq(heff_strSlice(v_text_244, MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2equery_2esymbolWith_str1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      v_t_249 = MK_INT(11LL);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_246);
      V v_t_247 = heff_strCharCode(heff_get(heff_dup(v_o_241), LBL_name), MK_INT(0LL));
      V v_x1_248 = (g_heff_2equery_2eisNameChar(v_t_247));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        heff_drop(v_x1_248);
        v_t_249 = MK_INT(12LL);
        break;
      }
      case TAG_False: {
        heff_drop(v_x1_248);
        v_t_249 = MK_INT(25LL);
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2410 = (g_prelude_2efind_24s781(v_own_243));
  V v_t_2412;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_t_2410);
    v_t_2412 = (g_heff_2equery_2enameInGo(heff_get(heff_dup(v_c_240), LBL_source), heff_get(heff_dup(v_o_241), LBL_name), heff_dup(v_sp_242), heff_get(heff_dup(v_sp_242), LBL_start)));
    break;
  }
  case TAG_Just: {
    V v_s_2411 = heff_field(v_t_2410, 0);
    heff_take(v_t_2410, 1ULL);
    v_t_2412 = heff_get(v_s_2411, LBL_span);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2413 = (g_prelude_2efilter_24s782(v_own_243));
  V v_t_2419 = (g_prelude_2emap(heff_clo(g_heff_2equery_2esymbolWith_lam0, 1, 2, (V[]){heff_dup(v_sp_242), heff_dup(v_c_240)}), v_t_2413));
  V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(v_c_240, LBL_decls)));
  V v_t_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_prelude_2efoldl_24s792(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2426 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2esymbolWith_lam1, 1, 1, (V[]){heff_dup(v_sp_242)}), v_t_2421));
  V v_t_2427 = (g_prelude_2econcatList(v_t_2419, v_t_2426));
  return heff_rec(5, shape_190_147_299_281_39, (V[]){heff_get(v_o_241, LBL_name), v_t_249, v_sp_242, v_t_2412, v_t_2427});
}
V g_heff_2equery_2esymbolWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2esymbolWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2equery_2esymbolWith_lam0(V self, V *args) {
  V v_m_2414 = args[0];
  V v_sp_242 = heff_dup(heff_env(self)[0]);
  V v_c_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2415 = heff_intAdd(heff_get(heff_dup(v_sp_242), LBL_start), MK_INT(5LL));
  V v_t_2416 = heff_strSlice(heff_get(v_c_240, LBL_source), heff_get(v_sp_242, LBL_start), v_t_2415);
  V v_t_2417 = heff_strEq(v_t_2416, ((V)&g_heff_2equery_2esymbolWith_str2));
  V v_t_2418;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop(v_t_2417);
    v_t_2418 = MK_INT(22LL);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2417);
    v_t_2418 = MK_INT(8LL);
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  return heff_rec(3, shape_190_147_299, (V[]){heff_get(heff_dup(v_m_2414), LBL_name), v_t_2418, heff_get(v_m_2414, LBL_span)});
}
V g_heff_2equery_2esymbolWith_lam1(V self, V *args) {
  V v_m_2422 = args[0];
  V v_sp_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2423 = heff_get(heff_get(heff_dup(v_m_2422), LBL_span), LBL_start);
  V v_t_2424 = heff_intLe(heff_get(heff_dup(v_sp_242), LBL_start), v_t_2423);
  switch (heff_tag_of(v_t_2424)) {
  case TAG_True: {
    heff_drop(v_t_2424);
    V v_t_2425 = heff_get(heff_get(v_m_2422, LBL_span), LBL_end);
    return heff_intLe(v_t_2425, heff_get(v_sp_242, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_m_2422);
    heff_drop(v_sp_242);
    heff_drop(v_t_2424);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2424);
  }
}
V g_heff_2equery_2esymbolsGo_lam0(V self, V *args);
Clo g_heff_2equery_2esymbolsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2esymbolsGo_entry, 4, 0};

V g_heff_2equery_2esymbolsGo(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x3_242);
    heff_drop(v_x4_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_x4_243);
      heff_drop(v_o_244);
      heff_drop(v_os_245);
      heff_drop(v_ru_24x3_242_24Cons);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      heff_take(v_x4_243, 3ULL);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        heff_take(v_x41_246, 2ULL);
        V v_t_2414 = (g_prelude_2efilter(heff_clo(g_heff_2equery_2esymbolsGo_lam0, 1, 1, (V[]){heff_dup(v_sp_249)}), heff_dup(v_ss_241)));
        V v_t_2415 = (g_heff_2equery_2esymbolWith(heff_dup(v_c_240), v_o_244, v_sp_249, v_t_2414));
        return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, (g_heff_2equery_2esymbolsGo(v_c_240, v_ss_241, v_os_245, v_sps_247))});
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2equery_2esymbolsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2esymbolsGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2equery_2esymbolsGo_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_sp_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2411 = heff_get(heff_get(heff_dup(v_s_2410), LBL_span), LBL_start);
  V v_t_2412 = heff_intLe(heff_get(heff_dup(v_sp_249), LBL_start), v_t_2411);
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_t_2412);
    V v_t_2413 = heff_get(heff_get(v_s_2410, LBL_span), LBL_end);
    return heff_intLe(v_t_2413, heff_get(v_sp_249, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_s_2410);
    heff_drop(v_sp_249);
    heff_drop(v_t_2412);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2equery_2esymbols_lam0(V self, V *args);
V g_heff_2equery_2esymbols_lam1(V self, V *args);
Clo g_heff_2equery_2esymbols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2equery_2esymbols_entry, 1, 0};

V g_heff_2equery_2esymbols(V v_c_240) {
top: ;
  V v_t_241 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_c_240), LBL_decls)));
  V v_t_245 = ({ V a_0 = heff_clo(g_heff_2equery_2esymbols_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_241; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  V v_t_246 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_spans);
  V v_t_247 = (g_heff_2equery_2esymbolsGo(heff_dup(v_c_240), v_t_245, heff_get(heff_dup(v_c_240), LBL_own), v_t_246));
  V v_t_248 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_broken);
  V v_t_2410 = (g_prelude_2emap(heff_clo(g_heff_2equery_2esymbols_lam1, 1, 1, (V[]){v_c_240}), v_t_248));
  V v_t_2411 = (g_prelude_2econcatList(v_t_247, v_t_2410));
  return (g_prelude_2esortBy_24s794(v_t_2411));
}
V g_heff_2equery_2esymbols_entry(V self, V *a) {
  (void)self;
  return g_heff_2equery_2esymbols(a[0]);
}
V g_heff_2equery_2esymbols_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_x_243 = args[1];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = ({ V a_0 = v_c_240; V a_1 = v_x_243; V r_ = (g_heff_2equery_2edeclSites(a_0, a_1)); heff_drop(v_x_243); r_; });
  return (g_prelude_2econcatList(v_t_244, v_acc_242));
}
V g_heff_2equery_2esymbols_lam1(V self, V *args) {
  V v_p_249 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_c_240; V a_1 = v_p_249; V r_ = (g_heff_2equery_2ebrokenSymbol(a_0, a_1)); heff_drop(v_p_249); r_; });
}