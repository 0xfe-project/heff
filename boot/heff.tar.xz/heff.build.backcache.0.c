// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_asks 9499105
#define LBL_copies 592412158
#define LBL_depth 296830685
#define LBL_emits 297985818
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_made 9839068
#define LBL_name 9869138
#define LBL_params 951713969
#define LBL_recipe 1012227257
#define LBL_result 1012715336
#define LBL_safe 10017876
#define LBL_ver 326173
#define LBL_works 314677148
static uint32_t shape_groups__copies__emits__jss__works[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss, LBL_works};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_ver__recipe__asks__depth__safe__made[] = {LBL_ver, LBL_recipe, LBL_asks, LBL_depth, LBL_safe, LBL_made};
HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V);
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackText(V, V);
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackText_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
V g_heff_2ebuild_2ebackcache_2ecopyText(V);
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesOf(V);
V g_heff_2ebuild_2ebackcache_2eentriesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesOf_clo;
V g_heff_2ebuild_2ebackcache_2elastDotGo(V, V, V);
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ebuild_2ebackcache_2epairsGo(V, V);
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2ereprOf_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2ebackcache_2esigD_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1220284991x1771862623_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
V g_list_2efoldl_24s1103469845x1474178821(V, V, V);
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1103469845x1474178821_clo;
V g_list_2efoldl_24s1494296198x1800016121(V, V, V);
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1494296198x1800016121_clo;
V g_list_2efoldl_24s1533929316x1834489357(V, V);
V g_list_2efoldl_24s1533929316x1834489357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1533929316x1834489357_clo;
V g_list_2efoldl_24s224553292x101133675(V, V);
V g_list_2efoldl_24s224553292x101133675_entry(V self, V *a);
extern Clo g_list_2efoldl_24s224553292x101133675_clo;
V g_list_2efoldl_24s425699049x1164890302(V, V, V);
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s425699049x1164890302_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s74354549x624137353(V, V, V);
V g_list_2efoldl_24s74354549x624137353_entry(V self, V *a);
extern Clo g_list_2efoldl_24s74354549x624137353_clo;
V g_list_2efoldl_24s788343806x1528994845(V, V, V);
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788343806x1528994845_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackDir_str0, 2, "b1");

static V g_heff_2ebuild_2ebackcache_2ebackDir_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2ebackDir_st;
static V g_heff_2ebuild_2ebackcache_2ebackDir_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2ebackDir_str0);
}
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2ebackDir_st)) return g_heff_2ebuild_2ebackcache_2ebackDir_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2ebackDir_val, &g_heff_2ebuild_2ebackcache_2ebackDir_st, g_heff_2ebuild_2ebackcache_2ebackDir_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str2, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str3, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str4, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str6, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str8, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str10, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str11, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str13, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2ecopyText(V v_c_240) {
top: ;
  V v_name_241 = heff_take_field(v_c_240, 0);
  V v_ver_242 = heff_take_field(v_c_240, 1);
  V v_recipe_243 = heff_take_field(v_c_240, 2);
  V v_asks_244 = heff_take_field(v_c_240, 3);
  V v_safe_245 = heff_take_field(v_c_240, 5);
  V v_made_246 = heff_take_field(v_c_240, 6);
  V v_depth_247 = heff_get_n(v_c_240, 4, 7);
  V v_s_248 = v_name_241;
  V v_s_249 = v_ver_242;
  V v_x2_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_recipe_243, NTAG(TAG_Nil)));
  V v_s_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_s_2413 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_s_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_ps_2414 = v_asks_244;
  V v_t_2415 = v_safe_245;
  V v_t_2416;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str2);
  } else {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str3);
  }
  V v_x1_2417 = v_made_246;
  V v_t_2430;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nothing: {
    v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str4), NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_MkPair: {
      V v_b_2419 = heff_field(v_x11_2418, 0);
      V v_t_2420 = heff_field(v_x11_2418, 1);
      V v_ru_24x11_2418_24MkPair = heff_take_reuse_n(v_x11_2418, 3ULL, 2);
      V v_x2_2421 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2419, NTAG(TAG_Nil)));
      V v_s_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_s_2424 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_s_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str6); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_t_2420));
      V v_t_2426 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_t_2420, NTAG(TAG_Nil)));
      V v_t_2427 = heff_intShow(heff_strLength_lent(v_s_2424, 0));
      V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str7)), v_s_2424);
      V v_t_2429 = heff_tag_at_n(v_ru_24x11_2418_24MkPair, TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), v_t_2426});
      v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2429})});
      break;
    }
    default: heff_nomatch(v_x11_2418);
    }
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_rest_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_depth_247), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2430})});
  V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2414));
  V v_t_2433 = heff_intShow(v_t_2432);
  V v_t_2434 = ({ V a_0 = v_ps_2414; V a_1 = v_rest_2431; V r_ = (g_heff_2ebuild_2ebackcache_2epairsGo(a_0, a_1)); heff_drop_tag(v_rest_2431, 2); r_; });
  V v_t_2435 = heff_intShow(heff_strLength_lent(v_s_249, 0));
  V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str9)), v_s_249);
  V v_t_2437 = heff_intShow(heff_strLength_lent(v_s_2413, 0));
  V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str10)), v_s_2413);
  V v_t_2439 = heff_intShow(heff_strLength_lent(v_s_248, 0));
  V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str11)), v_s_248);
  V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str12)), v_t_2436);
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2434})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str13); V a_1 = v_t_2441; V a_2 = v_t_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2442, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyText(a[0]);
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ecopyD(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(v_x_2424, v_s_240, v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam0, 3, 5, (V[]){v_x_246, v_x_2412, v_x_2418, v_x_2430, v_x_2436}), v_s_240, v_j_2437));
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2412);
                          heff_drop(v_x_2418);
                          heff_drop(v_x_2430);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return NTAG(TAG_Nothing);
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2412);
                      heff_drop(v_x_2418);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return NTAG(TAG_Nothing);
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_x_2418);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args) {
  V v_u_2453 = args[0];
  V v_x_2418 = heff_env(self)[0];
  heff_drop(v_u_2453);
  heff_clo_take(self, 1);
  HeffT3 v_t_2454 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2418, MK_INT(0LL)));
  {
    V v_field_2456 = v_t_2454.f[1];
    V v_field_2457 = v_t_2454.f[2];
    int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
    if ((v_tag_2455 == ((int64_t)0ULL))) {
      V v_x_2458 = v_field_2456;
      V v_x112_2459 = v_field_2457;
      heff_drop(v_x112_2459);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2458});
    } else {
      heff_drop(v_field_2456);
      heff_drop(v_field_2457);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args) {
  V v_safe_2438 = args[0];
  V v_s_2439 = args[1];
  V v_i_2440 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_x_2430 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  HeffT3 v_t_2441 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2439, v_i_2440));
  {
    V v_field_2443 = v_t_2441.f[1];
    V v_field_2444 = v_t_2441.f[2];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_x_2445 = v_field_2443;
      V v_j_2446 = v_field_2444;
      HeffT3 v_t_2447 = ({ V a_0 = v_x_2445; V a_1 = v_s_2439; V a_2 = v_j_2446; HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2445); r_; });
      {
        V v_field_2449 = v_t_2447.f[1];
        V v_field_2450 = v_t_2447.f[2];
        int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
        if ((v_tag_2448 == ((int64_t)0ULL))) {
          V v_x_2451 = v_field_2449;
          V v_j_2452 = v_field_2450;
          heff_clo_take(self, 5);
          V v_t_2460 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, heff_rec_n(6, shape_ver__recipe__asks__depth__safe__made, (V[]){v_x_2412, heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam1, 1, 1, (V[]){v_x_2418}), v_x_2430, v_x_2436, v_safe_2438, v_x_2451})});
          return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2460, v_j_2452})});
        } else {
          heff_drop(v_safe_2438);
          heff_drop(self);
          heff_drop(v_field_2449);
          heff_drop(v_field_2450);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_safe_2438);
      heff_drop(v_s_2439);
      heff_drop(self);
      heff_drop(v_field_2443);
      heff_drop(v_field_2444);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT3 g_heff_2ebuild_2ebackcache_2esigD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s1220284991x1771862623_24cpr(v_x_246, v_s_240, v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = ({ V a_0 = v_x_2418; V a_1 = v_s_240; V a_2 = v_j_2419; HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2ereprOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2418); heff_drop(v_s_240); r_; });
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_params__result, (V[]){v_x_2412, v_x_2424}), v_j_2425}});
                } else {
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emoduleIn_str0, 1, "_");
Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emoduleIn_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2emoduleIn(V v_mods_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_mods_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      return v_k_241;
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
      if (heff_intLe_c(v_t_246, MK_INT(0LL))) {
        heff_drop(v_k_241);
        return ((V)&g_heff_2ebuild_2ebackcache_2emoduleIn_str0);
      } else {
        V v_t_247 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
        V t_0 = v_mods_240;
        V t_1 = heff_strSlice(v_k_241, MK_INT(0LL), v_t_247);
        v_mods_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emoduleIn(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ebackcache_2eentriesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eentriesOf_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eentriesOf(V v_b_240) {
top: ;
  V v_groups_241 = heff_take_field(v_b_240, 0);
  V v_copies_242 = heff_take_field(v_b_240, 1);
  V v_emits_243 = heff_take_field(v_b_240, 2);
  V v_jss_244 = heff_take_field(v_b_240, 3);
  V v_works_245 = heff_take_field(v_b_240, 4);
  V v_t_246 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_groups_241; V r_ = (g_list_2efoldl_24s224553292x101133675(a_0, a_1)); heff_drop(v_groups_241); r_; });
  V v_t_247 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_copies_242; V r_ = (g_list_2efoldl_24s1533929316x1834489357(a_0, a_1)); heff_drop(v_copies_242); r_; });
  V v_t_248 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_emits_243; V r_ = (g_list_2efoldl_24s1533929316x1834489357(a_0, a_1)); heff_drop(v_emits_243); r_; });
  V v_t_249 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_jss_244; V r_ = (g_list_2efoldl_24s1533929316x1834489357(a_0, a_1)); heff_drop(v_jss_244); r_; });
  V v_t_2410 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_works_245; V r_ = (g_list_2efoldl_24s1533929316x1834489357(a_0, a_1)); heff_drop(v_works_245); r_; });
  return ({ V rv_0 = v_t_246; V rv_1 = v_t_247; V rv_2 = v_t_248; V rv_3 = v_t_249; V rv_4 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_b_240, 0ULL, 5, shape_groups__copies__emits__jss__works, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2ebuild_2ebackcache_2eentriesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eentriesOf(a[0]);
}

HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_rest_242));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_xs_247 = v_field_246;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_247})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_243);
          heff_drop(v_field_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackTexts_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2ebackTexts(V v_id_240, V v_fs_241, V v_gv_242) {
top: ;
  V v_groups_243 = heff_take_field(v_gv_242, 0);
  V v_copies_244 = heff_take_field(v_gv_242, 1);
  V v_emits_245 = heff_take_field(v_gv_242, 2);
  V v_jss_246 = heff_take_field(v_gv_242, 3);
  V v_works_247 = heff_get_n(v_gv_242, 4, 5);
  V v_t_248 = ({ V a_0 = v_fs_241; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_groups_243; V r_ = (g_list_2efoldl_24s1494296198x1800016121(a_0, a_1, a_2)); heff_drop(v_groups_243); r_; });
  V v_t_249 = ({ V a_0 = v_fs_241; V a_1 = v_t_248; V a_2 = v_copies_244; V r_ = (g_list_2efoldl_24s1103469845x1474178821(a_0, a_1, a_2)); heff_drop(v_copies_244); r_; });
  V v_t_2410 = ({ V a_0 = v_fs_241; V a_1 = v_t_249; V a_2 = v_emits_245; V r_ = (g_list_2efoldl_24s788343806x1528994845(a_0, a_1, a_2)); heff_drop(v_emits_245); r_; });
  V v_t_2411 = ({ V a_0 = v_fs_241; V a_1 = v_t_2410; V a_2 = v_jss_246; V r_ = (g_list_2efoldl_24s425699049x1164890302(a_0, a_1, a_2)); heff_drop(v_jss_246); r_; });
  V v_m_2412 = ({ V a_0 = v_fs_241; V a_1 = v_t_2411; V a_2 = v_works_247; V r_ = (g_list_2efoldl_24s74354549x624137353(a_0, a_1, a_2)); heff_drop(v_works_247); r_; });
  V v_t_2413 = ({ V a_0 = v_m_2412; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2412); r_; });
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2ebackTexts_lam0, 1, 1, (V[]){v_id_240}), v_t_2413));
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebackcache_2ebackTexts(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_dup(heff_field(v_p_2414, 0));
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  V v_t_2420;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_p_2414, 1);
    heff_take_n(v_p_2414, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  heff_clo_take(self, 1);
  V v_t_2421 = (g_heff_2ebuild_2ebackcache_2ebackText(v_id_240, v_t_2420));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_t_2421});
}