// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Catch 6517
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DForeign 42447
#define TAG_DImport 15253
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_F32 16337
#define TAG_Get 18914
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkDAlts 45152
#define TAG_MkLetHead 58143
#define TAG_MkSep 6724
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sum 30935
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_app 306331
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_opExpr 935619233
#define LBL_patAtom 1586746071
#define LBL_patHead 1586939750
#define LBL_pattern 1588251091
#define LBL_raw 322210
#define LBL_ret 322331
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_userOps 84709677
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE[] = {LBL_expr, LBL_opExpr, LBL_userOps, LBL_app, LBL_atom, LBL_pattern, LBL_patHead, LBL_patAtom, LBL_lambda, LBL_caseE, LBL_ifE, LBL_doE, LBL_letE};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecst_2eanonymousSumF(V, V, V);
V g_heff_2ecst_2eanonymousSumF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eanonymousSumF_clo;
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043(V, V);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_entry(V self, V *a);
extern Clo g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_clo;
V g_heff_2ecst_2earrowRhsF(V, V, V);
V g_heff_2ecst_2earrowRhsF_entry(V self, V *a);
extern Clo g_heff_2ecst_2earrowRhsF_clo;
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819(V, V);
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_entry(V self, V *a);
extern Clo g_heff_2ecst_2earrowRhsF_24s424219474x257387819_clo;
V g_heff_2ecst_2eatBoundary(V, V);
V g_heff_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatBoundary_clo;
V g_heff_2ecst_2eatTok(V, V, V);
V g_heff_2ecst_2eatTok_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatTok_clo;
V g_heff_2ecst_2eatomBase(V, V);
V g_heff_2ecst_2eatomBase_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomBase_clo;
V g_heff_2ecst_2eatomBase_24s833913695x513827753(V);
V g_heff_2ecst_2eatomBase_24s833913695x513827753_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomBase_24s833913695x513827753_clo;
V g_heff_2ecst_2eatomF(V, V, V);
V g_heff_2ecst_2eatomF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomF_clo;
V g_heff_2ecst_2eatomF_24s1730811308x810317142(V, V);
V g_heff_2ecst_2eatomF_24s1730811308x810317142_entry(V self, V *a);
extern Clo g_heff_2ecst_2eatomF_24s1730811308x810317142_clo;
V g_heff_2ecst_2eblock(V, V, V);
V g_heff_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblock_clo;
V g_heff_2ecst_2eblock_24s354081874x470153967(V, V);
V g_heff_2ecst_2eblock_24s354081874x470153967_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblock_24s354081874x470153967_clo;
V g_heff_2ecst_2eblock_24s57540649x559838160(V, V);
V g_heff_2ecst_2eblock_24s57540649x559838160_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblock_24s57540649x559838160_clo;
V g_heff_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblockGo_clo;
V g_heff_2ecst_2eblockGo_24s1300006556x200850327(V, V, V, V);
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblockGo_24s1300006556x200850327_clo;
V g_heff_2ecst_2eblockGo_24s570672665x991963980(V, V, V, V);
V g_heff_2ecst_2eblockGo_24s570672665x991963980_entry(V self, V *a);
extern Clo g_heff_2ecst_2eblockGo_24s570672665x991963980_clo;
V g_heff_2ecst_2ebracesF(V, V, V);
V g_heff_2ecst_2ebracesF_entry(V self, V *a);
extern Clo g_heff_2ecst_2ebracesF_clo;
V g_heff_2ecst_2ebracesF_24s658113058x1319132375(V, V);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_entry(V self, V *a);
extern Clo g_heff_2ecst_2ebracesF_24s658113058x1319132375_clo;
V g_heff_2ecst_2ecaseExprF(V, V, V);
V g_heff_2ecst_2ecaseExprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2ecaseExprF_clo;
V g_heff_2ecst_2echeckAltNames(V, V);
V g_heff_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2ecst_2echeckAltNames_clo;
V g_heff_2ecst_2econtinuesBlock(V, V);
V g_heff_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2ecst_2econtinuesBlock_clo;
V g_heff_2ecst_2ecur(V);
V g_heff_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2ecst_2ecur_clo;
V g_heff_2ecst_2edataAlternative(V, V);
V g_heff_2ecst_2edataAlternative_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataAlternative_clo;
V g_heff_2ecst_2edataDecl(V, V);
V g_heff_2ecst_2edataDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataDecl_clo;
V g_heff_2ecst_2edataLast(V, V, V, V);
V g_heff_2ecst_2edataLast_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataLast_clo;
V g_heff_2ecst_2edataParam(V, V);
V g_heff_2ecst_2edataParam_entry(V self, V *a);
extern Clo g_heff_2ecst_2edataParam_clo;
V g_heff_2ecst_2edeclAt(V);
V g_heff_2ecst_2edeclAt_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclAt_clo;
V g_heff_2ecst_2edeclNameLen(V, V, V);
V g_heff_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclNameLen_clo;
V g_heff_2ecst_2edeclaredAt(V);
V g_heff_2ecst_2edeclaredAt_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclaredAt_clo;
V g_heff_2ecst_2edeclaredTwo(V, V);
V g_heff_2ecst_2edeclaredTwo_entry(V self, V *a);
extern Clo g_heff_2ecst_2edeclaredTwo_clo;
V g_heff_2ecst_2edefaultedF(V, V, V);
V g_heff_2ecst_2edefaultedF_entry(V self, V *a);
extern Clo g_heff_2ecst_2edefaultedF_clo;
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756(V, V);
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_entry(V self, V *a);
extern Clo g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_clo;
V g_heff_2ecst_2eendBefore(V, V);
V g_heff_2ecst_2eendBefore_entry(V self, V *a);
extern Clo g_heff_2ecst_2eendBefore_clo;
V g_heff_2ecst_2eexpectAnn(V, V);
V g_heff_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectAnn_clo;
V g_heff_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectKind_clo;
V g_heff_2ecst_2eexpectKw(V, V, V);
V g_heff_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectKw_clo;
V g_heff_2ecst_2eexpectPunct(V, V, V);
V g_heff_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectPunct_clo;
V g_heff_2ecst_2eexpectSym(V, V, V);
V g_heff_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexpectSym_clo;
V g_heff_2ecst_2eexprF(V, V, V);
V g_heff_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprF_clo;
V g_heff_2ecst_2eexprF_24s1428526773x1081603075(V, V);
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprF_24s1428526773x1081603075_clo;
V g_heff_2ecst_2eexprF_24s504856081x2014933897(V, V);
V g_heff_2ecst_2eexprF_24s504856081x2014933897_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprF_24s504856081x2014933897_clo;
V g_heff_2ecst_2eexprHead(V, V);
V g_heff_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprHead_clo;
V g_heff_2ecst_2eexprHead_24s451872800x322153056(V);
V g_heff_2ecst_2eexprHead_24s451872800x322153056_entry(V self, V *a);
extern Clo g_heff_2ecst_2eexprHead_24s451872800x322153056_clo;
V g_heff_2ecst_2efieldDefault(V, V);
V g_heff_2ecst_2efieldDefault_entry(V self, V *a);
extern Clo g_heff_2ecst_2efieldDefault_clo;
V g_heff_2ecst_2efieldsGo(V, V, V);
V g_heff_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2efieldsGo_clo;
V g_heff_2ecst_2efirstD(V);
V g_heff_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2ecst_2efirstD_clo;
V g_heff_2ecst_2efirstE(V);
V g_heff_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2ecst_2efirstE_clo;
V g_heff_2ecst_2efirstP(V);
V g_heff_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2ecst_2efirstP_clo;
V g_heff_2ecst_2efixityRest(V, V, V);
V g_heff_2ecst_2efixityRest_entry(V self, V *a);
extern Clo g_heff_2ecst_2efixityRest_clo;
V g_heff_2ecst_2eforeignDecl(V, V);
V g_heff_2ecst_2eforeignDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2eforeignDecl_clo;
V g_heff_2ecst_2egram_get(void);
V g_heff_2ecst_2eifExprF(V, V, V);
V g_heff_2ecst_2eifExprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eifExprF_clo;
V g_heff_2ecst_2einBrackets(V, V, V);
V g_heff_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2ecst_2einBrackets_clo;
V g_heff_2ecst_2elamBinderF(V, V, V);
V g_heff_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2ecst_2elamBinderF_clo;
V g_heff_2ecst_2elamBinders(V, V, V, V);
V g_heff_2ecst_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2ecst_2elamBinders_clo;
V g_heff_2ecst_2elambdaF(V, V, V);
V g_heff_2ecst_2elambdaF_entry(V self, V *a);
extern Clo g_heff_2ecst_2elambdaF_clo;
V g_heff_2ecst_2elastD(V);
V g_heff_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2ecst_2elastD_clo;
V g_heff_2ecst_2elastE(V);
V g_heff_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2ecst_2elastE_clo;
V g_heff_2ecst_2elastP(V);
V g_heff_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2ecst_2elastP_clo;
V g_heff_2ecst_2eletExprF(V, V, V);
V g_heff_2ecst_2eletExprF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eletExprF_clo;
V g_heff_2ecst_2eletHeadF(V, V, V);
V g_heff_2ecst_2eletHeadF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eletHeadF_clo;
V g_heff_2ecst_2eletStmtF(V, V, V);
V g_heff_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eletStmtF_clo;
V g_heff_2ecst_2elistOfF_24s1130792037x937330368(V, V, V);
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_entry(V self, V *a);
extern Clo g_heff_2ecst_2elistOfF_24s1130792037x937330368_clo;
V g_heff_2ecst_2elistOfF_24s2135508030x893215028(V, V, V);
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_entry(V self, V *a);
extern Clo g_heff_2ecst_2elistOfF_24s2135508030x893215028_clo;
V g_heff_2ecst_2elocalDecl(V, V);
V g_heff_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2elocalDecl_clo;
V g_heff_2ecst_2emanyGo(V, V, V, V);
V g_heff_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2emanyGo_clo;
V g_heff_2ecst_2emanyParams(V, V, V);
V g_heff_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2ecst_2emanyParams_clo;
V g_heff_2ecst_2enext(V, V);
V g_heff_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2ecst_2enext_clo;
V g_heff_2ecst_2enextN(V, V, V);
V g_heff_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2ecst_2enextN_clo;
V g_heff_2ecst_2eopLoopF(V, V, V, V, V);
V g_heff_2ecst_2eopLoopF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eopLoopF_clo;
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009(V, V, V, V);
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_entry(V self, V *a);
extern Clo g_heff_2ecst_2eopLoopF_24s917930102x1677408009_clo;
V g_heff_2ecst_2eoperandsF(V, V, V, V);
V g_heff_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eoperandsF_clo;
V g_heff_2ecst_2eparensF(V, V, V);
V g_heff_2ecst_2eparensF_entry(V self, V *a);
extern Clo g_heff_2ecst_2eparensF_clo;
V g_heff_2ecst_2eparensF_24s640260088x2009418696(V, V);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_entry(V self, V *a);
extern Clo g_heff_2ecst_2eparensF_24s640260088x2009418696_clo;
V g_heff_2ecst_2epatAtomF(V, V, V);
V g_heff_2ecst_2epatAtomF_entry(V self, V *a);
extern Clo g_heff_2ecst_2epatAtomF_clo;
V g_heff_2ecst_2epatHeadF(V, V, V);
V g_heff_2ecst_2epatHeadF_entry(V self, V *a);
extern Clo g_heff_2ecst_2epatHeadF_clo;
V g_heff_2ecst_2epatternF(V, V, V);
V g_heff_2ecst_2epatternF_entry(V self, V *a);
extern Clo g_heff_2ecst_2epatternF_clo;
V g_heff_2ecst_2eprimitiveDecl(V, V);
V g_heff_2ecst_2eprimitiveDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2eprimitiveDecl_clo;
V g_heff_2ecst_2eprogramGo(V, V);
V g_heff_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2eprogramGo_clo;
V g_heff_2ecst_2ereadH_get(void);
V g_heff_2ecst_2ereadSumAlg(V, V);
V g_heff_2ecst_2ereadSumAlg_entry(V self, V *a);
extern Clo g_heff_2ecst_2ereadSumAlg_clo;
V g_heff_2ecst_2erecordPatF(V, V, V);
V g_heff_2ecst_2erecordPatF_entry(V self, V *a);
extern Clo g_heff_2ecst_2erecordPatF_clo;
V g_heff_2ecst_2erunP_24s1504380254x1312992993(V);
V g_heff_2ecst_2erunP_24s1504380254x1312992993_entry(V self, V *a);
extern Clo g_heff_2ecst_2erunP_24s1504380254x1312992993_clo;
V g_heff_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2ecst_2esepGo_clo;
V g_heff_2ecst_2esepGo_24s1211973577x145888309(V, V, V, V, V);
V g_heff_2ecst_2esepGo_24s1211973577x145888309_entry(V self, V *a);
extern Clo g_heff_2ecst_2esepGo_24s1211973577x145888309_clo;
V g_heff_2ecst_2esepGo_24s1789038472x1625161927(V, V, V, V, V);
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_entry(V self, V *a);
extern Clo g_heff_2ecst_2esepGo_24s1789038472x1625161927_clo;
V g_heff_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2ecst_2esigOrEqn_clo;
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291(V, V, V);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_entry(V self, V *a);
extern Clo g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_clo;
V g_heff_2ecst_2eskipDecl(V);
V g_heff_2ecst_2eskipDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2eskipDecl_clo;
V g_heff_2ecst_2eskipFrom(V);
V g_heff_2ecst_2eskipFrom_entry(V self, V *a);
extern Clo g_heff_2ecst_2eskipFrom_clo;
V g_heff_2ecst_2estartsAtom(V);
V g_heff_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2ecst_2estartsAtom_clo;
V g_heff_2ecst_2estatementF(V, V, V);
V g_heff_2ecst_2estatementF_entry(V self, V *a);
extern Clo g_heff_2ecst_2estatementF_clo;
V g_heff_2ecst_2etheoryDecl(V, V);
V g_heff_2ecst_2etheoryDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2etheoryDecl_clo;
V g_heff_2ecst_2etheoryField(V, V);
V g_heff_2ecst_2etheoryField_entry(V self, V *a);
extern Clo g_heff_2ecst_2etheoryField_clo;
V g_heff_2ecst_2etokAt(V, V);
V g_heff_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2ecst_2etokAt_clo;
V g_heff_2ecst_2etypeDecl(V, V);
V g_heff_2ecst_2etypeDecl_entry(V self, V *a);
extern Clo g_heff_2ecst_2etypeDecl_clo;
V g_heff_2efixed_2eallFixed_get(void);
V g_heff_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2ecst_2ereadSumAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ereadSumAlg_entry, 2, 0};

V g_heff_2ecst_2ereadSumAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_apply(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_s2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_s2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_d_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_d_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_c_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      heff_take_n(v_q_247, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24InR, 1);
      V v_r_2411 = heff_tr(heff_apply(v_c_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_r_2411)) {
      case TAG_MkPair: {
        V v_r1_2412 = heff_dup(heff_field(v_r_2411, 0));
        V v_st_2413 = heff_dup(heff_field(v_r_2411, 1));
        switch (heff_tag_of(v_r1_2412)) {
        case TAG_Left: {
          V v_d_2414 = heff_field(v_r1_2412, 0);
          heff_take_n(v_r1_2412, 1ULL, 1);
          heff_drop_tag(v_r_2411, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_d_2414, v_st_2413});
        }
        case TAG_Right: {
          heff_take_n(v_r1_2412, 0ULL, 1);
          heff_drop(v_h_2410);
          heff_drop(v_st_2413);
          return v_r_2411;
        }
        default: return heff_nomatch(v_r1_2412);
        }
      }
      default: return heff_nomatch(v_r_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecst_2ereadSumAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2ereadSumAlg(a[0], a[1]);
}
V g_heff_2ecst_2ereadH_lam0(V self, V *args); static Clo g_heff_2ecst_2ereadH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ereadH_lam0, 2, 0};
V g_heff_2ecst_2ereadH_lam1(V self, V *args); static Clo g_heff_2ecst_2ereadH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ereadH_lam1, 3, 0};

static V g_heff_2ecst_2ereadH_val;
static int g_heff_2ecst_2ereadH_st;
static V g_heff_2ecst_2ereadH_init(void) {
  return heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2ecst_2ereadH_lam0_clo), ((V)&g_heff_2ecst_2ereadH_lam1_clo), ((V)&g_heff_2ecst_2ereadSumAlg_clo)});
}
V g_heff_2ecst_2ereadH_get(void) {
  if (g_heff_2ecst_2ereadH_st == 2) return g_heff_2ecst_2ereadH_val;
  if (g_heff_2ecst_2ereadH_st == 1) heff_fail("defined by itself");
  g_heff_2ecst_2ereadH_st = 1;
  g_heff_2ecst_2ereadH_val = heff_tr(g_heff_2ecst_2ereadH_init());
  g_heff_2ecst_2ereadH_st = 2;
  return g_heff_2ecst_2ereadH_val;
}
V g_heff_2ecst_2ereadH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_st_241 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_240}), v_st_241});
}
V g_heff_2ecst_2ereadH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_st_244 = args[2];
  V v_x1_245 = heff_tr(heff_apply(v_m_242, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
Clo g_heff_2ecst_2eendBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eendBefore_entry, 2, 0};

V g_heff_2ecst_2eendBefore(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_j_241), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_j_241);
    return MK_INT(0LL);
  } else {
    V v_t_243 = heff_arrayLength(heff_get(heff_dup(v_s_240), LBL_toks));
    if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return MK_INT(0LL);
    } else {
      V v_t_245 = heff_arrayLength(heff_get(heff_dup(v_s_240), LBL_toks));
      if (heff_intLt_c(v_t_245, heff_dup(v_j_241))) {
        heff_drop(v_j_241);
        V v_t_247 = heff_arrayLength(heff_get(heff_dup(v_s_240), LBL_toks));
        V v_t_248 = heff_arrayIndex(heff_get(v_s_240, LBL_toks), heff_intSub(v_t_247, MK_INT(1LL)));
        return heff_get(v_t_248, LBL_end);
      } else {
        V v_t_249 = heff_arrayIndex(heff_get(v_s_240, LBL_toks), heff_intSub(v_j_241, MK_INT(1LL)));
        return heff_get(v_t_249, LBL_end);
      }
    }
  }
}
V g_heff_2ecst_2eendBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eendBefore(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatTok_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatTok_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatTok_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatTok_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatTok_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatTok_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatTok_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatTok_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2ecst_2eatTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatTok_entry, 3, 0};

V g_heff_2ecst_2eatTok(V v_s_240, V v_j_241, V v_t_242) {
top: ;
  if (heff_strEq_c(heff_get(heff_dup(v_t_242), LBL_kind), ((V)&g_heff_2ecst_2eatTok_str0))) {
    heff_drop(v_t_242);
    V v_e_244 = (g_heff_2ecst_2eendBefore(v_s_240, v_j_241));
    return heff_rec(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2ecst_2eatTok_str1), ((V)&g_heff_2ecst_2eatTok_str2), ((V)&g_heff_2ecst_2eatTok_str3), heff_dup(v_e_244), v_e_244, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  } else {
    if (heff_intLt_c(heff_get(heff_dup(v_s_240), LBL_top), heff_dup(v_j_241))) {
      V v_t_246 = heff_get(heff_dup(v_t_242), LBL_first);
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        if (heff_intEq_c(heff_get(heff_dup(v_t_242), LBL_col), MK_INT(0LL))) {
          if (heff_strEq_c(heff_get(heff_dup(v_t_242), LBL_kind), ((V)&g_heff_2ecst_2eatTok_str4))) {
            heff_drop(v_s_240);
            heff_drop(v_j_241);
            return v_t_242;
          } else {
            heff_drop(v_t_242);
            V v_e_249 = (g_heff_2ecst_2eendBefore(v_s_240, v_j_241));
            return heff_rec(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2ecst_2eatTok_str5), ((V)&g_heff_2ecst_2eatTok_str6), ((V)&g_heff_2ecst_2eatTok_str7), heff_dup(v_e_249), v_e_249, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_j_241);
          return v_t_242;
        }
      }
      case TAG_False: {
        heff_drop(v_s_240);
        heff_drop(v_j_241);
        return v_t_242;
      }
      default: return heff_nomatch(v_t_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return v_t_242;
    }
  }
}
V g_heff_2ecst_2eatTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eatTok(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2etokAt_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2etokAt_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2etokAt_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2etokAt_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2etokAt_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2etokAt_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2ecst_2etokAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2etokAt_entry, 2, 0};

V g_heff_2ecst_2etokAt(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_j_241), MK_INT(0LL))) {
    V v_e_243 = (g_heff_2ecst_2eendBefore(v_s_240, v_j_241));
    return heff_rec(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2ecst_2etokAt_str0), ((V)&g_heff_2ecst_2etokAt_str1), ((V)&g_heff_2ecst_2etokAt_str2), heff_dup(v_e_243), v_e_243, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  } else {
    V v_t_244 = heff_arrayLength(heff_get(heff_dup(v_s_240), LBL_toks));
    if (heff_intLe_c(v_t_244, heff_dup(v_j_241))) {
      V v_e_246 = (g_heff_2ecst_2eendBefore(v_s_240, v_j_241));
      return heff_rec(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2ecst_2etokAt_str3), ((V)&g_heff_2ecst_2etokAt_str4), ((V)&g_heff_2ecst_2etokAt_str5), heff_dup(v_e_246), v_e_246, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    } else {
      V v_t_247 = heff_arrayIndex(heff_get(heff_dup(v_s_240), LBL_toks), heff_dup(v_j_241));
      return (g_heff_2ecst_2eatTok(v_s_240, v_j_241, v_t_247));
    }
  }
}
V g_heff_2ecst_2etokAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2etokAt(a[0], a[1]);
}
Clo g_heff_2ecst_2ecur_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ecur_entry, 1, 0};

V g_heff_2ecst_2ecur(V v_s_240) {
top: ;
  return (g_heff_2ecst_2etokAt(heff_dup(v_s_240), heff_get(v_s_240, LBL_i)));
}
V g_heff_2ecst_2ecur_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2ecur(a[0]);
}
V g_heff_2ecst_2enext_lam1(V self, V *args); static Clo g_heff_2ecst_2enext_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2enext_lam1, 1, 0};
V g_heff_2ecst_2enext_lam3(V self, V *args);
V g_heff_2ecst_2enext_lam2(V self, V *args);
V g_heff_2ecst_2enext_lam0(V self, V *args);
Clo g_heff_2ecst_2enext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2enext_entry, 2, 0};

V g_heff_2ecst_2enext(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2enext_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2enext_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2enext(a[0], a[1]);
}
V g_heff_2ecst_2enext_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_get(heff_dup(v_s_245), LBL_i), MK_INT(1LL));
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_245), LBL_toks), v_t_246, heff_get(heff_dup(v_s_245), LBL_top), heff_get(heff_dup(v_s_245), LBL_stack), heff_get(v_s_245, LBL_start)});
}
V g_heff_2ecst_2enext_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_241;
  args[0] = v_x_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2enext_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecst_2enext_lam3, 1, 2, (V[]){v_k_241, v_x_244})});
}
V g_heff_2ecst_2enext_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2enext_lam1_clo)})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecst_2enext_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_244})});
}
V g_heff_2ecst_2enextN_lam1(V self, V *args);
V g_heff_2ecst_2enextN_lam0(V self, V *args);
Clo g_heff_2ecst_2enextN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2enextN_entry, 3, 0};

V g_heff_2ecst_2enextN(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  } else {
    return (g_heff_2ecst_2enext(heff_dup(v_p_241), heff_clo(g_heff_2ecst_2enextN_lam0, 1, 3, (V[]){v_n_240, v_p_241, v_p_242})));
  }
}
V g_heff_2ecst_2enextN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2enextN(a[0], a[1], a[2]);
}
V g_heff_2ecst_2enextN_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_242;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_244, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2enextN_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = heff_tr(heff_apply(((V)&g_heff_2ecst_2enextN_clo), 1, (V[]){heff_intSub(v_n_240, MK_INT(1LL))}));
  return heff_tail(v_c_245, 2, (V[]){v_p_241, heff_clo(g_heff_2ecst_2enextN_lam1, 1, 2, (V[]){v_p_242, v_x_244})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatBoundary_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
V g_heff_2ecst_2eatBoundary_lam0(V self, V *args); static Clo g_heff_2ecst_2eatBoundary_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatBoundary_lam0, 1, 0};
Clo g_heff_2ecst_2eatBoundary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatBoundary_entry, 2, 0};

V g_heff_2ecst_2eatBoundary(V v_hd_240, V v_k2_241) {
top: ;
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eatBoundary_lam0_clo)})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2417, v_k2_241});
}
V g_heff_2ecst_2eatBoundary_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eatBoundary(a[0], a[1]);
}
V g_heff_2ecst_2eatBoundary_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_t_243 = (g_heff_2ecst_2etokAt(heff_dup(v_s_242), heff_get(heff_dup(v_s_242), LBL_i)));
  if (heff_strEq_c(heff_get(v_t_243, LBL_kind), ((V)&g_heff_2ecst_2eatBoundary_str0))) {
    heff_drop(v_s_242);
    return NTAG(TAG_True);
  } else {
    V v_t_245 = (g_heff_2ecst_2etokAt(heff_dup(v_s_242), heff_get(heff_dup(v_s_242), LBL_i)));
    V v_t_246 = heff_get(v_t_245, LBL_first);
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = (g_heff_2ecst_2etokAt(heff_dup(v_s_242), heff_get(heff_dup(v_s_242), LBL_i)));
      V v_t_248 = heff_get(heff_dup(v_s_242), LBL_stack);
      V v_x2_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        v_x2_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 2);
        v_x2_2411 = heff_tag(TAG_Just, 1, (V[]){v_x_249});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        v_t_2413 = MK_INT(0LL);
        break;
      }
      case TAG_Just: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        heff_take_n(v_x2_2411, 1ULL, 1);
        v_t_2413 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      if (heff_intLe_c(heff_get(v_t_247, LBL_col), v_t_2413)) {
        if (heff_intEq_c(heff_get(heff_dup(v_s_242), LBL_i), heff_get(v_s_242, LBL_start))) {
          return NTAG(TAG_False);
        } else {
          return NTAG(TAG_True);
        }
      } else {
        heff_drop(v_s_242);
        return NTAG(TAG_False);
      }
    }
    case TAG_False: {
      heff_drop(v_s_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexpectAnn_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectAnn_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecst_2eexpectAnn_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96, 58, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecst_2eexpectAnn_str3 = {{0x80000000u, K_STR, 0}, 12, 12, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96, 58, 96}};
V g_heff_2ecst_2eexpectAnn_lam0(V self, V *args);
Clo g_heff_2ecst_2eexpectAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexpectAnn_entry, 2, 0};

V g_heff_2ecst_2eexpectAnn(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2eexpectAnn_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eexpectAnn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexpectAnn(a[0], a[1]);
}
V g_heff_2ecst_2eexpectAnn_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2eexpectAnn_str0))) {
    if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_text), ((V)&g_heff_2ecst_2eexpectAnn_str1))) {
      heff_drop(v_x_244);
      return (g_heff_2ecst_2enext(v_hd_240, v_k_241));
    } else {
      V v_t_247 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
      V v_t_248 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eexpectAnn_str2), v_t_247, NTAG(TAG_Nothing)});
      V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_249}));
      return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2410, v_k_241});
    }
  } else {
    V v_t_2411 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_2412 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eexpectAnn_str3), v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2414, v_k_241});
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexpectSym_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexpectSym_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eexpectSym_str2 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectSym_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectSym_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecst_2eexpectSym_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2eexpectSym_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {96, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eexpectSym_lam0(V self, V *args);
Clo g_heff_2ecst_2eexpectSym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexpectSym_entry, 3, 0};

V g_heff_2ecst_2eexpectSym(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2eexpectSym_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2ecst_2eexpectSym_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexpectSym(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eexpectSym_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eexpectSym_str0))) {
    v_t_247 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), heff_dup(v_x_240));
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_x_245);
    heff_drop(v_x_240);
    return (g_heff_2ecst_2enext(v_hd_241, v_k_242));
  }
  case TAG_False: {
    V v_t_249;
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eexpectSym_str1))) {
      v_t_249 = ((V)&g_heff_2ecst_2eexpectSym_str2);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2ecst_2eexpectSym_str3), heff_strAppend(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2eexpectSym_str4)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2ecst_2eexpectSym_str5), heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2ecst_2eexpectSym_str6), v_t_249)));
    V v_t_2411 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
    V v_d_2412 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eexpectPunct_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexpectPunct_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eexpectPunct_str2 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectPunct_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectPunct_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecst_2eexpectPunct_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2eexpectPunct_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {96, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eexpectPunct_lam0(V self, V *args);
Clo g_heff_2ecst_2eexpectPunct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexpectPunct_entry, 3, 0};

V g_heff_2ecst_2eexpectPunct(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2eexpectPunct_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2ecst_2eexpectPunct_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexpectPunct(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eexpectPunct_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eexpectPunct_str0))) {
    v_t_247 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), heff_dup(v_x_240));
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_x_245);
    heff_drop(v_x_240);
    return (g_heff_2ecst_2enext(v_hd_241, v_k_242));
  }
  case TAG_False: {
    V v_t_249;
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eexpectPunct_str1))) {
      v_t_249 = ((V)&g_heff_2ecst_2eexpectPunct_str2);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2ecst_2eexpectPunct_str3), heff_strAppend(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2eexpectPunct_str4)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2ecst_2eexpectPunct_str5), heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2ecst_2eexpectPunct_str6), v_t_249)));
    V v_t_2411 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
    V v_d_2412 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexpectKw_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexpectKw_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eexpectKw_str2 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectKw_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectKw_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecst_2eexpectKw_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {101, 120, 112, 101, 99, 116, 101, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2eexpectKw_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {96, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eexpectKw_lam0(V self, V *args);
Clo g_heff_2ecst_2eexpectKw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexpectKw_entry, 3, 0};

V g_heff_2ecst_2eexpectKw(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2eexpectKw_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2ecst_2eexpectKw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexpectKw(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eexpectKw_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eexpectKw_str0))) {
    v_t_247 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), heff_dup(v_x_240));
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_x_245);
    heff_drop(v_x_240);
    return (g_heff_2ecst_2enext(v_hd_241, v_k_242));
  }
  case TAG_False: {
    V v_t_249;
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eexpectKw_str1))) {
      v_t_249 = ((V)&g_heff_2ecst_2eexpectKw_str2);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2ecst_2eexpectKw_str3), heff_strAppend(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2eexpectKw_str4)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2ecst_2eexpectKw_str5), heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2ecst_2eexpectKw_str6), v_t_249)));
    V v_t_2411 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
    V v_d_2412 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexpectKind_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eexpectKind_str1 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectKind_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexpectKind_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecst_2eexpectKind_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eexpectKind_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eexpectKind_lam0(V self, V *args);
Clo g_heff_2ecst_2eexpectKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexpectKind_entry, 4, 0};

V g_heff_2ecst_2eexpectKind(V v_k_240, V v_what_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2eexpectKind_lam0, 1, 4, (V[]){v_k_240, v_hd_242, v_k_243, v_what_241})});
}
V g_heff_2ecst_2eexpectKind_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexpectKind(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2eexpectKind_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_what_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), v_k_240)) {
    heff_drop(v_x_246);
    heff_drop(v_what_241);
    return (g_heff_2ecst_2enext(v_hd_242, v_k_243));
  } else {
    V v_t_249;
    if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2eexpectKind_str0))) {
      v_t_249 = ((V)&g_heff_2ecst_2eexpectKind_str1);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2ecst_2eexpectKind_str2), heff_strAppend(heff_get(heff_dup(v_x_246), LBL_text), ((V)&g_heff_2ecst_2eexpectKind_str3)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2ecst_2eexpectKind_str4), heff_strAppend(v_what_241, heff_strAppend(((V)&g_heff_2ecst_2eexpectKind_str5), v_t_249)));
    V v_t_2411 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_246), LBL_start), heff_get(v_x_246, LBL_end)});
    V v_d_2412 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2414, v_k_243});
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2econtinuesBlock_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2econtinuesBlock_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2econtinuesBlock_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 104, 101, 114, 101}};
Clo g_heff_2ecst_2econtinuesBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2econtinuesBlock_entry, 2, 0};

V g_heff_2ecst_2econtinuesBlock(V v_t_240, V v_col_241) {
top: ;
  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2econtinuesBlock_str0))) {
    heff_drop(v_t_240);
    heff_drop(v_col_241);
    return NTAG(TAG_False);
  } else {
    V v_t_243 = heff_get(heff_dup(v_t_240), LBL_first);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      if (heff_intEq_c(heff_get(heff_dup(v_t_240), LBL_col), v_col_241)) {
        V v_x1_246;
        if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2econtinuesBlock_str1))) {
          v_x1_246 = heff_strEq(heff_get(v_t_240, LBL_text), ((V)&g_heff_2ecst_2econtinuesBlock_str2));
        } else {
          heff_drop(v_t_240);
          v_x1_246 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_x1_246)) {
        case TAG_True: {
          return NTAG(TAG_False);
        }
        case TAG_False: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x1_246);
        }
      } else {
        heff_drop(v_t_240);
        return NTAG(TAG_False);
      }
    }
    case TAG_False: {
      heff_drop(v_t_240);
      heff_drop(v_col_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
}
V g_heff_2ecst_2econtinuesBlock_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2econtinuesBlock(a[0], a[1]);
}
V g_heff_2ecst_2eblockGo_lam0(V self, V *args); static Clo g_heff_2ecst_2eblockGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblockGo_lam0, 1, 0};
V g_heff_2ecst_2eblockGo_lam4(V self, V *args);
V g_heff_2ecst_2eblockGo_lam3(V self, V *args);
V g_heff_2ecst_2eblockGo_lam2(V self, V *args);
V g_heff_2ecst_2eblockGo_lam1(V self, V *args);
Clo g_heff_2ecst_2eblockGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblockGo_entry, 5, 0};

V g_heff_2ecst_2eblockGo(V v_item_240, V v_col_241, V v_acc_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblockGo_lam0_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecst_2eblockGo_lam1, 1, 5, (V[]){v_hd_243, v_item_240, v_col_241, v_acc_242, v_k_244})});
}
V g_heff_2ecst_2eblockGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eblockGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecst_2eblockGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_245), LBL_toks), heff_get(heff_dup(v_s_245), LBL_i), heff_get(heff_dup(v_s_245), LBL_top), heff_get(heff_dup(v_s_245), LBL_stack), heff_get(v_s_245, LBL_i)});
}
V g_heff_2ecst_2eblockGo_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_col_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2ecst_2econtinuesBlock(v_x_2415, heff_dup(v_col_241)));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    return (g_heff_2ecst_2eblockGo(v_item_240, v_col_241, heff_tag(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242}), v_hd_243, v_k_244));
  }
  case TAG_False: {
    heff_drop(v_col_241);
    heff_drop(v_item_240);
    heff_drop(v_hd_243);
    V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242})));
    V f_ = v_k_244;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2ecst_2eblockGo_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecst_2eblockGo_lam4, 1, 6, (V[]){v_col_241, v_item_240, v_x_2412, v_acc_242, v_hd_243, v_k_244})});
}
V g_heff_2ecst_2eblockGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  return heff_tail(heff_dup(v_item_240), 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eblockGo_lam3, 1, 5, (V[]){v_hd_243, v_col_241, v_item_240, v_acc_242, v_k_244})});
}
V g_heff_2ecst_2eblockGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag(TAG_Put, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecst_2eblockGo_lam2, 1, 5, (V[]){v_item_240, v_hd_243, v_col_241, v_acc_242, v_k_244})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eblock_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecst_2eblock_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {97, 32, 98, 108, 111, 99, 107, 32, 105, 115, 32, 101, 109, 112, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2ecst_2eblock_str2 = {{0x80000000u, K_STR, 0}, 43, 43, {97, 32, 98, 108, 111, 99, 107, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 100, 101, 110, 116, 101, 100, 32, 112, 97, 115, 116, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 115, 32, 105, 110}};
V g_heff_2ecst_2eblock_lam1(V self, V *args); static Clo g_heff_2ecst_2eblock_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_lam1, 1, 0};
V g_heff_2ecst_2eblock_lam3(V self, V *args);
V g_heff_2ecst_2eblock_lam7(V self, V *args); static Clo g_heff_2ecst_2eblock_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_lam7, 1, 0};
V g_heff_2ecst_2eblock_lam9(V self, V *args);
V g_heff_2ecst_2eblock_lam8(V self, V *args);
V g_heff_2ecst_2eblock_lam6(V self, V *args);
V g_heff_2ecst_2eblock_lam5(V self, V *args);
V g_heff_2ecst_2eblock_lam4(V self, V *args);
V g_heff_2ecst_2eblock_lam2(V self, V *args);
V g_heff_2ecst_2eblock_lam0(V self, V *args);
Clo g_heff_2ecst_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_entry, 3, 0};

V g_heff_2ecst_2eblock(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2eblock_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_item_240})});
}
V g_heff_2ecst_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eblock(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eblock_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_t_2412 = heff_get(v_s_2411, LBL_stack);
  V v_x2_2415;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nil: {
    v_x2_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 2);
    v_x2_2415 = heff_tag(TAG_Just, 1, (V[]){v_x_2413});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    return v_x_2416;
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecst_2eblock_lam3(V self, V *args) {
  V v_s_2426 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_x_245, LBL_col), heff_get(heff_dup(v_s_2426), LBL_stack)});
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_2426), LBL_toks), heff_get(heff_dup(v_s_2426), LBL_i), heff_get(heff_dup(v_s_2426), LBL_top), v_t_2427, heff_get(v_s_2426, LBL_start)});
}
V g_heff_2ecst_2eblock_lam7(V self, V *args) {
  V v_s_2435 = args[0];
  V v_k_2436 = (g_list_2edrop(MK_INT(1LL), heff_get(heff_dup(v_s_2435), LBL_stack)));
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_2435), LBL_toks), heff_get(heff_dup(v_s_2435), LBL_i), heff_get(heff_dup(v_s_2435), LBL_top), v_k_2436, heff_get(v_s_2435, LBL_start)});
}
V g_heff_2ecst_2eblock_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2442);
  V f_ = v_k_242;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eblock_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2440 = heff_tag(TAG_Put, 2, (V[]){v_x_2439, NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2441, heff_clo(g_heff_2ecst_2eblock_lam9, 1, 2, (V[]){v_k_242, v_x_2434})});
}
V g_heff_2ecst_2eblock_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblock_lam7_clo)})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2437}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2438, heff_clo(g_heff_2ecst_2eblock_lam8, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2434})});
}
V g_heff_2ecst_2eblock_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2433);
  return (g_heff_2ecst_2eblockGo(v_item_240, heff_get(v_x_245, LBL_col), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eblock_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2ecst_2eblock_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag(TAG_Put, 2, (V[]){v_x_2430, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2432, heff_clo(g_heff_2ecst_2eblock_lam5, 1, 4, (V[]){v_item_240, v_x_245, v_hd_241, v_k_242})});
}
V g_heff_2ecst_2eblock_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2420 = heff_get(heff_dup(v_x_245), LBL_first);
  V v_t_2421;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    v_t_2421 = heff_intLe(heff_get(heff_dup(v_x_245), LBL_col), v_x_2419);
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2419);
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    heff_drop(v_item_240);
    V v_t_2422 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
    V v_t_2423 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eblock_str2), v_t_2422, NTAG(TAG_Nothing)});
    V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2425, v_k_242});
  }
  case TAG_False: {
    V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2ecst_2eblock_lam3, 1, 1, (V[]){heff_dup(v_x_245)})})});
    V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2428}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2429, heff_clo(g_heff_2ecst_2eblock_lam4, 1, 4, (V[]){v_hd_241, v_item_240, v_x_245, v_k_242})});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ecst_2eblock_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eblock_str0))) {
    heff_drop(v_item_240);
    V v_t_247 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
    V v_t_248 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eblock_str1), v_t_247, NTAG(TAG_Nothing)});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2410, v_k_242});
  } else {
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblock_lam1_clo)})});
    V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2417}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecst_2eblock_lam2, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_item_240})});
  }
}
V g_heff_2ecst_2einBrackets_lam0(V self, V *args); static Clo g_heff_2ecst_2einBrackets_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2einBrackets_lam0, 1, 0};
V g_heff_2ecst_2einBrackets_lam4(V self, V *args); static Clo g_heff_2ecst_2einBrackets_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2einBrackets_lam4, 1, 0};
V g_heff_2ecst_2einBrackets_lam6(V self, V *args);
V g_heff_2ecst_2einBrackets_lam5(V self, V *args);
V g_heff_2ecst_2einBrackets_lam3(V self, V *args);
V g_heff_2ecst_2einBrackets_lam2(V self, V *args);
V g_heff_2ecst_2einBrackets_lam1(V self, V *args);
Clo g_heff_2ecst_2einBrackets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2einBrackets_entry, 3, 0};

V g_heff_2ecst_2einBrackets(V v_p_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2einBrackets_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2einBrackets_lam1, 1, 3, (V[]){v_hd_241, v_p_240, v_k_242})});
}
V g_heff_2ecst_2einBrackets_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2einBrackets(a[0], a[1], a[2]);
}
V g_heff_2ecst_2einBrackets_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){MK_INT(-1LL), heff_get(heff_dup(v_s_243), LBL_stack)});
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_243), LBL_toks), heff_get(heff_dup(v_s_243), LBL_i), heff_get(heff_dup(v_s_243), LBL_top), v_t_244, heff_get(v_s_243, LBL_start)});
}
V g_heff_2ecst_2einBrackets_lam4(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2413 = (g_list_2edrop(MK_INT(1LL), heff_get(heff_dup(v_s_2412), LBL_stack)));
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_2412), LBL_toks), heff_get(heff_dup(v_s_2412), LBL_i), heff_get(heff_dup(v_s_2412), LBL_top), v_k_2413, heff_get(v_s_2412, LBL_start)});
}
V g_heff_2ecst_2einBrackets_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V f_ = v_k_242;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2einBrackets_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tag(TAG_Put, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecst_2einBrackets_lam6, 1, 2, (V[]){v_k_242, v_x_2411})});
}
V g_heff_2ecst_2einBrackets_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2einBrackets_lam4_clo)})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecst_2einBrackets_lam5, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411})});
}
V g_heff_2ecst_2einBrackets_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  return heff_tail(v_p_240, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2einBrackets_lam3, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecst_2einBrackets_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_p_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecst_2einBrackets_lam2, 1, 3, (V[]){v_p_240, v_hd_241, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estartsAtom_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estartsAtom_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estartsAtom_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estartsAtom_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2estartsAtom_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2estartsAtom_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2estartsAtom_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {100, 97, 116, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2estartsAtom_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2estartsAtom_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estartsAtom_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2estartsAtom_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str17 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2estartsAtom_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2estartsAtom_str19 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2estartsAtom_str20 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2estartsAtom_str21 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2estartsAtom_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2estartsAtom_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2estartsAtom_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2estartsAtom_str26 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2estartsAtom_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2estartsAtom_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2estartsAtom_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
V g_heff_2ecst_2estartsAtom_lam0(V self, V *args);
Clo g_heff_2ecst_2estartsAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2estartsAtom_entry, 1, 0};

V g_heff_2ecst_2estartsAtom(V v_t_240) {
top: ;
  V v_t_241 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_240), LBL_kind)}));
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str0), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str2), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str4), v_t_243})});
  V v_t_245 = ({ V a_0 = v_t_241; V a_1 = v_t_244; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_244, 2); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2estartsAtom_str5))) {
      V v_t_247 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_240), LBL_text)}));
      V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str6), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str8), v_t_248})});
      V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str10), v_t_249})});
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str11), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2estartsAtom_str12), v_t_2410})});
      V v_t_2412 = ({ V a_0 = v_t_247; V a_1 = v_t_2411; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2411, 2); r_; });
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_t_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_x3_2415 = ({ V a_0 = heff_clo(g_heff_2ecst_2estartsAtom_lam0, 1, 1, (V[]){heff_dup(v_t_240)}); V b_1 = heff_dup(g_heff_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x3_2415)) {
        case TAG_Nothing: {
          if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2estartsAtom_str22))) {
            if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2estartsAtom_str23))) {
              heff_drop(v_t_240);
              return NTAG(TAG_True);
            } else {
              if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2estartsAtom_str24))) {
                heff_drop(v_t_240);
                return NTAG(TAG_True);
              } else {
                return heff_strEq(heff_get(v_t_240, LBL_text), ((V)&g_heff_2ecst_2estartsAtom_str25));
              }
            }
          } else {
            heff_drop(v_t_240);
            return NTAG(TAG_False);
          }
        }
        case TAG_Just: {
          heff_take_n(v_x3_2415, 0ULL, 1);
          heff_drop(v_t_240);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x3_2415);
        }
      }
      default: return heff_nomatch(v_t_2412);
      }
    } else {
      if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2estartsAtom_str26))) {
        if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2estartsAtom_str27))) {
          heff_drop(v_t_240);
          return NTAG(TAG_True);
        } else {
          if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2estartsAtom_str28))) {
            heff_drop(v_t_240);
            return NTAG(TAG_True);
          } else {
            return heff_strEq(heff_get(v_t_240, LBL_text), ((V)&g_heff_2ecst_2estartsAtom_str29));
          }
        }
      } else {
        heff_drop(v_t_240);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecst_2estartsAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2estartsAtom(a[0]);
}
V g_heff_2ecst_2estartsAtom_lam0(V self, V *args) {
  V v_w_2413 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_w_2413)) {
  case TAG_I8: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str13);
    break;
  }
  case TAG_I16: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str14);
    break;
  }
  case TAG_I32: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str15);
    break;
  }
  case TAG_I64: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str16);
    break;
  }
  case TAG_U8: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str17);
    break;
  }
  case TAG_U16: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str18);
    break;
  }
  case TAG_U32: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str19);
    break;
  }
  case TAG_U64: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str20);
    break;
  }
  case TAG_F32: {
    v_t_2414 = ((V)&g_heff_2ecst_2estartsAtom_str21);
    break;
  }
  default: heff_nomatch(v_w_2413);
  }
  return heff_strEq(v_t_2414, heff_get(v_t_240, LBL_text));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2emanyGo_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2emanyGo_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2emanyGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
V g_heff_2ecst_2emanyGo_lam2(V self, V *args);
V g_heff_2ecst_2emanyGo_lam1(V self, V *args);
V g_heff_2ecst_2emanyGo_lam0(V self, V *args);
Clo g_heff_2ecst_2emanyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2emanyGo_entry, 4, 0};

V g_heff_2ecst_2emanyGo(V v_p_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2emanyGo_lam0, 1, 4, (V[]){v_hd_242, v_acc_241, v_k_243, v_p_240})));
}
V g_heff_2ecst_2emanyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2emanyGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2emanyGo_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2emanyGo(v_p_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2413, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2ecst_2emanyGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_244)) {
  case TAG_True: {
    heff_drop(v_x_247);
    heff_drop(v_p_240);
    heff_drop(v_hd_242);
    V v_x_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_249 = (g_heff_2ecst_2estartsAtom(heff_dup(v_x_247)));
    V v_x1_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_x_247);
      v_x1_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_kind), ((V)&g_heff_2ecst_2emanyGo_str0))) {
        heff_drop(v_x_247);
        v_x1_2412 = NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_kind), ((V)&g_heff_2ecst_2emanyGo_str1))) {
          v_x1_2412 = heff_strEq(heff_get(v_x_247, LBL_text), ((V)&g_heff_2ecst_2emanyGo_str2));
        } else {
          heff_drop(v_x_247);
          v_x1_2412 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_True: {
      return heff_tail(heff_dup(v_p_240), 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2emanyGo_lam2, 1, 4, (V[]){v_p_240, v_acc_241, v_hd_242, v_k_243})});
    }
    case TAG_False: {
      heff_drop(v_p_240);
      heff_drop(v_hd_242);
      V v_x_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      V f_ = v_k_243;
      args[0] = v_x_2414;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2ecst_2emanyGo_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2emanyGo_lam1, 1, 5, (V[]){v_x_244, v_acc_241, v_k_243, v_p_240, v_hd_242})});
}
V g_heff_2ecst_2esepGo_lam2(V self, V *args);
V g_heff_2ecst_2esepGo_lam1(V self, V *args);
V g_heff_2ecst_2esepGo_lam0(V self, V *args);
Clo g_heff_2ecst_2esepGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esepGo_entry, 6, 0};

V g_heff_2ecst_2esepGo(V v_sep_240, V v_p_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecst_2esepGo_lam0, 1, 6, (V[]){v_sep_240, v_hd_244, v_p_241, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2ecst_2esepGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2esepGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecst_2esepGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ecst_2esepGo(v_sep_240, v_p_241, heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_items_242}), heff_tag(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}), v_hd_244, v_k_245));
}
V g_heff_2ecst_2esepGo_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return heff_tail(heff_dup(v_p_241), 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2esepGo_lam2, 1, 7, (V[]){v_sep_240, v_p_241, v_items_242, v_x_2410, v_seps_243, v_hd_244, v_k_245})});
}
V g_heff_2ecst_2esepGo_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get(v_x_248, LBL_text), heff_dup(v_sep_240))) {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2esepGo_lam1, 1, 6, (V[]){v_p_241, v_hd_244, v_sep_240, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_240);
    heff_drop(v_hd_244);
    heff_drop(v_p_241);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_x_2413 = heff_tag(TAG_MkSep, 2, (V[]){v_t_2412, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243))});
    V f_ = v_k_245;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexprHead_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprHead_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eexprHead_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 97, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprHead_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprHead_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
Clo g_heff_2ecst_2eexprHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprHead_entry, 2, 0};

V g_heff_2ecst_2eexprHead(V v_g_240, V v_t_241) {
top: ;
  V v_t_243;
  if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eexprHead_str0))) {
    v_t_243 = heff_strEq(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_str1));
  } else {
    v_t_243 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_241);
    return heff_get(v_g_240, LBL_lambda);
  }
  case TAG_False: {
    V v_t_245;
    if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_str2))) {
      v_t_245 = heff_strEq(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eexprHead_str3));
    } else {
      v_t_245 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_241);
      return heff_get(v_g_240, LBL_caseE);
    }
    case TAG_False: {
      V v_t_247;
      if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_str4))) {
        v_t_247 = heff_strEq(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eexprHead_str5));
      } else {
        v_t_247 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_241);
        return heff_get(v_g_240, LBL_ifE);
      }
      case TAG_False: {
        if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_str6))) {
          if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eexprHead_str7))) {
            heff_drop(v_t_241);
            return heff_get(v_g_240, LBL_doE);
          } else {
            if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_str8))) {
              if (heff_strEq_c(heff_get(v_t_241, LBL_text), ((V)&g_heff_2ecst_2eexprHead_str9))) {
                return heff_get(v_g_240, LBL_letE);
              } else {
                return heff_tail(heff_get(v_g_240, LBL_opExpr), 1, (V[]){MK_INT(0LL)});
              }
            } else {
              heff_drop(v_t_241);
              return heff_tail(heff_get(v_g_240, LBL_opExpr), 1, (V[]){MK_INT(0LL)});
            }
          }
        } else {
          if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_str10))) {
            if (heff_strEq_c(heff_get(v_t_241, LBL_text), ((V)&g_heff_2ecst_2eexprHead_str11))) {
              return heff_get(v_g_240, LBL_letE);
            } else {
              return heff_tail(heff_get(v_g_240, LBL_opExpr), 1, (V[]){MK_INT(0LL)});
            }
          } else {
            heff_drop(v_t_241);
            return heff_tail(heff_get(v_g_240, LBL_opExpr), 1, (V[]){MK_INT(0LL)});
          }
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecst_2eexprHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexprHead(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexprF_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprF_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
V g_heff_2ecst_2eexprF_lam5(V self, V *args);
V g_heff_2ecst_2eexprF_lam4(V self, V *args);
V g_heff_2ecst_2eexprF_lam3(V self, V *args);
V g_heff_2ecst_2eexprF_lam2(V self, V *args);
V g_heff_2ecst_2eexprF_lam1(V self, V *args);
V g_heff_2ecst_2eexprF_lam0(V self, V *args);
Clo g_heff_2ecst_2eexprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprF_entry, 3, 0};

V g_heff_2ecst_2eexprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2eexprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2ecst_2eexprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexprF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eexprF_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_Ann, 3, (V[]){v_x_247, v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eexprF_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2eexprF_lam5, 1, 3, (V[]){v_k_242, v_x_247, v_x_2414})});
}
V g_heff_2ecst_2eexprF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(heff_dup(v_x_2410), LBL_text), ((V)&g_heff_2ecst_2eexprF_str0))) {
    if (heff_strEq_c(heff_get(v_x_2410, LBL_kind), ((V)&g_heff_2ecst_2eexprF_str1))) {
      switch (heff_tag_of(v_x_2411)) {
      case TAG_True: {
        heff_drop(v_hd_241);
        heff_drop(v_g_240);
        V f_ = v_k_242;
        args[0] = v_x_247;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eexprF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_247})));
      }
      default: return heff_nomatch(v_x_2411);
      }
    } else {
      heff_drop(v_x_2411);
      heff_drop(v_hd_241);
      heff_drop(v_g_240);
      V f_ = v_k_242;
      args[0] = v_x_247;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2411);
    heff_drop(v_x_2410);
    heff_drop(v_hd_241);
    heff_drop(v_g_240);
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecst_2eexprF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eexprF_lam3, 1, 5, (V[]){v_x_2410, v_k_242, v_x_247, v_hd_241, v_g_240})));
}
V g_heff_2ecst_2eexprF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecst_2eexprF_lam2, 1, 4, (V[]){v_hd_241, v_k_242, v_x_247, v_g_240})});
}
V g_heff_2ecst_2eexprF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = heff_tr(g_heff_2ecst_2eexprHead(heff_dup(v_g_240), v_x_245));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eexprF_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2earrowRhsF_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2earrowRhsF_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2earrowRhsF_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2earrowRhsF_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2earrowRhsF_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2earrowRhsF_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 97, 115, 101}};
V g_heff_2ecst_2earrowRhsF_lam0(V self, V *args);
Clo g_heff_2ecst_2earrowRhsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2earrowRhsF_entry, 3, 0};

V g_heff_2ecst_2earrowRhsF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2earrowRhsF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2ecst_2earrowRhsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2earrowRhsF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2earrowRhsF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2earrowRhsF_str0))) {
    heff_drop(v_x_245);
    return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, v_k_242});
  } else {
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2earrowRhsF_str1))) {
      V v_t_248 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_x_245, LBL_text)}));
      V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_str2), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_str4), v_t_249})});
      V v_t_2411 = ({ V a_0 = v_t_248; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_str5), v_t_2410}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, v_k_242});
      }
      case TAG_False: {
        return heff_tail(heff_get(v_g_240, LBL_opExpr), 3, (V[]){MK_INT(1LL), v_hd_241, v_k_242});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      heff_drop(v_x_245);
      return heff_tail(heff_get(v_g_240, LBL_opExpr), 3, (V[]){MK_INT(1LL), v_hd_241, v_k_242});
    }
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eopLoopF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
V g_heff_2ecst_2eopLoopF_lam3(V self, V *args);
V g_heff_2ecst_2eopLoopF_lam2(V self, V *args);
V g_heff_2ecst_2eopLoopF_lam1(V self, V *args);
V g_heff_2ecst_2eopLoopF_lam0(V self, V *args);
Clo g_heff_2ecst_2eopLoopF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eopLoopF_entry, 5, 0};

V g_heff_2ecst_2eopLoopF(V v_g_240, V v_minPrec_241, V v_lhs_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2eopLoopF_lam0, 1, 5, (V[]){v_hd_243, v_minPrec_241, v_g_240, v_lhs_242, v_k_244})});
}
V g_heff_2ecst_2eopLoopF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eopLoopF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecst_2eopLoopF_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_lhs_242 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecst_2eopLoopF(v_g_240, v_minPrec_241, heff_tag(TAG_Op, 3, (V[]){v_lhs_242, v_x_2421, v_x_2432}), v_hd_243, v_k_244));
}
V g_heff_2ecst_2eopLoopF_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_minPrec_241 = heff_env(self)[3];
  V v_lhs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_2422 = heff_get(heff_dup(v_x_247), LBL_text);
  V v_t_2425;
  if (heff_strEq_c(heff_dup(v_s_2422), ((V)&g_heff_2ecst_2eopLoopF_str5))) {
    heff_drop(v_s_2422);
    v_t_2425 = MK_INT(1LL);
  } else {
    if (heff_strEq_c(v_s_2422, ((V)&g_heff_2ecst_2eopLoopF_str6))) {
      v_t_2425 = MK_INT(2LL);
    } else {
      v_t_2425 = MK_INT(-1LL);
    }
  }
  V v_c_2431;
  if (heff_intEq_c(v_t_2425, MK_INT(1LL))) {
    heff_drop(v_x_247);
    v_c_2431 = heff_tr(heff_apply(((V)&g_heff_2ecst_2earrowRhsF_clo), 1, (V[]){heff_dup(v_g_240)}));
  } else {
    V v_s_2427 = heff_get(v_x_247, LBL_text);
    V v_t_2430;
    if (heff_strEq_c(heff_dup(v_s_2427), ((V)&g_heff_2ecst_2eopLoopF_str7))) {
      heff_drop(v_s_2427);
      v_t_2430 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2427, ((V)&g_heff_2ecst_2eopLoopF_str8))) {
        v_t_2430 = MK_INT(2LL);
      } else {
        v_t_2430 = MK_INT(-1LL);
      }
    }
    v_c_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_g_240), LBL_opExpr), 1, (V[]){v_t_2430}));
  }
  return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eopLoopF_lam3, 1, 6, (V[]){v_g_240, v_minPrec_241, v_lhs_242, v_x_2421, v_hd_243, v_k_244})});
}
V g_heff_2ecst_2eopLoopF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_lhs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420;
  if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_kind), ((V)&g_heff_2ecst_2eopLoopF_str0))) {
    V v_s_2410 = heff_get(heff_dup(v_x_247), LBL_text);
    V v_a_2413;
    if (heff_strEq_c(heff_dup(v_s_2410), ((V)&g_heff_2ecst_2eopLoopF_str1))) {
      heff_drop(v_s_2410);
      v_a_2413 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2410, ((V)&g_heff_2ecst_2eopLoopF_str2))) {
        v_a_2413 = MK_INT(2LL);
      } else {
        v_a_2413 = MK_INT(-1LL);
      }
    }
    if (heff_intLe_c(MK_INT(1LL), v_a_2413)) {
      V v_s_2415 = heff_get(heff_dup(v_x_247), LBL_text);
      V v_a_2418;
      if (heff_strEq_c(heff_dup(v_s_2415), ((V)&g_heff_2ecst_2eopLoopF_str3))) {
        heff_drop(v_s_2415);
        v_a_2418 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2415, ((V)&g_heff_2ecst_2eopLoopF_str4))) {
          v_a_2418 = MK_INT(2LL);
        } else {
          v_a_2418 = MK_INT(-1LL);
        }
      }
      if (heff_intLe_c(heff_dup(v_minPrec_241), v_a_2418)) {
        switch (heff_tag_of(v_x_248)) {
        case TAG_True: {
          v_t_2420 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2420 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_248);
        }
      } else {
        heff_drop(v_x_248);
        v_t_2420 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_248);
      v_t_2420 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_248);
    v_t_2420 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eopLoopF_lam2, 1, 6, (V[]){v_x_247, v_g_240, v_hd_243, v_minPrec_241, v_lhs_242, v_k_244})));
  }
  case TAG_False: {
    heff_drop(v_x_247);
    heff_drop(v_minPrec_241);
    heff_drop(v_hd_243);
    heff_drop(v_g_240);
    V f_ = v_k_244;
    args[0] = v_lhs_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ecst_2eopLoopF_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_lhs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eopLoopF_lam1, 1, 6, (V[]){v_x_247, v_minPrec_241, v_hd_243, v_g_240, v_lhs_242, v_k_244})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eoperandsF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eoperandsF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eoperandsF_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eoperandsF_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eoperandsF_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eoperandsF_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eoperandsF_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 97, 115, 101}};
V g_heff_2ecst_2eoperandsF_lam4(V self, V *args);
V g_heff_2ecst_2eoperandsF_lam5(V self, V *args);
V g_heff_2ecst_2eoperandsF_lam6(V self, V *args);
V g_heff_2ecst_2eoperandsF_lam7(V self, V *args);
V g_heff_2ecst_2eoperandsF_lam3(V self, V *args);
V g_heff_2ecst_2eoperandsF_lam2(V self, V *args);
V g_heff_2ecst_2eoperandsF_lam1(V self, V *args);
V g_heff_2ecst_2eoperandsF_lam0(V self, V *args);
Clo g_heff_2ecst_2eoperandsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eoperandsF_entry, 4, 0};

V g_heff_2ecst_2eoperandsF(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2eoperandsF_lam0, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})});
}
V g_heff_2ecst_2eoperandsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eoperandsF(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2eoperandsF_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2417}), v_acc_241});
  V v_x_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2418));
  V f_ = v_k_243;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eoperandsF_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2425}), v_acc_241});
  V v_x_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2426));
  V f_ = v_k_243;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eoperandsF_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2428}), v_acc_241});
  return (g_heff_2ecst_2eoperandsF(v_g_240, v_t_2429, v_hd_242, v_k_243));
}
V g_heff_2ecst_2eoperandsF_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2430}), v_acc_241});
  return (g_heff_2ecst_2eoperandsF(v_g_240, v_t_2431, v_hd_242, v_k_243));
}
V g_heff_2ecst_2eoperandsF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(heff_dup(v_x_2415), LBL_text), ((V)&g_heff_2ecst_2eoperandsF_str1))) {
    heff_drop(v_x_2415);
    return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_242, heff_clo(g_heff_2ecst_2eoperandsF_lam4, 1, 3, (V[]){v_x_2412, v_acc_241, v_k_243})});
  } else {
    if (heff_strEq_c(heff_get(heff_dup(v_x_2415), LBL_kind), ((V)&g_heff_2ecst_2eoperandsF_str2))) {
      V v_t_2421 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_x_2415, LBL_text)}));
      V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eoperandsF_str3), NTAG(TAG_Nil)});
      V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eoperandsF_str4), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eoperandsF_str5), v_t_2422})});
      V v_t_2424 = ({ V a_0 = v_t_2421; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eoperandsF_str6), v_t_2423}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_242, heff_clo(g_heff_2ecst_2eoperandsF_lam5, 1, 3, (V[]){v_x_2412, v_acc_241, v_k_243})});
      }
      case TAG_False: {
        return heff_tail(heff_get(heff_dup(v_g_240), LBL_app), 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eoperandsF_lam6, 1, 5, (V[]){v_x_2412, v_acc_241, v_g_240, v_hd_242, v_k_243})});
      }
      default: return heff_nomatch(v_t_2424);
      }
    } else {
      heff_drop(v_x_2415);
      return heff_tail(heff_get(heff_dup(v_g_240), LBL_app), 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eoperandsF_lam7, 1, 5, (V[]){v_x_2412, v_acc_241, v_g_240, v_hd_242, v_k_243})});
    }
  }
}
V g_heff_2ecst_2eoperandsF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecst_2eoperandsF_lam3, 1, 5, (V[]){v_g_240, v_hd_242, v_x_2412, v_acc_241, v_k_243})});
}
V g_heff_2ecst_2eoperandsF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411;
  if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2eoperandsF_str0))) {
    V v_t_249 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_x_246, LBL_text)}));
    V v_x1_2410 = ({ V a_0 = v_t_249; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_True: {
      heff_drop(v_x_247);
      v_t_2411 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_x_247)) {
      case TAG_True: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2411 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop(v_x_246);
    v_t_2411 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eoperandsF_lam2, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})));
  }
  case TAG_False: {
    heff_drop(v_hd_242);
    heff_drop(v_g_240);
    V v_x_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ecst_2eoperandsF_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eoperandsF_lam1, 1, 5, (V[]){v_x_246, v_hd_242, v_g_240, v_acc_241, v_k_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2efieldsGo_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 105, 101, 108, 100}};
V g_heff_2ecst_2efieldsGo_lam1(V self, V *args);
V g_heff_2ecst_2efieldsGo_lam0(V self, V *args);
Clo g_heff_2ecst_2efieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2efieldsGo_entry, 3, 0};

V g_heff_2ecst_2efieldsGo(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2efieldsGo_lam0, 1, 3, (V[]){v_hd_241, v_e_240, v_k_242})});
}
V g_heff_2ecst_2efieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2efieldsGo(a[0], a[1], a[2]);
}
V g_heff_2ecst_2efieldsGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2efieldsGo(heff_tag(TAG_EField, 2, (V[]){v_e_240, v_x_247}), v_hd_241, v_k_242));
}
V g_heff_2ecst_2efieldsGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get(v_x_245, LBL_kind), ((V)&g_heff_2ecst_2efieldsGo_str0))) {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2efieldsGo_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  } else {
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edefaultedF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edefaultedF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edefaultedF_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 61}};
V g_heff_2ecst_2edefaultedF_lam4(V self, V *args);
V g_heff_2ecst_2edefaultedF_lam3(V self, V *args);
V g_heff_2ecst_2edefaultedF_lam2(V self, V *args);
V g_heff_2ecst_2edefaultedF_lam1(V self, V *args);
V g_heff_2ecst_2edefaultedF_lam0(V self, V *args);
Clo g_heff_2ecst_2edefaultedF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edefaultedF_entry, 3, 0};

V g_heff_2ecst_2edefaultedF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_get(heff_dup(v_g_240), LBL_expr), 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2edefaultedF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2ecst_2edefaultedF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edefaultedF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2edefaultedF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_EFDefault, 3, (V[]){v_x_243, v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edefaultedF_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2edefaultedF_lam4, 1, 3, (V[]){v_k_242, v_x_243, v_x_2412})});
}
V g_heff_2ecst_2edefaultedF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2edefaultedF_str0))) {
    V v_t_2411;
    if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_text), ((V)&g_heff_2ecst_2edefaultedF_str1))) {
      heff_drop(v_x_246);
      switch (heff_tag_of(v_x_247)) {
      case TAG_True: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2411 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x_247);
      }
    } else {
      if (heff_strEq_c(heff_get(v_x_246, LBL_text), ((V)&g_heff_2ecst_2edefaultedF_str2))) {
        switch (heff_tag_of(v_x_247)) {
        case TAG_True: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_247);
        }
      } else {
        heff_drop(v_x_247);
        v_t_2411 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2edefaultedF_lam3, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})));
    }
    case TAG_False: {
      heff_drop(v_hd_241);
      heff_drop(v_g_240);
      V f_ = v_k_242;
      args[0] = v_x_243;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2411);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop(v_x_246);
    heff_drop(v_hd_241);
    heff_drop(v_g_240);
    V f_ = v_k_242;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecst_2edefaultedF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2edefaultedF_lam2, 1, 5, (V[]){v_x_246, v_hd_241, v_g_240, v_k_242, v_x_243})));
}
V g_heff_2ecst_2edefaultedF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2edefaultedF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2ebracesF_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2ecst_2ebracesF_lam3(V self, V *args); static Clo g_heff_2ecst_2ebracesF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ebracesF_lam3, 1, 0};
V g_heff_2ecst_2ebracesF_lam8(V self, V *args);
V g_heff_2ecst_2ebracesF_lam7(V self, V *args);
V g_heff_2ecst_2ebracesF_lam6(V self, V *args);
V g_heff_2ecst_2ebracesF_lam5(V self, V *args);
V g_heff_2ecst_2ebracesF_lam9(V self, V *args);
V g_heff_2ecst_2ebracesF_lam13(V self, V *args);
V g_heff_2ecst_2ebracesF_lam12(V self, V *args);
V g_heff_2ecst_2ebracesF_lam11(V self, V *args);
V g_heff_2ecst_2ebracesF_lam10(V self, V *args);
V g_heff_2ecst_2ebracesF_lam15(V self, V *args);
V g_heff_2ecst_2ebracesF_lam14(V self, V *args);
V g_heff_2ecst_2ebracesF_lam17(V self, V *args);
V g_heff_2ecst_2ebracesF_lam16(V self, V *args);
V g_heff_2ecst_2ebracesF_lam19(V self, V *args);
V g_heff_2ecst_2ebracesF_lam18(V self, V *args);
V g_heff_2ecst_2ebracesF_lam21(V self, V *args);
V g_heff_2ecst_2ebracesF_lam20(V self, V *args);
V g_heff_2ecst_2ebracesF_lam4(V self, V *args);
V g_heff_2ecst_2ebracesF_lam2(V self, V *args);
V g_heff_2ecst_2ebracesF_lam1(V self, V *args);
V g_heff_2ecst_2ebracesF_lam0(V self, V *args);
Clo g_heff_2ecst_2ebracesF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ebracesF_entry, 3, 0};

V g_heff_2ecst_2ebracesF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2ebracesF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2ebracesF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2ebracesF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2ebracesF_lam3(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_get(heff_dup(v_s_249), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2ecst_2ebracesF_lam8(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_InstB, 5, (V[]){v_x_243, v_x_2416, v_x_2417, v_x_2418, v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_str3), v_hd_244, heff_clo(g_heff_2ecst_2ebracesF_lam8, 1, 5, (V[]){v_k_245, v_x_243, v_x_2416, v_x_2417, v_x_2418})));
}
V g_heff_2ecst_2ebracesF_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_str2), heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2ebracesF_lam7, 1, 5, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2416, v_x_2417})));
}
V g_heff_2ecst_2ebracesF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2einBrackets(heff_get(v_g_240, LBL_expr), heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2ebracesF_lam6, 1, 4, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2416})));
}
V g_heff_2ecst_2ebracesF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tag(TAG_Braces, 4, (V[]){v_x_243, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2421});
  V f_ = v_k_245;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_lam13(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag(TAG_EFSet, 3, (V[]){v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_lam12(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_2424, heff_clo(g_heff_2ecst_2ebracesF_lam13, 1, 3, (V[]){v_k_2425, v_x_2426, v_x_2427})});
}
V g_heff_2ecst_2ebracesF_lam11(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2ebracesF_str6), heff_dup(v_hd_2424), heff_clo(g_heff_2ecst_2ebracesF_lam12, 1, 4, (V[]){v_g_240, v_hd_2424, v_k_2425, v_x_2426})));
}
V g_heff_2ecst_2ebracesF_lam10(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2424), heff_clo(g_heff_2ecst_2ebracesF_lam11, 1, 3, (V[]){v_hd_2424, v_g_240, v_k_2425})));
}
V g_heff_2ecst_2ebracesF_lam15(V self, V *args) {
  V v_x_2432 = args[0];
  V v_p_2429 = heff_env(self)[0];
  V v_hd_2430 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2ebracesF_str7), v_p_2429, v_t_2433, NTAG(TAG_Nil), v_hd_2430, v_k_2431));
}
V g_heff_2ecst_2ebracesF_lam14(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_p_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_p_2429);
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo(g_heff_2ecst_2ebracesF_lam15, 1, 3, (V[]){v_p_2429, v_hd_2430, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2ebracesF_lam17(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2439;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkSep: {
    V v_items_2437 = heff_field(v_x_2435, 0);
    V v_seps_2438 = heff_field(v_x_2435, 1);
    heff_take_n(v_x_2435, 3ULL, 2);
    v_x_2439 = heff_tag(TAG_Braces, 4, (V[]){v_x_243, v_items_2437, v_seps_2438, v_x_2436});
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_k_245;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_lam16(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_str8), v_hd_244, heff_clo(g_heff_2ecst_2ebracesF_lam17, 1, 3, (V[]){v_x_2435, v_x_243, v_k_245})));
}
V g_heff_2ecst_2ebracesF_lam19(V self, V *args) {
  V v_x_2443 = args[0];
  V v_p_2440 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_k_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){v_x_2443, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2ebracesF_str9), v_p_2440, v_t_2444, NTAG(TAG_Nil), v_hd_2441, v_k_2442));
}
V g_heff_2ecst_2ebracesF_lam18(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_p_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_p_2440);
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo(g_heff_2ecst_2ebracesF_lam19, 1, 3, (V[]){v_p_2440, v_hd_2441, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2ebracesF_lam21(V self, V *args) {
  V v_x_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2450;
  switch (heff_tag_of(v_x_2446)) {
  case TAG_MkSep: {
    V v_items_2448 = heff_field(v_x_2446, 0);
    V v_seps_2449 = heff_field(v_x_2446, 1);
    heff_take_n(v_x_2446, 3ULL, 2);
    v_x_2450 = heff_tag(TAG_Braces, 4, (V[]){v_x_243, v_items_2448, v_seps_2449, v_x_2447});
    break;
  }
  default: heff_nomatch(v_x_2446);
  }
  V f_ = v_k_245;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_lam20(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_str10), v_hd_244, heff_clo(g_heff_2ecst_2ebracesF_lam21, 1, 3, (V[]){v_x_2446, v_x_243, v_k_245})));
}
V g_heff_2ecst_2ebracesF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415;
  if (heff_strEq_c(heff_get(heff_dup(v_x_248), LBL_kind), ((V)&g_heff_2ecst_2ebracesF_str0))) {
    v_t_2415 = heff_strEq(heff_get(heff_dup(v_x_248), LBL_text), ((V)&g_heff_2ecst_2ebracesF_str1));
  } else {
    v_t_2415 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_x_2413);
    heff_drop(v_x_248);
    return (g_heff_2ecst_2enext(heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2ebracesF_lam5, 1, 4, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243})));
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get(v_x_248, LBL_text), ((V)&g_heff_2ecst_2ebracesF_str4))) {
      heff_drop(v_x_2413);
      heff_drop(v_g_240);
      return (g_heff_2ecst_2enext(v_hd_244, heff_clo(g_heff_2ecst_2ebracesF_lam9, 1, 2, (V[]){v_x_243, v_k_245})));
    } else {
      if (heff_strEq_c(heff_get(v_x_2413, LBL_text), ((V)&g_heff_2ecst_2ebracesF_str5))) {
        V v_p_2429 = heff_clo(g_heff_2ecst_2ebracesF_lam10, 2, 1, (V[]){v_g_240});
        V v_c_2434 = heff_clo(g_heff_2ecst_2ebracesF_lam14, 2, 1, (V[]){v_p_2429});
        return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2ebracesF_lam16, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})});
      } else {
        V v_p_2440 = heff_tr(heff_apply(((V)&g_heff_2ecst_2edefaultedF_clo), 1, (V[]){v_g_240}));
        V v_c_2445 = heff_clo(g_heff_2ecst_2ebracesF_lam18, 2, 1, (V[]){v_p_2440});
        return heff_tail(v_c_2445, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2ebracesF_lam20, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})});
      }
    }
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecst_2ebracesF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ebracesF_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecst_2ebracesF_lam4, 1, 5, (V[]){v_x_248, v_hd_244, v_g_240, v_k_245, v_x_243})});
}
V g_heff_2ecst_2ebracesF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_247;
  args[1] = heff_clo(g_heff_2ecst_2ebracesF_lam2, 1, 4, (V[]){v_hd_244, v_g_240, v_k_245, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2ebracesF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2ebracesF_lam1, 2, 2, (V[]){v_g_240, v_x_243}), v_hd_241, v_k_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eanonymousSumF_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eanonymousSumF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eanonymousSumF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2ecst_2eanonymousSumF_lam4(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam3(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam2(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam6(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam5(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam9(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam8(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam7(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam1(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_lam0(V self, V *args);
Clo g_heff_2ecst_2eanonymousSumF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eanonymousSumF_entry, 3, 0};

V g_heff_2ecst_2eanonymousSumF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eanonymousSumF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2ecst_2eanonymousSumF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eanonymousSumF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eanonymousSumF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag(TAG_ECon, 2, (V[]){v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eanonymousSumF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyGo(heff_get(v_g_240, LBL_atom), NTAG(TAG_Nil), v_hd_245, heff_clo(g_heff_2ecst_2eanonymousSumF_lam4, 1, 2, (V[]){v_k_246, v_x_247})));
}
V g_heff_2ecst_2eanonymousSumF_lam2(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_245), heff_clo(g_heff_2ecst_2eanonymousSumF_lam3, 1, 3, (V[]){v_g_240, v_hd_245, v_k_246})));
}
V g_heff_2ecst_2eanonymousSumF_lam6(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_249 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_x_2412, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2eanonymousSumF_str1), v_p_249, v_t_2413, NTAG(TAG_Nil), v_hd_2410, v_k_2411));
}
V g_heff_2ecst_2eanonymousSumF_lam5(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_p_249);
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2ecst_2eanonymousSumF_lam6, 1, 3, (V[]){v_p_249, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eanonymousSumF_lam9(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2421;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_MkSep: {
    V v_items_2419 = heff_field(v_x_2417, 0);
    V v_seps_2420 = heff_field(v_x_2417, 1);
    heff_take_n(v_x_2417, 3ULL, 2);
    v_x_2421 = heff_tag(TAG_Sum, 5, (V[]){v_x_243, v_x_244, v_items_2419, v_seps_2420, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_k_2416;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eanonymousSumF_lam8(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eanonymousSumF_str2), v_hd_2415, heff_clo(g_heff_2ecst_2eanonymousSumF_lam9, 1, 4, (V[]){v_x_2417, v_x_243, v_x_244, v_k_2416})));
}
V g_heff_2ecst_2eanonymousSumF_lam7(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2ecst_2eanonymousSumF_lam8, 1, 4, (V[]){v_hd_2415, v_x_243, v_x_244, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eanonymousSumF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_249 = heff_clo(g_heff_2ecst_2eanonymousSumF_lam2, 2, 1, (V[]){v_g_240});
  V v_c_2414 = heff_clo(g_heff_2ecst_2eanonymousSumF_lam5, 2, 1, (V[]){v_p_249});
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2eanonymousSumF_lam7, 2, 3, (V[]){v_c_2414, v_x_243, v_x_244}), v_hd_241, v_k_242));
}
V g_heff_2ecst_2eanonymousSumF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eanonymousSumF_str0), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eanonymousSumF_lam1, 1, 4, (V[]){v_g_240, v_x_243, v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eparensF_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eparensF_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2ecst_2eparensF_lam3(V self, V *args); static Clo g_heff_2ecst_2eparensF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eparensF_lam3, 1, 0};
V g_heff_2ecst_2eparensF_lam6(V self, V *args);
V g_heff_2ecst_2eparensF_lam5(V self, V *args);
V g_heff_2ecst_2eparensF_lam10(V self, V *args);
V g_heff_2ecst_2eparensF_lam9(V self, V *args);
V g_heff_2ecst_2eparensF_lam8(V self, V *args);
V g_heff_2ecst_2eparensF_lam7(V self, V *args);
V g_heff_2ecst_2eparensF_lam14(V self, V *args);
V g_heff_2ecst_2eparensF_lam13(V self, V *args);
V g_heff_2ecst_2eparensF_lam15(V self, V *args);
V g_heff_2ecst_2eparensF_lam12(V self, V *args);
V g_heff_2ecst_2eparensF_lam11(V self, V *args);
V g_heff_2ecst_2eparensF_lam4(V self, V *args);
V g_heff_2ecst_2eparensF_lam2(V self, V *args);
V g_heff_2ecst_2eparensF_lam1(V self, V *args);
V g_heff_2ecst_2eparensF_lam0(V self, V *args);
Clo g_heff_2ecst_2eparensF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eparensF_entry, 3, 0};

V g_heff_2ecst_2eparensF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eparensF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2eparensF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eparensF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eparensF_lam3(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_get(heff_dup(v_s_249), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2ecst_2eparensF_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag(TAG_EParen, 3, (V[]){v_x_243, heff_tag(TAG_Atom, 1, (V[]){v_x_2418}), v_x_2419});
  V f_ = v_k_245;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2enext(v_hd_244, heff_clo(g_heff_2ecst_2eparensF_lam6, 1, 3, (V[]){v_x_243, v_x_2418, v_k_245})));
}
V g_heff_2ecst_2eparensF_lam10(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_x_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_Named, 5, (V[]){v_x_243, v_x_2426, v_x_2427, v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_lam9(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eparensF_str8), v_hd_244, heff_clo(g_heff_2ecst_2eparensF_lam10, 1, 5, (V[]){v_k_245, v_x_243, v_x_2426, v_x_2427, v_x_2428})));
}
V g_heff_2ecst_2eparensF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2eparensF_lam9, 1, 5, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2426, v_x_2427})});
}
V g_heff_2ecst_2eparensF_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2eparensF_lam8, 1, 5, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243, v_x_2426})));
}
V g_heff_2ecst_2eparensF_lam14(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2440;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkSep: {
    V v_items_2438 = heff_field(v_x_2436, 0);
    V v_seps_2439 = heff_field(v_x_2436, 1);
    heff_take_n(v_x_2436, 3ULL, 2);
    v_x_2440 = heff_tag(TAG_Tup, 4, (V[]){v_x_243, v_items_2438, v_seps_2439, v_x_2437});
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V f_ = v_k_245;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_lam13(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eparensF_str11), v_hd_244, heff_clo(g_heff_2ecst_2eparensF_lam14, 1, 3, (V[]){v_x_2436, v_x_243, v_k_245})));
}
V g_heff_2ecst_2eparensF_lam15(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_EParen, 3, (V[]){v_x_243, v_x_2430, v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_lam12(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(v_x_2433, LBL_text), ((V)&g_heff_2ecst_2eparensF_str9))) {
    V v_t_2435 = heff_tag(TAG_Cons, 2, (V[]){v_x_2430, NTAG(TAG_Nil)});
    return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2eparensF_str10), heff_get(v_g_240, LBL_expr), v_t_2435, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2eparensF_lam13, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  } else {
    heff_drop(v_g_240);
    return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eparensF_str12), v_hd_244, heff_clo(g_heff_2ecst_2eparensF_lam15, 1, 3, (V[]){v_k_245, v_x_243, v_x_2430})));
  }
}
V g_heff_2ecst_2eparensF_lam11(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2431}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2432, heff_clo(g_heff_2ecst_2eparensF_lam12, 1, 5, (V[]){v_x_2430, v_g_240, v_hd_244, v_x_243, v_k_245})});
}
V g_heff_2ecst_2eparensF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417;
  if (heff_strEq_c(heff_get(heff_dup(v_x_248), LBL_kind), ((V)&g_heff_2ecst_2eparensF_str0))) {
    V v_t_2415 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_x_248), LBL_text)}));
    V v_x1_2416 = ({ V a_0 = v_t_2415; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_True: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2417 = heff_strEq(heff_get(heff_dup(v_x_2413), LBL_text), ((V)&g_heff_2ecst_2eparensF_str1));
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
  } else {
    v_t_2417 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop(v_x_2413);
    heff_drop(v_x_248);
    heff_drop(v_g_240);
    return (g_heff_2ecst_2enext(heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2eparensF_lam5, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  }
  case TAG_False: {
    V v_t_2425;
    if (heff_strEq_c(heff_get(heff_dup(v_x_248), LBL_kind), ((V)&g_heff_2ecst_2eparensF_str2))) {
      heff_drop(v_x_248);
      if (heff_strEq_c(heff_get(heff_dup(v_x_2413), LBL_kind), ((V)&g_heff_2ecst_2eparensF_str3))) {
        v_t_2425 = heff_strEq(heff_get(v_x_2413, LBL_text), ((V)&g_heff_2ecst_2eparensF_str4));
      } else {
        heff_drop(v_x_2413);
        v_t_2425 = NTAG(TAG_False);
      }
    } else {
      if (heff_strEq_c(heff_get(v_x_248, LBL_kind), ((V)&g_heff_2ecst_2eparensF_str5))) {
        if (heff_strEq_c(heff_get(heff_dup(v_x_2413), LBL_kind), ((V)&g_heff_2ecst_2eparensF_str6))) {
          v_t_2425 = heff_strEq(heff_get(v_x_2413, LBL_text), ((V)&g_heff_2ecst_2eparensF_str7));
        } else {
          heff_drop(v_x_2413);
          v_t_2425 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_x_2413);
        v_t_2425 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      return (g_heff_2ecst_2enext(heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2eparensF_lam7, 1, 4, (V[]){v_hd_244, v_g_240, v_k_245, v_x_243})));
    }
    case TAG_False: {
      return heff_tail(heff_get(heff_dup(v_g_240), LBL_expr), 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2eparensF_lam11, 1, 4, (V[]){v_hd_244, v_g_240, v_x_243, v_k_245})});
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2ecst_2eparensF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eparensF_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecst_2eparensF_lam4, 1, 5, (V[]){v_x_248, v_hd_244, v_x_243, v_k_245, v_g_240})});
}
V g_heff_2ecst_2eparensF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_247;
  args[1] = heff_clo(g_heff_2ecst_2eparensF_lam2, 1, 4, (V[]){v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eparensF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2eparensF_lam1, 2, 2, (V[]){v_x_243, v_g_240}), v_hd_241, v_k_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elistOfF_24s1130792037x937330368_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elistOfF_24s1130792037x937330368_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elistOfF_24s1130792037x937330368_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam3(V self, V *args); static Clo g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam3, 2, 0};
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam5(V self, V *args);
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam4(V self, V *args);
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam7(V self, V *args);
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam6(V self, V *args);
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam2(V self, V *args);
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam1(V self, V *args);
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam0(V self, V *args);
Clo g_heff_2ecst_2elistOfF_24s1130792037x937330368_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elistOfF_24s1130792037x937330368_entry, 3, 0};

V g_heff_2ecst_2elistOfF_24s1130792037x937330368(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elistOfF_24s1130792037x937330368(a[0], a[1], a[2]);
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam3(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_tag(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_2411;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2elistOfF_24s1130792037x937330368_str1), v_item_240, v_t_2416, NTAG(TAG_Nil), v_hd_2413, v_k_2414));
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_item_240);
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam5, 1, 3, (V[]){v_item_240, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkSep: {
    V v_items_2420 = heff_field(v_x_2418, 0);
    V v_seps_2421 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    v_x_2422 = heff_tag(TAG_Tup, 4, (V[]){v_x_243, v_items_2420, v_seps_2421, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_245;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2elistOfF_24s1130792037x937330368_str2), v_hd_244, heff_clo(g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam7, 1, 3, (V[]){v_x_2418, v_x_243, v_k_245})));
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2417;
  if (heff_strEq_c(heff_get(v_x_248, LBL_text), ((V)&g_heff_2ecst_2elistOfF_24s1130792037x937330368_str0))) {
    heff_drop(v_item_240);
    v_c_2417 = ((V)&g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam3_clo);
  } else {
    v_c_2417 = heff_clo(g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam4, 2, 1, (V[]){v_item_240});
  }
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})});
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_item_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_247;
  args[1] = heff_clo(g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam2, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2elistOfF_24s1130792037x937330368_lam1, 2, 2, (V[]){v_item_240, v_x_243}), v_hd_241, v_k_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eatomBase_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2eatomBase_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_str7 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eatomBase_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eatomBase_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_str19 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2eatomBase_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eatomBase_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eatomBase_str22 = {{0x80000000u, K_STR, 0}, 4, 4, {100, 97, 116, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str25 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_str27 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_str29 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eatomBase_str30 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2ecst_2eatomBase_str33 = {{0x80000000u, K_STR, 0}, 28, 28, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eatomBase_lam0(V self, V *args);
V g_heff_2ecst_2eatomBase_lam2(V self, V *args);
V g_heff_2ecst_2eatomBase_lam1(V self, V *args); static Clo g_heff_2ecst_2eatomBase_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatomBase_lam1, 2, 0};
V g_heff_2ecst_2eatomBase_lam3(V self, V *args);
Clo g_heff_2ecst_2eatomBase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatomBase_entry, 2, 0};

V g_heff_2ecst_2eatomBase(V v_g_240, V v_t_241) {
top: ;
  V v_t_242 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_241), LBL_kind)}));
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str2), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str4), v_t_244})});
  V v_t_246 = ({ V a_0 = v_t_242; V a_1 = v_t_245; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_245, 2); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_2417 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_str5))) {
      V v_t_248 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_241), LBL_text)}));
      V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str6), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str8), v_t_249})});
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str10), v_t_2410})});
      V v_t_2412 = ({ V a_0 = v_t_248; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_str11), v_t_2411}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        v_t_2417 = NTAG(TAG_True);
        break;
      }
      case TAG_False: {
        V v_x3_2415 = ({ V a_0 = heff_clo(g_heff_2ecst_2eatomBase_lam0, 1, 1, (V[]){heff_dup(v_t_241)}); V b_1 = heff_dup(g_heff_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x3_2415)) {
        case TAG_Nothing: {
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2415, 0ULL, 1);
          v_t_2417 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_2415);
        }
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
    } else {
      v_t_2417 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecst_2eatomBase_lam1_clo);
  }
  case TAG_False: {
    V v_t_2422;
    if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_str21))) {
      v_t_2422 = heff_strEq(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eatomBase_str22));
    } else {
      v_t_2422 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_t_241);
      return heff_tail(((V)&g_heff_2ecst_2eanonymousSumF_clo), 1, (V[]){v_g_240});
    }
    case TAG_False: {
      V v_t_2424;
      if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_str23))) {
        v_t_2424 = heff_strEq(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eatomBase_str24));
      } else {
        v_t_2424 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop(v_t_241);
        return heff_tail(((V)&g_heff_2ecst_2eparensF_clo), 1, (V[]){v_g_240});
      }
      case TAG_False: {
        V v_t_2426;
        if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_str25))) {
          v_t_2426 = heff_strEq(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eatomBase_str26));
        } else {
          v_t_2426 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2426)) {
        case TAG_True: {
          heff_drop(v_t_241);
          return heff_tail(((V)&g_heff_2ecst_2ebracesF_clo), 1, (V[]){v_g_240});
        }
        case TAG_False: {
          V v_t_2428;
          if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_str27))) {
            v_t_2428 = heff_strEq(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eatomBase_str28));
          } else {
            v_t_2428 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2428)) {
          case TAG_True: {
            heff_drop(v_t_241);
            return heff_tail(((V)&g_heff_2ecst_2elistOfF_24s1130792037x937330368_clo), 1, (V[]){heff_get(v_g_240, LBL_expr)});
          }
          case TAG_False: {
            heff_drop(v_g_240);
            V v_t_2430;
            if (heff_strEq_c(heff_get(heff_dup(v_t_241), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_str29))) {
              v_t_2430 = ((V)&g_heff_2ecst_2eatomBase_str30);
            } else {
              v_t_2430 = heff_strAppend(((V)&g_heff_2ecst_2eatomBase_str31), heff_strAppend(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2eatomBase_str32)));
            }
            V v_msg_2431 = heff_strAppend(((V)&g_heff_2ecst_2eatomBase_str33), v_t_2430);
            V v_t_2432 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_t_241), LBL_start), heff_get(v_t_241, LBL_end)});
            V v_d_2433 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2431, v_t_2432, NTAG(TAG_Nothing)});
            return heff_clo(g_heff_2ecst_2eatomBase_lam3, 2, 1, (V[]){v_d_2433});
          }
          default: return heff_nomatch(v_t_2428);
          }
        }
        default: return heff_nomatch(v_t_2426);
        }
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2ecst_2eatomBase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eatomBase(a[0], a[1]);
}
V g_heff_2ecst_2eatomBase_lam0(V self, V *args) {
  V v_w_2413 = args[0];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_w_2413)) {
  case TAG_I8: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str12);
    break;
  }
  case TAG_I16: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str13);
    break;
  }
  case TAG_I32: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str14);
    break;
  }
  case TAG_I64: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str15);
    break;
  }
  case TAG_U8: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str16);
    break;
  }
  case TAG_U16: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str17);
    break;
  }
  case TAG_U32: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str18);
    break;
  }
  case TAG_U64: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str19);
    break;
  }
  case TAG_F32: {
    v_t_2414 = ((V)&g_heff_2ecst_2eatomBase_str20);
    break;
  }
  default: heff_nomatch(v_w_2413);
  }
  return heff_strEq(v_t_2414, heff_get(v_t_241, LBL_text));
}
V g_heff_2ecst_2eatomBase_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2419;
  args[0] = heff_tag(TAG_Atom, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eatomBase_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  return (g_heff_2ecst_2enext(v_hd_2418, heff_clo(g_heff_2ecst_2eatomBase_lam2, 1, 1, (V[]){v_k_2419})));
}
V g_heff_2ecst_2eatomBase_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_d_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2433})});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2436}));
  V f_ = heff_get(v_hd_2434, LBL_bind);
  args[0] = v_t_2437;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eatomF_str1 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2ecst_2eatomF_str4 = {{0x80000000u, K_STR, 0}, 28, 28, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eatomF_lam2(V self, V *args);
V g_heff_2ecst_2eatomF_lam1(V self, V *args);
V g_heff_2ecst_2eatomF_lam0(V self, V *args);
Clo g_heff_2ecst_2eatomF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatomF_entry, 3, 0};

V g_heff_2ecst_2eatomF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2eatomF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2ecst_2eatomF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eatomF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eatomF_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2efieldsGo(v_x_2417, v_hd_241, v_k_242));
}
V g_heff_2ecst_2eatomF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_246)) {
  case TAG_True: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_x1_247 = (g_heff_2ecst_2estartsAtom(heff_dup(v_x_245)));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_g_240);
    V v_t_2410;
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2eatomF_str0))) {
      v_t_2410 = ((V)&g_heff_2ecst_2eatomF_str1);
    } else {
      v_t_2410 = heff_strAppend(((V)&g_heff_2ecst_2eatomF_str2), heff_strAppend(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2eatomF_str3)));
    }
    V v_msg_2411 = heff_strAppend(((V)&g_heff_2ecst_2eatomF_str4), v_t_2410);
    V v_t_2412 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
    V v_d_2413 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2411, v_t_2412, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2415, v_k_242});
  }
  case TAG_False: {
    V v_c_2416 = heff_tr(g_heff_2ecst_2eatomBase(v_g_240, v_x_245));
    return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eatomF_lam2, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecst_2eatomF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eatomF_lam1, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_g_240})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinderF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinderF_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2elamBinderF_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elamBinderF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinderF_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinderF_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elamBinderF_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2ecst_2elamBinderF_str7 = {{0x80000000u, K_STR, 0}, 36, 36, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 39, 115, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2elamBinderF_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elamBinderF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinderF_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinderF_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2ecst_2elamBinderF_str12 = {{0x80000000u, K_STR, 0}, 41, 41, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 98, 105, 110, 100, 101, 114, 39, 115, 32, 110, 97, 109, 101, 58, 32, 96, 92, 40, 120, 32, 58, 32, 84, 41, 32, 45, 62, 32, 101, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elamBinderF_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2ecst_2elamBinderF_str14 = {{0x80000000u, K_STR, 0}, 50, 50, {97, 32, 108, 97, 109, 98, 100, 97, 32, 98, 105, 110, 100, 115, 32, 110, 97, 109, 101, 115, 58, 32, 96, 92, 120, 32, 121, 32, 45, 62, 32, 101, 96, 44, 32, 96, 92, 40, 120, 32, 58, 32, 84, 41, 32, 45, 62, 32, 101, 96}};
V g_heff_2ecst_2elamBinderF_lam1(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam5(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam4(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam3(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam2(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam12(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam11(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam10(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam9(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam8(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam7(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam6(V self, V *args);
V g_heff_2ecst_2elamBinderF_lam0(V self, V *args);
Clo g_heff_2ecst_2elamBinderF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elamBinderF_entry, 3, 0};

V g_heff_2ecst_2elamBinderF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2elamBinderF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2ecst_2elamBinderF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elamBinderF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2elamBinderF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_BVar, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elamBinderF_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_BImp, 3, (V[]){v_x_2411, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elamBinderF_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2elamBinderF_str6), v_hd_241, heff_clo(g_heff_2ecst_2elamBinderF_lam5, 1, 3, (V[]){v_k_242, v_x_2411, v_x_2417})));
}
V g_heff_2ecst_2elamBinderF_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2416;
  if (heff_strEq_c(heff_get(heff_dup(v_x_2414), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str4))) {
    v_x1_2416 = NTAG(TAG_True);
  } else {
    v_x1_2416 = heff_strEq(heff_get(heff_dup(v_x_2414), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str5));
  }
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_True: {
    heff_drop(v_x_2414);
    return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elamBinderF_lam4, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411})));
  }
  case TAG_False: {
    heff_drop(v_x_2411);
    V v_t_2419 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_2414), LBL_start), heff_get(v_x_2414, LBL_end)});
    V v_t_2420 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2elamBinderF_str7), v_t_2419, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2422, v_k_242});
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2ecst_2elamBinderF_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecst_2elamBinderF_lam3, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411})});
}
V g_heff_2ecst_2elamBinderF_lam12(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2427 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_x_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2427;
  args[0] = heff_tag(TAG_BAnn, 5, (V[]){v_x_2425, v_x_2438, v_x_2439, v_x_2440, v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elamBinderF_lam11(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2elamBinderF_str13), v_hd_2426, heff_clo(g_heff_2ecst_2elamBinderF_lam12, 1, 5, (V[]){v_k_2427, v_x_2425, v_x_2438, v_x_2439, v_x_2440})));
}
V g_heff_2ecst_2elamBinderF_lam10(V self, V *args) {
  V v_x_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){heff_dup(v_hd_2426), heff_clo(g_heff_2ecst_2elamBinderF_lam11, 1, 5, (V[]){v_hd_2426, v_k_2427, v_x_2425, v_x_2438, v_x_2439})});
}
V g_heff_2ecst_2elamBinderF_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectAnn(heff_dup(v_hd_2426), heff_clo(g_heff_2ecst_2elamBinderF_lam10, 1, 5, (V[]){v_g_240, v_hd_2426, v_k_2427, v_x_2425, v_x_2438})));
}
V g_heff_2ecst_2elamBinderF_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2432;
  if (heff_strEq_c(heff_get(heff_dup(v_x_2430), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str10))) {
    v_x1_2432 = NTAG(TAG_True);
  } else {
    v_x1_2432 = heff_strEq(heff_get(heff_dup(v_x_2430), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str11));
  }
  V v_t_2433;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_True: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_x_2425);
    V v_t_2434 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_2430), LBL_start), heff_get(v_x_2430, LBL_end)});
    V v_t_2435 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2elamBinderF_str12), v_t_2434, NTAG(TAG_Nothing)});
    V v_t_2436 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2426), LBL_malg), 1, (V[]){v_t_2436}));
    return heff_tail(heff_get(v_hd_2426, LBL_bind), 2, (V[]){v_t_2437, v_k_2427});
  }
  case TAG_False: {
    heff_drop(v_x_2430);
    return (g_heff_2ecst_2enext(heff_dup(v_hd_2426), heff_clo(g_heff_2ecst_2elamBinderF_lam9, 1, 4, (V[]){v_hd_2426, v_g_240, v_k_2427, v_x_2425})));
  }
  default: return heff_nomatch(v_t_2433);
  }
}
V g_heff_2ecst_2elamBinderF_lam7(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2426), LBL_malg), 1, (V[]){v_t_2428}));
  V f_ = heff_get(heff_dup(v_hd_2426), LBL_bind);
  args[0] = v_t_2429;
  args[1] = heff_clo(g_heff_2ecst_2elamBinderF_lam8, 1, 4, (V[]){v_hd_2426, v_k_2427, v_g_240, v_x_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2elamBinderF_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2elamBinderF_lam7, 2, 2, (V[]){v_g_240, v_x_2425}), v_hd_241, v_k_242));
}
V g_heff_2ecst_2elamBinderF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str0))) {
    v_t_247 = NTAG(TAG_True);
  } else {
    v_t_247 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str1));
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_x_245);
    heff_drop(v_g_240);
    return (g_heff_2ecst_2enext(v_hd_241, heff_clo(g_heff_2ecst_2elamBinderF_lam1, 1, 1, (V[]){v_k_242})));
  }
  case TAG_False: {
    V v_t_2410;
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str2))) {
      v_t_2410 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2elamBinderF_str3));
    } else {
      v_t_2410 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_x_245);
      heff_drop(v_g_240);
      return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elamBinderF_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    case TAG_False: {
      V v_t_2424;
      if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2elamBinderF_str8))) {
        v_t_2424 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2elamBinderF_str9));
      } else {
        v_t_2424 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop(v_x_245);
        return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elamBinderF_lam6, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
      }
      case TAG_False: {
        heff_drop(v_g_240);
        V v_t_2442 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
        V v_t_2443 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2elamBinderF_str14), v_t_2442, NTAG(TAG_Nothing)});
        V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2443})});
        V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2444}));
        return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2445, v_k_242});
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinders_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2elamBinders_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2elamBinders_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elamBinders_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elamBinders_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
V g_heff_2ecst_2elamBinders_lam1(V self, V *args);
V g_heff_2ecst_2elamBinders_lam2(V self, V *args);
V g_heff_2ecst_2elamBinders_lam3(V self, V *args);
V g_heff_2ecst_2elamBinders_lam4(V self, V *args);
V g_heff_2ecst_2elamBinders_lam0(V self, V *args);
Clo g_heff_2ecst_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elamBinders_entry, 4, 0};

V g_heff_2ecst_2elamBinders(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2elamBinders_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_acc_241, v_k_243})});
}
V g_heff_2ecst_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elamBinders(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2elamBinders_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2elamBinders(v_g_240, heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2ecst_2elamBinders_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2elamBinders(v_g_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2410, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2ecst_2elamBinders_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2elamBinders(v_g_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2413, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2ecst_2elamBinders_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2elamBinders(v_g_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2415, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2ecst_2elamBinders_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2elamBinders_str0))) {
    heff_drop(v_x_246);
    return (g_heff_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2elamBinders_lam1, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
  } else {
    if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2elamBinders_str1))) {
      heff_drop(v_x_246);
      return (g_heff_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2elamBinders_lam2, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
    } else {
      if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2elamBinders_str2))) {
        if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_text), ((V)&g_heff_2ecst_2elamBinders_str3))) {
          heff_drop(v_x_246);
          return (g_heff_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2elamBinders_lam3, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
        } else {
          if (heff_strEq_c(heff_get(v_x_246, LBL_text), ((V)&g_heff_2ecst_2elamBinders_str4))) {
            return (g_heff_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2elamBinders_lam4, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
          } else {
            heff_drop(v_g_240);
            heff_drop(v_hd_242);
            V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
            V f_ = v_k_243;
            args[0] = v_x_2416;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        }
      } else {
        heff_drop(v_x_246);
        heff_drop(v_g_240);
        heff_drop(v_hd_242);
        V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
        V f_ = v_k_243;
        args[0] = v_x_2417;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2elambdaF_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
V g_heff_2ecst_2elambdaF_lam4(V self, V *args);
V g_heff_2ecst_2elambdaF_lam3(V self, V *args);
V g_heff_2ecst_2elambdaF_lam2(V self, V *args);
V g_heff_2ecst_2elambdaF_lam1(V self, V *args);
V g_heff_2ecst_2elambdaF_lam0(V self, V *args);
Clo g_heff_2ecst_2elambdaF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elambdaF_entry, 3, 0};

V g_heff_2ecst_2elambdaF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elambdaF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2elambdaF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elambdaF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2elambdaF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag(TAG_Lam, 4, (V[]){v_x_243, heff_tag(TAG_Cons, 2, (V[]){v_x_244, v_x_245}), v_x_246, v_x_247});
  V f_ = v_k_242;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elambdaF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2elambdaF_lam4, 1, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_k_242})});
}
V g_heff_2ecst_2elambdaF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2elambdaF_str0), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elambdaF_lam3, 1, 6, (V[]){v_g_240, v_hd_241, v_x_243, v_x_244, v_x_245, v_k_242})));
}
V g_heff_2ecst_2elambdaF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2elamBinders(heff_dup(v_g_240), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elambdaF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_243, v_x_244, v_k_242})));
}
V g_heff_2ecst_2elambdaF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elambdaF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_x_243, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2ecaseExprF_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2ecaseExprF_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
V g_heff_2ecst_2ecaseExprF_lam6(V self, V *args);
V g_heff_2ecst_2ecaseExprF_lam5(V self, V *args);
V g_heff_2ecst_2ecaseExprF_lam4(V self, V *args);
V g_heff_2ecst_2ecaseExprF_lam3(V self, V *args);
V g_heff_2ecst_2ecaseExprF_lam7(V self, V *args);
V g_heff_2ecst_2ecaseExprF_lam2(V self, V *args);
V g_heff_2ecst_2ecaseExprF_lam1(V self, V *args);
V g_heff_2ecst_2ecaseExprF_lam0(V self, V *args);
Clo g_heff_2ecst_2ecaseExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ecaseExprF_entry, 3, 0};

V g_heff_2ecst_2ecaseExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2ecaseExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2ecaseExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2ecaseExprF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2ecaseExprF_lam6(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_247;
  args[0] = heff_tag(TAG_EAlt, 3, (V[]){v_x_248, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ecaseExprF_lam5(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_246, heff_clo(g_heff_2ecst_2ecaseExprF_lam6, 1, 3, (V[]){v_k_247, v_x_248, v_x_249})});
}
V g_heff_2ecst_2ecaseExprF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2ecaseExprF_str1), heff_dup(v_hd_246), heff_clo(g_heff_2ecst_2ecaseExprF_lam5, 1, 4, (V[]){v_g_240, v_hd_246, v_k_247, v_x_248})));
}
V g_heff_2ecst_2ecaseExprF_lam3(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(heff_dup(v_g_240), LBL_pattern);
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2ecst_2ecaseExprF_lam4, 1, 3, (V[]){v_hd_246, v_g_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2ecaseExprF_lam7(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_Case, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ecaseExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eblock(heff_clo(g_heff_2ecst_2ecaseExprF_lam3, 2, 1, (V[]){v_g_240}), v_hd_241, heff_clo(g_heff_2ecst_2ecaseExprF_lam7, 1, 4, (V[]){v_k_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2ecst_2ecaseExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectKw(((V)&g_heff_2ecst_2ecaseExprF_str0), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2ecaseExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2ecst_2ecaseExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tail(heff_get(heff_dup(v_g_240), LBL_expr), 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2ecaseExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eifExprF_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 104, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eifExprF_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 108, 115, 101}};
V g_heff_2ecst_2eifExprF_lam5(V self, V *args);
V g_heff_2ecst_2eifExprF_lam4(V self, V *args);
V g_heff_2ecst_2eifExprF_lam3(V self, V *args);
V g_heff_2ecst_2eifExprF_lam2(V self, V *args);
V g_heff_2ecst_2eifExprF_lam1(V self, V *args);
V g_heff_2ecst_2eifExprF_lam0(V self, V *args);
Clo g_heff_2ecst_2eifExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eifExprF_entry, 3, 0};

V g_heff_2ecst_2eifExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eifExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2eifExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eifExprF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eifExprF_lam5(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_If, 6, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eifExprF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2eifExprF_lam5, 1, 6, (V[]){v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_x_247})});
}
V g_heff_2ecst_2eifExprF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecst_2eexpectKw(((V)&g_heff_2ecst_2eifExprF_str1), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eifExprF_lam4, 1, 7, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2ecst_2eifExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return heff_tail(heff_get(heff_dup(v_g_240), LBL_expr), 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eifExprF_lam3, 1, 6, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244, v_x_245})});
}
V g_heff_2ecst_2eifExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectKw(((V)&g_heff_2ecst_2eifExprF_str0), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eifExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2ecst_2eifExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tail(heff_get(heff_dup(v_g_240), LBL_expr), 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eifExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eletHeadF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eletHeadF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eletHeadF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
V g_heff_2ecst_2eletHeadF_lam4(V self, V *args);
V g_heff_2ecst_2eletHeadF_lam3(V self, V *args);
V g_heff_2ecst_2eletHeadF_lam2(V self, V *args);
V g_heff_2ecst_2eletHeadF_lam5(V self, V *args); static Clo g_heff_2ecst_2eletHeadF_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eletHeadF_lam5, 2, 0};
V g_heff_2ecst_2eletHeadF_lam6(V self, V *args); static Clo g_heff_2ecst_2eletHeadF_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eletHeadF_lam6, 2, 0};
V g_heff_2ecst_2eletHeadF_lam9(V self, V *args);
V g_heff_2ecst_2eletHeadF_lam8(V self, V *args);
V g_heff_2ecst_2eletHeadF_lam7(V self, V *args);
V g_heff_2ecst_2eletHeadF_lam1(V self, V *args);
V g_heff_2ecst_2eletHeadF_lam0(V self, V *args);
Clo g_heff_2ecst_2eletHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eletHeadF_entry, 3, 0};

V g_heff_2ecst_2eletHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_get(heff_dup(v_g_240), LBL_pattern), 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletHeadF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2ecst_2eletHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eletHeadF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eletHeadF_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2411, v_x_2412})});
  V f_ = v_k_2410;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eletHeadF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_249, heff_clo(g_heff_2ecst_2eletHeadF_lam4, 1, 2, (V[]){v_x_2411, v_k_2410})});
}
V g_heff_2ecst_2eletHeadF_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_249), heff_clo(g_heff_2ecst_2eletHeadF_lam3, 1, 3, (V[]){v_g_240, v_hd_249, v_k_2410})));
}
V g_heff_2ecst_2eletHeadF_lam5(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eletHeadF_lam6(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eletHeadF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_MkLetHead, 4, (V[]){v_x_243, v_x_2419, v_x_2420, v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eletHeadF_lam8(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2eletHeadF_lam9, 1, 4, (V[]){v_k_242, v_x_243, v_x_2419, v_x_2420})});
}
V g_heff_2ecst_2eletHeadF_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2eletHeadF_str2), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletHeadF_lam8, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_2419})));
}
V g_heff_2ecst_2eletHeadF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2418;
  if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2eletHeadF_str0))) {
    if (heff_strEq_c(heff_get(v_x_246, LBL_text), ((V)&g_heff_2ecst_2eletHeadF_str1))) {
      v_c_2418 = heff_clo(g_heff_2ecst_2eletHeadF_lam2, 2, 1, (V[]){heff_dup(v_g_240)});
    } else {
      v_c_2418 = ((V)&g_heff_2ecst_2eletHeadF_lam5_clo);
    }
  } else {
    heff_drop(v_x_246);
    v_c_2418 = ((V)&g_heff_2ecst_2eletHeadF_lam6_clo);
  }
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletHeadF_lam7, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})});
}
V g_heff_2ecst_2eletHeadF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2eletHeadF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eletExprF_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 110}};
V g_heff_2ecst_2eletExprF_lam3(V self, V *args);
V g_heff_2ecst_2eletExprF_lam2(V self, V *args);
V g_heff_2ecst_2eletExprF_lam1(V self, V *args);
V g_heff_2ecst_2eletExprF_lam0(V self, V *args);
Clo g_heff_2ecst_2eletExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eletExprF_entry, 3, 0};

V g_heff_2ecst_2eletExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2eletExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eletExprF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eletExprF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2412;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_247 = heff_field(v_x_244, 0);
    V v_ann_248 = heff_field(v_x_244, 1);
    V v_eq_249 = heff_field(v_x_244, 2);
    V v_e_2410 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2411 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_245, v_x_246})});
    v_x_2412 = heff_tag(TAG_ELet, 6, (V[]){v_x_243, v_p_247, v_ann_248, v_eq_249, v_e_2410, v_t_2411});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eletExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2eletExprF_lam3, 1, 4, (V[]){v_x_244, v_x_245, v_x_243, v_k_242})});
}
V g_heff_2ecst_2eletExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectKw(((V)&g_heff_2ecst_2eletExprF_str0), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
}
V g_heff_2ecst_2eletExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eletStmtF_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eletStmtF_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eletStmtF_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 110}};
V g_heff_2ecst_2eletStmtF_lam4(V self, V *args);
V g_heff_2ecst_2eletStmtF_lam3(V self, V *args);
V g_heff_2ecst_2eletStmtF_lam2(V self, V *args);
V g_heff_2ecst_2eletStmtF_lam1(V self, V *args);
V g_heff_2ecst_2eletStmtF_lam0(V self, V *args);
Clo g_heff_2ecst_2eletStmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eletStmtF_entry, 3, 0};

V g_heff_2ecst_2eletStmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletStmtF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2eletStmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eletStmtF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2eletStmtF_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2417;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_2412 = heff_field(v_x_244, 0);
    V v_ann_2413 = heff_field(v_x_244, 1);
    V v_eq_2414 = heff_field(v_x_244, 2);
    V v_e_2415 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2416 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_x_2411})});
    v_x_2417 = heff_tag(TAG_ELet, 6, (V[]){v_x_243, v_p_2412, v_ann_2413, v_eq_2414, v_e_2415, v_t_2416});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eletStmtF_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2eletStmtF_lam4, 1, 4, (V[]){v_x_244, v_x_2410, v_x_243, v_k_242})});
}
V g_heff_2ecst_2eletStmtF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249;
  if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_kind), ((V)&g_heff_2ecst_2eletStmtF_str0))) {
    v_t_249 = heff_strEq(heff_get(v_x_247, LBL_text), ((V)&g_heff_2ecst_2eletStmtF_str1));
  } else {
    heff_drop(v_x_247);
    v_t_249 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    return (g_heff_2ecst_2eexpectKw(((V)&g_heff_2ecst_2eletStmtF_str2), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletStmtF_lam3, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
  }
  case TAG_False: {
    heff_drop(v_hd_241);
    heff_drop(v_g_240);
    V v_x_2422;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkLetHead: {
      V v_p_2418 = heff_field(v_x_244, 0);
      V v_ann_2419 = heff_field(v_x_244, 1);
      V v_eq_2420 = heff_field(v_x_244, 2);
      V v_e_2421 = heff_field(v_x_244, 3);
      heff_take_n(v_x_244, 15ULL, 4);
      v_x_2422 = heff_tag(TAG_ELet, 6, (V[]){v_x_243, v_p_2418, v_ann_2419, v_eq_2420, v_e_2421, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V f_ = v_k_242;
    args[0] = v_x_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ecst_2eletStmtF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2eletStmtF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_244, v_x_243, v_k_242})});
}
V g_heff_2ecst_2eletStmtF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2eletStmtF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2estatementF_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estatementF_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estatementF_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2estatementF_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2estatementF_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2estatementF_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 45}};
V g_heff_2ecst_2estatementF_lam1(V self, V *args); static Clo g_heff_2ecst_2estatementF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2estatementF_lam1, 1, 0};
V g_heff_2ecst_2estatementF_lam5(V self, V *args);
V g_heff_2ecst_2estatementF_lam4(V self, V *args);
V g_heff_2ecst_2estatementF_lam3(V self, V *args);
V g_heff_2ecst_2estatementF_lam8(V self, V *args);
V g_heff_2ecst_2estatementF_lam7(V self, V *args);
V g_heff_2ecst_2estatementF_lam6(V self, V *args);
V g_heff_2ecst_2estatementF_lam2(V self, V *args);
V g_heff_2ecst_2estatementF_lam0(V self, V *args);
Clo g_heff_2ecst_2estatementF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2estatementF_entry, 3, 0};

V g_heff_2ecst_2estatementF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2estatementF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2ecst_2estatementF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2estatementF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2estatementF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_get(heff_dup(v_s_246), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2ecst_2estatementF_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_ESBind, 3, (V[]){v_x_2415, v_x_2416, v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2estatementF_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2estatementF_lam5, 1, 3, (V[]){v_k_242, v_x_2415, v_x_2416})});
}
V g_heff_2ecst_2estatementF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2estatementF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2415})));
}
V g_heff_2ecst_2estatementF_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_ESBind, 3, (V[]){v_x_2420, v_x_2421, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2estatementF_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2estatementF_lam8, 1, 3, (V[]){v_k_242, v_x_2420, v_x_2421})});
}
V g_heff_2ecst_2estatementF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2estatementF_lam7, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2420})));
}
V g_heff_2ecst_2estatementF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2estatementF_str0))) {
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2estatementF_str1))) {
      heff_drop(v_x_2410);
      heff_drop(v_x_245);
      return (g_heff_2ecst_2eletStmtF(v_g_240, v_hd_241, v_k_242));
    } else {
      if (heff_strEq_c(heff_get(v_x_245, LBL_kind), ((V)&g_heff_2ecst_2estatementF_str2))) {
        if (heff_strEq_c(heff_get(v_x_2410, LBL_text), ((V)&g_heff_2ecst_2estatementF_str3))) {
          return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2estatementF_lam3, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
        } else {
          return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, v_k_242});
        }
      } else {
        heff_drop(v_x_2410);
        return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, v_k_242});
      }
    }
  } else {
    if (heff_strEq_c(heff_get(v_x_245, LBL_kind), ((V)&g_heff_2ecst_2estatementF_str4))) {
      if (heff_strEq_c(heff_get(v_x_2410, LBL_text), ((V)&g_heff_2ecst_2estatementF_str5))) {
        return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2estatementF_lam6, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
      } else {
        return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, v_k_242});
      }
    } else {
      heff_drop(v_x_2410);
      return heff_tail(heff_get(v_g_240, LBL_expr), 2, (V[]){v_hd_241, v_k_242});
    }
  }
}
V g_heff_2ecst_2estatementF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2estatementF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecst_2estatementF_lam2, 1, 4, (V[]){v_x_245, v_g_240, v_hd_241, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2erecordPatF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecst_2erecordPatF_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {97, 32, 102, 105, 101, 108, 100, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2erecordPatF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2erecordPatF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2erecordPatF_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2ecst_2erecordPatF_lam4(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam3(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam2(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam1(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam6(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam5(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam9(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam8(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam7(V self, V *args);
V g_heff_2ecst_2erecordPatF_lam0(V self, V *args);
Clo g_heff_2ecst_2erecordPatF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2erecordPatF_entry, 3, 0};

V g_heff_2ecst_2erecordPatF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2erecordPatF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2erecordPatF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2erecordPatF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2erecordPatF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_PField, 3, (V[]){v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2erecordPatF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_pattern), 2, (V[]){v_hd_244, heff_clo(g_heff_2ecst_2erecordPatF_lam4, 1, 3, (V[]){v_k_245, v_x_246, v_x_247})});
}
V g_heff_2ecst_2erecordPatF_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2erecordPatF_str2), heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2erecordPatF_lam3, 1, 4, (V[]){v_g_240, v_hd_244, v_k_245, v_x_246})));
}
V g_heff_2ecst_2erecordPatF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecst_2eexpectKind(((V)&g_heff_2ecst_2erecordPatF_str0), ((V)&g_heff_2ecst_2erecordPatF_str1), heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2erecordPatF_lam2, 1, 3, (V[]){v_hd_244, v_g_240, v_k_245})));
}
V g_heff_2ecst_2erecordPatF_lam6(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_249 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_x_2412, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2erecordPatF_str3), v_p_249, v_t_2413, NTAG(TAG_Nil), v_hd_2410, v_k_2411));
}
V g_heff_2ecst_2erecordPatF_lam5(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_p_249);
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2ecst_2erecordPatF_lam6, 1, 3, (V[]){v_p_249, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2erecordPatF_lam9(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2421;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_MkSep: {
    V v_items_2419 = heff_field(v_x_2417, 0);
    V v_seps_2420 = heff_field(v_x_2417, 1);
    heff_take_n(v_x_2417, 3ULL, 2);
    v_x_2421 = heff_tag(TAG_PRec, 4, (V[]){v_x_243, v_items_2419, v_seps_2420, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_k_2416;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2erecordPatF_lam8(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2erecordPatF_str4), v_hd_2415, heff_clo(g_heff_2ecst_2erecordPatF_lam9, 1, 3, (V[]){v_x_2417, v_x_243, v_k_2416})));
}
V g_heff_2ecst_2erecordPatF_lam7(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2ecst_2erecordPatF_lam8, 1, 3, (V[]){v_hd_2415, v_x_243, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2erecordPatF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_249 = heff_clo(g_heff_2ecst_2erecordPatF_lam1, 2, 1, (V[]){v_g_240});
  V v_c_2414 = heff_clo(g_heff_2ecst_2erecordPatF_lam5, 2, 1, (V[]){v_p_249});
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2erecordPatF_lam7, 2, 2, (V[]){v_c_2414, v_x_243}), v_hd_241, v_k_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatHeadF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
V g_heff_2ecst_2epatHeadF_lam2(V self, V *args);
V g_heff_2ecst_2epatHeadF_lam1(V self, V *args);
V g_heff_2ecst_2epatHeadF_lam0(V self, V *args);
Clo g_heff_2ecst_2epatHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2epatHeadF_entry, 3, 0};

V g_heff_2ecst_2epatHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2epatHeadF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2ecst_2epatHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2epatHeadF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2epatHeadF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_PCon, 2, (V[]){v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2epatHeadF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyGo(heff_get(v_g_240, LBL_patAtom), NTAG(TAG_Nil), v_hd_241, heff_clo(g_heff_2ecst_2epatHeadF_lam2, 1, 2, (V[]){v_k_242, v_x_247})));
}
V g_heff_2ecst_2epatHeadF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get(v_x_245, LBL_kind), ((V)&g_heff_2ecst_2epatHeadF_str0))) {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatHeadF_lam1, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
  } else {
    return heff_tail(heff_get(v_g_240, LBL_patAtom), 2, (V[]){v_hd_241, v_k_242});
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatternF_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
V g_heff_2ecst_2epatternF_lam4(V self, V *args);
V g_heff_2ecst_2epatternF_lam3(V self, V *args);
V g_heff_2ecst_2epatternF_lam2(V self, V *args);
V g_heff_2ecst_2epatternF_lam1(V self, V *args);
V g_heff_2ecst_2epatternF_lam0(V self, V *args);
Clo g_heff_2ecst_2epatternF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2epatternF_entry, 3, 0};

V g_heff_2ecst_2epatternF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_get(heff_dup(v_g_240), LBL_patHead), 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatternF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2ecst_2epatternF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2epatternF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2epatternF_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_POp, 3, (V[]){v_x_243, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2epatternF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_pattern), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2epatternF_lam4, 1, 3, (V[]){v_k_242, v_x_243, v_x_2411})});
}
V g_heff_2ecst_2epatternF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2epatternF_str0))) {
    V v_t_249 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_x_246, LBL_text)}));
    V v_x1_2410 = ({ V a_0 = v_t_249; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_True: {
      heff_drop(v_x_247);
      heff_drop(v_hd_241);
      heff_drop(v_g_240);
      V f_ = v_k_242;
      args[0] = v_x_243;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      switch (heff_tag_of(v_x_247)) {
      case TAG_True: {
        heff_drop(v_hd_241);
        heff_drop(v_g_240);
        V f_ = v_k_242;
        args[0] = v_x_243;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatternF_lam3, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})));
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x1_2410);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop(v_x_246);
    heff_drop(v_hd_241);
    heff_drop(v_g_240);
    V f_ = v_k_242;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecst_2epatternF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatternF_lam2, 1, 5, (V[]){v_x_246, v_k_242, v_x_243, v_hd_241, v_g_240})));
}
V g_heff_2ecst_2epatternF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2epatternF_lam1, 1, 4, (V[]){v_hd_241, v_k_242, v_x_243, v_g_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elistOfF_24s2135508030x893215028_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elistOfF_24s2135508030x893215028_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2elistOfF_24s2135508030x893215028_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam3(V self, V *args); static Clo g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam3, 2, 0};
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam5(V self, V *args);
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam4(V self, V *args);
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam7(V self, V *args);
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam6(V self, V *args);
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam2(V self, V *args);
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam1(V self, V *args);
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam0(V self, V *args);
Clo g_heff_2ecst_2elistOfF_24s2135508030x893215028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elistOfF_24s2135508030x893215028_entry, 3, 0};

V g_heff_2ecst_2elistOfF_24s2135508030x893215028(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elistOfF_24s2135508030x893215028(a[0], a[1], a[2]);
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam3(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_tag(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_2411;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2elistOfF_24s2135508030x893215028_str1), v_item_240, v_t_2416, NTAG(TAG_Nil), v_hd_2413, v_k_2414));
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_item_240);
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam5, 1, 3, (V[]){v_item_240, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkSep: {
    V v_items_2420 = heff_field(v_x_2418, 0);
    V v_seps_2421 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    v_x_2422 = heff_tag(TAG_PList, 4, (V[]){v_x_243, v_items_2420, v_seps_2421, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_245;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2elistOfF_24s2135508030x893215028_str2), v_hd_244, heff_clo(g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam7, 1, 3, (V[]){v_x_2418, v_x_243, v_k_245})));
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2417;
  if (heff_strEq_c(heff_get(v_x_248, LBL_text), ((V)&g_heff_2ecst_2elistOfF_24s2135508030x893215028_str0))) {
    heff_drop(v_item_240);
    v_c_2417 = ((V)&g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam3_clo);
  } else {
    v_c_2417 = heff_clo(g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam4, 2, 1, (V[]){v_item_240});
  }
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})});
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_item_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_247;
  args[1] = heff_clo(g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam2, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2elistOfF_24s2135508030x893215028_lam1, 2, 2, (V[]){v_item_240, v_x_243}), v_hd_241, v_k_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecst_2epatAtomF_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatAtomF_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2epatAtomF_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatAtomF_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatAtomF_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2epatAtomF_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatAtomF_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatAtomF_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2epatAtomF_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2epatAtomF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2epatAtomF_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2epatAtomF_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2epatAtomF_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2epatAtomF_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2epatAtomF_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2epatAtomF_str15 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2epatAtomF_str16 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2epatAtomF_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2epatAtomF_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecst_2epatAtomF_str19 = {{0x80000000u, K_STR, 0}, 24, 24, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2epatAtomF_lam1(V self, V *args); static Clo g_heff_2ecst_2epatAtomF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2epatAtomF_lam1, 1, 0};
V g_heff_2ecst_2epatAtomF_lam3(V self, V *args); static Clo g_heff_2ecst_2epatAtomF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2epatAtomF_lam3, 1, 0};
V g_heff_2ecst_2epatAtomF_lam8(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam7(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam6(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam9(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam13(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam12(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam11(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam10(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam5(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam4(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam2(V self, V *args);
V g_heff_2ecst_2epatAtomF_lam0(V self, V *args);
Clo g_heff_2ecst_2epatAtomF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2epatAtomF_entry, 3, 0};

V g_heff_2ecst_2epatAtomF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2epatAtomF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2ecst_2epatAtomF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2epatAtomF(a[0], a[1], a[2]);
}
V g_heff_2ecst_2epatAtomF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_get(heff_dup(v_s_246), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2ecst_2epatAtomF_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_t_2412 = heff_intAdd(heff_get(heff_dup(v_s_2411), LBL_i), MK_INT(2LL));
  return (g_heff_2ecst_2etokAt(v_s_2411, v_t_2412));
}
V g_heff_2ecst_2epatAtomF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_PAs, 3, (V[]){v_x_2425, v_x_2426, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2epatAtomF_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_g_240, LBL_patAtom), 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2epatAtomF_lam8, 1, 3, (V[]){v_k_242, v_x_2425, v_x_2426})});
}
V g_heff_2ecst_2epatAtomF_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatAtomF_lam7, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2425})));
}
V g_heff_2ecst_2epatAtomF_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_PAtom, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2epatAtomF_lam13(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_2442 = heff_env(self)[0];
  V v_x_2440 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2442;
  args[0] = heff_tag(TAG_PParen, 3, (V[]){v_x_2440, v_x_2443, v_x_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2epatAtomF_lam12(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2441 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2epatAtomF_str14), v_hd_2441, heff_clo(g_heff_2ecst_2epatAtomF_lam13, 1, 3, (V[]){v_k_2442, v_x_2440, v_x_2443})));
}
V g_heff_2ecst_2epatAtomF_lam11(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_get(v_g_240, LBL_pattern);
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo(g_heff_2ecst_2epatAtomF_lam12, 1, 3, (V[]){v_hd_2441, v_k_2442, v_x_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2epatAtomF_lam10(V self, V *args) {
  V v_x_2440 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2epatAtomF_lam11, 2, 2, (V[]){v_g_240, v_x_2440}), v_hd_241, v_k_242));
}
V g_heff_2ecst_2epatAtomF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_True: {
    heff_drop(v_x_2410);
    heff_drop(v_x_2415);
    heff_drop(v_g_240);
    V v_t_2417 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
    V v_t_2418 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2epatAtomF_str0), v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2419}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2420, v_k_242});
  }
  case TAG_False: {
    V v_t_2424;
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2epatAtomF_str1))) {
      if (heff_strEq_c(heff_get(heff_dup(v_x_2410), LBL_text), ((V)&g_heff_2ecst_2epatAtomF_str2))) {
        if (heff_intEq_c(heff_get(heff_dup(v_x_245), LBL_end), heff_get(heff_dup(v_x_2410), LBL_start))) {
          v_t_2424 = heff_intEq(heff_get(v_x_2410, LBL_end), heff_get(v_x_2415, LBL_start));
        } else {
          heff_drop(v_x_2410);
          heff_drop(v_x_2415);
          v_t_2424 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_x_2410);
        heff_drop(v_x_2415);
        v_t_2424 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop(v_x_2415);
      v_t_2424 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      heff_drop(v_x_245);
      return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatAtomF_lam6, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
    }
    case TAG_False: {
      V v_t_2428 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_x_245), LBL_kind)}));
      V v_t_2429 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2epatAtomF_str3), NTAG(TAG_Nil)});
      V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2epatAtomF_str4), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2epatAtomF_str5), v_t_2429})});
      V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2epatAtomF_str6), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2epatAtomF_str7), v_t_2430})});
      V v_t_2432 = ({ V a_0 = v_t_2428; V a_1 = v_t_2431; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2431, 2); r_; });
      switch (heff_tag_of(v_t_2432)) {
      case TAG_True: {
        heff_drop(v_x_245);
        heff_drop(v_g_240);
        return (g_heff_2ecst_2enext(v_hd_241, heff_clo(g_heff_2ecst_2epatAtomF_lam9, 1, 1, (V[]){v_k_242})));
      }
      case TAG_False: {
        V v_t_2435;
        if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2epatAtomF_str8))) {
          v_t_2435 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2epatAtomF_str9));
        } else {
          v_t_2435 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2435)) {
        case TAG_True: {
          heff_drop(v_x_245);
          return (g_heff_2ecst_2elistOfF_24s2135508030x893215028(heff_get(v_g_240, LBL_pattern), v_hd_241, v_k_242));
        }
        case TAG_False: {
          V v_t_2437;
          if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2epatAtomF_str10))) {
            v_t_2437 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2epatAtomF_str11));
          } else {
            v_t_2437 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2437)) {
          case TAG_True: {
            heff_drop(v_x_245);
            return (g_heff_2ecst_2erecordPatF(v_g_240, v_hd_241, v_k_242));
          }
          case TAG_False: {
            V v_t_2439;
            if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2epatAtomF_str12))) {
              v_t_2439 = heff_strEq(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2epatAtomF_str13));
            } else {
              v_t_2439 = NTAG(TAG_False);
            }
            switch (heff_tag_of(v_t_2439)) {
            case TAG_True: {
              heff_drop(v_x_245);
              return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatAtomF_lam10, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
            }
            case TAG_False: {
              heff_drop(v_g_240);
              V v_t_2446;
              if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2epatAtomF_str15))) {
                v_t_2446 = ((V)&g_heff_2ecst_2epatAtomF_str16);
              } else {
                v_t_2446 = heff_strAppend(((V)&g_heff_2ecst_2epatAtomF_str17), heff_strAppend(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2epatAtomF_str18)));
              }
              V v_msg_2447 = heff_strAppend(((V)&g_heff_2ecst_2epatAtomF_str19), v_t_2446);
              V v_t_2448 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_245), LBL_start), heff_get(v_x_245, LBL_end)});
              V v_d_2449 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2447, v_t_2448, NTAG(TAG_Nothing)});
              V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2449})});
              V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2450}));
              return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2451, v_k_242});
            }
            default: return heff_nomatch(v_t_2439);
            }
          }
          default: return heff_nomatch(v_t_2437);
          }
        }
        default: return heff_nomatch(v_t_2435);
        }
      }
      default: return heff_nomatch(v_t_2432);
      }
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ecst_2epatAtomF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2epatAtomF_lam5, 1, 6, (V[]){v_x_245, v_hd_241, v_k_242, v_x_2410, v_x_2415, v_g_240})));
}
V g_heff_2ecst_2epatAtomF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2epatAtomF_lam3_clo)})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecst_2epatAtomF_lam4, 1, 5, (V[]){v_hd_241, v_x_245, v_k_242, v_x_2410, v_g_240})});
}
V g_heff_2ecst_2epatAtomF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2epatAtomF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecst_2epatAtomF_lam2, 1, 4, (V[]){v_hd_241, v_x_245, v_k_242, v_g_240})});
}
V g_heff_2ecst_2egram_lam0(V self, V *args); static Clo g_heff_2ecst_2egram_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam0, 1, 0};
V g_heff_2ecst_2egram_lam3(V self, V *args);
V g_heff_2ecst_2egram_lam2(V self, V *args);
V g_heff_2ecst_2egram_lam1(V self, V *args); static Clo g_heff_2ecst_2egram_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam1, 2, 0};
V g_heff_2ecst_2egram_lam7(V self, V *args);
V g_heff_2ecst_2egram_lam6(V self, V *args);
V g_heff_2ecst_2egram_lam5(V self, V *args);
V g_heff_2ecst_2egram_lam4(V self, V *args); static Clo g_heff_2ecst_2egram_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam4, 1, 0};
V g_heff_2ecst_2egram_lam11(V self, V *args);
V g_heff_2ecst_2egram_lam10(V self, V *args);
V g_heff_2ecst_2egram_lam9(V self, V *args);
V g_heff_2ecst_2egram_lam8(V self, V *args); static Clo g_heff_2ecst_2egram_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam8, 1, 0};
V g_heff_2ecst_2egram_lam12(V self, V *args); static Clo g_heff_2ecst_2egram_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam12, 1, 0};
V g_heff_2ecst_2egram_lam13(V self, V *args); static Clo g_heff_2ecst_2egram_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam13, 1, 0};
V g_heff_2ecst_2egram_lam14(V self, V *args); static Clo g_heff_2ecst_2egram_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam14, 1, 0};
V g_heff_2ecst_2egram_lam15(V self, V *args); static Clo g_heff_2ecst_2egram_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam15, 1, 0};
V g_heff_2ecst_2egram_lam16(V self, V *args); static Clo g_heff_2ecst_2egram_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam16, 1, 0};
V g_heff_2ecst_2egram_lam17(V self, V *args); static Clo g_heff_2ecst_2egram_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam17, 1, 0};
V g_heff_2ecst_2egram_lam18(V self, V *args); static Clo g_heff_2ecst_2egram_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam18, 1, 0};
V g_heff_2ecst_2egram_lam22(V self, V *args);
V g_heff_2ecst_2egram_lam21(V self, V *args);
V g_heff_2ecst_2egram_lam20(V self, V *args);
V g_heff_2ecst_2egram_lam19(V self, V *args); static Clo g_heff_2ecst_2egram_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam19, 1, 0};
V g_heff_2ecst_2egram_lam23(V self, V *args); static Clo g_heff_2ecst_2egram_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2egram_lam23, 1, 0};

static V g_heff_2ecst_2egram_val;
static int g_heff_2ecst_2egram_st;
static V g_heff_2ecst_2egram_init(void) {
  return heff_rec(13, shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE, (V[]){((V)&g_heff_2ecst_2egram_lam0_clo), ((V)&g_heff_2ecst_2egram_lam1_clo), ((V)&g_heff_2ecst_2egram_lam4_clo), ((V)&g_heff_2ecst_2egram_lam8_clo), ((V)&g_heff_2ecst_2egram_lam12_clo), ((V)&g_heff_2ecst_2egram_lam13_clo), ((V)&g_heff_2ecst_2egram_lam14_clo), ((V)&g_heff_2ecst_2egram_lam15_clo), ((V)&g_heff_2ecst_2egram_lam16_clo), ((V)&g_heff_2ecst_2egram_lam17_clo), ((V)&g_heff_2ecst_2egram_lam18_clo), ((V)&g_heff_2ecst_2egram_lam19_clo), ((V)&g_heff_2ecst_2egram_lam23_clo)});
}
V g_heff_2ecst_2egram_get(void) {
  if (g_heff_2ecst_2egram_st == 2) return g_heff_2ecst_2egram_val;
  if (g_heff_2ecst_2egram_st == 1) heff_fail("defined by itself");
  g_heff_2ecst_2egram_st = 1;
  g_heff_2ecst_2egram_val = heff_tr(g_heff_2ecst_2egram_init());
  g_heff_2ecst_2egram_st = 2;
  return g_heff_2ecst_2egram_val;
}
V g_heff_2ecst_2egram_lam0(V self, V *args) {
  V v_st_240 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2eexprF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_240});
}
V g_heff_2ecst_2egram_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eopLoopF(v_g_243, v_minPrec_241, v_x_245, v_st_242, v_k_244));
}
V g_heff_2ecst_2egram_lam2(V self, V *args) {
  V v_k_244 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_minPrec_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tail(heff_get(heff_dup(v_g_243), LBL_userOps), 2, (V[]){heff_dup(v_st_242), heff_clo(g_heff_2ecst_2egram_lam3, 1, 4, (V[]){v_g_243, v_minPrec_241, v_st_242, v_k_244})});
}
V g_heff_2ecst_2egram_lam1(V self, V *args) {
  V v_minPrec_241 = args[0];
  V v_st_242 = args[1];
  V v_g_243 = heff_dup(g_heff_2ecst_2egram_get());
  return heff_clo(g_heff_2ecst_2egram_lam2, 1, 3, (V[]){v_g_243, v_st_242, v_minPrec_241});
}
V g_heff_2ecst_2egram_lam7(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nil: {
    v_x_2413 = v_x_249;
    break;
  }
  case TAG_Cons: {
    v_x_2413 = heff_tag(TAG_Ops, 2, (V[]){v_x_249, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2egram_lam6(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eoperandsF(v_g_247, NTAG(TAG_Nil), v_st_246, heff_clo(g_heff_2ecst_2egram_lam7, 1, 2, (V[]){v_x_249, v_k_248})));
}
V g_heff_2ecst_2egram_lam5(V self, V *args) {
  V v_k_248 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(heff_get(heff_dup(v_g_247), LBL_app), 2, (V[]){heff_dup(v_st_246), heff_clo(g_heff_2ecst_2egram_lam6, 1, 3, (V[]){v_g_247, v_st_246, v_k_248})});
}
V g_heff_2ecst_2egram_lam4(V self, V *args) {
  V v_st_246 = args[0];
  V v_g_247 = heff_dup(g_heff_2ecst_2egram_get());
  return heff_clo(g_heff_2ecst_2egram_lam5, 1, 2, (V[]){v_g_247, v_st_246});
}
V g_heff_2ecst_2egram_lam11(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nil: {
    v_x_2421 = v_x_2417;
    break;
  }
  case TAG_Cons: {
    v_x_2421 = heff_tag(TAG_App, 2, (V[]){v_x_2417, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2416;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2egram_lam10(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_st_2414 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyGo(heff_get(v_g_2415, LBL_atom), NTAG(TAG_Nil), v_st_2414, heff_clo(g_heff_2ecst_2egram_lam11, 1, 2, (V[]){v_x_2417, v_k_2416})));
}
V g_heff_2ecst_2egram_lam9(V self, V *args) {
  V v_k_2416 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_st_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(heff_get(heff_dup(v_g_2415), LBL_atom), 2, (V[]){heff_dup(v_st_2414), heff_clo(g_heff_2ecst_2egram_lam10, 1, 3, (V[]){v_g_2415, v_st_2414, v_k_2416})});
}
V g_heff_2ecst_2egram_lam8(V self, V *args) {
  V v_st_2414 = args[0];
  V v_g_2415 = heff_dup(g_heff_2ecst_2egram_get());
  return heff_clo(g_heff_2ecst_2egram_lam9, 1, 2, (V[]){v_g_2415, v_st_2414});
}
V g_heff_2ecst_2egram_lam12(V self, V *args) {
  V v_st_2422 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2eatomF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2422});
}
V g_heff_2ecst_2egram_lam13(V self, V *args) {
  V v_st_2423 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2epatternF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2423});
}
V g_heff_2ecst_2egram_lam14(V self, V *args) {
  V v_st_2424 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2epatHeadF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2424});
}
V g_heff_2ecst_2egram_lam15(V self, V *args) {
  V v_st_2425 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2epatAtomF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2425});
}
V g_heff_2ecst_2egram_lam16(V self, V *args) {
  V v_st_2426 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2elambdaF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2426});
}
V g_heff_2ecst_2egram_lam17(V self, V *args) {
  V v_st_2427 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2ecaseExprF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2427});
}
V g_heff_2ecst_2egram_lam18(V self, V *args) {
  V v_st_2428 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2eifExprF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2428});
}
V g_heff_2ecst_2egram_lam22(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2431 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2431;
  args[0] = heff_tag(TAG_Do, 2, (V[]){v_x_2432, v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2egram_lam21(V self, V *args) {
  V v_x_2432 = args[0];
  V v_g_2430 = heff_env(self)[0];
  V v_st_2429 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tr(heff_apply(((V)&g_heff_2ecst_2estatementF_clo), 1, (V[]){v_g_2430}));
  V v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2ecst_2eblock_clo), 1, (V[]){v_t_2433}));
  return heff_tail(v_c_2434, 2, (V[]){v_st_2429, heff_clo(g_heff_2ecst_2egram_lam22, 1, 2, (V[]){v_k_2431, v_x_2432})});
}
V g_heff_2ecst_2egram_lam20(V self, V *args) {
  V v_k_2431 = args[0];
  V v_st_2429 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2enext(heff_dup(v_st_2429), heff_clo(g_heff_2ecst_2egram_lam21, 1, 3, (V[]){v_g_2430, v_st_2429, v_k_2431})));
}
V g_heff_2ecst_2egram_lam19(V self, V *args) {
  V v_st_2429 = args[0];
  V v_g_2430 = heff_dup(g_heff_2ecst_2egram_get());
  return heff_clo(g_heff_2ecst_2egram_lam20, 1, 2, (V[]){v_st_2429, v_g_2430});
}
V g_heff_2ecst_2egram_lam23(V self, V *args) {
  V v_st_2436 = args[0];
  return heff_tail(((V)&g_heff_2ecst_2eletExprF_clo), 2, (V[]){heff_dup(g_heff_2ecst_2egram_get()), v_st_2436});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam4(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam3(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam2(V self, V *args); static Clo g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam2, 2, 0};
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam6(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam5(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam9(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam8(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam7(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam1(V self, V *args);
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam0(V self, V *args);
Clo g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_entry, 2, 0};

V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eanonymousSumF_24s905580561x483496043(a[0], a[1]);
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag(TAG_ECon, 2, (V[]){v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2emanyGo(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_atom), NTAG(TAG_Nil), v_hd_244, heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam4, 1, 2, (V[]){v_k_245, v_x_246})));
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam2(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_244), heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam3, 1, 2, (V[]){v_hd_244, v_k_245})));
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam6(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_248 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_str1), v_p_248, v_t_2412, NTAG(TAG_Nil), v_hd_249, v_k_2410));
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam5(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_p_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_p_248);
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam6, 1, 3, (V[]){v_p_248, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam9(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2420;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkSep: {
    V v_items_2418 = heff_field(v_x_2416, 0);
    V v_seps_2419 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    v_x_2420 = heff_tag(TAG_Sum, 5, (V[]){v_x_242, v_x_243, v_items_2418, v_seps_2419, v_x_2417});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_2415;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam8(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_str2), v_hd_2414, heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam9, 1, 4, (V[]){v_x_2416, v_x_242, v_x_243, v_k_2415})));
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam7(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam8, 1, 4, (V[]){v_hd_2414, v_x_242, v_x_243, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_248 = ((V)&g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam2_clo);
  V v_c_2413 = heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam5, 2, 1, (V[]){v_p_248});
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam7, 2, 3, (V[]){v_c_2413, v_x_242, v_x_243}), v_hd_240, v_k_241));
}
V g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_str0), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_lam1, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 97, 115, 101}};
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam1(V self, V *args);
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam2(V self, V *args);
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam0(V self, V *args);
Clo g_heff_2ecst_2earrowRhsF_24s424219474x257387819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2earrowRhsF_24s424219474x257387819_entry, 2, 0};

V g_heff_2ecst_2earrowRhsF_24s424219474x257387819(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2earrowRhsF_24s424219474x257387819(a[0], a[1]);
}
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(MK_INT(1LL), v_x_2411, v_hd_240, v_k_241));
}
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(MK_INT(1LL), v_x_2412, v_hd_240, v_k_241));
}
V g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_text), ((V)&g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str0))) {
    heff_drop(v_x_244);
    return (g_heff_2ecst_2eexprF_24s504856081x2014933897(v_hd_240, v_k_241));
  } else {
    if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str1))) {
      V v_t_247 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_x_244, LBL_text)}));
      V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str2), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str4), v_t_248})});
      V v_t_2410 = ({ V a_0 = v_t_247; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2earrowRhsF_24s424219474x257387819_str5), v_t_249}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        return (g_heff_2ecst_2eexprF_24s504856081x2014933897(v_hd_240, v_k_241));
      }
      case TAG_False: {
        return heff_tail(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_userOps), 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
      }
      default: return heff_nomatch(v_t_2410);
      }
    } else {
      heff_drop(v_x_244);
      return heff_tail(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_userOps), 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2earrowRhsF_24s424219474x257387819_lam2, 1, 2, (V[]){v_hd_240, v_k_241})});
    }
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam4(V self, V *args);
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam3(V self, V *args);
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam5(V self, V *args);
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam2(V self, V *args);
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam1(V self, V *args);
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam0(V self, V *args);
Clo g_heff_2ecst_2eopLoopF_24s917930102x1677408009_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eopLoopF_24s917930102x1677408009_entry, 4, 0};

V g_heff_2ecst_2eopLoopF_24s917930102x1677408009(V v_minPrec_240, V v_lhs_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam0, 1, 4, (V[]){v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})});
}
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eopLoopF_24s917930102x1677408009(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_minPrec_2429 = heff_env(self)[0];
  V v_st_2430 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(v_minPrec_2429, v_x_2432, v_st_2430, v_k_2431));
}
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam3(V self, V *args) {
  V v_st_2430 = args[0];
  V v_k_2431 = args[1];
  V v_minPrec_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_userOps);
  args[0] = heff_dup(v_st_2430);
  args[1] = heff_clo(g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam4, 1, 3, (V[]){v_minPrec_2429, v_st_2430, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_minPrec_240 = heff_env(self)[0];
  V v_lhs_241 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(v_minPrec_240, heff_tag(TAG_Op, 3, (V[]){v_lhs_241, v_x_2420, v_x_2434}), v_hd_242, v_k_243));
}
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_minPrec_240 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_s_2421 = heff_get(heff_dup(v_x_246), LBL_text);
  V v_t_2424;
  if (heff_strEq_c(heff_dup(v_s_2421), ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str5))) {
    heff_drop(v_s_2421);
    v_t_2424 = MK_INT(1LL);
  } else {
    if (heff_strEq_c(v_s_2421, ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str6))) {
      v_t_2424 = MK_INT(2LL);
    } else {
      v_t_2424 = MK_INT(-1LL);
    }
  }
  V v_c_2433;
  if (heff_intEq_c(v_t_2424, MK_INT(1LL))) {
    heff_drop(v_x_246);
    v_c_2433 = ((V)&g_heff_2ecst_2earrowRhsF_24s424219474x257387819_clo);
  } else {
    V v_s_2426 = heff_get(v_x_246, LBL_text);
    V v_minPrec_2429;
    if (heff_strEq_c(heff_dup(v_s_2426), ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str7))) {
      heff_drop(v_s_2426);
      v_minPrec_2429 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2426, ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str8))) {
        v_minPrec_2429 = MK_INT(2LL);
      } else {
        v_minPrec_2429 = MK_INT(-1LL);
      }
    }
    v_c_2433 = heff_clo(g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam3, 2, 1, (V[]){v_minPrec_2429});
  }
  return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam5, 1, 5, (V[]){v_minPrec_240, v_lhs_241, v_x_2420, v_hd_242, v_k_243})});
}
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419;
  if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str0))) {
    V v_s_249 = heff_get(heff_dup(v_x_246), LBL_text);
    V v_a_2412;
    if (heff_strEq_c(heff_dup(v_s_249), ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str1))) {
      heff_drop(v_s_249);
      v_a_2412 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_249, ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str2))) {
        v_a_2412 = MK_INT(2LL);
      } else {
        v_a_2412 = MK_INT(-1LL);
      }
    }
    if (heff_intLe_c(MK_INT(1LL), v_a_2412)) {
      V v_s_2414 = heff_get(heff_dup(v_x_246), LBL_text);
      V v_a_2417;
      if (heff_strEq_c(heff_dup(v_s_2414), ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str3))) {
        heff_drop(v_s_2414);
        v_a_2417 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2414, ((V)&g_heff_2ecst_2eopLoopF_24s917930102x1677408009_str4))) {
          v_a_2417 = MK_INT(2LL);
        } else {
          v_a_2417 = MK_INT(-1LL);
        }
      }
      if (heff_intLe_c(heff_dup(v_minPrec_240), v_a_2417)) {
        switch (heff_tag_of(v_x_247)) {
        case TAG_True: {
          v_t_2419 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2419 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_247);
        }
      } else {
        heff_drop(v_x_247);
        v_t_2419 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_247);
      v_t_2419 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_247);
    v_t_2419 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam2, 1, 5, (V[]){v_x_246, v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})));
  }
  case TAG_False: {
    heff_drop(v_x_246);
    heff_drop(v_minPrec_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = v_lhs_241;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_lhs_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eopLoopF_24s917930102x1677408009_lam1, 1, 5, (V[]){v_x_246, v_minPrec_240, v_hd_242, v_lhs_241, v_k_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 97, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprHead_24s451872800x322153056_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam1(V self, V *args);
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam0(V self, V *args); static Clo g_heff_2ecst_2eexprHead_24s451872800x322153056_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprHead_24s451872800x322153056_lam0, 2, 0};
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam3(V self, V *args);
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam2(V self, V *args); static Clo g_heff_2ecst_2eexprHead_24s451872800x322153056_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprHead_24s451872800x322153056_lam2, 2, 0};
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam5(V self, V *args);
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam4(V self, V *args); static Clo g_heff_2ecst_2eexprHead_24s451872800x322153056_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprHead_24s451872800x322153056_lam4, 2, 0};
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam7(V self, V *args);
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam6(V self, V *args); static Clo g_heff_2ecst_2eexprHead_24s451872800x322153056_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprHead_24s451872800x322153056_lam6, 2, 0};
Clo g_heff_2ecst_2eexprHead_24s451872800x322153056_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprHead_24s451872800x322153056_entry, 1, 0};

V g_heff_2ecst_2eexprHead_24s451872800x322153056(V v_t_240) {
top: ;
  V v_t_242;
  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str0))) {
    v_t_242 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str1));
  } else {
    v_t_242 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_240);
    return heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_lambda);
  }
  case TAG_False: {
    V v_t_244;
    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str2))) {
      v_t_244 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str3));
    } else {
      v_t_244 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_240);
      return heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_caseE);
    }
    case TAG_False: {
      V v_t_246;
      if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str4))) {
        v_t_246 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str5));
      } else {
        v_t_246 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_t_240);
        return heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_ifE);
      }
      case TAG_False: {
        if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str6))) {
          if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str7))) {
            heff_drop(v_t_240);
            return heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_doE);
          } else {
            if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str8))) {
              if (heff_strEq_c(heff_get(v_t_240, LBL_text), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str9))) {
                return heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_letE);
              } else {
                return ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_lam0_clo);
              }
            } else {
              heff_drop(v_t_240);
              return ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_lam2_clo);
            }
          }
        } else {
          if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str10))) {
            if (heff_strEq_c(heff_get(v_t_240, LBL_text), ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_str11))) {
              return heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_letE);
            } else {
              return ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_lam4_clo);
            }
          } else {
            heff_drop(v_t_240);
            return ((V)&g_heff_2ecst_2eexprHead_24s451872800x322153056_lam6_clo);
          }
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexprHead_24s451872800x322153056(a[0]);
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(MK_INT(0LL), v_x_2413, v_st_2411, v_k_2412));
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam0(V self, V *args) {
  V v_st_2411 = args[0];
  V v_k_2412 = args[1];
  V f_ = heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_userOps);
  args[0] = heff_dup(v_st_2411);
  args[1] = heff_clo(g_heff_2ecst_2eexprHead_24s451872800x322153056_lam1, 1, 2, (V[]){v_st_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(MK_INT(0LL), v_x_2416, v_st_2414, v_k_2415));
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam2(V self, V *args) {
  V v_st_2414 = args[0];
  V v_k_2415 = args[1];
  V f_ = heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_userOps);
  args[0] = heff_dup(v_st_2414);
  args[1] = heff_clo(g_heff_2ecst_2eexprHead_24s451872800x322153056_lam3, 1, 2, (V[]){v_st_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_2419 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(MK_INT(0LL), v_x_2421, v_st_2419, v_k_2420));
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam4(V self, V *args) {
  V v_st_2419 = args[0];
  V v_k_2420 = args[1];
  V f_ = heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_userOps);
  args[0] = heff_dup(v_st_2419);
  args[1] = heff_clo(g_heff_2ecst_2eexprHead_24s451872800x322153056_lam5, 1, 2, (V[]){v_st_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eopLoopF_24s917930102x1677408009(MK_INT(0LL), v_x_2424, v_st_2422, v_k_2423));
}
V g_heff_2ecst_2eexprHead_24s451872800x322153056_lam6(V self, V *args) {
  V v_st_2422 = args[0];
  V v_k_2423 = args[1];
  V f_ = heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_userOps);
  args[0] = heff_dup(v_st_2422);
  args[1] = heff_clo(g_heff_2ecst_2eexprHead_24s451872800x322153056_lam7, 1, 2, (V[]){v_st_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexprF_24s504856081x2014933897_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprF_24s504856081x2014933897_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam5(V self, V *args);
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam4(V self, V *args);
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam3(V self, V *args);
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam2(V self, V *args);
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam1(V self, V *args);
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam0(V self, V *args);
Clo g_heff_2ecst_2eexprF_24s504856081x2014933897_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprF_24s504856081x2014933897_entry, 2, 0};

V g_heff_2ecst_2eexprF_24s504856081x2014933897(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2eexprF_24s504856081x2014933897_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eexprF_24s504856081x2014933897_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexprF_24s504856081x2014933897(a[0], a[1]);
}
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_Ann, 3, (V[]){v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexprF_24s504856081x2014933897(v_hd_240, heff_clo(g_heff_2ecst_2eexprF_24s504856081x2014933897_lam5, 1, 3, (V[]){v_k_241, v_x_246, v_x_2413})));
}
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get(heff_dup(v_x_249), LBL_text), ((V)&g_heff_2ecst_2eexprF_24s504856081x2014933897_str0))) {
    if (heff_strEq_c(heff_get(v_x_249, LBL_kind), ((V)&g_heff_2ecst_2eexprF_24s504856081x2014933897_str1))) {
      switch (heff_tag_of(v_x_2410)) {
      case TAG_True: {
        heff_drop(v_hd_240);
        V f_ = v_k_241;
        args[0] = v_x_246;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eexprF_24s504856081x2014933897_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})));
      }
      default: return heff_nomatch(v_x_2410);
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop(v_hd_240);
      V f_ = v_k_241;
      args[0] = v_x_246;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_x_249);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_x_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eexprF_24s504856081x2014933897_lam3, 1, 4, (V[]){v_x_249, v_k_241, v_x_246, v_hd_240})));
}
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecst_2eexprF_24s504856081x2014933897_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})});
}
V g_heff_2ecst_2eexprF_24s504856081x2014933897_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245 = (g_heff_2ecst_2eexprHead_24s451872800x322153056(v_x_244));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eexprF_24s504856081x2014933897_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eparensF_24s640260088x2009418696_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam3(V self, V *args); static Clo g_heff_2ecst_2eparensF_24s640260088x2009418696_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eparensF_24s640260088x2009418696_lam3, 1, 0};
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam6(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam5(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam10(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam9(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam8(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam7(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam14(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam13(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam15(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam12(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam11(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam4(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam2(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam1(V self, V *args);
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam0(V self, V *args);
Clo g_heff_2ecst_2eparensF_24s640260088x2009418696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eparensF_24s640260088x2009418696_entry, 2, 0};

V g_heff_2ecst_2eparensF_24s640260088x2009418696(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eparensF_24s640260088x2009418696(a[0], a[1]);
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_get(heff_dup(v_s_248), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag(TAG_EParen, 3, (V[]){v_x_242, heff_tag(TAG_Atom, 1, (V[]){v_x_2417}), v_x_2418});
  V f_ = v_k_244;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2enext(v_hd_243, heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam6, 1, 3, (V[]){v_x_242, v_x_2417, v_k_244})));
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag(TAG_Named, 5, (V[]){v_x_242, v_x_2425, v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str8), v_hd_243, heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam10, 1, 5, (V[]){v_k_244, v_x_242, v_x_2425, v_x_2426, v_x_2427})));
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexprF_24s504856081x2014933897(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam9, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425, v_x_2426})));
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam8, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425})));
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam14(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2439;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkSep: {
    V v_items_2437 = heff_field(v_x_2435, 0);
    V v_seps_2438 = heff_field(v_x_2435, 1);
    heff_take_n(v_x_2435, 3ULL, 2);
    v_x_2439 = heff_tag(TAG_Tup, 4, (V[]){v_x_242, v_items_2437, v_seps_2438, v_x_2436});
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_k_244;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam13(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str11), v_hd_243, heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam14, 1, 3, (V[]){v_x_2435, v_x_242, v_k_244})));
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam15(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  args[0] = heff_tag(TAG_EParen, 3, (V[]){v_x_242, v_x_2429, v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam12(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get(v_x_2432, LBL_text), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str9))) {
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){v_x_2429, NTAG(TAG_Nil)});
    return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str10), heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_expr), v_t_2434, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam13, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  } else {
    return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str12), v_hd_243, heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam15, 1, 3, (V[]){v_k_244, v_x_242, v_x_2429})));
  }
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam11(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2431, heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam12, 1, 4, (V[]){v_x_2429, v_hd_243, v_x_242, v_k_244})});
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_kind), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str0))) {
    V v_t_2414 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_x_247), LBL_text)}));
    V v_x1_2415 = ({ V a_0 = v_t_2414; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_True: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2416 = heff_strEq(heff_get(heff_dup(v_x_2412), LBL_text), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str1));
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
  } else {
    v_t_2416 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    heff_drop(v_x_2412);
    heff_drop(v_x_247);
    return (g_heff_2ecst_2enext(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam5, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  }
  case TAG_False: {
    V v_t_2424;
    if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_kind), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str2))) {
      heff_drop(v_x_247);
      if (heff_strEq_c(heff_get(heff_dup(v_x_2412), LBL_kind), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str3))) {
        v_t_2424 = heff_strEq(heff_get(v_x_2412, LBL_text), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str4));
      } else {
        heff_drop(v_x_2412);
        v_t_2424 = NTAG(TAG_False);
      }
    } else {
      if (heff_strEq_c(heff_get(v_x_247, LBL_kind), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str5))) {
        if (heff_strEq_c(heff_get(heff_dup(v_x_2412), LBL_kind), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str6))) {
          v_t_2424 = heff_strEq(heff_get(v_x_2412, LBL_text), ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_str7));
        } else {
          heff_drop(v_x_2412);
          v_t_2424 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_x_2412);
        v_t_2424 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      return (g_heff_2ecst_2enext(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam7, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
    }
    case TAG_False: {
      return (g_heff_2ecst_2eexprF_24s504856081x2014933897(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam11, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_x_242, v_k_244})});
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_245}));
  V f_ = heff_get(heff_dup(v_hd_243), LBL_bind);
  args[0] = v_t_246;
  args[1] = heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2eparensF_24s640260088x2009418696_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2eparensF_24s640260088x2009418696_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 61}};
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam4(V self, V *args);
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam3(V self, V *args);
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam2(V self, V *args);
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam1(V self, V *args);
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam0(V self, V *args);
Clo g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_entry, 2, 0};

V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2eexprF_24s504856081x2014933897(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edefaultedF_24s1757033401x1809946756(a[0], a[1]);
}
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_EFDefault, 3, (V[]){v_x_242, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexprF_24s504856081x2014933897(v_hd_240, heff_clo(g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam4, 1, 3, (V[]){v_k_241, v_x_242, v_x_2411})));
}
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_str0))) {
    V v_t_2410;
    if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_text), ((V)&g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_str1))) {
      heff_drop(v_x_245);
      switch (heff_tag_of(v_x_246)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x_246);
      }
    } else {
      if (heff_strEq_c(heff_get(v_x_245, LBL_text), ((V)&g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_str2))) {
        switch (heff_tag_of(v_x_246)) {
        case TAG_True: {
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_246);
        }
      } else {
        heff_drop(v_x_246);
        v_t_2410 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      return (g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
    }
    case TAG_False: {
      heff_drop(v_hd_240);
      V f_ = v_k_241;
      args[0] = v_x_242;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2410);
    }
  } else {
    heff_drop(v_x_246);
    heff_drop(v_x_245);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam2, 1, 4, (V[]){v_x_245, v_hd_240, v_k_241, v_x_242})));
}
V g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2edefaultedF_24s1757033401x1809946756_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})});
}
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam2(V self, V *args);
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam1(V self, V *args);
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam0(V self, V *args);
Clo g_heff_2ecst_2esepGo_24s1789038472x1625161927_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esepGo_24s1789038472x1625161927_entry, 5, 0};

V g_heff_2ecst_2esepGo_24s1789038472x1625161927(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2esepGo_24s1789038472x1625161927(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecst_2esepGo_24s1789038472x1625161927(v_sep_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}), heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2edefaultedF_24s1757033401x1809946756(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(v_x_247, LBL_text), heff_dup(v_sep_240))) {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2esepGo_24s1789038472x1625161927_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop(v_hd_243);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_x_2412 = heff_tag(TAG_MkSep, 2, (V[]){v_t_2411, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242))});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2ebracesF_24s658113058x1319132375_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam3(V self, V *args); static Clo g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam3, 1, 0};
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam8(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam7(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam6(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam5(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam9(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam13(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam12(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam11(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam10(V self, V *args); static Clo g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam10, 2, 0};
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam15(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam14(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam17(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam16(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam20(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam19(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam18(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam4(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam2(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam1(V self, V *args);
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam0(V self, V *args);
Clo g_heff_2ecst_2ebracesF_24s658113058x1319132375_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2ebracesF_24s658113058x1319132375_entry, 2, 0};

V g_heff_2ecst_2ebracesF_24s658113058x1319132375(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2ebracesF_24s658113058x1319132375(a[0], a[1]);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_get(heff_dup(v_s_248), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam8(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag(TAG_InstB, 5, (V[]){v_x_242, v_x_2415, v_x_2416, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str3), v_hd_243, heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam8, 1, 5, (V[]){v_k_244, v_x_242, v_x_2415, v_x_2416, v_x_2417})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str2), heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam7, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415, v_x_2416})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2einBrackets(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_expr), heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam6, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam9(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tag(TAG_Braces, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2420});
  V f_ = v_k_244;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam13(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2424;
  args[0] = heff_tag(TAG_EFSet, 3, (V[]){v_x_2425, v_x_2426, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam12(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexprF_24s504856081x2014933897(v_hd_2423, heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam13, 1, 3, (V[]){v_k_2424, v_x_2425, v_x_2426})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam11(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str6), heff_dup(v_hd_2423), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam12, 1, 3, (V[]){v_hd_2423, v_k_2424, v_x_2425})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam10(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2423), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam11, 1, 2, (V[]){v_hd_2423, v_k_2424})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam15(V self, V *args) {
  V v_x_2431 = args[0];
  V v_p_2428 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_x_2431, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo(((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str7), v_p_2428, v_t_2432, NTAG(TAG_Nil), v_hd_2429, v_k_2430));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam14(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_p_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_p_2428);
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam15, 1, 3, (V[]){v_p_2428, v_hd_2429, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam17(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2438;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkSep: {
    V v_items_2436 = heff_field(v_x_2434, 0);
    V v_seps_2437 = heff_field(v_x_2434, 1);
    heff_take_n(v_x_2434, 3ULL, 2);
    v_x_2438 = heff_tag(TAG_Braces, 4, (V[]){v_x_242, v_items_2436, v_seps_2437, v_x_2435});
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_k_244;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam16(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str8), v_hd_243, heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam17, 1, 3, (V[]){v_x_2434, v_x_242, v_k_244})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam20(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2445;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_MkSep: {
    V v_items_2443 = heff_field(v_x_2441, 0);
    V v_seps_2444 = heff_field(v_x_2441, 1);
    heff_take_n(v_x_2441, 3ULL, 2);
    v_x_2445 = heff_tag(TAG_Braces, 4, (V[]){v_x_242, v_items_2443, v_seps_2444, v_x_2442});
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V f_ = v_k_244;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam19(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectPunct(((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str10), v_hd_243, heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam20, 1, 3, (V[]){v_x_2441, v_x_242, v_k_244})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam18(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2440 = heff_tag(TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo_24s1789038472x1625161927(((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str9), v_t_2440, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam19, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414;
  if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_kind), ((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str0))) {
    v_t_2414 = heff_strEq(heff_get(heff_dup(v_x_247), LBL_text), ((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str1));
  } else {
    v_t_2414 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop(v_x_2412);
    heff_drop(v_x_247);
    return (g_heff_2ecst_2enext(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam5, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get(v_x_247, LBL_text), ((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str4))) {
      heff_drop(v_x_2412);
      return (g_heff_2ecst_2enext(v_hd_243, heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam9, 1, 2, (V[]){v_x_242, v_k_244})));
    } else {
      if (heff_strEq_c(heff_get(v_x_2412, LBL_text), ((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_str5))) {
        V v_p_2428 = ((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam10_clo);
        V v_c_2433 = heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam14, 2, 1, (V[]){v_p_2428});
        return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam16, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})});
      } else {
        return (g_heff_2ecst_2edefaultedF_24s1757033401x1809946756(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam18, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      }
    }
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_k_244, v_x_242})});
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_245}));
  V f_ = heff_get(heff_dup(v_hd_243), LBL_bind);
  args[0] = v_t_246;
  args[1] = heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam2, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2einBrackets(heff_clo(g_heff_2ecst_2ebracesF_24s658113058x1319132375_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 116, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {105, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str7 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str19 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str22 = {{0x80000000u, K_STR, 0}, 4, 4, {100, 97, 116, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str25 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str27 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str29 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str30 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2ecst_2eatomBase_24s833913695x513827753_str33 = {{0x80000000u, K_STR, 0}, 28, 28, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam0(V self, V *args);
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam2(V self, V *args);
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam1(V self, V *args); static Clo g_heff_2ecst_2eatomBase_24s833913695x513827753_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatomBase_24s833913695x513827753_lam1, 2, 0};
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam3(V self, V *args);
Clo g_heff_2ecst_2eatomBase_24s833913695x513827753_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatomBase_24s833913695x513827753_entry, 1, 0};

V g_heff_2ecst_2eatomBase_24s833913695x513827753(V v_t_240) {
top: ;
  V v_t_241 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_240), LBL_kind)}));
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str0), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str2), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str4), v_t_243})});
  V v_t_245 = ({ V a_0 = v_t_241; V a_1 = v_t_244; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_244, 2); r_; });
  V v_t_2416;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_2416 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str5))) {
      V v_t_247 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_240), LBL_text)}));
      V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str6), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str8), v_t_248})});
      V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str10), v_t_249})});
      V v_t_2411 = ({ V a_0 = v_t_247; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str11), v_t_2410}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        v_t_2416 = NTAG(TAG_True);
        break;
      }
      case TAG_False: {
        V v_x3_2414 = ({ V a_0 = heff_clo(g_heff_2ecst_2eatomBase_24s833913695x513827753_lam0, 1, 1, (V[]){heff_dup(v_t_240)}); V b_1 = heff_dup(g_heff_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x3_2414)) {
        case TAG_Nothing: {
          v_t_2416 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2414, 0ULL, 1);
          v_t_2416 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_2414);
        }
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
    } else {
      v_t_2416 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    heff_drop(v_t_240);
    return ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_lam1_clo);
  }
  case TAG_False: {
    V v_t_2421;
    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str21))) {
      v_t_2421 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str22));
    } else {
      v_t_2421 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      heff_drop(v_t_240);
      return ((V)&g_heff_2ecst_2eanonymousSumF_24s905580561x483496043_clo);
    }
    case TAG_False: {
      V v_t_2423;
      if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str23))) {
        v_t_2423 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str24));
      } else {
        v_t_2423 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2423)) {
      case TAG_True: {
        heff_drop(v_t_240);
        return ((V)&g_heff_2ecst_2eparensF_24s640260088x2009418696_clo);
      }
      case TAG_False: {
        V v_t_2425;
        if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str25))) {
          v_t_2425 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str26));
        } else {
          v_t_2425 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2425)) {
        case TAG_True: {
          heff_drop(v_t_240);
          return ((V)&g_heff_2ecst_2ebracesF_24s658113058x1319132375_clo);
        }
        case TAG_False: {
          V v_t_2427;
          if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str27))) {
            v_t_2427 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str28));
          } else {
            v_t_2427 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2427)) {
          case TAG_True: {
            heff_drop(v_t_240);
            return heff_tail(((V)&g_heff_2ecst_2elistOfF_24s1130792037x937330368_clo), 1, (V[]){heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_expr)});
          }
          case TAG_False: {
            V v_t_2429;
            if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str29))) {
              v_t_2429 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str30);
            } else {
              v_t_2429 = heff_strAppend(((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str31), heff_strAppend(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str32)));
            }
            V v_msg_2430 = heff_strAppend(((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str33), v_t_2429);
            V v_t_2431 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_t_240), LBL_start), heff_get(v_t_240, LBL_end)});
            V v_d_2432 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2430, v_t_2431, NTAG(TAG_Nothing)});
            return heff_clo(g_heff_2ecst_2eatomBase_24s833913695x513827753_lam3, 2, 1, (V[]){v_d_2432});
          }
          default: return heff_nomatch(v_t_2427);
          }
        }
        default: return heff_nomatch(v_t_2425);
        }
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2ecst_2eatomBase_24s833913695x513827753_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eatomBase_24s833913695x513827753(a[0]);
}
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam0(V self, V *args) {
  V v_w_2412 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413;
  switch (heff_tag_of(v_w_2412)) {
  case TAG_I8: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str12);
    break;
  }
  case TAG_I16: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str13);
    break;
  }
  case TAG_I32: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str14);
    break;
  }
  case TAG_I64: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str15);
    break;
  }
  case TAG_U8: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str16);
    break;
  }
  case TAG_U16: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str17);
    break;
  }
  case TAG_U32: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str18);
    break;
  }
  case TAG_U64: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str19);
    break;
  }
  case TAG_F32: {
    v_t_2413 = ((V)&g_heff_2ecst_2eatomBase_24s833913695x513827753_str20);
    break;
  }
  default: heff_nomatch(v_w_2412);
  }
  return heff_strEq(v_t_2413, heff_get(v_t_240, LBL_text));
}
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2418;
  args[0] = heff_tag(TAG_Atom, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  return (g_heff_2ecst_2enext(v_hd_2417, heff_clo(g_heff_2ecst_2eatomBase_24s833913695x513827753_lam2, 1, 1, (V[]){v_k_2418})));
}
V g_heff_2ecst_2eatomBase_24s833913695x513827753_lam3(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_d_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2432})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2433), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2433, LBL_bind);
  args[0] = v_t_2436;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eatomF_24s1730811308x810317142_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecst_2eatomF_24s1730811308x810317142_str1 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 101, 32, 101, 110, 100, 32, 111, 102, 32, 116, 104, 101, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomF_24s1730811308x810317142_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eatomF_24s1730811308x810317142_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2ecst_2eatomF_24s1730811308x810317142_str4 = {{0x80000000u, K_STR, 0}, 28, 28, {101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 110, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 44, 32, 110, 111, 116, 32}};
V g_heff_2ecst_2eatomF_24s1730811308x810317142_lam2(V self, V *args);
V g_heff_2ecst_2eatomF_24s1730811308x810317142_lam1(V self, V *args);
V g_heff_2ecst_2eatomF_24s1730811308x810317142_lam0(V self, V *args);
Clo g_heff_2ecst_2eatomF_24s1730811308x810317142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eatomF_24s1730811308x810317142_entry, 2, 0};

V g_heff_2ecst_2eatomF_24s1730811308x810317142(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2eatomF_24s1730811308x810317142_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eatomF_24s1730811308x810317142_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eatomF_24s1730811308x810317142(a[0], a[1]);
}
V g_heff_2ecst_2eatomF_24s1730811308x810317142_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2efieldsGo(v_x_2416, v_hd_240, v_k_241));
}
V g_heff_2ecst_2eatomF_24s1730811308x810317142_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  switch (heff_tag_of(v_x_245)) {
  case TAG_True: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_x1_246 = (g_heff_2ecst_2estartsAtom(heff_dup(v_x_244)));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_True: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_249;
    if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2eatomF_24s1730811308x810317142_str0))) {
      v_t_249 = ((V)&g_heff_2ecst_2eatomF_24s1730811308x810317142_str1);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2ecst_2eatomF_24s1730811308x810317142_str2), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_text), ((V)&g_heff_2ecst_2eatomF_24s1730811308x810317142_str3)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2ecst_2eatomF_24s1730811308x810317142_str4), v_t_249);
    V v_t_2411 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_d_2412 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_d_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2414, v_k_241});
  }
  case TAG_False: {
    V v_c_2415 = heff_tr(g_heff_2ecst_2eatomBase_24s833913695x513827753(v_x_244));
    return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eatomF_24s1730811308x810317142_lam2, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecst_2eatomF_24s1730811308x810317142_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eatomF_24s1730811308x810317142_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecst_2edataParam_str0 = {{0x80000000u, K_STR, 0}, 17, 17, {110, 111, 32, 112, 97, 114, 97, 109, 101, 116, 101, 114, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edataParam_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2ecst_2edataParam_str2 = {{0x80000000u, K_STR, 0}, 55, 55, {97, 32, 116, 121, 112, 101, 39, 115, 32, 112, 97, 114, 97, 109, 101, 116, 101, 114, 32, 105, 115, 32, 108, 111, 119, 101, 114, 32, 99, 97, 115, 101, 44, 32, 111, 114, 32, 103, 105, 118, 101, 110, 32, 105, 116, 115, 32, 116, 121, 112, 101, 58, 32, 96, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecst_2edataParam_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 58, 58, 32, 84, 121, 112, 101, 41, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edataParam_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edataParam_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edataParam_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecst_2edataParam_str7 = {{0x80000000u, K_STR, 0}, 17, 17, {110, 111, 32, 112, 97, 114, 97, 109, 101, 116, 101, 114, 32, 104, 101, 114, 101}};
V g_heff_2ecst_2edataParam_lam2(V self, V *args);
V g_heff_2ecst_2edataParam_lam1(V self, V *args);
V g_heff_2ecst_2edataParam_lam0(V self, V *args);
Clo g_heff_2ecst_2edataParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataParam_entry, 2, 0};

V g_heff_2ecst_2edataParam(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2edataParam_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2edataParam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edataParam(a[0], a[1]);
}
V g_heff_2ecst_2edataParam_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_Atom, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataParam_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_True: {
    V v_t_246 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_247 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2edataParam_str0), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_249, v_k_241});
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2edataParam_str1))) {
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ecst_2edataParam_str2), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_text), ((V)&g_heff_2ecst_2edataParam_str3)));
      V v_t_2412 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
      V v_t_2413 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2411, v_t_2412, NTAG(TAG_Nothing)});
      V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2414}));
      return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2415, v_k_241});
    } else {
      if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2edataParam_str4))) {
        heff_drop(v_x_244);
        return (g_heff_2ecst_2enext(v_hd_240, heff_clo(g_heff_2ecst_2edataParam_lam2, 1, 1, (V[]){v_k_241})));
      } else {
        if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_text), ((V)&g_heff_2ecst_2edataParam_str5))) {
          heff_drop(v_x_244);
          return (g_heff_2ecst_2eatomF_24s1730811308x810317142(v_hd_240, v_k_241));
        } else {
          if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_text), ((V)&g_heff_2ecst_2edataParam_str6))) {
            heff_drop(v_x_244);
            return (g_heff_2ecst_2eatomF_24s1730811308x810317142(v_hd_240, v_k_241));
          } else {
            V v_t_2420 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
            V v_t_2421 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2edataParam_str7), v_t_2420, NTAG(TAG_Nothing)});
            V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2421})});
            V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2422}));
            return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2423, v_k_241});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2ecst_2edataParam_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edataParam_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2emanyParams_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2emanyParams_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 117, 110, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2emanyParams_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
V g_heff_2ecst_2emanyParams_lam2(V self, V *args);
V g_heff_2ecst_2emanyParams_lam1(V self, V *args);
V g_heff_2ecst_2emanyParams_lam0(V self, V *args);
Clo g_heff_2ecst_2emanyParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2emanyParams_entry, 3, 0};

V g_heff_2ecst_2emanyParams(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2emanyParams_lam0, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})));
}
V g_heff_2ecst_2emanyParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2emanyParams(a[0], a[1], a[2]);
}
V g_heff_2ecst_2emanyParams_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyParams(heff_tag(TAG_Cons, 2, (V[]){v_x_2412, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2ecst_2emanyParams_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_243)) {
  case TAG_True: {
    heff_drop(v_x_246);
    heff_drop(v_hd_241);
    V v_x_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_248 = (g_heff_2ecst_2estartsAtom(heff_dup(v_x_246)));
    V v_x1_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_x_246);
      v_x1_2411 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2emanyParams_str0))) {
        heff_drop(v_x_246);
        v_x1_2411 = NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_kind), ((V)&g_heff_2ecst_2emanyParams_str1))) {
          v_x1_2411 = heff_strEq(heff_get(v_x_246, LBL_text), ((V)&g_heff_2ecst_2emanyParams_str2));
        } else {
          heff_drop(v_x_246);
          v_x1_2411 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      return (g_heff_2ecst_2edataParam(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2emanyParams_lam2, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
    }
    case TAG_False: {
      heff_drop(v_hd_241);
      V v_x_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
      V f_ = v_k_242;
      args[0] = v_x_2413;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_heff_2ecst_2emanyParams_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecst_2emanyParams_lam1, 1, 4, (V[]){v_x_243, v_acc_240, v_k_242, v_hd_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edataAlternative_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2ecst_2edataAlternative_str1 = {{0x80000000u, K_STR, 0}, 35, 35, {97, 32, 99, 111, 110, 115, 116, 114, 117, 99, 116, 111, 114, 32, 115, 116, 97, 114, 116, 115, 32, 119, 105, 116, 104, 32, 97, 32, 99, 97, 112, 105, 116, 97, 108}};
V g_heff_2ecst_2edataAlternative_lam1(V self, V *args);
V g_heff_2ecst_2edataAlternative_lam0(V self, V *args);
Clo g_heff_2ecst_2edataAlternative_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataAlternative_entry, 2, 0};

V g_heff_2ecst_2edataAlternative(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edataAlternative_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2edataAlternative_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edataAlternative(a[0], a[1]);
}
V g_heff_2ecst_2edataAlternative_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_ECon, 2, (V[]){v_x_242, v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataAlternative_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_get(heff_dup(v_x_242), LBL_kind), ((V)&g_heff_2ecst_2edataAlternative_str0))) {
    return (g_heff_2ecst_2emanyGo(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_atom), NTAG(TAG_Nil), v_hd_240, heff_clo(g_heff_2ecst_2edataAlternative_lam1, 1, 2, (V[]){v_k_241, v_x_242})));
  } else {
    V v_t_245 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_242), LBL_start), heff_get(v_x_242, LBL_end)});
    V v_t_246 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2edataAlternative_str1), v_t_245, NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_247}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_248, v_k_241});
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2echeckAltNames_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2ecst_2echeckAltNames_str1 = {{0x80000000u, K_STR, 0}, 62, 62, {96, 32, 110, 97, 109, 101, 115, 32, 116, 104, 101, 32, 116, 121, 112, 101, 59, 32, 105, 116, 115, 32, 99, 111, 110, 115, 116, 114, 117, 99, 116, 111, 114, 32, 110, 101, 101, 100, 115, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101, 44, 32, 101, 46, 103, 46, 32, 96, 77, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2echeckAltNames_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
V g_heff_2ecst_2echeckAltNames_lam0(V self, V *args); static Clo g_heff_2ecst_2echeckAltNames_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2echeckAltNames_lam0, 2, 0};
V g_heff_2ecst_2echeckAltNames_lam1(V self, V *args);
Clo g_heff_2ecst_2echeckAltNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2echeckAltNames_entry, 2, 0};

V g_heff_2ecst_2echeckAltNames(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_name_240);
    return ((V)&g_heff_2ecst_2echeckAltNames_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECon: {
      V v_c_2439 = heff_field(v_x21_244, 0);
      if (heff_strEq_c(heff_get(heff_dup(v_c_2439), LBL_text), heff_dup(v_name_240))) {
        heff_drop(v_name_240);
        return heff_clo(g_heff_2ecst_2echeckAltNames_lam1, 2, 1, (V[]){heff_dup(v_c_2439)});
      } else {
        V t_0 = v_name_240;
        V t_1 = v_rest_245;
        v_name_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EField: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_OpRhs: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ann: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecst_2echeckAltNames_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecst_2echeckAltNames(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecst_2echeckAltNames_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2echeckAltNames_lam1(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_strAppend(((V)&g_heff_2ecst_2echeckAltNames_str0), heff_strAppend(heff_get(heff_dup(v_c_2439), LBL_text), heff_strAppend(((V)&g_heff_2ecst_2echeckAltNames_str1), heff_strAppend(heff_get(heff_dup(v_c_2439), LBL_text), ((V)&g_heff_2ecst_2echeckAltNames_str2)))));
  V v_t_2445 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_c_2439), LBL_start), heff_get(v_c_2439, LBL_end)});
  V v_t_2446 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2444, v_t_2445, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2442), LBL_malg), 1, (V[]){v_t_2447}));
  V f_ = heff_get(v_hd_2442, LBL_bind);
  args[0] = v_t_2448;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2esepGo_24s1211973577x145888309_lam2(V self, V *args);
V g_heff_2ecst_2esepGo_24s1211973577x145888309_lam1(V self, V *args);
V g_heff_2ecst_2esepGo_24s1211973577x145888309_lam0(V self, V *args);
Clo g_heff_2ecst_2esepGo_24s1211973577x145888309_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esepGo_24s1211973577x145888309_entry, 5, 0};

V g_heff_2ecst_2esepGo_24s1211973577x145888309(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2esepGo_24s1211973577x145888309_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2ecst_2esepGo_24s1211973577x145888309_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2esepGo_24s1211973577x145888309(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecst_2esepGo_24s1211973577x145888309_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecst_2esepGo_24s1211973577x145888309(v_sep_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}), heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2ecst_2esepGo_24s1211973577x145888309_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2edataAlternative(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2esepGo_24s1211973577x145888309_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2ecst_2esepGo_24s1211973577x145888309_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(v_x_247, LBL_text), heff_dup(v_sep_240))) {
    return (g_heff_2ecst_2enext(heff_dup(v_hd_243), heff_clo(g_heff_2ecst_2esepGo_24s1211973577x145888309_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop(v_hd_243);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_x_2412 = heff_tag(TAG_MkSep, 2, (V[]){v_t_2411, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242))});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edataDecl_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecst_2edataDecl_str1 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 104, 101, 32, 110, 97, 109, 101, 32, 111, 102, 32, 97, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edataDecl_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edataDecl_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edataDecl_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edataDecl_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
V g_heff_2ecst_2edataDecl_lam7(V self, V *args);
V g_heff_2ecst_2edataDecl_lam6(V self, V *args);
V g_heff_2ecst_2edataDecl_lam5(V self, V *args);
V g_heff_2ecst_2edataDecl_lam4(V self, V *args); static Clo g_heff_2ecst_2edataDecl_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataDecl_lam4, 2, 0};
V g_heff_2ecst_2edataDecl_lam8(V self, V *args); static Clo g_heff_2ecst_2edataDecl_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataDecl_lam8, 2, 0};
V g_heff_2ecst_2edataDecl_lam9(V self, V *args); static Clo g_heff_2ecst_2edataDecl_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataDecl_lam9, 2, 0};
V g_heff_2ecst_2edataDecl_lam15(V self, V *args);
V g_heff_2ecst_2edataDecl_lam14(V self, V *args);
V g_heff_2ecst_2edataDecl_lam13(V self, V *args);
V g_heff_2ecst_2edataDecl_lam12(V self, V *args); static Clo g_heff_2ecst_2edataDecl_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataDecl_lam12, 2, 0};
V g_heff_2ecst_2edataDecl_lam16(V self, V *args); static Clo g_heff_2ecst_2edataDecl_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataDecl_lam16, 2, 0};
V g_heff_2ecst_2edataDecl_lam18(V self, V *args);
V g_heff_2ecst_2edataDecl_lam17(V self, V *args);
V g_heff_2ecst_2edataDecl_lam11(V self, V *args);
V g_heff_2ecst_2edataDecl_lam10(V self, V *args);
V g_heff_2ecst_2edataDecl_lam3(V self, V *args);
V g_heff_2ecst_2edataDecl_lam2(V self, V *args);
V g_heff_2ecst_2edataDecl_lam1(V self, V *args);
V g_heff_2ecst_2edataDecl_lam0(V self, V *args);
Clo g_heff_2ecst_2edataDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataDecl_entry, 2, 0};

V g_heff_2ecst_2edataDecl(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edataDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2edataDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edataDecl(a[0], a[1]);
}
V g_heff_2ecst_2edataDecl_lam7(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    v_x_2417 = v_x_2413;
    break;
  }
  case TAG_Cons: {
    v_x_2417 = heff_tag(TAG_App, 2, (V[]){v_x_2413, v_x_2414});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2418 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2412, v_x_2417})});
  V f_ = v_k_2411;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataDecl_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyGo(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_atom), NTAG(TAG_Nil), v_hd_2410, heff_clo(g_heff_2ecst_2edataDecl_lam7, 1, 3, (V[]){v_x_2413, v_x_2412, v_k_2411})));
}
V g_heff_2ecst_2edataDecl_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eatomF_24s1730811308x810317142(heff_dup(v_hd_2410), heff_clo(g_heff_2ecst_2edataDecl_lam6, 1, 3, (V[]){v_hd_2410, v_x_2412, v_k_2411})));
}
V g_heff_2ecst_2edataDecl_lam4(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2410), heff_clo(g_heff_2ecst_2edataDecl_lam5, 1, 2, (V[]){v_hd_2410, v_k_2411})));
}
V g_heff_2ecst_2edataDecl_lam8(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataDecl_lam9(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataDecl_lam15(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkSep: {
    V v_items_2435 = heff_field(v_x_2434, 0);
    V v_seps_2436 = heff_field(v_x_2434, 1);
    heff_take_n(v_x_2434, 3ULL, 2);
    v_t_2437 = heff_tag(TAG_MkDAlts, 3, (V[]){v_x_2431, v_items_2435, v_seps_2436});
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V v_x_2438 = heff_tag(TAG_Just, 1, (V[]){v_t_2437});
  V f_ = v_k_2430;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataDecl_lam14(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
  return (g_heff_2ecst_2esepGo_24s1211973577x145888309(((V)&g_heff_2ecst_2edataDecl_str5), v_t_2433, NTAG(TAG_Nil), v_hd_2429, heff_clo(g_heff_2ecst_2edataDecl_lam15, 1, 2, (V[]){v_x_2431, v_k_2430})));
}
V g_heff_2ecst_2edataDecl_lam13(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2edataAlternative(heff_dup(v_hd_2429), heff_clo(g_heff_2ecst_2edataDecl_lam14, 1, 3, (V[]){v_hd_2429, v_x_2431, v_k_2430})));
}
V g_heff_2ecst_2edataDecl_lam12(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2429), heff_clo(g_heff_2ecst_2edataDecl_lam13, 1, 2, (V[]){v_hd_2429, v_k_2430})));
}
V g_heff_2ecst_2edataDecl_lam16(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataDecl_lam18(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_x_2442 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2449);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_DData, 5, (V[]){v_x_242, v_x_243, v_x_244, v_x_2424, v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edataDecl_lam17(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2447;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nothing: {
    v_t_2447 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_2443 = heff_dup(heff_field(v_x_2442, 0));
    switch (heff_tag_of(v_x11_2443)) {
    case TAG_MkDAlts: {
      V v_alts_2445 = heff_field(v_x11_2443, 1);
      heff_take_n(v_x11_2443, 2ULL, 3);
      v_t_2447 = v_alts_2445;
      break;
    }
    default: heff_nomatch(v_x11_2443);
    }
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V v_c_2448 = ({ V a_0 = heff_get(heff_dup(v_x_243), LBL_text); V a_1 = v_t_2447; V r_ = (g_heff_2ecst_2echeckAltNames(a_0, a_1)); heff_drop(v_t_2447); r_; });
  return heff_tail(v_c_2448, 2, (V[]){v_hd_240, heff_clo(g_heff_2ecst_2edataDecl_lam18, 1, 6, (V[]){v_k_241, v_x_242, v_x_243, v_x_244, v_x_2424, v_x_2442})});
}
V g_heff_2ecst_2edataDecl_lam11(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2441;
  if (heff_strEq_c(heff_get(v_x_2427, LBL_text), ((V)&g_heff_2ecst_2edataDecl_str4))) {
    v_c_2441 = ((V)&g_heff_2ecst_2edataDecl_lam12_clo);
  } else {
    v_c_2441 = ((V)&g_heff_2ecst_2edataDecl_lam16_clo);
  }
  return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edataDecl_lam17, 1, 6, (V[]){v_x_243, v_hd_240, v_k_241, v_x_242, v_x_244, v_x_2424})});
}
V g_heff_2ecst_2edataDecl_lam10(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2ecst_2edataDecl_lam11, 1, 6, (V[]){v_hd_240, v_x_243, v_k_241, v_x_242, v_x_244, v_x_2424})});
}
V g_heff_2ecst_2edataDecl_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2423;
  if (heff_strEq_c(heff_get(heff_dup(v_x_247), LBL_text), ((V)&g_heff_2ecst_2edataDecl_str2))) {
    if (heff_strEq_c(heff_get(v_x_247, LBL_kind), ((V)&g_heff_2ecst_2edataDecl_str3))) {
      v_c_2423 = ((V)&g_heff_2ecst_2edataDecl_lam4_clo);
    } else {
      v_c_2423 = ((V)&g_heff_2ecst_2edataDecl_lam8_clo);
    }
  } else {
    heff_drop(v_x_247);
    v_c_2423 = ((V)&g_heff_2ecst_2edataDecl_lam9_clo);
  }
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edataDecl_lam10, 1, 5, (V[]){v_hd_240, v_x_243, v_k_241, v_x_242, v_x_244})});
}
V g_heff_2ecst_2edataDecl_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2edataDecl_lam3, 1, 5, (V[]){v_hd_240, v_x_243, v_k_241, v_x_242, v_x_244})});
}
V g_heff_2ecst_2edataDecl_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edataDecl_lam2, 1, 4, (V[]){v_hd_240, v_x_243, v_k_241, v_x_242})));
}
V g_heff_2ecst_2edataDecl_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectKind(((V)&g_heff_2ecst_2edataDecl_str0), ((V)&g_heff_2ecst_2edataDecl_str1), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2edataDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eexprF_24s1428526773x1081603075_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eexprF_24s1428526773x1081603075_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam5(V self, V *args);
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam4(V self, V *args);
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam3(V self, V *args);
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam2(V self, V *args);
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam1(V self, V *args);
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam0(V self, V *args);
Clo g_heff_2ecst_2eexprF_24s1428526773x1081603075_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eexprF_24s1428526773x1081603075_entry, 2, 0};

V g_heff_2ecst_2eexprF_24s1428526773x1081603075(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eexprF_24s1428526773x1081603075(a[0], a[1]);
}
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_Ann, 3, (V[]){v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexprF_24s504856081x2014933897(v_hd_240, heff_clo(g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam5, 1, 3, (V[]){v_k_241, v_x_246, v_x_2413})));
}
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get(heff_dup(v_x_249), LBL_text), ((V)&g_heff_2ecst_2eexprF_24s1428526773x1081603075_str0))) {
    if (heff_strEq_c(heff_get(v_x_249, LBL_kind), ((V)&g_heff_2ecst_2eexprF_24s1428526773x1081603075_str1))) {
      switch (heff_tag_of(v_x_2410)) {
      case TAG_True: {
        heff_drop(v_hd_240);
        V f_ = v_k_241;
        args[0] = v_x_246;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})));
      }
      default: return heff_nomatch(v_x_2410);
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop(v_hd_240);
      V f_ = v_k_241;
      args[0] = v_x_246;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_x_249);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_x_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam3, 1, 4, (V[]){v_x_249, v_k_241, v_x_246, v_hd_240})));
}
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})});
}
V g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245 = (g_heff_2ecst_2eexprHead_24s451872800x322153056(v_x_244));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eexprF_24s1428526773x1081603075_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2etypeDecl_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecst_2etypeDecl_str1 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 104, 101, 32, 110, 97, 109, 101, 32, 111, 102, 32, 97, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2etypeDecl_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
V g_heff_2ecst_2etypeDecl_lam4(V self, V *args);
V g_heff_2ecst_2etypeDecl_lam3(V self, V *args);
V g_heff_2ecst_2etypeDecl_lam2(V self, V *args);
V g_heff_2ecst_2etypeDecl_lam1(V self, V *args);
V g_heff_2ecst_2etypeDecl_lam0(V self, V *args);
Clo g_heff_2ecst_2etypeDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2etypeDecl_entry, 2, 0};

V g_heff_2ecst_2etypeDecl(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etypeDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2etypeDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2etypeDecl(a[0], a[1]);
}
V g_heff_2ecst_2etypeDecl_lam4(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_DType, 5, (V[]){v_x_242, v_x_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2etypeDecl_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_240, heff_clo(g_heff_2ecst_2etypeDecl_lam4, 1, 5, (V[]){v_k_241, v_x_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2ecst_2etypeDecl_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2etypeDecl_str2), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etypeDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243, v_x_244})));
}
V g_heff_2ecst_2etypeDecl_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etypeDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243})));
}
V g_heff_2ecst_2etypeDecl_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectKind(((V)&g_heff_2ecst_2etypeDecl_str0), ((V)&g_heff_2ecst_2etypeDecl_str1), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etypeDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2efieldDefault_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2efieldDefault_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
V g_heff_2ecst_2efieldDefault_lam3(V self, V *args);
V g_heff_2ecst_2efieldDefault_lam2(V self, V *args);
V g_heff_2ecst_2efieldDefault_lam1(V self, V *args);
V g_heff_2ecst_2efieldDefault_lam0(V self, V *args);
Clo g_heff_2ecst_2efieldDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2efieldDefault_entry, 2, 0};

V g_heff_2ecst_2efieldDefault(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2efieldDefault_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2efieldDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2efieldDefault(a[0], a[1]);
}
V g_heff_2ecst_2efieldDefault_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_248, v_x_249})});
  V f_ = v_k_241;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2efieldDefault_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_240, heff_clo(g_heff_2ecst_2efieldDefault_lam3, 1, 2, (V[]){v_x_248, v_k_241})));
}
V g_heff_2ecst_2efieldDefault_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2efieldDefault_str0))) {
    if (heff_strEq_c(heff_get(v_x_244, LBL_text), ((V)&g_heff_2ecst_2efieldDefault_str1))) {
      switch (heff_tag_of(v_x_245)) {
      case TAG_True: {
        heff_drop(v_hd_240);
        V f_ = v_k_241;
        args[0] = NTAG(TAG_Nothing);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2efieldDefault_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
      }
      default: return heff_nomatch(v_x_245);
      }
    } else {
      heff_drop(v_x_245);
      heff_drop(v_hd_240);
      V f_ = v_k_241;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_245);
    heff_drop(v_x_244);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecst_2efieldDefault_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2efieldDefault_lam1, 1, 3, (V[]){v_x_244, v_k_241, v_hd_240})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2etheoryField_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2etheoryField_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecst_2etheoryField_str2 = {{0x80000000u, K_STR, 0}, 24, 24, {97, 32, 102, 105, 101, 108, 100, 32, 105, 115, 32, 96, 110, 97, 109, 101, 32, 58, 32, 84, 121, 112, 101, 96}};
V g_heff_2ecst_2etheoryField_lam3(V self, V *args);
V g_heff_2ecst_2etheoryField_lam2(V self, V *args);
V g_heff_2ecst_2etheoryField_lam1(V self, V *args);
V g_heff_2ecst_2etheoryField_lam0(V self, V *args);
Clo g_heff_2ecst_2etheoryField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2etheoryField_entry, 2, 0};

V g_heff_2ecst_2etheoryField(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etheoryField_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2etheoryField_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2etheoryField(a[0], a[1]);
}
V g_heff_2ecst_2etheoryField_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_MkTF, 4, (V[]){v_x_242, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2etheoryField_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2efieldDefault(v_hd_240, heff_clo(g_heff_2ecst_2etheoryField_lam3, 1, 4, (V[]){v_k_241, v_x_242, v_x_245, v_x_246})));
}
V g_heff_2ecst_2etheoryField_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etheoryField_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_245})));
}
V g_heff_2ecst_2etheoryField_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244;
  if (heff_strEq_c(heff_get(heff_dup(v_x_242), LBL_kind), ((V)&g_heff_2ecst_2etheoryField_str0))) {
    v_x1_244 = NTAG(TAG_True);
  } else {
    v_x1_244 = heff_strEq(heff_get(heff_dup(v_x_242), LBL_kind), ((V)&g_heff_2ecst_2etheoryField_str1));
  }
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    return (g_heff_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etheoryField_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
  }
  case TAG_False: {
    V v_t_248 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_242), LBL_start), heff_get(v_x_242, LBL_end)});
    V v_t_249 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2etheoryField_str2), v_t_248, NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2411, v_k_241});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam0(V self, V *args); static Clo g_heff_2ecst_2eblockGo_24s570672665x991963980_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblockGo_24s570672665x991963980_lam0, 1, 0};
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam4(V self, V *args);
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam3(V self, V *args);
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam2(V self, V *args);
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam1(V self, V *args);
Clo g_heff_2ecst_2eblockGo_24s570672665x991963980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblockGo_24s570672665x991963980_entry, 4, 0};

V g_heff_2ecst_2eblockGo_24s570672665x991963980(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblockGo_24s570672665x991963980_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2eblockGo_24s570672665x991963980_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2ecst_2eblockGo_24s570672665x991963980_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eblockGo_24s570672665x991963980(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_244), LBL_toks), heff_get(heff_dup(v_s_244), LBL_i), heff_get(heff_dup(v_s_244), LBL_top), heff_get(heff_dup(v_s_244), LBL_stack), heff_get(v_s_244, LBL_i)});
}
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2ecst_2econtinuesBlock(v_x_2414, heff_dup(v_col_240)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    return (g_heff_2ecst_2eblockGo_24s570672665x991963980(v_col_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241}), v_hd_242, v_k_243));
  }
  case TAG_False: {
    heff_drop(v_col_240);
    heff_drop(v_hd_242);
    V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecst_2eblockGo_24s570672665x991963980_lam4, 1, 5, (V[]){v_col_240, v_x_2411, v_acc_241, v_hd_242, v_k_243})});
}
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  return (g_heff_2ecst_2etheoryField(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eblockGo_24s570672665x991963980_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2ecst_2eblockGo_24s570672665x991963980_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecst_2eblockGo_24s570672665x991963980_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eblock_24s354081874x470153967_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecst_2eblock_24s354081874x470153967_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {97, 32, 98, 108, 111, 99, 107, 32, 105, 115, 32, 101, 109, 112, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2ecst_2eblock_24s354081874x470153967_str2 = {{0x80000000u, K_STR, 0}, 43, 43, {97, 32, 98, 108, 111, 99, 107, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 100, 101, 110, 116, 101, 100, 32, 112, 97, 115, 116, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 115, 32, 105, 110}};
V g_heff_2ecst_2eblock_24s354081874x470153967_lam1(V self, V *args); static Clo g_heff_2ecst_2eblock_24s354081874x470153967_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_24s354081874x470153967_lam1, 1, 0};
V g_heff_2ecst_2eblock_24s354081874x470153967_lam3(V self, V *args);
V g_heff_2ecst_2eblock_24s354081874x470153967_lam7(V self, V *args); static Clo g_heff_2ecst_2eblock_24s354081874x470153967_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_24s354081874x470153967_lam7, 1, 0};
V g_heff_2ecst_2eblock_24s354081874x470153967_lam9(V self, V *args);
V g_heff_2ecst_2eblock_24s354081874x470153967_lam8(V self, V *args);
V g_heff_2ecst_2eblock_24s354081874x470153967_lam6(V self, V *args);
V g_heff_2ecst_2eblock_24s354081874x470153967_lam5(V self, V *args);
V g_heff_2ecst_2eblock_24s354081874x470153967_lam4(V self, V *args);
V g_heff_2ecst_2eblock_24s354081874x470153967_lam2(V self, V *args);
V g_heff_2ecst_2eblock_24s354081874x470153967_lam0(V self, V *args);
Clo g_heff_2ecst_2eblock_24s354081874x470153967_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_24s354081874x470153967_entry, 2, 0};

V g_heff_2ecst_2eblock_24s354081874x470153967(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eblock_24s354081874x470153967_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eblock_24s354081874x470153967(a[0], a[1]);
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_get(v_s_2410, LBL_stack);
  V v_x2_2414;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    v_x2_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    v_x2_2414 = heff_tag(TAG_Just, 1, (V[]){v_x_2412});
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_x_244, LBL_col), heff_get(heff_dup(v_s_2425), LBL_stack)});
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_2425), LBL_toks), heff_get(heff_dup(v_s_2425), LBL_i), heff_get(heff_dup(v_s_2425), LBL_top), v_t_2426, heff_get(v_s_2425, LBL_start)});
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_k_2435 = (g_list_2edrop(MK_INT(1LL), heff_get(heff_dup(v_s_2434), LBL_stack)));
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_2434), LBL_toks), heff_get(heff_dup(v_s_2434), LBL_i), heff_get(heff_dup(v_s_2434), LBL_top), v_k_2435, heff_get(v_s_2434, LBL_start)});
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V f_ = v_k_241;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_tag(TAG_Put, 2, (V[]){v_x_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2440, heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam9, 1, 2, (V[]){v_k_241, v_x_2433})});
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblock_24s354081874x470153967_lam7_clo)})});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2436}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2437, heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2433})});
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  return (g_heff_2ecst_2eblockGo_24s570672665x991963980(heff_get(v_x_244, LBL_col), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag(TAG_Put, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2431, heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam5, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_get(heff_dup(v_x_244), LBL_first);
  V v_t_2420;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    v_t_2420 = heff_intLe(heff_get(heff_dup(v_x_244), LBL_col), v_x_2418);
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2418);
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    V v_t_2421 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_2422 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eblock_24s354081874x470153967_str2), v_t_2421, NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2424, v_k_241});
  }
  case TAG_False: {
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam3, 1, 1, (V[]){heff_dup(v_x_244)})})});
    V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2427}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2428, heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam4, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241})});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ecst_2eblock_24s354081874x470153967_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2eblock_24s354081874x470153967_str0))) {
    V v_t_246 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_247 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eblock_24s354081874x470153967_str1), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_249, v_k_241});
  } else {
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblock_24s354081874x470153967_lam1_clo)})});
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2417, heff_clo(g_heff_2ecst_2eblock_24s354081874x470153967_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})});
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2etheoryDecl_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecst_2etheoryDecl_str1 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 104, 101, 32, 110, 97, 109, 101, 32, 111, 102, 32, 97, 32, 116, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2etheoryDecl_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 104, 101, 114, 101}};
V g_heff_2ecst_2etheoryDecl_lam4(V self, V *args);
V g_heff_2ecst_2etheoryDecl_lam3(V self, V *args);
V g_heff_2ecst_2etheoryDecl_lam2(V self, V *args);
V g_heff_2ecst_2etheoryDecl_lam1(V self, V *args);
V g_heff_2ecst_2etheoryDecl_lam0(V self, V *args);
Clo g_heff_2ecst_2etheoryDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2etheoryDecl_entry, 2, 0};

V g_heff_2ecst_2etheoryDecl(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etheoryDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2etheoryDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2etheoryDecl(a[0], a[1]);
}
V g_heff_2ecst_2etheoryDecl_lam4(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_DTheory, 5, (V[]){v_x_242, v_x_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2etheoryDecl_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eblock_24s354081874x470153967(v_hd_240, heff_clo(g_heff_2ecst_2etheoryDecl_lam4, 1, 5, (V[]){v_k_241, v_x_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2ecst_2etheoryDecl_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectKw(((V)&g_heff_2ecst_2etheoryDecl_str2), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etheoryDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243, v_x_244})));
}
V g_heff_2ecst_2etheoryDecl_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etheoryDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243})));
}
V g_heff_2ecst_2etheoryDecl_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectKind(((V)&g_heff_2ecst_2etheoryDecl_str0), ((V)&g_heff_2ecst_2etheoryDecl_str1), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2etheoryDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2eforeignDecl_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eforeignDecl_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecst_2eforeignDecl_str2 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 104, 101, 32, 112, 114, 105, 109, 105, 116, 105, 118, 101, 39, 115, 32, 110, 97, 109, 101}};
V g_heff_2ecst_2eforeignDecl_lam4(V self, V *args);
V g_heff_2ecst_2eforeignDecl_lam3(V self, V *args);
V g_heff_2ecst_2eforeignDecl_lam2(V self, V *args);
V g_heff_2ecst_2eforeignDecl_lam1(V self, V *args);
V g_heff_2ecst_2eforeignDecl_lam0(V self, V *args);
Clo g_heff_2ecst_2eforeignDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eforeignDecl_entry, 2, 0};

V g_heff_2ecst_2eforeignDecl(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eforeignDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2eforeignDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eforeignDecl(a[0], a[1]);
}
V g_heff_2ecst_2eforeignDecl_lam4(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_DForeign, 5, (V[]){v_x_242, v_x_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eforeignDecl_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_240, heff_clo(g_heff_2ecst_2eforeignDecl_lam4, 1, 5, (V[]){v_k_241, v_x_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2ecst_2eforeignDecl_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eforeignDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243, v_x_244})));
}
V g_heff_2ecst_2eforeignDecl_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectKind(((V)&g_heff_2ecst_2eforeignDecl_str1), ((V)&g_heff_2ecst_2eforeignDecl_str2), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eforeignDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243})));
}
V g_heff_2ecst_2eforeignDecl_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectKw(((V)&g_heff_2ecst_2eforeignDecl_str0), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eforeignDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eprimitiveDecl_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecst_2eprimitiveDecl_str1 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 104, 101, 32, 112, 114, 105, 109, 105, 116, 105, 118, 101, 39, 115, 32, 110, 97, 109, 101}};
V g_heff_2ecst_2eprimitiveDecl_lam3(V self, V *args);
V g_heff_2ecst_2eprimitiveDecl_lam2(V self, V *args);
V g_heff_2ecst_2eprimitiveDecl_lam1(V self, V *args);
V g_heff_2ecst_2eprimitiveDecl_lam0(V self, V *args);
Clo g_heff_2ecst_2eprimitiveDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eprimitiveDecl_entry, 2, 0};

V g_heff_2ecst_2eprimitiveDecl(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecst_2enext(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eprimitiveDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecst_2eprimitiveDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eprimitiveDecl(a[0], a[1]);
}
V g_heff_2ecst_2eprimitiveDecl_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag(TAG_DPrimitive, 4, (V[]){v_x_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eprimitiveDecl_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_240, heff_clo(g_heff_2ecst_2eprimitiveDecl_lam3, 1, 4, (V[]){v_k_241, v_x_242, v_x_243, v_x_244})));
}
V g_heff_2ecst_2eprimitiveDecl_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eprimitiveDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243})));
}
V g_heff_2ecst_2eprimitiveDecl_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectKind(((V)&g_heff_2ecst_2eprimitiveDecl_str0), ((V)&g_heff_2ecst_2eprimitiveDecl_str1), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eprimitiveDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2efixityRest_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
V g_heff_2ecst_2efixityRest_lam1(V self, V *args);
V g_heff_2ecst_2efixityRest_lam2(V self, V *args);
V g_heff_2ecst_2efixityRest_lam0(V self, V *args);
Clo g_heff_2ecst_2efixityRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2efixityRest_entry, 3, 0};

V g_heff_2ecst_2efixityRest(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_243}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_244, heff_clo(g_heff_2ecst_2efixityRest_lam0, 1, 3, (V[]){v_acc_240, v_k_242, v_hd_241})});
}
V g_heff_2ecst_2efixityRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2efixityRest(a[0], a[1], a[2]);
}
V g_heff_2ecst_2efixityRest_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2efixityRest(heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2ecst_2efixityRest_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2efixityRest(heff_tag(TAG_Cons, 2, (V[]){v_x_2412, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2ecst_2efixityRest_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get(heff_dup(v_x_245), LBL_kind), ((V)&g_heff_2ecst_2efixityRest_str0))) {
    heff_drop(v_x_245);
    heff_drop(v_hd_241);
    V v_x_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_248 = heff_get(heff_dup(v_x_245), LBL_first);
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      if (heff_intEq_c(heff_get(v_x_245, LBL_col), MK_INT(0LL))) {
        heff_drop(v_hd_241);
        V v_x_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
        V f_ = v_k_242;
        args[0] = v_x_2410;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2efixityRest_lam1, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
      }
    }
    case TAG_False: {
      heff_drop(v_x_245);
      return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2efixityRest_lam2, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclNameLen_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclNameLen_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edeclNameLen_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclNameLen_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edeclNameLen_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2ecst_2edeclNameLen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclNameLen_entry, 3, 0};

V g_heff_2ecst_2edeclNameLen(V v_t_240, V v_t2_241, V v_t3_242) {
top: ;
  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclNameLen_str0))) {
    heff_drop(v_t_240);
    heff_drop(v_t2_241);
    heff_drop(v_t3_242);
    return MK_INT(1LL);
  } else {
    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclNameLen_str1))) {
      heff_drop(v_t_240);
      heff_drop(v_t2_241);
      heff_drop(v_t3_242);
      return MK_INT(1LL);
    } else {
      if (heff_strEq_c(heff_get(v_t_240, LBL_text), ((V)&g_heff_2ecst_2edeclNameLen_str2))) {
        if (heff_strEq_c(heff_get(heff_dup(v_t2_241), LBL_kind), ((V)&g_heff_2ecst_2edeclNameLen_str3))) {
          V v_t_247 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_t2_241, LBL_text)}));
          V v_x1_248 = ({ V a_0 = v_t_247; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_x1_248)) {
          case TAG_True: {
            heff_drop(v_t3_242);
            return MK_INT(0LL);
          }
          case TAG_False: {
            if (heff_strEq_c(heff_get(v_t3_242, LBL_text), ((V)&g_heff_2ecst_2edeclNameLen_str4))) {
              return MK_INT(3LL);
            } else {
              return MK_INT(0LL);
            }
          }
          default: return heff_nomatch(v_x1_248);
          }
        } else {
          heff_drop(v_t2_241);
          heff_drop(v_t3_242);
          return MK_INT(0LL);
        }
      } else {
        heff_drop(v_t2_241);
        heff_drop(v_t3_242);
        return MK_INT(0LL);
      }
    }
  }
}
V g_heff_2ecst_2edeclNameLen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edeclNameLen(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2ecst_2esigOrEqn_str0 = {{0x80000000u, K_STR, 0}, 33, 33, {97, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110, 32, 99, 97, 110, 110, 111, 116, 32, 115, 116, 97, 114, 116, 32, 119, 105, 116, 104, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2esigOrEqn_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2esigOrEqn_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2esigOrEqn_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2esigOrEqn_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2esigOrEqn_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 104, 101, 114, 101}};
V g_heff_2ecst_2esigOrEqn_lam0(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_lam0, 1, 0};
V g_heff_2ecst_2esigOrEqn_lam2(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_lam2, 1, 0};
V g_heff_2ecst_2esigOrEqn_lam5(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam4(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam9(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam8(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam7(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam17(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam16(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam15(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam18(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_lam18, 2, 0};
V g_heff_2ecst_2esigOrEqn_lam19(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_lam19, 2, 0};
V g_heff_2ecst_2esigOrEqn_lam20(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam14(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam13(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam12(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam11(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam10(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam6(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam3(V self, V *args);
V g_heff_2ecst_2esigOrEqn_lam1(V self, V *args);
Clo g_heff_2ecst_2esigOrEqn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_entry, 4, 0};

V g_heff_2ecst_2esigOrEqn(V v_item_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2esigOrEqn_lam0_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecst_2esigOrEqn_lam1, 1, 4, (V[]){v_hd_242, v_t_241, v_k_243, v_item_240})});
}
V g_heff_2ecst_2esigOrEqn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2esigOrEqn(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2esigOrEqn_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_t_245 = heff_intAdd(heff_get(heff_dup(v_s_244), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_244, v_t_245));
}
V g_heff_2ecst_2esigOrEqn_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_get(heff_dup(v_s_249), LBL_i), MK_INT(2LL));
  return (g_heff_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2ecst_2esigOrEqn_lam5(V self, V *args) {
  V v_s_2424 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_intAdd(heff_get(heff_dup(v_s_2424), LBL_i), v_k_2421);
  return (g_heff_2ecst_2etokAt(v_s_2424, v_t_2425));
}
V g_heff_2ecst_2esigOrEqn_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k2_2423 = args[1];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2ecst_2esigOrEqn_lam5, 1, 1, (V[]){v_k_2421})})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2422, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2423;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2esigOrEqn_lam9(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  args[0] = heff_tag(TAG_DSig, 3, (V[]){v_x_2433, v_x_2434, v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_242, heff_clo(g_heff_2ecst_2esigOrEqn_lam9, 1, 3, (V[]){v_k_243, v_x_2433, v_x_2434})));
}
V g_heff_2ecst_2esigOrEqn_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2esigOrEqn_lam8, 1, 3, (V[]){v_hd_242, v_k_243, v_x_2433})));
}
V g_heff_2ecst_2esigOrEqn_lam17(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2449 = heff_env(self)[0];
  V v_k_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2449, v_x_2450})});
  V f_ = v_k_2448;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_lam16(V self, V *args) {
  V v_x_2449 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_k_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eblock(v_item_240, v_hd_2447, heff_clo(g_heff_2ecst_2esigOrEqn_lam17, 1, 2, (V[]){v_x_2449, v_k_2448})));
}
V g_heff_2ecst_2esigOrEqn_lam15(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2447), heff_clo(g_heff_2ecst_2esigOrEqn_lam16, 1, 3, (V[]){v_item_240, v_hd_2447, v_k_2448})));
}
V g_heff_2ecst_2esigOrEqn_lam18(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_lam19(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  heff_drop(v_hd_2454);
  V f_ = v_k_2455;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_lam20(V self, V *args) {
  V v_x_2457 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_2438 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_x_2440 = heff_env(self)[3];
  V v_x_2441 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_243;
  args[0] = heff_tag(TAG_DEqn, 5, (V[]){v_x_2438, v_x_2439, v_x_2440, v_x_2441, v_x_2457});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_lam14(V self, V *args) {
  V v_x_2444 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  V v_x_2440 = heff_env(self)[5];
  V v_x_2441 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2456;
  if (heff_strEq_c(heff_get(heff_dup(v_x_2444), LBL_kind), ((V)&g_heff_2ecst_2esigOrEqn_str4))) {
    if (heff_strEq_c(heff_get(v_x_2444, LBL_text), ((V)&g_heff_2ecst_2esigOrEqn_str5))) {
      v_c_2456 = heff_clo(g_heff_2ecst_2esigOrEqn_lam15, 2, 1, (V[]){v_item_240});
    } else {
      heff_drop(v_item_240);
      v_c_2456 = ((V)&g_heff_2ecst_2esigOrEqn_lam18_clo);
    }
  } else {
    heff_drop(v_x_2444);
    heff_drop(v_item_240);
    v_c_2456 = ((V)&g_heff_2ecst_2esigOrEqn_lam19_clo);
  }
  return heff_tail(v_c_2456, 2, (V[]){v_hd_242, heff_clo(g_heff_2ecst_2esigOrEqn_lam20, 1, 5, (V[]){v_k_243, v_x_2438, v_x_2439, v_x_2440, v_x_2441})});
}
V g_heff_2ecst_2esigOrEqn_lam13(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  V v_x_2440 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2442}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2443, heff_clo(g_heff_2ecst_2esigOrEqn_lam14, 1, 7, (V[]){v_item_240, v_hd_242, v_k_243, v_x_2438, v_x_2439, v_x_2440, v_x_2441})});
}
V g_heff_2ecst_2esigOrEqn_lam12(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2esigOrEqn_lam13, 1, 6, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2438, v_x_2439, v_x_2440})));
}
V g_heff_2ecst_2esigOrEqn_lam11(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2esigOrEqn_str3), heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2esigOrEqn_lam12, 1, 5, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2438, v_x_2439})));
}
V g_heff_2ecst_2esigOrEqn_lam10(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2emanyGo(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_patAtom), NTAG(TAG_Nil), heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2esigOrEqn_lam11, 1, 4, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2438})));
}
V g_heff_2ecst_2esigOrEqn_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_item_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get(v_x_2429, LBL_text), ((V)&g_heff_2ecst_2esigOrEqn_str2))) {
    heff_drop(v_item_240);
    V v_t_2431 = (g_heff_2ecst_2edeclNameLen(v_t_241, v_x_248, v_x_2413));
    V v_c_2432 = heff_tr(heff_apply(((V)&g_heff_2ecst_2enextN_clo), 1, (V[]){v_t_2431}));
    return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2esigOrEqn_lam7, 1, 2, (V[]){v_hd_242, v_k_243})});
  } else {
    V v_t_2436 = (g_heff_2ecst_2edeclNameLen(v_t_241, v_x_248, v_x_2413));
    V v_c_2437 = heff_tr(heff_apply(((V)&g_heff_2ecst_2enextN_clo), 1, (V[]){v_t_2436}));
    return heff_tail(v_c_2437, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2esigOrEqn_lam10, 1, 3, (V[]){v_hd_242, v_item_240, v_k_243})});
  }
}
V g_heff_2ecst_2esigOrEqn_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_item_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = (g_heff_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
  if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
    heff_drop(v_x_2413);
    heff_drop(v_x_248);
    heff_drop(v_item_240);
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecst_2esigOrEqn_str0), heff_strAppend(heff_get(heff_dup(v_t_241), LBL_text), ((V)&g_heff_2ecst_2esigOrEqn_str1)));
    V v_t_2417 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_t_241), LBL_start), heff_get(v_t_241, LBL_end)});
    V v_t_2418 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2416, v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2419}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2420, v_k_243});
  } else {
    V v_k_2421 = (g_heff_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
    V v_c_2428 = heff_clo(g_heff_2ecst_2esigOrEqn_lam4, 2, 1, (V[]){v_k_2421});
    return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2esigOrEqn_lam6, 1, 6, (V[]){v_t_241, v_x_248, v_x_2413, v_hd_242, v_k_243, v_item_240})});
  }
}
V g_heff_2ecst_2esigOrEqn_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2esigOrEqn_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecst_2esigOrEqn_lam3, 1, 5, (V[]){v_t_241, v_x_248, v_hd_242, v_k_243, v_item_240})});
}
V g_heff_2ecst_2elocalDecl_lam0(V self, V *args);
Clo g_heff_2ecst_2elocalDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elocalDecl_entry, 2, 0};

V g_heff_2ecst_2elocalDecl(V v_st_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_st_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_st_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2elocalDecl_lam0, 1, 2, (V[]){v_st_240, v_k_241})});
}
V g_heff_2ecst_2elocalDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elocalDecl(a[0], a[1]);
}
V g_heff_2ecst_2elocalDecl_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2esigOrEqn(((V)&g_heff_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
}
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam0(V self, V *args); static Clo g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam0, 1, 0};
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam4(V self, V *args);
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam3(V self, V *args);
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam2(V self, V *args);
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam1(V self, V *args);
Clo g_heff_2ecst_2eblockGo_24s1300006556x200850327_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblockGo_24s1300006556x200850327_entry, 4, 0};

V g_heff_2ecst_2eblockGo_24s1300006556x200850327(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eblockGo_24s1300006556x200850327(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_244), LBL_toks), heff_get(heff_dup(v_s_244), LBL_i), heff_get(heff_dup(v_s_244), LBL_top), heff_get(heff_dup(v_s_244), LBL_stack), heff_get(v_s_244, LBL_i)});
}
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2ecst_2econtinuesBlock(v_x_2414, heff_dup(v_col_240)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    return (g_heff_2ecst_2eblockGo_24s1300006556x200850327(v_col_240, heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241}), v_hd_242, v_k_243));
  }
  case TAG_False: {
    heff_drop(v_col_240);
    heff_drop(v_hd_242);
    V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam4, 1, 5, (V[]){v_col_240, v_x_2411, v_acc_241, v_hd_242, v_k_243})});
}
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  return (g_heff_2ecst_2elocalDecl(heff_dup(v_hd_242), heff_clo(g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecst_2eblockGo_24s1300006556x200850327_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eblock_24s57540649x559838160_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecst_2eblock_24s57540649x559838160_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {97, 32, 98, 108, 111, 99, 107, 32, 105, 115, 32, 101, 109, 112, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2ecst_2eblock_24s57540649x559838160_str2 = {{0x80000000u, K_STR, 0}, 43, 43, {97, 32, 98, 108, 111, 99, 107, 32, 109, 117, 115, 116, 32, 98, 101, 32, 105, 110, 100, 101, 110, 116, 101, 100, 32, 112, 97, 115, 116, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 115, 32, 105, 110}};
V g_heff_2ecst_2eblock_24s57540649x559838160_lam1(V self, V *args); static Clo g_heff_2ecst_2eblock_24s57540649x559838160_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_24s57540649x559838160_lam1, 1, 0};
V g_heff_2ecst_2eblock_24s57540649x559838160_lam3(V self, V *args);
V g_heff_2ecst_2eblock_24s57540649x559838160_lam7(V self, V *args); static Clo g_heff_2ecst_2eblock_24s57540649x559838160_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_24s57540649x559838160_lam7, 1, 0};
V g_heff_2ecst_2eblock_24s57540649x559838160_lam9(V self, V *args);
V g_heff_2ecst_2eblock_24s57540649x559838160_lam8(V self, V *args);
V g_heff_2ecst_2eblock_24s57540649x559838160_lam6(V self, V *args);
V g_heff_2ecst_2eblock_24s57540649x559838160_lam5(V self, V *args);
V g_heff_2ecst_2eblock_24s57540649x559838160_lam4(V self, V *args);
V g_heff_2ecst_2eblock_24s57540649x559838160_lam2(V self, V *args);
V g_heff_2ecst_2eblock_24s57540649x559838160_lam0(V self, V *args);
Clo g_heff_2ecst_2eblock_24s57540649x559838160_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eblock_24s57540649x559838160_entry, 2, 0};

V g_heff_2ecst_2eblock_24s57540649x559838160(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_242}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_243, heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eblock_24s57540649x559838160_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eblock_24s57540649x559838160(a[0], a[1]);
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_get(v_s_2410, LBL_stack);
  V v_x2_2414;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    v_x2_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    v_x2_2414 = heff_tag(TAG_Just, 1, (V[]){v_x_2412});
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_x_244, LBL_col), heff_get(heff_dup(v_s_2425), LBL_stack)});
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_2425), LBL_toks), heff_get(heff_dup(v_s_2425), LBL_i), heff_get(heff_dup(v_s_2425), LBL_top), v_t_2426, heff_get(v_s_2425, LBL_start)});
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_k_2435 = (g_list_2edrop(MK_INT(1LL), heff_get(heff_dup(v_s_2434), LBL_stack)));
  return heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_2434), LBL_toks), heff_get(heff_dup(v_s_2434), LBL_i), heff_get(heff_dup(v_s_2434), LBL_top), v_k_2435, heff_get(v_s_2434, LBL_start)});
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V f_ = v_k_241;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_tag(TAG_Put, 2, (V[]){v_x_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2440, heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam9, 1, 2, (V[]){v_k_241, v_x_2433})});
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblock_24s57540649x559838160_lam7_clo)})});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2436}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2437, heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2433})});
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  return (g_heff_2ecst_2eblockGo_24s1300006556x200850327(heff_get(v_x_244, LBL_col), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag(TAG_Put, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2431, heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam5, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})});
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_get(heff_dup(v_x_244), LBL_first);
  V v_t_2420;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    v_t_2420 = heff_intLe(heff_get(heff_dup(v_x_244), LBL_col), v_x_2418);
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2418);
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    V v_t_2421 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_2422 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eblock_24s57540649x559838160_str2), v_t_2421, NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2424, v_k_241});
  }
  case TAG_False: {
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam3, 1, 1, (V[]){heff_dup(v_x_244)})})});
    V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2427}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2428, heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam4, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241})});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ecst_2eblock_24s57540649x559838160_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_kind), ((V)&g_heff_2ecst_2eblock_24s57540649x559838160_str0))) {
    V v_t_246 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_247 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2ecst_2eblock_24s57540649x559838160_str1), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_249, v_k_241});
  } else {
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2eblock_24s57540649x559838160_lam1_clo)})});
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2417, heff_clo(g_heff_2ecst_2eblock_24s57540649x559838160_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})});
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str0 = {{0x80000000u, K_STR, 0}, 33, 33, {97, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110, 32, 99, 97, 110, 110, 111, 116, 32, 115, 116, 97, 114, 116, 32, 119, 105, 116, 104, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 104, 101, 114, 101}};
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam0(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam0, 1, 0};
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam2(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam2, 1, 0};
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam5(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam4(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam9(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam8(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam7(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam17(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam16(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam15(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam15, 2, 0};
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam18(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam18, 2, 0};
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam19(V self, V *args); static Clo g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam19, 2, 0};
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam20(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam14(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam13(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam12(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam11(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam10(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam6(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam3(V self, V *args);
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam1(V self, V *args);
Clo g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_entry, 3, 0};

V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291(V v_t_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam0_clo)})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam1, 1, 3, (V[]){v_hd_241, v_t_240, v_k_242})});
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2esigOrEqn_24s427219686x1642480291(a[0], a[1], a[2]);
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_t_244 = heff_intAdd(heff_get(heff_dup(v_s_243), LBL_i), MK_INT(1LL));
  return (g_heff_2ecst_2etokAt(v_s_243, v_t_244));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_get(heff_dup(v_s_248), LBL_i), MK_INT(2LL));
  return (g_heff_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam5(V self, V *args) {
  V v_s_2423 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_intAdd(heff_get(heff_dup(v_s_2423), LBL_i), v_k_2420);
  return (g_heff_2ecst_2etokAt(v_s_2423, v_t_2424));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam5, 1, 1, (V[]){v_k_2420})})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2425}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2426;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam9(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_DSig, 3, (V[]){v_x_2432, v_x_2433, v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_241, heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam9, 1, 3, (V[]){v_k_242, v_x_2432, v_x_2433})));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2enext(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam8, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2432})));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam17(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2448, v_x_2449})});
  V f_ = v_k_2447;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam16(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_2446 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eblock_24s57540649x559838160(v_hd_2446, heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam17, 1, 2, (V[]){v_x_2448, v_k_2447})));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam15(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2446), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam16, 1, 2, (V[]){v_hd_2446, v_k_2447})));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam18(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam19(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  heff_drop(v_hd_2453);
  V f_ = v_k_2454;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam20(V self, V *args) {
  V v_x_2456 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_x_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_DEqn, 5, (V[]){v_x_2437, v_x_2438, v_x_2439, v_x_2440, v_x_2456});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam14(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  V v_x_2440 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2455;
  if (heff_strEq_c(heff_get(heff_dup(v_x_2443), LBL_kind), ((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str4))) {
    if (heff_strEq_c(heff_get(v_x_2443, LBL_text), ((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str5))) {
      v_c_2455 = ((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam15_clo);
    } else {
      v_c_2455 = ((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam18_clo);
    }
  } else {
    heff_drop(v_x_2443);
    v_c_2455 = ((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam19_clo);
  }
  return heff_tail(v_c_2455, 2, (V[]){v_hd_241, heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam20, 1, 5, (V[]){v_k_242, v_x_2437, v_x_2438, v_x_2439, v_x_2440})});
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam13(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2ecur_clo)})});
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2441}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2442, heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam14, 1, 6, (V[]){v_hd_241, v_k_242, v_x_2437, v_x_2438, v_x_2439, v_x_2440})});
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam12(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam13, 1, 5, (V[]){v_hd_241, v_k_242, v_x_2437, v_x_2438, v_x_2439})));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecst_2eexpectSym(((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str3), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam12, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2437, v_x_2438})));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam10(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2emanyGo(heff_get(heff_dup(g_heff_2ecst_2egram_get()), LBL_patAtom), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam11, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2437})));
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get(v_x_2428, LBL_text), ((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str2))) {
    V v_t_2430 = (g_heff_2ecst_2edeclNameLen(v_t_240, v_x_247, v_x_2412));
    V v_c_2431 = heff_tr(heff_apply(((V)&g_heff_2ecst_2enextN_clo), 1, (V[]){v_t_2430}));
    return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam7, 1, 2, (V[]){v_hd_241, v_k_242})});
  } else {
    V v_t_2435 = (g_heff_2ecst_2edeclNameLen(v_t_240, v_x_247, v_x_2412));
    V v_c_2436 = heff_tr(heff_apply(((V)&g_heff_2ecst_2enextN_clo), 1, (V[]){v_t_2435}));
    return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam10, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = (g_heff_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_247), heff_dup(v_x_2412)));
  if (heff_intEq_c(v_t_2413, MK_INT(0LL))) {
    heff_drop(v_x_2412);
    heff_drop(v_x_247);
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str0), heff_strAppend(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_str1)));
    V v_t_2416 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_t_240), LBL_start), heff_get(v_t_240, LBL_end)});
    V v_t_2417 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2415, v_t_2416, NTAG(TAG_Nothing)});
    V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Throw, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2418}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2419, v_k_242});
  } else {
    V v_k_2420 = (g_heff_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_247), heff_dup(v_x_2412)));
    V v_c_2427 = heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam4, 2, 1, (V[]){v_k_2420});
    return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam6, 1, 5, (V[]){v_t_240, v_x_247, v_x_2412, v_hd_241, v_k_242})});
  }
}
V g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam2_clo)})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_lam3, 1, 4, (V[]){v_t_240, v_x_247, v_hd_241, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2edeclAt_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2edeclAt_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {100, 97, 116, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2edeclAt_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2edeclAt_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecst_2edeclAt_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 111, 114, 101, 105, 103, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecst_2edeclAt_str10 = {{0x80000000u, K_STR, 0}, 9, 9, {112, 114, 105, 109, 105, 116, 105, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2edeclAt_str12 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2edeclAt_str14 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2edeclAt_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2edeclAt_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2edeclAt_str20 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2edeclAt_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str23 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2edeclAt_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclAt_str25 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2edeclAt_str26 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclAt_str27 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecst_2edeclAt_str28 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 32, 116, 101, 115, 116, 39, 115, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2edeclAt_str29 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecst_2edeclAt_str30 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 97, 116, 99, 104}};
V g_heff_2ecst_2edeclAt_lam1(V self, V *args);
V g_heff_2ecst_2edeclAt_lam0(V self, V *args); static Clo g_heff_2ecst_2edeclAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclAt_lam0, 2, 0};
V g_heff_2ecst_2edeclAt_lam4(V self, V *args);
V g_heff_2ecst_2edeclAt_lam3(V self, V *args);
V g_heff_2ecst_2edeclAt_lam2(V self, V *args); static Clo g_heff_2ecst_2edeclAt_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclAt_lam2, 2, 0};
V g_heff_2ecst_2edeclAt_lam7(V self, V *args);
V g_heff_2ecst_2edeclAt_lam6(V self, V *args);
V g_heff_2ecst_2edeclAt_lam5(V self, V *args); static Clo g_heff_2ecst_2edeclAt_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclAt_lam5, 2, 0};
V g_heff_2ecst_2edeclAt_lam10(V self, V *args);
V g_heff_2ecst_2edeclAt_lam9(V self, V *args);
V g_heff_2ecst_2edeclAt_lam8(V self, V *args); static Clo g_heff_2ecst_2edeclAt_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclAt_lam8, 2, 0};
V g_heff_2ecst_2edeclAt_lam13(V self, V *args);
V g_heff_2ecst_2edeclAt_lam12(V self, V *args);
V g_heff_2ecst_2edeclAt_lam11(V self, V *args); static Clo g_heff_2ecst_2edeclAt_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclAt_lam11, 2, 0};
Clo g_heff_2ecst_2edeclAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclAt_entry, 1, 0};

V g_heff_2ecst_2edeclAt(V v_t_240) {
top: ;
  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str0))) {
    heff_drop(v_t_240);
    return ((V)&g_heff_2ecst_2edeclAt_lam0_clo);
  } else {
    V v_t_246;
    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str1))) {
      v_t_246 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str2));
    } else {
      v_t_246 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_240);
      return ((V)&g_heff_2ecst_2edataDecl_clo);
    }
    case TAG_False: {
      V v_t_248;
      if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str3))) {
        v_t_248 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str4));
      } else {
        v_t_248 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_t_240);
        return ((V)&g_heff_2ecst_2etypeDecl_clo);
      }
      case TAG_False: {
        V v_t_2410;
        if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str5))) {
          v_t_2410 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str6));
        } else {
          v_t_2410 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2410)) {
        case TAG_True: {
          heff_drop(v_t_240);
          return ((V)&g_heff_2ecst_2etheoryDecl_clo);
        }
        case TAG_False: {
          V v_t_2412;
          if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str7))) {
            v_t_2412 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str8));
          } else {
            v_t_2412 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2412)) {
          case TAG_True: {
            heff_drop(v_t_240);
            return ((V)&g_heff_2ecst_2eforeignDecl_clo);
          }
          case TAG_False: {
            V v_t_2414;
            if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str9))) {
              v_t_2414 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str10));
            } else {
              v_t_2414 = NTAG(TAG_False);
            }
            switch (heff_tag_of(v_t_2414)) {
            case TAG_True: {
              heff_drop(v_t_240);
              return ((V)&g_heff_2ecst_2eprimitiveDecl_clo);
            }
            case TAG_False: {
              V v_t_2425;
              if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str11))) {
                if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str12))) {
                  v_t_2425 = NTAG(TAG_True);
                } else {
                  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str13))) {
                    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str14))) {
                      v_t_2425 = NTAG(TAG_True);
                    } else {
                      if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str15))) {
                        v_t_2425 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str16));
                      } else {
                        v_t_2425 = NTAG(TAG_False);
                      }
                    }
                  } else {
                    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str17))) {
                      v_t_2425 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str18));
                    } else {
                      v_t_2425 = NTAG(TAG_False);
                    }
                  }
                }
              } else {
                if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str19))) {
                  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str20))) {
                    v_t_2425 = NTAG(TAG_True);
                  } else {
                    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str21))) {
                      v_t_2425 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str22));
                    } else {
                      v_t_2425 = NTAG(TAG_False);
                    }
                  }
                } else {
                  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str23))) {
                    v_t_2425 = heff_strEq(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str24));
                  } else {
                    v_t_2425 = NTAG(TAG_False);
                  }
                }
              }
              switch (heff_tag_of(v_t_2425)) {
              case TAG_True: {
                heff_drop(v_t_240);
                return ((V)&g_heff_2ecst_2edeclAt_lam2_clo);
              }
              case TAG_False: {
                if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str25))) {
                  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclAt_str26))) {
                    heff_drop(v_t_240);
                    return ((V)&g_heff_2ecst_2edeclAt_lam5_clo);
                  } else {
                    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str29))) {
                      heff_drop(v_t_240);
                      return ((V)&g_heff_2ecst_2edeclAt_lam8_clo);
                    } else {
                      return heff_tail(((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_clo), 1, (V[]){v_t_240});
                    }
                  }
                } else {
                  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclAt_str30))) {
                    heff_drop(v_t_240);
                    return ((V)&g_heff_2ecst_2edeclAt_lam11_clo);
                  } else {
                    return heff_tail(((V)&g_heff_2ecst_2esigOrEqn_24s427219686x1642480291_clo), 1, (V[]){v_t_240});
                  }
                }
              }
              default: return heff_nomatch(v_t_2425);
              }
            }
            default: return heff_nomatch(v_t_2414);
            }
          }
          default: return heff_nomatch(v_t_2412);
          }
        }
        default: return heff_nomatch(v_t_2410);
        }
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2ecst_2edeclAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edeclAt(a[0]);
}
V g_heff_2ecst_2edeclAt_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = heff_tag(TAG_DImport, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edeclAt_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  return (g_heff_2ecst_2enext(v_hd_242, heff_clo(g_heff_2ecst_2edeclAt_lam1, 1, 1, (V[]){v_k_243})));
}
V g_heff_2ecst_2edeclAt_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2427 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2427;
  args[0] = heff_tag(TAG_DFixity, 2, (V[]){v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edeclAt_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2efixityRest(NTAG(TAG_Nil), v_hd_2426, heff_clo(g_heff_2ecst_2edeclAt_lam4, 1, 2, (V[]){v_k_2427, v_x_2428})));
}
V g_heff_2ecst_2edeclAt_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2426), heff_clo(g_heff_2ecst_2edeclAt_lam3, 1, 2, (V[]){v_hd_2426, v_k_2427})));
}
V g_heff_2ecst_2edeclAt_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2433 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2433;
  args[0] = heff_tag(TAG_DTest, 2, (V[]){v_x_2434, v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edeclAt_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexpectKind(((V)&g_heff_2ecst_2edeclAt_str27), ((V)&g_heff_2ecst_2edeclAt_str28), v_hd_2432, heff_clo(g_heff_2ecst_2edeclAt_lam7, 1, 2, (V[]){v_k_2433, v_x_2434})));
}
V g_heff_2ecst_2edeclAt_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2432), heff_clo(g_heff_2ecst_2edeclAt_lam6, 1, 2, (V[]){v_hd_2432, v_k_2433})));
}
V g_heff_2ecst_2edeclAt_lam10(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_2438 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2438;
  args[0] = heff_tag(TAG_DWatch, 2, (V[]){v_x_2439, v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edeclAt_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2437 = heff_env(self)[0];
  V v_k_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_2437, heff_clo(g_heff_2ecst_2edeclAt_lam10, 1, 2, (V[]){v_k_2438, v_x_2439})));
}
V g_heff_2ecst_2edeclAt_lam8(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2437), heff_clo(g_heff_2ecst_2edeclAt_lam9, 1, 2, (V[]){v_hd_2437, v_k_2438})));
}
V g_heff_2ecst_2edeclAt_lam13(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2443 = heff_env(self)[0];
  V v_x_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2443;
  args[0] = heff_tag(TAG_DWatch, 2, (V[]){v_x_2444, v_x_2445});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecst_2edeclAt_lam12(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2442 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecst_2eexprF_24s1428526773x1081603075(v_hd_2442, heff_clo(g_heff_2ecst_2edeclAt_lam13, 1, 2, (V[]){v_k_2443, v_x_2444})));
}
V g_heff_2ecst_2edeclAt_lam11(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  return (g_heff_2ecst_2enext(heff_dup(v_hd_2442), heff_clo(g_heff_2ecst_2edeclAt_lam12, 1, 2, (V[]){v_hd_2442, v_k_2443})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eskipFrom_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
Clo g_heff_2ecst_2eskipFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eskipFrom_entry, 1, 0};

V g_heff_2ecst_2eskipFrom(V v_s_240) {
top: ;
  V v_t_241 = (g_heff_2ecst_2etokAt(heff_dup(v_s_240), heff_get(heff_dup(v_s_240), LBL_i)));
  if (heff_strEq_c(heff_get(v_t_241, LBL_kind), ((V)&g_heff_2ecst_2eskipFrom_str0))) {
    return v_s_240;
  } else {
    V v_t_243 = heff_intAdd(heff_get(heff_dup(v_s_240), LBL_i), MK_INT(1LL));
    V v_t_244 = heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_240), LBL_toks), v_t_243, heff_get(heff_dup(v_s_240), LBL_top), heff_get(heff_dup(v_s_240), LBL_stack), heff_get(v_s_240, LBL_start)});
    V t_0 = v_t_244;
    v_s_240 = t_0;
    goto top;
  }
}
V g_heff_2ecst_2eskipFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eskipFrom(a[0]);
}
Clo g_heff_2ecst_2eskipDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eskipDecl_entry, 1, 0};

V g_heff_2ecst_2eskipDecl(V v_s_240) {
top: ;
  V v_t_241 = heff_intAdd(heff_get(heff_dup(v_s_240), LBL_top), MK_INT(1LL));
  V v_i_243;
  if (heff_intLt_c(heff_get(heff_dup(v_s_240), LBL_i), v_t_241)) {
    v_i_243 = heff_intAdd(heff_get(heff_dup(v_s_240), LBL_top), MK_INT(1LL));
  } else {
    v_i_243 = heff_get(heff_dup(v_s_240), LBL_i);
  }
  V v_s_244 = heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_240), LBL_toks), v_i_243, heff_get(heff_dup(v_s_240), LBL_top), heff_get(heff_dup(v_s_240), LBL_stack), heff_get(v_s_240, LBL_start)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_246 = heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_244), LBL_toks), heff_get(heff_dup(v_s_244), LBL_i), heff_get(heff_dup(v_s_244), LBL_top), v_t_245, heff_get(v_s_244, LBL_start)});
  HEFF_LAST return g_heff_2ecst_2eskipFrom(v_t_246);
}
V g_heff_2ecst_2eskipDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eskipDecl(a[0]);
}
V g_heff_2ecst_2erunP_24s1504380254x1312992993_lam0(V self, V *args); static Clo g_heff_2ecst_2erunP_24s1504380254x1312992993_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2erunP_24s1504380254x1312992993_lam0, 2, 0};
Clo g_heff_2ecst_2erunP_24s1504380254x1312992993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2erunP_24s1504380254x1312992993_entry, 1, 0};

V g_heff_2ecst_2erunP_24s1504380254x1312992993(V v_st_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Right, 1, (V[]){(g_heff_2ecst_2etokAt(heff_dup(v_st_240), heff_get(heff_dup(v_st_240), LBL_i)))});
  V v_x1_242 = heff_tag(TAG_MkPair, 2, (V[]){v_t_241, v_st_240});
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_st_244 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24MkPair = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Left, 1, (V[]){v_e_245}), v_st_244});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24MkPair, 2);
      V v_t_247 = heff_tr(g_heff_2ecst_2edeclAt(v_x_246));
      return heff_tail(v_t_247, 3, (V[]){heff_dup(g_heff_2ecst_2ereadH_get()), ((V)&g_heff_2ecst_2erunP_24s1504380254x1312992993_lam0_clo), v_st_244});
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2ecst_2erunP_24s1504380254x1312992993_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2erunP_24s1504380254x1312992993(a[0]);
}
V g_heff_2ecst_2erunP_24s1504380254x1312992993_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_st_249 = args[1];
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_248}), v_st_249});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2edeclaredTwo_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {107, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecst_2edeclaredTwo_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {112, 114, 105, 109, 105, 116, 105, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2edeclaredTwo_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecst_2edeclaredTwo_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecst_2edeclaredTwo_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {100, 97, 116, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2edeclaredTwo_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclaredTwo_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 121, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclaredTwo_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclaredTwo_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclaredTwo_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclaredTwo_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
Clo g_heff_2ecst_2edeclaredTwo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclaredTwo_entry, 2, 0};

V g_heff_2ecst_2edeclaredTwo(V v_t_240, V v_u_241) {
top: ;
  V v_t_246;
  if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclaredTwo_str0))) {
    V v_t_243 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_t_240), LBL_text)}));
    V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2edeclaredTwo_str1), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2edeclaredTwo_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2edeclaredTwo_str3), v_t_244})});
    v_t_246 = ({ V a_0 = v_t_243; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecst_2edeclaredTwo_str4), v_t_245}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  } else {
    v_t_246 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_240);
    return heff_tag(TAG_Just, 1, (V[]){heff_get(v_u_241, LBL_text)});
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_text), ((V)&g_heff_2ecst_2edeclaredTwo_str5))) {
      if (heff_strEq_c(heff_get(heff_dup(v_u_241), LBL_kind), ((V)&g_heff_2ecst_2edeclaredTwo_str6))) {
        heff_drop(v_t_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_get(v_u_241, LBL_text)});
      } else {
        heff_drop(v_u_241);
        if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclaredTwo_str7))) {
          return heff_tag(TAG_Just, 1, (V[]){heff_get(v_t_240, LBL_text)});
        } else {
          if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclaredTwo_str8))) {
            return heff_tag(TAG_Just, 1, (V[]){heff_get(v_t_240, LBL_text)});
          } else {
            heff_drop(v_t_240);
            return NTAG(TAG_Nothing);
          }
        }
      }
    } else {
      heff_drop(v_u_241);
      if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclaredTwo_str9))) {
        return heff_tag(TAG_Just, 1, (V[]){heff_get(v_t_240, LBL_text)});
      } else {
        if (heff_strEq_c(heff_get(heff_dup(v_t_240), LBL_kind), ((V)&g_heff_2ecst_2edeclaredTwo_str10))) {
          return heff_tag(TAG_Just, 1, (V[]){heff_get(v_t_240, LBL_text)});
        } else {
          heff_drop(v_t_240);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecst_2edeclaredTwo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edeclaredTwo(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclaredAt_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2edeclaredAt_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {99, 111, 110}};
Clo g_heff_2ecst_2edeclaredAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edeclaredAt_entry, 1, 0};

V g_heff_2ecst_2edeclaredAt(V v_s_240) {
top: ;
  V v_t_241 = heff_intAdd(heff_get(heff_dup(v_s_240), LBL_top), MK_INT(1LL));
  V v_t_242 = heff_arrayLength(heff_get(heff_dup(v_s_240), LBL_toks));
  if (heff_intLt_c(v_t_241, v_t_242)) {
    V v_t_244 = heff_arrayIndex(heff_get(heff_dup(v_s_240), LBL_toks), heff_get(heff_dup(v_s_240), LBL_top));
    V v_t_245 = heff_intAdd(heff_get(heff_dup(v_s_240), LBL_top), MK_INT(1LL));
    V v_t_246 = heff_arrayIndex(heff_get(v_s_240, LBL_toks), v_t_245);
    return (g_heff_2ecst_2edeclaredTwo(v_t_244, v_t_246));
  } else {
    V v_t_247 = heff_arrayLength(heff_get(heff_dup(v_s_240), LBL_toks));
    if (heff_intLt_c(heff_get(heff_dup(v_s_240), LBL_top), v_t_247)) {
      V v_t_249 = heff_arrayIndex(heff_get(heff_dup(v_s_240), LBL_toks), heff_get(v_s_240, LBL_top));
      if (heff_strEq_c(heff_get(heff_dup(v_t_249), LBL_kind), ((V)&g_heff_2ecst_2edeclaredAt_str0))) {
        return heff_tag(TAG_Just, 1, (V[]){heff_get(v_t_249, LBL_text)});
      } else {
        if (heff_strEq_c(heff_get(heff_dup(v_t_249), LBL_kind), ((V)&g_heff_2ecst_2edeclaredAt_str1))) {
          return heff_tag(TAG_Just, 1, (V[]){heff_get(v_t_249, LBL_text)});
        } else {
          heff_drop(v_t_249);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_s_240);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecst_2edeclaredAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2edeclaredAt(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eprogramGo_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2ecst_2eprogramGo_str1 = {{0x80000000u, K_STR, 0}, 35, 35, {116, 104, 101, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 112, 97, 114, 115, 101, 32, 40, 97, 116, 32, 111, 102, 102, 115, 101, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eprogramGo_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eprogramGo_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2eprogramGo_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecst_2eprogramGo_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eprogramGo_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2ecst_2eprogramGo_str7 = {{0x80000000u, K_STR, 0}, 35, 35, {116, 104, 101, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 112, 97, 114, 115, 101, 32, 40, 97, 116, 32, 111, 102, 102, 115, 101, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecst_2eprogramGo_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2eprogramGo_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2ecst_2eprogramGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2eprogramGo_entry, 2, 0};

V g_heff_2ecst_2eprogramGo(V v_s_240, V v_acc_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_243 = heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_240), LBL_toks), heff_get(heff_dup(v_s_240), LBL_i), heff_get(heff_dup(v_s_240), LBL_i), v_t_242, heff_get(heff_dup(v_s_240), LBL_i)});
  V v_t_244 = (g_heff_2ecst_2etokAt(v_t_243, heff_get(heff_dup(v_s_240), LBL_i)));
  if (heff_strEq_c(heff_get(v_t_244, LBL_kind), ((V)&g_heff_2ecst_2eprogramGo_str0))) {
    heff_drop(v_s_240);
    return heff_tag(TAG_Right, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241))});
  } else {
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_247 = heff_rec(5, shape_toks__i__top__stack__start, (V[]){heff_get(heff_dup(v_s_240), LBL_toks), heff_get(heff_dup(v_s_240), LBL_i), heff_get(heff_dup(v_s_240), LBL_i), v_t_246, heff_get(v_s_240, LBL_i)});
    V v_it_248 = heff_tr(g_heff_2ecst_2erunP_24s1504380254x1312992993(v_t_247));
    switch (heff_tag_of(v_it_248)) {
    case TAG_MkPair: {
      V v_it1_249 = heff_field(v_it_248, 0);
      V v_s2_2410 = heff_field(v_it_248, 1);
      V v_ru_24it_248_24MkPair = heff_take_reuse_n(v_it_248, 3ULL, 2);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_Left: {
        V v_d_2411 = heff_field(v_it1_249, 0);
        V v_ru_24it1_249_24Left = heff_take_reuse_n(v_it1_249, 1ULL, 1);
        heff_drop(v_acc_241);
        heff_drop(v_s2_2410);
        heff_drop_cell(v_ru_24it_248_24MkPair, 2);
        V v_t_2412 = heff_get(heff_get(heff_dup(v_d_2411), LBL_span), LBL_start);
        V v_t_2413 = heff_strAppend(((V)&g_heff_2ecst_2eprogramGo_str1), heff_strAppend(heff_intShow(v_t_2412), heff_strAppend(((V)&g_heff_2ecst_2eprogramGo_str2), heff_strAppend(heff_get(v_d_2411, LBL_msg), ((V)&g_heff_2ecst_2eprogramGo_str3)))));
        return heff_tag_at(v_ru_24it1_249_24Left, TAG_Left, 1, (V[]){v_t_2413});
      }
      case TAG_Right: {
        V v_d_2414 = heff_field(v_it1_249, 0);
        V v_ru_24it1_249_24Right = heff_take_reuse_n(v_it1_249, 1ULL, 1);
        V v_t_2415 = (g_heff_2ecst_2etokAt(heff_dup(v_s2_2410), heff_get(heff_dup(v_s2_2410), LBL_i)));
        if (heff_strEq_c(heff_get(v_t_2415, LBL_kind), ((V)&g_heff_2ecst_2eprogramGo_str4))) {
          heff_drop_cell(v_ru_24it1_249_24Right, 1);
          V t_0 = v_s2_2410;
          V t_1 = heff_tag_at(v_ru_24it_248_24MkPair, TAG_Cons, 2, (V[]){v_d_2414, v_acc_241});
          v_s_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24it_248_24MkPair, 2);
          heff_drop(v_d_2414);
          V v_t_2417 = (g_heff_2ecst_2etokAt(heff_dup(v_s2_2410), heff_get(heff_dup(v_s2_2410), LBL_i)));
          V v_span_2418 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_t_2417), LBL_start), heff_get(v_t_2417, LBL_end)});
          V v_t_2419 = (g_heff_2ecst_2etokAt(heff_dup(v_s2_2410), heff_get(v_s2_2410, LBL_i)));
          V v_msg_2420 = heff_strAppend(((V)&g_heff_2ecst_2eprogramGo_str5), heff_strAppend(heff_get(v_t_2419, LBL_text), ((V)&g_heff_2ecst_2eprogramGo_str6)));
          V v_d_2421 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2420, v_span_2418, NTAG(TAG_Nothing)});
          V v_t_2422 = heff_get(heff_get(heff_dup(v_d_2421), LBL_span), LBL_start);
          V v_t_2423 = heff_strAppend(((V)&g_heff_2ecst_2eprogramGo_str7), heff_strAppend(heff_intShow(v_t_2422), heff_strAppend(((V)&g_heff_2ecst_2eprogramGo_str8), heff_strAppend(heff_get(v_d_2421, LBL_msg), ((V)&g_heff_2ecst_2eprogramGo_str9)))));
          return heff_tag_at(v_ru_24it1_249_24Right, TAG_Left, 1, (V[]){v_t_2423});
        }
      }
      default: return heff_nomatch(v_it1_249);
      }
    }
    default: return heff_nomatch(v_it_248);
    }
  }
}
V g_heff_2ecst_2eprogramGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2eprogramGo(a[0], a[1]);
}
Clo g_heff_2ecst_2efirstP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2efirstP_entry, 1, 0};

V g_heff_2ecst_2efirstP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_243);
  }
  case TAG_PParen: {
    V v_o_244 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_244);
  }
  case TAG_PList: {
    V v_o_247 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_247);
  }
  case TAG_POp: {
    V v_l_2411 = heff_field(v_x1_240, 0);
    V t_0 = v_l_2411;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_o_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2414);
  }
  case TAG_PField: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2418);
  }
  case TAG_PAs: {
    V v_x_2421 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2421);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecst_2efirstP_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecst_2efirstP(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecst_2elastP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elastP_entry, 1, 0};

V g_heff_2ecst_2elastP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_args_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      return v_t_241;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 2);
      heff_drop(v_t_241);
      V t_0 = v_x_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  case TAG_PAtom: {
    V v_t_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_246;
  }
  case TAG_PParen: {
    V v_c_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_249;
  }
  case TAG_PList: {
    V v_c_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2413;
  }
  case TAG_POp: {
    V v_r_2416 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_r_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_c_2420 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2420;
  }
  case TAG_PField: {
    V v_p_2423 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2423;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PAs: {
    V v_p_2426 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2426;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecst_2elastP_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elastP(a[0]);
}
Clo g_heff_2ecst_2efirstE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2efirstE_entry, 1, 0};

V g_heff_2ecst_2efirstE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_EParen: {
    V v_o_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_242);
  }
  case TAG_Named: {
    V v_o_245 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_245);
  }
  case TAG_Tup: {
    V v_o_2410 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2410);
  }
  case TAG_Braces: {
    V v_o_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2414);
  }
  case TAG_InstB: {
    V v_o_2418 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2418);
  }
  case TAG_EFSet: {
    V v_x_2423 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2423);
  }
  case TAG_EFDefault: {
    V v_e_2426 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2426;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Sum: {
    V v_kw_2429 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2429);
  }
  case TAG_ECon: {
    V v_c_2434 = heff_field(v_x1_240, 0);
    return heff_dup(v_c_2434);
  }
  case TAG_EField: {
    V v_e_2436 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2436;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_App: {
    V v_h_2438 = heff_field(v_x1_240, 0);
    V t_0 = v_h_2438;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Op: {
    V v_a_2440 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2440;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ops: {
    V v_a_2443 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2443;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_OpRhs: {
    V v_op_2445 = heff_field(v_x1_240, 0);
    return heff_dup(v_op_2445);
  }
  case TAG_Ann: {
    V v_e_2447 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2447;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_BVar: {
    V v_t_2450 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_2450);
  }
  case TAG_BImp: {
    V v_o_2451 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2451);
  }
  case TAG_BAnn: {
    V v_o_2454 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2454);
  }
  case TAG_Lam: {
    V v_bs_2459 = heff_field(v_x1_240, 0);
    return heff_dup(v_bs_2459);
  }
  case TAG_Case: {
    V v_kw_2463 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2463);
  }
  case TAG_EAlt: {
    V v_p_2467 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_heff_2ecst_2efirstP(v_p_2467);
  }
  case TAG_If: {
    V v_kw_2470 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2470);
  }
  case TAG_Do: {
    V v_kw_2476 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2476);
  }
  case TAG_ESBind: {
    V v_x_2478 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2478);
  }
  case TAG_ELet: {
    V v_kw_2481 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2481);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecst_2efirstE_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecst_2efirstE(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecst_2elastE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elastE_entry, 1, 0};

V g_heff_2ecst_2elastE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_EParen: {
    V v_c_244 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_244;
  }
  case TAG_Named: {
    V v_c_249 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_249;
  }
  case TAG_Tup: {
    V v_c_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2413;
  }
  case TAG_Braces: {
    V v_c_2417 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2417;
  }
  case TAG_InstB: {
    V v_c_2422 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2422;
  }
  case TAG_EFSet: {
    V v_e_2425 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_e_2425;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EFDefault: {
    V v_d_2428 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_d_2428;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Sum: {
    V v_c_2433 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2433;
  }
  case TAG_ECon: {
    V v_c_2434 = heff_field(v_x1_240, 0);
    V v_args_2435 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2435));
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_Nil: {
      return v_c_2434;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x1_2436, 0);
      heff_take_n(v_x1_2436, 1ULL, 2);
      heff_drop(v_c_2434);
      V t_0 = v_x_2437;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2436);
    }
  }
  case TAG_EField: {
    V v_f_2440 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_f_2440;
  }
  case TAG_App: {
    V v_h_2441 = heff_field(v_x1_240, 0);
    V v_args_2442 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2442));
    switch (heff_tag_of(v_x1_2443)) {
    case TAG_Nil: {
      V t_0 = v_h_2441;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x1_2443, 0);
      heff_take_n(v_x1_2443, 1ULL, 2);
      heff_drop(v_h_2441);
      V t_0 = v_x_2444;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2443);
    }
  }
  case TAG_Op: {
    V v_b_2448 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_b_2448;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ops: {
    V v_a_2449 = heff_field(v_x1_240, 0);
    V v_rest_2450 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_2450));
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nil: {
      V t_0 = v_a_2449;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 2);
      heff_drop(v_a_2449);
      V t_0 = v_x_2452;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2451);
    }
  }
  case TAG_OpRhs: {
    V v_e_2455 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_e_2455;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ann: {
    V v_ty_2458 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_ty_2458;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_BVar: {
    V v_t_2459 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_2459;
  }
  case TAG_BImp: {
    V v_c_2462 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_2462;
  }
  case TAG_BAnn: {
    V v_c_2467 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2467;
  }
  case TAG_Lam: {
    V v_body_2471 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    V t_0 = v_body_2471;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    V v_of2_2474 = heff_field(v_x1_240, 2);
    V v_alts_2475 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 12ULL, 4);
    V v_x1_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_alts_2475));
    switch (heff_tag_of(v_x1_2476)) {
    case TAG_Nil: {
      return v_of2_2474;
    }
    case TAG_Cons: {
      V v_x_2477 = heff_field(v_x1_2476, 0);
      heff_take_n(v_x1_2476, 1ULL, 2);
      heff_drop(v_of2_2474);
      V t_0 = v_x_2477;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2476);
    }
  }
  case TAG_EAlt: {
    V v_body_2481 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_body_2481;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_If: {
    V v_b_2487 = heff_field(v_x1_240, 5);
    heff_take_n(v_x1_240, 32ULL, 6);
    V t_0 = v_b_2487;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Do: {
    V v_kw_2488 = heff_field(v_x1_240, 0);
    V v_stmts_2489 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_2489));
    switch (heff_tag_of(v_x1_2490)) {
    case TAG_Nil: {
      return v_kw_2488;
    }
    case TAG_Cons: {
      V v_x_2491 = heff_field(v_x1_2490, 0);
      heff_take_n(v_x1_2490, 1ULL, 2);
      heff_drop(v_kw_2488);
      V t_0 = v_x_2491;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2490);
    }
  }
  case TAG_ESBind: {
    V v_e_2495 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_e_2495;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ELet: {
    V v_e_24100 = heff_field(v_x1_240, 4);
    V v_body_24101 = heff_field(v_x1_240, 5);
    heff_take_n(v_x1_240, 48ULL, 6);
    switch (heff_tag_of(v_body_24101)) {
    case TAG_Nothing: {
      V t_0 = v_e_24100;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_it1_24102 = heff_field(v_body_24101, 0);
      heff_take_n(v_body_24101, 1ULL, 1);
      heff_drop(v_e_24100);
      switch (heff_tag_of(v_it1_24102)) {
      case TAG_MkPair: {
        V v_b_24104 = heff_field(v_it1_24102, 1);
        heff_take_n(v_it1_24102, 2ULL, 2);
        V t_0 = v_b_24104;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_it1_24102);
      }
    }
    default: return heff_nomatch(v_body_24101);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecst_2elastE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elastE(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2efirstD_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2efirstD_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2efirstD_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecst_2efirstD_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2efirstD_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecst_2efirstD_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2ecst_2efirstD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2efirstD_entry, 1, 0};

V g_heff_2ecst_2efirstD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_242);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_x1_240, 0);
    V v_x2_249;
    switch (heff_tag_of(v_n_244)) {
    case TAG_Nil: {
      v_x2_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_n_244, 0);
      v_x2_249 = heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_247)});
      break;
    }
    default: heff_nomatch(v_n_244);
    }
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nothing: {
      return heff_rec(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2ecst_2efirstD_str0), ((V)&g_heff_2ecst_2efirstD_str1), ((V)&g_heff_2ecst_2efirstD_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      heff_take_n(v_x2_249, 1ULL, 1);
      return v_x_2410;
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  case TAG_DEqn: {
    V v_n_2411 = heff_field(v_x1_240, 0);
    V v_x2_2418;
    switch (heff_tag_of(v_n_2411)) {
    case TAG_Nil: {
      v_x2_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_n_2411, 0);
      v_x2_2418 = heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_2416)});
      break;
    }
    default: heff_nomatch(v_n_2411);
    }
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nothing: {
      return heff_rec(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2ecst_2efirstD_str3), ((V)&g_heff_2ecst_2efirstD_str4), ((V)&g_heff_2ecst_2efirstD_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      heff_take_n(v_x2_2418, 1ULL, 1);
      return v_x_2419;
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_DData: {
    V v_kw_2420 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2420);
  }
  case TAG_DType: {
    V v_kw_2425 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2425);
  }
  case TAG_DTheory: {
    V v_kw_2430 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2430);
  }
  case TAG_DForeign: {
    V v_kw_2435 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2435);
  }
  case TAG_DPrimitive: {
    V v_kw_2440 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2440);
  }
  case TAG_DTest: {
    V v_kw_2444 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2444);
  }
  case TAG_DWatch: {
    V v_w_2446 = heff_field(v_x1_240, 0);
    return heff_dup(v_w_2446);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecst_2efirstD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecst_2efirstD(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecst_2edataLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2edataLast_entry, 4, 0};

V g_heff_2ecst_2edataLast(V v_name_240, V v_params_241, V v_universe_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_universe_242)) {
    case TAG_Nothing: {
      V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_241));
      V v_x2_247;
      switch (heff_tag_of(v_x1_244)) {
      case TAG_Nil: {
        v_x2_247 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_245 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 2);
        v_x2_247 = heff_tag(TAG_Just, 1, (V[]){v_x_245});
        break;
      }
      default: heff_nomatch(v_x1_244);
      }
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        return v_name_240;
      }
      case TAG_Just: {
        V v_e_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        heff_drop(v_name_240);
        return (g_heff_2ecst_2elastE(v_e_248));
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    case TAG_Just: {
      V v_x31_249 = heff_field(v_universe_242, 0);
      heff_drop(v_name_240);
      heff_drop(v_params_241);
      switch (heff_tag_of(v_x31_249)) {
      case TAG_MkPair: {
        V v_u_2411 = heff_field(v_x31_249, 1);
        return (g_heff_2ecst_2elastE(heff_dup(v_u_2411)));
      }
      default: return heff_nomatch(v_x31_249);
      }
    }
    default: return heff_nomatch(v_universe_242);
    }
  }
  case TAG_Just: {
    V v_x41_2412 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_2412)) {
    case TAG_MkDAlts: {
      V v_alts_2414 = heff_field(v_x41_2412, 1);
      heff_take_n(v_x41_2412, 2ULL, 3);
      V v_t_2424;
      switch (heff_tag_of(v_universe_242)) {
      case TAG_Nothing: {
        V v_x1_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_241));
        V v_x2_2419;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          v_x2_2419 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 2);
          v_x2_2419 = heff_tag_at(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_x_2417});
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_Nothing: {
          v_t_2424 = v_name_240;
          break;
        }
        case TAG_Just: {
          V v_e_2420 = heff_field(v_x2_2419, 0);
          heff_take_n(v_x2_2419, 1ULL, 1);
          heff_drop(v_name_240);
          v_t_2424 = (g_heff_2ecst_2elastE(v_e_2420));
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        break;
      }
      case TAG_Just: {
        V v_x31_2421 = heff_field(v_universe_242, 0);
        heff_drop(v_name_240);
        heff_drop(v_params_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        switch (heff_tag_of(v_x31_2421)) {
        case TAG_MkPair: {
          V v_u_2423 = heff_field(v_x31_2421, 1);
          v_t_2424 = (g_heff_2ecst_2elastE(heff_dup(v_u_2423)));
          break;
        }
        default: heff_nomatch(v_x31_2421);
        }
        break;
      }
      default: heff_nomatch(v_universe_242);
      }
      V v_x1_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_alts_2414));
      V v_x2_2428;
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Nil: {
        v_x2_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 2);
        v_x2_2428 = heff_tag(TAG_Just, 1, (V[]){v_x_2426});
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_Nothing: {
        return v_t_2424;
      }
      case TAG_Just: {
        V v_e_2429 = heff_field(v_x2_2428, 0);
        heff_take_n(v_x2_2428, 1ULL, 1);
        heff_drop(v_t_2424);
        return (g_heff_2ecst_2elastE(v_e_2429));
      }
      default: return heff_nomatch(v_x2_2428);
      }
    }
    default: return heff_nomatch(v_x41_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecst_2edataLast_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecst_2edataLast(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
Clo g_heff_2ecst_2elastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecst_2elastD_entry, 1, 0};

V g_heff_2ecst_2elastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    V v_ts_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ts_243));
    V v_x2_247;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nil: {
      v_x2_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 2);
      v_x2_247 = heff_tag(TAG_Just, 1, (V[]){v_x_245});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      return v_kw_242;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      heff_drop(v_kw_242);
      return v_x_248;
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DSig: {
    V v_ty_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    HEFF_LAST return g_heff_2ecst_2elastE(v_ty_2411);
  }
  case TAG_DEqn: {
    V v_rhs_2415 = heff_field(v_x1_240, 3);
    V v_w_2416 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    switch (heff_tag_of(v_w_2416)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecst_2elastE(v_rhs_2415);
    }
    case TAG_Just: {
      V v_it1_2417 = heff_field(v_w_2416, 0);
      heff_take_n(v_w_2416, 1ULL, 1);
      heff_drop(v_rhs_2415);
      switch (heff_tag_of(v_it1_2417)) {
      case TAG_MkPair: {
        V v_kw_2418 = heff_field(v_it1_2417, 0);
        V v_ds_2419 = heff_field(v_it1_2417, 1);
        heff_take_n(v_it1_2417, 3ULL, 2);
        V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2419));
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_Nil: {
          return v_kw_2418;
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 2);
          heff_drop(v_kw_2418);
          V t_0 = v_x_2421;
          v_x1_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x1_2420);
        }
      }
      default: return heff_nomatch(v_it1_2417);
      }
    }
    default: return heff_nomatch(v_w_2416);
    }
  }
  case TAG_DData: {
    V v_name_2424 = heff_field(v_x1_240, 1);
    V v_params_2425 = heff_field(v_x1_240, 2);
    V v_universe_2426 = heff_field(v_x1_240, 3);
    V v_alts_2427 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 30ULL, 5);
    return ({ V a_0 = v_name_2424; V a_1 = v_params_2425; V a_2 = v_universe_2426; V a_3 = v_alts_2427; V r_ = (g_heff_2ecst_2edataLast(a_0, a_1, a_2, a_3)); heff_drop(v_universe_2426); r_; });
  }
  case TAG_DType: {
    V v_body_2432 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    HEFF_LAST return g_heff_2ecst_2elastE(v_body_2432);
  }
  case TAG_DTheory: {
    V v_w_2436 = heff_field(v_x1_240, 3);
    V v_fields_2437 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    V v_x1_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fields_2437));
    V v_x2_2441;
    switch (heff_tag_of(v_x1_2438)) {
    case TAG_Nil: {
      v_x2_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2439 = heff_field(v_x1_2438, 0);
      heff_take_n(v_x1_2438, 1ULL, 2);
      v_x2_2441 = heff_tag(TAG_Just, 1, (V[]){v_x_2439});
      break;
    }
    default: heff_nomatch(v_x1_2438);
    }
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_Nothing: {
      return v_w_2436;
    }
    case TAG_Just: {
      V v_f_2442 = heff_field(v_x2_2441, 0);
      heff_take_n(v_x2_2441, 1ULL, 1);
      heff_drop(v_w_2436);
      switch (heff_tag_of(v_f_2442)) {
      case TAG_MkTF: {
        V v_ty_2445 = heff_field(v_f_2442, 2);
        V v_x14_2446 = heff_field(v_f_2442, 3);
        heff_take_n(v_f_2442, 12ULL, 4);
        switch (heff_tag_of(v_x14_2446)) {
        case TAG_Nothing: {
          HEFF_LAST return g_heff_2ecst_2elastE(v_ty_2445);
        }
        case TAG_Just: {
          V v_x141_2447 = heff_field(v_x14_2446, 0);
          heff_take_n(v_x14_2446, 1ULL, 1);
          heff_drop(v_ty_2445);
          switch (heff_tag_of(v_x141_2447)) {
          case TAG_MkPair: {
            V v_d_2449 = heff_field(v_x141_2447, 1);
            heff_take_n(v_x141_2447, 2ULL, 2);
            HEFF_LAST return g_heff_2ecst_2elastE(v_d_2449);
          }
          default: return heff_nomatch(v_x141_2447);
          }
        }
        default: return heff_nomatch(v_x14_2446);
        }
      }
      default: return heff_nomatch(v_f_2442);
      }
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  case TAG_DForeign: {
    V v_ty_2454 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    HEFF_LAST return g_heff_2ecst_2elastE(v_ty_2454);
  }
  case TAG_DPrimitive: {
    V v_ty_2458 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2ecst_2elastE(v_ty_2458);
  }
  case TAG_DTest: {
    V v_x_2460 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_x_2460;
  }
  case TAG_DWatch: {
    V v_e_2462 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2ecst_2elastE(v_e_2462);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecst_2elastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecst_2elastD(a[0]);
}