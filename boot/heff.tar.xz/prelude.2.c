// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_DeclareField 57313
#define TAG_Describe 2650
#define TAG_ELam 43266
#define TAG_EVar 52881
#define TAG_Expl 20488
#define TAG_ExplicitParam 63083
#define TAG_Impl 63555
#define TAG_ImplicitParam 51130
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSmallTyp 41275
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SetPath 11095
#define TAG_Small 51389
#define TAG_Throw 56084
#define TAG_TopL 65516
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_typ 324869
#define LBL_val 326043
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_key__arity[] = {LBL_key, LBL_arity};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_span__name__typ__implicit[] = {LBL_span, LBL_name, LBL_typ, LBL_implicit};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo;
V g_heff_2ecompile_2etrmc_2econsEnds(V, V);
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2econsEnds_clo;
V g_heff_2ecompile_2etrmc_2edestined(V, V, V, V);
V g_heff_2ecompile_2etrmc_2edestined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edestined_clo;
V g_heff_2ecompile_2etrmc_2egathered(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egathered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egathered_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2eupdatePath(V, V, V);
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo;
V g_prelude_2e_2b_2b_24f132290754x1091834184(V, V, V, V);
V g_prelude_2e_2b_2b_24f132290754x1091834184_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f132290754x1091834184_clo;
V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587(V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_clo;
V g_prelude_2e_2b_2b_24f658301291x587486003(V, V);
V g_prelude_2e_2b_2b_24f658301291x587486003_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f658301291x587486003_clo;
V g_prelude_2e_2b_2b_24f658301291x587486003_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f658301291x587486003_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f658301291x587486003_24dps_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo;
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2edigitsFrom_24cpr(V, V, V);
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esnd(V);
V g_prelude_2esnd_entry(V self, V *a);
extern Clo g_prelude_2esnd_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2esplitFrom_2ebackwards_240(V, V);
V g_prelude_2esplitFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_2ebackwards_240_clo;
V g_prelude_2etraverse_24s1048254938x1609755296(V, V, V, V);
V g_prelude_2etraverse_24s1048254938x1609755296_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1048254938x1609755296_clo;
V g_prelude_2etraverse_24s1157078602x1175067503(V, V, V);
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1157078602x1175067503_clo;
HeffT2 g_prelude_2etraverse_24s119460564x671287541_24cpr(V, V);
V g_prelude_2etraverse_24s1211845059x266223635(V);
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1211845059x266223635_clo;
V g_prelude_2etraverse_24s1310917876x950458632(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_clo;
HeffT2 g_prelude_2etraverse_24s1483742185x1081287844_24cpr(V);
HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V, V);
V g_prelude_2etraverse_24s1778157750x1229378888(V);
V g_prelude_2etraverse_24s1778157750x1229378888_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1778157750x1229378888_clo;
HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V);
HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V, V);
V g_prelude_2etraverse_24s1882351740x242225671(V);
V g_prelude_2etraverse_24s1882351740x242225671_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1882351740x242225671_clo;
V g_prelude_2etraverse_24s2104983077x351811635(V);
V g_prelude_2etraverse_24s2104983077x351811635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2104983077x351811635_clo;
V g_prelude_2etraverse_24s215781391x848981957(V);
V g_prelude_2etraverse_24s215781391x848981957_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s215781391x848981957_clo;
V g_prelude_2etraverse_24s277604616x578020818(V);
V g_prelude_2etraverse_24s277604616x578020818_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s277604616x578020818_clo;
HeffT2 g_prelude_2etraverse_24s366524614x1308602553_24cpr(V);
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s515579549x140669784(V);
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s515579549x140669784_clo;
V g_prelude_2etraverse_24s646322350x1809881141(V);
V g_prelude_2etraverse_24s646322350x1809881141_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s646322350x1809881141_clo;
V g_prelude_2etraverse_24s735647865x424372205(V, V);
V g_prelude_2etraverse_24s735647865x424372205_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s735647865x424372205_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_prelude_2ewordsFrom_2ebackwards_240(V, V);
V g_prelude_2ewordsFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_2ebackwards_240_clo;
Clo g_prelude_2esnd_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esnd_entry, 1, 0};

V g_prelude_2esnd(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_y_242 = heff_field(v_x1_240, 1);
    return heff_dup(v_y_242);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2esnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2esnd(a0); heff_drop(a0); return r;
}
Clo g_prelude_2esplitFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplitFrom_entry, 5, 0};

V g_prelude_2esplitFrom(V v_sep_240, V v_s_241, V v_i_242, V v_j_243, V v_acc_244) {
top: ;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    V v_t_245 = heff_strSlice(heff_dup(v_s_241), v_i_242, heff_strLength_lent(v_s_241, 0));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return (g_prelude_2esplitFrom_2ebackwards_240(v_acc_244, v_t_246));
  } else {
    V v_t_247 = heff_intAdd(heff_dup(v_j_243), heff_strLength_lent(v_sep_240, 0));
    V v_t_248 = heff_intAdd(heff_dup(v_j_243), heff_strLength_lent(v_sep_240, 0));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_241, v_i_242, v_j_243, 6), v_acc_244});
    V t_0 = v_sep_240;
    V t_1 = v_s_241;
    V t_2 = v_t_247;
    V t_3 = heff_strFind_lent(v_sep_240, v_s_241, v_t_248, 4);
    V t_4 = v_t_249;
    v_sep_240 = t_0;
    v_s_241 = t_1;
    v_i_242 = t_2;
    v_j_243 = t_3;
    v_acc_244 = t_4;
    goto top;
  }
}
V g_prelude_2esplitFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2esplitFrom(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_prelude_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewordsFrom_entry, 4, 0};

V g_prelude_2ewordsFrom(V v_s_240, V v_start_241, V v_box_24i_242, V v_acc_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_242)) {
    V v_t_244;
    if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
      v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
    } else {
      heff_drop(v_start_241);
      v_t_244 = v_acc_243;
    }
    return (g_prelude_2ewordsFrom_2ebackwards_240(v_t_244, NTAG(TAG_Nil)));
  } else {
    V v_c_245 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2);
    if (((heff_peek_word(v_c_245) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_245) == ((int64_t)9ULL)) || ((heff_peek_word(v_c_245) == ((int64_t)10ULL)) || (heff_peek_word(v_c_245) == ((int64_t)13ULL)))))) {
      heff_drop(v_c_245);
      V v_t_246;
      if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
        v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
      } else {
        heff_drop(v_start_241);
        v_t_246 = v_acc_243;
      }
      V t_0 = v_s_240;
      V t_1 = heff_box_word((v_i_242 + ((int64_t)1ULL)));
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_246;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_c_245);
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_prelude_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2ewordsFrom(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_prelude_2eparseInt_24cpr_str0, 1, "-");

HeffT2 g_prelude_2eparseInt_24cpr(V v_s_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) == ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_prelude_2eparseInt_24cpr_str0))) {
      if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) == ((int64_t)1ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        HeffT2 v_t_241 = (g_prelude_2edigitsFrom_24cpr(v_s_240, MK_INT(1LL), MK_INT(0LL)));
        {
          V v_field_243 = v_t_241.f[1];
          int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
          if ((v_tag_242 == ((int64_t)0ULL))) {
            V v_x_244 = v_field_243;
            V v_f_245 = heff_intSub(MK_INT(0LL), v_x_244);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
          } else {
            heff_drop(v_field_243);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    } else {
      return (g_prelude_2edigitsFrom_24cpr(v_s_240, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_prelude_2etraverse_24s499544530x2060473942_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s499544530x2060473942_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s499544530x2060473942_lam0, 1, 0};
V g_prelude_2etraverse_24s499544530x2060473942_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s499544530x2060473942_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s499544530x2060473942_entry, 2, 0};

V g_prelude_2etraverse_24s499544530x2060473942(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s499544530x2060473942_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s499544530x2060473942_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s499544530x2060473942(a[0], a[1]);
}
V g_prelude_2etraverse_24s499544530x2060473942_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_prelude_2etraverse_24s499544530x2060473942_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = (g_prelude_2etraverse_24s499544530x2060473942(v_f_240, v_xs_245));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_Cons, 2, (V[]){v_x_2412, v_x_2418})});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_prelude_2etraverse_24s1048254938x1609755296_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1048254938x1609755296_entry, 4, 0};

V g_prelude_2etraverse_24s1048254938x1609755296(V v_lit_240, V v_lit_241, V v_x2_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    V v_t_244 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_p_243});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_242, 0);
    V v_xs_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_ty_247 = heff_dup(v_lit_240);
    V v_d_248 = heff_dup(v_lit_241);
    V v_x_249 = v_x_245;
    V v_text_2410 = heff_take_field(v_x_249, 1);
    V v_start_2411 = heff_take_field(v_x_249, 3);
    V v_end_2412 = heff_get_n(v_x_249, 4, 9);
    V v_st_2413 = v_p_243;
    V v_x1_2414 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_ty_247, v_st_2413));
    V v_x1_2446;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_MkPair: {
      V v_x11_2415 = heff_field(v_x1_2414, 0);
      V v_st_2416 = heff_field(v_x1_2414, 1);
      V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
      switch (heff_tag_of(v_x11_2415)) {
      case TAG_Left: {
        V v_e_2417 = heff_field(v_x11_2415, 0);
        V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_d_248);
        heff_drop(v_text_2410);
        heff_drop(v_start_2411);
        heff_drop(v_end_2412);
        v_x1_2446 = heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        break;
      }
      case TAG_Right: {
        V v_x_2418 = heff_field(v_x11_2415, 0);
        V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
        V v_x2_2419 = v_d_248;
        V v_p_2420 = v_st_2416;
        V v_x1_2431;
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_Nothing: {
          V v_t_2421 = heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
          v_x1_2431 = heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2421, v_p_2420});
          break;
        }
        case TAG_Just: {
          V v_x21_2422 = heff_field(v_x2_2419, 0);
          V v_ru_24x2_2419_24Just = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
          switch (heff_tag_of(v_x21_2422)) {
          case TAG_MkPair: {
            V v_d_2424 = heff_field(v_x21_2422, 1);
            heff_take_n(v_x21_2422, 2ULL, 2);
            V v_x1_2425 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_d_2424, v_p_2420));
            switch (heff_tag_of(v_x1_2425)) {
            case TAG_MkPair: {
              V v_x11_2426 = heff_field(v_x1_2425, 0);
              V v_st_2427 = heff_field(v_x1_2425, 1);
              heff_take_n(v_x1_2425, 3ULL, 2);
              switch (heff_tag_of(v_x11_2426)) {
              case TAG_Left: {
                V v_e_2428 = heff_field(v_x11_2426, 0);
                V v_ru_24x11_2426_24Left = heff_take_reuse_n(v_x11_2426, 1ULL, 1);
                heff_drop_cell(v_ru_24x11_2415_24Right, 1);
                heff_drop_cell(v_ru_24x2_2419_24Just, 1);
                v_x1_2431 = heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2426_24Left, TAG_Left, 1, (V[]){v_e_2428}), v_st_2427});
                break;
              }
              case TAG_Right: {
                V v_x_2429 = heff_field(v_x11_2426, 0);
                heff_take_n(v_x11_2426, 1ULL, 1);
                V v_t_2430 = heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_2419_24Just, TAG_Just, 1, (V[]){v_x_2429})});
                v_x1_2431 = heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_st_2427});
                break;
              }
              default: heff_nomatch(v_x11_2426);
              }
              break;
            }
            default: heff_nomatch(v_x1_2425);
            }
            break;
          }
          default: heff_nomatch(v_x21_2422);
          }
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        switch (heff_tag_of(v_x1_2431)) {
        case TAG_MkPair: {
          V v_x11_2432 = heff_field(v_x1_2431, 0);
          V v_st_2433 = heff_field(v_x1_2431, 1);
          V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
          switch (heff_tag_of(v_x11_2432)) {
          case TAG_Left: {
            V v_e_2434 = heff_field(v_x11_2432, 0);
            V v_ru_24x11_2432_24Left = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_242_24Cons, 2);
            heff_drop(v_text_2410);
            heff_drop(v_start_2411);
            heff_drop(v_end_2412);
            heff_drop(v_x_2418);
            v_x1_2446 = heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Left, TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
            break;
          }
          case TAG_Right: {
            V v_x_2435 = heff_field(v_x11_2432, 0);
            V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
            V v_t_2436 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_text_2410), heff_dup(heff_rfield(v_st_2433, 1))});
            V v_st_2437 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2436, v_st_2433));
            V v_t_2438 = heff_tag_n(TAG_DeclareField, 4, (V[]){v_text_2410, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_2411), v_end_2412}), heff_dup(v_x_2418), heff_dup(v_x_2435)});
            V v_t_2440;
            switch (heff_tag_of(v_x_2435)) {
            case TAG_Nothing: {
              v_t_2440 = v_x_2418;
              break;
            }
            case TAG_Just: {
              V v_x_2439 = heff_field(v_x_2435, 0);
              heff_take_n(v_x_2435, 1ULL, 1);
              heff_drop(v_x_2418);
              v_t_2440 = v_x_2439;
              break;
            }
            default: heff_nomatch(v_x_2435);
            }
            V v_t_2443;
            switch (heff_tag_of(v_t_2440)) {
            case TAG_At: {
              V v_s_2442 = heff_field(v_t_2440, 1);
              heff_take_n(v_t_2440, 2ULL, 2);
              v_t_2443 = v_s_2442;
              break;
            }
            default: heff_nomatch(v_t_2440);
            }
            V v_t_2444 = ({ V rv_0 = v_start_2411; V rr_ = heff_rec_reuse_nf(v_t_2443, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2445 = heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_t_2444})});
            v_x1_2446 = heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){v_t_2445, v_st_2437});
            break;
          }
          default: heff_nomatch(v_x11_2432);
          }
          break;
        }
        default: heff_nomatch(v_x1_2431);
        }
        break;
      }
      default: heff_nomatch(v_x11_2415);
      }
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    switch (heff_tag_of(v_x1_2446)) {
    case TAG_MkPair: {
      V v_x11_2447 = heff_field(v_x1_2446, 0);
      V v_st_2448 = heff_field(v_x1_2446, 1);
      V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
      switch (heff_tag_of(v_x11_2447)) {
      case TAG_Left: {
        V v_e_2449 = heff_field(v_x11_2447, 0);
        V v_ru_24x11_2447_24Left = heff_take_reuse_n(v_x11_2447, 1ULL, 1);
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_xs_246);
        return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2447_24Left, TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
      }
      case TAG_Right: {
        V v_x_2450 = heff_field(v_x11_2447, 0);
        V v_ru_24x11_2447_24Right = heff_take_reuse_n(v_x11_2447, 1ULL, 1);
        V v_m_2451 = heff_tr(heff_call(((V)&g_prelude_2etraverse_24s1048254938x1609755296_clo), 3, (V[]){v_lit_240, v_lit_241, v_xs_246}));
        V v_x1_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2448}));
        switch (heff_tag_of(v_x1_2452)) {
        case TAG_MkPair: {
          V v_x11_2453 = heff_field(v_x1_2452, 0);
          V v_st_2454 = heff_field(v_x1_2452, 1);
          V v_ru_24x1_2452_24MkPair = heff_take_reuse_n(v_x1_2452, 3ULL, 2);
          switch (heff_tag_of(v_x11_2453)) {
          case TAG_Left: {
            V v_e_2455 = heff_field(v_x11_2453, 0);
            V v_ru_24x11_2453_24Left = heff_take_reuse_n(v_x11_2453, 1ULL, 1);
            heff_drop(v_x_2450);
            heff_drop_cell(v_ru_24x11_2447_24Right, 1);
            heff_drop_cell(v_ru_24x1_2452_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2453_24Left, TAG_Left, 1, (V[]){v_e_2455}), v_st_2454});
          }
          case TAG_Right: {
            V v_x_2456 = heff_field(v_x11_2453, 0);
            heff_take_n(v_x11_2453, 1ULL, 1);
            V v_t_2457 = heff_tag_at_n(v_ru_24x11_2447_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_Cons, 2, (V[]){v_x_2450, v_x_2456})});
            return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){v_t_2457, v_st_2454});
          }
          default: return heff_nomatch(v_x11_2453);
          }
        }
        default: return heff_nomatch(v_x1_2452);
        }
      }
      default: return heff_nomatch(v_x11_2447);
      }
    }
    default: return heff_nomatch(v_x1_2446);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2etraverse_24s1048254938x1609755296_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1048254938x1609755296(a[0], a[1], a[2], a[3]);
}

HeffT2 g_prelude_2etraverse_24s119460564x671287541_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24MkPair = heff_take_reuse_n(v_x_242, 3ULL, 2);
      HeffT2 v_t_246 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_245, v_p_241));
      {
        V v_field_247 = v_t_246.f[0];
        V v_field_248 = v_t_246.f[1];
        V v_a_249 = v_field_247;
        V v_a_2410 = v_field_248;
        HeffT2 v_t_2411 = (g_prelude_2etraverse_24s119460564x671287541_24cpr(v_xs_243, v_a_2410));
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_x_2414 = v_field_2412;
          V v_st_2415 = v_field_2413;
          V v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x_242_24MkPair, TAG_MkPair, 2, (V[]){v_a_244, v_a_249}), v_x_2414});
          return ((HeffT2){{v_t_2416, v_st_2415}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nothing: {
      heff_drop(v_f_240);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      HeffT2 v_t_246 = (g_prelude_2etraverse_24s1760019503x148599044_24cpr(v_f_240, v_xs_243));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_249 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_249})}});
        } else {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_x_245);
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_prelude_2etraverse_24s2104983077x351811635_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2104983077x351811635_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2104983077x351811635_lam0, 1, 0};
V g_prelude_2etraverse_24s2104983077x351811635_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s2104983077x351811635_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2104983077x351811635_entry, 1, 0};

V g_prelude_2etraverse_24s2104983077x351811635(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s2104983077x351811635_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s2104983077x351811635_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s2104983077x351811635_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2104983077x351811635(a[0]);
}
V g_prelude_2etraverse_24s2104983077x351811635_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_prelude_2etraverse_24s2104983077x351811635_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s2104983077x351811635(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_s_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s735647865x424372205_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s735647865x424372205_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s735647865x424372205_lam0, 1, 0};
V g_prelude_2etraverse_24s735647865x424372205_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s735647865x424372205_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s735647865x424372205_entry, 2, 0};

V g_prelude_2etraverse_24s735647865x424372205(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s735647865x424372205_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s735647865x424372205_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s735647865x424372205_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s735647865x424372205(a[0], a[1]);
}
V g_prelude_2etraverse_24s735647865x424372205_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s735647865x424372205_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s735647865x424372205(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s646322350x1809881141_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s646322350x1809881141_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s646322350x1809881141_lam0, 1, 0};
V g_prelude_2etraverse_24s646322350x1809881141_lam1(V self, V *args);
V g_prelude_2etraverse_24s646322350x1809881141_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s646322350x1809881141_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s646322350x1809881141_entry, 1, 0};

V g_prelude_2etraverse_24s646322350x1809881141(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s646322350x1809881141_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_246));
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s646322350x1809881141_lam1, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s646322350x1809881141_lam2, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s646322350x1809881141_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s646322350x1809881141(a[0]);
}
V g_prelude_2etraverse_24s646322350x1809881141_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s646322350x1809881141_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_prelude_2etraverse_24s646322350x1809881141_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_m_2417 = (g_prelude_2etraverse_24s646322350x1809881141(v_xs_243));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_prelude_2etraverse_24s215781391x848981957_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s215781391x848981957_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s215781391x848981957_lam0, 1, 0};
V g_prelude_2etraverse_24s215781391x848981957_lam1(V self, V *args);
V g_prelude_2etraverse_24s215781391x848981957_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s215781391x848981957_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s215781391x848981957_entry, 1, 0};

V g_prelude_2etraverse_24s215781391x848981957(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s215781391x848981957_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_a_246 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_245));
      v_m_2411 = heff_clo_n(g_prelude_2etraverse_24s215781391x848981957_lam1, 1, 2, (V[]){v_a_246, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s215781391x848981957_lam2, 1, 2, (V[]){v_m_2411, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s215781391x848981957_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s215781391x848981957(a[0]);
}
V g_prelude_2etraverse_24s215781391x848981957_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s215781391x848981957_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_a_247}));
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_249}), v_a_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_prelude_2etraverse_24s215781391x848981957_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_m_2416 = (g_prelude_2etraverse_24s215781391x848981957(v_xs_243));
    V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_n_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_n_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s277604616x578020818_str0, 1, "_");
HEFF_LIT(g_prelude_2etraverse_24s277604616x578020818_str1, 1, "_");
HEFF_LIT(g_prelude_2etraverse_24s277604616x578020818_str2, 1, "$");
V g_prelude_2etraverse_24s277604616x578020818_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s277604616x578020818_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s277604616x578020818_lam0, 1, 0};
V g_prelude_2etraverse_24s277604616x578020818_lam1(V self, V *args); static Clo g_prelude_2etraverse_24s277604616x578020818_lam1_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s277604616x578020818_lam1, 1, 0};
V g_prelude_2etraverse_24s277604616x578020818_lam2(V self, V *args);
V g_prelude_2etraverse_24s277604616x578020818_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s277604616x578020818_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s277604616x578020818_entry, 1, 0};

V g_prelude_2etraverse_24s277604616x578020818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s277604616x578020818_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_248;
    if (heff_strEq_c_lent(v_x_242, ((V)&g_prelude_2etraverse_24s277604616x578020818_str0), 2)) {
      heff_drop(v_x_242);
      v_m_248 = ((V)&g_prelude_2etraverse_24s277604616x578020818_lam1_clo);
    } else {
      V v_base_245 = (g_heff_2ecompile_2eir_2ebaseGo(v_x_242, MK_INT(0LL)));
      v_m_248 = heff_clo_n(g_prelude_2etraverse_24s277604616x578020818_lam2, 1, 1, (V[]){v_base_245});
    }
    return heff_clo_n(g_prelude_2etraverse_24s277604616x578020818_lam3, 1, 2, (V[]){v_m_248, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s277604616x578020818_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s277604616x578020818(a[0]);
}
V g_prelude_2etraverse_24s277604616x578020818_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s277604616x578020818_lam1(V self, V *args) {
  V v_n_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_prelude_2etraverse_24s277604616x578020818_str1), v_n_244});
}
V g_prelude_2etraverse_24s277604616x578020818_lam2(V self, V *args) {
  V v_n_246 = args[0];
  V v_base_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_strAppend(heff_strAppend(v_base_245, ((V)&g_prelude_2etraverse_24s277604616x578020818_str2)), heff_intShow(heff_dup(v_n_246)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, heff_intAdd(v_n_246, MK_INT(1LL))});
}
V g_prelude_2etraverse_24s277604616x578020818_lam3(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_m_2413 = (g_prelude_2etraverse_24s277604616x578020818(v_xs_243));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_n_2416 = heff_field(v_x2_2414, 1);
      V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_x_2411, v_x_2415}), v_n_2416});
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_prelude_2etraverse_24s1882351740x242225671_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1882351740x242225671_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1882351740x242225671_lam0, 1, 0};
V g_prelude_2etraverse_24s1882351740x242225671_lam1(V self, V *args);
V g_prelude_2etraverse_24s1882351740x242225671_lam2(V self, V *args);
V g_prelude_2etraverse_24s1882351740x242225671_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s1882351740x242225671_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1882351740x242225671_entry, 1, 0};

V g_prelude_2etraverse_24s1882351740x242225671(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1882351740x242225671_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_d_244 = v_x_242;
    V v_t_245 = heff_dup(heff_rfield(v_d_244, 2));
    V v_m_2420;
    switch (heff_tag_of(v_t_245)) {
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_t_245, 0);
      V v_b_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      V v_s_249 = heff_rec_n(2, shape_key__arity, (V[]){heff_dup(heff_rfield(v_d_244, 0)), v_t_248});
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2econsEnds_clo), 1, (V[]){heff_dup(v_s_249)}));
      V v_t_2411 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_247), NTAG(TAG_Nil)));
      V v_t_2412 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2411); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_m_2420 = (g_heff_2ecompile_2etrmc_2edestined(v_s_249, v_d_244, v_xs_246, v_b_247));
      } else {
        heff_drop(v_t_2412);
        V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2eappendEnds_clo), 1, (V[]){heff_dup(v_s_249)}));
        V v_t_2414 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_247), NTAG(TAG_Nil)));
        V v_t_2415 = ({ V a_0 = v_t_2413; V a_1 = v_t_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2414); r_; });
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          v_m_2420 = (g_heff_2ecompile_2etrmc_2egathered(v_s_249, v_d_244, v_xs_246, v_b_247));
        } else {
          heff_drop(v_xs_246);
          heff_drop(v_b_247);
          heff_drop_rec(v_s_249, 2);
          heff_drop(v_t_2415);
          v_m_2420 = heff_clo_n(g_prelude_2etraverse_24s1882351740x242225671_lam1, 1, 1, (V[]){v_d_244});
        }
      }
      break;
    }
    default: {
      heff_drop(v_t_245);
      v_m_2420 = heff_clo_n(g_prelude_2etraverse_24s1882351740x242225671_lam2, 1, 1, (V[]){v_d_244});
      break;
    }
    }
    return heff_clo_n(g_prelude_2etraverse_24s1882351740x242225671_lam3, 1, 2, (V[]){v_m_2420, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1882351740x242225671_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1882351740x242225671(a[0]);
}
V g_prelude_2etraverse_24s1882351740x242225671_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1882351740x242225671_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_244, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_n_2416});
}
V g_prelude_2etraverse_24s1882351740x242225671_lam2(V self, V *args) {
  V v_n_2418 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_244, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_n_2418});
}
V g_prelude_2etraverse_24s1882351740x242225671_lam3(V self, V *args) {
  V v_n_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2422 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2421}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_m_2425 = (g_prelude_2etraverse_24s1882351740x242225671(v_xs_243));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_n_2424}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_n_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_Cons, 2, (V[]){v_x_2423, v_x_2427}), v_n_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}

HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_err_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_245}});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      HeffT2 v_t_247 = (g_prelude_2etraverse_24s1807059150x502333573_24cpr(v_f_240, v_xs_243));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_x_246);
          V v_err_2410 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2410}});
        } else {
          V v_x_2411 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_x_2411})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1483742185x1081287844_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24MkFieldPat = heff_take_reuse_n(v_x_241, 3ULL, 2);
      HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_a_244));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop(v_xs_242);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_a_243);
          heff_drop_cell(v_ru_24x_241_24MkFieldPat, 2);
          V v_a_248 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_248}});
        } else {
          V v_a_249 = v_field_247;
          HeffT2 v_t_2410 = (g_prelude_2etraverse_24s1483742185x1081287844_24cpr(v_xs_242));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24Cons, 2);
              heff_drop(v_a_243);
              heff_drop_cell(v_ru_24x_241_24MkFieldPat, 2);
              heff_drop(v_a_249);
              V v_err_2413 = v_field_2412;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2413}});
            } else {
              V v_x_2414 = v_field_2412;
              V v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x_241_24MkFieldPat, TAG_MkPair, 2, (V[]){v_a_243, v_a_249}), v_x_2414});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2415}});
            }
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        heff_take_n(v_a_243, 12ULL, 4);
        HeffT2 v_t_249 = (g_prelude_2etraverse_24s366524614x1308602553_24cpr(v_a_247));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop(v_xs_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_a_248);
            V v_a_2412 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_2412}});
          } else {
            V v_a_2413 = v_field_2411;
            HeffT2 v_t_2414 = (g_prelude_2etraverse_24s1778157750x1229378888_24cpr(v_xs_242));
            {
              V v_field_2416 = v_t_2414.f[1];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop(v_a_248);
                heff_drop(v_a_2413);
                V v_err_2417 = v_field_2416;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2417}});
              } else {
                V v_x_2418 = v_field_2416;
                V v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_a_2413, v_a_248}), v_x_2418});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2419}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_prelude_2etraverse_24s1778157750x1229378888_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1778157750x1229378888_entry, 1, 0};

V g_prelude_2etraverse_24s1778157750x1229378888(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_prelude_2etraverse_24s1778157750x1229378888_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_prelude_2etraverse_24s1778157750x1229378888_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1778157750x1229378888(a[0]);
}
HEFF_LIT(g_prelude_2etraverse_24s1157078602x1175067503_str0, 54, "an argument of a `case` pattern is a pattern or a name");
V g_prelude_2etraverse_24s1157078602x1175067503_lam1(V self, V *args);
V g_prelude_2etraverse_24s1157078602x1175067503_lam0(V self, V *args);
Clo g_prelude_2etraverse_24s1157078602x1175067503_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1157078602x1175067503_entry, 3, 0};

V g_prelude_2etraverse_24s1157078602x1175067503(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_p_245 = v_x_243;
    V v_p_246 = heff_dup(v_p_241);
    V v_bind_247 = heff_take_field(v_p_246, 1);
    V v_malg_248 = heff_get_n(v_p_246, 2, 3);
    V v_p_2411 = heff_clo_n(g_prelude_2etraverse_24s1157078602x1175067503_lam0, 1, 3, (V[]){v_xs_244, v_p_241, v_p_242});
    switch (heff_tag_of(v_p_245)) {
    case TAG_At: {
      V v_p1_2412 = heff_dup(heff_field(v_p_245, 0));
      switch (heff_tag_of(v_p1_2412)) {
      case TAG_PatVar: {
        V v_x_2414 = heff_field(v_p1_2412, 0);
        heff_take_n(v_p1_2412, 1ULL, 1);
        heff_drop(v_bind_247);
        heff_drop(v_malg_248);
        switch (heff_tag_of(v_p_245)) {
        case TAG_At: {
          heff_take_n(v_p_245, 0ULL, 2);
          return heff_tail(v_p_2411, 1, (V[]){v_x_2414});
        }
        default: return heff_nomatch(v_p_245);
        }
      }
      default: {
        heff_drop(v_p1_2412);
        V v_t_2419;
        switch (heff_tag_of(v_p_245)) {
        case TAG_At: {
          V v_s_2418 = heff_field(v_p_245, 1);
          heff_take_n(v_p_245, 2ULL, 2);
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_p_245);
        }
        V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1157078602x1175067503_str0), v_t_2419, NTAG(TAG_Nothing)});
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tr(heff_call(v_malg_248, 1, (V[]){v_t_2422}));
        return heff_tail(v_bind_247, 2, (V[]){v_t_2423, v_p_2411});
      }
      }
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1157078602x1175067503(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s1157078602x1175067503_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_249, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1157078602x1175067503_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_prelude_2etraverse_24s1157078602x1175067503(v_xs_244, v_p_241, heff_clo_n(g_prelude_2etraverse_24s1157078602x1175067503_lam1, 1, 2, (V[]){v_p_242, v_a_249})));
}
V g_prelude_2etraverse_24s515579549x140669784_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s515579549x140669784_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s515579549x140669784_lam0, 2, 0};
V g_prelude_2etraverse_24s515579549x140669784_lam2(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam1(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam5(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam4(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s515579549x140669784_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s515579549x140669784_entry, 1, 0};

V g_prelude_2etraverse_24s515579549x140669784(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s515579549x140669784_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_a_248));
        v_a_2414 = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam1, 2, 3, (V[]){v_a_249, v_a_246, v_a_247});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam3, 2, 2, (V[]){v_a_2414, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s515579549x140669784(a[0]);
}
V g_prelude_2etraverse_24s515579549x140669784_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam2(V self, V *args) {
  V v_a_2412 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = (g_heff_2eelab_2etoplevel_2eupdatePath(v_a_246, v_a_247, v_a_2412));
  V f_ = v_t_2413;
  heff_room[0] = v_a_2410;
  heff_room[1] = v_a_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s515579549x140669784_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_2411 = args[1];
  V v_a_249 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_249;
  args[0] = heff_dup(v_a_2410);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam2, 1, 4, (V[]){v_a_246, v_a_247, v_a_2410, v_a_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_a_2416 = heff_env(self)[0];
  V v_a_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2416;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2417, v_a_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam4(V self, V *args) {
  V v_a_2417 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_2415 = heff_env(self)[1];
  V v_a_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2418 = (g_prelude_2etraverse_24s515579549x140669784(v_xs_244));
  V f_ = v_a_2418;
  heff_room[0] = v_a_2415;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam5, 1, 2, (V[]){v_a_2416, v_a_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s515579549x140669784_lam3(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2416 = args[1];
  V v_a_2414 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2414;
  args[0] = heff_dup(v_a_2415);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam4, 1, 3, (V[]){v_xs_244, v_a_2415, v_a_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_prelude_2etraverse_24s1211845059x266223635_str0, 19, "expected small type");
HEFF_LIT(g_prelude_2etraverse_24s1211845059x266223635_str1, 19, "expected small type");
V g_prelude_2etraverse_24s1211845059x266223635_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1211845059x266223635_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1211845059x266223635_lam0, 2, 0};
V g_prelude_2etraverse_24s1211845059x266223635_lam6(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam5(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam4(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam3(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam2(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1211845059x266223635_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1211845059x266223635_entry, 1, 0};

V g_prelude_2etraverse_24s1211845059x266223635(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1211845059x266223635_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(heff_dup(v_x_243)));
    return heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam1, 2, 3, (V[]){v_a_245, v_xs_244, v_x_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1211845059x266223635(a[0]);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  V v_hd_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2420, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2425;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_t_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_x1_2425 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2422); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2423 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_x1_2425 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2423); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_x1_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2424); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_Small: {
    heff_drop(v_sp_2413);
    heff_drop_rec(v_hd_2418, 3);
    V f_ = v_k_2419;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Large: {
    heff_drop_rec(v_x_2420, 2);
    V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1211845059x266223635_str0), v_sp_2413, NTAG(TAG_Nothing)});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_2418, 2), 1, (V[]){v_t_2428}));
    V f_ = heff_get_n(v_hd_2418, 1, 3);
    heff_room[0] = v_t_2429;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_TopL: {
    heff_drop_rec(v_x_2420, 2);
    V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1211845059x266223635_str1), v_sp_2413, NTAG(TAG_Nothing)});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_2418, 2), 1, (V[]){v_t_2432}));
    V f_ = heff_get_n(v_hd_2418, 1, 3);
    heff_room[0] = v_t_2433;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_prelude_2etraverse_24s1211845059x266223635_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam6, 1, 3, (V[]){v_k_2419, v_sp_2413, v_hd_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam4(V self, V *args) {
  V v_e_2415 = args[0];
  V v_typ_2414 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2417;
  switch (heff_tag_of(v_typ_2414)) {
  case TAG_MkTyp: {
    V v_f_2416 = heff_field(v_typ_2414, 0);
    heff_take_n(v_typ_2414, 1ULL, 1);
    v_c_2417 = heff_tr(heff_call(v_f_2416, 1, (V[]){v_e_2415}));
    break;
  }
  default: heff_nomatch(v_typ_2414);
  }
  return heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam5, 2, 2, (V[]){v_c_2417, v_sp_2413});
}
V g_prelude_2etraverse_24s1211845059x266223635_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_sp_2413;
  switch (heff_tag_of(v_x_243)) {
  case TAG_At: {
    V v_a_2412 = heff_field(v_x_243, 1);
    heff_take_n(v_x_243, 2ULL, 2);
    v_sp_2413 = v_a_2412;
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_typ_2414 = v_a_248;
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkSmallTyp, 1, (V[]){heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam4, 1, 2, (V[]){v_typ_2414, v_sp_2413})}), v_a_2410});
  V f_ = v_a_247;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_a_249 = (g_prelude_2etraverse_24s1211845059x266223635(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam3, 1, 3, (V[]){v_x_243, v_a_248, v_a_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1211845059x266223635_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam2, 1, 4, (V[]){v_xs_244, v_a_246, v_x_243, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1310917876x950458632_lam1(V self, V *args);
V g_prelude_2etraverse_24s1310917876x950458632_lam0(V self, V *args);
V g_prelude_2etraverse_24s1310917876x950458632_lam2(V self, V *args);
V g_prelude_2etraverse_24s1310917876x950458632_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s1310917876x950458632_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1310917876x950458632_entry, 2, 0};

V g_prelude_2etraverse_24s1310917876x950458632(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tail(v_p_241, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_244 = v_x_242;
    V v_p_247 = heff_clo_n(g_prelude_2etraverse_24s1310917876x950458632_lam0, 1, 2, (V[]){v_xs_243, v_p_241});
    switch (heff_tag_of(v_x1_244)) {
    case TAG_At: {
      V v_x11_248 = heff_field(v_x1_244, 0);
      V v_sp_249 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 3ULL, 2);
      switch (heff_tag_of(v_x11_248)) {
      case TAG_ExplicitParam: {
        V v_x_2410 = heff_field(v_x11_248, 0);
        V v_t_2412 = heff_field(v_x11_248, 2);
        heff_take_n(v_x11_248, 5ULL, 3);
        V v_n_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_n_2413 = heff_field(v_t_2412, 0);
          V v_sp_2414 = heff_field(v_t_2412, 1);
          heff_take_n(v_t_2412, 3ULL, 2);
          v_n_2415 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x2_240_24Cons, v_sp_2414, v_n_2413));
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        V v_t_2416 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2415));
        return heff_tail(v_t_2416, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1310917876x950458632_lam2, 1, 3, (V[]){v_sp_249, v_x_2410, v_p_247})});
      }
      case TAG_ImplicitParam: {
        V v_x_2419 = heff_field(v_x11_248, 0);
        V v_t_2421 = heff_field(v_x11_248, 2);
        heff_take_n(v_x11_248, 5ULL, 3);
        V v_n_2424;
        switch (heff_tag_of(v_t_2421)) {
        case TAG_At: {
          V v_n_2422 = heff_field(v_t_2421, 0);
          V v_sp_2423 = heff_field(v_t_2421, 1);
          heff_take_n(v_t_2421, 3ULL, 2);
          v_n_2424 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x2_240_24Cons, v_sp_2423, v_n_2422));
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
        V v_t_2425 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2424));
        return heff_tail(v_t_2425, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1310917876x950458632_lam3, 1, 3, (V[]){v_sp_249, v_x_2419, v_p_247})});
      }
      default: return heff_nomatch(v_x11_248);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1310917876x950458632_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1310917876x950458632(a[0], a[1]);
}
V g_prelude_2etraverse_24s1310917876x950458632_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_a_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_241;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_a_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1310917876x950458632_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_xs_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_prelude_2etraverse_24s1310917876x950458632(v_xs_243, heff_clo_n(g_prelude_2etraverse_24s1310917876x950458632_lam1, 1, 2, (V[]){v_p_241, v_a_245})));
}
V g_prelude_2etraverse_24s1310917876x950458632_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_sp_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_249, v_x_2410, v_x_2417, NTAG(TAG_Expl)});
  V f_ = v_p_247;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1310917876x950458632_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_sp_249 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_249, v_x_2419, v_x_2426, NTAG(TAG_Impl)});
  V f_ = v_p_247;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_prelude_2e_2b_2b_24f658301291x587486003_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f658301291x587486003_entry, 2, 0};

V g_prelude_2e_2b_2b_24f658301291x587486003(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = (g_prelude_2e_2b_2b_24f658301291x587486003_24dps(v_ys_240, v_x12_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f658301291x587486003_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f658301291x587486003(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f658301291x587486003_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f658301291x587486003_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f658301291x587486003_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_x12_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_x12_244;
      V t_2 = v_cell_247;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x12_244);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f658301291x587486003_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f658301291x587486003_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_entry, 2, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_t_245 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_242); r_; });
    V v_u_246 = (g_prelude_2e_2b_2b_24f368057430x559112032_24dps(v_ys_240, v_t_245, heff_dup(v_cell_244)));
    heff_drop(v_u_246);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f368057430x559112032(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_243); r_; });
    V t_0 = v_ys_240;
    V t_1 = v_t_247;
    V t_2 = v_cell_245;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f368057430x559112032_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1681798656x925918587_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1681798656x925918587_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1681798656x925918587(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_EVar, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f1681798656x925918587_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1681798656x925918587_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1681798656x925918587(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_entry, 3, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251(V v_ys_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(v_ys_240, v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f489629841x1061860251(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_x12_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_x12_244;
      V t_2 = v_cell_247;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x12_244);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f709746438x971999636_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_strAppend(heff_dup(v_lit_241), v_x_243);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1306153264x1245859556(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_strAppend(heff_dup(v_lit_241), v_x_244);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry, 10, 0};

V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return heff_setField(v_d_249, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_247, 0);
    V v_xs_2411 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_2410);
      heff_drop(v_xs_2411);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return heff_setField(v_d_249, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x3_248, 0);
      V v_ys_2413 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2410); r_; });
      V v_t_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2414), heff_dup(v_lit_245));
      V v_t_2416 = heff_strAppend(v_t_2415, heff_intShow(v_y_2412));
      V v_x_2417 = heff_strAppend(v_t_2416, heff_dup(v_lit_246));
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2419 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_2411;
      V t_8 = v_ys_2413;
      V t_9 = v_cell_2418;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      v_x3_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_prelude_2e_2b_2b_24f132290754x1091834184_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f132290754x1091834184_entry, 4, 0};

V g_prelude_2e_2b_2b_24f132290754x1091834184(V v_ys_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_x_246 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_lit_242)), heff_intShow(v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = (g_prelude_2e_2b_2b_24f132290754x1091834184_24dps(v_ys_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2e_2b_2b_24f132290754x1091834184_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f132290754x1091834184(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1815933030x829523367_str0, 1, ":");
Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1815933030x829523367_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1815933030x829523367(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_x_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_prelude_2e_2b_2b_24f1815933030x829523367_str0)), v_x_242);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1815933030x829523367(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_241))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_246;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_241), heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_246;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(a[0], a[1], a[2], a[3]);
}