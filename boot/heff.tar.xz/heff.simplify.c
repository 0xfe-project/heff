// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Inlined 13187
#define TAG_MkArm 55352
#define TAG_NotInlined 18181
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_e 319
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_made 9839068
#define LBL_match 305026527
#define LBL_n 328
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_op 10312
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipes 1314274025
#define LBL_ren 322325
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_underLam 296337946
#define LBL_vars 10107635
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_e__vars__holes__n[] = {LBL_e, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_ren__vars__holes__n[] = {LBL_ren, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_simp__applyTo__project__match[] = {LBL_simp, LBL_applyTo, LBL_project, LBL_match};
static uint32_t shape_supply__fuel__defs__safe__total__plain__sp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_total, LBL_plain, LBL_sp};
V g_heff_2efixed_2efixedPrimOf(V);
V g_heff_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2efixed_2efixedPrimOf_clo;
V g_heff_2eir_2eallI(V);
V g_heff_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2eir_2eallI_clo;
V g_heff_2eir_2ecountW(V, V, V);
V g_heff_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2eir_2ecountW_clo;
V g_heff_2eir_2efreshGo_24s1749472566x1664180022(V, V, V);
V g_heff_2eir_2efreshGo_24s1749472566x1664180022_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshGo_24s1749472566x1664180022_clo;
V g_heff_2eir_2eglobalsGo(V);
V g_heff_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2eir_2eglobalsGo_clo;
V g_heff_2eir_2eisValue(V);
V g_heff_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2eir_2eisValue_clo;
V g_heff_2eir_2elamW(V, V);
V g_heff_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2eir_2elamW_clo;
V g_heff_2eir_2enubI(V);
V g_heff_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2eir_2enubI_clo;
V g_heff_2eir_2esizeB(V, V, V);
V g_heff_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2eir_2esizeB_clo;
V g_heff_2eir_2esizeW(V, V);
V g_heff_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2eir_2esizeW_clo;
V g_heff_2eir_2esubstGo(V, V);
V g_heff_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2eir_2esubstGo_clo;
V g_heff_2eprims_2eallPrims_get(void);
V g_heff_2eprims_2eprimArityGo(V, V);
V g_heff_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2eprims_2eprimArityGo_clo;
V g_heff_2esimplify_2eappendL(V, V);
V g_heff_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eappendL_clo;
V g_heff_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eapplyLam_clo;
V g_heff_2esimplify_2eapplyToF(V, V, V);
V g_heff_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eapplyToF_clo;
V g_heff_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eask_clo;
V g_heff_2esimplify_2easkedFor(V, V, V, V);
V g_heff_2esimplify_2easkedFor_entry(V self, V *a);
extern Clo g_heff_2esimplify_2easkedFor_clo;
V g_heff_2esimplify_2eattempt(V, V, V);
V g_heff_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eattempt_clo;
V g_heff_2esimplify_2ebackTo(V, V);
V g_heff_2esimplify_2ebackTo_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ebackTo_clo;
V g_heff_2esimplify_2ebinOp(V, V, V);
V g_heff_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ebinOp_clo;
V g_heff_2esimplify_2ebudget_get(void);
V g_heff_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ecallOf_clo;
V g_heff_2esimplify_2ecaseBudget_get(void);
V g_heff_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ecaseOfCase_clo;
V g_heff_2esimplify_2echeap(V, V);
V g_heff_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2esimplify_2echeap_clo;
V g_heff_2esimplify_2econcatDefs(V);
V g_heff_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2esimplify_2econcatDefs_clo;
V g_heff_2esimplify_2edepthOf(V, V, V);
V g_heff_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2edepthOf_clo;
V g_heff_2esimplify_2edropL(V, V);
V g_heff_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2edropL_clo;
V g_heff_2esimplify_2eelemStr(V, V);
V g_heff_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eelemStr_clo;
V g_heff_2esimplify_2eeta(V, V);
V g_heff_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eeta_clo;
V g_heff_2esimplify_2eetaHead(V, V, V);
V g_heff_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eetaHead_clo;
V g_heff_2esimplify_2efailing_get(void);
V g_heff_2esimplify_2efieldIn(V, V);
V g_heff_2esimplify_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efieldIn_clo;
V g_heff_2esimplify_2efindArm(V, V);
V g_heff_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efindArm_clo;
V g_heff_2esimplify_2efindField(V, V);
V g_heff_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efindField_clo;
V g_heff_2esimplify_2eflat(V);
V g_heff_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eflat_clo;
V g_heff_2esimplify_2efreshParams(V, V);
V g_heff_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2esimplify_2efreshParams_clo;
V g_heff_2esimplify_2einlineCall(V, V, V, V, V);
V g_heff_2esimplify_2einlineCall_entry(V self, V *a);
extern Clo g_heff_2esimplify_2einlineCall_clo;
V g_heff_2esimplify_2einlineMax_get(void);
V g_heff_2esimplify_2eintOp(V, V, V);
V g_heff_2esimplify_2eintOp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eintOp_clo;
V g_heff_2esimplify_2eisPure(V, V);
V g_heff_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eisPure_clo;
V g_heff_2esimplify_2ekeepParams(V, V);
V g_heff_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ekeepParams_clo;
V g_heff_2esimplify_2eknowing(V, V, V);
V g_heff_2esimplify_2eknowing_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eknowing_clo;
V g_heff_2esimplify_2eknown(V, V);
V g_heff_2esimplify_2eknown_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eknown_clo;
V g_heff_2esimplify_2eknownArg(V, V);
V g_heff_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eknownArg_clo;
V g_heff_2esimplify_2eknownField(V, V, V);
V g_heff_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eknownField_clo;
V g_heff_2esimplify_2elam(V, V);
V g_heff_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2esimplify_2elam_clo;
V g_heff_2esimplify_2elamsOut(V, V);
V g_heff_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2esimplify_2elamsOut_clo;
V g_heff_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eletIn_clo;
V g_heff_2esimplify_2eletPure(V, V, V, V, V);
V g_heff_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eletPure_clo;
V g_heff_2esimplify_2eletsOf(V, V);
V g_heff_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eletsOf_clo;
V g_heff_2esimplify_2emadeOne(V, V);
V g_heff_2esimplify_2emadeOne_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emadeOne_clo;
V g_heff_2esimplify_2emakeEach(V, V);
V g_heff_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emakeEach_clo;
V g_heff_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emakeOne_clo;
V g_heff_2esimplify_2emarkGo(V, V, V, V);
V g_heff_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emarkGo_clo;
V g_heff_2esimplify_2emarkSafe(V, V, V);
V g_heff_2esimplify_2emarkSafe_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emarkSafe_clo;
V g_heff_2esimplify_2emarkedOf(V, V);
V g_heff_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emarkedOf_clo;
V g_heff_2esimplify_2ematchF(V, V, V);
V g_heff_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ematchF_clo;
V g_heff_2esimplify_2emkApp(V, V);
V g_heff_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2emkApp_clo;
V g_heff_2esimplify_2enthE(V, V);
V g_heff_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2esimplify_2enthE_clo;
V g_heff_2esimplify_2eoneDef(V, V);
V g_heff_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eoneDef_clo;
V g_heff_2esimplify_2eothersPure(V, V);
V g_heff_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eothersPure_clo;
V g_heff_2esimplify_2eparamsAre(V, V);
V g_heff_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eparamsAre_clo;
V g_heff_2esimplify_2epartialHead(V, V, V);
V g_heff_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epartialHead_clo;
V g_heff_2esimplify_2epartialOf(V, V, V);
V g_heff_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epartialOf_clo;
V g_heff_2esimplify_2eplainCall(V, V, V, V, V);
V g_heff_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eplainCall_clo;
V g_heff_2esimplify_2eprimAppN(V, V, V);
V g_heff_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eprimAppN_clo;
V g_heff_2esimplify_2eprimFails(V);
V g_heff_2esimplify_2eprimFails_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eprimFails_clo;
V g_heff_2esimplify_2eprojectF(V, V, V);
V g_heff_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eprojectF_clo;
V g_heff_2esimplify_2epureIn(V, V, V);
V g_heff_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epureIn_clo;
V g_heff_2esimplify_2epushArm(V, V, V, V);
V g_heff_2esimplify_2epushArm_entry(V self, V *a);
extern Clo g_heff_2esimplify_2epushArm_clo;
V g_heff_2esimplify_2eraise(V, V);
V g_heff_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eraise_clo;
V g_heff_2esimplify_2erecordAll(V, V, V);
V g_heff_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2esimplify_2erecordAll_clo;
V g_heff_2esimplify_2erecordDef(V, V, V);
V g_heff_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2esimplify_2erecordDef_clo;
V g_heff_2esimplify_2eremember(V, V, V);
V g_heff_2esimplify_2eremember_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eremember_clo;
V g_heff_2esimplify_2esetOff(V, V);
V g_heff_2esimplify_2esetOff_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esetOff_clo;
V g_heff_2esimplify_2esgFlat(V, V, V);
V g_heff_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esgFlat_clo;
V g_heff_2esimplify_2eshapeOne(V, V, V);
V g_heff_2esimplify_2eshapeOne_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eshapeOne_clo;
V g_heff_2esimplify_2eshapesOf(V, V, V);
V g_heff_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eshapesOf_clo;
V g_heff_2esimplify_2esimpF(V, V);
V g_heff_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esimpF_clo;
V g_heff_2esimplify_2esimplifyProgram(V, V);
V g_heff_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esimplifyProgram_clo;
V g_heff_2esimplify_2esk_get(void);
V g_heff_2esimplify_2especArgSize_get(void);
V g_heff_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especBody_clo;
V g_heff_2esimplify_2especBodySize_get(void);
V g_heff_2esimplify_2especDepth_get(void);
V g_heff_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especLam_clo;
V g_heff_2esimplify_2especLimit_get(void);
V g_heff_2esimplify_2especMarked(V, V, V, V, V, V);
V g_heff_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especMarked_clo;
V g_heff_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V);
V g_heff_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especNamed_clo;
V g_heff_2esimplify_2especShaped(V, V, V, V, V, V, V, V);
V g_heff_2esimplify_2especShaped_entry(V self, V *a);
extern Clo g_heff_2esimplify_2especShaped_clo;
V g_heff_2esimplify_2estillCall(V, V);
V g_heff_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2esimplify_2estillCall_clo;
V g_heff_2esimplify_2estripLams(V, V);
V g_heff_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2esimplify_2estripLams_clo;
V g_heff_2esimplify_2esubstCopies(V, V, V);
V g_heff_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esubstCopies_clo;
V g_heff_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esubstMarked_clo;
V g_heff_2esimplify_2etakeL(V, V);
V g_heff_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etakeL_clo;
V g_heff_2esimplify_2etakesMore(V, V, V);
V g_heff_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etakesMore_clo;
V g_heff_2esimplify_2etraverseS(V, V);
V g_heff_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etraverseS_clo;
V g_heff_2esimplify_2etraverseS_24s1959824798x755618522(V, V);
V g_heff_2esimplify_2etraverseS_24s1959824798x755618522_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etraverseS_24s1959824798x755618522_clo;
V g_heff_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2esimplify_2etrySpec_clo;
V g_heff_2esimplify_2eunOp(V, V);
V g_heff_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eunOp_clo;
V g_heff_2esimplify_2evarsAre(V, V);
V g_heff_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2esimplify_2evarsAre_clo;
V g_heff_2esimplify_2ezipL(V, V);
V g_heff_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2esimplify_2ezipL_clo;
V g_heff_2espec_2eclosedIn(V, V);
V g_heff_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2espec_2eclosedIn_clo;
V g_heff_2espec_2edropAt(V, V);
V g_heff_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2espec_2edropAt_clo;
V g_heff_2espec_2ehashGo(V, V, V, V);
V g_heff_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2espec_2ehashGo_clo;
V g_heff_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2espec_2eselfTo_clo;
V g_heff_2espec_2eshapeGo(V, V);
V g_heff_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2espec_2eshapeGo_clo;
V g_heff_2espec_2estaticGo(V, V, V);
V g_heff_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2espec_2estaticGo_clo;
V g_heff_2espec_2eusesOf(V, V);
V g_heff_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2espec_2eusesOf_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_prelude_2eany(V, V);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2eany_24s1963868307x1860200435(V);
V g_prelude_2eany_24s1963868307x1860200435_entry(V self, V *a);
extern Clo g_prelude_2eany_24s1963868307x1860200435_clo;
V g_prelude_2eany_24s438096394x623120595(V);
V g_prelude_2eany_24s438096394x623120595_entry(V self, V *a);
extern Clo g_prelude_2eany_24s438096394x623120595_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1075493002x264635373(V, V, V, V, V);
V g_prelude_2efoldl_24s1075493002x264635373_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1075493002x264635373_clo;
V g_prelude_2efoldl_24s1163606919x177582362(V, V);
V g_prelude_2efoldl_24s1163606919x177582362_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1163606919x177582362_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s1431458237x755517792(V, V);
V g_prelude_2efoldl_24s1431458237x755517792_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1431458237x755517792_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s1700457534x694272192(V, V);
V g_prelude_2efoldl_24s1700457534x694272192_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1700457534x694272192_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2efoldl_24s279777603x1686732349(V, V);
V g_prelude_2efoldl_24s279777603x1686732349_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s279777603x1686732349_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1295898052x1915853031(V);
V g_prelude_2emap_24s1295898052x1915853031_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1295898052x1915853031_clo;
V g_prelude_2emap_24s1448703749x94773476(V);
V g_prelude_2emap_24s1448703749x94773476_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1448703749x94773476_clo;
V g_prelude_2emap_24s1645030849x525483621(V);
V g_prelude_2emap_24s1645030849x525483621_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1645030849x525483621_clo;
V g_prelude_2emap_24s1716181342x353410538(V);
V g_prelude_2emap_24s1716181342x353410538_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1716181342x353410538_clo;
V g_prelude_2emap_24s2083806615x1058260173(V);
V g_prelude_2emap_24s2083806615x1058260173_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2083806615x1058260173_clo;
V g_prelude_2emap_24s764047539x1158385979(V);
V g_prelude_2emap_24s764047539x1158385979_entry(V self, V *a);
extern Clo g_prelude_2emap_24s764047539x1158385979_clo;
V g_prelude_2erange(V, V);
V g_prelude_2erange_entry(V self, V *a);
extern Clo g_prelude_2erange_clo;
V g_prelude_2ezipWith_24s836893971x454572333(V, V, V);
V g_prelude_2ezipWith_24s836893971x454572333_entry(V self, V *a);
extern Clo g_prelude_2ezipWith_24s836893971x454572333_clo;

static V g_heff_2esimplify_2ebudget_val;
static int g_heff_2esimplify_2ebudget_st;
static V g_heff_2esimplify_2ebudget_init(void) {
  return MK_INT(24LL);
}
V g_heff_2esimplify_2ebudget_get(void) {
  if (g_heff_2esimplify_2ebudget_st == 2) return g_heff_2esimplify_2ebudget_val;
  if (g_heff_2esimplify_2ebudget_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2ebudget_st = 1;
  g_heff_2esimplify_2ebudget_val = heff_tr(g_heff_2esimplify_2ebudget_init());
  g_heff_2esimplify_2ebudget_st = 2;
  return g_heff_2esimplify_2ebudget_val;
}
V g_heff_2esimplify_2etraverseS_lam0(V self, V *args); static Clo g_heff_2esimplify_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etraverseS_lam0, 1, 0};
V g_heff_2esimplify_2etraverseS_lam1(V self, V *args);
Clo g_heff_2esimplify_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etraverseS_entry, 2, 0};

V g_heff_2esimplify_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2esimplify_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo(g_heff_2esimplify_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etraverseS(a[0], a[1]);
}
V g_heff_2esimplify_2etraverseS_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2esimplify_2etraverseS_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2esimplify_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_apply(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2esimplify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eappendL_entry, 2, 0};

V g_heff_2esimplify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2esimplify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eappendL(a[0], a[1]);
}
Clo g_heff_2esimplify_2eelemStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eelemStr_entry, 2, 0};

V g_heff_2esimplify_2eelemStr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eelemStr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eelemStr(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ezipL_entry, 2, 0};

V g_heff_2esimplify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2esimplify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ezipL(a[0], a[1]);
}
Clo g_heff_2esimplify_2etakeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etakeL_entry, 2, 0};

V g_heff_2esimplify_2etakeL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2esimplify_2etakeL(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2etakeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etakeL(a[0], a[1]);
}
Clo g_heff_2esimplify_2edropL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2edropL_entry, 2, 0};

V g_heff_2esimplify_2edropL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2edropL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2edropL(a[0], a[1]);
}
Clo g_heff_2esimplify_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eletsOf_entry, 2, 0};

V g_heff_2esimplify_2eletsOf(V v_x1_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_body_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      return heff_tag(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), (g_heff_2esimplify_2eletsOf(v_rest_243, v_body_241))});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2eletsOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eletsOf(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2esimplify_2eknown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eknown_entry, 2, 0};

V g_heff_2esimplify_2eknown(V v_g_240, V v_s_241) {
top: ;
  V v_t_242 = ({ V a_0 = v_g_240; V b_1 = heff_get(heff_dup(v_s_241), LBL_defs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_244 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_241), LBL_fuel));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_intSub(heff_get(heff_dup(v_s_241), LBL_fuel), MK_INT(1LL));
      V v_s_246 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), v_t_245, heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(heff_dup(v_s_241), LBL_plain), heff_get(v_s_241, LBL_sp)});
      V v_x2_247 = (g_heff_2eir_2efreshGo_24s1749472566x1664180022(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_246), LBL_supply), v_b_243));
      V v_x2_2411;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_e_27_248 = heff_field(v_x2_247, 0);
        V v_n_249 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        V v_t_2410 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n_249, heff_get(heff_dup(v_s_246), LBL_fuel), heff_get(heff_dup(v_s_246), LBL_defs), heff_get(heff_dup(v_s_246), LBL_safe), heff_get(heff_dup(v_s_246), LBL_total), heff_get(heff_dup(v_s_246), LBL_plain), heff_get(v_s_246, LBL_sp)});
        v_x2_2411 = heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_248, v_t_2410});
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_s_2413 = heff_field(v_x2_2411, 1);
        V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_x_2412}), v_s_2413});
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    case TAG_False: {
      heff_drop(v_b_243);
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esimplify_2eknown_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eknown(a[0], a[1]);
}
Clo g_heff_2esimplify_2eattempt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eattempt_entry, 3, 0};

V g_heff_2esimplify_2eattempt(V v_orig_240, V v_m_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_apply(v_m_241, 1, (V[]){heff_dup(v_s_242)}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_tag_at(v_ru_24x2_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_orig_240), NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_lim_248 = heff_intAdd(v_t_247, heff_dup(g_heff_2esimplify_2ebudget_get()));
    V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
    V v_a_2410 = (g_heff_2eir_2esizeB(heff_dup(v_lim_248), MK_INT(0LL), v_t_249));
    V v_x1_2411 = heff_intLt(v_lim_248, v_a_2410);
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      heff_drop(v_x_244);
      V v_t_2412 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_245), LBL_supply), heff_get(heff_dup(v_s_245), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_245), LBL_safe), heff_get(v_s_242, LBL_total), heff_get(heff_dup(v_s_245), LBL_plain), heff_get(v_s_245, LBL_sp)});
      return heff_tag(TAG_MkPair, 2, (V[]){v_orig_240, v_t_2412});
    }
    case TAG_False: {
      heff_drop(v_orig_240);
      heff_drop(v_s_242);
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2esimplify_2eattempt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eattempt(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2esimplify_2efailing_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 101, 114, 102, 111, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2esimplify_2efailing_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 114, 97, 121, 83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2esimplify_2efailing_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2esimplify_2efailing_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 70, 108, 111, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2esimplify_2efailing_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 114, 114, 97, 121, 73, 110, 100, 101, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2efailing_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2efailing_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 111, 100}};

static V g_heff_2esimplify_2efailing_val;
static int g_heff_2esimplify_2efailing_st;
static V g_heff_2esimplify_2efailing_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str4), v_t_241})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str6), v_t_242})});
}
V g_heff_2esimplify_2efailing_get(void) {
  if (g_heff_2esimplify_2efailing_st == 2) return g_heff_2esimplify_2efailing_val;
  if (g_heff_2esimplify_2efailing_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2efailing_st = 1;
  g_heff_2esimplify_2efailing_val = heff_tr(g_heff_2esimplify_2efailing_init());
  g_heff_2esimplify_2efailing_st = 2;
  return g_heff_2esimplify_2efailing_val;
}
Clo g_heff_2esimplify_2eprimFails_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eprimFails_entry, 1, 0};

V g_heff_2esimplify_2eprimFails(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2esimplify_2efailing_get()); V r_ = (g_heff_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_x3_242 = (g_heff_2efixed_2efixedPrimOf(v_p_240));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      V v_t_244 = heff_get(v_x_243, LBL_op);
      switch (heff_tag_of(v_t_244)) {
      case TAG_OpAdd: {
        return NTAG(TAG_False);
      }
      case TAG_OpSub: {
        return NTAG(TAG_False);
      }
      case TAG_OpMul: {
        return NTAG(TAG_False);
      }
      case TAG_OpDiv: {
        return NTAG(TAG_True);
      }
      case TAG_OpRem: {
        return NTAG(TAG_True);
      }
      case TAG_OpEq: {
        return NTAG(TAG_False);
      }
      case TAG_OpLt: {
        return NTAG(TAG_False);
      }
      case TAG_OpLe: {
        return NTAG(TAG_False);
      }
      case TAG_OpAnd: {
        return NTAG(TAG_False);
      }
      case TAG_OpOr: {
        return NTAG(TAG_False);
      }
      case TAG_OpXor: {
        return NTAG(TAG_False);
      }
      case TAG_OpShl: {
        return NTAG(TAG_False);
      }
      case TAG_OpShr: {
        return NTAG(TAG_False);
      }
      case TAG_OpShow: {
        return NTAG(TAG_False);
      }
      case TAG_OpFromInt: {
        return NTAG(TAG_False);
      }
      case TAG_OpToInt: {
        return NTAG(TAG_False);
      }
      case TAG_OpSqrt: {
        return NTAG(TAG_False);
      }
      case TAG_OpFromFloat: {
        return NTAG(TAG_False);
      }
      case TAG_OpToFloat: {
        return NTAG(TAG_False);
      }
      case TAG_OpFloor: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esimplify_2eprimFails_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eprimFails(a[0]);
}
V g_heff_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2esimplify_2epureIn_lam4(V self, V *args);
Clo g_heff_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_242, 0);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_244), v_safe_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_it1_249 = heff_field(v_e_242, 0);
    V v_as_2410 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2412 = heff_field(v_it1_249, 0);
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2412), v_total_241));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_ar_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_t_2415 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_2410));
        V v_t_2416 = heff_intLe(v_t_2415, v_ar_2414);
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          V v_t_2418 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2410)));
          return ({ V a_0 = v_t_2418; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2418); r_; });
        }
        case TAG_False: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2449 = heff_field(v_e_242, 0);
    V v_t_2453 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_fs_2449)));
    return ({ V a_0 = v_t_2453; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2453); r_; });
  }
  case TAG_EProj: {
    V v_e2_2454 = heff_field(v_e_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_total_241;
    V t_2 = v_e2_2454;
    v_safe_240 = t_0;
    v_total_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2457 = heff_field(v_e_242, 1);
    V v_t_2459 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2457)));
    return ({ V a_0 = v_t_2459; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2459); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2463 = heff_field(v_e_242, 0);
    V v_as_2464 = heff_field(v_e_242, 1);
    V v_x1_2465 = (g_heff_2esimplify_2eprimFails(heff_dup(v_p_2463)));
    switch (heff_tag_of(v_x1_2465)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_t_2467 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2464)));
      return ({ V a_0 = v_t_2467; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2467); r_; });
    }
    default: return heff_nomatch(v_x1_2465);
    }
  }
  case TAG_ECall: {
    V v_g_2468 = heff_field(v_e_242, 0);
    V v_as_2469 = heff_field(v_e_242, 1);
    V v_t_2470 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2468), v_total_241));
    switch (heff_tag_of(v_t_2470)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_ar_2471 = heff_field(v_t_2470, 0);
      heff_take_n(v_t_2470, 1ULL, 1);
      V v_t_2472 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_2469));
      V v_t_2473 = heff_intLe(v_t_2472, v_ar_2471);
      switch (heff_tag_of(v_t_2473)) {
      case TAG_True: {
        V v_t_2475 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2469)));
        return ({ V a_0 = v_t_2475; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2475); r_; });
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2473);
      }
    }
    default: return heff_nomatch(v_t_2470);
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2epureIn(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2417; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2417); r_; });
}
V g_heff_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_p_2450 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2450)) {
  case TAG_MkPair: {
    V v_e2_2452 = heff_field(v_p_2450, 1);
    heff_take_n(v_p_2450, 2ULL, 2);
    return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_e2_2452; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_e2_2452); r_; });
  }
  default: return heff_nomatch(v_p_2450);
  }
}
V g_heff_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2458 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2458; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2458); r_; });
}
V g_heff_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_a_2466 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2466; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2466); r_; });
}
V g_heff_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2474 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2474; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2474); r_; });
}
Clo g_heff_2esimplify_2eflat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eflat_entry, 1, 0};

V g_heff_2esimplify_2eflat(V v_b_240) {
top: ;
  switch (heff_tag_of(v_b_240)) {
  case TAG_EVar: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EGlobal: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_b_240, 0);
    V v_b2_244 = heff_field(v_b_240, 1);
    V v_ru_24b_240_24ELam = heff_take_reuse_n(v_b_240, 3ULL, 2);
    V v_x2_245 = (g_heff_2esimplify_2eflat(v_b2_244));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_ys_246 = heff_field(v_x2_245, 0);
      V v_b_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_t_248 = (g_heff_2esimplify_2eappendL(v_xs_243, v_ys_246));
      return heff_tag_at(v_ru_24b_240_24ELam, TAG_MkPair, 2, (V[]){v_t_248, v_b_247});
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  case TAG_EApp: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELet: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ERecord: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EProj: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ETag: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EMatch: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrim: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrimCall: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ECall: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EInt: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFloat: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EStr: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFixed: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFloat32: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFix: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  default: return heff_nomatch(v_b_240);
  }
}
V g_heff_2esimplify_2eflat_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eflat(a[0]);
}
Clo g_heff_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_a_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    V v_t_246 = heff_intLt(MK_INT(0LL), v_a_245);
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = ({ V b_0 = heff_get(heff_dup(v_acc_240), LBL_safe); V b_1 = heff_get(heff_dup(v_acc_240), LBL_total); V a_2 = v_b_244; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_t_248 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_249 = (g_heff_2eir_2enubI(v_t_248));
        V v_x1_2410 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_249; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_249); r_; });
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_True: {
          V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
          return heff_rec(2, shape_safe__total, (V[]){v_t_2411, heff_get(v_acc_240, LBL_total)});
        }
        case TAG_False: {
          V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_241), NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
          V v_t_2413 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_243));
          V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_key_241, v_t_2413, heff_get(v_acc_240, LBL_total)));
          return heff_rec(2, shape_safe__total, (V[]){v_t_2412, v_t_2414});
        }
        default: return heff_nomatch(v_x1_2410);
        }
      }
      case TAG_False: {
        V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
        return heff_rec(2, shape_safe__total, (V[]){v_t_2415, heff_get(v_acc_240, LBL_total)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_False: {
      V v_t_2416 = ({ V b_0 = heff_get(heff_dup(v_acc_240), LBL_safe); V b_1 = heff_get(heff_dup(v_acc_240), LBL_total); V a_2 = v_b_244; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        V v_t_2417 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_2418 = (g_heff_2eir_2enubI(v_t_2417));
        V v_x1_2419 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_2418; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_True: {
          heff_drop(v_key_241);
          return v_acc_240;
        }
        case TAG_False: {
          V v_t_2420 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
          return heff_rec(2, shape_safe__total, (V[]){v_t_2420, heff_get(v_acc_240, LBL_total)});
        }
        default: return heff_nomatch(v_x1_2419);
        }
      }
      case TAG_False: {
        heff_drop(v_key_241);
        return v_acc_240;
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2esgFlat(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esimplify_2epartialOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epartialOf_entry, 3, 0};

V g_heff_2esimplify_2epartialOf(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_t_248 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_241));
      V v_t_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      V v_t_2410 = heff_intLt(v_t_248, v_t_249);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2epureIn_clo), 2, (V[]){heff_get(heff_dup(v_s_240), LBL_safe), heff_get(v_s_240, LBL_total)}));
        V v_t_2412 = (g_prelude_2emap(v_t_2411, v_as_241));
        return ({ V a_0 = v_t_2412; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
      }
      case TAG_False: {
        heff_drop(v_s_240);
        heff_drop(v_as_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_EApp: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2epartialOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2epartialOf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esimplify_2epartialHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epartialHead_entry, 3, 0};

V g_heff_2esimplify_2epartialHead(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_all);
    V v_t_246 = ({ V a_0 = heff_dup(v_g_244); V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    return ({ V a_0 = v_s_240; V a_1 = v_as_241; V a_2 = v_t_246; V r_ = (g_heff_2esimplify_2epartialOf(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  case TAG_ELam: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2epartialHead_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2epartialHead(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esimplify_2eisPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eisPure_entry, 2, 0};

V g_heff_2esimplify_2eisPure(V v_e_240, V v_s_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get(heff_dup(v_s_241), LBL_safe); V b_1 = heff_get(heff_dup(v_s_241), LBL_total); V a_2 = v_e_240; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2432;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    v_t_2432 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      V v_f_247 = heff_field(v_e_240, 0);
      V v_as_248 = heff_field(v_e_240, 1);
      v_t_2432 = (g_heff_2esimplify_2epartialHead(heff_dup(v_s_241), heff_dup(v_as_248), v_f_247));
      break;
    }
    case TAG_ELet: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2432, v_s_241});
}
V g_heff_2esimplify_2eisPure_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eisPure(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2eintOp_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2eintOp_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2eintOp_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2eintOp_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2eintOp_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2eintOp_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2esimplify_2eintOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eintOp_entry, 3, 0};

V g_heff_2esimplify_2eintOp(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_p_240);
    V v_t_244 = heff_tag(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return heff_tag(TAG_Just, 1, (V[]){v_t_244});
  }
  case TAG_False: {
    V v_t_245 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_p_240);
      V v_t_246 = heff_tag(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return heff_tag(TAG_Just, 1, (V[]){v_t_246});
    }
    case TAG_False: {
      V v_t_247 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str2));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_p_240);
        V v_t_248 = heff_tag(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return heff_tag(TAG_Just, 1, (V[]){v_t_248});
      }
      case TAG_False: {
        V v_t_249 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str3));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          heff_drop(v_p_240);
          V v_t_2410 = heff_intEq(v_a_241, v_b_242);
          V v_t_2411;
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            v_t_2411 = ((V)&g_heff_2esimplify_2eintOp_str4);
            break;
          }
          case TAG_False: {
            v_t_2411 = ((V)&g_heff_2esimplify_2eintOp_str5);
            break;
          }
          default: heff_nomatch(v_t_2410);
          }
          V v_t_2412 = heff_tag(TAG_ETag, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2412});
        }
        case TAG_False: {
          V v_t_2413 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str6));
          switch (heff_tag_of(v_t_2413)) {
          case TAG_True: {
            heff_drop(v_p_240);
            V v_t_2414 = heff_intLt(v_a_241, v_b_242);
            V v_t_2415;
            switch (heff_tag_of(v_t_2414)) {
            case TAG_True: {
              v_t_2415 = ((V)&g_heff_2esimplify_2eintOp_str7);
              break;
            }
            case TAG_False: {
              v_t_2415 = ((V)&g_heff_2esimplify_2eintOp_str8);
              break;
            }
            default: heff_nomatch(v_t_2414);
            }
            V v_t_2416 = heff_tag(TAG_ETag, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
            return heff_tag(TAG_Just, 1, (V[]){v_t_2416});
          }
          case TAG_False: {
            V v_t_2417 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2eintOp_str9));
            switch (heff_tag_of(v_t_2417)) {
            case TAG_True: {
              V v_t_2418 = heff_intLe(v_a_241, v_b_242);
              V v_t_2419;
              switch (heff_tag_of(v_t_2418)) {
              case TAG_True: {
                v_t_2419 = ((V)&g_heff_2esimplify_2eintOp_str10);
                break;
              }
              case TAG_False: {
                v_t_2419 = ((V)&g_heff_2esimplify_2eintOp_str11);
                break;
              }
              default: heff_nomatch(v_t_2418);
              }
              V v_t_2420 = heff_tag(TAG_ETag, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
              return heff_tag(TAG_Just, 1, (V[]){v_t_2420});
            }
            case TAG_False: {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2417);
            }
          }
          default: return heff_nomatch(v_t_2413);
          }
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esimplify_2eintOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eintOp(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2esimplify_2eunOp_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2esimplify_2eunOp_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
Clo g_heff_2esimplify_2eunOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eunOp_entry, 2, 0};

V g_heff_2esimplify_2eunOp(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2423 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2424 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2eunOp_str0));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      V v_t_2425 = heff_tag_at(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2423)});
      return heff_tag(TAG_Just, 1, (V[]){v_t_2425});
    }
    case TAG_False: {
      heff_drop(v_a_2423);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2427 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2428 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2eunOp_str1));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_True: {
      V v_t_2429 = heff_tag_at(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2427)});
      return heff_tag(TAG_Just, 1, (V[]){v_t_2429});
    }
    case TAG_False: {
      heff_drop(v_a_2427);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eunOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eunOp(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2esimplify_2ebinOp_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2ebinOp_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2ebinOp_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2ebinOp_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2424 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      V v_b_2446 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2esimplify_2eintOp(v_p_240, v_a_2424, v_b_2446);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2455 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      V v_b_2479 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24EStr = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      V v_t_2480 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2ebinOp_str0));
      switch (heff_tag_of(v_t_2480)) {
      case TAG_True: {
        heff_drop(v_p_240);
        V v_t_2481 = heff_tag_at(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2455, v_b_2479)});
        return heff_tag_at(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2481});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x3_242_24EStr, 1);
        V v_t_2482 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2ebinOp_str1));
        switch (heff_tag_of(v_t_2482)) {
        case TAG_True: {
          V v_t_2483 = heff_strEq(v_a_2455, v_b_2479);
          V v_t_2484;
          switch (heff_tag_of(v_t_2483)) {
          case TAG_True: {
            v_t_2484 = ((V)&g_heff_2esimplify_2ebinOp_str2);
            break;
          }
          case TAG_False: {
            v_t_2484 = ((V)&g_heff_2esimplify_2ebinOp_str3);
            break;
          }
          default: heff_nomatch(v_t_2483);
          }
          V v_t_2485 = heff_tag(TAG_ETag, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x2_241_24EStr, TAG_Just, 1, (V[]){v_t_2485});
        }
        case TAG_False: {
          heff_drop(v_a_2455);
          heff_drop_cell(v_ru_24x2_241_24EStr, 1);
          heff_drop(v_b_2479);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2482);
        }
      }
      default: return heff_nomatch(v_t_2480);
      }
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2455);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ebinOp(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2eprimAppN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eprimAppN_entry, 3, 0};

V g_heff_2esimplify_2eprimAppN(V v_p_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_241));
    V v_t_245 = heff_intEq(v_t_244, heff_dup(v_n_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_n_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      V v_x2_2412;
      switch (heff_tag_of(v_as_241)) {
      case TAG_Nil: {
        v_x2_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_dup(heff_field(v_as_241, 0));
        V v_x22_247 = heff_dup(heff_field(v_as_241, 1));
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          v_x2_2412 = (g_heff_2esimplify_2eunOp(heff_dup(v_p_240), v_a_246));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_x22_247, 0);
          V v_x222_249 = heff_field(v_x22_247, 1);
          heff_take_n(v_x22_247, 3ULL, 2);
          switch (heff_tag_of(v_x222_249)) {
          case TAG_Nil: {
            v_x2_2412 = (g_heff_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_246, v_b_248));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x222_249, 0ULL, 2);
            heff_drop(v_a_246);
            heff_drop(v_b_248);
            v_x2_2412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x222_249);
          }
          break;
        }
        default: heff_nomatch(v_x22_247);
        }
        break;
      }
      default: heff_nomatch(v_as_241);
      }
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        return heff_tag(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_241});
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop(v_as_241);
        return v_x_2413;
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    case TAG_False: {
      V v_a_2414 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_241));
      V v_t_2415 = heff_intLt(heff_dup(v_n_243), v_a_2414);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        V v_as_2416 = (g_heff_2esimplify_2etakeL(heff_dup(v_n_243), heff_dup(v_as_241)));
        V v_x2_2423;
        switch (heff_tag_of(v_as_2416)) {
        case TAG_Nil: {
          v_x2_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_a_2417 = heff_dup(heff_field(v_as_2416, 0));
          V v_x22_2418 = heff_dup(heff_field(v_as_2416, 1));
          switch (heff_tag_of(v_x22_2418)) {
          case TAG_Nil: {
            v_x2_2423 = (g_heff_2esimplify_2eunOp(heff_dup(v_p_240), v_a_2417));
            break;
          }
          case TAG_Cons: {
            V v_b_2419 = heff_field(v_x22_2418, 0);
            V v_x222_2420 = heff_field(v_x22_2418, 1);
            heff_take_n(v_x22_2418, 3ULL, 2);
            switch (heff_tag_of(v_x222_2420)) {
            case TAG_Nil: {
              v_x2_2423 = (g_heff_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_2417, v_b_2419));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2420, 0ULL, 2);
              heff_drop(v_a_2417);
              heff_drop(v_b_2419);
              v_x2_2423 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x222_2420);
            }
            break;
          }
          default: heff_nomatch(v_x22_2418);
          }
          break;
        }
        default: heff_nomatch(v_as_2416);
        }
        V v_t_2425;
        switch (heff_tag_of(v_x2_2423)) {
        case TAG_Nothing: {
          v_t_2425 = heff_tag(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_2416});
          break;
        }
        case TAG_Just: {
          V v_x_2424 = heff_field(v_x2_2423, 0);
          heff_take_n(v_x2_2423, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop(v_as_2416);
          v_t_2425 = v_x_2424;
          break;
        }
        default: heff_nomatch(v_x2_2423);
        }
        return heff_tag(TAG_EApp, 2, (V[]){v_t_2425, (g_heff_2esimplify_2edropL(v_n_243, v_as_241))});
      }
      case TAG_False: {
        heff_drop(v_n_243);
        return heff_tag(TAG_EApp, 2, (V[]){heff_tag_at(v_ru_24x3_242_24Just, TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2eprimAppN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eprimAppN(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2esimplify_2emkApp(V v_f_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EGlobal: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ELam: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      heff_take_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_heff_2esimplify_2eappendL(v_bs_249, v_as_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_as_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ERecord: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EProj: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ETag: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EMatch: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EPrim: {
      V v_p_2421 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 1);
      V v_t_2422 = ({ V a_0 = heff_dup(v_p_2421); V b_1 = heff_dup(g_heff_2eprims_2eallPrims_get()); V r_ = (g_heff_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
      return (g_heff_2esimplify_2eprimAppN(v_p_2421, v_as_241, v_t_2422));
    }
    case TAG_EPrimCall: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ECall: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EInt: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EStr: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFixed: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat32: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EAbandon: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFix: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2emkApp(a[0], a[1]);
}
V g_heff_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam3(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam5(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam4(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam6(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam8(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam7(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam9(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam10(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam11(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam12(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam15(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam14(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam13(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam16(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam17(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam18(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam19(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam20(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam21(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam22(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam23(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam24(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam25(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam26(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam27(V self, V *args);
Clo g_heff_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_244 = heff_strEq(heff_dup(v_y_243), v_x_240);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_y_243);
      return heff_clo(g_heff_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_a_241});
    }
    case TAG_False: {
      heff_drop(v_a_241);
      return heff_clo(g_heff_2esimplify_2esubstCopies_lam1, 1, 1, (V[]){v_y_243});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam2, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_2413 = heff_field(v_e_242, 0);
    V v_b_2414 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2415 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2414));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam3, 1, 2, (V[]){v_m_2415, v_xs_2413});
  }
  case TAG_EApp: {
    V v_f_2420 = heff_field(v_e_242, 0);
    V v_as_2421 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2422 = (g_heff_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_f_2420));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam4, 1, 4, (V[]){v_m_2422, v_x_240, v_a_241, v_as_2421});
  }
  case TAG_ELet: {
    V v_y_2433 = heff_field(v_e_242, 0);
    V v_e2_2434 = heff_field(v_e_242, 1);
    V v_b_2435 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2436 = (g_heff_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_e2_2434));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam6, 1, 5, (V[]){v_m_2436, v_x_240, v_a_241, v_b_2435, v_y_2433});
  }
  case TAG_ERecord: {
    V v_fs_2445 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_m_2454 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam7, 1, 2, (V[]){v_x_240, v_a_241}), v_fs_2445));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam9, 1, 1, (V[]){v_m_2454});
  }
  case TAG_EProj: {
    V v_e2_2459 = heff_field(v_e_242, 0);
    V v_l_2460 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2461 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e2_2459));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam10, 1, 2, (V[]){v_m_2461, v_l_2460});
  }
  case TAG_ETag: {
    V v_t_2466 = heff_field(v_e_242, 0);
    V v_as_2467 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2469 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam11, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2467));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam12, 1, 2, (V[]){v_m_2469, v_t_2466});
  }
  case TAG_EMatch: {
    V v_s_2474 = heff_field(v_e_242, 0);
    V v_arms_2475 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2476 = (g_heff_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_s_2474));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam13, 1, 4, (V[]){v_m_2476, v_x_240, v_a_241, v_arms_2475});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam16, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_2496 = heff_field(v_e_242, 0);
    V v_as_2497 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2499 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam17, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2497));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam18, 1, 2, (V[]){v_m_2499, v_p_2496});
  }
  case TAG_ECall: {
    V v_g_24104 = heff_field(v_e_242, 0);
    V v_as_24105 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24107 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam19, 1, 2, (V[]){v_x_240, v_a_241}), v_as_24105));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam20, 1, 2, (V[]){v_m_24107, v_g_24104});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam21, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam22, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam23, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam24, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam25, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam26, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam27, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2esubstCopies(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = (g_heff_2eir_2efreshGo_24s1749472566x1664180022(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_245), LBL_supply), v_a_241));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_e_27_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n_248, heff_get(heff_dup(v_s_245), LBL_fuel), heff_get(heff_dup(v_s_245), LBL_defs), heff_get(heff_dup(v_s_245), LBL_safe), heff_get(heff_dup(v_s_245), LBL_total), heff_get(heff_dup(v_s_245), LBL_plain), heff_get(v_s_245, LBL_sp)});
    return heff_tag_at(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_247, v_t_249});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_y_243}), v_s_2410});
}
V g_heff_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_2412});
}
V g_heff_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_xs_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_apply(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_2413, v_x_2418}), v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2esimplify_2esubstCopies_lam5(V self, V *args) {
  V v_q_2427 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2427));
}
V g_heff_2esimplify_2esubstCopies_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_as_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2424 = heff_tr(heff_apply(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_m_2428 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam5, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2421));
    V v_x2_2429 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2426}));
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_s_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      V v_x_2432 = (g_heff_2esimplify_2emkApp(v_x_2425, v_x_2430));
      return heff_tag_at(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_x_2432, v_s_2431});
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2esimplify_2esubstCopies_lam6(V self, V *args) {
  V v_s_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_2435 = heff_env(self)[3];
  V v_y_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2438 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_s_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_s_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    V v_m_2441 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2435));
    V v_x2_2442 = heff_tr(heff_apply(v_m_2441, 1, (V[]){v_s_2440}));
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_MkPair: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      V v_s_2444 = heff_field(v_x2_2442, 1);
      heff_take_n(v_x2_2442, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_y_2433, v_x_2439, v_x_2443}), v_s_2444});
    }
    default: return heff_nomatch(v_x2_2442);
    }
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2esimplify_2esubstCopies_lam8(V self, V *args) {
  V v_s_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_l_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_apply(v_m_2449, 1, (V[]){v_s_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_s_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_2447, v_x_2452}), v_s_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2esimplify_2esubstCopies_lam7(V self, V *args) {
  V v_p_2446 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2446)) {
  case TAG_MkPair: {
    V v_l_2447 = heff_field(v_p_2446, 0);
    V v_e_2448 = heff_field(v_p_2446, 1);
    heff_take_n(v_p_2446, 3ULL, 2);
    V v_m_2449 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e_2448));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam8, 1, 2, (V[]){v_m_2449, v_l_2447});
  }
  default: return heff_nomatch(v_p_2446);
  }
}
V g_heff_2esimplify_2esubstCopies_lam9(V self, V *args) {
  V v_s_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_s_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_s_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_x_2457}), v_s_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2esimplify_2esubstCopies_lam10(V self, V *args) {
  V v_s_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_l_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_apply(v_m_2461, 1, (V[]){v_s_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_s_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x_2464, v_l_2460}), v_s_2465});
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2esimplify_2esubstCopies_lam11(V self, V *args) {
  V v_q_2468 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2468));
}
V g_heff_2esimplify_2esubstCopies_lam12(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_t_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2471 = heff_tr(heff_apply(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2466, v_x_2472}), v_s_2473});
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2esimplify_2esubstCopies_lam15(V self, V *args) {
  V v_s_2486 = args[0];
  V v_m_2485 = heff_env(self)[0];
  V v_t_2482 = heff_env(self)[1];
  V v_vs_2483 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2487 = heff_tr(heff_apply(v_m_2485, 1, (V[]){v_s_2486}));
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_x2_2487, 0);
    V v_s_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_2482, v_vs_2483, v_x_2488}), v_s_2489});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
V g_heff_2esimplify_2esubstCopies_lam14(V self, V *args) {
  V v_a_2481 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2481)) {
  case TAG_MkArm: {
    V v_t_2482 = heff_field(v_a_2481, 0);
    V v_vs_2483 = heff_field(v_a_2481, 1);
    V v_b_2484 = heff_field(v_a_2481, 2);
    heff_take_n(v_a_2481, 7ULL, 3);
    V v_m_2485 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2484));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam15, 1, 3, (V[]){v_m_2485, v_t_2482, v_vs_2483});
  }
  default: return heff_nomatch(v_a_2481);
  }
}
V g_heff_2esimplify_2esubstCopies_lam13(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_arms_2475 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2478 = heff_tr(heff_apply(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_m_2490 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam14, 1, 2, (V[]){v_x_240, v_a_241}), v_arms_2475));
    V v_x2_2491 = heff_tr(heff_apply(v_m_2490, 1, (V[]){v_s_2480}));
    switch (heff_tag_of(v_x2_2491)) {
    case TAG_MkPair: {
      V v_x_2492 = heff_field(v_x2_2491, 0);
      V v_s_2493 = heff_field(v_x2_2491, 1);
      heff_take_n(v_x2_2491, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x_2479, v_x_2492}), v_s_2493});
    }
    default: return heff_nomatch(v_x2_2491);
    }
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2esimplify_2esubstCopies_lam16(V self, V *args) {
  V v_s_2495 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_2495});
}
V g_heff_2esimplify_2esubstCopies_lam17(V self, V *args) {
  V v_q_2498 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2498));
}
V g_heff_2esimplify_2esubstCopies_lam18(V self, V *args) {
  V v_s_24100 = args[0];
  V v_m_2499 = heff_env(self)[0];
  V v_p_2496 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24101 = heff_tr(heff_apply(v_m_2499, 1, (V[]){v_s_24100}));
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkPair: {
    V v_x_24102 = heff_field(v_x2_24101, 0);
    V v_s_24103 = heff_field(v_x2_24101, 1);
    V v_ru_24x2_24101_24MkPair = heff_take_reuse_n(v_x2_24101, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24101_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2496, v_x_24102}), v_s_24103});
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2esimplify_2esubstCopies_lam19(V self, V *args) {
  V v_q_24106 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_24106));
}
V g_heff_2esimplify_2esubstCopies_lam20(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_g_24104 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24109 = heff_tr(heff_apply(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24109_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_g_24104, v_x_24110}), v_s_24111});
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2esimplify_2esubstCopies_lam21(V self, V *args) {
  V v_s_24113 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24113});
}
V g_heff_2esimplify_2esubstCopies_lam22(V self, V *args) {
  V v_s_24115 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24115});
}
V g_heff_2esimplify_2esubstCopies_lam23(V self, V *args) {
  V v_s_24117 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24117});
}
V g_heff_2esimplify_2esubstCopies_lam24(V self, V *args) {
  V v_s_24120 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24120});
}
V g_heff_2esimplify_2esubstCopies_lam25(V self, V *args) {
  V v_s_24122 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24122});
}
V g_heff_2esimplify_2esubstCopies_lam26(V self, V *args) {
  V v_s_24123 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24123});
}
V g_heff_2esimplify_2esubstCopies_lam27(V self, V *args) {
  V v_s_24126 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24126});
}
Clo g_heff_2esimplify_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2elam_entry, 2, 0};

V g_heff_2esimplify_2elam(V v_xs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_246 = (g_heff_2esimplify_2eappendL(v_xs_240, v_ys_244));
    return heff_tag_at(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_246, v_b_245});
  }
  case TAG_EApp: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELet: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ERecord: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EProj: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ETag: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EMatch: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrim: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ECall: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EInt: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EStr: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFixed: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFix: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2elam(a[0], a[1]);
}
V g_heff_2esimplify_2eletPure_lam0(V self, V *args);
V g_heff_2esimplify_2eletPure_lam1(V self, V *args);
V g_heff_2esimplify_2eletPure_lam2(V self, V *args);
Clo g_heff_2esimplify_2eletPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eletPure_entry, 5, 0};

V g_heff_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  V v_t_245 = heff_intEq(heff_dup(v_o_244), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_x_241);
    heff_drop(v_a_242);
    heff_drop(v_o_244);
    return heff_tail(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243});
  }
  case TAG_False: {
    V v_t_2435;
    switch (heff_tag_of(v_a_242)) {
    case TAG_EVar: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_t_2436;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_o_244);
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2436 = heff_intEq(v_o_244, MK_INT(1LL));
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    switch (heff_tag_of(v_t_2436)) {
    case TAG_True: {
      V v_m_2437 = (g_map_2einsert_24s1341440536x470972936(v_x_241, v_a_242, heff_dup(g_map_2eempty_get())));
      V v_t_2438 = (g_map_2esize(v_m_2437));
      V v_t_2439 = heff_intEq(v_t_2438, MK_INT(0LL));
      V v_t_2440;
      switch (heff_tag_of(v_t_2439)) {
      case TAG_True: {
        heff_drop(v_m_2437);
        v_t_2440 = v_b_243;
        break;
      }
      case TAG_False: {
        v_t_2440 = ({ V a_0 = v_m_2437; V a_1 = v_b_243; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2437); r_; });
        break;
      }
      default: heff_nomatch(v_t_2439);
      }
      return heff_tail(heff_get(v_r_240, LBL_simp), 1, (V[]){v_t_2440});
    }
    case TAG_False: {
      V v_t_2441 = (g_heff_2eir_2eisValue(v_a_242));
      switch (heff_tag_of(v_t_2441)) {
      case TAG_True: {
        V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_242), NTAG(TAG_Nil)});
        V v_a_2443 = (g_heff_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2442));
        V v_x1_2444 = heff_intLt(MK_INT(12LL), v_a_2443);
        switch (heff_tag_of(v_x1_2444)) {
        case TAG_True: {
          V v_m_2445 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243}));
          return heff_clo(g_heff_2esimplify_2eletPure_lam0, 1, 3, (V[]){v_m_2445, v_x_241, v_a_242});
        }
        case TAG_False: {
          V v_m_2450 = (g_heff_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
          return heff_clo(g_heff_2esimplify_2eletPure_lam1, 1, 2, (V[]){v_m_2450, v_r_240});
        }
        default: return heff_nomatch(v_x1_2444);
        }
      }
      case TAG_False: {
        V v_m_2455 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243}));
        return heff_clo(g_heff_2esimplify_2eletPure_lam2, 1, 3, (V[]){v_m_2455, v_x_241, v_a_242});
      }
      default: return heff_nomatch(v_t_2441);
      }
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esimplify_2eletPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eletPure(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esimplify_2eletPure_lam0(V self, V *args) {
  V v_s_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2447 = heff_tr(heff_apply(v_m_2445, 1, (V[]){v_s_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_s_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2448}), v_s_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2esimplify_2eletPure_lam1(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2452 = heff_tr(heff_apply(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    heff_take_n(v_x2_2452, 3ULL, 2);
    return heff_tail(heff_get(v_r_240, LBL_simp), 2, (V[]){v_x_2453, v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2esimplify_2eletPure_lam2(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2458}), v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
Clo g_heff_2esimplify_2eletIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eletIn_entry, 5, 0};

V g_heff_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244) {
top: ;
  V v_x2_245 = (g_heff_2esimplify_2eisPure(v_a_242, v_s_244));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_246)) {
    case TAG_True: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_m_249 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243}));
      V v_x2_2410 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_s_247}));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_s_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2411}), v_s_2412});
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    case TAG_False: {
      V v_t_2413 = heff_tag_at(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2414 = (g_heff_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_2413));
      V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2416 = (g_heff_2eir_2elamW(heff_dup(v_x_241), v_t_2415));
      V v_t_2417 = heff_get(heff_rec(2, shape_count__underLam, (V[]){v_t_2414, v_t_2416}), LBL_count);
      V v_t_2418 = heff_tr(g_heff_2esimplify_2eletPure(v_r_240, v_x_241, v_a_242, v_b_243, v_t_2417));
      return heff_tail(v_t_2418, 1, (V[]){v_s_247});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2esimplify_2eletIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eletIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esimplify_2etakesMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etakesMore_entry, 3, 0};

V g_heff_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242) {
top: ;
  V v_it_243 = ({ V a_0 = v_g_241; V b_1 = heff_get(v_s_240, LBL_defs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_n_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    heff_take_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_EVar: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 2);
      V v_a_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_247; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      return heff_intLt(v_n_242, v_a_249);
    }
    case TAG_EApp: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_it1_244, 0ULL, 3);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2esimplify_2etakesMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etakesMore(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        V v_t_249 = heff_strEq(heff_dup(v_x_244), heff_dup(v_y_248));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_False: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eparamsAre(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2eetaHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eetaHead_entry, 3, 0};

V g_heff_2esimplify_2eetaHead(V v_kinds_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_x1_244 = (g_heff_2esimplify_2eelemStr(heff_dup(v_y_243), v_xs_241));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x3_242, 0);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_245), v_kinds_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2eetaHead_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eetaHead(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2esimplify_2eeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eeta_entry, 2, 0};

V g_heff_2esimplify_2eeta(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_245 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_245)) {
    case TAG_EVar: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ELam: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_e2_245, 0);
      V v_as_2411 = heff_field(v_e2_245, 1);
      V v_ru_24e2_245_24EApp = heff_take_reuse_n(v_e2_245, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_t_2412 = (g_heff_2esimplify_2eparamsAre(v_xs_244, v_as_2411));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        V v_t_2413 = (g_heff_2esimplify_2eetaHead(v_kinds_240, v_xs_244, v_f_2410));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_xs_244);
          heff_drop(v_as_2411);
          heff_drop_cell(v_ru_24e2_245_24EApp, 2);
          return v_f_2410;
        }
        case TAG_False: {
          return heff_tag_at(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_ELet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    default: return heff_nomatch(v_e2_245);
    }
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2eeta_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eeta(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2esimplify_2esimpF_lam0(V self, V *args);
V g_heff_2esimplify_2esimpF_lam1(V self, V *args);
V g_heff_2esimplify_2esimpF_lam2(V self, V *args);
V g_heff_2esimplify_2esimpF_lam4(V self, V *args);
V g_heff_2esimplify_2esimpF_lam3(V self, V *args);
V g_heff_2esimplify_2esimpF_lam6(V self, V *args);
V g_heff_2esimplify_2esimpF_lam5(V self, V *args);
V g_heff_2esimplify_2esimpF_lam8(V self, V *args);
V g_heff_2esimplify_2esimpF_lam7(V self, V *args);
V g_heff_2esimplify_2esimpF_lam10(V self, V *args);
V g_heff_2esimplify_2esimpF_lam9(V self, V *args);
V g_heff_2esimplify_2esimpF_lam12(V self, V *args);
V g_heff_2esimplify_2esimpF_lam11(V self, V *args);
V g_heff_2esimplify_2esimpF_lam14(V self, V *args);
V g_heff_2esimplify_2esimpF_lam13(V self, V *args);
V g_heff_2esimplify_2esimpF_lam16(V self, V *args);
V g_heff_2esimplify_2esimpF_lam15(V self, V *args);
V g_heff_2esimplify_2esimpF_lam18(V self, V *args);
V g_heff_2esimplify_2esimpF_lam17(V self, V *args);
V g_heff_2esimplify_2esimpF_lam20(V self, V *args);
V g_heff_2esimplify_2esimpF_lam19(V self, V *args);
V g_heff_2esimplify_2esimpF_lam22(V self, V *args);
V g_heff_2esimplify_2esimpF_lam21(V self, V *args);
V g_heff_2esimplify_2esimpF_lam24(V self, V *args);
V g_heff_2esimplify_2esimpF_lam23(V self, V *args);
V g_heff_2esimplify_2esimpF_lam26(V self, V *args);
V g_heff_2esimplify_2esimpF_lam25(V self, V *args);
V g_heff_2esimplify_2esimpF_lam28(V self, V *args);
V g_heff_2esimplify_2esimpF_lam27(V self, V *args);
V g_heff_2esimplify_2esimpF_lam30(V self, V *args);
V g_heff_2esimplify_2esimpF_lam29(V self, V *args);
V g_heff_2esimplify_2esimpF_lam32(V self, V *args);
V g_heff_2esimplify_2esimpF_lam31(V self, V *args);
V g_heff_2esimplify_2esimpF_lam34(V self, V *args);
V g_heff_2esimplify_2esimpF_lam33(V self, V *args);
V g_heff_2esimplify_2esimpF_lam36(V self, V *args);
V g_heff_2esimplify_2esimpF_lam35(V self, V *args);
V g_heff_2esimplify_2esimpF_lam38(V self, V *args);
V g_heff_2esimplify_2esimpF_lam37(V self, V *args);
V g_heff_2esimplify_2esimpF_lam40(V self, V *args);
V g_heff_2esimplify_2esimpF_lam39(V self, V *args);
V g_heff_2esimplify_2esimpF_lam42(V self, V *args);
V g_heff_2esimplify_2esimpF_lam41(V self, V *args);
V g_heff_2esimplify_2esimpF_lam44(V self, V *args);
V g_heff_2esimplify_2esimpF_lam43(V self, V *args);
V g_heff_2esimplify_2esimpF_lam46(V self, V *args);
V g_heff_2esimplify_2esimpF_lam45(V self, V *args);
V g_heff_2esimplify_2esimpF_lam48(V self, V *args);
V g_heff_2esimplify_2esimpF_lam47(V self, V *args);
V g_heff_2esimplify_2esimpF_lam50(V self, V *args);
V g_heff_2esimplify_2esimpF_lam49(V self, V *args);
V g_heff_2esimplify_2esimpF_lam52(V self, V *args);
V g_heff_2esimplify_2esimpF_lam51(V self, V *args);
V g_heff_2esimplify_2esimpF_lam54(V self, V *args);
V g_heff_2esimplify_2esimpF_lam53(V self, V *args);
V g_heff_2esimplify_2esimpF_lam56(V self, V *args);
V g_heff_2esimplify_2esimpF_lam55(V self, V *args);
V g_heff_2esimplify_2esimpF_lam58(V self, V *args);
V g_heff_2esimplify_2esimpF_lam57(V self, V *args);
V g_heff_2esimplify_2esimpF_lam60(V self, V *args);
V g_heff_2esimplify_2esimpF_lam59(V self, V *args);
V g_heff_2esimplify_2esimpF_lam62(V self, V *args);
V g_heff_2esimplify_2esimpF_lam61(V self, V *args);
V g_heff_2esimplify_2esimpF_lam64(V self, V *args);
V g_heff_2esimplify_2esimpF_lam63(V self, V *args);
V g_heff_2esimplify_2esimpF_lam66(V self, V *args);
V g_heff_2esimplify_2esimpF_lam65(V self, V *args);
V g_heff_2esimplify_2esimpF_lam68(V self, V *args);
V g_heff_2esimplify_2esimpF_lam67(V self, V *args);
V g_heff_2esimplify_2esimpF_lam70(V self, V *args);
V g_heff_2esimplify_2esimpF_lam69(V self, V *args);
V g_heff_2esimplify_2esimpF_lam72(V self, V *args);
V g_heff_2esimplify_2esimpF_lam71(V self, V *args);
V g_heff_2esimplify_2esimpF_lam74(V self, V *args);
V g_heff_2esimplify_2esimpF_lam73(V self, V *args);
V g_heff_2esimplify_2esimpF_lam76(V self, V *args);
V g_heff_2esimplify_2esimpF_lam75(V self, V *args);
V g_heff_2esimplify_2esimpF_lam77(V self, V *args);
V g_heff_2esimplify_2esimpF_lam79(V self, V *args);
V g_heff_2esimplify_2esimpF_lam78(V self, V *args);
V g_heff_2esimplify_2esimpF_lam80(V self, V *args);
V g_heff_2esimplify_2esimpF_lam81(V self, V *args);
V g_heff_2esimplify_2esimpF_lam82(V self, V *args);
V g_heff_2esimplify_2esimpF_lam83(V self, V *args);
V g_heff_2esimplify_2esimpF_lam86(V self, V *args);
V g_heff_2esimplify_2esimpF_lam85(V self, V *args);
V g_heff_2esimplify_2esimpF_lam84(V self, V *args);
V g_heff_2esimplify_2esimpF_lam87(V self, V *args);
V g_heff_2esimplify_2esimpF_lam88(V self, V *args);
V g_heff_2esimplify_2esimpF_lam89(V self, V *args);
V g_heff_2esimplify_2esimpF_lam90(V self, V *args);
V g_heff_2esimplify_2esimpF_lam91(V self, V *args);
V g_heff_2esimplify_2esimpF_lam92(V self, V *args);
V g_heff_2esimplify_2esimpF_lam93(V self, V *args);
V g_heff_2esimplify_2esimpF_lam94(V self, V *args);
V g_heff_2esimplify_2esimpF_lam95(V self, V *args);
V g_heff_2esimplify_2esimpF_lam96(V self, V *args);
V g_heff_2esimplify_2esimpF_lam97(V self, V *args);
Clo g_heff_2esimplify_2esimpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esimpF_entry, 2, 0};

V g_heff_2esimplify_2esimpF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_247}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_it1_2416 = heff_field(v_e_241, 0);
    V v_as_2417 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_it1_2416)) {
    case TAG_EVar: {
      V v_m_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam3, 1, 3, (V[]){v_m_2419, v_r_240, v_as_2417});
    }
    case TAG_EGlobal: {
      V v_m_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam5, 1, 3, (V[]){v_m_2430, v_r_240, v_as_2417});
    }
    case TAG_ELam: {
      V v_m_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam7, 1, 3, (V[]){v_m_2442, v_r_240, v_as_2417});
    }
    case TAG_EApp: {
      V v_it11_2452 = heff_dup(heff_field(v_it1_2416, 0));
      V v_bs_2453 = heff_dup(heff_field(v_it1_2416, 1));
      switch (heff_tag_of(v_it11_2452)) {
      case TAG_EVar: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_2455 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam9, 1, 3, (V[]){v_m_2455, v_r_240, v_as_2417});
      }
      case TAG_EGlobal: {
        V v_g_2465 = heff_field(v_it11_2452, 0);
        heff_take_n(v_it11_2452, 1ULL, 1);
        heff_drop_tag(v_it1_2416, 2);
        return heff_clo(g_heff_2esimplify_2esimpF_lam11, 1, 4, (V[]){v_bs_2453, v_g_2465, v_as_2417, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam13, 1, 3, (V[]){v_m_2482, v_r_240, v_as_2417});
      }
      case TAG_EApp: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2494 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam15, 1, 3, (V[]){v_m_2494, v_r_240, v_as_2417});
      }
      case TAG_ELet: {
        heff_take_n(v_it11_2452, 0ULL, 3);
        heff_drop(v_bs_2453);
        V v_m_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam17, 1, 3, (V[]){v_m_24107, v_r_240, v_as_2417});
      }
      case TAG_ERecord: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24118 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam19, 1, 3, (V[]){v_m_24118, v_r_240, v_as_2417});
      }
      case TAG_EProj: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24130 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam21, 1, 3, (V[]){v_m_24130, v_r_240, v_as_2417});
      }
      case TAG_ETag: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24142 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam23, 1, 3, (V[]){v_m_24142, v_r_240, v_as_2417});
      }
      case TAG_EMatch: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24154 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam25, 1, 3, (V[]){v_m_24154, v_r_240, v_as_2417});
      }
      case TAG_EPrim: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24165 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam27, 1, 3, (V[]){v_m_24165, v_r_240, v_as_2417});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24177 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam29, 1, 3, (V[]){v_m_24177, v_r_240, v_as_2417});
      }
      case TAG_ECall: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24189 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam31, 1, 3, (V[]){v_m_24189, v_r_240, v_as_2417});
      }
      case TAG_EInt: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24200 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam33, 1, 3, (V[]){v_m_24200, v_r_240, v_as_2417});
      }
      case TAG_EFloat: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24211 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam35, 1, 3, (V[]){v_m_24211, v_r_240, v_as_2417});
      }
      case TAG_EStr: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24222 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam37, 1, 3, (V[]){v_m_24222, v_r_240, v_as_2417});
      }
      case TAG_EFixed: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24234 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam39, 1, 3, (V[]){v_m_24234, v_r_240, v_as_2417});
      }
      case TAG_EFloat32: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24245 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam41, 1, 3, (V[]){v_m_24245, v_r_240, v_as_2417});
      }
      case TAG_EAbandon: {
        heff_drop(v_bs_2453);
        V v_m_24255 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam43, 1, 3, (V[]){v_m_24255, v_r_240, v_as_2417});
      }
      case TAG_EFix: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24267 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam45, 1, 3, (V[]){v_m_24267, v_r_240, v_as_2417});
      }
      default: return heff_nomatch(v_it11_2452);
      }
    }
    case TAG_ELet: {
      V v_m_24280 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam47, 1, 3, (V[]){v_m_24280, v_r_240, v_as_2417});
    }
    case TAG_ERecord: {
      V v_m_24291 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam49, 1, 3, (V[]){v_m_24291, v_r_240, v_as_2417});
    }
    case TAG_EProj: {
      V v_m_24303 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam51, 1, 3, (V[]){v_m_24303, v_r_240, v_as_2417});
    }
    case TAG_ETag: {
      V v_m_24315 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam53, 1, 3, (V[]){v_m_24315, v_r_240, v_as_2417});
    }
    case TAG_EMatch: {
      V v_m_24327 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam55, 1, 3, (V[]){v_m_24327, v_r_240, v_as_2417});
    }
    case TAG_EPrim: {
      V v_m_24338 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam57, 1, 3, (V[]){v_m_24338, v_r_240, v_as_2417});
    }
    case TAG_EPrimCall: {
      V v_m_24350 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam59, 1, 3, (V[]){v_m_24350, v_r_240, v_as_2417});
    }
    case TAG_ECall: {
      V v_m_24362 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam61, 1, 3, (V[]){v_m_24362, v_r_240, v_as_2417});
    }
    case TAG_EInt: {
      V v_m_24373 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam63, 1, 3, (V[]){v_m_24373, v_r_240, v_as_2417});
    }
    case TAG_EFloat: {
      V v_m_24384 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam65, 1, 3, (V[]){v_m_24384, v_r_240, v_as_2417});
    }
    case TAG_EStr: {
      V v_m_24395 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam67, 1, 3, (V[]){v_m_24395, v_r_240, v_as_2417});
    }
    case TAG_EFixed: {
      V v_m_24407 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam69, 1, 3, (V[]){v_m_24407, v_r_240, v_as_2417});
    }
    case TAG_EFloat32: {
      V v_m_24418 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam71, 1, 3, (V[]){v_m_24418, v_r_240, v_as_2417});
    }
    case TAG_EAbandon: {
      V v_m_24428 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam73, 1, 3, (V[]){v_m_24428, v_r_240, v_as_2417});
    }
    case TAG_EFix: {
      V v_m_24440 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam75, 1, 3, (V[]){v_m_24440, v_r_240, v_as_2417});
    }
    default: return heff_nomatch(v_it1_2416);
    }
  }
  case TAG_ELet: {
    V v_x_24450 = heff_field(v_e_241, 0);
    V v_a_24451 = heff_field(v_e_241, 1);
    V v_b_24452 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24453 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_a_24451}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam77, 1, 4, (V[]){v_m_24453, v_r_240, v_x_24450, v_b_24452});
  }
  case TAG_ERecord: {
    V v_fs_24458 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_m_24467 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam78, 1, 1, (V[]){v_r_240}), v_fs_24458));
    return heff_clo(g_heff_2esimplify_2esimpF_lam80, 1, 1, (V[]){v_m_24467});
  }
  case TAG_EProj: {
    V v_e2_24472 = heff_field(v_e_241, 0);
    V v_l_24473 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24474 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_e2_24472}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam81, 1, 3, (V[]){v_m_24474, v_r_240, v_l_24473});
  }
  case TAG_ETag: {
    V v_t_24479 = heff_field(v_e_241, 0);
    V v_as_24480 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24482 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam82, 1, 1, (V[]){v_r_240}), v_as_24480));
    return heff_clo(g_heff_2esimplify_2esimpF_lam83, 1, 2, (V[]){v_m_24482, v_t_24479});
  }
  case TAG_EMatch: {
    V v_s_24487 = heff_field(v_e_241, 0);
    V v_arms_24488 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24489 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_s_24487}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam84, 1, 3, (V[]){v_m_24489, v_r_240, v_arms_24488});
  }
  case TAG_EPrim: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam87, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_24509 = heff_field(v_e_241, 0);
    V v_as_24510 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24512 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam88, 1, 1, (V[]){v_r_240}), v_as_24510));
    return heff_clo(g_heff_2esimplify_2esimpF_lam89, 1, 2, (V[]){v_m_24512, v_p_24509});
  }
  case TAG_ECall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam90, 1, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam91, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam92, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam93, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam94, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam95, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam96, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam97, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2esimpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2esimpF(a[0], a[1]);
}
V g_heff_2esimplify_2esimpF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2esimplify_2esimpF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_245});
}
V g_heff_2esimplify_2esimpF_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_apply(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_get(heff_get(heff_dup(v_s_2412), LBL_sp), LBL_kinds);
    V v_t_2414 = (g_heff_2esimplify_2elam(v_xs_246, v_x_2411));
    V v_x_2415 = ({ V a_0 = v_t_2413; V a_1 = v_t_2414; V r_ = (g_heff_2esimplify_2eeta(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_tag_at(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2esimplify_2esimpF_lam4(V self, V *args) {
  V v_a_2424 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2421 = heff_tr(heff_apply(v_m_2419, 1, (V[]){v_s_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_s_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    V v_m_2425 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2426 = heff_tr(heff_apply(v_m_2425, 1, (V[]){v_s_2423}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_s_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2422, v_x_2427, v_s_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2esimplify_2esimpF_lam6(V self, V *args) {
  V v_a_2435 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_apply(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    heff_take_n(v_x2_2432, 3ULL, 2);
    V v_m_2436 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam6, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2437 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2433, v_x_2438, v_s_2439});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2esimplify_2esimpF_lam8(V self, V *args) {
  V v_a_2447 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2444 = heff_tr(heff_apply(v_m_2442, 1, (V[]){v_s_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_s_2446 = heff_field(v_x2_2444, 1);
    heff_take_n(v_x2_2444, 3ULL, 2);
    V v_m_2448 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam8, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2449 = heff_tr(heff_apply(v_m_2448, 1, (V[]){v_s_2446}));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_s_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2445, v_x_2450, v_s_2451});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2esimplify_2esimpF_lam10(V self, V *args) {
  V v_a_2460 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam9(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    V v_m_2461 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2462 = heff_tr(heff_apply(v_m_2461, 1, (V[]){v_s_2459}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_s_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2458, v_x_2463, v_s_2464});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2esimplify_2esimpF_lam12(V self, V *args) {
  V v_a_2475 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam11(V self, V *args) {
  V v_s_2466 = args[0];
  V v_bs_2453 = heff_env(self)[0];
  V v_g_2465 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_bs_2453));
  V v_t_2468 = (g_heff_2esimplify_2etakesMore(heff_dup(v_s_2466), heff_dup(v_g_2465), v_t_2467));
  switch (heff_tag_of(v_t_2468)) {
  case TAG_True: {
    V v_t_2469 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_g_2465}), (g_heff_2esimplify_2eappendL(v_bs_2453, v_as_2417))});
    return heff_tail(heff_get(v_r_240, LBL_simp), 2, (V[]){v_t_2469, v_s_2466});
  }
  case TAG_False: {
    V v_t_2470 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_g_2465}), v_bs_2453});
    V v_m_2471 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_t_2470}));
    V v_x2_2472 = heff_tr(heff_apply(v_m_2471, 1, (V[]){v_s_2466}));
    switch (heff_tag_of(v_x2_2472)) {
    case TAG_MkPair: {
      V v_x_2473 = heff_field(v_x2_2472, 0);
      V v_s_2474 = heff_field(v_x2_2472, 1);
      heff_take_n(v_x2_2472, 3ULL, 2);
      V v_m_2476 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam12, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
      V v_x2_2477 = heff_tr(heff_apply(v_m_2476, 1, (V[]){v_s_2474}));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2473, v_x_2478, v_s_2479});
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
    default: return heff_nomatch(v_x2_2472);
    }
  }
  default: return heff_nomatch(v_t_2468);
  }
}
V g_heff_2esimplify_2esimpF_lam14(V self, V *args) {
  V v_a_2487 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam13(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_apply(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    heff_take_n(v_x2_2484, 3ULL, 2);
    V v_m_2488 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam14, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2489 = heff_tr(heff_apply(v_m_2488, 1, (V[]){v_s_2486}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_s_2491 = heff_field(v_x2_2489, 1);
      heff_take_n(v_x2_2489, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2485, v_x_2490, v_s_2491});
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2esimplify_2esimpF_lam16(V self, V *args) {
  V v_a_2499 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam15(V self, V *args) {
  V v_s_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2496 = heff_tr(heff_apply(v_m_2494, 1, (V[]){v_s_2495}));
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_MkPair: {
    V v_x_2497 = heff_field(v_x2_2496, 0);
    V v_s_2498 = heff_field(v_x2_2496, 1);
    heff_take_n(v_x2_2496, 3ULL, 2);
    V v_m_24100 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam16, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24101 = heff_tr(heff_apply(v_m_24100, 1, (V[]){v_s_2498}));
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_MkPair: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      V v_s_24103 = heff_field(v_x2_24101, 1);
      heff_take_n(v_x2_24101, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2497, v_x_24102, v_s_24103});
    }
    default: return heff_nomatch(v_x2_24101);
    }
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
V g_heff_2esimplify_2esimpF_lam18(V self, V *args) {
  V v_a_24112 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24112;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam17(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24109 = heff_tr(heff_apply(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    heff_take_n(v_x2_24109, 3ULL, 2);
    V v_m_24113 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam18, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24114 = heff_tr(heff_apply(v_m_24113, 1, (V[]){v_s_24111}));
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_s_24116 = heff_field(v_x2_24114, 1);
      heff_take_n(v_x2_24114, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24110, v_x_24115, v_s_24116});
    }
    default: return heff_nomatch(v_x2_24114);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2esimplify_2esimpF_lam20(V self, V *args) {
  V v_a_24123 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24123;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam19(V self, V *args) {
  V v_s_24119 = args[0];
  V v_m_24118 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24120 = heff_tr(heff_apply(v_m_24118, 1, (V[]){v_s_24119}));
  switch (heff_tag_of(v_x2_24120)) {
  case TAG_MkPair: {
    V v_x_24121 = heff_field(v_x2_24120, 0);
    V v_s_24122 = heff_field(v_x2_24120, 1);
    heff_take_n(v_x2_24120, 3ULL, 2);
    V v_m_24124 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam20, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24125 = heff_tr(heff_apply(v_m_24124, 1, (V[]){v_s_24122}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_s_24127 = heff_field(v_x2_24125, 1);
      heff_take_n(v_x2_24125, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24121, v_x_24126, v_s_24127});
    }
    default: return heff_nomatch(v_x2_24125);
    }
  }
  default: return heff_nomatch(v_x2_24120);
  }
}
V g_heff_2esimplify_2esimpF_lam22(V self, V *args) {
  V v_a_24135 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24135;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam21(V self, V *args) {
  V v_s_24131 = args[0];
  V v_m_24130 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24132 = heff_tr(heff_apply(v_m_24130, 1, (V[]){v_s_24131}));
  switch (heff_tag_of(v_x2_24132)) {
  case TAG_MkPair: {
    V v_x_24133 = heff_field(v_x2_24132, 0);
    V v_s_24134 = heff_field(v_x2_24132, 1);
    heff_take_n(v_x2_24132, 3ULL, 2);
    V v_m_24136 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam22, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24137 = heff_tr(heff_apply(v_m_24136, 1, (V[]){v_s_24134}));
    switch (heff_tag_of(v_x2_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x2_24137, 0);
      V v_s_24139 = heff_field(v_x2_24137, 1);
      heff_take_n(v_x2_24137, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24133, v_x_24138, v_s_24139});
    }
    default: return heff_nomatch(v_x2_24137);
    }
  }
  default: return heff_nomatch(v_x2_24132);
  }
}
V g_heff_2esimplify_2esimpF_lam24(V self, V *args) {
  V v_a_24147 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24147;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam23(V self, V *args) {
  V v_s_24143 = args[0];
  V v_m_24142 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24144 = heff_tr(heff_apply(v_m_24142, 1, (V[]){v_s_24143}));
  switch (heff_tag_of(v_x2_24144)) {
  case TAG_MkPair: {
    V v_x_24145 = heff_field(v_x2_24144, 0);
    V v_s_24146 = heff_field(v_x2_24144, 1);
    heff_take_n(v_x2_24144, 3ULL, 2);
    V v_m_24148 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam24, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24149 = heff_tr(heff_apply(v_m_24148, 1, (V[]){v_s_24146}));
    switch (heff_tag_of(v_x2_24149)) {
    case TAG_MkPair: {
      V v_x_24150 = heff_field(v_x2_24149, 0);
      V v_s_24151 = heff_field(v_x2_24149, 1);
      heff_take_n(v_x2_24149, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24145, v_x_24150, v_s_24151});
    }
    default: return heff_nomatch(v_x2_24149);
    }
  }
  default: return heff_nomatch(v_x2_24144);
  }
}
V g_heff_2esimplify_2esimpF_lam26(V self, V *args) {
  V v_a_24159 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24159;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam25(V self, V *args) {
  V v_s_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24156 = heff_tr(heff_apply(v_m_24154, 1, (V[]){v_s_24155}));
  switch (heff_tag_of(v_x2_24156)) {
  case TAG_MkPair: {
    V v_x_24157 = heff_field(v_x2_24156, 0);
    V v_s_24158 = heff_field(v_x2_24156, 1);
    heff_take_n(v_x2_24156, 3ULL, 2);
    V v_m_24160 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24161 = heff_tr(heff_apply(v_m_24160, 1, (V[]){v_s_24158}));
    switch (heff_tag_of(v_x2_24161)) {
    case TAG_MkPair: {
      V v_x_24162 = heff_field(v_x2_24161, 0);
      V v_s_24163 = heff_field(v_x2_24161, 1);
      heff_take_n(v_x2_24161, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24157, v_x_24162, v_s_24163});
    }
    default: return heff_nomatch(v_x2_24161);
    }
  }
  default: return heff_nomatch(v_x2_24156);
  }
}
V g_heff_2esimplify_2esimpF_lam28(V self, V *args) {
  V v_a_24170 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24170;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam27(V self, V *args) {
  V v_s_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24167 = heff_tr(heff_apply(v_m_24165, 1, (V[]){v_s_24166}));
  switch (heff_tag_of(v_x2_24167)) {
  case TAG_MkPair: {
    V v_x_24168 = heff_field(v_x2_24167, 0);
    V v_s_24169 = heff_field(v_x2_24167, 1);
    heff_take_n(v_x2_24167, 3ULL, 2);
    V v_m_24171 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam28, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24172 = heff_tr(heff_apply(v_m_24171, 1, (V[]){v_s_24169}));
    switch (heff_tag_of(v_x2_24172)) {
    case TAG_MkPair: {
      V v_x_24173 = heff_field(v_x2_24172, 0);
      V v_s_24174 = heff_field(v_x2_24172, 1);
      heff_take_n(v_x2_24172, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24168, v_x_24173, v_s_24174});
    }
    default: return heff_nomatch(v_x2_24172);
    }
  }
  default: return heff_nomatch(v_x2_24167);
  }
}
V g_heff_2esimplify_2esimpF_lam30(V self, V *args) {
  V v_a_24182 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24182;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam29(V self, V *args) {
  V v_s_24178 = args[0];
  V v_m_24177 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24179 = heff_tr(heff_apply(v_m_24177, 1, (V[]){v_s_24178}));
  switch (heff_tag_of(v_x2_24179)) {
  case TAG_MkPair: {
    V v_x_24180 = heff_field(v_x2_24179, 0);
    V v_s_24181 = heff_field(v_x2_24179, 1);
    heff_take_n(v_x2_24179, 3ULL, 2);
    V v_m_24183 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam30, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24184 = heff_tr(heff_apply(v_m_24183, 1, (V[]){v_s_24181}));
    switch (heff_tag_of(v_x2_24184)) {
    case TAG_MkPair: {
      V v_x_24185 = heff_field(v_x2_24184, 0);
      V v_s_24186 = heff_field(v_x2_24184, 1);
      heff_take_n(v_x2_24184, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24180, v_x_24185, v_s_24186});
    }
    default: return heff_nomatch(v_x2_24184);
    }
  }
  default: return heff_nomatch(v_x2_24179);
  }
}
V g_heff_2esimplify_2esimpF_lam32(V self, V *args) {
  V v_a_24194 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24194;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam31(V self, V *args) {
  V v_s_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24191 = heff_tr(heff_apply(v_m_24189, 1, (V[]){v_s_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_MkPair: {
    V v_x_24192 = heff_field(v_x2_24191, 0);
    V v_s_24193 = heff_field(v_x2_24191, 1);
    heff_take_n(v_x2_24191, 3ULL, 2);
    V v_m_24195 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam32, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24196 = heff_tr(heff_apply(v_m_24195, 1, (V[]){v_s_24193}));
    switch (heff_tag_of(v_x2_24196)) {
    case TAG_MkPair: {
      V v_x_24197 = heff_field(v_x2_24196, 0);
      V v_s_24198 = heff_field(v_x2_24196, 1);
      heff_take_n(v_x2_24196, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24192, v_x_24197, v_s_24198});
    }
    default: return heff_nomatch(v_x2_24196);
    }
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2esimplify_2esimpF_lam34(V self, V *args) {
  V v_a_24205 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24205;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam33(V self, V *args) {
  V v_s_24201 = args[0];
  V v_m_24200 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24202 = heff_tr(heff_apply(v_m_24200, 1, (V[]){v_s_24201}));
  switch (heff_tag_of(v_x2_24202)) {
  case TAG_MkPair: {
    V v_x_24203 = heff_field(v_x2_24202, 0);
    V v_s_24204 = heff_field(v_x2_24202, 1);
    heff_take_n(v_x2_24202, 3ULL, 2);
    V v_m_24206 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam34, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24207 = heff_tr(heff_apply(v_m_24206, 1, (V[]){v_s_24204}));
    switch (heff_tag_of(v_x2_24207)) {
    case TAG_MkPair: {
      V v_x_24208 = heff_field(v_x2_24207, 0);
      V v_s_24209 = heff_field(v_x2_24207, 1);
      heff_take_n(v_x2_24207, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24203, v_x_24208, v_s_24209});
    }
    default: return heff_nomatch(v_x2_24207);
    }
  }
  default: return heff_nomatch(v_x2_24202);
  }
}
V g_heff_2esimplify_2esimpF_lam36(V self, V *args) {
  V v_a_24216 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24216;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam35(V self, V *args) {
  V v_s_24212 = args[0];
  V v_m_24211 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24213 = heff_tr(heff_apply(v_m_24211, 1, (V[]){v_s_24212}));
  switch (heff_tag_of(v_x2_24213)) {
  case TAG_MkPair: {
    V v_x_24214 = heff_field(v_x2_24213, 0);
    V v_s_24215 = heff_field(v_x2_24213, 1);
    heff_take_n(v_x2_24213, 3ULL, 2);
    V v_m_24217 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam36, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24218 = heff_tr(heff_apply(v_m_24217, 1, (V[]){v_s_24215}));
    switch (heff_tag_of(v_x2_24218)) {
    case TAG_MkPair: {
      V v_x_24219 = heff_field(v_x2_24218, 0);
      V v_s_24220 = heff_field(v_x2_24218, 1);
      heff_take_n(v_x2_24218, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24214, v_x_24219, v_s_24220});
    }
    default: return heff_nomatch(v_x2_24218);
    }
  }
  default: return heff_nomatch(v_x2_24213);
  }
}
V g_heff_2esimplify_2esimpF_lam38(V self, V *args) {
  V v_a_24227 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24227;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam37(V self, V *args) {
  V v_s_24223 = args[0];
  V v_m_24222 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24224 = heff_tr(heff_apply(v_m_24222, 1, (V[]){v_s_24223}));
  switch (heff_tag_of(v_x2_24224)) {
  case TAG_MkPair: {
    V v_x_24225 = heff_field(v_x2_24224, 0);
    V v_s_24226 = heff_field(v_x2_24224, 1);
    heff_take_n(v_x2_24224, 3ULL, 2);
    V v_m_24228 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam38, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24229 = heff_tr(heff_apply(v_m_24228, 1, (V[]){v_s_24226}));
    switch (heff_tag_of(v_x2_24229)) {
    case TAG_MkPair: {
      V v_x_24230 = heff_field(v_x2_24229, 0);
      V v_s_24231 = heff_field(v_x2_24229, 1);
      heff_take_n(v_x2_24229, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24225, v_x_24230, v_s_24231});
    }
    default: return heff_nomatch(v_x2_24229);
    }
  }
  default: return heff_nomatch(v_x2_24224);
  }
}
V g_heff_2esimplify_2esimpF_lam40(V self, V *args) {
  V v_a_24239 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24239;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam39(V self, V *args) {
  V v_s_24235 = args[0];
  V v_m_24234 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24236 = heff_tr(heff_apply(v_m_24234, 1, (V[]){v_s_24235}));
  switch (heff_tag_of(v_x2_24236)) {
  case TAG_MkPair: {
    V v_x_24237 = heff_field(v_x2_24236, 0);
    V v_s_24238 = heff_field(v_x2_24236, 1);
    heff_take_n(v_x2_24236, 3ULL, 2);
    V v_m_24240 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam40, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24241 = heff_tr(heff_apply(v_m_24240, 1, (V[]){v_s_24238}));
    switch (heff_tag_of(v_x2_24241)) {
    case TAG_MkPair: {
      V v_x_24242 = heff_field(v_x2_24241, 0);
      V v_s_24243 = heff_field(v_x2_24241, 1);
      heff_take_n(v_x2_24241, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24237, v_x_24242, v_s_24243});
    }
    default: return heff_nomatch(v_x2_24241);
    }
  }
  default: return heff_nomatch(v_x2_24236);
  }
}
V g_heff_2esimplify_2esimpF_lam42(V self, V *args) {
  V v_a_24250 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24250;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam41(V self, V *args) {
  V v_s_24246 = args[0];
  V v_m_24245 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24247 = heff_tr(heff_apply(v_m_24245, 1, (V[]){v_s_24246}));
  switch (heff_tag_of(v_x2_24247)) {
  case TAG_MkPair: {
    V v_x_24248 = heff_field(v_x2_24247, 0);
    V v_s_24249 = heff_field(v_x2_24247, 1);
    heff_take_n(v_x2_24247, 3ULL, 2);
    V v_m_24251 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24252 = heff_tr(heff_apply(v_m_24251, 1, (V[]){v_s_24249}));
    switch (heff_tag_of(v_x2_24252)) {
    case TAG_MkPair: {
      V v_x_24253 = heff_field(v_x2_24252, 0);
      V v_s_24254 = heff_field(v_x2_24252, 1);
      heff_take_n(v_x2_24252, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24248, v_x_24253, v_s_24254});
    }
    default: return heff_nomatch(v_x2_24252);
    }
  }
  default: return heff_nomatch(v_x2_24247);
  }
}
V g_heff_2esimplify_2esimpF_lam44(V self, V *args) {
  V v_a_24260 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24260;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam43(V self, V *args) {
  V v_s_24256 = args[0];
  V v_m_24255 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24257 = heff_tr(heff_apply(v_m_24255, 1, (V[]){v_s_24256}));
  switch (heff_tag_of(v_x2_24257)) {
  case TAG_MkPair: {
    V v_x_24258 = heff_field(v_x2_24257, 0);
    V v_s_24259 = heff_field(v_x2_24257, 1);
    heff_take_n(v_x2_24257, 3ULL, 2);
    V v_m_24261 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam44, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24262 = heff_tr(heff_apply(v_m_24261, 1, (V[]){v_s_24259}));
    switch (heff_tag_of(v_x2_24262)) {
    case TAG_MkPair: {
      V v_x_24263 = heff_field(v_x2_24262, 0);
      V v_s_24264 = heff_field(v_x2_24262, 1);
      heff_take_n(v_x2_24262, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24258, v_x_24263, v_s_24264});
    }
    default: return heff_nomatch(v_x2_24262);
    }
  }
  default: return heff_nomatch(v_x2_24257);
  }
}
V g_heff_2esimplify_2esimpF_lam46(V self, V *args) {
  V v_a_24272 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24272;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam45(V self, V *args) {
  V v_s_24268 = args[0];
  V v_m_24267 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24269 = heff_tr(heff_apply(v_m_24267, 1, (V[]){v_s_24268}));
  switch (heff_tag_of(v_x2_24269)) {
  case TAG_MkPair: {
    V v_x_24270 = heff_field(v_x2_24269, 0);
    V v_s_24271 = heff_field(v_x2_24269, 1);
    heff_take_n(v_x2_24269, 3ULL, 2);
    V v_m_24273 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam46, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24274 = heff_tr(heff_apply(v_m_24273, 1, (V[]){v_s_24271}));
    switch (heff_tag_of(v_x2_24274)) {
    case TAG_MkPair: {
      V v_x_24275 = heff_field(v_x2_24274, 0);
      V v_s_24276 = heff_field(v_x2_24274, 1);
      heff_take_n(v_x2_24274, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24270, v_x_24275, v_s_24276});
    }
    default: return heff_nomatch(v_x2_24274);
    }
  }
  default: return heff_nomatch(v_x2_24269);
  }
}
V g_heff_2esimplify_2esimpF_lam48(V self, V *args) {
  V v_a_24285 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24285;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam47(V self, V *args) {
  V v_s_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24282 = heff_tr(heff_apply(v_m_24280, 1, (V[]){v_s_24281}));
  switch (heff_tag_of(v_x2_24282)) {
  case TAG_MkPair: {
    V v_x_24283 = heff_field(v_x2_24282, 0);
    V v_s_24284 = heff_field(v_x2_24282, 1);
    heff_take_n(v_x2_24282, 3ULL, 2);
    V v_m_24286 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam48, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24287 = heff_tr(heff_apply(v_m_24286, 1, (V[]){v_s_24284}));
    switch (heff_tag_of(v_x2_24287)) {
    case TAG_MkPair: {
      V v_x_24288 = heff_field(v_x2_24287, 0);
      V v_s_24289 = heff_field(v_x2_24287, 1);
      heff_take_n(v_x2_24287, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24283, v_x_24288, v_s_24289});
    }
    default: return heff_nomatch(v_x2_24287);
    }
  }
  default: return heff_nomatch(v_x2_24282);
  }
}
V g_heff_2esimplify_2esimpF_lam50(V self, V *args) {
  V v_a_24296 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24296;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam49(V self, V *args) {
  V v_s_24292 = args[0];
  V v_m_24291 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24293 = heff_tr(heff_apply(v_m_24291, 1, (V[]){v_s_24292}));
  switch (heff_tag_of(v_x2_24293)) {
  case TAG_MkPair: {
    V v_x_24294 = heff_field(v_x2_24293, 0);
    V v_s_24295 = heff_field(v_x2_24293, 1);
    heff_take_n(v_x2_24293, 3ULL, 2);
    V v_m_24297 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam50, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24298 = heff_tr(heff_apply(v_m_24297, 1, (V[]){v_s_24295}));
    switch (heff_tag_of(v_x2_24298)) {
    case TAG_MkPair: {
      V v_x_24299 = heff_field(v_x2_24298, 0);
      V v_s_24300 = heff_field(v_x2_24298, 1);
      heff_take_n(v_x2_24298, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24294, v_x_24299, v_s_24300});
    }
    default: return heff_nomatch(v_x2_24298);
    }
  }
  default: return heff_nomatch(v_x2_24293);
  }
}
V g_heff_2esimplify_2esimpF_lam52(V self, V *args) {
  V v_a_24308 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24308;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam51(V self, V *args) {
  V v_s_24304 = args[0];
  V v_m_24303 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24305 = heff_tr(heff_apply(v_m_24303, 1, (V[]){v_s_24304}));
  switch (heff_tag_of(v_x2_24305)) {
  case TAG_MkPair: {
    V v_x_24306 = heff_field(v_x2_24305, 0);
    V v_s_24307 = heff_field(v_x2_24305, 1);
    heff_take_n(v_x2_24305, 3ULL, 2);
    V v_m_24309 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam52, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24310 = heff_tr(heff_apply(v_m_24309, 1, (V[]){v_s_24307}));
    switch (heff_tag_of(v_x2_24310)) {
    case TAG_MkPair: {
      V v_x_24311 = heff_field(v_x2_24310, 0);
      V v_s_24312 = heff_field(v_x2_24310, 1);
      heff_take_n(v_x2_24310, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24306, v_x_24311, v_s_24312});
    }
    default: return heff_nomatch(v_x2_24310);
    }
  }
  default: return heff_nomatch(v_x2_24305);
  }
}
V g_heff_2esimplify_2esimpF_lam54(V self, V *args) {
  V v_a_24320 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24320;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam53(V self, V *args) {
  V v_s_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24317 = heff_tr(heff_apply(v_m_24315, 1, (V[]){v_s_24316}));
  switch (heff_tag_of(v_x2_24317)) {
  case TAG_MkPair: {
    V v_x_24318 = heff_field(v_x2_24317, 0);
    V v_s_24319 = heff_field(v_x2_24317, 1);
    heff_take_n(v_x2_24317, 3ULL, 2);
    V v_m_24321 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam54, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24322 = heff_tr(heff_apply(v_m_24321, 1, (V[]){v_s_24319}));
    switch (heff_tag_of(v_x2_24322)) {
    case TAG_MkPair: {
      V v_x_24323 = heff_field(v_x2_24322, 0);
      V v_s_24324 = heff_field(v_x2_24322, 1);
      heff_take_n(v_x2_24322, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24318, v_x_24323, v_s_24324});
    }
    default: return heff_nomatch(v_x2_24322);
    }
  }
  default: return heff_nomatch(v_x2_24317);
  }
}
V g_heff_2esimplify_2esimpF_lam56(V self, V *args) {
  V v_a_24332 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24332;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam55(V self, V *args) {
  V v_s_24328 = args[0];
  V v_m_24327 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24329 = heff_tr(heff_apply(v_m_24327, 1, (V[]){v_s_24328}));
  switch (heff_tag_of(v_x2_24329)) {
  case TAG_MkPair: {
    V v_x_24330 = heff_field(v_x2_24329, 0);
    V v_s_24331 = heff_field(v_x2_24329, 1);
    heff_take_n(v_x2_24329, 3ULL, 2);
    V v_m_24333 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam56, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24334 = heff_tr(heff_apply(v_m_24333, 1, (V[]){v_s_24331}));
    switch (heff_tag_of(v_x2_24334)) {
    case TAG_MkPair: {
      V v_x_24335 = heff_field(v_x2_24334, 0);
      V v_s_24336 = heff_field(v_x2_24334, 1);
      heff_take_n(v_x2_24334, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24330, v_x_24335, v_s_24336});
    }
    default: return heff_nomatch(v_x2_24334);
    }
  }
  default: return heff_nomatch(v_x2_24329);
  }
}
V g_heff_2esimplify_2esimpF_lam58(V self, V *args) {
  V v_a_24343 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24343;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam57(V self, V *args) {
  V v_s_24339 = args[0];
  V v_m_24338 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24340 = heff_tr(heff_apply(v_m_24338, 1, (V[]){v_s_24339}));
  switch (heff_tag_of(v_x2_24340)) {
  case TAG_MkPair: {
    V v_x_24341 = heff_field(v_x2_24340, 0);
    V v_s_24342 = heff_field(v_x2_24340, 1);
    heff_take_n(v_x2_24340, 3ULL, 2);
    V v_m_24344 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam58, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24345 = heff_tr(heff_apply(v_m_24344, 1, (V[]){v_s_24342}));
    switch (heff_tag_of(v_x2_24345)) {
    case TAG_MkPair: {
      V v_x_24346 = heff_field(v_x2_24345, 0);
      V v_s_24347 = heff_field(v_x2_24345, 1);
      heff_take_n(v_x2_24345, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24341, v_x_24346, v_s_24347});
    }
    default: return heff_nomatch(v_x2_24345);
    }
  }
  default: return heff_nomatch(v_x2_24340);
  }
}
V g_heff_2esimplify_2esimpF_lam60(V self, V *args) {
  V v_a_24355 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24355;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam59(V self, V *args) {
  V v_s_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24352 = heff_tr(heff_apply(v_m_24350, 1, (V[]){v_s_24351}));
  switch (heff_tag_of(v_x2_24352)) {
  case TAG_MkPair: {
    V v_x_24353 = heff_field(v_x2_24352, 0);
    V v_s_24354 = heff_field(v_x2_24352, 1);
    heff_take_n(v_x2_24352, 3ULL, 2);
    V v_m_24356 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam60, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24357 = heff_tr(heff_apply(v_m_24356, 1, (V[]){v_s_24354}));
    switch (heff_tag_of(v_x2_24357)) {
    case TAG_MkPair: {
      V v_x_24358 = heff_field(v_x2_24357, 0);
      V v_s_24359 = heff_field(v_x2_24357, 1);
      heff_take_n(v_x2_24357, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24353, v_x_24358, v_s_24359});
    }
    default: return heff_nomatch(v_x2_24357);
    }
  }
  default: return heff_nomatch(v_x2_24352);
  }
}
V g_heff_2esimplify_2esimpF_lam62(V self, V *args) {
  V v_a_24367 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24367;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam61(V self, V *args) {
  V v_s_24363 = args[0];
  V v_m_24362 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24364 = heff_tr(heff_apply(v_m_24362, 1, (V[]){v_s_24363}));
  switch (heff_tag_of(v_x2_24364)) {
  case TAG_MkPair: {
    V v_x_24365 = heff_field(v_x2_24364, 0);
    V v_s_24366 = heff_field(v_x2_24364, 1);
    heff_take_n(v_x2_24364, 3ULL, 2);
    V v_m_24368 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam62, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24369 = heff_tr(heff_apply(v_m_24368, 1, (V[]){v_s_24366}));
    switch (heff_tag_of(v_x2_24369)) {
    case TAG_MkPair: {
      V v_x_24370 = heff_field(v_x2_24369, 0);
      V v_s_24371 = heff_field(v_x2_24369, 1);
      heff_take_n(v_x2_24369, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24365, v_x_24370, v_s_24371});
    }
    default: return heff_nomatch(v_x2_24369);
    }
  }
  default: return heff_nomatch(v_x2_24364);
  }
}
V g_heff_2esimplify_2esimpF_lam64(V self, V *args) {
  V v_a_24378 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24378;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam63(V self, V *args) {
  V v_s_24374 = args[0];
  V v_m_24373 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24375 = heff_tr(heff_apply(v_m_24373, 1, (V[]){v_s_24374}));
  switch (heff_tag_of(v_x2_24375)) {
  case TAG_MkPair: {
    V v_x_24376 = heff_field(v_x2_24375, 0);
    V v_s_24377 = heff_field(v_x2_24375, 1);
    heff_take_n(v_x2_24375, 3ULL, 2);
    V v_m_24379 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam64, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24380 = heff_tr(heff_apply(v_m_24379, 1, (V[]){v_s_24377}));
    switch (heff_tag_of(v_x2_24380)) {
    case TAG_MkPair: {
      V v_x_24381 = heff_field(v_x2_24380, 0);
      V v_s_24382 = heff_field(v_x2_24380, 1);
      heff_take_n(v_x2_24380, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24376, v_x_24381, v_s_24382});
    }
    default: return heff_nomatch(v_x2_24380);
    }
  }
  default: return heff_nomatch(v_x2_24375);
  }
}
V g_heff_2esimplify_2esimpF_lam66(V self, V *args) {
  V v_a_24389 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24389;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam65(V self, V *args) {
  V v_s_24385 = args[0];
  V v_m_24384 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24386 = heff_tr(heff_apply(v_m_24384, 1, (V[]){v_s_24385}));
  switch (heff_tag_of(v_x2_24386)) {
  case TAG_MkPair: {
    V v_x_24387 = heff_field(v_x2_24386, 0);
    V v_s_24388 = heff_field(v_x2_24386, 1);
    heff_take_n(v_x2_24386, 3ULL, 2);
    V v_m_24390 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam66, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24391 = heff_tr(heff_apply(v_m_24390, 1, (V[]){v_s_24388}));
    switch (heff_tag_of(v_x2_24391)) {
    case TAG_MkPair: {
      V v_x_24392 = heff_field(v_x2_24391, 0);
      V v_s_24393 = heff_field(v_x2_24391, 1);
      heff_take_n(v_x2_24391, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24387, v_x_24392, v_s_24393});
    }
    default: return heff_nomatch(v_x2_24391);
    }
  }
  default: return heff_nomatch(v_x2_24386);
  }
}
V g_heff_2esimplify_2esimpF_lam68(V self, V *args) {
  V v_a_24400 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24400;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam67(V self, V *args) {
  V v_s_24396 = args[0];
  V v_m_24395 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24397 = heff_tr(heff_apply(v_m_24395, 1, (V[]){v_s_24396}));
  switch (heff_tag_of(v_x2_24397)) {
  case TAG_MkPair: {
    V v_x_24398 = heff_field(v_x2_24397, 0);
    V v_s_24399 = heff_field(v_x2_24397, 1);
    heff_take_n(v_x2_24397, 3ULL, 2);
    V v_m_24401 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam68, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24402 = heff_tr(heff_apply(v_m_24401, 1, (V[]){v_s_24399}));
    switch (heff_tag_of(v_x2_24402)) {
    case TAG_MkPair: {
      V v_x_24403 = heff_field(v_x2_24402, 0);
      V v_s_24404 = heff_field(v_x2_24402, 1);
      heff_take_n(v_x2_24402, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24398, v_x_24403, v_s_24404});
    }
    default: return heff_nomatch(v_x2_24402);
    }
  }
  default: return heff_nomatch(v_x2_24397);
  }
}
V g_heff_2esimplify_2esimpF_lam70(V self, V *args) {
  V v_a_24412 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam69(V self, V *args) {
  V v_s_24408 = args[0];
  V v_m_24407 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24409 = heff_tr(heff_apply(v_m_24407, 1, (V[]){v_s_24408}));
  switch (heff_tag_of(v_x2_24409)) {
  case TAG_MkPair: {
    V v_x_24410 = heff_field(v_x2_24409, 0);
    V v_s_24411 = heff_field(v_x2_24409, 1);
    heff_take_n(v_x2_24409, 3ULL, 2);
    V v_m_24413 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam70, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24414 = heff_tr(heff_apply(v_m_24413, 1, (V[]){v_s_24411}));
    switch (heff_tag_of(v_x2_24414)) {
    case TAG_MkPair: {
      V v_x_24415 = heff_field(v_x2_24414, 0);
      V v_s_24416 = heff_field(v_x2_24414, 1);
      heff_take_n(v_x2_24414, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24410, v_x_24415, v_s_24416});
    }
    default: return heff_nomatch(v_x2_24414);
    }
  }
  default: return heff_nomatch(v_x2_24409);
  }
}
V g_heff_2esimplify_2esimpF_lam72(V self, V *args) {
  V v_a_24423 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam71(V self, V *args) {
  V v_s_24419 = args[0];
  V v_m_24418 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24420 = heff_tr(heff_apply(v_m_24418, 1, (V[]){v_s_24419}));
  switch (heff_tag_of(v_x2_24420)) {
  case TAG_MkPair: {
    V v_x_24421 = heff_field(v_x2_24420, 0);
    V v_s_24422 = heff_field(v_x2_24420, 1);
    heff_take_n(v_x2_24420, 3ULL, 2);
    V v_m_24424 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam72, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24425 = heff_tr(heff_apply(v_m_24424, 1, (V[]){v_s_24422}));
    switch (heff_tag_of(v_x2_24425)) {
    case TAG_MkPair: {
      V v_x_24426 = heff_field(v_x2_24425, 0);
      V v_s_24427 = heff_field(v_x2_24425, 1);
      heff_take_n(v_x2_24425, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24421, v_x_24426, v_s_24427});
    }
    default: return heff_nomatch(v_x2_24425);
    }
  }
  default: return heff_nomatch(v_x2_24420);
  }
}
V g_heff_2esimplify_2esimpF_lam74(V self, V *args) {
  V v_a_24433 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam73(V self, V *args) {
  V v_s_24429 = args[0];
  V v_m_24428 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24430 = heff_tr(heff_apply(v_m_24428, 1, (V[]){v_s_24429}));
  switch (heff_tag_of(v_x2_24430)) {
  case TAG_MkPair: {
    V v_x_24431 = heff_field(v_x2_24430, 0);
    V v_s_24432 = heff_field(v_x2_24430, 1);
    heff_take_n(v_x2_24430, 3ULL, 2);
    V v_m_24434 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam74, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24435 = heff_tr(heff_apply(v_m_24434, 1, (V[]){v_s_24432}));
    switch (heff_tag_of(v_x2_24435)) {
    case TAG_MkPair: {
      V v_x_24436 = heff_field(v_x2_24435, 0);
      V v_s_24437 = heff_field(v_x2_24435, 1);
      heff_take_n(v_x2_24435, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24431, v_x_24436, v_s_24437});
    }
    default: return heff_nomatch(v_x2_24435);
    }
  }
  default: return heff_nomatch(v_x2_24430);
  }
}
V g_heff_2esimplify_2esimpF_lam76(V self, V *args) {
  V v_a_24445 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam75(V self, V *args) {
  V v_s_24441 = args[0];
  V v_m_24440 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24442 = heff_tr(heff_apply(v_m_24440, 1, (V[]){v_s_24441}));
  switch (heff_tag_of(v_x2_24442)) {
  case TAG_MkPair: {
    V v_x_24443 = heff_field(v_x2_24442, 0);
    V v_s_24444 = heff_field(v_x2_24442, 1);
    heff_take_n(v_x2_24442, 3ULL, 2);
    V v_m_24446 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam76, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24447 = heff_tr(heff_apply(v_m_24446, 1, (V[]){v_s_24444}));
    switch (heff_tag_of(v_x2_24447)) {
    case TAG_MkPair: {
      V v_x_24448 = heff_field(v_x2_24447, 0);
      V v_s_24449 = heff_field(v_x2_24447, 1);
      heff_take_n(v_x2_24447, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24443, v_x_24448, v_s_24449});
    }
    default: return heff_nomatch(v_x2_24447);
    }
  }
  default: return heff_nomatch(v_x2_24442);
  }
}
V g_heff_2esimplify_2esimpF_lam77(V self, V *args) {
  V v_s_24454 = args[0];
  V v_m_24453 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_24450 = heff_env(self)[2];
  V v_b_24452 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24455 = heff_tr(heff_apply(v_m_24453, 1, (V[]){v_s_24454}));
  switch (heff_tag_of(v_x2_24455)) {
  case TAG_MkPair: {
    V v_x_24456 = heff_field(v_x2_24455, 0);
    V v_s_24457 = heff_field(v_x2_24455, 1);
    heff_take_n(v_x2_24455, 3ULL, 2);
    return (g_heff_2esimplify_2eletIn(v_r_240, v_x_24450, v_x_24456, v_b_24452, v_s_24457));
  }
  default: return heff_nomatch(v_x2_24455);
  }
}
V g_heff_2esimplify_2esimpF_lam79(V self, V *args) {
  V v_s_24463 = args[0];
  V v_m_24462 = heff_env(self)[0];
  V v_l_24460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24464 = heff_tr(heff_apply(v_m_24462, 1, (V[]){v_s_24463}));
  switch (heff_tag_of(v_x2_24464)) {
  case TAG_MkPair: {
    V v_x_24465 = heff_field(v_x2_24464, 0);
    V v_s_24466 = heff_field(v_x2_24464, 1);
    V v_ru_24x2_24464_24MkPair = heff_take_reuse_n(v_x2_24464, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_24460, v_x_24465}), v_s_24466});
  }
  default: return heff_nomatch(v_x2_24464);
  }
}
V g_heff_2esimplify_2esimpF_lam78(V self, V *args) {
  V v_p_24459 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24459)) {
  case TAG_MkPair: {
    V v_l_24460 = heff_field(v_p_24459, 0);
    V v_e_24461 = heff_field(v_p_24459, 1);
    heff_take_n(v_p_24459, 3ULL, 2);
    V v_m_24462 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_e_24461}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam79, 1, 2, (V[]){v_m_24462, v_l_24460});
  }
  default: return heff_nomatch(v_p_24459);
  }
}
V g_heff_2esimplify_2esimpF_lam80(V self, V *args) {
  V v_s_24468 = args[0];
  V v_m_24467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24469 = heff_tr(heff_apply(v_m_24467, 1, (V[]){v_s_24468}));
  switch (heff_tag_of(v_x2_24469)) {
  case TAG_MkPair: {
    V v_x_24470 = heff_field(v_x2_24469, 0);
    V v_s_24471 = heff_field(v_x2_24469, 1);
    V v_ru_24x2_24469_24MkPair = heff_take_reuse_n(v_x2_24469, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_x_24470}), v_s_24471});
  }
  default: return heff_nomatch(v_x2_24469);
  }
}
V g_heff_2esimplify_2esimpF_lam81(V self, V *args) {
  V v_s_24475 = args[0];
  V v_m_24474 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_l_24473 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24476 = heff_tr(heff_apply(v_m_24474, 1, (V[]){v_s_24475}));
  switch (heff_tag_of(v_x2_24476)) {
  case TAG_MkPair: {
    V v_x_24477 = heff_field(v_x2_24476, 0);
    V v_s_24478 = heff_field(v_x2_24476, 1);
    heff_take_n(v_x2_24476, 3ULL, 2);
    return heff_tail(heff_get(v_r_240, LBL_project), 3, (V[]){v_l_24473, v_x_24477, v_s_24478});
  }
  default: return heff_nomatch(v_x2_24476);
  }
}
V g_heff_2esimplify_2esimpF_lam82(V self, V *args) {
  V v_a_24481 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam83(V self, V *args) {
  V v_s_24483 = args[0];
  V v_m_24482 = heff_env(self)[0];
  V v_t_24479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24484 = heff_tr(heff_apply(v_m_24482, 1, (V[]){v_s_24483}));
  switch (heff_tag_of(v_x2_24484)) {
  case TAG_MkPair: {
    V v_x_24485 = heff_field(v_x2_24484, 0);
    V v_s_24486 = heff_field(v_x2_24484, 1);
    V v_ru_24x2_24484_24MkPair = heff_take_reuse_n(v_x2_24484, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_24479, v_x_24485}), v_s_24486});
  }
  default: return heff_nomatch(v_x2_24484);
  }
}
V g_heff_2esimplify_2esimpF_lam86(V self, V *args) {
  V v_s_24499 = args[0];
  V v_m_24498 = heff_env(self)[0];
  V v_t_24495 = heff_env(self)[1];
  V v_vs_24496 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24500 = heff_tr(heff_apply(v_m_24498, 1, (V[]){v_s_24499}));
  switch (heff_tag_of(v_x2_24500)) {
  case TAG_MkPair: {
    V v_x_24501 = heff_field(v_x2_24500, 0);
    V v_s_24502 = heff_field(v_x2_24500, 1);
    V v_ru_24x2_24500_24MkPair = heff_take_reuse_n(v_x2_24500, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24500_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_24495, v_vs_24496, v_x_24501}), v_s_24502});
  }
  default: return heff_nomatch(v_x2_24500);
  }
}
V g_heff_2esimplify_2esimpF_lam85(V self, V *args) {
  V v_a_24494 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24494)) {
  case TAG_MkArm: {
    V v_t_24495 = heff_field(v_a_24494, 0);
    V v_vs_24496 = heff_field(v_a_24494, 1);
    V v_b_24497 = heff_field(v_a_24494, 2);
    heff_take_n(v_a_24494, 7ULL, 3);
    V v_m_24498 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_24497}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam86, 1, 3, (V[]){v_m_24498, v_t_24495, v_vs_24496});
  }
  default: return heff_nomatch(v_a_24494);
  }
}
V g_heff_2esimplify_2esimpF_lam84(V self, V *args) {
  V v_s_24490 = args[0];
  V v_m_24489 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_24488 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24491 = heff_tr(heff_apply(v_m_24489, 1, (V[]){v_s_24490}));
  switch (heff_tag_of(v_x2_24491)) {
  case TAG_MkPair: {
    V v_x_24492 = heff_field(v_x2_24491, 0);
    V v_s_24493 = heff_field(v_x2_24491, 1);
    heff_take_n(v_x2_24491, 3ULL, 2);
    V v_m_24503 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam85, 1, 1, (V[]){heff_dup(v_r_240)}), v_arms_24488));
    V v_x2_24504 = heff_tr(heff_apply(v_m_24503, 1, (V[]){v_s_24493}));
    switch (heff_tag_of(v_x2_24504)) {
    case TAG_MkPair: {
      V v_x_24505 = heff_field(v_x2_24504, 0);
      V v_s_24506 = heff_field(v_x2_24504, 1);
      heff_take_n(v_x2_24504, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_match), 3, (V[]){v_x_24492, v_x_24505, v_s_24506});
    }
    default: return heff_nomatch(v_x2_24504);
    }
  }
  default: return heff_nomatch(v_x2_24491);
  }
}
V g_heff_2esimplify_2esimpF_lam87(V self, V *args) {
  V v_s_24508 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24508});
}
V g_heff_2esimplify_2esimpF_lam88(V self, V *args) {
  V v_a_24511 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24511;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam89(V self, V *args) {
  V v_s_24513 = args[0];
  V v_m_24512 = heff_env(self)[0];
  V v_p_24509 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24514 = heff_tr(heff_apply(v_m_24512, 1, (V[]){v_s_24513}));
  switch (heff_tag_of(v_x2_24514)) {
  case TAG_MkPair: {
    V v_x_24515 = heff_field(v_x2_24514, 0);
    V v_s_24516 = heff_field(v_x2_24514, 1);
    V v_ru_24x2_24514_24MkPair = heff_take_reuse_n(v_x2_24514, 3ULL, 2);
    V v_x2_24523;
    switch (heff_tag_of(v_x_24515)) {
    case TAG_Nil: {
      v_x2_24523 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_24517 = heff_dup(heff_field(v_x_24515, 0));
      V v_x22_24518 = heff_dup(heff_field(v_x_24515, 1));
      switch (heff_tag_of(v_x22_24518)) {
      case TAG_Nil: {
        v_x2_24523 = (g_heff_2esimplify_2eunOp(heff_dup(v_p_24509), v_a_24517));
        break;
      }
      case TAG_Cons: {
        V v_b_24519 = heff_field(v_x22_24518, 0);
        V v_x222_24520 = heff_field(v_x22_24518, 1);
        heff_take_n(v_x22_24518, 3ULL, 2);
        switch (heff_tag_of(v_x222_24520)) {
        case TAG_Nil: {
          v_x2_24523 = (g_heff_2esimplify_2ebinOp(heff_dup(v_p_24509), v_a_24517, v_b_24519));
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x222_24520, 0ULL, 2);
          heff_drop(v_a_24517);
          heff_drop(v_b_24519);
          v_x2_24523 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x222_24520);
        }
        break;
      }
      default: heff_nomatch(v_x22_24518);
      }
      break;
    }
    default: heff_nomatch(v_x_24515);
    }
    V v_x_24525;
    switch (heff_tag_of(v_x2_24523)) {
    case TAG_Nothing: {
      v_x_24525 = heff_tag_at(v_ru_24x2_24514_24MkPair, TAG_EPrimCall, 2, (V[]){v_p_24509, v_x_24515});
      break;
    }
    case TAG_Just: {
      V v_x_24524 = heff_field(v_x2_24523, 0);
      heff_take_n(v_x2_24523, 1ULL, 1);
      heff_drop(v_p_24509);
      heff_drop(v_x_24515);
      heff_drop_cell(v_ru_24x2_24514_24MkPair, 2);
      v_x_24525 = v_x_24524;
      break;
    }
    default: heff_nomatch(v_x2_24523);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24525, v_s_24516});
  }
  default: return heff_nomatch(v_x2_24514);
  }
}
V g_heff_2esimplify_2esimpF_lam90(V self, V *args) {
  V v_s_24528 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24528});
}
V g_heff_2esimplify_2esimpF_lam91(V self, V *args) {
  V v_s_24530 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24530});
}
V g_heff_2esimplify_2esimpF_lam92(V self, V *args) {
  V v_s_24532 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24532});
}
V g_heff_2esimplify_2esimpF_lam93(V self, V *args) {
  V v_s_24534 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24534});
}
V g_heff_2esimplify_2esimpF_lam94(V self, V *args) {
  V v_s_24537 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24537});
}
V g_heff_2esimplify_2esimpF_lam95(V self, V *args) {
  V v_s_24539 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24539});
}
V g_heff_2esimplify_2esimpF_lam96(V self, V *args) {
  V v_s_24540 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24540});
}
V g_heff_2esimplify_2esimpF_lam97(V self, V *args) {
  V v_s_24543 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24543});
}

static V g_heff_2esimplify_2einlineMax_val;
static int g_heff_2esimplify_2einlineMax_st;
static V g_heff_2esimplify_2einlineMax_init(void) {
  return MK_INT(50LL);
}
V g_heff_2esimplify_2einlineMax_get(void) {
  if (g_heff_2esimplify_2einlineMax_st == 2) return g_heff_2esimplify_2einlineMax_val;
  if (g_heff_2esimplify_2einlineMax_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2einlineMax_st = 1;
  g_heff_2esimplify_2einlineMax_val = heff_tr(g_heff_2esimplify_2einlineMax_init());
  g_heff_2esimplify_2einlineMax_st = 2;
  return g_heff_2esimplify_2einlineMax_val;
}
Clo g_heff_2esimplify_2einlineCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2einlineCall_entry, 5, 0};

V g_heff_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = ({ V a_0 = heff_dup(v_g_242); V b_1 = heff_get(heff_dup(v_s_244), LBL_defs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_x2_246 = (g_heff_2esimplify_2eknown(v_g_242, v_s_244));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x_247)) {
      case TAG_Nothing: {
        heff_drop(v_r_240);
        V v_x_249 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_249, v_s_248});
      }
      case TAG_Just: {
        V v_b_2410 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
        V v_t_2411 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
        V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2410, v_as_243}));
        return (g_heff_2esimplify_2eattempt(v_t_2411, v_t_2412, v_s_248));
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  case TAG_Just: {
    V v_b_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_b_2413, NTAG(TAG_Nil)});
    V v_a_2415 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2einlineMax_get()), MK_INT(0LL), v_t_2414));
    V v_t_2416 = heff_intLt(heff_dup(g_heff_2esimplify_2einlineMax_get()), v_a_2415);
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_r_240);
      heff_drop(v_g_242);
      V v_x_2417 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2417, v_s_244});
    }
    case TAG_False: {
      V v_x2_2418 = (g_heff_2esimplify_2eknown(v_g_242, v_s_244));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_s_2420 = heff_field(v_x2_2418, 1);
        V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
        switch (heff_tag_of(v_x_2419)) {
        case TAG_Nothing: {
          heff_drop(v_r_240);
          V v_x_2421 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2420});
        }
        case TAG_Just: {
          V v_b_2422 = heff_field(v_x_2419, 0);
          heff_take_n(v_x_2419, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
          V v_t_2423 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
          V v_t_2424 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2422, v_as_243}));
          return (g_heff_2esimplify_2eattempt(v_t_2423, v_t_2424, v_s_2420));
        }
        default: return heff_nomatch(v_x_2419);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esimplify_2einlineCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2einlineCall(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2efreshParams_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2efreshParams_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2esimplify_2efreshParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efreshParams_entry, 2, 0};

V g_heff_2esimplify_2efreshParams(V v_k_240, V v_s_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_get(heff_dup(v_s_241), LBL_supply)});
  V v_t_243 = (g_prelude_2erange(MK_INT(1LL), v_k_240));
  V v_t_244 = (g_prelude_2efoldl_24s1075493002x264635373(((V)&g_heff_2esimplify_2efreshParams_str0), ((V)&g_heff_2esimplify_2efreshParams_str1), MK_INT(1LL), v_t_242, v_t_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_MkPair: {
    V v_xs_245 = heff_field(v_t_244, 0);
    V v_n_246 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24MkPair = heff_take_reuse_n(v_t_244, 3ULL, 2);
    V v_t_247 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n_246, heff_get(heff_dup(v_s_241), LBL_fuel), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(heff_dup(v_s_241), LBL_plain), heff_get(v_s_241, LBL_sp)});
    return heff_tag_at(v_ru_24t_244_24MkPair, TAG_MkPair, 2, (V[]){v_xs_245, v_t_247});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esimplify_2efreshParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2efreshParams(a[0], a[1]);
}
Clo g_heff_2esimplify_2eremember_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eremember_entry, 3, 0};

V g_heff_2esimplify_2eremember(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_t_243 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_242), LBL_fuel));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_k_240, v_p_241, heff_get(heff_dup(v_s_242), LBL_plain)));
    v_t_245 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), v_t_244, heff_get(v_s_242, LBL_sp)});
    break;
  }
  case TAG_False: {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_t_245 = v_s_242;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
}
V g_heff_2esimplify_2eremember_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eremember(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2eplainCall_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2eplainCall_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2eplainCall_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_heff_2esimplify_2eplainCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eplainCall_entry, 5, 0};

V g_heff_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_246 = heff_strAppend(heff_dup(v_g_242), heff_strAppend(((V)&g_heff_2esimplify_2eplainCall_str0), heff_intShow(v_t_245)));
  V v_it_247 = ({ V a_0 = v_t_246; V b_1 = heff_get(heff_dup(v_s_244), LBL_plain); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_m_249 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_248}));
    V v_x2_2410 = heff_tr(heff_apply(v_m_249, 1, (V[]){heff_dup(v_s_244)}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_x2_2413 = (g_heff_2esimplify_2eknown(heff_dup(v_g_242), v_s_2412));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
        switch (heff_tag_of(v_x_2414)) {
        case TAG_Nothing: {
          heff_drop(v_r_240);
          heff_drop(v_g_242);
          heff_drop(v_s_244);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
          V v_x_2416 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_s_2415});
        }
        case TAG_Just: {
          V v_b_2417 = heff_field(v_x_2414, 0);
          heff_take_n(v_x_2414, 1ULL, 1);
          V v_t_2418 = (g_prelude_2emap_24s2083806615x1058260173(heff_dup(v_x_2411)));
          V v_m_2419 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2417, v_t_2418}));
          V v_x2_2420 = heff_tr(heff_apply(v_m_2419, 1, (V[]){v_s_2415}));
          switch (heff_tag_of(v_x2_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x2_2420, 0);
            V v_s_2422 = heff_field(v_x2_2420, 1);
            V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
            V v_e_2423 = (g_heff_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_as_243)));
            V v_t_2424 = heff_tag_at(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
            V v_t_2425 = (g_heff_2eir_2esizeW(MK_INT(0LL), v_t_2424));
            V v_lim_2426 = heff_intAdd(v_t_2425, heff_dup(g_heff_2esimplify_2ebudget_get()));
            V v_t_2427 = heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_2421), NTAG(TAG_Nil)});
            V v_a_2428 = (g_heff_2eir_2esizeB(heff_dup(v_lim_2426), MK_INT(0LL), v_t_2427));
            V v_x1_2429 = heff_intLt(v_lim_2426, v_a_2428);
            V v_t_2430;
            switch (heff_tag_of(v_x1_2429)) {
            case TAG_True: {
              v_t_2430 = NTAG(TAG_False);
              break;
            }
            case TAG_False: {
              v_t_2430 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x1_2429);
            }
            switch (heff_tag_of(v_t_2430)) {
            case TAG_True: {
              heff_drop(v_f_241);
              heff_drop(v_s_244);
              V v_t_2431 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2432 = heff_strAppend(v_g_242, heff_strAppend(((V)&g_heff_2esimplify_2eplainCall_str1), heff_intShow(v_t_2431)));
              V v_m_2433 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2eremember_clo), 2, (V[]){v_t_2432, heff_tag(TAG_Inlined, 2, (V[]){heff_dup(v_x_2411), heff_dup(v_x_2421)})}));
              V v_x2_2434 = heff_tr(heff_apply(v_m_2433, 1, (V[]){v_s_2422}));
              switch (heff_tag_of(v_x2_2434)) {
              case TAG_MkPair: {
                V v_s_2436 = heff_field(v_x2_2434, 1);
                heff_take_n(v_x2_2434, 2ULL, 2);
                V v_t_2437 = (g_heff_2esimplify_2ezipL(v_x_2411, v_as_243));
                V v_m_2438 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2437; V r_ = (g_prelude_2efoldl_24s1431458237x755517792(a_0, a_1)); heff_drop(v_t_2437); r_; });
                V v_t_2439 = (g_map_2esize(v_m_2438));
                V v_t_2440 = heff_intEq(v_t_2439, MK_INT(0LL));
                V v_x_2441;
                switch (heff_tag_of(v_t_2440)) {
                case TAG_True: {
                  heff_drop(v_m_2438);
                  v_x_2441 = v_x_2421;
                  break;
                }
                case TAG_False: {
                  v_x_2441 = ({ V a_0 = v_m_2438; V a_1 = v_x_2421; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2438); r_; });
                  break;
                }
                default: heff_nomatch(v_t_2440);
                }
                return heff_tag_at(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_x_2441, v_s_2436});
              }
              default: return heff_nomatch(v_x2_2434);
              }
            }
            case TAG_False: {
              heff_drop(v_x_2411);
              heff_drop(v_x_2421);
              V v_t_2442 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2443 = heff_strAppend(v_g_242, heff_strAppend(((V)&g_heff_2esimplify_2eplainCall_str2), heff_intShow(v_t_2442)));
              V v_m_2444 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2eremember_clo), 2, (V[]){v_t_2443, NTAG(TAG_NotInlined)}));
              V v_t_2445 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_2422), LBL_supply), heff_get(heff_dup(v_s_2422), LBL_fuel), heff_get(heff_dup(v_s_244), LBL_defs), heff_get(heff_dup(v_s_2422), LBL_safe), heff_get(v_s_244, LBL_total), heff_get(heff_dup(v_s_2422), LBL_plain), heff_get(v_s_2422, LBL_sp)});
              V v_x2_2446 = heff_tr(heff_apply(v_m_2444, 1, (V[]){v_t_2445}));
              switch (heff_tag_of(v_x2_2446)) {
              case TAG_MkPair: {
                V v_s_2448 = heff_field(v_x2_2446, 1);
                heff_take_n(v_x2_2446, 2ULL, 2);
                V v_x_2449 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
                return heff_tag_at(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_x_2449, v_s_2448});
              }
              default: return heff_nomatch(v_x2_2446);
              }
            }
            default: return heff_nomatch(v_t_2430);
            }
          }
          default: return heff_nomatch(v_x2_2420);
          }
        }
        default: return heff_nomatch(v_x_2414);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  case TAG_Just: {
    V v_it1_2450 = heff_field(v_it_247, 0);
    heff_take_n(v_it_247, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_242);
    switch (heff_tag_of(v_it1_2450)) {
    case TAG_Inlined: {
      V v_ps_2451 = heff_field(v_it1_2450, 0);
      V v_e_2452 = heff_field(v_it1_2450, 1);
      V v_ru_24it1_2450_24Inlined = heff_take_reuse_n(v_it1_2450, 3ULL, 2);
      V v_t_2453 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_244), LBL_fuel));
      switch (heff_tag_of(v_t_2453)) {
      case TAG_True: {
        heff_drop(v_f_241);
        V v_t_2454 = heff_intSub(heff_get(heff_dup(v_s_244), LBL_fuel), MK_INT(1LL));
        V v_s_2455 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_244), LBL_supply), v_t_2454, heff_get(heff_dup(v_s_244), LBL_defs), heff_get(heff_dup(v_s_244), LBL_safe), heff_get(heff_dup(v_s_244), LBL_total), heff_get(heff_dup(v_s_244), LBL_plain), heff_get(v_s_244, LBL_sp)});
        V v_x2_2456 = (g_heff_2eir_2efreshGo_24s1749472566x1664180022(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_2455), LBL_supply), v_e_2452));
        V v_x2_2460;
        switch (heff_tag_of(v_x2_2456)) {
        case TAG_MkPair: {
          V v_e_27_2457 = heff_field(v_x2_2456, 0);
          V v_n_2458 = heff_field(v_x2_2456, 1);
          heff_take_n(v_x2_2456, 3ULL, 2);
          V v_t_2459 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n_2458, heff_get(heff_dup(v_s_2455), LBL_fuel), heff_get(heff_dup(v_s_2455), LBL_defs), heff_get(heff_dup(v_s_2455), LBL_safe), heff_get(heff_dup(v_s_2455), LBL_total), heff_get(heff_dup(v_s_2455), LBL_plain), heff_get(v_s_2455, LBL_sp)});
          v_x2_2460 = heff_tag_at(v_ru_24it1_2450_24Inlined, TAG_MkPair, 2, (V[]){v_e_27_2457, v_t_2459});
          break;
        }
        default: heff_nomatch(v_x2_2456);
        }
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_MkPair: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          V v_s_2462 = heff_field(v_x2_2460, 1);
          V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
          V v_t_2463 = (g_heff_2esimplify_2ezipL(v_ps_2451, v_as_243));
          V v_m_2464 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2463; V r_ = (g_prelude_2efoldl_24s1431458237x755517792(a_0, a_1)); heff_drop(v_t_2463); r_; });
          V v_t_2465 = (g_map_2esize(v_m_2464));
          V v_t_2466 = heff_intEq(v_t_2465, MK_INT(0LL));
          V v_x_2467;
          switch (heff_tag_of(v_t_2466)) {
          case TAG_True: {
            heff_drop(v_m_2464);
            v_x_2467 = v_x_2461;
            break;
          }
          case TAG_False: {
            v_x_2467 = ({ V a_0 = v_m_2464; V a_1 = v_x_2461; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2464); r_; });
            break;
          }
          default: heff_nomatch(v_t_2466);
          }
          return heff_tag_at(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){v_x_2467, v_s_2462});
        }
        default: return heff_nomatch(v_x2_2460);
        }
      }
      case TAG_False: {
        heff_drop(v_ps_2451);
        heff_drop(v_e_2452);
        V v_x_2468 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at(v_ru_24it1_2450_24Inlined, TAG_MkPair, 2, (V[]){v_x_2468, v_s_244});
      }
      default: return heff_nomatch(v_t_2453);
      }
    }
    case TAG_NotInlined: {
      V v_x_2469 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2469, v_s_244});
    }
    default: return heff_nomatch(v_it1_2450);
    }
  }
  default: return heff_nomatch(v_it_247);
  }
}
V g_heff_2esimplify_2eplainCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eplainCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esimplify_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ecallOf_entry, 5, 0};

V g_heff_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
  }
  case TAG_Just: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EGlobal: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x51_245, 0);
      V v_t_2410 = (g_prelude_2emap_24s1716181342x353410538(heff_dup(v_as_243)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2412 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_248));
        V v_t_2413 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
        V v_t_2414 = heff_intEq(v_t_2412, v_t_2413);
        switch (heff_tag_of(v_t_2414)) {
        case TAG_True: {
          return heff_tail(((V)&g_heff_2esimplify_2eplainCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
        case TAG_False: {
          return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      case TAG_False: {
        return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_EApp: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELet: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ERecord: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EProj: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ETag: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EMatch: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrim: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrimCall: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ECall: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EInt: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EStr: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFixed: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat32: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EAbandon: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFix: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esimplify_2ecallOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2ecallOf(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
V g_heff_2esimplify_2eapplyLam_lam0(V self, V *args);
Clo g_heff_2esimplify_2eapplyLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eapplyLam_entry, 4, 0};

V g_heff_2esimplify_2eapplyLam(V v_r_240, V v_xs_241, V v_b_242, V v_as_243) {
top: ;
  V v_a_244 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_245 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_246 = heff_intLe(heff_dup(v_a_244), heff_dup(v_b_245));
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_b_245);
    v_t_247 = v_a_244;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_244);
    v_t_247 = v_b_245;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = (g_heff_2esimplify_2etakeL(v_t_247, heff_dup(v_xs_241)));
  V v_a_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2410 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_2411 = heff_intLe(heff_dup(v_a_249), heff_dup(v_b_2410));
  V v_t_2412;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_b_2410);
    v_t_2412 = v_a_249;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_249);
    v_t_2412 = v_b_2410;
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_t_2413 = (g_heff_2esimplify_2etakeL(v_t_2412, heff_dup(v_as_243)));
  V v_t_2414 = (g_heff_2esimplify_2ezipL(v_t_248, v_t_2413));
  V v_a_2415 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_a_2416 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2417 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_2418 = heff_intLe(heff_dup(v_a_2416), heff_dup(v_b_2417));
  V v_b_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_b_2417);
    v_b_2419 = v_a_2416;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_2416);
    v_b_2419 = v_b_2417;
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_t_2420 = heff_intLt(v_b_2419, v_a_2415);
  V v_t_2426;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    V v_a_2421 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    V v_b_2422 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2423 = heff_intLe(heff_dup(v_a_2421), heff_dup(v_b_2422));
    V v_t_2424;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_b_2422);
      v_t_2424 = v_a_2421;
      break;
    }
    case TAG_False: {
      heff_drop(v_a_2421);
      v_t_2424 = v_b_2422;
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_t_2425 = (g_heff_2esimplify_2edropL(v_t_2424, heff_dup(v_xs_241)));
    v_t_2426 = heff_tag(TAG_ELam, 2, (V[]){v_t_2425, v_b_242});
    break;
  }
  case TAG_False: {
    v_t_2426 = v_b_242;
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_t_2427 = ({ V a_0 = v_t_2414; V a_1 = v_t_2426; V r_ = (g_heff_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_m_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_t_2427}));
  return heff_clo(g_heff_2esimplify_2eapplyLam_lam0, 1, 4, (V[]){v_m_2428, v_xs_241, v_as_243, v_r_240});
}
V g_heff_2esimplify_2eapplyLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eapplyLam(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2eapplyLam_lam0(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_a_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
    V v_b_2434 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2435 = heff_intLe(heff_dup(v_a_2433), heff_dup(v_b_2434));
    V v_t_2436;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_b_2434);
      v_t_2436 = v_a_2433;
      break;
    }
    case TAG_False: {
      heff_drop(v_a_2433);
      v_t_2436 = v_b_2434;
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2437 = (g_heff_2esimplify_2edropL(v_t_2436, v_as_243));
    return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2431, v_t_2437, v_s_2432});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
Clo g_heff_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        V v_t_249 = heff_strEq(heff_dup(v_x_244), heff_dup(v_y_248));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_False: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2evarsAre(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}

static V g_heff_2esimplify_2especArgSize_val;
static int g_heff_2esimplify_2especArgSize_st;
static V g_heff_2esimplify_2especArgSize_init(void) {
  return MK_INT(60LL);
}
V g_heff_2esimplify_2especArgSize_get(void) {
  if (g_heff_2esimplify_2especArgSize_st == 2) return g_heff_2esimplify_2especArgSize_val;
  if (g_heff_2esimplify_2especArgSize_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especArgSize_st = 1;
  g_heff_2esimplify_2especArgSize_val = heff_tr(g_heff_2esimplify_2especArgSize_init());
  g_heff_2esimplify_2especArgSize_st = 2;
  return g_heff_2esimplify_2especArgSize_val;
}

static V g_heff_2esimplify_2especBodySize_val;
static int g_heff_2esimplify_2especBodySize_st;
static V g_heff_2esimplify_2especBodySize_init(void) {
  return MK_INT(1200LL);
}
V g_heff_2esimplify_2especBodySize_get(void) {
  if (g_heff_2esimplify_2especBodySize_st == 2) return g_heff_2esimplify_2especBodySize_val;
  if (g_heff_2esimplify_2especBodySize_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especBodySize_st = 1;
  g_heff_2esimplify_2especBodySize_val = heff_tr(g_heff_2esimplify_2especBodySize_init());
  g_heff_2esimplify_2especBodySize_st = 2;
  return g_heff_2esimplify_2especBodySize_val;
}

static V g_heff_2esimplify_2especLimit_val;
static int g_heff_2esimplify_2especLimit_st;
static V g_heff_2esimplify_2especLimit_init(void) {
  return MK_INT(50000LL);
}
V g_heff_2esimplify_2especLimit_get(void) {
  if (g_heff_2esimplify_2especLimit_st == 2) return g_heff_2esimplify_2especLimit_val;
  if (g_heff_2esimplify_2especLimit_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especLimit_st = 1;
  g_heff_2esimplify_2especLimit_val = heff_tr(g_heff_2esimplify_2especLimit_init());
  g_heff_2esimplify_2especLimit_st = 2;
  return g_heff_2esimplify_2especLimit_val;
}

static V g_heff_2esimplify_2especDepth_val;
static int g_heff_2esimplify_2especDepth_st;
static V g_heff_2esimplify_2especDepth_init(void) {
  return MK_INT(16LL);
}
V g_heff_2esimplify_2especDepth_get(void) {
  if (g_heff_2esimplify_2especDepth_st == 2) return g_heff_2esimplify_2especDepth_val;
  if (g_heff_2esimplify_2especDepth_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especDepth_st = 1;
  g_heff_2esimplify_2especDepth_val = heff_tr(g_heff_2esimplify_2especDepth_init());
  g_heff_2esimplify_2especDepth_st = 2;
  return g_heff_2esimplify_2especDepth_val;
}
Clo g_heff_2esimplify_2eknownArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eknownArg_entry, 2, 0};

V g_heff_2esimplify_2eknownArg(V v_kinds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(v_g_243, v_kinds_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tag_at(v_ru_24x2_241_24ELam, TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){heff_dup(v_xs_246), heff_dup(v_b_247)}), NTAG(TAG_Nil)});
    V v_a_249 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_248));
    V v_x1_2410 = heff_intLt(heff_dup(g_heff_2esimplify_2especArgSize_get()), v_a_249);
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_True: {
      heff_drop(v_xs_246);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag(TAG_ELam, 2, (V[]){v_xs_246, v_b_247}); V r_ = (g_heff_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24x2_241_24ERecord, TAG_ERecord, 1, (V[]){heff_dup(v_fs_2416)}), NTAG(TAG_Nil)});
    V v_a_2418 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_2417));
    V v_x1_2419 = heff_intLt(heff_dup(g_heff_2esimplify_2especArgSize_get()), v_a_2418);
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_True: {
      heff_drop(v_fs_2416);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag(TAG_ERecord, 1, (V[]){v_fs_2416}); V r_ = (g_heff_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x1_2419);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eknownArg_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eknownArg(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2esimplify_2enthE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2enthE_entry, 2, 0};

V g_heff_2esimplify_2enthE(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2enthE_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2enthE(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emarkGo_entry, 4, 0};

V g_heff_2esimplify_2emarkGo(V v_all_240, V v_as_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_st_244)) {
    case TAG_True: {
      V v_x3_246 = (g_heff_2esimplify_2enthE(heff_dup(v_i_243), v_as_241));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        v_t_248 = (g_heff_2esimplify_2eknownArg(v_all_240, v_x_247));
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_st_244);
    }
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2esimplify_2emarkGo(v_all_240, v_as_241, v_rest_245, heff_intAdd(v_i_243, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2emarkGo(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2esimplify_2ekeepParams(V v_x1_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_xs_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_xs_241, 0);
      V v_xs2_245 = heff_field(v_xs_241, 1);
      heff_take_n(v_xs_241, 3ULL, 2);
      switch (heff_tag_of(v_m_242)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs2_245;
        v_x1_240 = t_0;
        v_xs_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_heff_2esimplify_2ekeepParams(v_ms_243, v_xs2_245))});
      }
      default: return heff_nomatch(v_m_242);
      }
    }
    default: return heff_nomatch(v_xs_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ekeepParams(a[0], a[1]);
}
V g_heff_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo(g_heff_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo(g_heff_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo(g_heff_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_as_2412 = heff_field(v_x3_242, 1);
        switch (heff_tag_of(v_m_245)) {
        case TAG_True: {
          V v_m_2413 = (g_heff_2esimplify_2esubstCopies(v_x_248, heff_dup(v_a_2411), v_e_243));
          return heff_clo(g_heff_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_as_2412)});
        }
        case TAG_False: {
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_as_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_m_245);
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2esubstMarked(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_as_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_as_2412; V a_3 = v_x_2416; V r_ = (g_heff_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_as_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2esimplify_2eshapeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eshapeOne_entry, 3, 0};

V g_heff_2esimplify_2eshapeOne(V v_m_240, V v_a_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_m_240)) {
  case TAG_True: {
    V v_t_243 = heff_rec(4, shape_ren__vars__holes__n, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_get(heff_dup(v_s_242), LBL_supply)});
    V v_x1_244 = (g_heff_2espec_2eshapeGo(v_a_241, v_t_243));
    V v_x_249;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_st_246 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 3ULL, 2);
      V v_t_247 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_st_246), LBL_vars)));
      V v_t_248 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_st_246), LBL_holes)));
      v_x_249 = heff_rec(4, shape_e__vars__holes__n, (V[]){v_e_245, v_t_247, v_t_248, heff_get(v_st_246, LBL_n)});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_t_2410 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_x_249), LBL_n), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_249, v_t_2410});
  }
  case TAG_False: {
    V v_t_2411 = heff_rec(4, shape_e__vars__holes__n, (V[]){v_a_241, NTAG(TAG_Nil), NTAG(TAG_Nil), heff_get(heff_dup(v_s_242), LBL_supply)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2411, v_s_242});
  }
  default: return heff_nomatch(v_m_240);
  }
}
V g_heff_2esimplify_2eshapeOne_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eshapeOne(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2esimplify_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eshapesOf_entry, 3, 0};

V g_heff_2esimplify_2eshapesOf(V v_x1_240, V v_as_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_243, v_p_242});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      V v_t_246 = heff_rec(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_t_246, v_p_242});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_as_241, 0);
      V v_as2_248 = heff_field(v_as_241, 1);
      V v_ru_24as_241_24Cons = heff_take_reuse_n(v_as_241, 3ULL, 2);
      V v_x2_249 = ({ V a_0 = v_m_244; V a_1 = v_a_247; V a_2 = v_p_242; V r_ = (g_heff_2esimplify_2eshapeOne(a_0, a_1, a_2)); heff_drop(v_m_244); r_; });
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        V v_m_2412 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_as2_248}));
        V v_x2_2413 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2411}));
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          V v_s_2415 = heff_field(v_x2_2413, 1);
          heff_take_n(v_x2_2413, 3ULL, 2);
          V v_t_2416 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_x_2410), LBL_e), heff_get(heff_dup(v_x_2414), LBL_args)});
          V v_t_2417 = (g_heff_2esimplify_2eappendL(heff_get(heff_dup(v_x_2410), LBL_vars), heff_get(heff_dup(v_x_2414), LBL_vars)));
          V v_t_2418 = (g_heff_2esimplify_2eappendL(heff_get(v_x_2410, LBL_holes), heff_get(v_x_2414, LBL_holes)));
          V v_x_2419 = heff_rec(3, shape_args__vars__holes, (V[]){v_t_2416, v_t_2417, v_t_2418});
          return heff_tag_at(v_ru_24as_241_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2415});
        }
        default: return heff_nomatch(v_x2_2413);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2eshapesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eshapesOf(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2emarkSafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emarkSafe_entry, 3, 0};

V g_heff_2esimplify_2emarkSafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2eir_2eisValue(v_b_241));
  V v_t_247;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_get(heff_dup(v_s_242), LBL_safe)));
    v_t_247 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), v_t_244, heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
    break;
  }
  case TAG_False: {
    V v_t_245 = ({ V b_0 = heff_get(heff_dup(v_s_242), LBL_safe); V b_1 = heff_get(heff_dup(v_s_242), LBL_total); V a_2 = v_b_241; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_get(heff_dup(v_s_242), LBL_safe)));
      v_t_247 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), v_t_246, heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
      break;
    }
    case TAG_False: {
      heff_drop(v_h_240);
      v_t_247 = v_s_242;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2esimplify_2emarkSafe_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2emarkSafe(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2easkedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2easkedFor_entry, 4, 0};

V g_heff_2esimplify_2easkedFor(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_a_245 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_244));
  V v_x1_246 = heff_intLt(heff_dup(g_heff_2esimplify_2especBodySize_get()), v_a_245);
  V v_t_248;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    v_t_248 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_all);
    break;
  }
  case TAG_False: {
    V v_t_247 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_all);
    v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), heff_dup(v_b0_241), v_t_247));
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_2438;
  switch (heff_tag_of(v_b0_241)) {
  case TAG_EVar: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2438 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2438 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b0_241);
  }
  V v_t_2440;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_True: {
    V v_t_2439 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_kinds);
    v_t_2440 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), v_t_2439));
    break;
  }
  case TAG_False: {
    v_t_2440 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_kinds);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2441 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_recipes);
  V v_t_2442 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_b0_241, v_t_2441));
  V v_t_2443 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_depths);
  V v_t_2444 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_d_242, v_t_2443));
  V v_t_2445 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_made);
  V v_t_2446 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_count);
  V v_t_2447 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_off);
  V v_p_2448 = heff_rec(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_248, v_t_2440, v_t_2442, v_t_2444, v_t_2445, heff_intAdd(v_t_2446, MK_INT(1LL)), v_t_2447});
  V v_t_2449 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_243), LBL_supply), heff_get(heff_dup(v_s_243), LBL_fuel), heff_get(heff_dup(v_s_243), LBL_defs), heff_get(heff_dup(v_s_243), LBL_safe), heff_get(heff_dup(v_s_243), LBL_total), heff_get(v_s_243, LBL_plain), v_p_2448});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2449});
}
V g_heff_2esimplify_2easkedFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2easkedFor(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2especBody_lam0(V self, V *args);
V g_heff_2esimplify_2especBody_lam1(V self, V *args);
V g_heff_2esimplify_2especBody_lam2(V self, V *args);
V g_heff_2esimplify_2especBody_lam3(V self, V *args);
V g_heff_2esimplify_2especBody_lam4(V self, V *args);
V g_heff_2esimplify_2especBody_lam5(V self, V *args);
V g_heff_2esimplify_2especBody_lam6(V self, V *args);
V g_heff_2esimplify_2especBody_lam7(V self, V *args);
V g_heff_2esimplify_2especBody_lam8(V self, V *args);
V g_heff_2esimplify_2especBody_lam9(V self, V *args);
V g_heff_2esimplify_2especBody_lam10(V self, V *args);
V g_heff_2esimplify_2especBody_lam11(V self, V *args);
V g_heff_2esimplify_2especBody_lam12(V self, V *args);
V g_heff_2esimplify_2especBody_lam13(V self, V *args);
V g_heff_2esimplify_2especBody_lam14(V self, V *args);
V g_heff_2esimplify_2especBody_lam15(V self, V *args);
V g_heff_2esimplify_2especBody_lam16(V self, V *args);
V g_heff_2esimplify_2especBody_lam17(V self, V *args);
V g_heff_2esimplify_2especBody_lam18(V self, V *args);
Clo g_heff_2esimplify_2especBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especBody_entry, 5, 0};

V g_heff_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_sh_243, V v_lam1_244) {
top: ;
  switch (heff_tag_of(v_lam1_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam0, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam1, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELam: {
    V v_xs1_249 = heff_field(v_lam1_244, 0);
    V v_b1_2410 = heff_field(v_lam1_244, 1);
    heff_take_n(v_lam1_244, 3ULL, 2);
    V v_t_2411 = (g_prelude_2emap_24s2083806615x1058260173(heff_get(heff_dup(v_sh_243), LBL_vars)));
    V v_t_2412 = (g_heff_2espec_2eselfTo(v_g_240, v_h_241, v_t_2411, heff_dup(v_marks_242), v_b1_2410));
    V v_m_2413 = ({ V a_0 = heff_dup(v_marks_242); V a_1 = heff_dup(v_xs1_249); V b_2 = heff_get(heff_dup(v_sh_243), LBL_args); V a_3 = v_t_2412; V r_ = (g_heff_2esimplify_2esubstMarked(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    return heff_clo(g_heff_2esimplify_2especBody_lam2, 1, 4, (V[]){v_m_2413, v_marks_242, v_xs1_249, v_sh_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam3, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam4, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam5, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam6, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam7, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam8, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam9, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam10, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam11, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam12, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam13, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam14, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam15, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam16, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam17, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop(v_sh_243);
    return heff_clo(g_heff_2esimplify_2especBody_lam18, 1, 1, (V[]){v_lam1_244});
  }
  default: return heff_nomatch(v_lam1_244);
  }
}
V g_heff_2esimplify_2especBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2especBody(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esimplify_2especBody_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_246});
}
V g_heff_2esimplify_2especBody_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_248});
}
V g_heff_2esimplify_2especBody_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_marks_242 = heff_env(self)[1];
  V v_xs1_249 = heff_env(self)[2];
  V v_sh_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = (g_heff_2esimplify_2ekeepParams(heff_dup(v_marks_242), heff_dup(v_xs1_249)));
    V v_x1_2419 = (g_heff_2esimplify_2eappendL(heff_get(heff_dup(v_sh_243), LBL_vars), v_t_2418));
    V v_x_2424;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      heff_drop(v_marks_242);
      heff_drop(v_xs1_249);
      heff_drop(v_sh_243);
      heff_drop_cell(v_ru_24x2_2415_24MkPair, 2);
      v_x_2424 = v_x_2416;
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2419, 0ULL, 2);
      V v_t_2422 = (g_heff_2esimplify_2ekeepParams(v_marks_242, v_xs1_249));
      V v_t_2423 = (g_heff_2esimplify_2eappendL(heff_get(v_sh_243, LBL_vars), v_t_2422));
      v_x_2424 = heff_tag_at(v_ru_24x2_2415_24MkPair, TAG_ELam, 2, (V[]){v_t_2423, v_x_2416});
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2424, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2esimplify_2especBody_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2427});
}
V g_heff_2esimplify_2especBody_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2431});
}
V g_heff_2esimplify_2especBody_lam5(V self, V *args) {
  V v_s_2433 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2433});
}
V g_heff_2esimplify_2especBody_lam6(V self, V *args) {
  V v_s_2436 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2436});
}
V g_heff_2esimplify_2especBody_lam7(V self, V *args) {
  V v_s_2439 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2439});
}
V g_heff_2esimplify_2especBody_lam8(V self, V *args) {
  V v_s_2442 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2442});
}
V g_heff_2esimplify_2especBody_lam9(V self, V *args) {
  V v_s_2444 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2444});
}
V g_heff_2esimplify_2especBody_lam10(V self, V *args) {
  V v_s_2447 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2447});
}
V g_heff_2esimplify_2especBody_lam11(V self, V *args) {
  V v_s_2450 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2450});
}
V g_heff_2esimplify_2especBody_lam12(V self, V *args) {
  V v_s_2452 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2452});
}
V g_heff_2esimplify_2especBody_lam13(V self, V *args) {
  V v_s_2454 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2454});
}
V g_heff_2esimplify_2especBody_lam14(V self, V *args) {
  V v_s_2456 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2456});
}
V g_heff_2esimplify_2especBody_lam15(V self, V *args) {
  V v_s_2459 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2459});
}
V g_heff_2esimplify_2especBody_lam16(V self, V *args) {
  V v_s_2461 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2461});
}
V g_heff_2esimplify_2especBody_lam17(V self, V *args) {
  V v_s_2462 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2462});
}
V g_heff_2esimplify_2especBody_lam18(V self, V *args) {
  V v_s_2465 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2465});
}
Clo g_heff_2esimplify_2echeap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2echeap_entry, 2, 0};

V g_heff_2esimplify_2echeap(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    V v_x3_244 = ({ V a_0 = heff_dup(v_g_243); V a_1 = v_safe_240; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_safe_240); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_b_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2esimplify_2echeap(heff_dup(v_safe_240), v_a_2411));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      V t_0 = v_safe_240;
      V t_1 = v_b_2412;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x2_241, 0);
    V v_t_2415 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2416 = (g_prelude_2emap_24s1448703749x94773476(heff_dup(v_fs_2414)));
    V v_t_2417 = (g_prelude_2emap(v_t_2415, v_t_2416));
    return ({ V a_0 = v_t_2417; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    V t_0 = v_safe_240;
    V t_1 = v_e_2418;
    v_safe_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2423 = (g_prelude_2emap(v_t_2422, heff_dup(v_as_2421)));
    return ({ V a_0 = v_t_2423; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2423); r_; });
  }
  case TAG_EMatch: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2427 = heff_field(v_x2_241, 0);
    V v_as_2428 = heff_field(v_x2_241, 1);
    V v_x1_2429 = (g_heff_2esimplify_2eprimFails(heff_dup(v_p_2427)));
    switch (heff_tag_of(v_x1_2429)) {
    case TAG_True: {
      heff_drop(v_safe_240);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_t_2430 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
      V v_t_2431 = (g_prelude_2emap(v_t_2430, heff_dup(v_as_2428)));
      return ({ V a_0 = v_t_2431; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2431); r_; });
    }
    default: return heff_nomatch(v_x1_2429);
    }
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2echeap_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2echeap(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2elamsOut_entry, 2, 0};

V g_heff_2esimplify_2elamsOut(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_x2_241, 0);
    heff_drop(v_safe_240);
    return (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_ys_244));
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2esimplify_2echeap(heff_dup(v_safe_240), v_a_249));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V t_0 = v_safe_240;
      V t_1 = v_b_2410;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2417 = heff_field(v_x2_241, 0);
    V v_arms_2418 = heff_field(v_x2_241, 1);
    V v_t_2419 = (g_heff_2esimplify_2echeap(heff_dup(v_safe_240), v_sc_2417));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      V v_x1_2422;
      switch (heff_tag_of(v_arms_2418)) {
      case TAG_Nil: {
        v_x1_2422 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_2422 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_arms_2418);
      }
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_True: {
        heff_drop(v_safe_240);
        return MK_INT(0LL);
      }
      case TAG_False: {
        V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2elamsOut_clo), 1, (V[]){v_safe_240}));
        V v_t_2424 = (g_prelude_2emap_24s1295898052x1915853031(heff_dup(v_arms_2418)));
        V v_x1_2425 = (g_prelude_2emap(v_t_2423, v_t_2424));
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2426 = heff_field(v_x1_2425, 0);
          V v_xs_2427 = heff_field(v_x1_2425, 1);
          heff_take_n(v_x1_2425, 3ULL, 2);
          return ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s1163606919x177582362(a_0, a_1)); heff_drop(v_xs_2427); r_; });
        }
        default: return heff_nomatch(v_x1_2425);
        }
      }
      default: return heff_nomatch(v_x1_2422);
      }
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2elamsOut(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esimplify_2estripLams_lam0(V self, V *args);
Clo g_heff_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_246 = (g_prelude_2emap_24s2083806615x1058260173(heff_dup(v_zs_240)));
    V v_t_247 = (g_heff_2esimplify_2ezipL(heff_dup(v_ys_244), v_as_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_prelude_2efoldl_24s1431458237x755517792(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_a_249 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_ys_244));
    V v_b_2410 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_t_2411 = heff_intLt(v_b_2410, v_a_249);
    V v_e_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2413 = (g_heff_2esimplify_2edropL(v_t_2412, v_ys_244));
      v_e_2414 = heff_tag_at(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_b_245});
      break;
    }
    case TAG_False: {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2414 = v_b_245;
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2415 = (g_map_2esize(v_m_248));
    V v_t_2416 = heff_intEq(v_t_2415, MK_INT(0LL));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_m_248);
      return v_e_2414;
    }
    case TAG_False: {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2414; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  case TAG_EApp: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_e_241, 0);
    V v_a_2420 = heff_field(v_e_241, 1);
    V v_b_2421 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    return heff_tag_at(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_a_2420, (g_heff_2esimplify_2estripLams(v_zs_240, v_b_2421))});
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2427 = heff_field(v_e_241, 0);
    V v_arms_2428 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2429 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    return heff_tag_at(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2427, (g_prelude_2emap(heff_clo(g_heff_2esimplify_2estripLams_lam0, 1, 1, (V[]){v_go_2429}), v_arms_2428))});
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2estripLams(a[0], a[1]);
}
V g_heff_2esimplify_2estripLams_lam0(V self, V *args) {
  V v_x2_2430 = args[0];
  V v_go_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkArm: {
    V v_t_2431 = heff_field(v_x2_2430, 0);
    V v_vs_2432 = heff_field(v_x2_2430, 1);
    V v_b_2433 = heff_field(v_x2_2430, 2);
    V v_ru_24x2_2430_24MkArm = heff_take_reuse_n(v_x2_2430, 7ULL, 3);
    V v_t_2434 = heff_tr(heff_apply(v_go_2429, 1, (V[]){v_b_2433}));
    return heff_tag_at(v_ru_24x2_2430_24MkArm, TAG_MkArm, 3, (V[]){v_t_2431, v_vs_2432, v_t_2434});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
Clo g_heff_2esimplify_2eraise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eraise_entry, 2, 0};

V g_heff_2esimplify_2eraise(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_244 = heff_intEq(v_t_243, MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_245 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_246 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_245}));
      V v_x2_247 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        V v_x_2410 = heff_tag_at(v_ru_24x2_247_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_248), (g_heff_2esimplify_2estripLams(v_x_248, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_2412 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2413 = heff_intEq(v_t_2412, MK_INT(0LL));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2414 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2415 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2414}));
      V v_x2_2416 = heff_tr(heff_apply(v_m_2415, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
        V v_x_2419 = heff_tag_at(v_ru_24x2_2416_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2417), (g_heff_2esimplify_2estripLams(v_x_2417, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_ELam: {
    V v_xs_2420 = heff_field(v_e_240, 0);
    V v_b_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2422 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_b_2421));
    V v_t_2423 = heff_intEq(v_t_2422, MK_INT(0LL));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_2420, v_b_2421}), v_p_241});
    }
    case TAG_False: {
      V v_t_2424 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_b_2421));
      V v_m_2425 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2424}));
      V v_x2_2426 = heff_tr(heff_apply(v_m_2425, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        V v_s_2428 = heff_field(v_x2_2426, 1);
        V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
        V v_t_2429 = (g_heff_2esimplify_2eappendL(v_xs_2420, heff_dup(v_x_2427)));
        V v_x_2430 = heff_tag_at(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2429, (g_heff_2esimplify_2estripLams(v_x_2427, v_b_2421))});
        return heff_tag_at(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){v_x_2430, v_s_2428});
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_EApp: {
    V v_t_2433 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2434 = heff_intEq(v_t_2433, MK_INT(0LL));
    switch (heff_tag_of(v_t_2434)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2435 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2436 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2435}));
      V v_x2_2437 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2437)) {
      case TAG_MkPair: {
        V v_x_2438 = heff_field(v_x2_2437, 0);
        V v_s_2439 = heff_field(v_x2_2437, 1);
        V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
        V v_x_2440 = heff_tag_at(v_ru_24x2_2437_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2438), (g_heff_2esimplify_2estripLams(v_x_2438, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2439});
      }
      default: return heff_nomatch(v_x2_2437);
      }
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  case TAG_ELet: {
    V v_t_2444 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2445 = heff_intEq(v_t_2444, MK_INT(0LL));
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2446 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2447 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2446}));
      V v_x2_2448 = heff_tr(heff_apply(v_m_2447, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_MkPair: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        V v_s_2450 = heff_field(v_x2_2448, 1);
        V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
        V v_x_2451 = heff_tag_at(v_ru_24x2_2448_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2449), (g_heff_2esimplify_2estripLams(v_x_2449, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2451, v_s_2450});
      }
      default: return heff_nomatch(v_x2_2448);
      }
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_ERecord: {
    V v_t_2453 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2454 = heff_intEq(v_t_2453, MK_INT(0LL));
    switch (heff_tag_of(v_t_2454)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2455 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2456 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2455}));
      V v_x2_2457 = heff_tr(heff_apply(v_m_2456, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_s_2459 = heff_field(v_x2_2457, 1);
        V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
        V v_x_2460 = heff_tag_at(v_ru_24x2_2457_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2458), (g_heff_2esimplify_2estripLams(v_x_2458, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2460, v_s_2459});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  case TAG_EProj: {
    V v_t_2463 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2464 = heff_intEq(v_t_2463, MK_INT(0LL));
    switch (heff_tag_of(v_t_2464)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2465 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2466 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2465}));
      V v_x2_2467 = heff_tr(heff_apply(v_m_2466, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2467)) {
      case TAG_MkPair: {
        V v_x_2468 = heff_field(v_x2_2467, 0);
        V v_s_2469 = heff_field(v_x2_2467, 1);
        V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
        V v_x_2470 = heff_tag_at(v_ru_24x2_2467_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2468), (g_heff_2esimplify_2estripLams(v_x_2468, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2470, v_s_2469});
      }
      default: return heff_nomatch(v_x2_2467);
      }
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  case TAG_ETag: {
    V v_t_2473 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2474 = heff_intEq(v_t_2473, MK_INT(0LL));
    switch (heff_tag_of(v_t_2474)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2475 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2476 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2475}));
      V v_x2_2477 = heff_tr(heff_apply(v_m_2476, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
        V v_x_2480 = heff_tag_at(v_ru_24x2_2477_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2478), (g_heff_2esimplify_2estripLams(v_x_2478, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2480, v_s_2479});
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
    default: return heff_nomatch(v_t_2474);
    }
  }
  case TAG_EMatch: {
    V v_t_2483 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2484 = heff_intEq(v_t_2483, MK_INT(0LL));
    switch (heff_tag_of(v_t_2484)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2485 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2486 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2485}));
      V v_x2_2487 = heff_tr(heff_apply(v_m_2486, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2487)) {
      case TAG_MkPair: {
        V v_x_2488 = heff_field(v_x2_2487, 0);
        V v_s_2489 = heff_field(v_x2_2487, 1);
        V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
        V v_x_2490 = heff_tag_at(v_ru_24x2_2487_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2488), (g_heff_2esimplify_2estripLams(v_x_2488, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2490, v_s_2489});
      }
      default: return heff_nomatch(v_x2_2487);
      }
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
  case TAG_EPrim: {
    V v_t_2492 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2493 = heff_intEq(v_t_2492, MK_INT(0LL));
    switch (heff_tag_of(v_t_2493)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2494 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2495 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2494}));
      V v_x2_2496 = heff_tr(heff_apply(v_m_2495, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_MkPair: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_s_2498 = heff_field(v_x2_2496, 1);
        V v_ru_24x2_2496_24MkPair = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
        V v_x_2499 = heff_tag_at(v_ru_24x2_2496_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2497), (g_heff_2esimplify_2estripLams(v_x_2497, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2499, v_s_2498});
      }
      default: return heff_nomatch(v_x2_2496);
      }
    }
    default: return heff_nomatch(v_t_2493);
    }
  }
  case TAG_EPrimCall: {
    V v_t_24102 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24103 = heff_intEq(v_t_24102, MK_INT(0LL));
    switch (heff_tag_of(v_t_24103)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24104 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24105 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24104}));
      V v_x2_24106 = heff_tr(heff_apply(v_m_24105, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24106)) {
      case TAG_MkPair: {
        V v_x_24107 = heff_field(v_x2_24106, 0);
        V v_s_24108 = heff_field(v_x2_24106, 1);
        V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
        V v_x_24109 = heff_tag_at(v_ru_24x2_24106_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24107), (g_heff_2esimplify_2estripLams(v_x_24107, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24109, v_s_24108});
      }
      default: return heff_nomatch(v_x2_24106);
      }
    }
    default: return heff_nomatch(v_t_24103);
    }
  }
  case TAG_ECall: {
    V v_t_24112 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24113 = heff_intEq(v_t_24112, MK_INT(0LL));
    switch (heff_tag_of(v_t_24113)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24114 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24115 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24114}));
      V v_x2_24116 = heff_tr(heff_apply(v_m_24115, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24116)) {
      case TAG_MkPair: {
        V v_x_24117 = heff_field(v_x2_24116, 0);
        V v_s_24118 = heff_field(v_x2_24116, 1);
        V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
        V v_x_24119 = heff_tag_at(v_ru_24x2_24116_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24117), (g_heff_2esimplify_2estripLams(v_x_24117, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24119, v_s_24118});
      }
      default: return heff_nomatch(v_x2_24116);
      }
    }
    default: return heff_nomatch(v_t_24113);
    }
  }
  case TAG_EInt: {
    V v_t_24121 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24122 = heff_intEq(v_t_24121, MK_INT(0LL));
    switch (heff_tag_of(v_t_24122)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24123 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24124 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24123}));
      V v_x2_24125 = heff_tr(heff_apply(v_m_24124, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24125)) {
      case TAG_MkPair: {
        V v_x_24126 = heff_field(v_x2_24125, 0);
        V v_s_24127 = heff_field(v_x2_24125, 1);
        V v_ru_24x2_24125_24MkPair = heff_take_reuse_n(v_x2_24125, 3ULL, 2);
        V v_x_24128 = heff_tag_at(v_ru_24x2_24125_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24126), (g_heff_2esimplify_2estripLams(v_x_24126, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24128, v_s_24127});
      }
      default: return heff_nomatch(v_x2_24125);
      }
    }
    default: return heff_nomatch(v_t_24122);
    }
  }
  case TAG_EFloat: {
    V v_t_24130 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24131 = heff_intEq(v_t_24130, MK_INT(0LL));
    switch (heff_tag_of(v_t_24131)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24132 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24133 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24132}));
      V v_x2_24134 = heff_tr(heff_apply(v_m_24133, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24134)) {
      case TAG_MkPair: {
        V v_x_24135 = heff_field(v_x2_24134, 0);
        V v_s_24136 = heff_field(v_x2_24134, 1);
        V v_ru_24x2_24134_24MkPair = heff_take_reuse_n(v_x2_24134, 3ULL, 2);
        V v_x_24137 = heff_tag_at(v_ru_24x2_24134_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24135), (g_heff_2esimplify_2estripLams(v_x_24135, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24137, v_s_24136});
      }
      default: return heff_nomatch(v_x2_24134);
      }
    }
    default: return heff_nomatch(v_t_24131);
    }
  }
  case TAG_EStr: {
    V v_t_24139 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24140 = heff_intEq(v_t_24139, MK_INT(0LL));
    switch (heff_tag_of(v_t_24140)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24141 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24142 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24141}));
      V v_x2_24143 = heff_tr(heff_apply(v_m_24142, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24143)) {
      case TAG_MkPair: {
        V v_x_24144 = heff_field(v_x2_24143, 0);
        V v_s_24145 = heff_field(v_x2_24143, 1);
        V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
        V v_x_24146 = heff_tag_at(v_ru_24x2_24143_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24144), (g_heff_2esimplify_2estripLams(v_x_24144, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24146, v_s_24145});
      }
      default: return heff_nomatch(v_x2_24143);
      }
    }
    default: return heff_nomatch(v_t_24140);
    }
  }
  case TAG_EFixed: {
    V v_t_24149 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24150 = heff_intEq(v_t_24149, MK_INT(0LL));
    switch (heff_tag_of(v_t_24150)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24151 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24152 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24151}));
      V v_x2_24153 = heff_tr(heff_apply(v_m_24152, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24153)) {
      case TAG_MkPair: {
        V v_x_24154 = heff_field(v_x2_24153, 0);
        V v_s_24155 = heff_field(v_x2_24153, 1);
        V v_ru_24x2_24153_24MkPair = heff_take_reuse_n(v_x2_24153, 3ULL, 2);
        V v_x_24156 = heff_tag_at(v_ru_24x2_24153_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24154), (g_heff_2esimplify_2estripLams(v_x_24154, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24156, v_s_24155});
      }
      default: return heff_nomatch(v_x2_24153);
      }
    }
    default: return heff_nomatch(v_t_24150);
    }
  }
  case TAG_EFloat32: {
    V v_t_24158 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24159 = heff_intEq(v_t_24158, MK_INT(0LL));
    switch (heff_tag_of(v_t_24159)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24160 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24161 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24160}));
      V v_x2_24162 = heff_tr(heff_apply(v_m_24161, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24162)) {
      case TAG_MkPair: {
        V v_x_24163 = heff_field(v_x2_24162, 0);
        V v_s_24164 = heff_field(v_x2_24162, 1);
        V v_ru_24x2_24162_24MkPair = heff_take_reuse_n(v_x2_24162, 3ULL, 2);
        V v_x_24165 = heff_tag_at(v_ru_24x2_24162_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24163), (g_heff_2esimplify_2estripLams(v_x_24163, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24165, v_s_24164});
      }
      default: return heff_nomatch(v_x2_24162);
      }
    }
    default: return heff_nomatch(v_t_24159);
    }
  }
  case TAG_EAbandon: {
    V v_t_24166 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24167 = heff_intEq(v_t_24166, MK_INT(0LL));
    switch (heff_tag_of(v_t_24167)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24168 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24169 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24168}));
      V v_x2_24170 = heff_tr(heff_apply(v_m_24169, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24170)) {
      case TAG_MkPair: {
        V v_x_24171 = heff_field(v_x2_24170, 0);
        V v_s_24172 = heff_field(v_x2_24170, 1);
        V v_ru_24x2_24170_24MkPair = heff_take_reuse_n(v_x2_24170, 3ULL, 2);
        V v_x_24173 = heff_tag_at(v_ru_24x2_24170_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24171), (g_heff_2esimplify_2estripLams(v_x_24171, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24173, v_s_24172});
      }
      default: return heff_nomatch(v_x2_24170);
      }
    }
    default: return heff_nomatch(v_t_24167);
    }
  }
  case TAG_EFix: {
    V v_t_24176 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24177 = heff_intEq(v_t_24176, MK_INT(0LL));
    switch (heff_tag_of(v_t_24177)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24178 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24179 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24178}));
      V v_x2_24180 = heff_tr(heff_apply(v_m_24179, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24180)) {
      case TAG_MkPair: {
        V v_x_24181 = heff_field(v_x2_24180, 0);
        V v_s_24182 = heff_field(v_x2_24180, 1);
        V v_ru_24x2_24180_24MkPair = heff_take_reuse_n(v_x2_24180, 3ULL, 2);
        V v_x_24183 = heff_tag_at(v_ru_24x2_24180_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24181), (g_heff_2esimplify_2estripLams(v_x_24181, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24183, v_s_24182});
      }
      default: return heff_nomatch(v_x2_24180);
      }
    }
    default: return heff_nomatch(v_t_24177);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esimplify_2eraise_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eraise(a[0], a[1]);
}
Clo g_heff_2esimplify_2emarkedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emarkedOf_entry, 2, 0};

V g_heff_2esimplify_2emarkedOf(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_as_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_m_242)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, (g_heff_2esimplify_2emarkedOf(v_ms_243, v_as_245))});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ms_243;
        V t_1 = v_as_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_m_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2emarkedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2emarkedOf(a[0], a[1]);
}
V g_heff_2esimplify_2edepthOf_lam0(V self, V *args);
Clo g_heff_2esimplify_2edepthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2edepthOf_entry, 3, 0};

V g_heff_2esimplify_2edepthOf(V v_ds_240, V v_g_241, V v_args_242) {
top: ;
  V v_t_243 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_args_242));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_g_241, ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_prelude_2efoldl_24s279777603x1686732349(a_0, a_1)); heff_drop(v_t_243); r_; })});
  V v_t_2411 = ({ V a_0 = heff_clo(g_heff_2esimplify_2edepthOf_lam0, 2, 1, (V[]){heff_dup(v_ds_240)}); V a_1 = MK_INT(0LL); V a_2 = v_t_244; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
  return heff_intAdd(MK_INT(1LL), v_t_2411);
}
V g_heff_2esimplify_2edepthOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2edepthOf(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2esimplify_2edepthOf_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_n_246 = args[1];
  V v_ds_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_247 = ({ V a_0 = v_n_246; V a_1 = v_ds_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_ds_240); r_; });
  V v_b_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_b_249 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_b_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2410 = heff_intLe(heff_dup(v_b_249), heff_dup(v_d_245));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_b_249);
    return v_d_245;
  }
  case TAG_False: {
    heff_drop(v_d_245);
    return v_b_249;
  }
  default: return heff_nomatch(v_t_2410);
  }
}
Clo g_heff_2esimplify_2esetOff_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esetOff_entry, 2, 0};

V g_heff_2esimplify_2esetOff(V v_o_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_all);
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_kinds);
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_recipes);
  V v_t_245 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_depths);
  V v_t_246 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_made);
  V v_t_247 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_count);
  V v_t_248 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), heff_get(heff_dup(v_s_241), LBL_fuel), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(v_s_241, LBL_plain), heff_rec(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_o_240})});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2esimplify_2esetOff_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2esetOff(a[0], a[1]);
}
Clo g_heff_2esimplify_2ebackTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ebackTo_entry, 2, 0};

V g_heff_2esimplify_2ebackTo(V v_saved_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_all);
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_kinds);
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_recipes);
  V v_t_245 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_depths);
  V v_t_246 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_made);
  V v_t_247 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_count);
  V v_t_248 = heff_get(heff_get(heff_dup(v_saved_240), LBL_sp), LBL_off);
  V v_t_249 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), heff_get(heff_dup(v_saved_240), LBL_fuel), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(v_s_241, LBL_total), heff_get(v_saved_240, LBL_plain), heff_rec(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248})});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_249});
}
V g_heff_2esimplify_2ebackTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ebackTo(a[0], a[1]);
}
Clo g_heff_2esimplify_2eknowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eknowing_entry, 3, 0};

V g_heff_2esimplify_2eknowing(V v_r_240, V v_b0_241, V v_s_242) {
top: ;
  V v_t_243 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), MK_INT(4000LL), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_242), LBL_sp)});
  V v_x2_244 = (g_heff_2esimplify_2esetOff(NTAG(TAG_True), v_t_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 2ULL, 2);
    V v_m_247 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_b0_241}));
    V v_x2_248 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_s_246}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      V v_m_2411 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_x_249}));
      V v_x2_2412 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_s_2410}));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        V v_x2_2415 = (g_heff_2esimplify_2eraise(v_x_2413, v_s_2414));
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_field(v_x2_2415, 0);
          V v_s_2417 = heff_field(v_x2_2415, 1);
          heff_take_n(v_x2_2415, 3ULL, 2);
          V v_t_2418 = (g_heff_2esimplify_2ebackTo(v_s_242, v_s_2417));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_MkPair: {
            V v_s_2420 = heff_field(v_t_2418, 1);
            heff_take_n(v_t_2418, 2ULL, 2);
            return heff_tag_at(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_s_2420});
          }
          default: return heff_nomatch(v_t_2418);
          }
        }
        default: return heff_nomatch(v_x2_2415);
        }
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2esimplify_2eknowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eknowing(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2eask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eask_entry, 9, 0};

V g_heff_2esimplify_2eask(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_marks_244, V v_sh_245, V v_h_246, V v_d_247, V v_s_248) {
top: ;
  V v_t_249 = heff_get(heff_get(heff_dup(v_s_248), LBL_sp), LBL_recipes);
  V v_x3_2410 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_t_249; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2410, 0ULL, 1);
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2410);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_244);
    heff_drop(v_sh_245);
    heff_drop(v_h_246);
    heff_drop(v_d_247);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_248});
  }
  case TAG_False: {
    V v_x2_2413 = (g_heff_2eir_2efreshGo_24s1749472566x1664180022(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_248), LBL_supply), heff_tag(TAG_ELam, 2, (V[]){v_xs_242, v_b_243})));
    V v_x2_2417;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_e_27_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2416 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n_2415, heff_get(heff_dup(v_s_248), LBL_fuel), heff_get(heff_dup(v_s_248), LBL_defs), heff_get(heff_dup(v_s_248), LBL_safe), heff_get(heff_dup(v_s_248), LBL_total), heff_get(heff_dup(v_s_248), LBL_plain), heff_get(v_s_248, LBL_sp)});
      v_x2_2417 = heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_2414, v_t_2416});
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_s_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      V v_m_2420 = (g_heff_2esimplify_2especBody(v_g_241, heff_dup(v_h_246), v_marks_244, v_sh_245, v_x_2418));
      V v_x2_2421 = heff_tr(heff_apply(v_m_2420, 1, (V[]){v_s_2419}));
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_s_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        V v_x2_2424 = (g_heff_2esimplify_2eknowing(v_r_240, v_x_2422, v_s_2423));
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_s_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          V v_x2_2427 = (g_heff_2esimplify_2easkedFor(heff_dup(v_h_246), heff_dup(v_x_2425), v_d_247, v_s_2426));
          switch (heff_tag_of(v_x2_2427)) {
          case TAG_MkPair: {
            V v_s_2429 = heff_field(v_x2_2427, 1);
            heff_take_n(v_x2_2427, 2ULL, 2);
            return ({ V a_0 = v_h_246; V a_1 = v_x_2425; V a_2 = v_s_2429; V r_ = (g_heff_2esimplify_2emarkSafe(a_0, a_1, a_2)); heff_drop(v_x_2425); r_; });
          }
          default: return heff_nomatch(v_x2_2427);
          }
        }
        default: return heff_nomatch(v_x2_2424);
        }
      }
      default: return heff_nomatch(v_x2_2421);
      }
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2esimplify_2eask_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eask(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2esimplify_2especNamed_lam0(V self, V *args);
V g_heff_2esimplify_2especNamed_lam1(V self, V *args);
Clo g_heff_2esimplify_2especNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especNamed_entry, 9, 0};

V g_heff_2esimplify_2especNamed(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_h_247, V v_d_248) {
top: ;
  V v_t_249 = heff_intLt(heff_dup(g_heff_2esimplify_2especDepth_get()), heff_dup(v_d_248));
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_sh_246);
    heff_drop(v_h_247);
    heff_drop(v_d_248);
    V v_x_2410 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_clo(g_heff_2esimplify_2especNamed_lam0, 1, 1, (V[]){v_x_2410});
  }
  case TAG_False: {
    return heff_clo(g_heff_2esimplify_2especNamed_lam1, 1, 9, (V[]){v_r_240, v_g_241, v_xs_242, v_b_243, v_marks_245, v_sh_246, v_h_247, v_d_248, v_as_244});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2esimplify_2especNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2especNamed(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2esimplify_2especNamed_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_s_2411});
}
V g_heff_2esimplify_2especNamed_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_xs_242 = heff_env(self)[2];
  V v_b_243 = heff_env(self)[3];
  V v_marks_245 = heff_env(self)[4];
  V v_sh_246 = heff_env(self)[5];
  V v_h_247 = heff_env(self)[6];
  V v_d_248 = heff_env(self)[7];
  V v_as_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_2413 = (g_heff_2esimplify_2eask(heff_dup(v_r_240), v_g_241, v_xs_242, v_b_243, heff_dup(v_marks_245), heff_dup(v_sh_246), heff_dup(v_h_247), v_d_248, v_s_2412));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_s_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 2ULL, 2);
    V v_t_2416 = (g_heff_2espec_2edropAt(v_marks_245, v_as_244));
    V v_t_2417 = (g_heff_2esimplify_2eappendL(heff_get(v_sh_246, LBL_holes), v_t_2416));
    return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_h_247}), v_t_2417, v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especShaped_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especShaped_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especShaped_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especShaped_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especShaped_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2especShaped_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2especShaped_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
Clo g_heff_2esimplify_2especShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especShaped_entry, 8, 0};

V g_heff_2esimplify_2especShaped(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_s_247) {
top: ;
  V v_x1_248 = (g_heff_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    V v_t_249 = heff_get(heff_dup(v_sh_246), LBL_vars);
    V v_x1_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_x1_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_249, 0ULL, 2);
      v_x1_2412 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_True: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_sh_246);
    V v_t_2416 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2416, v_s_247});
  }
  case TAG_False: {
    V v_t_2417 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_marks_245));
    V v_t_2418 = (g_heff_2esimplify_2etakeL(v_t_2417, heff_get(heff_dup(v_sh_246), LBL_args)));
    V v_x2_2419 = (g_prelude_2ezipWith_24s836893971x454572333(((V)&g_heff_2esimplify_2especShaped_str0), heff_dup(v_marks_245), v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2esimplify_2especShaped_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2esimplify_2especShaped_str2); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_k_2423 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2especShaped_str3), heff_strAppend(v_t_2422, ((V)&g_heff_2esimplify_2especShaped_str4))));
    V v_x2_2424 = (g_prelude_2eindexFrom(((V)&g_heff_2esimplify_2especShaped_str5), heff_dup(v_g_241), MK_INT(0LL)));
    V v_t_2426;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      v_t_2426 = heff_dup(v_g_241);
      break;
    }
    case TAG_Just: {
      V v_i_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      v_t_2426 = heff_strSlice(heff_dup(v_g_241), MK_INT(0LL), v_i_2425);
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2esimplify_2especShaped_str6), (g_heff_2espec_2ehashGo(v_k_2423, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)))));
    V v_t_2428 = heff_get(heff_get(heff_dup(v_s_247), LBL_sp), LBL_depths);
    V v_t_2429 = (g_heff_2esimplify_2emarkedOf(heff_dup(v_marks_245), heff_get(heff_dup(v_sh_246), LBL_args)));
    V v_t_2430 = ({ V a_0 = v_t_2428; V a_1 = heff_dup(v_g_241); V a_2 = v_t_2429; V r_ = (g_heff_2esimplify_2edepthOf(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
    V v_t_2431 = (g_heff_2esimplify_2especNamed(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_sh_246, v_t_2427, v_t_2430));
    return heff_tail(v_t_2431, 1, (V[]){v_s_247});
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2esimplify_2especShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2especShaped(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2esimplify_2especMarked_lam0(V self, V *args);
V g_heff_2esimplify_2especMarked_lam1(V self, V *args);
V g_heff_2esimplify_2especMarked_lam2(V self, V *args);
V g_heff_2esimplify_2especMarked_lam3(V self, V *args);
V g_heff_2esimplify_2especMarked_lam4(V self, V *args);
Clo g_heff_2esimplify_2especMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especMarked_entry, 6, 0};

V g_heff_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245) {
top: ;
  V v_x1_246 = (g_prelude_2eany_24s1963868307x1860200435(v_marks_245));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    V v_x1_247 = (g_heff_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      V v_t_248 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_249 = (g_heff_2eir_2enubI(v_t_248));
      V v_t_2410 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_249; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_249); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_x1_2411 = (g_heff_2eir_2eisValue(v_b_243));
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_True: {
          return heff_clo(g_heff_2esimplify_2especMarked_lam0, 1, 6, (V[]){v_marks_245, v_as_244, v_r_240, v_g_241, v_xs_242, v_b_243});
        }
        case TAG_False: {
          heff_drop(v_r_240);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_245);
          V v_x_2416 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
          return heff_clo(g_heff_2esimplify_2especMarked_lam1, 1, 1, (V[]){v_x_2416});
        }
        default: return heff_nomatch(v_x1_2411);
        }
      }
      case TAG_False: {
        return heff_clo(g_heff_2esimplify_2especMarked_lam2, 1, 6, (V[]){v_marks_245, v_as_244, v_r_240, v_g_241, v_xs_242, v_b_243});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_x1_247, 0ULL, 2);
      return heff_clo(g_heff_2esimplify_2especMarked_lam3, 1, 6, (V[]){v_marks_245, v_as_244, v_r_240, v_g_241, v_xs_242, v_b_243});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_False: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    V v_x_2428 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_clo(g_heff_2esimplify_2especMarked_lam4, 1, 1, (V[]){v_x_2428});
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esimplify_2especMarked_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2especMarked(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esimplify_2especMarked_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_marks_245 = heff_env(self)[0];
  V v_as_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_xs_242 = heff_env(self)[4];
  V v_b_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2413 = (g_heff_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_s_2412));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    return (g_heff_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2414, v_s_2415));
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2esimplify_2especMarked_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2416, v_s_2417});
}
V g_heff_2esimplify_2especMarked_lam2(V self, V *args) {
  V v_s_2418 = args[0];
  V v_marks_245 = heff_env(self)[0];
  V v_as_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_xs_242 = heff_env(self)[4];
  V v_b_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2419 = (g_heff_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_s_2418));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    return (g_heff_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2420, v_s_2421));
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2esimplify_2especMarked_lam3(V self, V *args) {
  V v_s_2424 = args[0];
  V v_marks_245 = heff_env(self)[0];
  V v_as_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_xs_242 = heff_env(self)[4];
  V v_b_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2425 = (g_heff_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_s_2424));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    heff_take_n(v_x2_2425, 3ULL, 2);
    return (g_heff_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2426, v_s_2427));
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2esimplify_2especMarked_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2428, v_s_2429});
}
V g_heff_2esimplify_2especLam_lam0(V self, V *args);
Clo g_heff_2esimplify_2especLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especLam_entry, 6, 0};

V g_heff_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get(heff_get(heff_dup(v_s_245), LBL_sp), LBL_off);
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_t_247 = heff_get(heff_get(heff_dup(v_s_245), LBL_sp), LBL_count);
    V v_t_248 = heff_intLe(heff_dup(g_heff_2esimplify_2especLimit_get()), v_t_247);
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_x1_2411 = (g_prelude_2eany(heff_clo(g_heff_2esimplify_2especLam_lam0, 1, 1, (V[]){heff_dup(v_s_245)}), v_as_244));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_True: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2412 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_2411);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    V v_x_2413 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2413, v_s_245});
  }
  case TAG_False: {
    V v_t_2414 = heff_get(heff_get(heff_dup(v_s_245), LBL_sp), LBL_kinds);
    V v_t_2415 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_2416 = (g_heff_2eir_2enubI(v_t_2415));
    V v_t_2417 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2416; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2419;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      V v_t_2418 = (g_heff_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
      v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
      break;
    }
    case TAG_False: {
      v_t_2419 = (g_prelude_2emap_24s764047539x1158385979(heff_dup(v_xs_242)));
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2420 = ({ V a_0 = v_t_2414; V a_1 = v_as_244; V a_2 = v_t_2419; V a_3 = MK_INT(0LL); V r_ = (g_heff_2esimplify_2emarkGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    V v_t_2421 = (g_heff_2esimplify_2especMarked(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_t_2420));
    return heff_tail(v_t_2421, 1, (V[]){v_s_245});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2esimplify_2especLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2especLam(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esimplify_2especLam_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_s_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_get(heff_get(v_s_245, LBL_sp), LBL_kinds);
  return ({ V a_0 = v_t_2410; V a_1 = v_a_249; V r_ = (g_heff_2esimplify_2eknownArg(a_0, a_1)); heff_drop(v_t_2410); r_; });
}
Clo g_heff_2esimplify_2etrySpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etrySpec_entry, 4, 0};

V g_heff_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_as_242, V v_s_243) {
top: ;
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_all);
  V v_it_245 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_r_240);
    V v_x_246 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_246, v_s_243});
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_EVar: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_249 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_249, v_s_243});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2411 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2411, v_s_243});
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_it1_247, 0);
      V v_b_2413 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      heff_drop_cell(v_ru_24it_245_24Just, 1);
      return (g_heff_2esimplify_2especLam(v_r_240, v_g_241, v_xs_2412, v_b_2413, v_as_242, v_s_243));
    }
    case TAG_EApp: {
      V v_ru_24it1_247_24EApp = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2416 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EApp, TAG_MkPair, 2, (V[]){v_x_2416, v_s_243});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2420 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2420, v_s_243});
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2422 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2422, v_s_243});
    }
    case TAG_EProj: {
      V v_ru_24it1_247_24EProj = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2425 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EProj, TAG_MkPair, 2, (V[]){v_x_2425, v_s_243});
    }
    case TAG_ETag: {
      V v_ru_24it1_247_24ETag = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2428 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24ETag, TAG_MkPair, 2, (V[]){v_x_2428, v_s_243});
    }
    case TAG_EMatch: {
      V v_ru_24it1_247_24EMatch = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2431 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EMatch, TAG_MkPair, 2, (V[]){v_x_2431, v_s_243});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2433 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2433, v_s_243});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_247_24EPrimCall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2436 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EPrimCall, TAG_MkPair, 2, (V[]){v_x_2436, v_s_243});
    }
    case TAG_ECall: {
      V v_ru_24it1_247_24ECall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2439 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24ECall, TAG_MkPair, 2, (V[]){v_x_2439, v_s_243});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2441 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2441, v_s_243});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2443 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2443, v_s_243});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2445 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2445, v_s_243});
    }
    case TAG_EFixed: {
      V v_ru_24it1_247_24EFixed = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2448 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EFixed, TAG_MkPair, 2, (V[]){v_x_2448, v_s_243});
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2450 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2450, v_s_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_2451 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2451, v_s_243});
    }
    case TAG_EFix: {
      V v_ru_24it1_247_24EFix = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2454 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EFix, TAG_MkPair, 2, (V[]){v_x_2454, v_s_243});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esimplify_2etrySpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etrySpec(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      return heff_strEq(v_g_240, heff_dup(v_h_249));
    }
    case TAG_ELam: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2estillCall(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2efieldIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efieldIn_entry, 2, 0};

V g_heff_2esimplify_2efieldIn(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_k_244), heff_dup(v_l_240));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_l_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      }
      case TAG_False: {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2efieldIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2efieldIn(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2eknownField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eknownField_entry, 3, 0};

V g_heff_2esimplify_2eknownField(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
  V v_it_244 = ({ V a_0 = v_g_240; V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_244, 0);
    V v_ru_24it_244_24Just = heff_take_reuse_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_EVar: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELam: {
      V v_ru_24it1_245_24ELam = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EApp: {
      V v_ru_24it1_245_24EApp = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_245, 0ULL, 3);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      V v_t_2416 = ({ V a_0 = v_l_241; V a_1 = v_fs_2415; V r_ = (g_heff_2esimplify_2efieldIn(a_0, a_1)); heff_drop(v_fs_2415); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24it_244_24Just, 1);
        return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
      }
      case TAG_Just: {
        V v_v_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        V v_t_2418 = (g_heff_2eir_2eisValue(v_v_2417));
        V v_t_2419;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          v_t_2419 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_242), LBL_fuel));
          break;
        }
        case TAG_False: {
          v_t_2419 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        switch (heff_tag_of(v_t_2419)) {
        case TAG_True: {
          V v_t_2420 = heff_intSub(heff_get(heff_dup(v_s_242), LBL_fuel), MK_INT(1LL));
          V v_s_2421 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), v_t_2420, heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
          V v_x2_2422 = (g_heff_2eir_2efreshGo_24s1749472566x1664180022(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_2421), LBL_supply), v_v_2417));
          V v_x2_2426;
          switch (heff_tag_of(v_x2_2422)) {
          case TAG_MkPair: {
            V v_e_27_2423 = heff_field(v_x2_2422, 0);
            V v_n_2424 = heff_field(v_x2_2422, 1);
            V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
            V v_t_2425 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n_2424, heff_get(heff_dup(v_s_2421), LBL_fuel), heff_get(heff_dup(v_s_2421), LBL_defs), heff_get(heff_dup(v_s_2421), LBL_safe), heff_get(heff_dup(v_s_2421), LBL_total), heff_get(heff_dup(v_s_2421), LBL_plain), heff_get(v_s_2421, LBL_sp)});
            v_x2_2426 = heff_tag_at(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_2423, v_t_2425});
            break;
          }
          default: heff_nomatch(v_x2_2422);
          }
          switch (heff_tag_of(v_x2_2426)) {
          case TAG_MkPair: {
            V v_x_2427 = heff_field(v_x2_2426, 0);
            V v_s_2428 = heff_field(v_x2_2426, 1);
            V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
            return heff_tag_at(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24it_244_24Just, TAG_Just, 1, (V[]){v_x_2427}), v_s_2428});
          }
          default: return heff_nomatch(v_x2_2426);
          }
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24it_244_24Just, 1);
          heff_drop(v_v_2417);
          return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
        }
        default: return heff_nomatch(v_t_2419);
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_EProj: {
      V v_ru_24it1_245_24EProj = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EProj, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ETag: {
      V v_ru_24it1_245_24ETag = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EMatch: {
      V v_ru_24it1_245_24EMatch = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_245_24EPrimCall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ECall: {
      V v_ru_24it1_245_24ECall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFixed: {
      V v_ru_24it1_245_24EFixed = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFix: {
      V v_ru_24it1_245_24EFix = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esimplify_2eknownField_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eknownField(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2eapplyToF_lam0(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam1(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam2(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam3(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam4(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam5(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam6(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam8(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam7(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam9(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam10(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam11(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam12(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam13(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam14(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam15(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam16(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam17(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam18(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam19(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam20(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam21(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam22(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam23(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam24(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam25(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam26(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam28(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam27(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam29(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam30(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam31(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam32(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam33(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam34(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam35(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam36(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam37(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam38(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam39(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam40(V self, V *args);
Clo g_heff_2esimplify_2eapplyToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eapplyToF_entry, 3, 0};

V g_heff_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_as_242) {
top: ;
  V v_t_243 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_242));
  V v_t_244 = heff_intEq(v_t_243, MK_INT(0LL));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_as_242);
    return heff_clo(g_heff_2esimplify_2eapplyToF_lam0, 1, 1, (V[]){v_f_241});
  }
  case TAG_False: {
    switch (heff_tag_of(v_f_241)) {
    case TAG_EVar: {
      heff_drop(v_r_240);
      V v_x_247 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam1, 1, 1, (V[]){v_x_247});
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_dup(heff_field(v_f_241, 0));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam2, 1, 4, (V[]){v_g_249, v_r_240, v_f_241, v_as_242});
    }
    case TAG_ELam: {
      V v_xs_2417 = heff_field(v_f_241, 0);
      V v_it2_2418 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24ELam = heff_take_reuse_n(v_f_241, 3ULL, 2);
      switch (heff_tag_of(v_it2_2418)) {
      case TAG_EVar: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EGlobal: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELam: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EApp: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELet: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ERecord: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EProj: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ETag: {
        V v_t_2431 = heff_field(v_it2_2418, 0);
        V v_es_2432 = heff_field(v_it2_2418, 1);
        heff_take_n(v_it2_2418, 3ULL, 2);
        V v_t_2433 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
        V v_t_2434 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_242));
        V v_t_2435 = heff_intEq(v_t_2433, v_t_2434);
        switch (heff_tag_of(v_t_2435)) {
        case TAG_True: {
          V v_t_2436 = (g_heff_2esimplify_2evarsAre(v_xs_2417, v_es_2432));
          switch (heff_tag_of(v_t_2436)) {
          case TAG_True: {
            heff_drop(v_r_240);
            heff_drop(v_xs_2417);
            heff_drop_cell(v_ru_24f_241_24ELam, 2);
            heff_drop(v_es_2432);
            return heff_clo(g_heff_2esimplify_2eapplyToF_lam3, 1, 2, (V[]){v_t_2431, v_as_242});
          }
          case TAG_False: {
            return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2431, v_es_2432}), v_as_242));
          }
          default: return heff_nomatch(v_t_2436);
          }
        }
        case TAG_False: {
          return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2431, v_es_2432}), v_as_242));
        }
        default: return heff_nomatch(v_t_2435);
        }
      }
      case TAG_EMatch: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrim: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrimCall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ECall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EInt: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EStr: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFixed: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat32: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFix: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      default: return heff_nomatch(v_it2_2418);
      }
    }
    case TAG_EApp: {
      V v_g_2453 = heff_field(v_f_241, 0);
      V v_bs_2454 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      V v_t_2455 = (g_heff_2esimplify_2eappendL(v_bs_2454, v_as_242));
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_g_2453, v_t_2455});
    }
    case TAG_ELet: {
      V v_x_2456 = heff_field(v_f_241, 0);
      V v_a_2457 = heff_field(v_f_241, 1);
      V v_b_2458 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_2459 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2458, v_as_242}));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam4, 1, 3, (V[]){v_m_2459, v_x_2456, v_a_2457});
    }
    case TAG_ERecord: {
      heff_drop(v_r_240);
      V v_x_2465 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam5, 1, 1, (V[]){v_x_2465});
    }
    case TAG_EProj: {
      V v_it1_2467 = heff_dup(heff_field(v_f_241, 0));
      V v_l_2468 = heff_dup(heff_field(v_f_241, 1));
      switch (heff_tag_of(v_it1_2467)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2467, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_2470 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam6, 1, 1, (V[]){v_x_2470});
      }
      case TAG_EGlobal: {
        V v_g_2472 = heff_field(v_it1_2467, 0);
        heff_take_n(v_it1_2467, 1ULL, 1);
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam7, 1, 5, (V[]){v_g_2472, v_l_2468, v_f_241, v_as_242, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_2493 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam9, 1, 1, (V[]){v_x_2493});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_2497 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam10, 1, 1, (V[]){v_x_2497});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2467, 0ULL, 3);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24102 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam11, 1, 1, (V[]){v_x_24102});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2467, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24105 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam12, 1, 1, (V[]){v_x_24105});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24109 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam13, 1, 1, (V[]){v_x_24109});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24113 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam14, 1, 1, (V[]){v_x_24113});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24117 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam15, 1, 1, (V[]){v_x_24117});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2467, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24120 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam16, 1, 1, (V[]){v_x_24120});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24124 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam17, 1, 1, (V[]){v_x_24124});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24128 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam18, 1, 1, (V[]){v_x_24128});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2467, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24131 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam19, 1, 1, (V[]){v_x_24131});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2467, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24134 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam20, 1, 1, (V[]){v_x_24134});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2467, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24137 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam21, 1, 1, (V[]){v_x_24137});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24141 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam22, 1, 1, (V[]){v_x_24141});
      }
      case TAG_EFloat32: {
        heff_take_n(v_it1_2467, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24144 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam23, 1, 1, (V[]){v_x_24144});
      }
      case TAG_EAbandon: {
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24146 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam24, 1, 1, (V[]){v_x_24146});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2467, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2468);
        V v_x_24150 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam25, 1, 1, (V[]){v_x_24150});
      }
      default: return heff_nomatch(v_it1_2467);
      }
    }
    case TAG_ETag: {
      heff_drop(v_r_240);
      V v_x_24154 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam26, 1, 1, (V[]){v_x_24154});
    }
    case TAG_EMatch: {
      V v_s_24156 = heff_field(v_f_241, 0);
      V v_arms_24157 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24EMatch = heff_take_reuse_n(v_f_241, 3ULL, 2);
      V v_t_24158 = (g_prelude_2emap_24s1645030849x525483621(heff_dup(v_as_242)));
      V v_t_24159 = ({ V a_0 = v_t_24158; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_24158); r_; });
      switch (heff_tag_of(v_t_24159)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24f_241_24EMatch, 2);
        V v_m_24169 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2eapplyToF_lam27, 1, 2, (V[]){v_r_240, v_as_242}), v_arms_24157));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam29, 1, 2, (V[]){v_m_24169, v_s_24156});
      }
      case TAG_False: {
        heff_drop(v_r_240);
        V v_x_24174 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24f_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_24156, v_arms_24157}), v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam30, 1, 1, (V[]){v_x_24174});
      }
      default: return heff_nomatch(v_t_24159);
      }
    }
    case TAG_EPrim: {
      heff_drop(v_r_240);
      V v_x_24177 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam31, 1, 1, (V[]){v_x_24177});
    }
    case TAG_EPrimCall: {
      heff_drop(v_r_240);
      V v_x_24181 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam32, 1, 1, (V[]){v_x_24181});
    }
    case TAG_ECall: {
      heff_drop(v_r_240);
      V v_x_24185 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam33, 1, 1, (V[]){v_x_24185});
    }
    case TAG_EInt: {
      heff_drop(v_r_240);
      V v_x_24188 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam34, 1, 1, (V[]){v_x_24188});
    }
    case TAG_EFloat: {
      heff_drop(v_r_240);
      V v_x_24191 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam35, 1, 1, (V[]){v_x_24191});
    }
    case TAG_EStr: {
      heff_drop(v_r_240);
      V v_x_24194 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam36, 1, 1, (V[]){v_x_24194});
    }
    case TAG_EFixed: {
      heff_drop(v_r_240);
      V v_x_24198 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam37, 1, 1, (V[]){v_x_24198});
    }
    case TAG_EFloat32: {
      heff_drop(v_r_240);
      V v_x_24201 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam38, 1, 1, (V[]){v_x_24201});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_24203 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam39, 1, 1, (V[]){v_x_24203});
    }
    case TAG_EFix: {
      heff_drop(v_r_240);
      V v_x_24207 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam40, 1, 1, (V[]){v_x_24207});
    }
    default: return heff_nomatch(v_f_241);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esimplify_2eapplyToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eapplyToF(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2eapplyToF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_f_241, v_s_245});
}
V g_heff_2esimplify_2eapplyToF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2esimplify_2eapplyToF_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = heff_dup(v_g_249); V b_1 = heff_get(heff_dup(v_s_2410), LBL_defs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_m_2412 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_f_241; V a_2 = heff_dup(v_g_249); V a_3 = heff_dup(v_as_242); V a_4 = v_t_2411; V r_ = heff_tr(g_heff_2esimplify_2ecallOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); r_; });
  V v_x2_2413 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2esimplify_2estillCall(heff_dup(v_g_249), v_x_2414));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_x_2414);
      heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
      return (g_heff_2esimplify_2etrySpec(v_r_240, v_g_249, v_as_242, v_s_2415));
    }
    case TAG_False: {
      heff_drop(v_g_249);
      heff_drop(v_r_240);
      heff_drop(v_as_242);
      return heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2esimplify_2eapplyToF_lam3(V self, V *args) {
  V v_s_2437 = args[0];
  V v_t_2431 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2431, v_as_242}), v_s_2437});
}
V g_heff_2esimplify_2eapplyToF_lam4(V self, V *args) {
  V v_s_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_x_2456 = heff_env(self)[1];
  V v_a_2457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2461 = heff_tr(heff_apply(v_m_2459, 1, (V[]){v_s_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_s_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2456, v_a_2457, v_x_2462}), v_s_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2esimplify_2eapplyToF_lam5(V self, V *args) {
  V v_s_2466 = args[0];
  V v_x_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2465, v_s_2466});
}
V g_heff_2esimplify_2eapplyToF_lam6(V self, V *args) {
  V v_s_2471 = args[0];
  V v_x_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2470, v_s_2471});
}
V g_heff_2esimplify_2eapplyToF_lam8(V self, V *args) {
  V v_s_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2488 = heff_tr(heff_apply(v_m_2486, 1, (V[]){v_s_2487}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_s_2490 = heff_field(v_x2_2488, 1);
    heff_take_n(v_x2_2488, 3ULL, 2);
    return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2489, v_as_242, v_s_2490});
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2esimplify_2eapplyToF_lam7(V self, V *args) {
  V v_s_2473 = args[0];
  V v_g_2472 = heff_env(self)[0];
  V v_l_2468 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2474 = (g_heff_2esimplify_2eknown(heff_dup(v_g_2472), v_s_2473));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_s_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    switch (heff_tag_of(v_x_2475)) {
    case TAG_Nothing: {
      V v_x2_2477 = (g_heff_2esimplify_2eknownField(v_g_2472, v_l_2468, v_s_2476));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        switch (heff_tag_of(v_x_2478)) {
        case TAG_Nothing: {
          heff_drop(v_r_240);
          V v_x_2480 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
          return heff_tag_at(v_ru_24x2_2474_24MkPair, TAG_MkPair, 2, (V[]){v_x_2480, v_s_2479});
        }
        case TAG_Just: {
          V v_v_2481 = heff_field(v_x_2478, 0);
          heff_take_n(v_x_2478, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2474_24MkPair, 2);
          V v_t_2482 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
          V v_t_2483 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_v_2481, v_as_242}));
          return (g_heff_2esimplify_2eattempt(v_t_2482, v_t_2483, v_s_2479));
        }
        default: return heff_nomatch(v_x_2478);
        }
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
    case TAG_Just: {
      V v_b_2484 = heff_field(v_x_2475, 0);
      heff_take_n(v_x_2475, 1ULL, 1);
      heff_drop(v_g_2472);
      heff_drop_cell(v_ru_24x2_2474_24MkPair, 2);
      V v_t_2485 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
      V v_m_2486 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_project), 2, (V[]){v_l_2468, v_b_2484}));
      return (g_heff_2esimplify_2eattempt(v_t_2485, heff_clo(g_heff_2esimplify_2eapplyToF_lam8, 1, 3, (V[]){v_m_2486, v_r_240, v_as_242}), v_s_2476));
    }
    default: return heff_nomatch(v_x_2475);
    }
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2esimplify_2eapplyToF_lam9(V self, V *args) {
  V v_s_2494 = args[0];
  V v_x_2493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2493, v_s_2494});
}
V g_heff_2esimplify_2eapplyToF_lam10(V self, V *args) {
  V v_s_2498 = args[0];
  V v_x_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2497, v_s_2498});
}
V g_heff_2esimplify_2eapplyToF_lam11(V self, V *args) {
  V v_s_24103 = args[0];
  V v_x_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24102, v_s_24103});
}
V g_heff_2esimplify_2eapplyToF_lam12(V self, V *args) {
  V v_s_24106 = args[0];
  V v_x_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24105, v_s_24106});
}
V g_heff_2esimplify_2eapplyToF_lam13(V self, V *args) {
  V v_s_24110 = args[0];
  V v_x_24109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24109, v_s_24110});
}
V g_heff_2esimplify_2eapplyToF_lam14(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x_24113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24113, v_s_24114});
}
V g_heff_2esimplify_2eapplyToF_lam15(V self, V *args) {
  V v_s_24118 = args[0];
  V v_x_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24117, v_s_24118});
}
V g_heff_2esimplify_2eapplyToF_lam16(V self, V *args) {
  V v_s_24121 = args[0];
  V v_x_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24120, v_s_24121});
}
V g_heff_2esimplify_2eapplyToF_lam17(V self, V *args) {
  V v_s_24125 = args[0];
  V v_x_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24124, v_s_24125});
}
V g_heff_2esimplify_2eapplyToF_lam18(V self, V *args) {
  V v_s_24129 = args[0];
  V v_x_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24128, v_s_24129});
}
V g_heff_2esimplify_2eapplyToF_lam19(V self, V *args) {
  V v_s_24132 = args[0];
  V v_x_24131 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24131, v_s_24132});
}
V g_heff_2esimplify_2eapplyToF_lam20(V self, V *args) {
  V v_s_24135 = args[0];
  V v_x_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24134, v_s_24135});
}
V g_heff_2esimplify_2eapplyToF_lam21(V self, V *args) {
  V v_s_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24137, v_s_24138});
}
V g_heff_2esimplify_2eapplyToF_lam22(V self, V *args) {
  V v_s_24142 = args[0];
  V v_x_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24141, v_s_24142});
}
V g_heff_2esimplify_2eapplyToF_lam23(V self, V *args) {
  V v_s_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24144, v_s_24145});
}
V g_heff_2esimplify_2eapplyToF_lam24(V self, V *args) {
  V v_s_24147 = args[0];
  V v_x_24146 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24146, v_s_24147});
}
V g_heff_2esimplify_2eapplyToF_lam25(V self, V *args) {
  V v_s_24151 = args[0];
  V v_x_24150 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24150, v_s_24151});
}
V g_heff_2esimplify_2eapplyToF_lam26(V self, V *args) {
  V v_s_24155 = args[0];
  V v_x_24154 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24154, v_s_24155});
}
V g_heff_2esimplify_2eapplyToF_lam28(V self, V *args) {
  V v_s_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  V v_t_24161 = heff_env(self)[1];
  V v_vs_24162 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24166 = heff_tr(heff_apply(v_m_24164, 1, (V[]){v_s_24165}));
  switch (heff_tag_of(v_x2_24166)) {
  case TAG_MkPair: {
    V v_x_24167 = heff_field(v_x2_24166, 0);
    V v_s_24168 = heff_field(v_x2_24166, 1);
    V v_ru_24x2_24166_24MkPair = heff_take_reuse_n(v_x2_24166, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_24161, v_vs_24162, v_x_24167}), v_s_24168});
  }
  default: return heff_nomatch(v_x2_24166);
  }
}
V g_heff_2esimplify_2eapplyToF_lam27(V self, V *args) {
  V v_a_24160 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24160)) {
  case TAG_MkArm: {
    V v_t_24161 = heff_field(v_a_24160, 0);
    V v_vs_24162 = heff_field(v_a_24160, 1);
    V v_b_24163 = heff_field(v_a_24160, 2);
    heff_take_n(v_a_24160, 7ULL, 3);
    V v_m_24164 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_24163, v_as_242}));
    return heff_clo(g_heff_2esimplify_2eapplyToF_lam28, 1, 3, (V[]){v_m_24164, v_t_24161, v_vs_24162});
  }
  default: return heff_nomatch(v_a_24160);
  }
}
V g_heff_2esimplify_2eapplyToF_lam29(V self, V *args) {
  V v_s_24170 = args[0];
  V v_m_24169 = heff_env(self)[0];
  V v_s_24156 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24171 = heff_tr(heff_apply(v_m_24169, 1, (V[]){v_s_24170}));
  switch (heff_tag_of(v_x2_24171)) {
  case TAG_MkPair: {
    V v_x_24172 = heff_field(v_x2_24171, 0);
    V v_s_24173 = heff_field(v_x2_24171, 1);
    V v_ru_24x2_24171_24MkPair = heff_take_reuse_n(v_x2_24171, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_24156, v_x_24172}), v_s_24173});
  }
  default: return heff_nomatch(v_x2_24171);
  }
}
V g_heff_2esimplify_2eapplyToF_lam30(V self, V *args) {
  V v_s_24175 = args[0];
  V v_x_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24174, v_s_24175});
}
V g_heff_2esimplify_2eapplyToF_lam31(V self, V *args) {
  V v_s_24178 = args[0];
  V v_x_24177 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24177, v_s_24178});
}
V g_heff_2esimplify_2eapplyToF_lam32(V self, V *args) {
  V v_s_24182 = args[0];
  V v_x_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24181, v_s_24182});
}
V g_heff_2esimplify_2eapplyToF_lam33(V self, V *args) {
  V v_s_24186 = args[0];
  V v_x_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24185, v_s_24186});
}
V g_heff_2esimplify_2eapplyToF_lam34(V self, V *args) {
  V v_s_24189 = args[0];
  V v_x_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24188, v_s_24189});
}
V g_heff_2esimplify_2eapplyToF_lam35(V self, V *args) {
  V v_s_24192 = args[0];
  V v_x_24191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24191, v_s_24192});
}
V g_heff_2esimplify_2eapplyToF_lam36(V self, V *args) {
  V v_s_24195 = args[0];
  V v_x_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24194, v_s_24195});
}
V g_heff_2esimplify_2eapplyToF_lam37(V self, V *args) {
  V v_s_24199 = args[0];
  V v_x_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24198, v_s_24199});
}
V g_heff_2esimplify_2eapplyToF_lam38(V self, V *args) {
  V v_s_24202 = args[0];
  V v_x_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24201, v_s_24202});
}
V g_heff_2esimplify_2eapplyToF_lam39(V self, V *args) {
  V v_s_24204 = args[0];
  V v_x_24203 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24203, v_s_24204});
}
V g_heff_2esimplify_2eapplyToF_lam40(V self, V *args) {
  V v_s_24208 = args[0];
  V v_x_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24207, v_s_24208});
}
Clo g_heff_2esimplify_2efindField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efindField_entry, 2, 0};

V g_heff_2esimplify_2efindField(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_k_244), heff_dup(v_l_240));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_l_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      }
      case TAG_False: {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2efindField_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2efindField(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return ((V)&g_heff_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_t_247 = heff_strEq(v_k_245, heff_dup(v_l_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_clo(g_heff_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, v_l_240, v_rest_244});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eothersPure(a[0], a[1]);
}
V g_heff_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = ({ V a_0 = v_f_246; V a_1 = v_s_248; V r_ = (g_heff_2esimplify_2eisPure(a_0, a_1)); heff_drop(v_f_246); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    switch (heff_tag_of(v_x_2410)) {
    case TAG_True: {
      heff_drop_cell(v_ru_24x2_249_24MkPair, 2);
      V v_t_2412 = (g_heff_2esimplify_2eothersPure(v_l_240, v_rest_244));
      V f_ = v_t_2412;
      args[0] = v_s_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      heff_drop(v_l_240);
      heff_drop(v_rest_244);
      return heff_tag_at(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2411});
    }
    default: return heff_nomatch(v_x_2410);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2esimplify_2eprojectF_lam0(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam1(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam2(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam3(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam4(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam5(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam6(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam7(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam8(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam9(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam10(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam11(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam12(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam13(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam14(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam15(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam16(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam17(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam18(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam19(V self, V *args);
Clo g_heff_2esimplify_2eprojectF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eprojectF_entry, 3, 0};

V g_heff_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam0, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_e_242, 0));
    return heff_clo(g_heff_2esimplify_2eprojectF_lam1, 1, 4, (V[]){v_g_245, v_e_242, v_l_241, v_r_240});
  }
  case TAG_ELam: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam2, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EApp: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam3, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_e_242, 0);
    V v_a_2419 = heff_field(v_e_242, 1);
    V v_b_2420 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2421 = heff_tr(heff_apply(heff_get(v_r_240, LBL_project), 2, (V[]){v_l_241, v_b_2420}));
    return heff_clo(g_heff_2esimplify_2eprojectF_lam4, 1, 3, (V[]){v_m_2421, v_x_2418, v_a_2419});
  }
  case TAG_ERecord: {
    V v_fs_2426 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2427 = (g_heff_2esimplify_2efindField(heff_dup(v_l_241), v_fs_2426));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nothing: {
      return heff_clo(g_heff_2esimplify_2eprojectF_lam5, 1, 2, (V[]){v_fs_2426, v_l_241});
    }
    case TAG_Just: {
      V v_v_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      V v_m_2431 = (g_heff_2esimplify_2eothersPure(heff_dup(v_l_241), heff_dup(v_fs_2426)));
      return heff_clo(g_heff_2esimplify_2eprojectF_lam6, 1, 4, (V[]){v_m_2431, v_v_2430, v_fs_2426, v_l_241});
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_EProj: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam7, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_ETag: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam8, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EMatch: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam9, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EPrim: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam10, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EPrimCall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam11, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_ECall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam12, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EInt: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam13, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EFloat: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam14, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EStr: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam15, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EFixed: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam16, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam17, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam18, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EFix: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam19, 1, 2, (V[]){v_e_242, v_l_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esimplify_2eprojectF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eprojectF(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2eprojectF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_244});
}
V g_heff_2esimplify_2eprojectF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = (g_heff_2esimplify_2eknown(v_g_245, v_s_246));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_249});
    }
    case TAG_Just: {
      V v_b_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      V v_t_2411 = heff_tr(heff_apply(heff_get(v_r_240, LBL_project), 2, (V[]){heff_dup(v_l_241), v_b_2410}));
      return (g_heff_2esimplify_2eattempt(heff_tag_at(v_ru_24x2_247_24MkPair, TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_t_2411, v_s_249));
    }
    default: return heff_nomatch(v_x_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2esimplify_2eprojectF_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2414});
}
V g_heff_2esimplify_2eprojectF_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2417});
}
V g_heff_2esimplify_2eprojectF_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_a_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2423 = heff_tr(heff_apply(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2418, v_a_2419, v_x_2424}), v_s_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2esimplify_2eprojectF_lam5(V self, V *args) {
  V v_s_2428 = args[0];
  V v_fs_2426 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = heff_tag(TAG_EProj, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_fs_2426}), v_l_241});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2429, v_s_2428});
}
V g_heff_2esimplify_2eprojectF_lam6(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_v_2430 = heff_env(self)[1];
  V v_fs_2426 = heff_env(self)[2];
  V v_l_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_apply(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_x_2436;
    switch (heff_tag_of(v_x_2434)) {
    case TAG_True: {
      heff_drop(v_fs_2426);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24x2_2433_24MkPair, 2);
      v_x_2436 = v_v_2430;
      break;
    }
    case TAG_False: {
      heff_drop(v_v_2430);
      v_x_2436 = heff_tag_at(v_ru_24x2_2433_24MkPair, TAG_EProj, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_fs_2426}), v_l_241});
      break;
    }
    default: heff_nomatch(v_x_2434);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2436, v_s_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2esimplify_2eprojectF_lam7(V self, V *args) {
  V v_s_2439 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2439});
}
V g_heff_2esimplify_2eprojectF_lam8(V self, V *args) {
  V v_s_2442 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2442});
}
V g_heff_2esimplify_2eprojectF_lam9(V self, V *args) {
  V v_s_2445 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2445});
}
V g_heff_2esimplify_2eprojectF_lam10(V self, V *args) {
  V v_s_2447 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2447});
}
V g_heff_2esimplify_2eprojectF_lam11(V self, V *args) {
  V v_s_2450 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2450});
}
V g_heff_2esimplify_2eprojectF_lam12(V self, V *args) {
  V v_s_2453 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2453});
}
V g_heff_2esimplify_2eprojectF_lam13(V self, V *args) {
  V v_s_2455 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2455});
}
V g_heff_2esimplify_2eprojectF_lam14(V self, V *args) {
  V v_s_2457 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2457});
}
V g_heff_2esimplify_2eprojectF_lam15(V self, V *args) {
  V v_s_2459 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2459});
}
V g_heff_2esimplify_2eprojectF_lam16(V self, V *args) {
  V v_s_2462 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2462});
}
V g_heff_2esimplify_2eprojectF_lam17(V self, V *args) {
  V v_s_2464 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2464});
}
V g_heff_2esimplify_2eprojectF_lam18(V self, V *args) {
  V v_s_2465 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2465});
}
V g_heff_2esimplify_2eprojectF_lam19(V self, V *args) {
  V v_s_2468 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2468});
}
Clo g_heff_2esimplify_2efindArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efindArm_entry, 2, 0};

V g_heff_2esimplify_2efindArm(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      V v_t_247 = heff_strEq(heff_dup(v_t2_244), heff_dup(v_t_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkArm, 3, (V[]){heff_dup(v_t2_244), heff_dup(v_vs_245), heff_dup(v_b_246)})});
      }
      case TAG_False: {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2efindArm_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2efindArm(a[0], a[1]); heff_drop(a[1]); return r;
}

static V g_heff_2esimplify_2ecaseBudget_val;
static int g_heff_2esimplify_2ecaseBudget_st;
static V g_heff_2esimplify_2ecaseBudget_init(void) {
  return MK_INT(40LL);
}
V g_heff_2esimplify_2ecaseBudget_get(void) {
  if (g_heff_2esimplify_2ecaseBudget_st == 2) return g_heff_2esimplify_2ecaseBudget_val;
  if (g_heff_2esimplify_2ecaseBudget_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2ecaseBudget_st = 1;
  g_heff_2esimplify_2ecaseBudget_val = heff_tr(g_heff_2esimplify_2ecaseBudget_init());
  g_heff_2esimplify_2ecaseBudget_st = 2;
  return g_heff_2esimplify_2ecaseBudget_val;
}
Clo g_heff_2esimplify_2epushArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epushArm_entry, 4, 0};

V g_heff_2esimplify_2epushArm(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    V v_x2_248 = (g_heff_2eir_2efreshGo_24s1749472566x1664180022(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_p_243), LBL_supply), v_t_247));
    V v_x2_2412;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_e_27_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2411 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n_2410, heff_get(heff_dup(v_p_243), LBL_fuel), heff_get(heff_dup(v_p_243), LBL_defs), heff_get(heff_dup(v_p_243), LBL_safe), heff_get(heff_dup(v_p_243), LBL_total), heff_get(heff_dup(v_p_243), LBL_plain), heff_get(v_p_243, LBL_sp)});
      v_x2_2412 = heff_tag_at(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_249, v_t_2411});
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_t_2444;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_EVar: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_2413, 0ULL, 3);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2430 = heff_field(v_x_2413, 1);
        heff_take_n(v_x_2413, 2ULL, 2);
        v_t_2444 = v_arms_2430;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_m_2445 = heff_tr(heff_apply(heff_get(v_r_240, LBL_match), 2, (V[]){v_b_246, v_t_2444}));
      V v_x2_2446 = heff_tr(heff_apply(v_m_2445, 1, (V[]){v_s_2414}));
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_MkPair: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_s_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2447}), v_s_2448});
      }
      default: return heff_nomatch(v_x2_2446);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2epushArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2epushArm(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2ecaseOfCase_lam0(V self, V *args);
V g_heff_2esimplify_2ecaseOfCase_lam1(V self, V *args);
V g_heff_2esimplify_2ecaseOfCase_lam2(V self, V *args);
Clo g_heff_2esimplify_2ecaseOfCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ecaseOfCase_entry, 4, 0};

V g_heff_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_prelude_2eany_24s438096394x623120595(v_arms2_242));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = heff_tag(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), heff_dup(v_arms_243)});
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_t_248 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_arms2_242));
    V v_t_249 = heff_intMul(v_t_247, heff_intSub(v_t_248, MK_INT(1LL)));
    V v_t_2410 = heff_intLe(v_t_249, heff_dup(g_heff_2esimplify_2ecaseBudget_get()));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2epushArm_clo), 2, (V[]){v_r_240, v_arms_243}));
      V v_m_2412 = (g_heff_2esimplify_2etraverseS(v_t_2411, v_arms2_242));
      return heff_clo(g_heff_2esimplify_2ecaseOfCase_lam0, 1, 2, (V[]){v_m_2412, v_s2_241});
    }
    case TAG_False: {
      heff_drop(v_r_240);
      return heff_clo(g_heff_2esimplify_2ecaseOfCase_lam1, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_False: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ecaseOfCase_lam2, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esimplify_2ecaseOfCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ecaseOfCase(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2ecaseOfCase_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_s2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s2_241, v_x_2415}), v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2esimplify_2ecaseOfCase_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag(TAG_EMatch, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2417});
}
V g_heff_2esimplify_2ecaseOfCase_lam2(V self, V *args) {
  V v_s_2419 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag(TAG_EMatch, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2420, v_s_2419});
}
V g_heff_2esimplify_2ematchF_lam0(V self, V *args);
V g_heff_2esimplify_2ematchF_lam1(V self, V *args);
V g_heff_2esimplify_2ematchF_lam2(V self, V *args);
V g_heff_2esimplify_2ematchF_lam3(V self, V *args);
V g_heff_2esimplify_2ematchF_lam4(V self, V *args);
V g_heff_2esimplify_2ematchF_lam5(V self, V *args);
V g_heff_2esimplify_2ematchF_lam6(V self, V *args);
V g_heff_2esimplify_2ematchF_lam7(V self, V *args);
V g_heff_2esimplify_2ematchF_lam8(V self, V *args);
V g_heff_2esimplify_2ematchF_lam9(V self, V *args);
V g_heff_2esimplify_2ematchF_lam10(V self, V *args);
V g_heff_2esimplify_2ematchF_lam11(V self, V *args);
V g_heff_2esimplify_2ematchF_lam12(V self, V *args);
V g_heff_2esimplify_2ematchF_lam13(V self, V *args);
V g_heff_2esimplify_2ematchF_lam14(V self, V *args);
V g_heff_2esimplify_2ematchF_lam15(V self, V *args);
V g_heff_2esimplify_2ematchF_lam16(V self, V *args);
V g_heff_2esimplify_2ematchF_lam17(V self, V *args);
Clo g_heff_2esimplify_2ematchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ematchF_entry, 3, 0};

V g_heff_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam0, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_s_241, 0));
    return heff_clo(g_heff_2esimplify_2ematchF_lam1, 1, 4, (V[]){v_g_245, v_s_241, v_arms_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam2, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EApp: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam3, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ELet: {
    V v_x_2446 = heff_field(v_s_241, 0);
    V v_a_2447 = heff_field(v_s_241, 1);
    V v_b_2448 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_2449 = heff_tr(heff_apply(heff_get(v_r_240, LBL_match), 2, (V[]){v_b_2448, v_arms_242}));
    return heff_clo(g_heff_2esimplify_2ematchF_lam4, 1, 3, (V[]){v_m_2449, v_x_2446, v_a_2447});
  }
  case TAG_ERecord: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam5, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EProj: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam6, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ETag: {
    V v_t_2459 = heff_dup(heff_field(v_s_241, 0));
    V v_as_2460 = heff_dup(heff_field(v_s_241, 1));
    V v_it_2461 = (g_heff_2esimplify_2efindArm(v_t_2459, v_arms_242));
    switch (heff_tag_of(v_it_2461)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      heff_drop(v_as_2460);
      return heff_clo(g_heff_2esimplify_2ematchF_lam7, 1, 2, (V[]){v_s_241, v_arms_242});
    }
    case TAG_Just: {
      V v_it1_2463 = heff_field(v_it_2461, 0);
      heff_take_n(v_it_2461, 1ULL, 1);
      heff_drop_tag(v_s_241, 2);
      heff_drop(v_arms_242);
      switch (heff_tag_of(v_it1_2463)) {
      case TAG_MkArm: {
        V v_vs_2465 = heff_field(v_it1_2463, 1);
        V v_b_2466 = heff_field(v_it1_2463, 2);
        heff_take_n(v_it1_2463, 6ULL, 3);
        V v_t_2467 = (g_heff_2esimplify_2ezipL(v_vs_2465, v_as_2460));
        V v_t_2468 = ({ V a_0 = v_t_2467; V a_1 = v_b_2466; V r_ = (g_heff_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2467); r_; });
        return heff_tail(heff_get(v_r_240, LBL_simp), 1, (V[]){v_t_2468});
      }
      default: return heff_nomatch(v_it1_2463);
      }
    }
    default: return heff_nomatch(v_it_2461);
    }
  }
  case TAG_EMatch: {
    V v_s2_2469 = heff_field(v_s_241, 0);
    V v_arms2_2470 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 3ULL, 2);
    return (g_heff_2esimplify_2ecaseOfCase(v_r_240, v_s2_2469, v_arms2_2470, v_arms_242));
  }
  case TAG_EPrim: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam8, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EPrimCall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam9, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ECall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam10, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EInt: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam11, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam12, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EStr: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam13, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFixed: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam14, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam15, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam16, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFix: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam17, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2esimplify_2ematchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ematchF(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2ematchF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_244});
}
V g_heff_2esimplify_2ematchF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = (g_heff_2esimplify_2eknown(v_g_245, v_s_246));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
    }
    case TAG_Just: {
      V v_it1_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2410, 0ULL, 3);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ETag: {
        V v_t2_2423 = heff_field(v_it1_2410, 0);
        V v_as2_2424 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        heff_drop_tag(v_s_241, 1);
        heff_drop_cell(v_ru_24x2_247_24MkPair, 2);
        return heff_tail(heff_get(v_r_240, LBL_match), 3, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t2_2423, v_as2_2424}), v_arms_242, v_s_249});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFloat32: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EAbandon: {
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_x_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2esimplify_2ematchF_lam2(V self, V *args) {
  V v_s_2442 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2442});
}
V g_heff_2esimplify_2ematchF_lam3(V self, V *args) {
  V v_s_2445 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2445});
}
V g_heff_2esimplify_2ematchF_lam4(V self, V *args) {
  V v_s_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_x_2446 = heff_env(self)[1];
  V v_a_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2451 = heff_tr(heff_apply(v_m_2449, 1, (V[]){v_s_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_s_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2446, v_a_2447, v_x_2452}), v_s_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2esimplify_2ematchF_lam5(V self, V *args) {
  V v_s_2455 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2455});
}
V g_heff_2esimplify_2ematchF_lam6(V self, V *args) {
  V v_s_2458 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2458});
}
V g_heff_2esimplify_2ematchF_lam7(V self, V *args) {
  V v_s_2462 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2462});
}
V g_heff_2esimplify_2ematchF_lam8(V self, V *args) {
  V v_s_2472 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2472});
}
V g_heff_2esimplify_2ematchF_lam9(V self, V *args) {
  V v_s_2475 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2475});
}
V g_heff_2esimplify_2ematchF_lam10(V self, V *args) {
  V v_s_2478 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2478});
}
V g_heff_2esimplify_2ematchF_lam11(V self, V *args) {
  V v_s_2480 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2480});
}
V g_heff_2esimplify_2ematchF_lam12(V self, V *args) {
  V v_s_2482 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2482});
}
V g_heff_2esimplify_2ematchF_lam13(V self, V *args) {
  V v_s_2484 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2484});
}
V g_heff_2esimplify_2ematchF_lam14(V self, V *args) {
  V v_s_2487 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2487});
}
V g_heff_2esimplify_2ematchF_lam15(V self, V *args) {
  V v_s_2489 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2489});
}
V g_heff_2esimplify_2ematchF_lam16(V self, V *args) {
  V v_s_2490 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2490});
}
V g_heff_2esimplify_2ematchF_lam17(V self, V *args) {
  V v_s_2493 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2493});
}
V g_heff_2esimplify_2esk_lam0(V self, V *args); static Clo g_heff_2esimplify_2esk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam0, 1, 0};
V g_heff_2esimplify_2esk_lam1(V self, V *args); static Clo g_heff_2esimplify_2esk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam1, 2, 0};
V g_heff_2esimplify_2esk_lam2(V self, V *args); static Clo g_heff_2esimplify_2esk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam2, 2, 0};
V g_heff_2esimplify_2esk_lam3(V self, V *args); static Clo g_heff_2esimplify_2esk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam3, 2, 0};

static V g_heff_2esimplify_2esk_val;
static int g_heff_2esimplify_2esk_st;
static V g_heff_2esimplify_2esk_init(void) {
  return heff_rec(4, shape_simp__applyTo__project__match, (V[]){((V)&g_heff_2esimplify_2esk_lam0_clo), ((V)&g_heff_2esimplify_2esk_lam1_clo), ((V)&g_heff_2esimplify_2esk_lam2_clo), ((V)&g_heff_2esimplify_2esk_lam3_clo)});
}
V g_heff_2esimplify_2esk_get(void) {
  if (g_heff_2esimplify_2esk_st == 2) return g_heff_2esimplify_2esk_val;
  if (g_heff_2esimplify_2esk_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2esk_st = 1;
  g_heff_2esimplify_2esk_val = heff_tr(g_heff_2esimplify_2esk_init());
  g_heff_2esimplify_2esk_st = 2;
  return g_heff_2esimplify_2esk_val;
}
V g_heff_2esimplify_2esk_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), v_e_240));
}
V g_heff_2esimplify_2esk_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_as_242 = args[1];
  return (g_heff_2esimplify_2eapplyToF(heff_dup(g_heff_2esimplify_2esk_get()), v_f_241, v_as_242));
}
V g_heff_2esimplify_2esk_lam2(V self, V *args) {
  V v_l_243 = args[0];
  V v_e_244 = args[1];
  return (g_heff_2esimplify_2eprojectF(heff_dup(g_heff_2esimplify_2esk_get()), v_l_243, v_e_244));
}
V g_heff_2esimplify_2esk_lam3(V self, V *args) {
  V v_s_245 = args[0];
  V v_arms_246 = args[1];
  return (g_heff_2esimplify_2ematchF(heff_dup(g_heff_2esimplify_2esk_get()), v_s_245, v_arms_246));
}
Clo g_heff_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_a_244 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_243));
  V v_x1_245 = heff_intLt(heff_dup(g_heff_2esimplify_2especBodySize_get()), v_a_244);
  V v_t_247;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    v_t_247 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
    break;
  }
  case TAG_False: {
    V v_t_246 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
    v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), v_t_246));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_t_2437;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2439;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    V v_t_2438 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
    v_t_2439 = (g_map_2einsert_24s1341440536x470972936(v_key_240, NTAG(TAG_MkUnit), v_t_2438));
    break;
  }
  case TAG_False: {
    heff_drop(v_key_240);
    v_t_2439 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_t_2440 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_recipes);
  V v_t_2441 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_depths);
  V v_t_2442 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_made);
  V v_t_2443 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_count);
  V v_t_2444 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_off);
  V v_p_2445 = heff_rec(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_247, v_t_2439, v_t_2440, v_t_2441, v_t_2442, v_t_2443, v_t_2444});
  return heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(v_s_242, LBL_plain), v_p_2445});
}
V g_heff_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2erecordDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2erecordDef_entry, 3, 0};

V g_heff_2esimplify_2erecordDef(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_t_244 = (g_heff_2eir_2enubI(v_t_243));
  V v_t_245 = ({ V a_0 = heff_dup(v_key_240); V a_1 = v_t_244; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_247 = v_s_242;
    break;
  }
  case TAG_False: {
    V v_d_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), heff_get(heff_dup(v_s_242), LBL_defs)));
    v_t_247 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), v_d_246, heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), (g_heff_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_247))});
}
V g_heff_2esimplify_2erecordDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2erecordDef(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2emadeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emadeOne_entry, 2, 0};

V g_heff_2esimplify_2emadeOne(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_all);
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_kinds);
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_recipes);
  V v_t_245 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_depths);
  V v_t_246 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_made);
  V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), v_t_246));
  V v_t_248 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_count);
  V v_t_249 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_off);
  V v_p_2410 = heff_rec(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_247, v_t_248, v_t_249});
  V v_t_2411 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), heff_get(heff_dup(v_s_241), LBL_fuel), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(v_s_241, LBL_plain), v_p_2410});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2411});
}
V g_heff_2esimplify_2emadeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2emadeOne(a[0], a[1]);
}
Clo g_heff_2esimplify_2emakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emakeOne_entry, 4, 0};

V g_heff_2esimplify_2emakeOne(V v_more_240, V v_h_241, V v_b0_242, V v_s_243) {
top: ;
  V v_x2_244 = (g_heff_2esimplify_2emadeOne(heff_dup(v_h_241), v_s_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 2ULL, 2);
    V v_m_247 = (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), v_b0_242));
    V v_t_248 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_246), LBL_supply), MK_INT(4000LL), heff_get(heff_dup(v_s_246), LBL_defs), heff_get(heff_dup(v_s_246), LBL_safe), heff_get(heff_dup(v_s_246), LBL_total), heff_dup(g_map_2eempty_get()), heff_get(v_s_246, LBL_sp)});
    V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_t_248}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
      V v_m_2412 = (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), v_x_2410));
      V v_x2_2413 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2411}));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        V v_x2_2416 = (g_heff_2esimplify_2eraise(v_x_2414, v_s_2415));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          heff_take_n(v_x2_2416, 3ULL, 2);
          V v_t_2419 = (g_heff_2eir_2eglobalsGo(heff_dup(v_x_2417)));
          V v_t_2420 = (g_heff_2eir_2enubI(v_t_2419));
          V v_m_2421 = heff_tr(heff_apply(v_more_240, 1, (V[]){v_t_2420}));
          V v_x2_2422 = heff_tr(heff_apply(v_m_2421, 1, (V[]){v_s_2418}));
          switch (heff_tag_of(v_x2_2422)) {
          case TAG_MkPair: {
            V v_x_2423 = heff_field(v_x2_2422, 0);
            V v_s_2424 = heff_field(v_x2_2422, 1);
            heff_take_n(v_x2_2422, 3ULL, 2);
            V v_t_2425 = heff_tag_at(v_ru_24x2_244_24MkPair, TAG_Cons, 2, (V[]){heff_rec(3, shape_key__name__body, (V[]){heff_dup(v_h_241), v_h_241, v_x_2417}), NTAG(TAG_Nil)});
            V v_x_2426 = (g_heff_2esimplify_2eappendL(v_x_2423, v_t_2425));
            return heff_tag_at(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_s_2424});
          }
          default: return heff_nomatch(v_x2_2422);
          }
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2esimplify_2emakeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2emakeOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2emakeEach_lam0(V self, V *args); static Clo g_heff_2esimplify_2emakeEach_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emakeEach_lam0, 1, 0};
Clo g_heff_2esimplify_2emakeEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emakeEach_entry, 2, 0};

V g_heff_2esimplify_2emakeEach(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_h_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_get(heff_get(heff_dup(v_p_241), LBL_sp), LBL_made);
    V v_x3_245 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_x3_248;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = heff_get(heff_get(heff_dup(v_p_241), LBL_sp), LBL_recipes);
      v_x3_248 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      v_x3_248 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    V v_m_2411;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nothing: {
      heff_drop(v_h_242);
      v_m_2411 = ((V)&g_heff_2esimplify_2emakeEach_lam0_clo);
      break;
    }
    case TAG_Just: {
      V v_b0_2410 = heff_field(v_x3_248, 0);
      heff_take_n(v_x3_248, 1ULL, 1);
      v_m_2411 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2emakeOne_clo), 3, (V[]){((V)&g_heff_2esimplify_2emakeEach_clo), v_h_242, v_b0_2410}));
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    V v_x2_2412 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_p_241}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      V v_m_2415 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2emakeEach_clo), 1, (V[]){v_rest_243}));
      V v_x2_2416 = heff_tr(heff_apply(v_m_2415, 1, (V[]){v_s_2414}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        V v_x_2419 = (g_heff_2esimplify_2eappendL(v_x_2413, v_x_2417));
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2emakeEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2emakeEach(a[0], a[1]);
}
V g_heff_2esimplify_2emakeEach_lam0(V self, V *args) {
  V v_s_249 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_249});
}
Clo g_heff_2esimplify_2eoneDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eoneDef_entry, 2, 0};

V g_heff_2esimplify_2eoneDef(V v_d_240, V v_s_241) {
top: ;
  V v_m_242 = (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), heff_get(heff_dup(v_d_240), LBL_body)));
  V v_t_243 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), MK_INT(4000LL), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_dup(g_map_2eempty_get()), heff_get(v_s_241, LBL_sp)});
  V v_x2_244 = heff_tr(heff_apply(v_m_242, 1, (V[]){v_t_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_m_247 = (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), v_x_245));
    V v_x2_248 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_s_246}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_x2_2411 = (g_heff_2esimplify_2eraise(v_x_249, v_s_2410));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_s_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        V v_x2_2414 = (g_heff_2esimplify_2erecordDef(heff_get(heff_dup(v_d_240), LBL_key), heff_dup(v_x_2412), v_s_2413));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 2ULL, 2);
          V v_x2_2417 = (g_heff_2esimplify_2emarkSafe(heff_get(heff_dup(v_d_240), LBL_key), v_x_2412, v_s_2416));
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_MkPair: {
            V v_s_2419 = heff_field(v_x2_2417, 1);
            heff_take_n(v_x2_2417, 2ULL, 2);
            V v_t_2420 = (g_heff_2eir_2eglobalsGo(heff_dup(v_x_2412)));
            V v_t_2421 = (g_heff_2eir_2enubI(v_t_2420));
            V v_m_2422 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2emakeEach_clo), 1, (V[]){v_t_2421}));
            V v_x2_2423 = heff_tr(heff_apply(v_m_2422, 1, (V[]){v_s_2419}));
            switch (heff_tag_of(v_x2_2423)) {
            case TAG_MkPair: {
              V v_x_2424 = heff_field(v_x2_2423, 0);
              V v_s_2425 = heff_field(v_x2_2423, 1);
              heff_take_n(v_x2_2423, 3ULL, 2);
              V v_t_2426 = heff_rec(3, shape_key__name__body, (V[]){heff_get(heff_dup(v_d_240), LBL_key), heff_get(v_d_240, LBL_name), v_x_2412});
              V v_t_2427 = heff_tag_at(v_ru_24x2_244_24MkPair, TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
              V v_x_2428 = (g_heff_2esimplify_2eappendL(v_x_2424, v_t_2427));
              return heff_tag_at(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2425});
            }
            default: return heff_nomatch(v_x2_2423);
            }
          }
          default: return heff_nomatch(v_x2_2417);
          }
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2esimplify_2eoneDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eoneDef(a[0], a[1]);
}
Clo g_heff_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2esimplify_2econcatDefs(v_rest_242));
    return (g_heff_2esimplify_2eappendL(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2econcatDefs(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2esimplify_2etraverseS_24s1959824798x755618522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etraverseS_24s1959824798x755618522_entry, 2, 0};

V g_heff_2esimplify_2etraverseS_24s1959824798x755618522(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2esimplify_2eoneDef(v_x_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      V v_x2_247 = (g_heff_2esimplify_2etraverseS_24s1959824798x755618522(v_xs_243, v_s_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_245, v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esimplify_2etraverseS_24s1959824798x755618522_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etraverseS_24s1959824798x755618522(a[0], a[1]);
}
Clo g_heff_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_prelude_2efoldl_24s1700457534x694272192(heff_rec(2, shape_safe__total, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}), v_defs_241));
  V v_t_243 = heff_rec(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_244 = heff_rec(7, shape_supply__fuel__defs__safe__total__plain__sp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_sg_242), LBL_safe), heff_get(v_sg_242, LBL_total), heff_dup(g_map_2eempty_get()), v_t_243});
  V v_x1_245 = (g_heff_2esimplify_2etraverseS_24s1959824798x755618522(v_defs_241, v_t_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_out_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    V v_t_248 = ({ V a_0 = v_out_246; V r_ = (g_heff_2esimplify_2econcatDefs(a_0)); heff_drop(v_out_246); r_; });
    return heff_rec(2, shape_defs__supply, (V[]){v_t_248, heff_get(v_st_247, LBL_supply)});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2esimplifyProgram(a[0], a[1]);
}