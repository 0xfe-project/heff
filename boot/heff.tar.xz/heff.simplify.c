// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_heff_2esimplify_2ebudget_val;
static int g_heff_2esimplify_2ebudget_st;
static V g_heff_2esimplify_2ebudget_init(void) {
  return MK_INT(24LL);
}
V g_heff_2esimplify_2ebudget_get(void) {
  if (g_heff_2esimplify_2ebudget_st == 2) return g_heff_2esimplify_2ebudget_val;
  if (g_heff_2esimplify_2ebudget_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2ebudget_st = 1;
  g_heff_2esimplify_2ebudget_val = heff_tr(g_heff_2esimplify_2ebudget_init());
  g_heff_2esimplify_2ebudget_st = 2;
  return g_heff_2esimplify_2ebudget_val;
}
V g_heff_2esimplify_2etraverseS_lam0(V self, V *args); static Clo g_heff_2esimplify_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etraverseS_lam0, 1, 0};
V g_heff_2esimplify_2etraverseS_lam1(V self, V *args);
Clo g_heff_2esimplify_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etraverseS_entry, 2, 0};

V g_heff_2esimplify_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2esimplify_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo(g_heff_2esimplify_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etraverseS(a[0], a[1]);
}
V g_heff_2esimplify_2etraverseS_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2esimplify_2etraverseS_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2esimplify_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_apply(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2esimplify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eappendL_entry, 2, 0};

V g_heff_2esimplify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2esimplify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eappendL(a[0], a[1]);
}
Clo g_heff_2esimplify_2eelemStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eelemStr_entry, 2, 0};

V g_heff_2esimplify_2eelemStr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eelemStr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eelemStr(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ezipL_entry, 2, 0};

V g_heff_2esimplify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2esimplify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ezipL(a[0], a[1]);
}
Clo g_heff_2esimplify_2etakeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etakeL_entry, 2, 0};

V g_heff_2esimplify_2etakeL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2esimplify_2etakeL(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2etakeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etakeL(a[0], a[1]);
}
Clo g_heff_2esimplify_2edropL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2edropL_entry, 2, 0};

V g_heff_2esimplify_2edropL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2edropL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2edropL(a[0], a[1]);
}
Clo g_heff_2esimplify_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eletsOf_entry, 2, 0};

V g_heff_2esimplify_2eletsOf(V v_x1_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_body_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      return heff_tag(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), (g_heff_2esimplify_2eletsOf(v_rest_243, v_body_241))});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2eletsOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eletsOf(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2esimplify_2eknown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eknown_entry, 2, 0};

V g_heff_2esimplify_2eknown(V v_g_240, V v_s_241) {
top: ;
  V v_t_242 = ({ V a_0 = v_g_240; V b_1 = heff_get(heff_dup(v_s_241), LBL_defs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_244 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_241), LBL_fuel));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_intSub(heff_get(heff_dup(v_s_241), LBL_fuel), MK_INT(1LL));
      V v_s_246 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), v_t_245, heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(heff_dup(v_s_241), LBL_plain), heff_get(v_s_241, LBL_sp)});
      V v_x2_247 = (g_heff_2eir_2efreshGo_24s504(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_246), LBL_supply), v_b_243));
      V v_x2_2411;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_e_27_248 = heff_field(v_x2_247, 0);
        V v_n_249 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        V v_t_2410 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n_249, heff_get(heff_dup(v_s_246), LBL_fuel), heff_get(heff_dup(v_s_246), LBL_defs), heff_get(heff_dup(v_s_246), LBL_safe), heff_get(heff_dup(v_s_246), LBL_total), heff_get(heff_dup(v_s_246), LBL_plain), heff_get(v_s_246, LBL_sp)});
        v_x2_2411 = heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_248, v_t_2410});
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_s_2413 = heff_field(v_x2_2411, 1);
        V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_x_2412}), v_s_2413});
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    case TAG_False: {
      heff_drop(v_b_243);
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esimplify_2eknown_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eknown(a[0], a[1]);
}
Clo g_heff_2esimplify_2etrying_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etrying_entry, 2, 0};

V g_heff_2esimplify_2etrying(V v_d_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_all);
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_kinds);
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_specs);
  V v_t_245 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_made);
  V v_t_246 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_count);
  V v_t_247 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_within);
  V v_t_248 = heff_get(heff_get(heff_dup(v_s_241), LBL_sp), LBL_trying);
  V v_t_249 = heff_rec(7, shape_5_155_316_184_52_375_350, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, heff_intAdd(v_t_248, v_d_240)});
  V v_t_2410 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), heff_get(heff_dup(v_s_241), LBL_fuel), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(v_s_241, LBL_plain), v_t_249});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2410});
}
V g_heff_2esimplify_2etrying_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etrying(a[0], a[1]);
}
Clo g_heff_2esimplify_2eattempt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eattempt_entry, 3, 0};

V g_heff_2esimplify_2eattempt(V v_orig_240, V v_m_241, V v_s_242) {
top: ;
  V v_x2_243 = (g_heff_2esimplify_2etrying(MK_INT(1LL), heff_dup(v_s_242)));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 2ULL, 2);
    V v_x2_246 = heff_tr(heff_apply(v_m_241, 1, (V[]){v_s_245}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      V v_x2_249 = (g_heff_2esimplify_2etrying(MK_INT(-1LL), v_s_248));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_s_2411 = heff_field(v_x2_249, 1);
        V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 2ULL, 2);
        V v_t_2412 = heff_tag_at(v_ru_24x2_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_orig_240), NTAG(TAG_Nil)});
        V v_t_2413 = (g_heff_2eir_2esizeW(MK_INT(0LL), v_t_2412));
        V v_lim_2414 = heff_intAdd(v_t_2413, heff_dup(g_heff_2esimplify_2ebudget_get()));
        V v_t_2415 = heff_tag_at(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_247), NTAG(TAG_Nil)});
        V v_a_2416 = (g_heff_2eir_2esizeB(heff_dup(v_lim_2414), MK_INT(0LL), v_t_2415));
        V v_x1_2417 = heff_intLt(v_lim_2414, v_a_2416);
        switch (heff_tag_of(v_x1_2417)) {
        case TAG_True: {
          heff_drop(v_x_247);
          V v_t_2418 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_2411), LBL_supply), heff_get(heff_dup(v_s_2411), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(v_s_242, LBL_total), heff_get(heff_dup(v_s_2411), LBL_plain), heff_get(v_s_2411, LBL_sp)});
          return heff_tag_at(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_orig_240, v_t_2418});
        }
        case TAG_False: {
          heff_drop(v_orig_240);
          heff_drop(v_s_242);
          return heff_tag_at(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_247, v_s_2411});
        }
        default: return heff_nomatch(v_x1_2417);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2esimplify_2eattempt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eattempt(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2esimplify_2efailing_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 101, 114, 102, 111, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2esimplify_2efailing_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 114, 97, 121, 83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2esimplify_2efailing_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2esimplify_2efailing_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 70, 108, 111, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2esimplify_2efailing_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 114, 114, 97, 121, 73, 110, 100, 101, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2efailing_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2efailing_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 111, 100}};

static V g_heff_2esimplify_2efailing_val;
static int g_heff_2esimplify_2efailing_st;
static V g_heff_2esimplify_2efailing_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str4), v_t_241})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2esimplify_2efailing_str6), v_t_242})});
}
V g_heff_2esimplify_2efailing_get(void) {
  if (g_heff_2esimplify_2efailing_st == 2) return g_heff_2esimplify_2efailing_val;
  if (g_heff_2esimplify_2efailing_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2efailing_st = 1;
  g_heff_2esimplify_2efailing_val = heff_tr(g_heff_2esimplify_2efailing_init());
  g_heff_2esimplify_2efailing_st = 2;
  return g_heff_2esimplify_2efailing_val;
}
V g_heff_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2esimplify_2epureIn_lam4(V self, V *args);
Clo g_heff_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_242, 0);
    V v_x3_245 = (g_map_2elookup_24s9(heff_dup(v_g_244), v_safe_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_it1_249 = heff_field(v_e_242, 0);
    V v_as_2410 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2412 = heff_field(v_it1_249, 0);
      V v_t_2413 = (g_map_2elookup_24s8(heff_dup(v_g_2412), v_total_241));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_ar_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_t_2415 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2410));
        V v_t_2416 = heff_intLe(v_t_2415, v_ar_2414);
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          V v_t_2418 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2410)));
          return ({ V a_0 = v_t_2418; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2418); r_; });
        }
        case TAG_False: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2446 = heff_field(v_e_242, 0);
    V v_t_2450 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_fs_2446)));
    return ({ V a_0 = v_t_2450; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2450); r_; });
  }
  case TAG_EProj: {
    V v_e2_2451 = heff_field(v_e_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_total_241;
    V t_2 = v_e2_2451;
    v_safe_240 = t_0;
    v_total_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2454 = heff_field(v_e_242, 1);
    V v_t_2456 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2454)));
    return ({ V a_0 = v_t_2456; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2456); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2460 = heff_field(v_e_242, 0);
    V v_as_2461 = heff_field(v_e_242, 1);
    V v_x1_2462 = ({ V a_0 = heff_dup(v_p_2460); V b_1 = heff_dup(g_heff_2esimplify_2efailing_get()); V r_ = (g_heff_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2462)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_t_2464 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2461)));
      return ({ V a_0 = v_t_2464; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2464); r_; });
    }
    default: return heff_nomatch(v_x1_2462);
    }
  }
  case TAG_ECall: {
    V v_g_2465 = heff_field(v_e_242, 0);
    V v_as_2466 = heff_field(v_e_242, 1);
    V v_t_2467 = (g_map_2elookup_24s8(heff_dup(v_g_2465), v_total_241));
    switch (heff_tag_of(v_t_2467)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_ar_2468 = heff_field(v_t_2467, 0);
      heff_take_n(v_t_2467, 1ULL, 1);
      V v_t_2469 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2466));
      V v_t_2470 = heff_intLe(v_t_2469, v_ar_2468);
      switch (heff_tag_of(v_t_2470)) {
      case TAG_True: {
        V v_t_2472 = (g_prelude_2emap(heff_clo(g_heff_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2466)));
        return ({ V a_0 = v_t_2472; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2472); r_; });
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2470);
      }
    }
    default: return heff_nomatch(v_t_2467);
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2epureIn(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2417; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2417); r_; });
}
V g_heff_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_p_2447 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_e2_2449 = heff_field(v_p_2447, 1);
    heff_take_n(v_p_2447, 2ULL, 2);
    return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_e2_2449; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_e2_2449); r_; });
  }
  default: return heff_nomatch(v_p_2447);
  }
}
V g_heff_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2455 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2455; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2455); r_; });
}
V g_heff_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_a_2463 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2463; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2463); r_; });
}
V g_heff_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2471 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2471; V r_ = (g_heff_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2471); r_; });
}
Clo g_heff_2esimplify_2eflat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eflat_entry, 1, 0};

V g_heff_2esimplify_2eflat(V v_b_240) {
top: ;
  switch (heff_tag_of(v_b_240)) {
  case TAG_EVar: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EGlobal: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_b_240, 0);
    V v_b2_244 = heff_field(v_b_240, 1);
    V v_ru_24b_240_24ELam = heff_take_reuse_n(v_b_240, 3ULL, 2);
    V v_x2_245 = (g_heff_2esimplify_2eflat(v_b2_244));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_ys_246 = heff_field(v_x2_245, 0);
      V v_b_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_t_248 = (g_heff_2esimplify_2eappendL(v_xs_243, v_ys_246));
      return heff_tag_at(v_ru_24b_240_24ELam, TAG_MkPair, 2, (V[]){v_t_248, v_b_247});
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  case TAG_EApp: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELet: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ERecord: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EProj: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ETag: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EMatch: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrim: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrimCall: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ECall: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EInt: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFloat: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EStr: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFix: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  default: return heff_nomatch(v_b_240);
  }
}
V g_heff_2esimplify_2eflat_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eflat(a[0]);
}
Clo g_heff_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_a_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_243));
    V v_t_246 = heff_intLt(MK_INT(0LL), v_a_245);
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = ({ V b_0 = heff_get(heff_dup(v_acc_240), LBL_safe); V b_1 = heff_get(heff_dup(v_acc_240), LBL_total); V a_2 = v_b_244; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_t_248 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_249 = (g_heff_2eir_2enubI(v_t_248));
        V v_x1_2410 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_249; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_249); r_; });
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_True: {
          V v_t_2411 = (g_map_2einsert_24s7(v_key_241, NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
          return heff_rec(2, shape_286_345, (V[]){v_t_2411, heff_get(v_acc_240, LBL_total)});
        }
        case TAG_False: {
          V v_t_2412 = (g_map_2einsert_24s7(heff_dup(v_key_241), NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
          V v_t_2413 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_243));
          V v_t_2414 = (g_map_2einsert_24s7(v_key_241, v_t_2413, heff_get(v_acc_240, LBL_total)));
          return heff_rec(2, shape_286_345, (V[]){v_t_2412, v_t_2414});
        }
        default: return heff_nomatch(v_x1_2410);
        }
      }
      case TAG_False: {
        V v_t_2415 = (g_map_2einsert_24s7(v_key_241, NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
        return heff_rec(2, shape_286_345, (V[]){v_t_2415, heff_get(v_acc_240, LBL_total)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_False: {
      V v_t_2416 = ({ V b_0 = heff_get(heff_dup(v_acc_240), LBL_safe); V b_1 = heff_get(heff_dup(v_acc_240), LBL_total); V a_2 = v_b_244; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        V v_t_2417 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_2418 = (g_heff_2eir_2enubI(v_t_2417));
        V v_x1_2419 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_2418; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_True: {
          heff_drop(v_key_241);
          return v_acc_240;
        }
        case TAG_False: {
          V v_t_2420 = (g_map_2einsert_24s7(v_key_241, NTAG(TAG_MkUnit), heff_get(heff_dup(v_acc_240), LBL_safe)));
          return heff_rec(2, shape_286_345, (V[]){v_t_2420, heff_get(v_acc_240, LBL_total)});
        }
        default: return heff_nomatch(v_x1_2419);
        }
      }
      case TAG_False: {
        heff_drop(v_key_241);
        return v_acc_240;
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2esgFlat(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esimplify_2epartialOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epartialOf_entry, 3, 0};

V g_heff_2esimplify_2epartialOf(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_t_248 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_241));
      V v_t_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_246));
      V v_t_2410 = heff_intLt(v_t_248, v_t_249);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2epureIn_clo), 2, (V[]){heff_get(heff_dup(v_s_240), LBL_safe), heff_get(v_s_240, LBL_total)}));
        V v_t_2412 = (g_prelude_2emap(v_t_2411, v_as_241));
        return ({ V a_0 = v_t_2412; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
      }
      case TAG_False: {
        heff_drop(v_s_240);
        heff_drop(v_as_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_EApp: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_s_240);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2epartialOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2epartialOf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esimplify_2epartialIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epartialIn_entry, 2, 0};

V g_heff_2esimplify_2epartialIn(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_f_246)) {
    case TAG_EVar: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_f_246, 0);
      V v_t_2410 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_all);
      V v_t_2411 = ({ V a_0 = heff_dup(v_g_249); V a_1 = v_t_2410; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return ({ V a_0 = v_s_240; V a_1 = heff_dup(v_as_247); V a_2 = v_t_2411; V r_ = (g_heff_2esimplify_2epartialOf(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    }
    case TAG_ELam: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_f_246);
    }
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2epartialIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2epartialIn(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2eintOp_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2eintOp_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2esimplify_2eintOp_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2eintOp_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2eintOp_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2eintOp_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2eintOp_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2esimplify_2eintOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eintOp_entry, 3, 0};

V g_heff_2esimplify_2eintOp(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_p_240);
    V v_t_244 = heff_tag(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return heff_tag(TAG_Just, 1, (V[]){v_t_244});
  }
  case TAG_False: {
    V v_t_245 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_p_240);
      V v_t_246 = heff_tag(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return heff_tag(TAG_Just, 1, (V[]){v_t_246});
    }
    case TAG_False: {
      V v_t_247 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str2));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_p_240);
        V v_t_248 = heff_tag(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return heff_tag(TAG_Just, 1, (V[]){v_t_248});
      }
      case TAG_False: {
        V v_t_249 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str3));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          heff_drop(v_p_240);
          V v_t_2410 = heff_intEq(v_a_241, v_b_242);
          V v_t_2411;
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            v_t_2411 = ((V)&g_heff_2esimplify_2eintOp_str4);
            break;
          }
          case TAG_False: {
            v_t_2411 = ((V)&g_heff_2esimplify_2eintOp_str5);
            break;
          }
          default: heff_nomatch(v_t_2410);
          }
          V v_t_2412 = heff_tag(TAG_ETag, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
          return heff_tag(TAG_Just, 1, (V[]){v_t_2412});
        }
        case TAG_False: {
          V v_t_2413 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2eintOp_str6));
          switch (heff_tag_of(v_t_2413)) {
          case TAG_True: {
            heff_drop(v_p_240);
            V v_t_2414 = heff_intLt(v_a_241, v_b_242);
            V v_t_2415;
            switch (heff_tag_of(v_t_2414)) {
            case TAG_True: {
              v_t_2415 = ((V)&g_heff_2esimplify_2eintOp_str7);
              break;
            }
            case TAG_False: {
              v_t_2415 = ((V)&g_heff_2esimplify_2eintOp_str8);
              break;
            }
            default: heff_nomatch(v_t_2414);
            }
            V v_t_2416 = heff_tag(TAG_ETag, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
            return heff_tag(TAG_Just, 1, (V[]){v_t_2416});
          }
          case TAG_False: {
            V v_t_2417 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2eintOp_str9));
            switch (heff_tag_of(v_t_2417)) {
            case TAG_True: {
              V v_t_2418 = heff_intLe(v_a_241, v_b_242);
              V v_t_2419;
              switch (heff_tag_of(v_t_2418)) {
              case TAG_True: {
                v_t_2419 = ((V)&g_heff_2esimplify_2eintOp_str10);
                break;
              }
              case TAG_False: {
                v_t_2419 = ((V)&g_heff_2esimplify_2eintOp_str11);
                break;
              }
              default: heff_nomatch(v_t_2418);
              }
              V v_t_2420 = heff_tag(TAG_ETag, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
              return heff_tag(TAG_Just, 1, (V[]){v_t_2420});
            }
            case TAG_False: {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2417);
            }
          }
          default: return heff_nomatch(v_t_2413);
          }
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esimplify_2eintOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eintOp(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2esimplify_2eunOp_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2esimplify_2eunOp_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
Clo g_heff_2esimplify_2eunOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eunOp_entry, 2, 0};

V g_heff_2esimplify_2eunOp(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2423 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2424 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2eunOp_str0));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      V v_t_2425 = heff_tag_at(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2423)});
      return heff_tag(TAG_Just, 1, (V[]){v_t_2425});
    }
    case TAG_False: {
      heff_drop(v_a_2423);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2427 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2428 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2eunOp_str1));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_True: {
      V v_t_2429 = heff_tag_at(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2427)});
      return heff_tag(TAG_Just, 1, (V[]){v_t_2429});
    }
    case TAG_False: {
      heff_drop(v_a_2427);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eunOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eunOp(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2esimplify_2ebinOp_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2ebinOp_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2esimplify_2ebinOp_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esimplify_2ebinOp_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2424 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      V v_b_2446 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2esimplify_2eintOp(v_p_240, v_a_2424, v_b_2446);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2424);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2452 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      V v_b_2476 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24EStr = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      V v_t_2477 = heff_strEq(heff_dup(v_p_240), ((V)&g_heff_2esimplify_2ebinOp_str0));
      switch (heff_tag_of(v_t_2477)) {
      case TAG_True: {
        heff_drop(v_p_240);
        V v_t_2478 = heff_tag_at(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2452, v_b_2476)});
        return heff_tag_at(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2478});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x3_242_24EStr, 1);
        V v_t_2479 = heff_strEq(v_p_240, ((V)&g_heff_2esimplify_2ebinOp_str1));
        switch (heff_tag_of(v_t_2479)) {
        case TAG_True: {
          V v_t_2480 = heff_strEq(v_a_2452, v_b_2476);
          V v_t_2481;
          switch (heff_tag_of(v_t_2480)) {
          case TAG_True: {
            v_t_2481 = ((V)&g_heff_2esimplify_2ebinOp_str2);
            break;
          }
          case TAG_False: {
            v_t_2481 = ((V)&g_heff_2esimplify_2ebinOp_str3);
            break;
          }
          default: heff_nomatch(v_t_2480);
          }
          V v_t_2482 = heff_tag(TAG_ETag, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x2_241_24EStr, TAG_Just, 1, (V[]){v_t_2482});
        }
        case TAG_False: {
          heff_drop(v_a_2452);
          heff_drop_cell(v_ru_24x2_241_24EStr, 1);
          heff_drop(v_b_2476);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2479);
        }
      }
      default: return heff_nomatch(v_t_2477);
      }
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2452);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ebinOp(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2eprimAppN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eprimAppN_entry, 3, 0};

V g_heff_2esimplify_2eprimAppN(V v_p_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_241));
    V v_t_245 = heff_intEq(v_t_244, heff_dup(v_n_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_n_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      V v_x2_2412;
      switch (heff_tag_of(v_as_241)) {
      case TAG_Nil: {
        v_x2_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_dup(heff_field(v_as_241, 0));
        V v_x22_247 = heff_dup(heff_field(v_as_241, 1));
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          v_x2_2412 = (g_heff_2esimplify_2eunOp(heff_dup(v_p_240), v_a_246));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_x22_247, 0);
          V v_x222_249 = heff_field(v_x22_247, 1);
          heff_take_n(v_x22_247, 3ULL, 2);
          switch (heff_tag_of(v_x222_249)) {
          case TAG_Nil: {
            v_x2_2412 = (g_heff_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_246, v_b_248));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x222_249, 0ULL, 2);
            heff_drop(v_a_246);
            heff_drop(v_b_248);
            v_x2_2412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x222_249);
          }
          break;
        }
        default: heff_nomatch(v_x22_247);
        }
        break;
      }
      default: heff_nomatch(v_as_241);
      }
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        return heff_tag(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_241});
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop(v_as_241);
        return v_x_2413;
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    case TAG_False: {
      V v_a_2414 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_241));
      V v_t_2415 = heff_intLt(heff_dup(v_n_243), v_a_2414);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        V v_as_2416 = (g_heff_2esimplify_2etakeL(heff_dup(v_n_243), heff_dup(v_as_241)));
        V v_x2_2423;
        switch (heff_tag_of(v_as_2416)) {
        case TAG_Nil: {
          v_x2_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_a_2417 = heff_dup(heff_field(v_as_2416, 0));
          V v_x22_2418 = heff_dup(heff_field(v_as_2416, 1));
          switch (heff_tag_of(v_x22_2418)) {
          case TAG_Nil: {
            v_x2_2423 = (g_heff_2esimplify_2eunOp(heff_dup(v_p_240), v_a_2417));
            break;
          }
          case TAG_Cons: {
            V v_b_2419 = heff_field(v_x22_2418, 0);
            V v_x222_2420 = heff_field(v_x22_2418, 1);
            heff_take_n(v_x22_2418, 3ULL, 2);
            switch (heff_tag_of(v_x222_2420)) {
            case TAG_Nil: {
              v_x2_2423 = (g_heff_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_2417, v_b_2419));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2420, 0ULL, 2);
              heff_drop(v_a_2417);
              heff_drop(v_b_2419);
              v_x2_2423 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x222_2420);
            }
            break;
          }
          default: heff_nomatch(v_x22_2418);
          }
          break;
        }
        default: heff_nomatch(v_as_2416);
        }
        V v_t_2425;
        switch (heff_tag_of(v_x2_2423)) {
        case TAG_Nothing: {
          v_t_2425 = heff_tag(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_2416});
          break;
        }
        case TAG_Just: {
          V v_x_2424 = heff_field(v_x2_2423, 0);
          heff_take_n(v_x2_2423, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop(v_as_2416);
          v_t_2425 = v_x_2424;
          break;
        }
        default: heff_nomatch(v_x2_2423);
        }
        return heff_tag(TAG_EApp, 2, (V[]){v_t_2425, (g_heff_2esimplify_2edropL(v_n_243, v_as_241))});
      }
      case TAG_False: {
        heff_drop(v_n_243);
        return heff_tag(TAG_EApp, 2, (V[]){heff_tag_at(v_ru_24x3_242_24Just, TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2eprimAppN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eprimAppN(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2esimplify_2emkApp(V v_f_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EGlobal: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ELam: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      heff_take_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_heff_2esimplify_2eappendL(v_bs_249, v_as_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_as_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ERecord: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EProj: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ETag: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EMatch: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EPrim: {
      V v_p_2421 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 1);
      V v_t_2422 = ({ V a_0 = heff_dup(v_p_2421); V b_1 = heff_dup(g_heff_2eprims_2eallPrims_get()); V r_ = (g_heff_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
      return (g_heff_2esimplify_2eprimAppN(v_p_2421, v_as_241, v_t_2422));
    }
    case TAG_EPrimCall: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ECall: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EInt: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EStr: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EAbandon: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFix: {
      return heff_tag(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2emkApp(a[0], a[1]);
}
V g_heff_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam3(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam5(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam4(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam6(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam8(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam7(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam9(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam10(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam11(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam12(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam15(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam14(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam13(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam16(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam17(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam18(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam19(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam20(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam21(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam22(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam23(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam24(V self, V *args);
V g_heff_2esimplify_2esubstCopies_lam25(V self, V *args);
Clo g_heff_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_t_244 = heff_strEq(heff_dup(v_y_243), v_x_240);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_y_243);
      return heff_clo(g_heff_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_a_241});
    }
    case TAG_False: {
      heff_drop(v_a_241);
      return heff_clo(g_heff_2esimplify_2esubstCopies_lam1, 1, 1, (V[]){v_y_243});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam2, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_2413 = heff_field(v_e_242, 0);
    V v_b_2414 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2415 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2414));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam3, 1, 2, (V[]){v_m_2415, v_xs_2413});
  }
  case TAG_EApp: {
    V v_f_2420 = heff_field(v_e_242, 0);
    V v_as_2421 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2422 = (g_heff_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_f_2420));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam4, 1, 4, (V[]){v_m_2422, v_x_240, v_a_241, v_as_2421});
  }
  case TAG_ELet: {
    V v_y_2433 = heff_field(v_e_242, 0);
    V v_e2_2434 = heff_field(v_e_242, 1);
    V v_b_2435 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2436 = (g_heff_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_e2_2434));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam6, 1, 5, (V[]){v_m_2436, v_x_240, v_a_241, v_b_2435, v_y_2433});
  }
  case TAG_ERecord: {
    V v_fs_2445 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_m_2454 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam7, 1, 2, (V[]){v_x_240, v_a_241}), v_fs_2445));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam9, 1, 1, (V[]){v_m_2454});
  }
  case TAG_EProj: {
    V v_e2_2459 = heff_field(v_e_242, 0);
    V v_l_2460 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2461 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e2_2459));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam10, 1, 2, (V[]){v_m_2461, v_l_2460});
  }
  case TAG_ETag: {
    V v_t_2466 = heff_field(v_e_242, 0);
    V v_as_2467 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2469 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam11, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2467));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam12, 1, 2, (V[]){v_m_2469, v_t_2466});
  }
  case TAG_EMatch: {
    V v_s_2474 = heff_field(v_e_242, 0);
    V v_arms_2475 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2476 = (g_heff_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_s_2474));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam13, 1, 4, (V[]){v_m_2476, v_x_240, v_a_241, v_arms_2475});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam16, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_2496 = heff_field(v_e_242, 0);
    V v_as_2497 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2499 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam17, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2497));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam18, 1, 2, (V[]){v_m_2499, v_p_2496});
  }
  case TAG_ECall: {
    V v_g_24104 = heff_field(v_e_242, 0);
    V v_as_24105 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24107 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam19, 1, 2, (V[]){v_x_240, v_a_241}), v_as_24105));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam20, 1, 2, (V[]){v_m_24107, v_g_24104});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam21, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam22, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam23, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam24, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam25, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2esubstCopies(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = (g_heff_2eir_2efreshGo_24s504(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_245), LBL_supply), v_a_241));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_e_27_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n_248, heff_get(heff_dup(v_s_245), LBL_fuel), heff_get(heff_dup(v_s_245), LBL_defs), heff_get(heff_dup(v_s_245), LBL_safe), heff_get(heff_dup(v_s_245), LBL_total), heff_get(heff_dup(v_s_245), LBL_plain), heff_get(v_s_245, LBL_sp)});
    return heff_tag_at(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_247, v_t_249});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_y_243}), v_s_2410});
}
V g_heff_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_2412});
}
V g_heff_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_xs_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_apply(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_2413, v_x_2418}), v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2esimplify_2esubstCopies_lam5(V self, V *args) {
  V v_q_2427 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2427));
}
V g_heff_2esimplify_2esubstCopies_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_as_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2424 = heff_tr(heff_apply(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_m_2428 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam5, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2421));
    V v_x2_2429 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2426}));
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_s_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      V v_x_2432 = (g_heff_2esimplify_2emkApp(v_x_2425, v_x_2430));
      return heff_tag_at(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_x_2432, v_s_2431});
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2esimplify_2esubstCopies_lam6(V self, V *args) {
  V v_s_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_2435 = heff_env(self)[3];
  V v_y_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2438 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_s_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_s_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    V v_m_2441 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2435));
    V v_x2_2442 = heff_tr(heff_apply(v_m_2441, 1, (V[]){v_s_2440}));
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_MkPair: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      V v_s_2444 = heff_field(v_x2_2442, 1);
      heff_take_n(v_x2_2442, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_y_2433, v_x_2439, v_x_2443}), v_s_2444});
    }
    default: return heff_nomatch(v_x2_2442);
    }
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2esimplify_2esubstCopies_lam8(V self, V *args) {
  V v_s_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_l_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_apply(v_m_2449, 1, (V[]){v_s_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_s_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_2447, v_x_2452}), v_s_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2esimplify_2esubstCopies_lam7(V self, V *args) {
  V v_p_2446 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2446)) {
  case TAG_MkPair: {
    V v_l_2447 = heff_field(v_p_2446, 0);
    V v_e_2448 = heff_field(v_p_2446, 1);
    heff_take_n(v_p_2446, 3ULL, 2);
    V v_m_2449 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e_2448));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam8, 1, 2, (V[]){v_m_2449, v_l_2447});
  }
  default: return heff_nomatch(v_p_2446);
  }
}
V g_heff_2esimplify_2esubstCopies_lam9(V self, V *args) {
  V v_s_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_s_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_s_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_x_2457}), v_s_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2esimplify_2esubstCopies_lam10(V self, V *args) {
  V v_s_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_l_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_apply(v_m_2461, 1, (V[]){v_s_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_s_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x_2464, v_l_2460}), v_s_2465});
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2esimplify_2esubstCopies_lam11(V self, V *args) {
  V v_q_2468 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2468));
}
V g_heff_2esimplify_2esubstCopies_lam12(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_t_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2471 = heff_tr(heff_apply(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2466, v_x_2472}), v_s_2473});
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2esimplify_2esubstCopies_lam15(V self, V *args) {
  V v_s_2486 = args[0];
  V v_m_2485 = heff_env(self)[0];
  V v_t_2482 = heff_env(self)[1];
  V v_vs_2483 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2487 = heff_tr(heff_apply(v_m_2485, 1, (V[]){v_s_2486}));
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_x2_2487, 0);
    V v_s_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_2482, v_vs_2483, v_x_2488}), v_s_2489});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
V g_heff_2esimplify_2esubstCopies_lam14(V self, V *args) {
  V v_a_2481 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2481)) {
  case TAG_MkArm: {
    V v_t_2482 = heff_field(v_a_2481, 0);
    V v_vs_2483 = heff_field(v_a_2481, 1);
    V v_b_2484 = heff_field(v_a_2481, 2);
    heff_take_n(v_a_2481, 7ULL, 3);
    V v_m_2485 = (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2484));
    return heff_clo(g_heff_2esimplify_2esubstCopies_lam15, 1, 3, (V[]){v_m_2485, v_t_2482, v_vs_2483});
  }
  default: return heff_nomatch(v_a_2481);
  }
}
V g_heff_2esimplify_2esubstCopies_lam13(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_arms_2475 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2478 = heff_tr(heff_apply(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_m_2490 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esubstCopies_lam14, 1, 2, (V[]){v_x_240, v_a_241}), v_arms_2475));
    V v_x2_2491 = heff_tr(heff_apply(v_m_2490, 1, (V[]){v_s_2480}));
    switch (heff_tag_of(v_x2_2491)) {
    case TAG_MkPair: {
      V v_x_2492 = heff_field(v_x2_2491, 0);
      V v_s_2493 = heff_field(v_x2_2491, 1);
      heff_take_n(v_x2_2491, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x_2479, v_x_2492}), v_s_2493});
    }
    default: return heff_nomatch(v_x2_2491);
    }
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2esimplify_2esubstCopies_lam16(V self, V *args) {
  V v_s_2495 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_2495});
}
V g_heff_2esimplify_2esubstCopies_lam17(V self, V *args) {
  V v_q_2498 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2498));
}
V g_heff_2esimplify_2esubstCopies_lam18(V self, V *args) {
  V v_s_24100 = args[0];
  V v_m_2499 = heff_env(self)[0];
  V v_p_2496 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24101 = heff_tr(heff_apply(v_m_2499, 1, (V[]){v_s_24100}));
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkPair: {
    V v_x_24102 = heff_field(v_x2_24101, 0);
    V v_s_24103 = heff_field(v_x2_24101, 1);
    V v_ru_24x2_24101_24MkPair = heff_take_reuse_n(v_x2_24101, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24101_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2496, v_x_24102}), v_s_24103});
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2esimplify_2esubstCopies_lam19(V self, V *args) {
  V v_q_24106 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_24106));
}
V g_heff_2esimplify_2esubstCopies_lam20(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_g_24104 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24109 = heff_tr(heff_apply(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24109_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_g_24104, v_x_24110}), v_s_24111});
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2esimplify_2esubstCopies_lam21(V self, V *args) {
  V v_s_24113 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24113});
}
V g_heff_2esimplify_2esubstCopies_lam22(V self, V *args) {
  V v_s_24115 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24115});
}
V g_heff_2esimplify_2esubstCopies_lam23(V self, V *args) {
  V v_s_24117 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24117});
}
V g_heff_2esimplify_2esubstCopies_lam24(V self, V *args) {
  V v_s_24118 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24118});
}
V g_heff_2esimplify_2esubstCopies_lam25(V self, V *args) {
  V v_s_24121 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_s_24121});
}
Clo g_heff_2esimplify_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2elam_entry, 2, 0};

V g_heff_2esimplify_2elam(V v_xs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_246 = (g_heff_2esimplify_2eappendL(v_xs_240, v_ys_244));
    return heff_tag_at(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_246, v_b_245});
  }
  case TAG_EApp: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELet: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ERecord: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EProj: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ETag: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EMatch: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrim: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ECall: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EInt: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EStr: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFix: {
    return heff_tag(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2elam(a[0], a[1]);
}
V g_heff_2esimplify_2eletPure_lam0(V self, V *args);
V g_heff_2esimplify_2eletPure_lam1(V self, V *args);
V g_heff_2esimplify_2eletPure_lam2(V self, V *args);
Clo g_heff_2esimplify_2eletPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eletPure_entry, 5, 0};

V g_heff_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  V v_t_245 = heff_intEq(heff_dup(v_o_244), MK_INT(0LL));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_x_241);
    heff_drop(v_a_242);
    heff_drop(v_o_244);
    return heff_tail(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243});
  }
  case TAG_False: {
    V v_t_2432;
    switch (heff_tag_of(v_a_242)) {
    case TAG_EVar: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_t_2433;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      heff_drop(v_o_244);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2433 = heff_intEq(v_o_244, MK_INT(1LL));
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      V v_m_2434 = (g_map_2einsert_24s7(v_x_241, v_a_242, heff_dup(g_map_2eempty_get())));
      V v_t_2435 = (g_map_2esize(v_m_2434));
      V v_t_2436 = heff_intEq(v_t_2435, MK_INT(0LL));
      V v_t_2437;
      switch (heff_tag_of(v_t_2436)) {
      case TAG_True: {
        heff_drop(v_m_2434);
        v_t_2437 = v_b_243;
        break;
      }
      case TAG_False: {
        v_t_2437 = ({ V a_0 = v_m_2434; V a_1 = v_b_243; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2434); r_; });
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      return heff_tail(heff_get(v_r_240, LBL_simp), 1, (V[]){v_t_2437});
    }
    case TAG_False: {
      V v_t_2466;
      switch (heff_tag_of(v_a_242)) {
      case TAG_EVar: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_ELam: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        V v_fs_2447 = heff_dup(heff_field(v_a_242, 0));
        V v_t_2448 = (g_prelude_2emap_24s511(v_fs_2447));
        v_t_2466 = ({ V a_0 = v_t_2448; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2448); r_; });
        break;
      }
      case TAG_EProj: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        V v_as_2452 = heff_dup(heff_field(v_a_242, 1));
        V v_t_2453 = (g_prelude_2emap_24s512(v_as_2452));
        v_t_2466 = ({ V a_0 = v_t_2453; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2453); r_; });
        break;
      }
      case TAG_EMatch: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      switch (heff_tag_of(v_t_2466)) {
      case TAG_True: {
        V v_t_2467 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_242), NTAG(TAG_Nil)});
        V v_a_2468 = (g_heff_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2467));
        V v_x1_2469 = heff_intLt(MK_INT(12LL), v_a_2468);
        switch (heff_tag_of(v_x1_2469)) {
        case TAG_True: {
          V v_m_2470 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243}));
          return heff_clo(g_heff_2esimplify_2eletPure_lam0, 1, 3, (V[]){v_m_2470, v_x_241, v_a_242});
        }
        case TAG_False: {
          V v_m_2475 = (g_heff_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
          return heff_clo(g_heff_2esimplify_2eletPure_lam1, 1, 2, (V[]){v_m_2475, v_r_240});
        }
        default: return heff_nomatch(v_x1_2469);
        }
      }
      case TAG_False: {
        V v_m_2480 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243}));
        return heff_clo(g_heff_2esimplify_2eletPure_lam2, 1, 3, (V[]){v_m_2480, v_x_241, v_a_242});
      }
      default: return heff_nomatch(v_t_2466);
      }
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esimplify_2eletPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eletPure(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esimplify_2eletPure_lam0(V self, V *args) {
  V v_s_2471 = args[0];
  V v_m_2470 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2472 = heff_tr(heff_apply(v_m_2470, 1, (V[]){v_s_2471}));
  switch (heff_tag_of(v_x2_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_field(v_x2_2472, 0);
    V v_s_2474 = heff_field(v_x2_2472, 1);
    V v_ru_24x2_2472_24MkPair = heff_take_reuse_n(v_x2_2472, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2473}), v_s_2474});
  }
  default: return heff_nomatch(v_x2_2472);
  }
}
V g_heff_2esimplify_2eletPure_lam1(V self, V *args) {
  V v_s_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2477 = heff_tr(heff_apply(v_m_2475, 1, (V[]){v_s_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_s_2479 = heff_field(v_x2_2477, 1);
    heff_take_n(v_x2_2477, 3ULL, 2);
    return heff_tail(heff_get(v_r_240, LBL_simp), 2, (V[]){v_x_2478, v_s_2479});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2esimplify_2eletPure_lam2(V self, V *args) {
  V v_s_2481 = args[0];
  V v_m_2480 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2482 = heff_tr(heff_apply(v_m_2480, 1, (V[]){v_s_2481}));
  switch (heff_tag_of(v_x2_2482)) {
  case TAG_MkPair: {
    V v_x_2483 = heff_field(v_x2_2482, 0);
    V v_s_2484 = heff_field(v_x2_2482, 1);
    V v_ru_24x2_2482_24MkPair = heff_take_reuse_n(v_x2_2482, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2483}), v_s_2484});
  }
  default: return heff_nomatch(v_x2_2482);
  }
}
Clo g_heff_2esimplify_2eletIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eletIn_entry, 5, 0};

V g_heff_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244) {
top: ;
  V v_t_245 = ({ V b_0 = heff_get(heff_dup(v_s_244), LBL_safe); V b_1 = heff_get(heff_dup(v_s_244), LBL_total); V a_2 = v_a_242; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_246 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_246 = (g_heff_2esimplify_2epartialIn(heff_dup(v_s_244), v_a_242));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_x2_247 = heff_tag(TAG_MkPair, 2, (V[]){v_t_246, v_s_244});
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_248)) {
    case TAG_True: {
      v_t_2410 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      V v_m_2411 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_243}));
      V v_x2_2412 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_s_249}));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2413}), v_s_2414});
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    case TAG_False: {
      V v_t_2415 = heff_tag_at(v_ru_24x2_247_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2416 = (g_heff_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_2415));
      V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2418 = (g_heff_2eir_2elamW(heff_dup(v_x_241), v_t_2417));
      V v_t_2419 = heff_get(heff_rec(2, shape_52_358, (V[]){v_t_2416, v_t_2418}), LBL_count);
      V v_t_2420 = heff_tr(g_heff_2esimplify_2eletPure(v_r_240, v_x_241, v_a_242, v_b_243, v_t_2419));
      return heff_tail(v_t_2420, 1, (V[]){v_s_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2esimplify_2eletIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eletIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esimplify_2etakesMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etakesMore_entry, 3, 0};

V g_heff_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242) {
top: ;
  V v_it_243 = ({ V a_0 = v_g_241; V b_1 = heff_get(v_s_240, LBL_defs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_n_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    heff_take_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_EVar: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 2);
      V v_a_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_247); r_; });
      return heff_intLt(v_n_242, v_a_249);
    }
    case TAG_EApp: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_it1_244, 0ULL, 3);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2esimplify_2etakesMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etakesMore(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        V v_t_249 = heff_strEq(heff_dup(v_x_244), heff_dup(v_y_248));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_False: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eparamsAre(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2eetaHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eetaHead_entry, 3, 0};

V g_heff_2esimplify_2eetaHead(V v_kinds_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_x1_244 = (g_heff_2esimplify_2eelemStr(heff_dup(v_y_243), v_xs_241));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x3_242, 0);
    V v_x3_246 = (g_map_2elookup_24s9(heff_dup(v_g_245), v_kinds_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2eetaHead_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eetaHead(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2esimplify_2eeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eeta_entry, 2, 0};

V g_heff_2esimplify_2eeta(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_245 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_245)) {
    case TAG_EVar: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ELam: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_e2_245, 0);
      V v_as_2411 = heff_field(v_e2_245, 1);
      V v_ru_24e2_245_24EApp = heff_take_reuse_n(v_e2_245, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_t_2412 = (g_heff_2esimplify_2eparamsAre(v_xs_244, v_as_2411));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        V v_t_2413 = (g_heff_2esimplify_2eetaHead(v_kinds_240, v_xs_244, v_f_2410));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_xs_244);
          heff_drop(v_as_2411);
          heff_drop_cell(v_ru_24e2_245_24EApp, 2);
          return v_f_2410;
        }
        case TAG_False: {
          return heff_tag_at(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_ELet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    default: return heff_nomatch(v_e2_245);
    }
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2eeta_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eeta(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2esimplify_2esimpF_lam0(V self, V *args);
V g_heff_2esimplify_2esimpF_lam1(V self, V *args);
V g_heff_2esimplify_2esimpF_lam2(V self, V *args);
V g_heff_2esimplify_2esimpF_lam4(V self, V *args);
V g_heff_2esimplify_2esimpF_lam3(V self, V *args);
V g_heff_2esimplify_2esimpF_lam6(V self, V *args);
V g_heff_2esimplify_2esimpF_lam5(V self, V *args);
V g_heff_2esimplify_2esimpF_lam8(V self, V *args);
V g_heff_2esimplify_2esimpF_lam7(V self, V *args);
V g_heff_2esimplify_2esimpF_lam10(V self, V *args);
V g_heff_2esimplify_2esimpF_lam9(V self, V *args);
V g_heff_2esimplify_2esimpF_lam12(V self, V *args);
V g_heff_2esimplify_2esimpF_lam11(V self, V *args);
V g_heff_2esimplify_2esimpF_lam14(V self, V *args);
V g_heff_2esimplify_2esimpF_lam13(V self, V *args);
V g_heff_2esimplify_2esimpF_lam16(V self, V *args);
V g_heff_2esimplify_2esimpF_lam15(V self, V *args);
V g_heff_2esimplify_2esimpF_lam18(V self, V *args);
V g_heff_2esimplify_2esimpF_lam17(V self, V *args);
V g_heff_2esimplify_2esimpF_lam20(V self, V *args);
V g_heff_2esimplify_2esimpF_lam19(V self, V *args);
V g_heff_2esimplify_2esimpF_lam22(V self, V *args);
V g_heff_2esimplify_2esimpF_lam21(V self, V *args);
V g_heff_2esimplify_2esimpF_lam24(V self, V *args);
V g_heff_2esimplify_2esimpF_lam23(V self, V *args);
V g_heff_2esimplify_2esimpF_lam26(V self, V *args);
V g_heff_2esimplify_2esimpF_lam25(V self, V *args);
V g_heff_2esimplify_2esimpF_lam28(V self, V *args);
V g_heff_2esimplify_2esimpF_lam27(V self, V *args);
V g_heff_2esimplify_2esimpF_lam30(V self, V *args);
V g_heff_2esimplify_2esimpF_lam29(V self, V *args);
V g_heff_2esimplify_2esimpF_lam32(V self, V *args);
V g_heff_2esimplify_2esimpF_lam31(V self, V *args);
V g_heff_2esimplify_2esimpF_lam34(V self, V *args);
V g_heff_2esimplify_2esimpF_lam33(V self, V *args);
V g_heff_2esimplify_2esimpF_lam36(V self, V *args);
V g_heff_2esimplify_2esimpF_lam35(V self, V *args);
V g_heff_2esimplify_2esimpF_lam38(V self, V *args);
V g_heff_2esimplify_2esimpF_lam37(V self, V *args);
V g_heff_2esimplify_2esimpF_lam40(V self, V *args);
V g_heff_2esimplify_2esimpF_lam39(V self, V *args);
V g_heff_2esimplify_2esimpF_lam42(V self, V *args);
V g_heff_2esimplify_2esimpF_lam41(V self, V *args);
V g_heff_2esimplify_2esimpF_lam44(V self, V *args);
V g_heff_2esimplify_2esimpF_lam43(V self, V *args);
V g_heff_2esimplify_2esimpF_lam46(V self, V *args);
V g_heff_2esimplify_2esimpF_lam45(V self, V *args);
V g_heff_2esimplify_2esimpF_lam48(V self, V *args);
V g_heff_2esimplify_2esimpF_lam47(V self, V *args);
V g_heff_2esimplify_2esimpF_lam50(V self, V *args);
V g_heff_2esimplify_2esimpF_lam49(V self, V *args);
V g_heff_2esimplify_2esimpF_lam52(V self, V *args);
V g_heff_2esimplify_2esimpF_lam51(V self, V *args);
V g_heff_2esimplify_2esimpF_lam54(V self, V *args);
V g_heff_2esimplify_2esimpF_lam53(V self, V *args);
V g_heff_2esimplify_2esimpF_lam56(V self, V *args);
V g_heff_2esimplify_2esimpF_lam55(V self, V *args);
V g_heff_2esimplify_2esimpF_lam58(V self, V *args);
V g_heff_2esimplify_2esimpF_lam57(V self, V *args);
V g_heff_2esimplify_2esimpF_lam60(V self, V *args);
V g_heff_2esimplify_2esimpF_lam59(V self, V *args);
V g_heff_2esimplify_2esimpF_lam62(V self, V *args);
V g_heff_2esimplify_2esimpF_lam61(V self, V *args);
V g_heff_2esimplify_2esimpF_lam64(V self, V *args);
V g_heff_2esimplify_2esimpF_lam63(V self, V *args);
V g_heff_2esimplify_2esimpF_lam66(V self, V *args);
V g_heff_2esimplify_2esimpF_lam65(V self, V *args);
V g_heff_2esimplify_2esimpF_lam68(V self, V *args);
V g_heff_2esimplify_2esimpF_lam67(V self, V *args);
V g_heff_2esimplify_2esimpF_lam69(V self, V *args);
V g_heff_2esimplify_2esimpF_lam71(V self, V *args);
V g_heff_2esimplify_2esimpF_lam70(V self, V *args);
V g_heff_2esimplify_2esimpF_lam72(V self, V *args);
V g_heff_2esimplify_2esimpF_lam73(V self, V *args);
V g_heff_2esimplify_2esimpF_lam74(V self, V *args);
V g_heff_2esimplify_2esimpF_lam75(V self, V *args);
V g_heff_2esimplify_2esimpF_lam78(V self, V *args);
V g_heff_2esimplify_2esimpF_lam77(V self, V *args);
V g_heff_2esimplify_2esimpF_lam76(V self, V *args);
V g_heff_2esimplify_2esimpF_lam79(V self, V *args);
V g_heff_2esimplify_2esimpF_lam80(V self, V *args);
V g_heff_2esimplify_2esimpF_lam81(V self, V *args);
V g_heff_2esimplify_2esimpF_lam82(V self, V *args);
V g_heff_2esimplify_2esimpF_lam83(V self, V *args);
V g_heff_2esimplify_2esimpF_lam84(V self, V *args);
V g_heff_2esimplify_2esimpF_lam85(V self, V *args);
V g_heff_2esimplify_2esimpF_lam86(V self, V *args);
V g_heff_2esimplify_2esimpF_lam87(V self, V *args);
Clo g_heff_2esimplify_2esimpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esimpF_entry, 2, 0};

V g_heff_2esimplify_2esimpF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_247}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_it1_2416 = heff_field(v_e_241, 0);
    V v_as_2417 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_it1_2416)) {
    case TAG_EVar: {
      V v_m_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam3, 1, 3, (V[]){v_m_2419, v_r_240, v_as_2417});
    }
    case TAG_EGlobal: {
      V v_m_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam5, 1, 3, (V[]){v_m_2430, v_r_240, v_as_2417});
    }
    case TAG_ELam: {
      V v_m_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam7, 1, 3, (V[]){v_m_2442, v_r_240, v_as_2417});
    }
    case TAG_EApp: {
      V v_it11_2452 = heff_dup(heff_field(v_it1_2416, 0));
      V v_bs_2453 = heff_dup(heff_field(v_it1_2416, 1));
      switch (heff_tag_of(v_it11_2452)) {
      case TAG_EVar: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_2455 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam9, 1, 3, (V[]){v_m_2455, v_r_240, v_as_2417});
      }
      case TAG_EGlobal: {
        V v_g_2465 = heff_field(v_it11_2452, 0);
        heff_take_n(v_it11_2452, 1ULL, 1);
        heff_drop_tag(v_it1_2416, 2);
        return heff_clo(g_heff_2esimplify_2esimpF_lam11, 1, 4, (V[]){v_bs_2453, v_g_2465, v_as_2417, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2482 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam13, 1, 3, (V[]){v_m_2482, v_r_240, v_as_2417});
      }
      case TAG_EApp: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2494 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam15, 1, 3, (V[]){v_m_2494, v_r_240, v_as_2417});
      }
      case TAG_ELet: {
        heff_take_n(v_it11_2452, 0ULL, 3);
        heff_drop(v_bs_2453);
        V v_m_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam17, 1, 3, (V[]){v_m_24107, v_r_240, v_as_2417});
      }
      case TAG_ERecord: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24118 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam19, 1, 3, (V[]){v_m_24118, v_r_240, v_as_2417});
      }
      case TAG_EProj: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24130 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam21, 1, 3, (V[]){v_m_24130, v_r_240, v_as_2417});
      }
      case TAG_ETag: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24142 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam23, 1, 3, (V[]){v_m_24142, v_r_240, v_as_2417});
      }
      case TAG_EMatch: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24154 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam25, 1, 3, (V[]){v_m_24154, v_r_240, v_as_2417});
      }
      case TAG_EPrim: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24165 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam27, 1, 3, (V[]){v_m_24165, v_r_240, v_as_2417});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24177 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam29, 1, 3, (V[]){v_m_24177, v_r_240, v_as_2417});
      }
      case TAG_ECall: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24189 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam31, 1, 3, (V[]){v_m_24189, v_r_240, v_as_2417});
      }
      case TAG_EInt: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24200 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam33, 1, 3, (V[]){v_m_24200, v_r_240, v_as_2417});
      }
      case TAG_EFloat: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24211 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam35, 1, 3, (V[]){v_m_24211, v_r_240, v_as_2417});
      }
      case TAG_EStr: {
        heff_take_n(v_it11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24222 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam37, 1, 3, (V[]){v_m_24222, v_r_240, v_as_2417});
      }
      case TAG_EAbandon: {
        heff_drop(v_bs_2453);
        V v_m_24232 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam39, 1, 3, (V[]){v_m_24232, v_r_240, v_as_2417});
      }
      case TAG_EFix: {
        heff_take_n(v_it11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24244 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
        return heff_clo(g_heff_2esimplify_2esimpF_lam41, 1, 3, (V[]){v_m_24244, v_r_240, v_as_2417});
      }
      default: return heff_nomatch(v_it11_2452);
      }
    }
    case TAG_ELet: {
      V v_m_24257 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam43, 1, 3, (V[]){v_m_24257, v_r_240, v_as_2417});
    }
    case TAG_ERecord: {
      V v_m_24268 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam45, 1, 3, (V[]){v_m_24268, v_r_240, v_as_2417});
    }
    case TAG_EProj: {
      V v_m_24280 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam47, 1, 3, (V[]){v_m_24280, v_r_240, v_as_2417});
    }
    case TAG_ETag: {
      V v_m_24292 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam49, 1, 3, (V[]){v_m_24292, v_r_240, v_as_2417});
    }
    case TAG_EMatch: {
      V v_m_24304 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam51, 1, 3, (V[]){v_m_24304, v_r_240, v_as_2417});
    }
    case TAG_EPrim: {
      V v_m_24315 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam53, 1, 3, (V[]){v_m_24315, v_r_240, v_as_2417});
    }
    case TAG_EPrimCall: {
      V v_m_24327 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam55, 1, 3, (V[]){v_m_24327, v_r_240, v_as_2417});
    }
    case TAG_ECall: {
      V v_m_24339 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam57, 1, 3, (V[]){v_m_24339, v_r_240, v_as_2417});
    }
    case TAG_EInt: {
      V v_m_24350 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam59, 1, 3, (V[]){v_m_24350, v_r_240, v_as_2417});
    }
    case TAG_EFloat: {
      V v_m_24361 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam61, 1, 3, (V[]){v_m_24361, v_r_240, v_as_2417});
    }
    case TAG_EStr: {
      V v_m_24372 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam63, 1, 3, (V[]){v_m_24372, v_r_240, v_as_2417});
    }
    case TAG_EAbandon: {
      V v_m_24382 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam65, 1, 3, (V[]){v_m_24382, v_r_240, v_as_2417});
    }
    case TAG_EFix: {
      V v_m_24394 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_it1_2416}));
      return heff_clo(g_heff_2esimplify_2esimpF_lam67, 1, 3, (V[]){v_m_24394, v_r_240, v_as_2417});
    }
    default: return heff_nomatch(v_it1_2416);
    }
  }
  case TAG_ELet: {
    V v_x_24404 = heff_field(v_e_241, 0);
    V v_a_24405 = heff_field(v_e_241, 1);
    V v_b_24406 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24407 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_a_24405}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam69, 1, 4, (V[]){v_m_24407, v_r_240, v_x_24404, v_b_24406});
  }
  case TAG_ERecord: {
    V v_fs_24412 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_m_24421 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam70, 1, 1, (V[]){v_r_240}), v_fs_24412));
    return heff_clo(g_heff_2esimplify_2esimpF_lam72, 1, 1, (V[]){v_m_24421});
  }
  case TAG_EProj: {
    V v_e2_24426 = heff_field(v_e_241, 0);
    V v_l_24427 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24428 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_e2_24426}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam73, 1, 3, (V[]){v_m_24428, v_r_240, v_l_24427});
  }
  case TAG_ETag: {
    V v_t_24433 = heff_field(v_e_241, 0);
    V v_as_24434 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24436 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam74, 1, 1, (V[]){v_r_240}), v_as_24434));
    return heff_clo(g_heff_2esimplify_2esimpF_lam75, 1, 2, (V[]){v_m_24436, v_t_24433});
  }
  case TAG_EMatch: {
    V v_s_24441 = heff_field(v_e_241, 0);
    V v_arms_24442 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24443 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_s_24441}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam76, 1, 3, (V[]){v_m_24443, v_r_240, v_arms_24442});
  }
  case TAG_EPrim: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam79, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_24463 = heff_field(v_e_241, 0);
    V v_as_24464 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24466 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam80, 1, 1, (V[]){v_r_240}), v_as_24464));
    return heff_clo(g_heff_2esimplify_2esimpF_lam81, 1, 2, (V[]){v_m_24466, v_p_24463});
  }
  case TAG_ECall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam82, 1, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam83, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam84, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam85, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam86, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2esimpF_lam87, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2esimpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2esimpF(a[0], a[1]);
}
V g_heff_2esimplify_2esimpF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2esimplify_2esimpF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_245});
}
V g_heff_2esimplify_2esimpF_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_apply(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_get(heff_get(heff_dup(v_s_2412), LBL_sp), LBL_kinds);
    V v_t_2414 = (g_heff_2esimplify_2elam(v_xs_246, v_x_2411));
    V v_x_2415 = ({ V a_0 = v_t_2413; V a_1 = v_t_2414; V r_ = (g_heff_2esimplify_2eeta(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_tag_at(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2esimplify_2esimpF_lam4(V self, V *args) {
  V v_a_2424 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2421 = heff_tr(heff_apply(v_m_2419, 1, (V[]){v_s_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_s_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    V v_m_2425 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2426 = heff_tr(heff_apply(v_m_2425, 1, (V[]){v_s_2423}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_s_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2422, v_x_2427, v_s_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2esimplify_2esimpF_lam6(V self, V *args) {
  V v_a_2435 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_apply(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    heff_take_n(v_x2_2432, 3ULL, 2);
    V v_m_2436 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam6, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2437 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2433, v_x_2438, v_s_2439});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2esimplify_2esimpF_lam8(V self, V *args) {
  V v_a_2447 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2444 = heff_tr(heff_apply(v_m_2442, 1, (V[]){v_s_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_s_2446 = heff_field(v_x2_2444, 1);
    heff_take_n(v_x2_2444, 3ULL, 2);
    V v_m_2448 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam8, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2449 = heff_tr(heff_apply(v_m_2448, 1, (V[]){v_s_2446}));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_s_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2445, v_x_2450, v_s_2451});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2esimplify_2esimpF_lam10(V self, V *args) {
  V v_a_2460 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam9(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    V v_m_2461 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2462 = heff_tr(heff_apply(v_m_2461, 1, (V[]){v_s_2459}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_s_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2458, v_x_2463, v_s_2464});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2esimplify_2esimpF_lam12(V self, V *args) {
  V v_a_2475 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam11(V self, V *args) {
  V v_s_2466 = args[0];
  V v_bs_2453 = heff_env(self)[0];
  V v_g_2465 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_bs_2453));
  V v_t_2468 = (g_heff_2esimplify_2etakesMore(heff_dup(v_s_2466), heff_dup(v_g_2465), v_t_2467));
  switch (heff_tag_of(v_t_2468)) {
  case TAG_True: {
    V v_t_2469 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_g_2465}), (g_heff_2esimplify_2eappendL(v_bs_2453, v_as_2417))});
    return heff_tail(heff_get(v_r_240, LBL_simp), 2, (V[]){v_t_2469, v_s_2466});
  }
  case TAG_False: {
    V v_t_2470 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_g_2465}), v_bs_2453});
    V v_m_2471 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_t_2470}));
    V v_x2_2472 = heff_tr(heff_apply(v_m_2471, 1, (V[]){v_s_2466}));
    switch (heff_tag_of(v_x2_2472)) {
    case TAG_MkPair: {
      V v_x_2473 = heff_field(v_x2_2472, 0);
      V v_s_2474 = heff_field(v_x2_2472, 1);
      heff_take_n(v_x2_2472, 3ULL, 2);
      V v_m_2476 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam12, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
      V v_x2_2477 = heff_tr(heff_apply(v_m_2476, 1, (V[]){v_s_2474}));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2473, v_x_2478, v_s_2479});
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
    default: return heff_nomatch(v_x2_2472);
    }
  }
  default: return heff_nomatch(v_t_2468);
  }
}
V g_heff_2esimplify_2esimpF_lam14(V self, V *args) {
  V v_a_2487 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam13(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_apply(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    heff_take_n(v_x2_2484, 3ULL, 2);
    V v_m_2488 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam14, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2489 = heff_tr(heff_apply(v_m_2488, 1, (V[]){v_s_2486}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_s_2491 = heff_field(v_x2_2489, 1);
      heff_take_n(v_x2_2489, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2485, v_x_2490, v_s_2491});
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2esimplify_2esimpF_lam16(V self, V *args) {
  V v_a_2499 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_2499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam15(V self, V *args) {
  V v_s_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2496 = heff_tr(heff_apply(v_m_2494, 1, (V[]){v_s_2495}));
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_MkPair: {
    V v_x_2497 = heff_field(v_x2_2496, 0);
    V v_s_2498 = heff_field(v_x2_2496, 1);
    heff_take_n(v_x2_2496, 3ULL, 2);
    V v_m_24100 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam16, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24101 = heff_tr(heff_apply(v_m_24100, 1, (V[]){v_s_2498}));
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_MkPair: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      V v_s_24103 = heff_field(v_x2_24101, 1);
      heff_take_n(v_x2_24101, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2497, v_x_24102, v_s_24103});
    }
    default: return heff_nomatch(v_x2_24101);
    }
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
V g_heff_2esimplify_2esimpF_lam18(V self, V *args) {
  V v_a_24112 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24112;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam17(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24109 = heff_tr(heff_apply(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    heff_take_n(v_x2_24109, 3ULL, 2);
    V v_m_24113 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam18, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24114 = heff_tr(heff_apply(v_m_24113, 1, (V[]){v_s_24111}));
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_s_24116 = heff_field(v_x2_24114, 1);
      heff_take_n(v_x2_24114, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24110, v_x_24115, v_s_24116});
    }
    default: return heff_nomatch(v_x2_24114);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2esimplify_2esimpF_lam20(V self, V *args) {
  V v_a_24123 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24123;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam19(V self, V *args) {
  V v_s_24119 = args[0];
  V v_m_24118 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24120 = heff_tr(heff_apply(v_m_24118, 1, (V[]){v_s_24119}));
  switch (heff_tag_of(v_x2_24120)) {
  case TAG_MkPair: {
    V v_x_24121 = heff_field(v_x2_24120, 0);
    V v_s_24122 = heff_field(v_x2_24120, 1);
    heff_take_n(v_x2_24120, 3ULL, 2);
    V v_m_24124 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam20, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24125 = heff_tr(heff_apply(v_m_24124, 1, (V[]){v_s_24122}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_s_24127 = heff_field(v_x2_24125, 1);
      heff_take_n(v_x2_24125, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24121, v_x_24126, v_s_24127});
    }
    default: return heff_nomatch(v_x2_24125);
    }
  }
  default: return heff_nomatch(v_x2_24120);
  }
}
V g_heff_2esimplify_2esimpF_lam22(V self, V *args) {
  V v_a_24135 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24135;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam21(V self, V *args) {
  V v_s_24131 = args[0];
  V v_m_24130 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24132 = heff_tr(heff_apply(v_m_24130, 1, (V[]){v_s_24131}));
  switch (heff_tag_of(v_x2_24132)) {
  case TAG_MkPair: {
    V v_x_24133 = heff_field(v_x2_24132, 0);
    V v_s_24134 = heff_field(v_x2_24132, 1);
    heff_take_n(v_x2_24132, 3ULL, 2);
    V v_m_24136 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam22, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24137 = heff_tr(heff_apply(v_m_24136, 1, (V[]){v_s_24134}));
    switch (heff_tag_of(v_x2_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x2_24137, 0);
      V v_s_24139 = heff_field(v_x2_24137, 1);
      heff_take_n(v_x2_24137, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24133, v_x_24138, v_s_24139});
    }
    default: return heff_nomatch(v_x2_24137);
    }
  }
  default: return heff_nomatch(v_x2_24132);
  }
}
V g_heff_2esimplify_2esimpF_lam24(V self, V *args) {
  V v_a_24147 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24147;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam23(V self, V *args) {
  V v_s_24143 = args[0];
  V v_m_24142 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24144 = heff_tr(heff_apply(v_m_24142, 1, (V[]){v_s_24143}));
  switch (heff_tag_of(v_x2_24144)) {
  case TAG_MkPair: {
    V v_x_24145 = heff_field(v_x2_24144, 0);
    V v_s_24146 = heff_field(v_x2_24144, 1);
    heff_take_n(v_x2_24144, 3ULL, 2);
    V v_m_24148 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam24, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24149 = heff_tr(heff_apply(v_m_24148, 1, (V[]){v_s_24146}));
    switch (heff_tag_of(v_x2_24149)) {
    case TAG_MkPair: {
      V v_x_24150 = heff_field(v_x2_24149, 0);
      V v_s_24151 = heff_field(v_x2_24149, 1);
      heff_take_n(v_x2_24149, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24145, v_x_24150, v_s_24151});
    }
    default: return heff_nomatch(v_x2_24149);
    }
  }
  default: return heff_nomatch(v_x2_24144);
  }
}
V g_heff_2esimplify_2esimpF_lam26(V self, V *args) {
  V v_a_24159 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24159;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam25(V self, V *args) {
  V v_s_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24156 = heff_tr(heff_apply(v_m_24154, 1, (V[]){v_s_24155}));
  switch (heff_tag_of(v_x2_24156)) {
  case TAG_MkPair: {
    V v_x_24157 = heff_field(v_x2_24156, 0);
    V v_s_24158 = heff_field(v_x2_24156, 1);
    heff_take_n(v_x2_24156, 3ULL, 2);
    V v_m_24160 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24161 = heff_tr(heff_apply(v_m_24160, 1, (V[]){v_s_24158}));
    switch (heff_tag_of(v_x2_24161)) {
    case TAG_MkPair: {
      V v_x_24162 = heff_field(v_x2_24161, 0);
      V v_s_24163 = heff_field(v_x2_24161, 1);
      heff_take_n(v_x2_24161, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24157, v_x_24162, v_s_24163});
    }
    default: return heff_nomatch(v_x2_24161);
    }
  }
  default: return heff_nomatch(v_x2_24156);
  }
}
V g_heff_2esimplify_2esimpF_lam28(V self, V *args) {
  V v_a_24170 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24170;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam27(V self, V *args) {
  V v_s_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24167 = heff_tr(heff_apply(v_m_24165, 1, (V[]){v_s_24166}));
  switch (heff_tag_of(v_x2_24167)) {
  case TAG_MkPair: {
    V v_x_24168 = heff_field(v_x2_24167, 0);
    V v_s_24169 = heff_field(v_x2_24167, 1);
    heff_take_n(v_x2_24167, 3ULL, 2);
    V v_m_24171 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam28, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24172 = heff_tr(heff_apply(v_m_24171, 1, (V[]){v_s_24169}));
    switch (heff_tag_of(v_x2_24172)) {
    case TAG_MkPair: {
      V v_x_24173 = heff_field(v_x2_24172, 0);
      V v_s_24174 = heff_field(v_x2_24172, 1);
      heff_take_n(v_x2_24172, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24168, v_x_24173, v_s_24174});
    }
    default: return heff_nomatch(v_x2_24172);
    }
  }
  default: return heff_nomatch(v_x2_24167);
  }
}
V g_heff_2esimplify_2esimpF_lam30(V self, V *args) {
  V v_a_24182 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24182;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam29(V self, V *args) {
  V v_s_24178 = args[0];
  V v_m_24177 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24179 = heff_tr(heff_apply(v_m_24177, 1, (V[]){v_s_24178}));
  switch (heff_tag_of(v_x2_24179)) {
  case TAG_MkPair: {
    V v_x_24180 = heff_field(v_x2_24179, 0);
    V v_s_24181 = heff_field(v_x2_24179, 1);
    heff_take_n(v_x2_24179, 3ULL, 2);
    V v_m_24183 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam30, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24184 = heff_tr(heff_apply(v_m_24183, 1, (V[]){v_s_24181}));
    switch (heff_tag_of(v_x2_24184)) {
    case TAG_MkPair: {
      V v_x_24185 = heff_field(v_x2_24184, 0);
      V v_s_24186 = heff_field(v_x2_24184, 1);
      heff_take_n(v_x2_24184, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24180, v_x_24185, v_s_24186});
    }
    default: return heff_nomatch(v_x2_24184);
    }
  }
  default: return heff_nomatch(v_x2_24179);
  }
}
V g_heff_2esimplify_2esimpF_lam32(V self, V *args) {
  V v_a_24194 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24194;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam31(V self, V *args) {
  V v_s_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24191 = heff_tr(heff_apply(v_m_24189, 1, (V[]){v_s_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_MkPair: {
    V v_x_24192 = heff_field(v_x2_24191, 0);
    V v_s_24193 = heff_field(v_x2_24191, 1);
    heff_take_n(v_x2_24191, 3ULL, 2);
    V v_m_24195 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam32, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24196 = heff_tr(heff_apply(v_m_24195, 1, (V[]){v_s_24193}));
    switch (heff_tag_of(v_x2_24196)) {
    case TAG_MkPair: {
      V v_x_24197 = heff_field(v_x2_24196, 0);
      V v_s_24198 = heff_field(v_x2_24196, 1);
      heff_take_n(v_x2_24196, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24192, v_x_24197, v_s_24198});
    }
    default: return heff_nomatch(v_x2_24196);
    }
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2esimplify_2esimpF_lam34(V self, V *args) {
  V v_a_24205 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24205;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam33(V self, V *args) {
  V v_s_24201 = args[0];
  V v_m_24200 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24202 = heff_tr(heff_apply(v_m_24200, 1, (V[]){v_s_24201}));
  switch (heff_tag_of(v_x2_24202)) {
  case TAG_MkPair: {
    V v_x_24203 = heff_field(v_x2_24202, 0);
    V v_s_24204 = heff_field(v_x2_24202, 1);
    heff_take_n(v_x2_24202, 3ULL, 2);
    V v_m_24206 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam34, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24207 = heff_tr(heff_apply(v_m_24206, 1, (V[]){v_s_24204}));
    switch (heff_tag_of(v_x2_24207)) {
    case TAG_MkPair: {
      V v_x_24208 = heff_field(v_x2_24207, 0);
      V v_s_24209 = heff_field(v_x2_24207, 1);
      heff_take_n(v_x2_24207, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24203, v_x_24208, v_s_24209});
    }
    default: return heff_nomatch(v_x2_24207);
    }
  }
  default: return heff_nomatch(v_x2_24202);
  }
}
V g_heff_2esimplify_2esimpF_lam36(V self, V *args) {
  V v_a_24216 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24216;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam35(V self, V *args) {
  V v_s_24212 = args[0];
  V v_m_24211 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24213 = heff_tr(heff_apply(v_m_24211, 1, (V[]){v_s_24212}));
  switch (heff_tag_of(v_x2_24213)) {
  case TAG_MkPair: {
    V v_x_24214 = heff_field(v_x2_24213, 0);
    V v_s_24215 = heff_field(v_x2_24213, 1);
    heff_take_n(v_x2_24213, 3ULL, 2);
    V v_m_24217 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam36, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24218 = heff_tr(heff_apply(v_m_24217, 1, (V[]){v_s_24215}));
    switch (heff_tag_of(v_x2_24218)) {
    case TAG_MkPair: {
      V v_x_24219 = heff_field(v_x2_24218, 0);
      V v_s_24220 = heff_field(v_x2_24218, 1);
      heff_take_n(v_x2_24218, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24214, v_x_24219, v_s_24220});
    }
    default: return heff_nomatch(v_x2_24218);
    }
  }
  default: return heff_nomatch(v_x2_24213);
  }
}
V g_heff_2esimplify_2esimpF_lam38(V self, V *args) {
  V v_a_24227 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24227;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam37(V self, V *args) {
  V v_s_24223 = args[0];
  V v_m_24222 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24224 = heff_tr(heff_apply(v_m_24222, 1, (V[]){v_s_24223}));
  switch (heff_tag_of(v_x2_24224)) {
  case TAG_MkPair: {
    V v_x_24225 = heff_field(v_x2_24224, 0);
    V v_s_24226 = heff_field(v_x2_24224, 1);
    heff_take_n(v_x2_24224, 3ULL, 2);
    V v_m_24228 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam38, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24229 = heff_tr(heff_apply(v_m_24228, 1, (V[]){v_s_24226}));
    switch (heff_tag_of(v_x2_24229)) {
    case TAG_MkPair: {
      V v_x_24230 = heff_field(v_x2_24229, 0);
      V v_s_24231 = heff_field(v_x2_24229, 1);
      heff_take_n(v_x2_24229, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24225, v_x_24230, v_s_24231});
    }
    default: return heff_nomatch(v_x2_24229);
    }
  }
  default: return heff_nomatch(v_x2_24224);
  }
}
V g_heff_2esimplify_2esimpF_lam40(V self, V *args) {
  V v_a_24237 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24237;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam39(V self, V *args) {
  V v_s_24233 = args[0];
  V v_m_24232 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24234 = heff_tr(heff_apply(v_m_24232, 1, (V[]){v_s_24233}));
  switch (heff_tag_of(v_x2_24234)) {
  case TAG_MkPair: {
    V v_x_24235 = heff_field(v_x2_24234, 0);
    V v_s_24236 = heff_field(v_x2_24234, 1);
    heff_take_n(v_x2_24234, 3ULL, 2);
    V v_m_24238 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam40, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24239 = heff_tr(heff_apply(v_m_24238, 1, (V[]){v_s_24236}));
    switch (heff_tag_of(v_x2_24239)) {
    case TAG_MkPair: {
      V v_x_24240 = heff_field(v_x2_24239, 0);
      V v_s_24241 = heff_field(v_x2_24239, 1);
      heff_take_n(v_x2_24239, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24235, v_x_24240, v_s_24241});
    }
    default: return heff_nomatch(v_x2_24239);
    }
  }
  default: return heff_nomatch(v_x2_24234);
  }
}
V g_heff_2esimplify_2esimpF_lam42(V self, V *args) {
  V v_a_24249 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam41(V self, V *args) {
  V v_s_24245 = args[0];
  V v_m_24244 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24246 = heff_tr(heff_apply(v_m_24244, 1, (V[]){v_s_24245}));
  switch (heff_tag_of(v_x2_24246)) {
  case TAG_MkPair: {
    V v_x_24247 = heff_field(v_x2_24246, 0);
    V v_s_24248 = heff_field(v_x2_24246, 1);
    heff_take_n(v_x2_24246, 3ULL, 2);
    V v_m_24250 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24251 = heff_tr(heff_apply(v_m_24250, 1, (V[]){v_s_24248}));
    switch (heff_tag_of(v_x2_24251)) {
    case TAG_MkPair: {
      V v_x_24252 = heff_field(v_x2_24251, 0);
      V v_s_24253 = heff_field(v_x2_24251, 1);
      heff_take_n(v_x2_24251, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24247, v_x_24252, v_s_24253});
    }
    default: return heff_nomatch(v_x2_24251);
    }
  }
  default: return heff_nomatch(v_x2_24246);
  }
}
V g_heff_2esimplify_2esimpF_lam44(V self, V *args) {
  V v_a_24262 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24262;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam43(V self, V *args) {
  V v_s_24258 = args[0];
  V v_m_24257 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24259 = heff_tr(heff_apply(v_m_24257, 1, (V[]){v_s_24258}));
  switch (heff_tag_of(v_x2_24259)) {
  case TAG_MkPair: {
    V v_x_24260 = heff_field(v_x2_24259, 0);
    V v_s_24261 = heff_field(v_x2_24259, 1);
    heff_take_n(v_x2_24259, 3ULL, 2);
    V v_m_24263 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam44, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24264 = heff_tr(heff_apply(v_m_24263, 1, (V[]){v_s_24261}));
    switch (heff_tag_of(v_x2_24264)) {
    case TAG_MkPair: {
      V v_x_24265 = heff_field(v_x2_24264, 0);
      V v_s_24266 = heff_field(v_x2_24264, 1);
      heff_take_n(v_x2_24264, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24260, v_x_24265, v_s_24266});
    }
    default: return heff_nomatch(v_x2_24264);
    }
  }
  default: return heff_nomatch(v_x2_24259);
  }
}
V g_heff_2esimplify_2esimpF_lam46(V self, V *args) {
  V v_a_24273 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24273;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam45(V self, V *args) {
  V v_s_24269 = args[0];
  V v_m_24268 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24270 = heff_tr(heff_apply(v_m_24268, 1, (V[]){v_s_24269}));
  switch (heff_tag_of(v_x2_24270)) {
  case TAG_MkPair: {
    V v_x_24271 = heff_field(v_x2_24270, 0);
    V v_s_24272 = heff_field(v_x2_24270, 1);
    heff_take_n(v_x2_24270, 3ULL, 2);
    V v_m_24274 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam46, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24275 = heff_tr(heff_apply(v_m_24274, 1, (V[]){v_s_24272}));
    switch (heff_tag_of(v_x2_24275)) {
    case TAG_MkPair: {
      V v_x_24276 = heff_field(v_x2_24275, 0);
      V v_s_24277 = heff_field(v_x2_24275, 1);
      heff_take_n(v_x2_24275, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24271, v_x_24276, v_s_24277});
    }
    default: return heff_nomatch(v_x2_24275);
    }
  }
  default: return heff_nomatch(v_x2_24270);
  }
}
V g_heff_2esimplify_2esimpF_lam48(V self, V *args) {
  V v_a_24285 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24285;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam47(V self, V *args) {
  V v_s_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24282 = heff_tr(heff_apply(v_m_24280, 1, (V[]){v_s_24281}));
  switch (heff_tag_of(v_x2_24282)) {
  case TAG_MkPair: {
    V v_x_24283 = heff_field(v_x2_24282, 0);
    V v_s_24284 = heff_field(v_x2_24282, 1);
    heff_take_n(v_x2_24282, 3ULL, 2);
    V v_m_24286 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam48, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24287 = heff_tr(heff_apply(v_m_24286, 1, (V[]){v_s_24284}));
    switch (heff_tag_of(v_x2_24287)) {
    case TAG_MkPair: {
      V v_x_24288 = heff_field(v_x2_24287, 0);
      V v_s_24289 = heff_field(v_x2_24287, 1);
      heff_take_n(v_x2_24287, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24283, v_x_24288, v_s_24289});
    }
    default: return heff_nomatch(v_x2_24287);
    }
  }
  default: return heff_nomatch(v_x2_24282);
  }
}
V g_heff_2esimplify_2esimpF_lam50(V self, V *args) {
  V v_a_24297 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24297;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam49(V self, V *args) {
  V v_s_24293 = args[0];
  V v_m_24292 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24294 = heff_tr(heff_apply(v_m_24292, 1, (V[]){v_s_24293}));
  switch (heff_tag_of(v_x2_24294)) {
  case TAG_MkPair: {
    V v_x_24295 = heff_field(v_x2_24294, 0);
    V v_s_24296 = heff_field(v_x2_24294, 1);
    heff_take_n(v_x2_24294, 3ULL, 2);
    V v_m_24298 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam50, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24299 = heff_tr(heff_apply(v_m_24298, 1, (V[]){v_s_24296}));
    switch (heff_tag_of(v_x2_24299)) {
    case TAG_MkPair: {
      V v_x_24300 = heff_field(v_x2_24299, 0);
      V v_s_24301 = heff_field(v_x2_24299, 1);
      heff_take_n(v_x2_24299, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24295, v_x_24300, v_s_24301});
    }
    default: return heff_nomatch(v_x2_24299);
    }
  }
  default: return heff_nomatch(v_x2_24294);
  }
}
V g_heff_2esimplify_2esimpF_lam52(V self, V *args) {
  V v_a_24309 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24309;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam51(V self, V *args) {
  V v_s_24305 = args[0];
  V v_m_24304 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24306 = heff_tr(heff_apply(v_m_24304, 1, (V[]){v_s_24305}));
  switch (heff_tag_of(v_x2_24306)) {
  case TAG_MkPair: {
    V v_x_24307 = heff_field(v_x2_24306, 0);
    V v_s_24308 = heff_field(v_x2_24306, 1);
    heff_take_n(v_x2_24306, 3ULL, 2);
    V v_m_24310 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam52, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24311 = heff_tr(heff_apply(v_m_24310, 1, (V[]){v_s_24308}));
    switch (heff_tag_of(v_x2_24311)) {
    case TAG_MkPair: {
      V v_x_24312 = heff_field(v_x2_24311, 0);
      V v_s_24313 = heff_field(v_x2_24311, 1);
      heff_take_n(v_x2_24311, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24307, v_x_24312, v_s_24313});
    }
    default: return heff_nomatch(v_x2_24311);
    }
  }
  default: return heff_nomatch(v_x2_24306);
  }
}
V g_heff_2esimplify_2esimpF_lam54(V self, V *args) {
  V v_a_24320 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24320;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam53(V self, V *args) {
  V v_s_24316 = args[0];
  V v_m_24315 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24317 = heff_tr(heff_apply(v_m_24315, 1, (V[]){v_s_24316}));
  switch (heff_tag_of(v_x2_24317)) {
  case TAG_MkPair: {
    V v_x_24318 = heff_field(v_x2_24317, 0);
    V v_s_24319 = heff_field(v_x2_24317, 1);
    heff_take_n(v_x2_24317, 3ULL, 2);
    V v_m_24321 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam54, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24322 = heff_tr(heff_apply(v_m_24321, 1, (V[]){v_s_24319}));
    switch (heff_tag_of(v_x2_24322)) {
    case TAG_MkPair: {
      V v_x_24323 = heff_field(v_x2_24322, 0);
      V v_s_24324 = heff_field(v_x2_24322, 1);
      heff_take_n(v_x2_24322, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24318, v_x_24323, v_s_24324});
    }
    default: return heff_nomatch(v_x2_24322);
    }
  }
  default: return heff_nomatch(v_x2_24317);
  }
}
V g_heff_2esimplify_2esimpF_lam56(V self, V *args) {
  V v_a_24332 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24332;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam55(V self, V *args) {
  V v_s_24328 = args[0];
  V v_m_24327 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24329 = heff_tr(heff_apply(v_m_24327, 1, (V[]){v_s_24328}));
  switch (heff_tag_of(v_x2_24329)) {
  case TAG_MkPair: {
    V v_x_24330 = heff_field(v_x2_24329, 0);
    V v_s_24331 = heff_field(v_x2_24329, 1);
    heff_take_n(v_x2_24329, 3ULL, 2);
    V v_m_24333 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam56, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24334 = heff_tr(heff_apply(v_m_24333, 1, (V[]){v_s_24331}));
    switch (heff_tag_of(v_x2_24334)) {
    case TAG_MkPair: {
      V v_x_24335 = heff_field(v_x2_24334, 0);
      V v_s_24336 = heff_field(v_x2_24334, 1);
      heff_take_n(v_x2_24334, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24330, v_x_24335, v_s_24336});
    }
    default: return heff_nomatch(v_x2_24334);
    }
  }
  default: return heff_nomatch(v_x2_24329);
  }
}
V g_heff_2esimplify_2esimpF_lam58(V self, V *args) {
  V v_a_24344 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24344;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam57(V self, V *args) {
  V v_s_24340 = args[0];
  V v_m_24339 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24341 = heff_tr(heff_apply(v_m_24339, 1, (V[]){v_s_24340}));
  switch (heff_tag_of(v_x2_24341)) {
  case TAG_MkPair: {
    V v_x_24342 = heff_field(v_x2_24341, 0);
    V v_s_24343 = heff_field(v_x2_24341, 1);
    heff_take_n(v_x2_24341, 3ULL, 2);
    V v_m_24345 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam58, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24346 = heff_tr(heff_apply(v_m_24345, 1, (V[]){v_s_24343}));
    switch (heff_tag_of(v_x2_24346)) {
    case TAG_MkPair: {
      V v_x_24347 = heff_field(v_x2_24346, 0);
      V v_s_24348 = heff_field(v_x2_24346, 1);
      heff_take_n(v_x2_24346, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24342, v_x_24347, v_s_24348});
    }
    default: return heff_nomatch(v_x2_24346);
    }
  }
  default: return heff_nomatch(v_x2_24341);
  }
}
V g_heff_2esimplify_2esimpF_lam60(V self, V *args) {
  V v_a_24355 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24355;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam59(V self, V *args) {
  V v_s_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24352 = heff_tr(heff_apply(v_m_24350, 1, (V[]){v_s_24351}));
  switch (heff_tag_of(v_x2_24352)) {
  case TAG_MkPair: {
    V v_x_24353 = heff_field(v_x2_24352, 0);
    V v_s_24354 = heff_field(v_x2_24352, 1);
    heff_take_n(v_x2_24352, 3ULL, 2);
    V v_m_24356 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam60, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24357 = heff_tr(heff_apply(v_m_24356, 1, (V[]){v_s_24354}));
    switch (heff_tag_of(v_x2_24357)) {
    case TAG_MkPair: {
      V v_x_24358 = heff_field(v_x2_24357, 0);
      V v_s_24359 = heff_field(v_x2_24357, 1);
      heff_take_n(v_x2_24357, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24353, v_x_24358, v_s_24359});
    }
    default: return heff_nomatch(v_x2_24357);
    }
  }
  default: return heff_nomatch(v_x2_24352);
  }
}
V g_heff_2esimplify_2esimpF_lam62(V self, V *args) {
  V v_a_24366 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24366;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam61(V self, V *args) {
  V v_s_24362 = args[0];
  V v_m_24361 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24363 = heff_tr(heff_apply(v_m_24361, 1, (V[]){v_s_24362}));
  switch (heff_tag_of(v_x2_24363)) {
  case TAG_MkPair: {
    V v_x_24364 = heff_field(v_x2_24363, 0);
    V v_s_24365 = heff_field(v_x2_24363, 1);
    heff_take_n(v_x2_24363, 3ULL, 2);
    V v_m_24367 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam62, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24368 = heff_tr(heff_apply(v_m_24367, 1, (V[]){v_s_24365}));
    switch (heff_tag_of(v_x2_24368)) {
    case TAG_MkPair: {
      V v_x_24369 = heff_field(v_x2_24368, 0);
      V v_s_24370 = heff_field(v_x2_24368, 1);
      heff_take_n(v_x2_24368, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24364, v_x_24369, v_s_24370});
    }
    default: return heff_nomatch(v_x2_24368);
    }
  }
  default: return heff_nomatch(v_x2_24363);
  }
}
V g_heff_2esimplify_2esimpF_lam64(V self, V *args) {
  V v_a_24377 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24377;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam63(V self, V *args) {
  V v_s_24373 = args[0];
  V v_m_24372 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24374 = heff_tr(heff_apply(v_m_24372, 1, (V[]){v_s_24373}));
  switch (heff_tag_of(v_x2_24374)) {
  case TAG_MkPair: {
    V v_x_24375 = heff_field(v_x2_24374, 0);
    V v_s_24376 = heff_field(v_x2_24374, 1);
    heff_take_n(v_x2_24374, 3ULL, 2);
    V v_m_24378 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam64, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24379 = heff_tr(heff_apply(v_m_24378, 1, (V[]){v_s_24376}));
    switch (heff_tag_of(v_x2_24379)) {
    case TAG_MkPair: {
      V v_x_24380 = heff_field(v_x2_24379, 0);
      V v_s_24381 = heff_field(v_x2_24379, 1);
      heff_take_n(v_x2_24379, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24375, v_x_24380, v_s_24381});
    }
    default: return heff_nomatch(v_x2_24379);
    }
  }
  default: return heff_nomatch(v_x2_24374);
  }
}
V g_heff_2esimplify_2esimpF_lam66(V self, V *args) {
  V v_a_24387 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24387;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam65(V self, V *args) {
  V v_s_24383 = args[0];
  V v_m_24382 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24384 = heff_tr(heff_apply(v_m_24382, 1, (V[]){v_s_24383}));
  switch (heff_tag_of(v_x2_24384)) {
  case TAG_MkPair: {
    V v_x_24385 = heff_field(v_x2_24384, 0);
    V v_s_24386 = heff_field(v_x2_24384, 1);
    heff_take_n(v_x2_24384, 3ULL, 2);
    V v_m_24388 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam66, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24389 = heff_tr(heff_apply(v_m_24388, 1, (V[]){v_s_24386}));
    switch (heff_tag_of(v_x2_24389)) {
    case TAG_MkPair: {
      V v_x_24390 = heff_field(v_x2_24389, 0);
      V v_s_24391 = heff_field(v_x2_24389, 1);
      heff_take_n(v_x2_24389, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24385, v_x_24390, v_s_24391});
    }
    default: return heff_nomatch(v_x2_24389);
    }
  }
  default: return heff_nomatch(v_x2_24384);
  }
}
V g_heff_2esimplify_2esimpF_lam68(V self, V *args) {
  V v_a_24399 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24399;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam67(V self, V *args) {
  V v_s_24395 = args[0];
  V v_m_24394 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24396 = heff_tr(heff_apply(v_m_24394, 1, (V[]){v_s_24395}));
  switch (heff_tag_of(v_x2_24396)) {
  case TAG_MkPair: {
    V v_x_24397 = heff_field(v_x2_24396, 0);
    V v_s_24398 = heff_field(v_x2_24396, 1);
    heff_take_n(v_x2_24396, 3ULL, 2);
    V v_m_24400 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam68, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24401 = heff_tr(heff_apply(v_m_24400, 1, (V[]){v_s_24398}));
    switch (heff_tag_of(v_x2_24401)) {
    case TAG_MkPair: {
      V v_x_24402 = heff_field(v_x2_24401, 0);
      V v_s_24403 = heff_field(v_x2_24401, 1);
      heff_take_n(v_x2_24401, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_24397, v_x_24402, v_s_24403});
    }
    default: return heff_nomatch(v_x2_24401);
    }
  }
  default: return heff_nomatch(v_x2_24396);
  }
}
V g_heff_2esimplify_2esimpF_lam69(V self, V *args) {
  V v_s_24408 = args[0];
  V v_m_24407 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_24404 = heff_env(self)[2];
  V v_b_24406 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24409 = heff_tr(heff_apply(v_m_24407, 1, (V[]){v_s_24408}));
  switch (heff_tag_of(v_x2_24409)) {
  case TAG_MkPair: {
    V v_x_24410 = heff_field(v_x2_24409, 0);
    V v_s_24411 = heff_field(v_x2_24409, 1);
    heff_take_n(v_x2_24409, 3ULL, 2);
    return (g_heff_2esimplify_2eletIn(v_r_240, v_x_24404, v_x_24410, v_b_24406, v_s_24411));
  }
  default: return heff_nomatch(v_x2_24409);
  }
}
V g_heff_2esimplify_2esimpF_lam71(V self, V *args) {
  V v_s_24417 = args[0];
  V v_m_24416 = heff_env(self)[0];
  V v_l_24414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24418 = heff_tr(heff_apply(v_m_24416, 1, (V[]){v_s_24417}));
  switch (heff_tag_of(v_x2_24418)) {
  case TAG_MkPair: {
    V v_x_24419 = heff_field(v_x2_24418, 0);
    V v_s_24420 = heff_field(v_x2_24418, 1);
    V v_ru_24x2_24418_24MkPair = heff_take_reuse_n(v_x2_24418, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_24414, v_x_24419}), v_s_24420});
  }
  default: return heff_nomatch(v_x2_24418);
  }
}
V g_heff_2esimplify_2esimpF_lam70(V self, V *args) {
  V v_p_24413 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24413)) {
  case TAG_MkPair: {
    V v_l_24414 = heff_field(v_p_24413, 0);
    V v_e_24415 = heff_field(v_p_24413, 1);
    heff_take_n(v_p_24413, 3ULL, 2);
    V v_m_24416 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_e_24415}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam71, 1, 2, (V[]){v_m_24416, v_l_24414});
  }
  default: return heff_nomatch(v_p_24413);
  }
}
V g_heff_2esimplify_2esimpF_lam72(V self, V *args) {
  V v_s_24422 = args[0];
  V v_m_24421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24423 = heff_tr(heff_apply(v_m_24421, 1, (V[]){v_s_24422}));
  switch (heff_tag_of(v_x2_24423)) {
  case TAG_MkPair: {
    V v_x_24424 = heff_field(v_x2_24423, 0);
    V v_s_24425 = heff_field(v_x2_24423, 1);
    V v_ru_24x2_24423_24MkPair = heff_take_reuse_n(v_x2_24423, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_x_24424}), v_s_24425});
  }
  default: return heff_nomatch(v_x2_24423);
  }
}
V g_heff_2esimplify_2esimpF_lam73(V self, V *args) {
  V v_s_24429 = args[0];
  V v_m_24428 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_l_24427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24430 = heff_tr(heff_apply(v_m_24428, 1, (V[]){v_s_24429}));
  switch (heff_tag_of(v_x2_24430)) {
  case TAG_MkPair: {
    V v_x_24431 = heff_field(v_x2_24430, 0);
    V v_s_24432 = heff_field(v_x2_24430, 1);
    heff_take_n(v_x2_24430, 3ULL, 2);
    return heff_tail(heff_get(v_r_240, LBL_project), 3, (V[]){v_l_24427, v_x_24431, v_s_24432});
  }
  default: return heff_nomatch(v_x2_24430);
  }
}
V g_heff_2esimplify_2esimpF_lam74(V self, V *args) {
  V v_a_24435 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam75(V self, V *args) {
  V v_s_24437 = args[0];
  V v_m_24436 = heff_env(self)[0];
  V v_t_24433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24438 = heff_tr(heff_apply(v_m_24436, 1, (V[]){v_s_24437}));
  switch (heff_tag_of(v_x2_24438)) {
  case TAG_MkPair: {
    V v_x_24439 = heff_field(v_x2_24438, 0);
    V v_s_24440 = heff_field(v_x2_24438, 1);
    V v_ru_24x2_24438_24MkPair = heff_take_reuse_n(v_x2_24438, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_24433, v_x_24439}), v_s_24440});
  }
  default: return heff_nomatch(v_x2_24438);
  }
}
V g_heff_2esimplify_2esimpF_lam78(V self, V *args) {
  V v_s_24453 = args[0];
  V v_m_24452 = heff_env(self)[0];
  V v_t_24449 = heff_env(self)[1];
  V v_vs_24450 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24454 = heff_tr(heff_apply(v_m_24452, 1, (V[]){v_s_24453}));
  switch (heff_tag_of(v_x2_24454)) {
  case TAG_MkPair: {
    V v_x_24455 = heff_field(v_x2_24454, 0);
    V v_s_24456 = heff_field(v_x2_24454, 1);
    V v_ru_24x2_24454_24MkPair = heff_take_reuse_n(v_x2_24454, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_24449, v_vs_24450, v_x_24455}), v_s_24456});
  }
  default: return heff_nomatch(v_x2_24454);
  }
}
V g_heff_2esimplify_2esimpF_lam77(V self, V *args) {
  V v_a_24448 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24448)) {
  case TAG_MkArm: {
    V v_t_24449 = heff_field(v_a_24448, 0);
    V v_vs_24450 = heff_field(v_a_24448, 1);
    V v_b_24451 = heff_field(v_a_24448, 2);
    heff_take_n(v_a_24448, 7ULL, 3);
    V v_m_24452 = heff_tr(heff_apply(heff_get(v_r_240, LBL_simp), 1, (V[]){v_b_24451}));
    return heff_clo(g_heff_2esimplify_2esimpF_lam78, 1, 3, (V[]){v_m_24452, v_t_24449, v_vs_24450});
  }
  default: return heff_nomatch(v_a_24448);
  }
}
V g_heff_2esimplify_2esimpF_lam76(V self, V *args) {
  V v_s_24444 = args[0];
  V v_m_24443 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_24442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24445 = heff_tr(heff_apply(v_m_24443, 1, (V[]){v_s_24444}));
  switch (heff_tag_of(v_x2_24445)) {
  case TAG_MkPair: {
    V v_x_24446 = heff_field(v_x2_24445, 0);
    V v_s_24447 = heff_field(v_x2_24445, 1);
    heff_take_n(v_x2_24445, 3ULL, 2);
    V v_m_24457 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2esimpF_lam77, 1, 1, (V[]){heff_dup(v_r_240)}), v_arms_24442));
    V v_x2_24458 = heff_tr(heff_apply(v_m_24457, 1, (V[]){v_s_24447}));
    switch (heff_tag_of(v_x2_24458)) {
    case TAG_MkPair: {
      V v_x_24459 = heff_field(v_x2_24458, 0);
      V v_s_24460 = heff_field(v_x2_24458, 1);
      heff_take_n(v_x2_24458, 3ULL, 2);
      return heff_tail(heff_get(v_r_240, LBL_match), 3, (V[]){v_x_24446, v_x_24459, v_s_24460});
    }
    default: return heff_nomatch(v_x2_24458);
    }
  }
  default: return heff_nomatch(v_x2_24445);
  }
}
V g_heff_2esimplify_2esimpF_lam79(V self, V *args) {
  V v_s_24462 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24462});
}
V g_heff_2esimplify_2esimpF_lam80(V self, V *args) {
  V v_a_24465 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_simp);
  args[0] = v_a_24465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esimplify_2esimpF_lam81(V self, V *args) {
  V v_s_24467 = args[0];
  V v_m_24466 = heff_env(self)[0];
  V v_p_24463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24468 = heff_tr(heff_apply(v_m_24466, 1, (V[]){v_s_24467}));
  switch (heff_tag_of(v_x2_24468)) {
  case TAG_MkPair: {
    V v_x_24469 = heff_field(v_x2_24468, 0);
    V v_s_24470 = heff_field(v_x2_24468, 1);
    V v_ru_24x2_24468_24MkPair = heff_take_reuse_n(v_x2_24468, 3ULL, 2);
    V v_x2_24477;
    switch (heff_tag_of(v_x_24469)) {
    case TAG_Nil: {
      v_x2_24477 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_24471 = heff_dup(heff_field(v_x_24469, 0));
      V v_x22_24472 = heff_dup(heff_field(v_x_24469, 1));
      switch (heff_tag_of(v_x22_24472)) {
      case TAG_Nil: {
        v_x2_24477 = (g_heff_2esimplify_2eunOp(heff_dup(v_p_24463), v_a_24471));
        break;
      }
      case TAG_Cons: {
        V v_b_24473 = heff_field(v_x22_24472, 0);
        V v_x222_24474 = heff_field(v_x22_24472, 1);
        heff_take_n(v_x22_24472, 3ULL, 2);
        switch (heff_tag_of(v_x222_24474)) {
        case TAG_Nil: {
          v_x2_24477 = (g_heff_2esimplify_2ebinOp(heff_dup(v_p_24463), v_a_24471, v_b_24473));
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x222_24474, 0ULL, 2);
          heff_drop(v_a_24471);
          heff_drop(v_b_24473);
          v_x2_24477 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x222_24474);
        }
        break;
      }
      default: heff_nomatch(v_x22_24472);
      }
      break;
    }
    default: heff_nomatch(v_x_24469);
    }
    V v_x_24479;
    switch (heff_tag_of(v_x2_24477)) {
    case TAG_Nothing: {
      v_x_24479 = heff_tag_at(v_ru_24x2_24468_24MkPair, TAG_EPrimCall, 2, (V[]){v_p_24463, v_x_24469});
      break;
    }
    case TAG_Just: {
      V v_x_24478 = heff_field(v_x2_24477, 0);
      heff_take_n(v_x2_24477, 1ULL, 1);
      heff_drop(v_p_24463);
      heff_drop(v_x_24469);
      heff_drop_cell(v_ru_24x2_24468_24MkPair, 2);
      v_x_24479 = v_x_24478;
      break;
    }
    default: heff_nomatch(v_x2_24477);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_24479, v_s_24470});
  }
  default: return heff_nomatch(v_x2_24468);
  }
}
V g_heff_2esimplify_2esimpF_lam82(V self, V *args) {
  V v_s_24482 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24482});
}
V g_heff_2esimplify_2esimpF_lam83(V self, V *args) {
  V v_s_24484 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24484});
}
V g_heff_2esimplify_2esimpF_lam84(V self, V *args) {
  V v_s_24486 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24486});
}
V g_heff_2esimplify_2esimpF_lam85(V self, V *args) {
  V v_s_24488 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24488});
}
V g_heff_2esimplify_2esimpF_lam86(V self, V *args) {
  V v_s_24489 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24489});
}
V g_heff_2esimplify_2esimpF_lam87(V self, V *args) {
  V v_s_24492 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_s_24492});
}

static V g_heff_2esimplify_2einlineMax_val;
static int g_heff_2esimplify_2einlineMax_st;
static V g_heff_2esimplify_2einlineMax_init(void) {
  return MK_INT(50LL);
}
V g_heff_2esimplify_2einlineMax_get(void) {
  if (g_heff_2esimplify_2einlineMax_st == 2) return g_heff_2esimplify_2einlineMax_val;
  if (g_heff_2esimplify_2einlineMax_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2einlineMax_st = 1;
  g_heff_2esimplify_2einlineMax_val = heff_tr(g_heff_2esimplify_2einlineMax_init());
  g_heff_2esimplify_2einlineMax_st = 2;
  return g_heff_2esimplify_2einlineMax_val;
}
Clo g_heff_2esimplify_2einlineCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2einlineCall_entry, 5, 0};

V g_heff_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = ({ V a_0 = heff_dup(v_g_242); V b_1 = heff_get(heff_dup(v_s_244), LBL_defs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_x2_246 = (g_heff_2esimplify_2eknown(v_g_242, v_s_244));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x_247)) {
      case TAG_Nothing: {
        heff_drop(v_r_240);
        V v_x_249 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_249, v_s_248});
      }
      case TAG_Just: {
        V v_b_2410 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
        V v_t_2411 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
        V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2410, v_as_243}));
        return (g_heff_2esimplify_2eattempt(v_t_2411, v_t_2412, v_s_248));
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  case TAG_Just: {
    V v_b_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_b_2413, NTAG(TAG_Nil)});
    V v_a_2415 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2einlineMax_get()), MK_INT(0LL), v_t_2414));
    V v_t_2416 = heff_intLt(heff_dup(g_heff_2esimplify_2einlineMax_get()), v_a_2415);
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_r_240);
      heff_drop(v_g_242);
      V v_x_2417 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2417, v_s_244});
    }
    case TAG_False: {
      V v_x2_2418 = (g_heff_2esimplify_2eknown(v_g_242, v_s_244));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_s_2420 = heff_field(v_x2_2418, 1);
        V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
        switch (heff_tag_of(v_x_2419)) {
        case TAG_Nothing: {
          heff_drop(v_r_240);
          V v_x_2421 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2420});
        }
        case TAG_Just: {
          V v_b_2422 = heff_field(v_x_2419, 0);
          heff_take_n(v_x_2419, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
          V v_t_2423 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
          V v_t_2424 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2422, v_as_243}));
          return (g_heff_2esimplify_2eattempt(v_t_2423, v_t_2424, v_s_2420));
        }
        default: return heff_nomatch(v_x_2419);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esimplify_2einlineCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2einlineCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esimplify_2efreshParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efreshParams_entry, 2, 0};

V g_heff_2esimplify_2efreshParams(V v_k_240, V v_s_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_get(heff_dup(v_s_241), LBL_supply)});
  V v_t_243 = (g_prelude_2erange(MK_INT(1LL), v_k_240));
  V v_t_244 = (g_prelude_2efoldl_24s520(v_t_242, v_t_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_MkPair: {
    V v_xs_245 = heff_field(v_t_244, 0);
    V v_n_246 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24MkPair = heff_take_reuse_n(v_t_244, 3ULL, 2);
    V v_t_247 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n_246, heff_get(heff_dup(v_s_241), LBL_fuel), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(heff_dup(v_s_241), LBL_plain), heff_get(v_s_241, LBL_sp)});
    return heff_tag_at(v_ru_24t_244_24MkPair, TAG_MkPair, 2, (V[]){v_xs_245, v_t_247});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esimplify_2efreshParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2efreshParams(a[0], a[1]);
}
Clo g_heff_2esimplify_2eremember_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eremember_entry, 3, 0};

V g_heff_2esimplify_2eremember(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_t_243 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_242), LBL_fuel));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = (g_map_2einsert_24s7(v_k_240, v_p_241, heff_get(heff_dup(v_s_242), LBL_plain)));
    v_t_245 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), v_t_244, heff_get(v_s_242, LBL_sp)});
    break;
  }
  case TAG_False: {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_t_245 = v_s_242;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
}
V g_heff_2esimplify_2eremember_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eremember(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2eplainCall_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2eplainCall_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2eplainCall_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_heff_2esimplify_2eplainCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eplainCall_entry, 5, 0};

V g_heff_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
  V v_t_246 = heff_strAppend(heff_dup(v_g_242), heff_strAppend(((V)&g_heff_2esimplify_2eplainCall_str0), heff_intShow(v_t_245)));
  V v_it_247 = ({ V a_0 = v_t_246; V b_1 = heff_get(heff_dup(v_s_244), LBL_plain); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
    V v_m_249 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_248}));
    V v_x2_2410 = heff_tr(heff_apply(v_m_249, 1, (V[]){heff_dup(v_s_244)}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_x2_2413 = (g_heff_2esimplify_2eknown(heff_dup(v_g_242), v_s_2412));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
        switch (heff_tag_of(v_x_2414)) {
        case TAG_Nothing: {
          heff_drop(v_r_240);
          heff_drop(v_g_242);
          heff_drop(v_s_244);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
          V v_x_2416 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_s_2415});
        }
        case TAG_Just: {
          V v_b_2417 = heff_field(v_x_2414, 0);
          heff_take_n(v_x_2414, 1ULL, 1);
          V v_t_2418 = (g_prelude_2emap_24s521(heff_dup(v_x_2411)));
          V v_m_2419 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2417, v_t_2418}));
          V v_x2_2420 = heff_tr(heff_apply(v_m_2419, 1, (V[]){v_s_2415}));
          switch (heff_tag_of(v_x2_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x2_2420, 0);
            V v_s_2422 = heff_field(v_x2_2420, 1);
            V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
            V v_e_2423 = (g_heff_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_as_243)));
            V v_t_2424 = heff_tag_at(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
            V v_t_2425 = (g_heff_2eir_2esizeW(MK_INT(0LL), v_t_2424));
            V v_lim_2426 = heff_intAdd(v_t_2425, heff_dup(g_heff_2esimplify_2ebudget_get()));
            V v_t_2427 = heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_2421), NTAG(TAG_Nil)});
            V v_a_2428 = (g_heff_2eir_2esizeB(heff_dup(v_lim_2426), MK_INT(0LL), v_t_2427));
            V v_x1_2429 = heff_intLt(v_lim_2426, v_a_2428);
            V v_t_2430;
            switch (heff_tag_of(v_x1_2429)) {
            case TAG_True: {
              v_t_2430 = NTAG(TAG_False);
              break;
            }
            case TAG_False: {
              v_t_2430 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x1_2429);
            }
            switch (heff_tag_of(v_t_2430)) {
            case TAG_True: {
              heff_drop(v_f_241);
              heff_drop(v_s_244);
              V v_t_2431 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
              V v_t_2432 = heff_strAppend(v_g_242, heff_strAppend(((V)&g_heff_2esimplify_2eplainCall_str1), heff_intShow(v_t_2431)));
              V v_m_2433 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2eremember_clo), 2, (V[]){v_t_2432, heff_tag(TAG_Inlined, 2, (V[]){heff_dup(v_x_2411), heff_dup(v_x_2421)})}));
              V v_x2_2434 = heff_tr(heff_apply(v_m_2433, 1, (V[]){v_s_2422}));
              switch (heff_tag_of(v_x2_2434)) {
              case TAG_MkPair: {
                V v_s_2436 = heff_field(v_x2_2434, 1);
                heff_take_n(v_x2_2434, 2ULL, 2);
                V v_t_2437 = (g_heff_2esimplify_2ezipL(v_x_2411, v_as_243));
                V v_m_2438 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2437; V r_ = (g_prelude_2efoldl_24s519(a_0, a_1)); heff_drop(v_t_2437); r_; });
                V v_t_2439 = (g_map_2esize(v_m_2438));
                V v_t_2440 = heff_intEq(v_t_2439, MK_INT(0LL));
                V v_x_2441;
                switch (heff_tag_of(v_t_2440)) {
                case TAG_True: {
                  heff_drop(v_m_2438);
                  v_x_2441 = v_x_2421;
                  break;
                }
                case TAG_False: {
                  v_x_2441 = ({ V a_0 = v_m_2438; V a_1 = v_x_2421; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2438); r_; });
                  break;
                }
                default: heff_nomatch(v_t_2440);
                }
                return heff_tag_at(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_x_2441, v_s_2436});
              }
              default: return heff_nomatch(v_x2_2434);
              }
            }
            case TAG_False: {
              heff_drop(v_x_2411);
              heff_drop(v_x_2421);
              V v_t_2442 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
              V v_t_2443 = heff_strAppend(v_g_242, heff_strAppend(((V)&g_heff_2esimplify_2eplainCall_str2), heff_intShow(v_t_2442)));
              V v_m_2444 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2eremember_clo), 2, (V[]){v_t_2443, NTAG(TAG_NotInlined)}));
              V v_t_2445 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_2422), LBL_supply), heff_get(heff_dup(v_s_2422), LBL_fuel), heff_get(heff_dup(v_s_244), LBL_defs), heff_get(heff_dup(v_s_244), LBL_safe), heff_get(v_s_244, LBL_total), heff_get(heff_dup(v_s_2422), LBL_plain), heff_get(v_s_2422, LBL_sp)});
              V v_x2_2446 = heff_tr(heff_apply(v_m_2444, 1, (V[]){v_t_2445}));
              switch (heff_tag_of(v_x2_2446)) {
              case TAG_MkPair: {
                V v_s_2448 = heff_field(v_x2_2446, 1);
                heff_take_n(v_x2_2446, 2ULL, 2);
                V v_x_2449 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
                return heff_tag_at(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_x_2449, v_s_2448});
              }
              default: return heff_nomatch(v_x2_2446);
              }
            }
            default: return heff_nomatch(v_t_2430);
            }
          }
          default: return heff_nomatch(v_x2_2420);
          }
        }
        default: return heff_nomatch(v_x_2414);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  case TAG_Just: {
    V v_it1_2450 = heff_field(v_it_247, 0);
    heff_take_n(v_it_247, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_242);
    switch (heff_tag_of(v_it1_2450)) {
    case TAG_Inlined: {
      V v_ps_2451 = heff_field(v_it1_2450, 0);
      V v_e_2452 = heff_field(v_it1_2450, 1);
      V v_ru_24it1_2450_24Inlined = heff_take_reuse_n(v_it1_2450, 3ULL, 2);
      V v_t_2453 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_244), LBL_fuel));
      switch (heff_tag_of(v_t_2453)) {
      case TAG_True: {
        heff_drop(v_f_241);
        V v_t_2454 = heff_intSub(heff_get(heff_dup(v_s_244), LBL_fuel), MK_INT(1LL));
        V v_s_2455 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_244), LBL_supply), v_t_2454, heff_get(heff_dup(v_s_244), LBL_defs), heff_get(heff_dup(v_s_244), LBL_safe), heff_get(heff_dup(v_s_244), LBL_total), heff_get(heff_dup(v_s_244), LBL_plain), heff_get(v_s_244, LBL_sp)});
        V v_x2_2456 = (g_heff_2eir_2efreshGo_24s504(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_2455), LBL_supply), v_e_2452));
        V v_x2_2460;
        switch (heff_tag_of(v_x2_2456)) {
        case TAG_MkPair: {
          V v_e_27_2457 = heff_field(v_x2_2456, 0);
          V v_n_2458 = heff_field(v_x2_2456, 1);
          heff_take_n(v_x2_2456, 3ULL, 2);
          V v_t_2459 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n_2458, heff_get(heff_dup(v_s_2455), LBL_fuel), heff_get(heff_dup(v_s_2455), LBL_defs), heff_get(heff_dup(v_s_2455), LBL_safe), heff_get(heff_dup(v_s_2455), LBL_total), heff_get(heff_dup(v_s_2455), LBL_plain), heff_get(v_s_2455, LBL_sp)});
          v_x2_2460 = heff_tag_at(v_ru_24it1_2450_24Inlined, TAG_MkPair, 2, (V[]){v_e_27_2457, v_t_2459});
          break;
        }
        default: heff_nomatch(v_x2_2456);
        }
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_MkPair: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          V v_s_2462 = heff_field(v_x2_2460, 1);
          V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
          V v_t_2463 = (g_heff_2esimplify_2ezipL(v_ps_2451, v_as_243));
          V v_m_2464 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2463; V r_ = (g_prelude_2efoldl_24s519(a_0, a_1)); heff_drop(v_t_2463); r_; });
          V v_t_2465 = (g_map_2esize(v_m_2464));
          V v_t_2466 = heff_intEq(v_t_2465, MK_INT(0LL));
          V v_x_2467;
          switch (heff_tag_of(v_t_2466)) {
          case TAG_True: {
            heff_drop(v_m_2464);
            v_x_2467 = v_x_2461;
            break;
          }
          case TAG_False: {
            v_x_2467 = ({ V a_0 = v_m_2464; V a_1 = v_x_2461; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2464); r_; });
            break;
          }
          default: heff_nomatch(v_t_2466);
          }
          return heff_tag_at(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){v_x_2467, v_s_2462});
        }
        default: return heff_nomatch(v_x2_2460);
        }
      }
      case TAG_False: {
        heff_drop(v_ps_2451);
        heff_drop(v_e_2452);
        V v_x_2468 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at(v_ru_24it1_2450_24Inlined, TAG_MkPair, 2, (V[]){v_x_2468, v_s_244});
      }
      default: return heff_nomatch(v_t_2453);
      }
    }
    case TAG_NotInlined: {
      V v_x_2469 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2469, v_s_244});
    }
    default: return heff_nomatch(v_it1_2450);
    }
  }
  default: return heff_nomatch(v_it_247);
  }
}
V g_heff_2esimplify_2eplainCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eplainCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esimplify_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ecallOf_entry, 5, 0};

V g_heff_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
  }
  case TAG_Just: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EGlobal: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x51_245, 0);
      V v_t_2410 = (g_prelude_2emap_24s518(heff_dup(v_as_243)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2412 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_248));
        V v_t_2413 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
        V v_t_2414 = heff_intEq(v_t_2412, v_t_2413);
        switch (heff_tag_of(v_t_2414)) {
        case TAG_True: {
          return heff_tail(((V)&g_heff_2esimplify_2eplainCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
        case TAG_False: {
          return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      case TAG_False: {
        return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_EApp: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELet: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ERecord: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EProj: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ETag: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EMatch: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrim: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrimCall: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ECall: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EInt: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EStr: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EAbandon: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFix: {
      return heff_tail(((V)&g_heff_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esimplify_2ecallOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2ecallOf(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
V g_heff_2esimplify_2eapplyLam_lam0(V self, V *args);
Clo g_heff_2esimplify_2eapplyLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eapplyLam_entry, 4, 0};

V g_heff_2esimplify_2eapplyLam(V v_r_240, V v_xs_241, V v_b_242, V v_as_243) {
top: ;
  V v_a_244 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
  V v_b_245 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
  V v_t_246 = heff_intLe(heff_dup(v_a_244), heff_dup(v_b_245));
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_b_245);
    v_t_247 = v_a_244;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_244);
    v_t_247 = v_b_245;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = (g_heff_2esimplify_2etakeL(v_t_247, heff_dup(v_xs_241)));
  V v_a_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
  V v_b_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
  V v_t_2411 = heff_intLe(heff_dup(v_a_249), heff_dup(v_b_2410));
  V v_t_2412;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_b_2410);
    v_t_2412 = v_a_249;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_249);
    v_t_2412 = v_b_2410;
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_t_2413 = (g_heff_2esimplify_2etakeL(v_t_2412, heff_dup(v_as_243)));
  V v_t_2414 = (g_heff_2esimplify_2ezipL(v_t_248, v_t_2413));
  V v_a_2415 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
  V v_a_2416 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
  V v_b_2417 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
  V v_t_2418 = heff_intLe(heff_dup(v_a_2416), heff_dup(v_b_2417));
  V v_b_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_b_2417);
    v_b_2419 = v_a_2416;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_2416);
    v_b_2419 = v_b_2417;
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_t_2420 = heff_intLt(v_b_2419, v_a_2415);
  V v_t_2426;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    V v_a_2421 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_241));
    V v_b_2422 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
    V v_t_2423 = heff_intLe(heff_dup(v_a_2421), heff_dup(v_b_2422));
    V v_t_2424;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_b_2422);
      v_t_2424 = v_a_2421;
      break;
    }
    case TAG_False: {
      heff_drop(v_a_2421);
      v_t_2424 = v_b_2422;
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_t_2425 = (g_heff_2esimplify_2edropL(v_t_2424, heff_dup(v_xs_241)));
    v_t_2426 = heff_tag(TAG_ELam, 2, (V[]){v_t_2425, v_b_242});
    break;
  }
  case TAG_False: {
    v_t_2426 = v_b_242;
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_t_2427 = ({ V a_0 = v_t_2414; V a_1 = v_t_2426; V r_ = (g_heff_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_m_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_t_2427}));
  return heff_clo(g_heff_2esimplify_2eapplyLam_lam0, 1, 4, (V[]){v_m_2428, v_xs_241, v_as_243, v_r_240});
}
V g_heff_2esimplify_2eapplyLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eapplyLam(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2eapplyLam_lam0(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_apply(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_a_2433 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_241; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_241); r_; });
    V v_b_2434 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_243));
    V v_t_2435 = heff_intLe(heff_dup(v_a_2433), heff_dup(v_b_2434));
    V v_t_2436;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_b_2434);
      v_t_2436 = v_a_2433;
      break;
    }
    case TAG_False: {
      heff_drop(v_a_2433);
      v_t_2436 = v_b_2434;
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2437 = (g_heff_2esimplify_2edropL(v_t_2436, v_as_243));
    return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2431, v_t_2437, v_s_2432});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
Clo g_heff_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        V v_t_249 = heff_strEq(heff_dup(v_x_244), heff_dup(v_y_248));
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_False: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2evarsAre(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}

static V g_heff_2esimplify_2especArgSize_val;
static int g_heff_2esimplify_2especArgSize_st;
static V g_heff_2esimplify_2especArgSize_init(void) {
  return MK_INT(60LL);
}
V g_heff_2esimplify_2especArgSize_get(void) {
  if (g_heff_2esimplify_2especArgSize_st == 2) return g_heff_2esimplify_2especArgSize_val;
  if (g_heff_2esimplify_2especArgSize_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especArgSize_st = 1;
  g_heff_2esimplify_2especArgSize_val = heff_tr(g_heff_2esimplify_2especArgSize_init());
  g_heff_2esimplify_2especArgSize_st = 2;
  return g_heff_2esimplify_2especArgSize_val;
}

static V g_heff_2esimplify_2especBodySize_val;
static int g_heff_2esimplify_2especBodySize_st;
static V g_heff_2esimplify_2especBodySize_init(void) {
  return MK_INT(1200LL);
}
V g_heff_2esimplify_2especBodySize_get(void) {
  if (g_heff_2esimplify_2especBodySize_st == 2) return g_heff_2esimplify_2especBodySize_val;
  if (g_heff_2esimplify_2especBodySize_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especBodySize_st = 1;
  g_heff_2esimplify_2especBodySize_val = heff_tr(g_heff_2esimplify_2especBodySize_init());
  g_heff_2esimplify_2especBodySize_st = 2;
  return g_heff_2esimplify_2especBodySize_val;
}

static V g_heff_2esimplify_2especLimit_val;
static int g_heff_2esimplify_2especLimit_st;
static V g_heff_2esimplify_2especLimit_init(void) {
  return MK_INT(2000LL);
}
V g_heff_2esimplify_2especLimit_get(void) {
  if (g_heff_2esimplify_2especLimit_st == 2) return g_heff_2esimplify_2especLimit_val;
  if (g_heff_2esimplify_2especLimit_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especLimit_st = 1;
  g_heff_2esimplify_2especLimit_val = heff_tr(g_heff_2esimplify_2especLimit_init());
  g_heff_2esimplify_2especLimit_st = 2;
  return g_heff_2esimplify_2especLimit_val;
}

static V g_heff_2esimplify_2especDepth_val;
static int g_heff_2esimplify_2especDepth_st;
static V g_heff_2esimplify_2especDepth_init(void) {
  return MK_INT(16LL);
}
V g_heff_2esimplify_2especDepth_get(void) {
  if (g_heff_2esimplify_2especDepth_st == 2) return g_heff_2esimplify_2especDepth_val;
  if (g_heff_2esimplify_2especDepth_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2especDepth_st = 1;
  g_heff_2esimplify_2especDepth_val = heff_tr(g_heff_2esimplify_2especDepth_init());
  g_heff_2esimplify_2especDepth_st = 2;
  return g_heff_2esimplify_2especDepth_val;
}
Clo g_heff_2esimplify_2eknownArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eknownArg_entry, 2, 0};

V g_heff_2esimplify_2eknownArg(V v_kinds_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s9(v_g_243, v_kinds_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tag_at(v_ru_24x2_241_24ELam, TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){heff_dup(v_xs_246), heff_dup(v_b_247)}), NTAG(TAG_Nil)});
    V v_a_249 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_248));
    V v_x1_2410 = heff_intLt(heff_dup(g_heff_2esimplify_2especArgSize_get()), v_a_249);
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_True: {
      heff_drop(v_xs_246);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag(TAG_ELam, 2, (V[]){v_xs_246, v_b_247}); V r_ = (g_heff_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24x2_241_24ERecord, TAG_ERecord, 1, (V[]){heff_dup(v_fs_2416)}), NTAG(TAG_Nil)});
    V v_a_2418 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_2417));
    V v_x1_2419 = heff_intLt(heff_dup(g_heff_2esimplify_2especArgSize_get()), v_a_2418);
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_True: {
      heff_drop(v_fs_2416);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag(TAG_ERecord, 1, (V[]){v_fs_2416}); V r_ = (g_heff_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
    default: return heff_nomatch(v_x1_2419);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eknownArg_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2eknownArg(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2esimplify_2enthE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2enthE_entry, 2, 0};

V g_heff_2esimplify_2enthE(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2enthE_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2enthE(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emarkGo_entry, 4, 0};

V g_heff_2esimplify_2emarkGo(V v_all_240, V v_as_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_st_244)) {
    case TAG_True: {
      V v_x3_246 = (g_heff_2esimplify_2enthE(heff_dup(v_i_243), v_as_241));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        v_t_248 = (g_heff_2esimplify_2eknownArg(v_all_240, v_x_247));
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_st_244);
    }
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2esimplify_2emarkGo(v_all_240, v_as_241, v_rest_245, heff_intAdd(v_i_243, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2emarkGo(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2esimplify_2ekeepParams(V v_x1_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_xs_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_xs_241, 0);
      V v_xs2_245 = heff_field(v_xs_241, 1);
      heff_take_n(v_xs_241, 3ULL, 2);
      switch (heff_tag_of(v_m_242)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs2_245;
        v_x1_240 = t_0;
        v_xs_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_heff_2esimplify_2ekeepParams(v_ms_243, v_xs2_245))});
      }
      default: return heff_nomatch(v_m_242);
      }
    }
    default: return heff_nomatch(v_xs_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ekeepParams(a[0], a[1]);
}
V g_heff_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo(g_heff_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo(g_heff_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo(g_heff_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_as_2412 = heff_field(v_x3_242, 1);
        switch (heff_tag_of(v_m_245)) {
        case TAG_True: {
          V v_m_2413 = (g_heff_2esimplify_2esubstCopies(v_x_248, heff_dup(v_a_2411), v_e_243));
          return heff_clo(g_heff_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_as_2412)});
        }
        case TAG_False: {
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_as_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_m_245);
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2esubstMarked(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_as_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_as_2412; V a_3 = v_x_2416; V r_ = (g_heff_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_as_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2esimplify_2epushSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epushSpec_entry, 3, 0};

V g_heff_2esimplify_2epushSpec(V v_k_240, V v_h_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
  V v_t_245 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_specs);
  V v_t_246 = (g_map_2einsert_24s7(heff_dup(v_k_240), v_h_241, v_t_245));
  V v_t_247 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_made);
  V v_t_248 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_count);
  V v_t_249 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_within);
  V v_t_2410 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_trying);
  V v_p_2411 = heff_rec(7, shape_5_155_316_184_52_375_350, (V[]){v_t_243, v_t_244, v_t_246, v_t_247, heff_intAdd(v_t_248, MK_INT(1LL)), heff_tag(TAG_Cons, 2, (V[]){v_k_240, v_t_249}), v_t_2410});
  V v_t_2412 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(v_s_242, LBL_plain), v_p_2411});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2412});
}
V g_heff_2esimplify_2epushSpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2epushSpec(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2epreKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epreKnown_entry, 3, 0};

V g_heff_2esimplify_2epreKnown(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_a_244 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_243));
  V v_x1_245 = heff_intLt(heff_dup(g_heff_2esimplify_2especBodySize_get()), v_a_244);
  V v_t_247;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    v_t_247 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
    break;
  }
  case TAG_False: {
    V v_t_246 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
    v_t_247 = (g_map_2einsert_24s7(heff_dup(v_h_240), heff_dup(v_b_241), v_t_246));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_t_2434;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2436;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_True: {
    V v_t_2435 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
    v_t_2436 = (g_map_2einsert_24s7(v_h_240, NTAG(TAG_MkUnit), v_t_2435));
    break;
  }
  case TAG_False: {
    heff_drop(v_h_240);
    v_t_2436 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  V v_t_2437 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_specs);
  V v_t_2438 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_made);
  V v_t_2439 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_count);
  V v_t_2440 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_within);
  V v_t_2441 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_trying);
  V v_p_2442 = heff_rec(7, shape_5_155_316_184_52_375_350, (V[]){v_t_247, v_t_2436, v_t_2437, v_t_2438, v_t_2439, v_t_2440, v_t_2441});
  V v_t_2443 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(v_s_242, LBL_plain), v_p_2442});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2443});
}
V g_heff_2esimplify_2epreKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2epreKnown(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2emarkSafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emarkSafe_entry, 3, 0};

V g_heff_2esimplify_2emarkSafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_2431;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_b_241, 0);
    V v_t_2413 = (g_prelude_2emap_24s511(heff_dup(v_fs_2412)));
    v_t_2431 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2413); r_; });
    break;
  }
  case TAG_EProj: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    V v_as_2417 = heff_field(v_b_241, 1);
    V v_t_2418 = (g_prelude_2emap_24s512(heff_dup(v_as_2417)));
    v_t_2431 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2418); r_; });
    break;
  }
  case TAG_EMatch: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2435;
  switch (heff_tag_of(v_t_2431)) {
  case TAG_True: {
    V v_t_2432 = (g_map_2einsert_24s7(v_h_240, NTAG(TAG_MkUnit), heff_get(heff_dup(v_s_242), LBL_safe)));
    v_t_2435 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), v_t_2432, heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
    break;
  }
  case TAG_False: {
    V v_t_2433 = ({ V b_0 = heff_get(heff_dup(v_s_242), LBL_safe); V b_1 = heff_get(heff_dup(v_s_242), LBL_total); V a_2 = v_b_241; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      V v_t_2434 = (g_map_2einsert_24s7(v_h_240, NTAG(TAG_MkUnit), heff_get(heff_dup(v_s_242), LBL_safe)));
      v_t_2435 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), v_t_2434, heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
      break;
    }
    case TAG_False: {
      heff_drop(v_h_240);
      v_t_2435 = v_s_242;
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    break;
  }
  default: heff_nomatch(v_t_2431);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2435});
}
V g_heff_2esimplify_2emarkSafe_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2emarkSafe(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2epopSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epopSpec_entry, 3, 0};

V g_heff_2esimplify_2epopSpec(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
  V v_t_244 = (g_map_2einsert_24s7(heff_dup(v_h_240), heff_dup(v_b_241), v_t_243));
  V v_t_245 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
  V v_t_246 = (g_map_2einsert_24s7(heff_dup(v_h_240), NTAG(TAG_MkUnit), v_t_245));
  V v_t_247 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_specs);
  V v_t_248 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_made);
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_152_198_28, (V[]){heff_dup(v_h_240), v_h_240, v_b_241}), v_t_248});
  V v_t_2410 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_count);
  V v_t_2411 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_within);
  V v_t_2412 = (g_prelude_2edrop(MK_INT(1LL), v_t_2411));
  V v_t_2413 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_trying);
  V v_p_2414 = heff_rec(7, shape_5_155_316_184_52_375_350, (V[]){v_t_244, v_t_246, v_t_247, v_t_249, v_t_2410, v_t_2412, v_t_2413});
  V v_t_2415 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(v_s_242, LBL_plain), v_p_2414});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2415});
}
V g_heff_2esimplify_2epopSpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2epopSpec(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2especBody_lam0(V self, V *args);
V g_heff_2esimplify_2especBody_lam1(V self, V *args);
V g_heff_2esimplify_2especBody_lam2(V self, V *args);
V g_heff_2esimplify_2especBody_lam3(V self, V *args);
V g_heff_2esimplify_2especBody_lam4(V self, V *args);
V g_heff_2esimplify_2especBody_lam5(V self, V *args);
V g_heff_2esimplify_2especBody_lam6(V self, V *args);
V g_heff_2esimplify_2especBody_lam7(V self, V *args);
V g_heff_2esimplify_2especBody_lam8(V self, V *args);
V g_heff_2esimplify_2especBody_lam9(V self, V *args);
V g_heff_2esimplify_2especBody_lam10(V self, V *args);
V g_heff_2esimplify_2especBody_lam11(V self, V *args);
V g_heff_2esimplify_2especBody_lam12(V self, V *args);
V g_heff_2esimplify_2especBody_lam13(V self, V *args);
V g_heff_2esimplify_2especBody_lam14(V self, V *args);
V g_heff_2esimplify_2especBody_lam15(V self, V *args);
V g_heff_2esimplify_2especBody_lam16(V self, V *args);
Clo g_heff_2esimplify_2especBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especBody_entry, 5, 0};

V g_heff_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_as_243, V v_lam1_244) {
top: ;
  switch (heff_tag_of(v_lam1_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam0, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam1, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELam: {
    V v_xs1_249 = heff_field(v_lam1_244, 0);
    V v_b1_2410 = heff_field(v_lam1_244, 1);
    heff_take_n(v_lam1_244, 3ULL, 2);
    V v_t_2411 = (g_heff_2espec_2eselfTo(v_g_240, v_h_241, heff_dup(v_marks_242), v_b1_2410));
    V v_m_2412 = (g_heff_2esimplify_2esubstMarked(heff_dup(v_marks_242), heff_dup(v_xs1_249), v_as_243, v_t_2411));
    return heff_clo(g_heff_2esimplify_2especBody_lam2, 1, 3, (V[]){v_m_2412, v_marks_242, v_xs1_249});
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam3, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam4, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam5, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam6, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam7, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam8, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam9, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam10, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam11, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam12, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam13, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam14, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam15, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    return heff_clo(g_heff_2esimplify_2especBody_lam16, 1, 1, (V[]){v_lam1_244});
  }
  default: return heff_nomatch(v_lam1_244);
  }
}
V g_heff_2esimplify_2especBody_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2especBody(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
V g_heff_2esimplify_2especBody_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_246});
}
V g_heff_2esimplify_2especBody_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_248});
}
V g_heff_2esimplify_2especBody_lam2(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_marks_242 = heff_env(self)[1];
  V v_xs1_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_x1_2417 = (g_heff_2esimplify_2ekeepParams(heff_dup(v_marks_242), heff_dup(v_xs1_249)));
    V v_x_2421;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      heff_drop(v_marks_242);
      heff_drop(v_xs1_249);
      heff_drop_cell(v_ru_24x2_2414_24MkPair, 2);
      v_x_2421 = v_x_2415;
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2417, 0ULL, 2);
      V v_t_2420 = (g_heff_2esimplify_2ekeepParams(v_marks_242, v_xs1_249));
      v_x_2421 = heff_tag_at(v_ru_24x2_2414_24MkPair, TAG_ELam, 2, (V[]){v_t_2420, v_x_2415});
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2421, v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2esimplify_2especBody_lam3(V self, V *args) {
  V v_s_2424 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2424});
}
V g_heff_2esimplify_2especBody_lam4(V self, V *args) {
  V v_s_2428 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2428});
}
V g_heff_2esimplify_2especBody_lam5(V self, V *args) {
  V v_s_2430 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2430});
}
V g_heff_2esimplify_2especBody_lam6(V self, V *args) {
  V v_s_2433 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2433});
}
V g_heff_2esimplify_2especBody_lam7(V self, V *args) {
  V v_s_2436 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2436});
}
V g_heff_2esimplify_2especBody_lam8(V self, V *args) {
  V v_s_2439 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2439});
}
V g_heff_2esimplify_2especBody_lam9(V self, V *args) {
  V v_s_2441 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2441});
}
V g_heff_2esimplify_2especBody_lam10(V self, V *args) {
  V v_s_2444 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2444});
}
V g_heff_2esimplify_2especBody_lam11(V self, V *args) {
  V v_s_2447 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2447});
}
V g_heff_2esimplify_2especBody_lam12(V self, V *args) {
  V v_s_2449 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2449});
}
V g_heff_2esimplify_2especBody_lam13(V self, V *args) {
  V v_s_2451 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2451});
}
V g_heff_2esimplify_2especBody_lam14(V self, V *args) {
  V v_s_2453 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2453});
}
V g_heff_2esimplify_2especBody_lam15(V self, V *args) {
  V v_s_2454 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2454});
}
V g_heff_2esimplify_2especBody_lam16(V self, V *args) {
  V v_s_2457 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2457});
}
Clo g_heff_2esimplify_2echeap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2echeap_entry, 2, 0};

V g_heff_2esimplify_2echeap(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    V v_x3_244 = ({ V a_0 = heff_dup(v_g_243); V a_1 = v_safe_240; V r_ = (g_map_2elookup_24s9(a_0, a_1)); heff_drop(v_safe_240); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_b_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2esimplify_2echeap(heff_dup(v_safe_240), v_a_2411));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      V t_0 = v_safe_240;
      V t_1 = v_b_2412;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x2_241, 0);
    V v_t_2415 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2416 = (g_prelude_2emap_24s513(heff_dup(v_fs_2414)));
    V v_t_2417 = (g_prelude_2emap(v_t_2415, v_t_2416));
    return ({ V a_0 = v_t_2417; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    V t_0 = v_safe_240;
    V t_1 = v_e_2418;
    v_safe_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2423 = (g_prelude_2emap(v_t_2422, heff_dup(v_as_2421)));
    return ({ V a_0 = v_t_2423; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2423); r_; });
  }
  case TAG_EMatch: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2427 = heff_field(v_x2_241, 0);
    V v_as_2428 = heff_field(v_x2_241, 1);
    V v_x1_2429 = ({ V a_0 = heff_dup(v_p_2427); V b_1 = heff_dup(g_heff_2esimplify_2efailing_get()); V r_ = (g_heff_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2429)) {
    case TAG_True: {
      heff_drop(v_safe_240);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_t_2430 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
      V v_t_2431 = (g_prelude_2emap(v_t_2430, heff_dup(v_as_2428)));
      return ({ V a_0 = v_t_2431; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2431); r_; });
    }
    default: return heff_nomatch(v_x1_2429);
    }
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2echeap_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2echeap(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2elamsOut_entry, 2, 0};

V g_heff_2esimplify_2elamsOut(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_x2_241, 0);
    heff_drop(v_safe_240);
    HEFF_LAST return g_prelude_2efoldl_24s1(MK_INT(0LL), v_ys_244);
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2esimplify_2echeap(heff_dup(v_safe_240), v_a_249));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V t_0 = v_safe_240;
      V t_1 = v_b_2410;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2417 = heff_field(v_x2_241, 0);
    V v_arms_2418 = heff_field(v_x2_241, 1);
    V v_t_2419 = (g_heff_2esimplify_2echeap(heff_dup(v_safe_240), v_sc_2417));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      V v_x1_2422;
      switch (heff_tag_of(v_arms_2418)) {
      case TAG_Nil: {
        v_x1_2422 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_2422 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_arms_2418);
      }
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_True: {
        heff_drop(v_safe_240);
        return MK_INT(0LL);
      }
      case TAG_False: {
        V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2elamsOut_clo), 1, (V[]){v_safe_240}));
        V v_t_2424 = (g_prelude_2emap_24s515(heff_dup(v_arms_2418)));
        V v_x1_2425 = (g_prelude_2emap(v_t_2423, v_t_2424));
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2426 = heff_field(v_x1_2425, 0);
          V v_xs_2427 = heff_field(v_x1_2425, 1);
          heff_take_n(v_x1_2425, 3ULL, 2);
          return ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s524(a_0, a_1)); heff_drop(v_xs_2427); r_; });
        }
        default: return heff_nomatch(v_x1_2425);
        }
      }
      default: return heff_nomatch(v_x1_2422);
      }
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2elamsOut(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esimplify_2estripLams_lam0(V self, V *args);
Clo g_heff_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_246 = (g_prelude_2emap_24s521(heff_dup(v_zs_240)));
    V v_t_247 = (g_heff_2esimplify_2ezipL(heff_dup(v_ys_244), v_as_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_prelude_2efoldl_24s519(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_a_249 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ys_244));
    V v_b_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_zs_240));
    V v_t_2411 = heff_intLt(v_b_2410, v_a_249);
    V v_e_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = v_zs_240; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_zs_240); r_; });
      V v_t_2413 = (g_heff_2esimplify_2edropL(v_t_2412, v_ys_244));
      v_e_2414 = heff_tag_at(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_b_245});
      break;
    }
    case TAG_False: {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2414 = v_b_245;
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2415 = (g_map_2esize(v_m_248));
    V v_t_2416 = heff_intEq(v_t_2415, MK_INT(0LL));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_m_248);
      return v_e_2414;
    }
    case TAG_False: {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2414; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  case TAG_EApp: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_e_241, 0);
    V v_a_2420 = heff_field(v_e_241, 1);
    V v_b_2421 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    return heff_tag_at(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_a_2420, (g_heff_2esimplify_2estripLams(v_zs_240, v_b_2421))});
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2427 = heff_field(v_e_241, 0);
    V v_arms_2428 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2429 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    return heff_tag_at(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2427, (g_prelude_2emap(heff_clo(g_heff_2esimplify_2estripLams_lam0, 1, 1, (V[]){v_go_2429}), v_arms_2428))});
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2estripLams(a[0], a[1]);
}
V g_heff_2esimplify_2estripLams_lam0(V self, V *args) {
  V v_x2_2430 = args[0];
  V v_go_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkArm: {
    V v_t_2431 = heff_field(v_x2_2430, 0);
    V v_vs_2432 = heff_field(v_x2_2430, 1);
    V v_b_2433 = heff_field(v_x2_2430, 2);
    V v_ru_24x2_2430_24MkArm = heff_take_reuse_n(v_x2_2430, 7ULL, 3);
    V v_t_2434 = heff_tr(heff_apply(v_go_2429, 1, (V[]){v_b_2433}));
    return heff_tag_at(v_ru_24x2_2430_24MkArm, TAG_MkArm, 3, (V[]){v_t_2431, v_vs_2432, v_t_2434});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
Clo g_heff_2esimplify_2eraise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eraise_entry, 2, 0};

V g_heff_2esimplify_2eraise(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_244 = heff_intEq(v_t_243, MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_245 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_246 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_245}));
      V v_x2_247 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        V v_x_2410 = heff_tag_at(v_ru_24x2_247_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_248), (g_heff_2esimplify_2estripLams(v_x_248, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_2412 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2413 = heff_intEq(v_t_2412, MK_INT(0LL));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2414 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2415 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2414}));
      V v_x2_2416 = heff_tr(heff_apply(v_m_2415, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
        V v_x_2419 = heff_tag_at(v_ru_24x2_2416_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2417), (g_heff_2esimplify_2estripLams(v_x_2417, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_ELam: {
    V v_xs_2420 = heff_field(v_e_240, 0);
    V v_b_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2422 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_b_2421));
    V v_t_2423 = heff_intEq(v_t_2422, MK_INT(0LL));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_2420, v_b_2421}), v_p_241});
    }
    case TAG_False: {
      V v_t_2424 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_b_2421));
      V v_m_2425 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2424}));
      V v_x2_2426 = heff_tr(heff_apply(v_m_2425, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        V v_s_2428 = heff_field(v_x2_2426, 1);
        V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
        V v_t_2429 = (g_heff_2esimplify_2eappendL(v_xs_2420, heff_dup(v_x_2427)));
        V v_x_2430 = heff_tag_at(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2429, (g_heff_2esimplify_2estripLams(v_x_2427, v_b_2421))});
        return heff_tag_at(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){v_x_2430, v_s_2428});
      }
      default: return heff_nomatch(v_x2_2426);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_EApp: {
    V v_t_2433 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2434 = heff_intEq(v_t_2433, MK_INT(0LL));
    switch (heff_tag_of(v_t_2434)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2435 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2436 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2435}));
      V v_x2_2437 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2437)) {
      case TAG_MkPair: {
        V v_x_2438 = heff_field(v_x2_2437, 0);
        V v_s_2439 = heff_field(v_x2_2437, 1);
        V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
        V v_x_2440 = heff_tag_at(v_ru_24x2_2437_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2438), (g_heff_2esimplify_2estripLams(v_x_2438, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2439});
      }
      default: return heff_nomatch(v_x2_2437);
      }
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  case TAG_ELet: {
    V v_t_2444 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2445 = heff_intEq(v_t_2444, MK_INT(0LL));
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2446 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2447 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2446}));
      V v_x2_2448 = heff_tr(heff_apply(v_m_2447, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_MkPair: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        V v_s_2450 = heff_field(v_x2_2448, 1);
        V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
        V v_x_2451 = heff_tag_at(v_ru_24x2_2448_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2449), (g_heff_2esimplify_2estripLams(v_x_2449, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2451, v_s_2450});
      }
      default: return heff_nomatch(v_x2_2448);
      }
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_ERecord: {
    V v_t_2453 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2454 = heff_intEq(v_t_2453, MK_INT(0LL));
    switch (heff_tag_of(v_t_2454)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2455 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2456 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2455}));
      V v_x2_2457 = heff_tr(heff_apply(v_m_2456, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_s_2459 = heff_field(v_x2_2457, 1);
        V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
        V v_x_2460 = heff_tag_at(v_ru_24x2_2457_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2458), (g_heff_2esimplify_2estripLams(v_x_2458, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2460, v_s_2459});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  case TAG_EProj: {
    V v_t_2463 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2464 = heff_intEq(v_t_2463, MK_INT(0LL));
    switch (heff_tag_of(v_t_2464)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2465 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2466 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2465}));
      V v_x2_2467 = heff_tr(heff_apply(v_m_2466, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2467)) {
      case TAG_MkPair: {
        V v_x_2468 = heff_field(v_x2_2467, 0);
        V v_s_2469 = heff_field(v_x2_2467, 1);
        V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
        V v_x_2470 = heff_tag_at(v_ru_24x2_2467_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2468), (g_heff_2esimplify_2estripLams(v_x_2468, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2470, v_s_2469});
      }
      default: return heff_nomatch(v_x2_2467);
      }
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  case TAG_ETag: {
    V v_t_2473 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2474 = heff_intEq(v_t_2473, MK_INT(0LL));
    switch (heff_tag_of(v_t_2474)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2475 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2476 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2475}));
      V v_x2_2477 = heff_tr(heff_apply(v_m_2476, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
        V v_x_2480 = heff_tag_at(v_ru_24x2_2477_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2478), (g_heff_2esimplify_2estripLams(v_x_2478, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2480, v_s_2479});
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
    default: return heff_nomatch(v_t_2474);
    }
  }
  case TAG_EMatch: {
    V v_t_2483 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2484 = heff_intEq(v_t_2483, MK_INT(0LL));
    switch (heff_tag_of(v_t_2484)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2485 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2486 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2485}));
      V v_x2_2487 = heff_tr(heff_apply(v_m_2486, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2487)) {
      case TAG_MkPair: {
        V v_x_2488 = heff_field(v_x2_2487, 0);
        V v_s_2489 = heff_field(v_x2_2487, 1);
        V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
        V v_x_2490 = heff_tag_at(v_ru_24x2_2487_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2488), (g_heff_2esimplify_2estripLams(v_x_2488, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2490, v_s_2489});
      }
      default: return heff_nomatch(v_x2_2487);
      }
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
  case TAG_EPrim: {
    V v_t_2492 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_2493 = heff_intEq(v_t_2492, MK_INT(0LL));
    switch (heff_tag_of(v_t_2493)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_2494 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_2495 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_2494}));
      V v_x2_2496 = heff_tr(heff_apply(v_m_2495, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_MkPair: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_s_2498 = heff_field(v_x2_2496, 1);
        V v_ru_24x2_2496_24MkPair = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
        V v_x_2499 = heff_tag_at(v_ru_24x2_2496_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2497), (g_heff_2esimplify_2estripLams(v_x_2497, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_2499, v_s_2498});
      }
      default: return heff_nomatch(v_x2_2496);
      }
    }
    default: return heff_nomatch(v_t_2493);
    }
  }
  case TAG_EPrimCall: {
    V v_t_24102 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24103 = heff_intEq(v_t_24102, MK_INT(0LL));
    switch (heff_tag_of(v_t_24103)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24104 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24105 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24104}));
      V v_x2_24106 = heff_tr(heff_apply(v_m_24105, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24106)) {
      case TAG_MkPair: {
        V v_x_24107 = heff_field(v_x2_24106, 0);
        V v_s_24108 = heff_field(v_x2_24106, 1);
        V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
        V v_x_24109 = heff_tag_at(v_ru_24x2_24106_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24107), (g_heff_2esimplify_2estripLams(v_x_24107, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24109, v_s_24108});
      }
      default: return heff_nomatch(v_x2_24106);
      }
    }
    default: return heff_nomatch(v_t_24103);
    }
  }
  case TAG_ECall: {
    V v_t_24112 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24113 = heff_intEq(v_t_24112, MK_INT(0LL));
    switch (heff_tag_of(v_t_24113)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24114 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24115 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24114}));
      V v_x2_24116 = heff_tr(heff_apply(v_m_24115, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24116)) {
      case TAG_MkPair: {
        V v_x_24117 = heff_field(v_x2_24116, 0);
        V v_s_24118 = heff_field(v_x2_24116, 1);
        V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
        V v_x_24119 = heff_tag_at(v_ru_24x2_24116_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24117), (g_heff_2esimplify_2estripLams(v_x_24117, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24119, v_s_24118});
      }
      default: return heff_nomatch(v_x2_24116);
      }
    }
    default: return heff_nomatch(v_t_24113);
    }
  }
  case TAG_EInt: {
    V v_t_24121 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24122 = heff_intEq(v_t_24121, MK_INT(0LL));
    switch (heff_tag_of(v_t_24122)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24123 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24124 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24123}));
      V v_x2_24125 = heff_tr(heff_apply(v_m_24124, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24125)) {
      case TAG_MkPair: {
        V v_x_24126 = heff_field(v_x2_24125, 0);
        V v_s_24127 = heff_field(v_x2_24125, 1);
        V v_ru_24x2_24125_24MkPair = heff_take_reuse_n(v_x2_24125, 3ULL, 2);
        V v_x_24128 = heff_tag_at(v_ru_24x2_24125_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24126), (g_heff_2esimplify_2estripLams(v_x_24126, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24128, v_s_24127});
      }
      default: return heff_nomatch(v_x2_24125);
      }
    }
    default: return heff_nomatch(v_t_24122);
    }
  }
  case TAG_EFloat: {
    V v_t_24130 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24131 = heff_intEq(v_t_24130, MK_INT(0LL));
    switch (heff_tag_of(v_t_24131)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24132 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24133 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24132}));
      V v_x2_24134 = heff_tr(heff_apply(v_m_24133, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24134)) {
      case TAG_MkPair: {
        V v_x_24135 = heff_field(v_x2_24134, 0);
        V v_s_24136 = heff_field(v_x2_24134, 1);
        V v_ru_24x2_24134_24MkPair = heff_take_reuse_n(v_x2_24134, 3ULL, 2);
        V v_x_24137 = heff_tag_at(v_ru_24x2_24134_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24135), (g_heff_2esimplify_2estripLams(v_x_24135, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24137, v_s_24136});
      }
      default: return heff_nomatch(v_x2_24134);
      }
    }
    default: return heff_nomatch(v_t_24131);
    }
  }
  case TAG_EStr: {
    V v_t_24139 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24140 = heff_intEq(v_t_24139, MK_INT(0LL));
    switch (heff_tag_of(v_t_24140)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24141 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24142 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24141}));
      V v_x2_24143 = heff_tr(heff_apply(v_m_24142, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24143)) {
      case TAG_MkPair: {
        V v_x_24144 = heff_field(v_x2_24143, 0);
        V v_s_24145 = heff_field(v_x2_24143, 1);
        V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
        V v_x_24146 = heff_tag_at(v_ru_24x2_24143_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24144), (g_heff_2esimplify_2estripLams(v_x_24144, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24146, v_s_24145});
      }
      default: return heff_nomatch(v_x2_24143);
      }
    }
    default: return heff_nomatch(v_t_24140);
    }
  }
  case TAG_EAbandon: {
    V v_t_24147 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24148 = heff_intEq(v_t_24147, MK_INT(0LL));
    switch (heff_tag_of(v_t_24148)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24149 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24150 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24149}));
      V v_x2_24151 = heff_tr(heff_apply(v_m_24150, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24151)) {
      case TAG_MkPair: {
        V v_x_24152 = heff_field(v_x2_24151, 0);
        V v_s_24153 = heff_field(v_x2_24151, 1);
        V v_ru_24x2_24151_24MkPair = heff_take_reuse_n(v_x2_24151, 3ULL, 2);
        V v_x_24154 = heff_tag_at(v_ru_24x2_24151_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24152), (g_heff_2esimplify_2estripLams(v_x_24152, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24154, v_s_24153});
      }
      default: return heff_nomatch(v_x2_24151);
      }
    }
    default: return heff_nomatch(v_t_24148);
    }
  }
  case TAG_EFix: {
    V v_t_24157 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
    V v_t_24158 = heff_intEq(v_t_24157, MK_INT(0LL));
    switch (heff_tag_of(v_t_24158)) {
    case TAG_True: {
      return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    }
    case TAG_False: {
      V v_t_24159 = (g_heff_2esimplify_2elamsOut(heff_get(heff_dup(v_p_241), LBL_safe), v_e_240));
      V v_m_24160 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2efreshParams_clo), 1, (V[]){v_t_24159}));
      V v_x2_24161 = heff_tr(heff_apply(v_m_24160, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_24161)) {
      case TAG_MkPair: {
        V v_x_24162 = heff_field(v_x2_24161, 0);
        V v_s_24163 = heff_field(v_x2_24161, 1);
        V v_ru_24x2_24161_24MkPair = heff_take_reuse_n(v_x2_24161, 3ULL, 2);
        V v_x_24164 = heff_tag_at(v_ru_24x2_24161_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24162), (g_heff_2esimplify_2estripLams(v_x_24162, v_e_240))});
        return heff_tag(TAG_MkPair, 2, (V[]){v_x_24164, v_s_24163});
      }
      default: return heff_nomatch(v_x2_24161);
      }
    }
    default: return heff_nomatch(v_t_24158);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esimplify_2eraise_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eraise(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2emakeSpec_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2emakeSpec_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2emakeSpec_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2emakeSpec_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2emakeSpec_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2esimplify_2emakeSpec_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 115}};
Clo g_heff_2esimplify_2emakeSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2emakeSpec_entry, 8, 0};

V g_heff_2esimplify_2emakeSpec(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_k_246, V v_s_247) {
top: ;
  V v_t_248 = heff_get(heff_get(heff_dup(v_s_247), LBL_sp), LBL_count);
  V v_t_249 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2emakeSpec_str0), heff_intShow(v_t_248)));
  V v_x2_2410 = (g_heff_2esimplify_2epushSpec(v_k_246, v_t_249, heff_dup(v_s_247)));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 2ULL, 2);
    V v_x2_2413 = (g_heff_2eir_2efreshGo_24s504(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_2412), LBL_supply), heff_tag_at(v_ru_24x2_2410_24MkPair, TAG_ELam, 2, (V[]){v_xs_242, v_b_243})));
    V v_x2_2417;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_e_27_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2416 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n_2415, heff_get(heff_dup(v_s_2412), LBL_fuel), heff_get(heff_dup(v_s_2412), LBL_defs), heff_get(heff_dup(v_s_2412), LBL_safe), heff_get(heff_dup(v_s_2412), LBL_total), heff_get(heff_dup(v_s_2412), LBL_plain), heff_get(v_s_2412, LBL_sp)});
      v_x2_2417 = heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_2414, v_t_2416});
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_s_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      V v_t_2420 = heff_get(heff_get(heff_dup(v_s_247), LBL_sp), LBL_count);
      V v_t_2421 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2emakeSpec_str1), heff_intShow(v_t_2420)));
      V v_m_2422 = (g_heff_2esimplify_2especBody(heff_dup(v_g_241), v_t_2421, heff_dup(v_marks_245), v_as_244, v_x_2418));
      V v_x2_2423 = heff_tr(heff_apply(v_m_2422, 1, (V[]){v_s_2419}));
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_field(v_x2_2423, 0);
        V v_s_2425 = heff_field(v_x2_2423, 1);
        heff_take_n(v_x2_2423, 3ULL, 2);
        V v_t_2426 = heff_get(heff_get(heff_dup(v_s_247), LBL_sp), LBL_count);
        V v_t_2427 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2emakeSpec_str2), heff_intShow(v_t_2426)));
        V v_x2_2428 = (g_heff_2esimplify_2epreKnown(v_t_2427, heff_dup(v_x_2424), v_s_2425));
        switch (heff_tag_of(v_x2_2428)) {
        case TAG_MkPair: {
          V v_s_2430 = heff_field(v_x2_2428, 1);
          heff_take_n(v_x2_2428, 2ULL, 2);
          V v_m_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_x_2424}));
          V v_t_2432 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_2430), LBL_supply), MK_INT(4000LL), heff_get(heff_dup(v_s_2430), LBL_defs), heff_get(heff_dup(v_s_2430), LBL_safe), heff_get(heff_dup(v_s_2430), LBL_total), heff_get(heff_dup(v_s_2430), LBL_plain), heff_get(v_s_2430, LBL_sp)});
          V v_x2_2433 = heff_tr(heff_apply(v_m_2431, 1, (V[]){v_t_2432}));
          switch (heff_tag_of(v_x2_2433)) {
          case TAG_MkPair: {
            V v_x_2434 = heff_field(v_x2_2433, 0);
            V v_s_2435 = heff_field(v_x2_2433, 1);
            heff_take_n(v_x2_2433, 3ULL, 2);
            V v_m_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_simp), 1, (V[]){v_x_2434}));
            V v_x2_2437 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_s_2435}));
            switch (heff_tag_of(v_x2_2437)) {
            case TAG_MkPair: {
              V v_x_2438 = heff_field(v_x2_2437, 0);
              V v_s_2439 = heff_field(v_x2_2437, 1);
              heff_take_n(v_x2_2437, 3ULL, 2);
              V v_x2_2440 = (g_heff_2esimplify_2eraise(v_x_2438, v_s_2439));
              switch (heff_tag_of(v_x2_2440)) {
              case TAG_MkPair: {
                V v_x_2441 = heff_field(v_x2_2440, 0);
                V v_s_2442 = heff_field(v_x2_2440, 1);
                heff_take_n(v_x2_2440, 3ULL, 2);
                V v_t_2443 = heff_get(heff_get(heff_dup(v_s_247), LBL_sp), LBL_count);
                V v_t_2444 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2emakeSpec_str3), heff_intShow(v_t_2443)));
                V v_t_2445 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_2442), LBL_supply), heff_get(heff_dup(v_s_247), LBL_fuel), heff_get(heff_dup(v_s_2442), LBL_defs), heff_get(heff_dup(v_s_2442), LBL_safe), heff_get(heff_dup(v_s_2442), LBL_total), heff_get(heff_dup(v_s_2442), LBL_plain), heff_get(v_s_2442, LBL_sp)});
                V v_x2_2446 = (g_heff_2esimplify_2epopSpec(v_t_2444, heff_dup(v_x_2441), v_t_2445));
                switch (heff_tag_of(v_x2_2446)) {
                case TAG_MkPair: {
                  V v_s_2448 = heff_field(v_x2_2446, 1);
                  heff_take_n(v_x2_2446, 2ULL, 2);
                  V v_t_2449 = heff_get(heff_get(heff_dup(v_s_247), LBL_sp), LBL_count);
                  V v_t_2450 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2emakeSpec_str4), heff_intShow(v_t_2449)));
                  V v_x2_2451 = ({ V a_0 = v_t_2450; V a_1 = v_x_2441; V a_2 = v_s_2448; V r_ = (g_heff_2esimplify_2emarkSafe(a_0, a_1, a_2)); heff_drop(v_x_2441); r_; });
                  switch (heff_tag_of(v_x2_2451)) {
                  case TAG_MkPair: {
                    V v_s_2453 = heff_field(v_x2_2451, 1);
                    heff_take_n(v_x2_2451, 2ULL, 2);
                    V v_t_2454 = heff_get(heff_get(v_s_247, LBL_sp), LBL_count);
                    V v_t_2455 = heff_strAppend(v_g_241, heff_strAppend(((V)&g_heff_2esimplify_2emakeSpec_str5), heff_intShow(v_t_2454)));
                    V v_t_2456 = (g_heff_2espec_2edropAt(v_marks_245, v_as_244));
                    return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_t_2455}), v_t_2456, v_s_2453});
                  }
                  default: return heff_nomatch(v_x2_2451);
                  }
                }
                default: return heff_nomatch(v_x2_2446);
                }
              }
              default: return heff_nomatch(v_x2_2440);
              }
            }
            default: return heff_nomatch(v_x2_2437);
            }
          }
          default: return heff_nomatch(v_x2_2433);
          }
        }
        default: return heff_nomatch(v_x2_2428);
        }
      }
      default: return heff_nomatch(v_x2_2423);
      }
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2esimplify_2emakeSpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2emakeSpec(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especMarked_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especMarked_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especMarked_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especMarked_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especMarked_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2esimplify_2especMarked_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2esimplify_2especMarked_lam0(V self, V *args);
V g_heff_2esimplify_2especMarked_lam1(V self, V *args);
Clo g_heff_2esimplify_2especMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especMarked_entry, 7, 0};

V g_heff_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_s_246) {
top: ;
  V v_x1_247 = (g_prelude_2eany_24s525(v_marks_245));
  V v_t_248;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2445;
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_x1_249 = (g_heff_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    V v_t_2412;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nil: {
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_249, 0ULL, 2);
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      V v_t_2413 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2414 = (g_heff_2eir_2enubI(v_t_2413));
      V v_t_2415 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2414; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2414); r_; });
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        V v_x1_2444;
        switch (heff_tag_of(v_b_243)) {
        case TAG_EVar: {
          v_x1_2444 = NTAG(TAG_True);
          break;
        }
        case TAG_EGlobal: {
          v_x1_2444 = NTAG(TAG_True);
          break;
        }
        case TAG_ELam: {
          v_x1_2444 = NTAG(TAG_True);
          break;
        }
        case TAG_EApp: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          V v_fs_2425 = heff_dup(heff_field(v_b_243, 0));
          V v_t_2426 = (g_prelude_2emap_24s511(v_fs_2425));
          v_x1_2444 = ({ V a_0 = v_t_2426; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2426); r_; });
          break;
        }
        case TAG_EProj: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          V v_as_2430 = heff_dup(heff_field(v_b_243, 1));
          V v_t_2431 = (g_prelude_2emap_24s512(v_as_2430));
          v_x1_2444 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2431); r_; });
          break;
        }
        case TAG_EMatch: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          v_x1_2444 = NTAG(TAG_True);
          break;
        }
        case TAG_EPrimCall: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          v_x1_2444 = NTAG(TAG_True);
          break;
        }
        case TAG_EFloat: {
          v_x1_2444 = NTAG(TAG_True);
          break;
        }
        case TAG_EStr: {
          v_x1_2444 = NTAG(TAG_True);
          break;
        }
        case TAG_EAbandon: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          v_x1_2444 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_b_243);
        }
        switch (heff_tag_of(v_x1_2444)) {
        case TAG_True: {
          v_t_2445 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2445 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x1_2444);
        }
        break;
      }
      case TAG_False: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      break;
    }
    case TAG_False: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  switch (heff_tag_of(v_t_2445)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_s_246);
    V v_x_2446 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_clo(g_heff_2esimplify_2especMarked_lam0, 1, 1, (V[]){v_x_2446});
  }
  case TAG_False: {
    V v_t_2448 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_marks_245));
    V v_t_2449 = (g_heff_2esimplify_2etakeL(v_t_2448, heff_dup(v_as_244)));
    V v_x2_2450 = (g_prelude_2ezipWith_24s523(heff_dup(v_marks_245), v_t_2449));
    V v_t_2453;
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_Nil: {
      v_t_2453 = ((V)&g_heff_2esimplify_2especMarked_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2451 = heff_field(v_x2_2450, 0);
      V v_xs_2452 = heff_field(v_x2_2450, 1);
      heff_take_n(v_x2_2450, 3ULL, 2);
      v_t_2453 = ({ V a_0 = v_x_2451; V a_1 = v_xs_2452; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_xs_2452); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2450);
    }
    V v_t_2454 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2especMarked_str1), heff_strAppend(v_t_2453, ((V)&g_heff_2esimplify_2especMarked_str2))));
    V v_t_2455 = heff_get(heff_get(heff_dup(v_s_246), LBL_sp), LBL_specs);
    V v_t_2456 = ({ V a_0 = v_t_2454; V a_1 = v_t_2455; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_t_2455); r_; });
    switch (heff_tag_of(v_t_2456)) {
    case TAG_Nothing: {
      V v_t_2457 = heff_get(heff_get(v_s_246, LBL_sp), LBL_trying);
      V v_t_2458 = heff_intLt(MK_INT(0LL), v_t_2457);
      switch (heff_tag_of(v_t_2458)) {
      case TAG_True: {
        heff_drop(v_r_240);
        heff_drop(v_xs_242);
        heff_drop(v_b_243);
        heff_drop(v_marks_245);
        V v_x_2459 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
        return heff_clo(g_heff_2esimplify_2especMarked_lam1, 1, 1, (V[]){v_x_2459});
      }
      case TAG_False: {
        V v_t_2461 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_marks_245));
        V v_t_2462 = (g_heff_2esimplify_2etakeL(v_t_2461, heff_dup(v_as_244)));
        V v_x2_2463 = (g_prelude_2ezipWith_24s523(heff_dup(v_marks_245), v_t_2462));
        V v_t_2466;
        switch (heff_tag_of(v_x2_2463)) {
        case TAG_Nil: {
          v_t_2466 = ((V)&g_heff_2esimplify_2especMarked_str3);
          break;
        }
        case TAG_Cons: {
          V v_x_2464 = heff_field(v_x2_2463, 0);
          V v_xs_2465 = heff_field(v_x2_2463, 1);
          heff_take_n(v_x2_2463, 3ULL, 2);
          v_t_2466 = ({ V a_0 = v_x_2464; V a_1 = v_xs_2465; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_xs_2465); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2463);
        }
        V v_t_2467 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2esimplify_2especMarked_str4), heff_strAppend(v_t_2466, ((V)&g_heff_2esimplify_2especMarked_str5))));
        return heff_tail(((V)&g_heff_2esimplify_2emakeSpec_clo), 7, (V[]){v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_t_2467});
      }
      default: return heff_nomatch(v_t_2458);
      }
    }
    case TAG_Just: {
      V v_h_2468 = heff_field(v_t_2456, 0);
      heff_take_n(v_t_2456, 1ULL, 1);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_s_246);
      V v_t_2469 = (g_heff_2espec_2edropAt(v_marks_245, v_as_244));
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_h_2468}), v_t_2469});
    }
    default: return heff_nomatch(v_t_2456);
    }
  }
  default: return heff_nomatch(v_t_2445);
  }
}
V g_heff_2esimplify_2especMarked_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2especMarked(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esimplify_2especMarked_lam0(V self, V *args) {
  V v_s_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2446, v_s_2447});
}
V g_heff_2esimplify_2especMarked_lam1(V self, V *args) {
  V v_s_2460 = args[0];
  V v_x_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2459, v_s_2460});
}
V g_heff_2esimplify_2especLam_lam0(V self, V *args);
Clo g_heff_2esimplify_2especLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2especLam_entry, 6, 0};

V g_heff_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get(heff_get(heff_dup(v_s_245), LBL_sp), LBL_count);
  V v_t_247 = heff_intLe(heff_dup(g_heff_2esimplify_2especLimit_get()), v_t_246);
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    v_t_2414 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_t_248 = heff_get(heff_get(heff_dup(v_s_245), LBL_sp), LBL_within);
    V v_a_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_248; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_intLe(heff_dup(g_heff_2esimplify_2especDepth_get()), v_a_249);
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_x1_2413 = (g_prelude_2eany(heff_clo(g_heff_2esimplify_2especLam_lam0, 1, 1, (V[]){heff_dup(v_s_245)}), v_as_244));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_True: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2414 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_2413);
      }
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    V v_x_2415 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2415, v_s_245});
  }
  case TAG_False: {
    V v_t_2416 = heff_get(heff_get(heff_dup(v_s_245), LBL_sp), LBL_kinds);
    V v_t_2417 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_2418 = (g_heff_2eir_2enubI(v_t_2417));
    V v_t_2419 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2418; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2421;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      V v_t_2420 = (g_heff_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
      v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
      break;
    }
    case TAG_False: {
      v_t_2421 = (g_prelude_2emap_24s522(heff_dup(v_xs_242)));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_t_2422 = ({ V a_0 = v_t_2416; V a_1 = v_as_244; V a_2 = v_t_2421; V a_3 = MK_INT(0LL); V r_ = (g_heff_2esimplify_2emarkGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
    V v_t_2423 = heff_tr(g_heff_2esimplify_2especMarked(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_t_2422, heff_dup(v_s_245)));
    return heff_tail(v_t_2423, 1, (V[]){v_s_245});
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2esimplify_2especLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2especLam(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esimplify_2especLam_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_s_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_get(heff_get(v_s_245, LBL_sp), LBL_kinds);
  return ({ V a_0 = v_t_2412; V a_1 = v_a_2411; V r_ = (g_heff_2esimplify_2eknownArg(a_0, a_1)); heff_drop(v_t_2412); r_; });
}
Clo g_heff_2esimplify_2etrySpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etrySpec_entry, 4, 0};

V g_heff_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_as_242, V v_s_243) {
top: ;
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_243), LBL_sp), LBL_all);
  V v_it_245 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_r_240);
    V v_x_246 = (g_heff_2esimplify_2emkApp(heff_tag(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_246, v_s_243});
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_EVar: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_249 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_249, v_s_243});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2411 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2411, v_s_243});
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_it1_247, 0);
      V v_b_2413 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      heff_drop_cell(v_ru_24it_245_24Just, 1);
      return (g_heff_2esimplify_2especLam(v_r_240, v_g_241, v_xs_2412, v_b_2413, v_as_242, v_s_243));
    }
    case TAG_EApp: {
      V v_ru_24it1_247_24EApp = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2416 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EApp, TAG_MkPair, 2, (V[]){v_x_2416, v_s_243});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2420 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2420, v_s_243});
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2422 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2422, v_s_243});
    }
    case TAG_EProj: {
      V v_ru_24it1_247_24EProj = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2425 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EProj, TAG_MkPair, 2, (V[]){v_x_2425, v_s_243});
    }
    case TAG_ETag: {
      V v_ru_24it1_247_24ETag = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2428 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24ETag, TAG_MkPair, 2, (V[]){v_x_2428, v_s_243});
    }
    case TAG_EMatch: {
      V v_ru_24it1_247_24EMatch = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2431 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EMatch, TAG_MkPair, 2, (V[]){v_x_2431, v_s_243});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2433 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2433, v_s_243});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_247_24EPrimCall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2436 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EPrimCall, TAG_MkPair, 2, (V[]){v_x_2436, v_s_243});
    }
    case TAG_ECall: {
      V v_ru_24it1_247_24ECall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2439 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24ECall, TAG_MkPair, 2, (V[]){v_x_2439, v_s_243});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2441 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2441, v_s_243});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2443 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2443, v_s_243});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2445 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2445, v_s_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_2446 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag(TAG_MkPair, 2, (V[]){v_x_2446, v_s_243});
    }
    case TAG_EFix: {
      V v_ru_24it1_247_24EFix = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2449 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at(v_ru_24it1_247_24EFix, TAG_MkPair, 2, (V[]){v_x_2449, v_s_243});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esimplify_2etrySpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etrySpec(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      return heff_strEq(v_g_240, heff_dup(v_h_249));
    }
    case TAG_ELam: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2estillCall(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2efieldIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efieldIn_entry, 2, 0};

V g_heff_2esimplify_2efieldIn(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_k_244), heff_dup(v_l_240));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_l_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      }
      case TAG_False: {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2efieldIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2efieldIn(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esimplify_2eknownField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eknownField_entry, 3, 0};

V g_heff_2esimplify_2eknownField(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
  V v_it_244 = ({ V a_0 = v_g_240; V a_1 = v_t_243; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_244, 0);
    V v_ru_24it_244_24Just = heff_take_reuse_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_EVar: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELam: {
      V v_ru_24it1_245_24ELam = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EApp: {
      V v_ru_24it1_245_24EApp = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_245, 0ULL, 3);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      V v_t_2416 = ({ V a_0 = v_l_241; V a_1 = v_fs_2415; V r_ = (g_heff_2esimplify_2efieldIn(a_0, a_1)); heff_drop(v_fs_2415); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24it_244_24Just, 1);
        return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
      }
      case TAG_Just: {
        V v_v_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        V v_t_2446;
        switch (heff_tag_of(v_v_2417)) {
        case TAG_EVar: {
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        case TAG_EGlobal: {
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        case TAG_ELam: {
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        case TAG_EApp: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          V v_fs_2427 = heff_dup(heff_field(v_v_2417, 0));
          V v_t_2428 = (g_prelude_2emap_24s511(v_fs_2427));
          v_t_2446 = ({ V a_0 = v_t_2428; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2428); r_; });
          break;
        }
        case TAG_EProj: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          V v_as_2432 = heff_dup(heff_field(v_v_2417, 1));
          V v_t_2433 = (g_prelude_2emap_24s512(v_as_2432));
          v_t_2446 = ({ V a_0 = v_t_2433; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2433); r_; });
          break;
        }
        case TAG_EMatch: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        case TAG_EPrimCall: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        case TAG_EFloat: {
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        case TAG_EStr: {
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        case TAG_EAbandon: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_v_2417);
        }
        V v_t_2447;
        switch (heff_tag_of(v_t_2446)) {
        case TAG_True: {
          v_t_2447 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_s_242), LBL_fuel));
          break;
        }
        case TAG_False: {
          v_t_2447 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2446);
        }
        switch (heff_tag_of(v_t_2447)) {
        case TAG_True: {
          V v_t_2448 = heff_intSub(heff_get(heff_dup(v_s_242), LBL_fuel), MK_INT(1LL));
          V v_s_2449 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), v_t_2448, heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
          V v_x2_2450 = (g_heff_2eir_2efreshGo_24s504(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_s_2449), LBL_supply), v_v_2417));
          V v_x2_2454;
          switch (heff_tag_of(v_x2_2450)) {
          case TAG_MkPair: {
            V v_e_27_2451 = heff_field(v_x2_2450, 0);
            V v_n_2452 = heff_field(v_x2_2450, 1);
            V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
            V v_t_2453 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n_2452, heff_get(heff_dup(v_s_2449), LBL_fuel), heff_get(heff_dup(v_s_2449), LBL_defs), heff_get(heff_dup(v_s_2449), LBL_safe), heff_get(heff_dup(v_s_2449), LBL_total), heff_get(heff_dup(v_s_2449), LBL_plain), heff_get(v_s_2449, LBL_sp)});
            v_x2_2454 = heff_tag_at(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_2451, v_t_2453});
            break;
          }
          default: heff_nomatch(v_x2_2450);
          }
          switch (heff_tag_of(v_x2_2454)) {
          case TAG_MkPair: {
            V v_x_2455 = heff_field(v_x2_2454, 0);
            V v_s_2456 = heff_field(v_x2_2454, 1);
            V v_ru_24x2_2454_24MkPair = heff_take_reuse_n(v_x2_2454, 3ULL, 2);
            return heff_tag_at(v_ru_24x2_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24it_244_24Just, TAG_Just, 1, (V[]){v_x_2455}), v_s_2456});
          }
          default: return heff_nomatch(v_x2_2454);
          }
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24it_244_24Just, 1);
          heff_drop(v_v_2417);
          return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
        }
        default: return heff_nomatch(v_t_2447);
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_EProj: {
      V v_ru_24it1_245_24EProj = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EProj, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ETag: {
      V v_ru_24it1_245_24ETag = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EMatch: {
      V v_ru_24it1_245_24EMatch = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_245_24EPrimCall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ECall: {
      V v_ru_24it1_245_24ECall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFix: {
      V v_ru_24it1_245_24EFix = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at(v_ru_24it1_245_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esimplify_2eknownField_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eknownField(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2eapplyToF_lam0(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam1(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam2(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam3(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam4(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam5(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam6(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam8(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam7(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam9(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam10(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam11(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam12(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam13(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam14(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam15(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam16(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam17(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam18(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam19(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam20(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam21(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam22(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam23(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam24(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam26(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam25(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam27(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam28(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam29(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam30(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam31(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam32(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam33(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam34(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam35(V self, V *args);
V g_heff_2esimplify_2eapplyToF_lam36(V self, V *args);
Clo g_heff_2esimplify_2eapplyToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eapplyToF_entry, 3, 0};

V g_heff_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_as_242) {
top: ;
  V v_t_243 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_242));
  V v_t_244 = heff_intEq(v_t_243, MK_INT(0LL));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_as_242);
    return heff_clo(g_heff_2esimplify_2eapplyToF_lam0, 1, 1, (V[]){v_f_241});
  }
  case TAG_False: {
    switch (heff_tag_of(v_f_241)) {
    case TAG_EVar: {
      heff_drop(v_r_240);
      V v_x_247 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam1, 1, 1, (V[]){v_x_247});
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_dup(heff_field(v_f_241, 0));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam2, 1, 4, (V[]){v_g_249, v_r_240, v_f_241, v_as_242});
    }
    case TAG_ELam: {
      V v_xs_2417 = heff_field(v_f_241, 0);
      V v_it2_2418 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24ELam = heff_take_reuse_n(v_f_241, 3ULL, 2);
      switch (heff_tag_of(v_it2_2418)) {
      case TAG_EVar: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EGlobal: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELam: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EApp: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELet: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ERecord: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EProj: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ETag: {
        V v_t_2431 = heff_field(v_it2_2418, 0);
        V v_es_2432 = heff_field(v_it2_2418, 1);
        heff_take_n(v_it2_2418, 3ULL, 2);
        V v_t_2433 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_2417));
        V v_t_2434 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_242));
        V v_t_2435 = heff_intEq(v_t_2433, v_t_2434);
        switch (heff_tag_of(v_t_2435)) {
        case TAG_True: {
          V v_t_2436 = (g_heff_2esimplify_2evarsAre(v_xs_2417, v_es_2432));
          switch (heff_tag_of(v_t_2436)) {
          case TAG_True: {
            heff_drop(v_r_240);
            heff_drop(v_xs_2417);
            heff_drop_cell(v_ru_24f_241_24ELam, 2);
            heff_drop(v_es_2432);
            return heff_clo(g_heff_2esimplify_2eapplyToF_lam3, 1, 2, (V[]){v_t_2431, v_as_242});
          }
          case TAG_False: {
            return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2431, v_es_2432}), v_as_242));
          }
          default: return heff_nomatch(v_t_2436);
          }
        }
        case TAG_False: {
          return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2431, v_es_2432}), v_as_242));
        }
        default: return heff_nomatch(v_t_2435);
        }
      }
      case TAG_EMatch: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrim: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrimCall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ECall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EInt: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EStr: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFix: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      default: return heff_nomatch(v_it2_2418);
      }
    }
    case TAG_EApp: {
      V v_g_2450 = heff_field(v_f_241, 0);
      V v_bs_2451 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      V v_t_2452 = (g_heff_2esimplify_2eappendL(v_bs_2451, v_as_242));
      return heff_tail(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_g_2450, v_t_2452});
    }
    case TAG_ELet: {
      V v_x_2453 = heff_field(v_f_241, 0);
      V v_a_2454 = heff_field(v_f_241, 1);
      V v_b_2455 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_2456 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_2455, v_as_242}));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam4, 1, 3, (V[]){v_m_2456, v_x_2453, v_a_2454});
    }
    case TAG_ERecord: {
      heff_drop(v_r_240);
      V v_x_2462 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam5, 1, 1, (V[]){v_x_2462});
    }
    case TAG_EProj: {
      V v_it1_2464 = heff_dup(heff_field(v_f_241, 0));
      V v_l_2465 = heff_dup(heff_field(v_f_241, 1));
      switch (heff_tag_of(v_it1_2464)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2464, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_2467 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam6, 1, 1, (V[]){v_x_2467});
      }
      case TAG_EGlobal: {
        V v_g_2469 = heff_field(v_it1_2464, 0);
        heff_take_n(v_it1_2464, 1ULL, 1);
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam7, 1, 5, (V[]){v_g_2469, v_l_2465, v_f_241, v_as_242, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_2490 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam9, 1, 1, (V[]){v_x_2490});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_2494 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam10, 1, 1, (V[]){v_x_2494});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2464, 0ULL, 3);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_2499 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam11, 1, 1, (V[]){v_x_2499});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2464, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24102 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam12, 1, 1, (V[]){v_x_24102});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24106 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam13, 1, 1, (V[]){v_x_24106});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24110 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam14, 1, 1, (V[]){v_x_24110});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24114 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam15, 1, 1, (V[]){v_x_24114});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2464, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24117 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam16, 1, 1, (V[]){v_x_24117});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24121 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam17, 1, 1, (V[]){v_x_24121});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24125 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam18, 1, 1, (V[]){v_x_24125});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2464, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24128 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam19, 1, 1, (V[]){v_x_24128});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2464, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24131 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam20, 1, 1, (V[]){v_x_24131});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2464, 0ULL, 1);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24134 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam21, 1, 1, (V[]){v_x_24134});
      }
      case TAG_EAbandon: {
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24136 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam22, 1, 1, (V[]){v_x_24136});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2464, 0ULL, 2);
        heff_drop(v_r_240);
        heff_drop(v_l_2465);
        V v_x_24140 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam23, 1, 1, (V[]){v_x_24140});
      }
      default: return heff_nomatch(v_it1_2464);
      }
    }
    case TAG_ETag: {
      heff_drop(v_r_240);
      V v_x_24144 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam24, 1, 1, (V[]){v_x_24144});
    }
    case TAG_EMatch: {
      V v_s_24146 = heff_field(v_f_241, 0);
      V v_arms_24147 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24EMatch = heff_take_reuse_n(v_f_241, 3ULL, 2);
      V v_t_24148 = (g_prelude_2emap_24s517(heff_dup(v_as_242)));
      V v_t_24149 = ({ V a_0 = v_t_24148; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_24148); r_; });
      switch (heff_tag_of(v_t_24149)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24f_241_24EMatch, 2);
        V v_m_24159 = (g_heff_2esimplify_2etraverseS(heff_clo(g_heff_2esimplify_2eapplyToF_lam25, 1, 2, (V[]){v_r_240, v_as_242}), v_arms_24147));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam27, 1, 2, (V[]){v_m_24159, v_s_24146});
      }
      case TAG_False: {
        heff_drop(v_r_240);
        V v_x_24164 = (g_heff_2esimplify_2emkApp(heff_tag_at(v_ru_24f_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_24146, v_arms_24147}), v_as_242));
        return heff_clo(g_heff_2esimplify_2eapplyToF_lam28, 1, 1, (V[]){v_x_24164});
      }
      default: return heff_nomatch(v_t_24149);
      }
    }
    case TAG_EPrim: {
      heff_drop(v_r_240);
      V v_x_24167 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam29, 1, 1, (V[]){v_x_24167});
    }
    case TAG_EPrimCall: {
      heff_drop(v_r_240);
      V v_x_24171 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam30, 1, 1, (V[]){v_x_24171});
    }
    case TAG_ECall: {
      heff_drop(v_r_240);
      V v_x_24175 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam31, 1, 1, (V[]){v_x_24175});
    }
    case TAG_EInt: {
      heff_drop(v_r_240);
      V v_x_24178 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam32, 1, 1, (V[]){v_x_24178});
    }
    case TAG_EFloat: {
      heff_drop(v_r_240);
      V v_x_24181 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam33, 1, 1, (V[]){v_x_24181});
    }
    case TAG_EStr: {
      heff_drop(v_r_240);
      V v_x_24184 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam34, 1, 1, (V[]){v_x_24184});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_24186 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam35, 1, 1, (V[]){v_x_24186});
    }
    case TAG_EFix: {
      heff_drop(v_r_240);
      V v_x_24190 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo(g_heff_2esimplify_2eapplyToF_lam36, 1, 1, (V[]){v_x_24190});
    }
    default: return heff_nomatch(v_f_241);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esimplify_2eapplyToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eapplyToF(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2eapplyToF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_f_241, v_s_245});
}
V g_heff_2esimplify_2eapplyToF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2esimplify_2eapplyToF_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = heff_dup(v_g_249); V b_1 = heff_get(heff_dup(v_s_2410), LBL_defs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_m_2412 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_f_241; V a_2 = heff_dup(v_g_249); V a_3 = heff_dup(v_as_242); V a_4 = v_t_2411; V r_ = heff_tr(g_heff_2esimplify_2ecallOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); r_; });
  V v_x2_2413 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2esimplify_2estillCall(heff_dup(v_g_249), v_x_2414));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_x_2414);
      heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
      return (g_heff_2esimplify_2etrySpec(v_r_240, v_g_249, v_as_242, v_s_2415));
    }
    case TAG_False: {
      heff_drop(v_g_249);
      heff_drop(v_r_240);
      heff_drop(v_as_242);
      return heff_tag_at(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2esimplify_2eapplyToF_lam3(V self, V *args) {
  V v_s_2437 = args[0];
  V v_t_2431 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2431, v_as_242}), v_s_2437});
}
V g_heff_2esimplify_2eapplyToF_lam4(V self, V *args) {
  V v_s_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_x_2453 = heff_env(self)[1];
  V v_a_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2458 = heff_tr(heff_apply(v_m_2456, 1, (V[]){v_s_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_s_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2453, v_a_2454, v_x_2459}), v_s_2460});
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2esimplify_2eapplyToF_lam5(V self, V *args) {
  V v_s_2463 = args[0];
  V v_x_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2462, v_s_2463});
}
V g_heff_2esimplify_2eapplyToF_lam6(V self, V *args) {
  V v_s_2468 = args[0];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2467, v_s_2468});
}
V g_heff_2esimplify_2eapplyToF_lam8(V self, V *args) {
  V v_s_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2485 = heff_tr(heff_apply(v_m_2483, 1, (V[]){v_s_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_s_2487 = heff_field(v_x2_2485, 1);
    heff_take_n(v_x2_2485, 3ULL, 2);
    return heff_tail(heff_get(v_r_240, LBL_applyTo), 3, (V[]){v_x_2486, v_as_242, v_s_2487});
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2esimplify_2eapplyToF_lam7(V self, V *args) {
  V v_s_2470 = args[0];
  V v_g_2469 = heff_env(self)[0];
  V v_l_2465 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2471 = (g_heff_2esimplify_2eknown(heff_dup(v_g_2469), v_s_2470));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    switch (heff_tag_of(v_x_2472)) {
    case TAG_Nothing: {
      V v_x2_2474 = (g_heff_2esimplify_2eknownField(v_g_2469, v_l_2465, v_s_2473));
      switch (heff_tag_of(v_x2_2474)) {
      case TAG_MkPair: {
        V v_x_2475 = heff_field(v_x2_2474, 0);
        V v_s_2476 = heff_field(v_x2_2474, 1);
        heff_take_n(v_x2_2474, 3ULL, 2);
        switch (heff_tag_of(v_x_2475)) {
        case TAG_Nothing: {
          heff_drop(v_r_240);
          V v_x_2477 = (g_heff_2esimplify_2emkApp(v_f_241, v_as_242));
          return heff_tag_at(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){v_x_2477, v_s_2476});
        }
        case TAG_Just: {
          V v_v_2478 = heff_field(v_x_2475, 0);
          heff_take_n(v_x_2475, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2471_24MkPair, 2);
          V v_t_2479 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
          V v_t_2480 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_v_2478, v_as_242}));
          return (g_heff_2esimplify_2eattempt(v_t_2479, v_t_2480, v_s_2476));
        }
        default: return heff_nomatch(v_x_2475);
        }
      }
      default: return heff_nomatch(v_x2_2474);
      }
    }
    case TAG_Just: {
      V v_b_2481 = heff_field(v_x_2472, 0);
      heff_take_n(v_x_2472, 1ULL, 1);
      heff_drop(v_g_2469);
      heff_drop_cell(v_ru_24x2_2471_24MkPair, 2);
      V v_t_2482 = (g_heff_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
      V v_m_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_project), 2, (V[]){v_l_2465, v_b_2481}));
      return (g_heff_2esimplify_2eattempt(v_t_2482, heff_clo(g_heff_2esimplify_2eapplyToF_lam8, 1, 3, (V[]){v_m_2483, v_r_240, v_as_242}), v_s_2473));
    }
    default: return heff_nomatch(v_x_2472);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2esimplify_2eapplyToF_lam9(V self, V *args) {
  V v_s_2491 = args[0];
  V v_x_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2490, v_s_2491});
}
V g_heff_2esimplify_2eapplyToF_lam10(V self, V *args) {
  V v_s_2495 = args[0];
  V v_x_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2494, v_s_2495});
}
V g_heff_2esimplify_2eapplyToF_lam11(V self, V *args) {
  V v_s_24100 = args[0];
  V v_x_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2499, v_s_24100});
}
V g_heff_2esimplify_2eapplyToF_lam12(V self, V *args) {
  V v_s_24103 = args[0];
  V v_x_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24102, v_s_24103});
}
V g_heff_2esimplify_2eapplyToF_lam13(V self, V *args) {
  V v_s_24107 = args[0];
  V v_x_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24106, v_s_24107});
}
V g_heff_2esimplify_2eapplyToF_lam14(V self, V *args) {
  V v_s_24111 = args[0];
  V v_x_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24110, v_s_24111});
}
V g_heff_2esimplify_2eapplyToF_lam15(V self, V *args) {
  V v_s_24115 = args[0];
  V v_x_24114 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24114, v_s_24115});
}
V g_heff_2esimplify_2eapplyToF_lam16(V self, V *args) {
  V v_s_24118 = args[0];
  V v_x_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24117, v_s_24118});
}
V g_heff_2esimplify_2eapplyToF_lam17(V self, V *args) {
  V v_s_24122 = args[0];
  V v_x_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24121, v_s_24122});
}
V g_heff_2esimplify_2eapplyToF_lam18(V self, V *args) {
  V v_s_24126 = args[0];
  V v_x_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24125, v_s_24126});
}
V g_heff_2esimplify_2eapplyToF_lam19(V self, V *args) {
  V v_s_24129 = args[0];
  V v_x_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24128, v_s_24129});
}
V g_heff_2esimplify_2eapplyToF_lam20(V self, V *args) {
  V v_s_24132 = args[0];
  V v_x_24131 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24131, v_s_24132});
}
V g_heff_2esimplify_2eapplyToF_lam21(V self, V *args) {
  V v_s_24135 = args[0];
  V v_x_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24134, v_s_24135});
}
V g_heff_2esimplify_2eapplyToF_lam22(V self, V *args) {
  V v_s_24137 = args[0];
  V v_x_24136 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24136, v_s_24137});
}
V g_heff_2esimplify_2eapplyToF_lam23(V self, V *args) {
  V v_s_24141 = args[0];
  V v_x_24140 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24140, v_s_24141});
}
V g_heff_2esimplify_2eapplyToF_lam24(V self, V *args) {
  V v_s_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24144, v_s_24145});
}
V g_heff_2esimplify_2eapplyToF_lam26(V self, V *args) {
  V v_s_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  V v_t_24151 = heff_env(self)[1];
  V v_vs_24152 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24156 = heff_tr(heff_apply(v_m_24154, 1, (V[]){v_s_24155}));
  switch (heff_tag_of(v_x2_24156)) {
  case TAG_MkPair: {
    V v_x_24157 = heff_field(v_x2_24156, 0);
    V v_s_24158 = heff_field(v_x2_24156, 1);
    V v_ru_24x2_24156_24MkPair = heff_take_reuse_n(v_x2_24156, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_24151, v_vs_24152, v_x_24157}), v_s_24158});
  }
  default: return heff_nomatch(v_x2_24156);
  }
}
V g_heff_2esimplify_2eapplyToF_lam25(V self, V *args) {
  V v_a_24150 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24150)) {
  case TAG_MkArm: {
    V v_t_24151 = heff_field(v_a_24150, 0);
    V v_vs_24152 = heff_field(v_a_24150, 1);
    V v_b_24153 = heff_field(v_a_24150, 2);
    heff_take_n(v_a_24150, 7ULL, 3);
    V v_m_24154 = heff_tr(heff_apply(heff_get(v_r_240, LBL_applyTo), 2, (V[]){v_b_24153, v_as_242}));
    return heff_clo(g_heff_2esimplify_2eapplyToF_lam26, 1, 3, (V[]){v_m_24154, v_t_24151, v_vs_24152});
  }
  default: return heff_nomatch(v_a_24150);
  }
}
V g_heff_2esimplify_2eapplyToF_lam27(V self, V *args) {
  V v_s_24160 = args[0];
  V v_m_24159 = heff_env(self)[0];
  V v_s_24146 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24161 = heff_tr(heff_apply(v_m_24159, 1, (V[]){v_s_24160}));
  switch (heff_tag_of(v_x2_24161)) {
  case TAG_MkPair: {
    V v_x_24162 = heff_field(v_x2_24161, 0);
    V v_s_24163 = heff_field(v_x2_24161, 1);
    V v_ru_24x2_24161_24MkPair = heff_take_reuse_n(v_x2_24161, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_24146, v_x_24162}), v_s_24163});
  }
  default: return heff_nomatch(v_x2_24161);
  }
}
V g_heff_2esimplify_2eapplyToF_lam28(V self, V *args) {
  V v_s_24165 = args[0];
  V v_x_24164 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24164, v_s_24165});
}
V g_heff_2esimplify_2eapplyToF_lam29(V self, V *args) {
  V v_s_24168 = args[0];
  V v_x_24167 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24167, v_s_24168});
}
V g_heff_2esimplify_2eapplyToF_lam30(V self, V *args) {
  V v_s_24172 = args[0];
  V v_x_24171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24171, v_s_24172});
}
V g_heff_2esimplify_2eapplyToF_lam31(V self, V *args) {
  V v_s_24176 = args[0];
  V v_x_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24175, v_s_24176});
}
V g_heff_2esimplify_2eapplyToF_lam32(V self, V *args) {
  V v_s_24179 = args[0];
  V v_x_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24178, v_s_24179});
}
V g_heff_2esimplify_2eapplyToF_lam33(V self, V *args) {
  V v_s_24182 = args[0];
  V v_x_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24181, v_s_24182});
}
V g_heff_2esimplify_2eapplyToF_lam34(V self, V *args) {
  V v_s_24185 = args[0];
  V v_x_24184 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24184, v_s_24185});
}
V g_heff_2esimplify_2eapplyToF_lam35(V self, V *args) {
  V v_s_24187 = args[0];
  V v_x_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24186, v_s_24187});
}
V g_heff_2esimplify_2eapplyToF_lam36(V self, V *args) {
  V v_s_24191 = args[0];
  V v_x_24190 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_24190, v_s_24191});
}
Clo g_heff_2esimplify_2efindField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efindField_entry, 2, 0};

V g_heff_2esimplify_2efindField(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_k_244), heff_dup(v_l_240));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_l_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      }
      case TAG_False: {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2efindField_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2efindField(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return ((V)&g_heff_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_t_247 = heff_strEq(v_k_245, heff_dup(v_l_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_clo(g_heff_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, v_l_240, v_rest_244});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eothersPure(a[0], a[1]);
}
V g_heff_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = ({ V b_0 = heff_get(heff_dup(v_s_248), LBL_safe); V b_1 = heff_get(heff_dup(v_s_248), LBL_total); V a_2 = v_f_246; V r_ = (g_heff_2esimplify_2epureIn(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_f_246);
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_2410 = ({ V a_0 = heff_dup(v_s_248); V a_1 = v_f_246; V r_ = (g_heff_2esimplify_2epartialIn(a_0, a_1)); heff_drop(v_f_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_x2_2411 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_s_248});
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    switch (heff_tag_of(v_x_2412)) {
    case TAG_True: {
      heff_drop_cell(v_ru_24x2_2411_24MkPair, 2);
      V v_t_2414 = (g_heff_2esimplify_2eothersPure(v_l_240, v_rest_244));
      V f_ = v_t_2414;
      args[0] = v_s_2413;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      heff_drop(v_l_240);
      heff_drop(v_rest_244);
      return heff_tag_at(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2413});
    }
    default: return heff_nomatch(v_x_2412);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2esimplify_2eprojectF_lam0(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam1(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam2(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam3(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam4(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam5(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam6(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam7(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam8(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam9(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam10(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam11(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam12(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam13(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam14(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam15(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam16(V self, V *args);
V g_heff_2esimplify_2eprojectF_lam17(V self, V *args);
Clo g_heff_2esimplify_2eprojectF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eprojectF_entry, 3, 0};

V g_heff_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam0, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_e_242, 0));
    return heff_clo(g_heff_2esimplify_2eprojectF_lam1, 1, 4, (V[]){v_g_245, v_e_242, v_l_241, v_r_240});
  }
  case TAG_ELam: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam2, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EApp: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam3, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_e_242, 0);
    V v_a_2419 = heff_field(v_e_242, 1);
    V v_b_2420 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2421 = heff_tr(heff_apply(heff_get(v_r_240, LBL_project), 2, (V[]){v_l_241, v_b_2420}));
    return heff_clo(g_heff_2esimplify_2eprojectF_lam4, 1, 3, (V[]){v_m_2421, v_x_2418, v_a_2419});
  }
  case TAG_ERecord: {
    V v_fs_2426 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_240);
    V v_t_2427 = (g_heff_2esimplify_2efindField(heff_dup(v_l_241), v_fs_2426));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nothing: {
      return heff_clo(g_heff_2esimplify_2eprojectF_lam5, 1, 2, (V[]){v_fs_2426, v_l_241});
    }
    case TAG_Just: {
      V v_v_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      V v_m_2431 = (g_heff_2esimplify_2eothersPure(heff_dup(v_l_241), heff_dup(v_fs_2426)));
      return heff_clo(g_heff_2esimplify_2eprojectF_lam6, 1, 4, (V[]){v_m_2431, v_v_2430, v_fs_2426, v_l_241});
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_EProj: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam7, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_ETag: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam8, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EMatch: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam9, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EPrim: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam10, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EPrimCall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam11, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_ECall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam12, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EInt: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam13, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EFloat: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam14, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EStr: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam15, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam16, 1, 2, (V[]){v_e_242, v_l_241});
  }
  case TAG_EFix: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2eprojectF_lam17, 1, 2, (V[]){v_e_242, v_l_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esimplify_2eprojectF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eprojectF(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2eprojectF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_244});
}
V g_heff_2esimplify_2eprojectF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = (g_heff_2esimplify_2eknown(v_g_245, v_s_246));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_249});
    }
    case TAG_Just: {
      V v_b_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      V v_t_2411 = heff_tr(heff_apply(heff_get(v_r_240, LBL_project), 2, (V[]){heff_dup(v_l_241), v_b_2410}));
      return (g_heff_2esimplify_2eattempt(heff_tag_at(v_ru_24x2_247_24MkPair, TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_t_2411, v_s_249));
    }
    default: return heff_nomatch(v_x_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2esimplify_2eprojectF_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2414});
}
V g_heff_2esimplify_2eprojectF_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2417});
}
V g_heff_2esimplify_2eprojectF_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_a_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2423 = heff_tr(heff_apply(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2418, v_a_2419, v_x_2424}), v_s_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2esimplify_2eprojectF_lam5(V self, V *args) {
  V v_s_2428 = args[0];
  V v_fs_2426 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = heff_tag(TAG_EProj, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_fs_2426}), v_l_241});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2429, v_s_2428});
}
V g_heff_2esimplify_2eprojectF_lam6(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_v_2430 = heff_env(self)[1];
  V v_fs_2426 = heff_env(self)[2];
  V v_l_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_apply(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_x_2436;
    switch (heff_tag_of(v_x_2434)) {
    case TAG_True: {
      heff_drop(v_fs_2426);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24x2_2433_24MkPair, 2);
      v_x_2436 = v_v_2430;
      break;
    }
    case TAG_False: {
      heff_drop(v_v_2430);
      v_x_2436 = heff_tag_at(v_ru_24x2_2433_24MkPair, TAG_EProj, 2, (V[]){heff_tag(TAG_ERecord, 1, (V[]){v_fs_2426}), v_l_241});
      break;
    }
    default: heff_nomatch(v_x_2434);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){v_x_2436, v_s_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2esimplify_2eprojectF_lam7(V self, V *args) {
  V v_s_2439 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2439});
}
V g_heff_2esimplify_2eprojectF_lam8(V self, V *args) {
  V v_s_2442 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2442});
}
V g_heff_2esimplify_2eprojectF_lam9(V self, V *args) {
  V v_s_2445 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2445});
}
V g_heff_2esimplify_2eprojectF_lam10(V self, V *args) {
  V v_s_2447 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2447});
}
V g_heff_2esimplify_2eprojectF_lam11(V self, V *args) {
  V v_s_2450 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2450});
}
V g_heff_2esimplify_2eprojectF_lam12(V self, V *args) {
  V v_s_2453 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2453});
}
V g_heff_2esimplify_2eprojectF_lam13(V self, V *args) {
  V v_s_2455 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2455});
}
V g_heff_2esimplify_2eprojectF_lam14(V self, V *args) {
  V v_s_2457 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2457});
}
V g_heff_2esimplify_2eprojectF_lam15(V self, V *args) {
  V v_s_2459 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2459});
}
V g_heff_2esimplify_2eprojectF_lam16(V self, V *args) {
  V v_s_2460 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2460});
}
V g_heff_2esimplify_2eprojectF_lam17(V self, V *args) {
  V v_s_2463 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_242, v_l_241}), v_s_2463});
}
Clo g_heff_2esimplify_2efindArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2efindArm_entry, 2, 0};

V g_heff_2esimplify_2efindArm(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      V v_t_247 = heff_strEq(heff_dup(v_t2_244), heff_dup(v_t_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkArm, 3, (V[]){heff_dup(v_t2_244), heff_dup(v_vs_245), heff_dup(v_b_246)})});
      }
      case TAG_False: {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esimplify_2efindArm_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2efindArm(a[0], a[1]); heff_drop(a[1]); return r;
}

static V g_heff_2esimplify_2ecaseBudget_val;
static int g_heff_2esimplify_2ecaseBudget_st;
static V g_heff_2esimplify_2ecaseBudget_init(void) {
  return MK_INT(40LL);
}
V g_heff_2esimplify_2ecaseBudget_get(void) {
  if (g_heff_2esimplify_2ecaseBudget_st == 2) return g_heff_2esimplify_2ecaseBudget_val;
  if (g_heff_2esimplify_2ecaseBudget_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2ecaseBudget_st = 1;
  g_heff_2esimplify_2ecaseBudget_val = heff_tr(g_heff_2esimplify_2ecaseBudget_init());
  g_heff_2esimplify_2ecaseBudget_st = 2;
  return g_heff_2esimplify_2ecaseBudget_val;
}
Clo g_heff_2esimplify_2epushArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2epushArm_entry, 4, 0};

V g_heff_2esimplify_2epushArm(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    V v_x2_248 = (g_heff_2eir_2efreshGo_24s504(heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_p_243), LBL_supply), v_t_247));
    V v_x2_2412;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_e_27_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2411 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n_2410, heff_get(heff_dup(v_p_243), LBL_fuel), heff_get(heff_dup(v_p_243), LBL_defs), heff_get(heff_dup(v_p_243), LBL_safe), heff_get(heff_dup(v_p_243), LBL_total), heff_get(heff_dup(v_p_243), LBL_plain), heff_get(v_p_243, LBL_sp)});
      v_x2_2412 = heff_tag_at(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_249, v_t_2411});
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_t_2441;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_EVar: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_2413, 0ULL, 3);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2430 = heff_field(v_x_2413, 1);
        heff_take_n(v_x_2413, 2ULL, 2);
        v_t_2441 = v_arms_2430;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_2413, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_2413, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_m_2442 = heff_tr(heff_apply(heff_get(v_r_240, LBL_match), 2, (V[]){v_b_246, v_t_2441}));
      V v_x2_2443 = heff_tr(heff_apply(v_m_2442, 1, (V[]){v_s_2414}));
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_MkPair: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_s_2445 = heff_field(v_x2_2443, 1);
        heff_take_n(v_x2_2443, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2444}), v_s_2445});
      }
      default: return heff_nomatch(v_x2_2443);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esimplify_2epushArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2epushArm(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2ecaseOfCase_lam0(V self, V *args);
V g_heff_2esimplify_2ecaseOfCase_lam1(V self, V *args);
V g_heff_2esimplify_2ecaseOfCase_lam2(V self, V *args);
Clo g_heff_2esimplify_2ecaseOfCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ecaseOfCase_entry, 4, 0};

V g_heff_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_prelude_2eany_24s526(v_arms2_242));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = heff_tag(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), heff_dup(v_arms_243)});
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_t_248 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_arms2_242));
    V v_t_249 = heff_intMul(v_t_247, heff_intSub(v_t_248, MK_INT(1LL)));
    V v_t_2410 = heff_intLe(v_t_249, heff_dup(g_heff_2esimplify_2ecaseBudget_get()));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2epushArm_clo), 2, (V[]){v_r_240, v_arms_243}));
      V v_m_2412 = (g_heff_2esimplify_2etraverseS(v_t_2411, v_arms2_242));
      return heff_clo(g_heff_2esimplify_2ecaseOfCase_lam0, 1, 2, (V[]){v_m_2412, v_s2_241});
    }
    case TAG_False: {
      heff_drop(v_r_240);
      return heff_clo(g_heff_2esimplify_2ecaseOfCase_lam1, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_False: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ecaseOfCase_lam2, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esimplify_2ecaseOfCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ecaseOfCase(a[0], a[1], a[2], a[3]);
}
V g_heff_2esimplify_2ecaseOfCase_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_s2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s2_241, v_x_2415}), v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2esimplify_2ecaseOfCase_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag(TAG_EMatch, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2417});
}
V g_heff_2esimplify_2ecaseOfCase_lam2(V self, V *args) {
  V v_s_2419 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag(TAG_EMatch, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2420, v_s_2419});
}
V g_heff_2esimplify_2ematchF_lam0(V self, V *args);
V g_heff_2esimplify_2ematchF_lam1(V self, V *args);
V g_heff_2esimplify_2ematchF_lam2(V self, V *args);
V g_heff_2esimplify_2ematchF_lam3(V self, V *args);
V g_heff_2esimplify_2ematchF_lam4(V self, V *args);
V g_heff_2esimplify_2ematchF_lam5(V self, V *args);
V g_heff_2esimplify_2ematchF_lam6(V self, V *args);
V g_heff_2esimplify_2ematchF_lam7(V self, V *args);
V g_heff_2esimplify_2ematchF_lam8(V self, V *args);
V g_heff_2esimplify_2ematchF_lam9(V self, V *args);
V g_heff_2esimplify_2ematchF_lam10(V self, V *args);
V g_heff_2esimplify_2ematchF_lam11(V self, V *args);
V g_heff_2esimplify_2ematchF_lam12(V self, V *args);
V g_heff_2esimplify_2ematchF_lam13(V self, V *args);
V g_heff_2esimplify_2ematchF_lam14(V self, V *args);
V g_heff_2esimplify_2ematchF_lam15(V self, V *args);
Clo g_heff_2esimplify_2ematchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2ematchF_entry, 3, 0};

V g_heff_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam0, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_s_241, 0));
    return heff_clo(g_heff_2esimplify_2ematchF_lam1, 1, 4, (V[]){v_g_245, v_s_241, v_arms_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam2, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EApp: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam3, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ELet: {
    V v_x_2443 = heff_field(v_s_241, 0);
    V v_a_2444 = heff_field(v_s_241, 1);
    V v_b_2445 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_2446 = heff_tr(heff_apply(heff_get(v_r_240, LBL_match), 2, (V[]){v_b_2445, v_arms_242}));
    return heff_clo(g_heff_2esimplify_2ematchF_lam4, 1, 3, (V[]){v_m_2446, v_x_2443, v_a_2444});
  }
  case TAG_ERecord: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam5, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EProj: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam6, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ETag: {
    V v_t_2456 = heff_dup(heff_field(v_s_241, 0));
    V v_as_2457 = heff_dup(heff_field(v_s_241, 1));
    V v_it_2458 = (g_heff_2esimplify_2efindArm(v_t_2456, v_arms_242));
    switch (heff_tag_of(v_it_2458)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      heff_drop(v_as_2457);
      return heff_clo(g_heff_2esimplify_2ematchF_lam7, 1, 2, (V[]){v_s_241, v_arms_242});
    }
    case TAG_Just: {
      V v_it1_2460 = heff_field(v_it_2458, 0);
      heff_take_n(v_it_2458, 1ULL, 1);
      heff_drop_tag(v_s_241, 2);
      heff_drop(v_arms_242);
      switch (heff_tag_of(v_it1_2460)) {
      case TAG_MkArm: {
        V v_vs_2462 = heff_field(v_it1_2460, 1);
        V v_b_2463 = heff_field(v_it1_2460, 2);
        heff_take_n(v_it1_2460, 6ULL, 3);
        V v_t_2464 = (g_heff_2esimplify_2ezipL(v_vs_2462, v_as_2457));
        V v_t_2465 = ({ V a_0 = v_t_2464; V a_1 = v_b_2463; V r_ = (g_heff_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2464); r_; });
        return heff_tail(heff_get(v_r_240, LBL_simp), 1, (V[]){v_t_2465});
      }
      default: return heff_nomatch(v_it1_2460);
      }
    }
    default: return heff_nomatch(v_it_2458);
    }
  }
  case TAG_EMatch: {
    V v_s2_2466 = heff_field(v_s_241, 0);
    V v_arms2_2467 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 3ULL, 2);
    return (g_heff_2esimplify_2ecaseOfCase(v_r_240, v_s2_2466, v_arms2_2467, v_arms_242));
  }
  case TAG_EPrim: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam8, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EPrimCall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam9, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ECall: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam10, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EInt: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam11, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam12, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EStr: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam13, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam14, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFix: {
    heff_drop(v_r_240);
    return heff_clo(g_heff_2esimplify_2ematchF_lam15, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2esimplify_2ematchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2ematchF(a[0], a[1], a[2]);
}
V g_heff_2esimplify_2ematchF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_244});
}
V g_heff_2esimplify_2ematchF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = (g_heff_2esimplify_2eknown(v_g_245, v_s_246));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
    }
    case TAG_Just: {
      V v_it1_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2410, 0ULL, 3);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ETag: {
        V v_t2_2423 = heff_field(v_it1_2410, 0);
        V v_as2_2424 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        heff_drop_tag(v_s_241, 1);
        heff_drop_cell(v_ru_24x2_247_24MkPair, 2);
        return heff_tail(heff_get(v_r_240, LBL_match), 3, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t2_2423, v_as2_2424}), v_arms_242, v_s_249});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EAbandon: {
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_x_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2esimplify_2ematchF_lam2(V self, V *args) {
  V v_s_2439 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2439});
}
V g_heff_2esimplify_2ematchF_lam3(V self, V *args) {
  V v_s_2442 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2442});
}
V g_heff_2esimplify_2ematchF_lam4(V self, V *args) {
  V v_s_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_a_2444 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_apply(v_m_2446, 1, (V[]){v_s_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_s_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2443, v_a_2444, v_x_2449}), v_s_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2esimplify_2ematchF_lam5(V self, V *args) {
  V v_s_2452 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2452});
}
V g_heff_2esimplify_2ematchF_lam6(V self, V *args) {
  V v_s_2455 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2455});
}
V g_heff_2esimplify_2ematchF_lam7(V self, V *args) {
  V v_s_2459 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2459});
}
V g_heff_2esimplify_2ematchF_lam8(V self, V *args) {
  V v_s_2469 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2469});
}
V g_heff_2esimplify_2ematchF_lam9(V self, V *args) {
  V v_s_2472 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2472});
}
V g_heff_2esimplify_2ematchF_lam10(V self, V *args) {
  V v_s_2475 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2475});
}
V g_heff_2esimplify_2ematchF_lam11(V self, V *args) {
  V v_s_2477 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2477});
}
V g_heff_2esimplify_2ematchF_lam12(V self, V *args) {
  V v_s_2479 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2479});
}
V g_heff_2esimplify_2ematchF_lam13(V self, V *args) {
  V v_s_2481 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2481});
}
V g_heff_2esimplify_2ematchF_lam14(V self, V *args) {
  V v_s_2482 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2482});
}
V g_heff_2esimplify_2ematchF_lam15(V self, V *args) {
  V v_s_2485 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2485});
}
V g_heff_2esimplify_2esk_lam0(V self, V *args); static Clo g_heff_2esimplify_2esk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam0, 1, 0};
V g_heff_2esimplify_2esk_lam1(V self, V *args); static Clo g_heff_2esimplify_2esk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam1, 2, 0};
V g_heff_2esimplify_2esk_lam2(V self, V *args); static Clo g_heff_2esimplify_2esk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam2, 2, 0};
V g_heff_2esimplify_2esk_lam3(V self, V *args); static Clo g_heff_2esimplify_2esk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esk_lam3, 2, 0};

static V g_heff_2esimplify_2esk_val;
static int g_heff_2esimplify_2esk_st;
static V g_heff_2esimplify_2esk_init(void) {
  return heff_rec(4, shape_307_10_258_186, (V[]){((V)&g_heff_2esimplify_2esk_lam0_clo), ((V)&g_heff_2esimplify_2esk_lam1_clo), ((V)&g_heff_2esimplify_2esk_lam2_clo), ((V)&g_heff_2esimplify_2esk_lam3_clo)});
}
V g_heff_2esimplify_2esk_get(void) {
  if (g_heff_2esimplify_2esk_st == 2) return g_heff_2esimplify_2esk_val;
  if (g_heff_2esimplify_2esk_st == 1) heff_fail("defined by itself");
  g_heff_2esimplify_2esk_st = 1;
  g_heff_2esimplify_2esk_val = heff_tr(g_heff_2esimplify_2esk_init());
  g_heff_2esimplify_2esk_st = 2;
  return g_heff_2esimplify_2esk_val;
}
V g_heff_2esimplify_2esk_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), v_e_240));
}
V g_heff_2esimplify_2esk_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_as_242 = args[1];
  return (g_heff_2esimplify_2eapplyToF(heff_dup(g_heff_2esimplify_2esk_get()), v_f_241, v_as_242));
}
V g_heff_2esimplify_2esk_lam2(V self, V *args) {
  V v_l_243 = args[0];
  V v_e_244 = args[1];
  return (g_heff_2esimplify_2eprojectF(heff_dup(g_heff_2esimplify_2esk_get()), v_l_243, v_e_244));
}
V g_heff_2esimplify_2esk_lam3(V self, V *args) {
  V v_s_245 = args[0];
  V v_arms_246 = args[1];
  return (g_heff_2esimplify_2ematchF(heff_dup(g_heff_2esimplify_2esk_get()), v_s_245, v_arms_246));
}
Clo g_heff_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_a_244 = (g_heff_2eir_2esizeB(heff_dup(g_heff_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_243));
  V v_x1_245 = heff_intLt(heff_dup(g_heff_2esimplify_2especBodySize_get()), v_a_244);
  V v_t_247;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    v_t_247 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
    break;
  }
  case TAG_False: {
    V v_t_246 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_all);
    v_t_247 = (g_map_2einsert_24s7(heff_dup(v_key_240), heff_dup(v_b_241), v_t_246));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_t_2434;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2436;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_True: {
    V v_t_2435 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
    v_t_2436 = (g_map_2einsert_24s7(v_key_240, NTAG(TAG_MkUnit), v_t_2435));
    break;
  }
  case TAG_False: {
    heff_drop(v_key_240);
    v_t_2436 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_kinds);
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  V v_t_2437 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_specs);
  V v_t_2438 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_made);
  V v_t_2439 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_count);
  V v_t_2440 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_within);
  V v_t_2441 = heff_get(heff_get(heff_dup(v_s_242), LBL_sp), LBL_trying);
  V v_p_2442 = heff_rec(7, shape_5_155_316_184_52_375_350, (V[]){v_t_247, v_t_2436, v_t_2437, v_t_2438, v_t_2439, v_t_2440, v_t_2441});
  return heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), heff_get(heff_dup(v_s_242), LBL_defs), heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(v_s_242, LBL_plain), v_p_2442});
}
V g_heff_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2erecordDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2erecordDef_entry, 3, 0};

V g_heff_2esimplify_2erecordDef(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_t_244 = (g_heff_2eir_2enubI(v_t_243));
  V v_t_245 = ({ V a_0 = heff_dup(v_key_240); V a_1 = v_t_244; V r_ = (g_heff_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_247 = v_s_242;
    break;
  }
  case TAG_False: {
    V v_d_246 = (g_map_2einsert_24s7(heff_dup(v_key_240), heff_dup(v_b_241), heff_get(heff_dup(v_s_242), LBL_defs)));
    v_t_247 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_242), LBL_supply), heff_get(heff_dup(v_s_242), LBL_fuel), v_d_246, heff_get(heff_dup(v_s_242), LBL_safe), heff_get(heff_dup(v_s_242), LBL_total), heff_get(heff_dup(v_s_242), LBL_plain), heff_get(v_s_242, LBL_sp)});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), (g_heff_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_247))});
}
V g_heff_2esimplify_2erecordDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2erecordDef(a[0], a[1], a[2]);
}
Clo g_heff_2esimplify_2etakeMade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etakeMade_entry, 1, 0};

V g_heff_2esimplify_2etakeMade(V v_s_240) {
top: ;
  V v_t_241 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_made);
  V v_t_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_t_241));
  V v_t_243 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_all);
  V v_t_244 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_kinds);
  V v_t_245 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_specs);
  V v_t_246 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_count);
  V v_t_247 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_within);
  V v_t_248 = heff_get(heff_get(heff_dup(v_s_240), LBL_sp), LBL_trying);
  V v_t_249 = heff_rec(7, shape_5_155_316_184_52_375_350, (V[]){v_t_243, v_t_244, v_t_245, NTAG(TAG_Nil), v_t_246, v_t_247, v_t_248});
  V v_t_2410 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_240), LBL_supply), heff_get(heff_dup(v_s_240), LBL_fuel), heff_get(heff_dup(v_s_240), LBL_defs), heff_get(heff_dup(v_s_240), LBL_safe), heff_get(heff_dup(v_s_240), LBL_total), heff_get(v_s_240, LBL_plain), v_t_249});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_242, v_t_2410});
}
V g_heff_2esimplify_2etakeMade_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etakeMade(a[0]);
}
Clo g_heff_2esimplify_2eoneDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2eoneDef_entry, 2, 0};

V g_heff_2esimplify_2eoneDef(V v_d_240, V v_s_241) {
top: ;
  V v_m_242 = (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), heff_get(heff_dup(v_d_240), LBL_body)));
  V v_t_243 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){heff_get(heff_dup(v_s_241), LBL_supply), MK_INT(4000LL), heff_get(heff_dup(v_s_241), LBL_defs), heff_get(heff_dup(v_s_241), LBL_safe), heff_get(heff_dup(v_s_241), LBL_total), heff_get(heff_dup(v_s_241), LBL_plain), heff_get(v_s_241, LBL_sp)});
  V v_x2_244 = heff_tr(heff_apply(v_m_242, 1, (V[]){v_t_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_m_247 = (g_heff_2esimplify_2esimpF(heff_dup(g_heff_2esimplify_2esk_get()), v_x_245));
    V v_x2_248 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_s_246}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_x2_2411 = (g_heff_2esimplify_2eraise(v_x_249, v_s_2410));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_s_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        V v_x2_2414 = (g_heff_2esimplify_2erecordDef(heff_get(heff_dup(v_d_240), LBL_key), heff_dup(v_x_2412), v_s_2413));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 2ULL, 2);
          V v_x2_2417 = (g_heff_2esimplify_2emarkSafe(heff_get(heff_dup(v_d_240), LBL_key), v_x_2412, v_s_2416));
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_MkPair: {
            V v_s_2419 = heff_field(v_x2_2417, 1);
            heff_take_n(v_x2_2417, 2ULL, 2);
            V v_x2_2420 = (g_heff_2esimplify_2etakeMade(v_s_2419));
            switch (heff_tag_of(v_x2_2420)) {
            case TAG_MkPair: {
              V v_x_2421 = heff_field(v_x2_2420, 0);
              V v_s_2422 = heff_field(v_x2_2420, 1);
              heff_take_n(v_x2_2420, 3ULL, 2);
              V v_t_2423 = heff_rec(3, shape_152_198_28, (V[]){heff_get(heff_dup(v_d_240), LBL_key), heff_get(v_d_240, LBL_name), v_x_2412});
              V v_t_2424 = heff_tag_at(v_ru_24x2_244_24MkPair, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
              V v_x_2425 = (g_heff_2esimplify_2eappendL(v_x_2421, v_t_2424));
              return heff_tag_at(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2425, v_s_2422});
            }
            default: return heff_nomatch(v_x2_2420);
            }
          }
          default: return heff_nomatch(v_x2_2417);
          }
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2esimplify_2eoneDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2eoneDef(a[0], a[1]);
}
Clo g_heff_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2esimplify_2econcatDefs(v_rest_242));
    return (g_heff_2esimplify_2eappendL(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esimplify_2econcatDefs(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2esimplify_2etraverseS_24s527_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2etraverseS_24s527_entry, 2, 0};

V g_heff_2esimplify_2etraverseS_24s527(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2esimplify_2eoneDef(v_x_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      V v_m_247 = heff_tr(heff_apply(((V)&g_heff_2esimplify_2etraverseS_24s527_clo), 1, (V[]){v_xs_243}));
      V v_x2_248 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_s_246}));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_s_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_245, v_x_249}), v_s_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esimplify_2etraverseS_24s527_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2etraverseS_24s527(a[0], a[1]);
}
Clo g_heff_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_prelude_2efoldl_24s516(heff_rec(2, shape_286_345, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}), v_defs_241));
  V v_t_243 = heff_rec(7, shape_5_155_316_184_52_375_350, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_244 = heff_rec(7, shape_328_109_59_286_345_246_313, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_get(heff_dup(v_sg_242), LBL_safe), heff_get(v_sg_242, LBL_total), heff_dup(g_map_2eempty_get()), v_t_243});
  V v_x1_245 = (g_heff_2esimplify_2etraverseS_24s527(v_defs_241, v_t_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_out_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    V v_t_248 = ({ V a_0 = v_out_246; V r_ = (g_heff_2esimplify_2econcatDefs(a_0)); heff_drop(v_out_246); r_; });
    return heff_rec(2, shape_59_328, (V[]){v_t_248, heff_get(v_st_247, LBL_supply)});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2esimplify_2esimplifyProgram(a[0], a[1]);
}