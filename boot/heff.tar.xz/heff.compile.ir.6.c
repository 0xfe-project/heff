// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_MkArm 55352
#define LBL_m 327
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
V g_heff_2ecompile_2eir_2eallArms(V, V);
V g_heff_2ecompile_2eir_2eallArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallArms_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econcatMapI(V, V);
V g_heff_2ecompile_2eir_2econcatMapI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
V g_heff_2ecompile_2eir_2efoldFields(V, V, V);
V g_heff_2ecompile_2eir_2efoldFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldFields_clo;
V g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393(V, V);
V g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794(V, V, V);
V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2esubstGo_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24dps_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2erunes_2ereads(V);
V g_heff_2ecompile_2erunes_2ereads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereads_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s524770901x1440232311(V, V);
V g_list_2efoldl_24s524770901x1440232311_entry(V self, V *a);
extern Clo g_list_2efoldl_24s524770901x1440232311_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str2, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str3, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str4, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str5, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str6, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str7, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str8, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str9, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str10, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str11, 7, "Float32");

HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str0), 2)) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtFloat)}});
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str1), 2)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtOther)}});
    } else {
      if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str2), 2)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtAny)}});
      } else {
        HeffT2 v_t_241 = ({ V a_0 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str3); V a_1 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str4); V a_2 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str5); V a_3 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str6); V a_4 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str7); V a_5 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str8); V a_6 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str9); V a_7 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str10); V a_8 = ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str11); V a_9 = v_x_240; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
        {
          V v_field_243 = v_t_241.f[1];
          int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
          if ((v_tag_242 == ((int64_t)0ULL))) {
            V v_x_244 = v_field_243;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_FtFixed, 1, (V[]){v_x_244})}});
          } else {
            heff_drop(v_field_243);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2eir_2econcatMapI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_entry, 2, 0};

V g_heff_2ecompile_2eir_2econcatMapI(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2ecompile_2eir_2econcatMapI(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2econcatMapI(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
Clo g_heff_2ecompile_2eir_2efoldFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldFields_entry, 3, 0};

V g_heff_2ecompile_2eir_2efoldFields(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_fs_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_e_246 = heff_field(v_x21_243, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 3, (V[]){NTAG(TAG_Nil), heff_dup(v_e_246), v_acc_242}));
      V t_0 = v_f_240;
      V t_1 = v_fs_244;
      V t_2 = v_t_247;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2efoldFields_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2efoldFields(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eallArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallArms_entry, 2, 0};

V g_heff_2ecompile_2eir_2eallArms(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_arms_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_dup(v_vs_245), heff_dup(v_b_246)}));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V t_0 = v_f_240;
        V t_1 = v_arms_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_f_240);
        heff_drop(v_t_247);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2eallArms_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2eallArms(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2ewaysOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysOnto_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysOnto(V v_e_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_2410;
    V t_1 = v_rest_241;
    v_e_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EMatch: {
    V v_arms_2421 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2421));
    return ({ V a_0 = v_rest_241; V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s524770901x1440232311(a_0, a_1)); heff_drop(v_t_2422); r_; });
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EBool: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_ESet: {
    V v_b_2438 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_2438;
    V t_1 = v_rest_241;
    v_e_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  case TAG_EValues: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, v_rest_241});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysOnto(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkArm: {
      V v_tag_245 = heff_field(v_x41_243, 0);
      V v_vars_246 = heff_field(v_x41_243, 1);
      V v_body_247 = heff_field(v_x41_243, 2);
      V v_ru_24x41_243_24MkArm = heff_take_reuse_n(v_x41_243, 7ULL, 3);
      V v_t_248 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(v_m_240), v_n_241, NTAG(TAG_Nil)});
      V v_v_249 = (g_list_2efoldl_24s690313412x1307839513(v_t_248, v_vars_246));
      V v_m_2410 = heff_take_field(v_v_249, 0);
      V v_n_2411 = heff_take_field(v_v_249, 1);
      V v_xs_2412 = heff_get_n(v_v_249, 2, 3);
      HeffT2 v_t_2413 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2410, v_n_2411, v_body_247));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_b_27_2416 = v_field_2414;
        V v_n1_2417 = v_field_2415;
        V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
        V v_a_2419 = heff_tag_at_n(v_ru_24x41_243_24MkArm, TAG_MkArm, 3, (V[]){v_tag_245, v_t_2418, v_b_27_2416});
        HeffT2 v_t_2420 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(v_m_240, v_n1_2417, v_rest_244));
        {
          V v_field_2421 = v_t_2420.f[0];
          V v_field_2422 = v_t_2420.f[1];
          V v_args_2423 = v_field_2421;
          V v_n_2424 = v_field_2422;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_a_2419, v_args_2423}), v_n_2424}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry, 3, 0};

V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2eir_2esubstGo_24dps(V v_m_240, V v_e_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_240, v_x_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_244);
        V v_e2_248 = v_field_247;
        return heff_setField(v_d_242, v_i_243, v_e2_248);
      } else {
        heff_drop(v_field_247);
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EVar, 1, (V[]){v_x_244}));
      }
    }
  }
  case TAG_EGlobal: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ELam: {
    V v_xs_2410 = heff_field(v_e_241, 0);
    V v_b_2411 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_2412 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2410, heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_m_240;
    V t_1 = v_b_2411;
    V t_2 = v_cell_2412;
    V t_3 = MK_INT(1LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_e_241, 0);
    V v_args_2415 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_f_2414));
    V v_t_2418 = (g_list_2emap_24tok2(v_ru_24e_241_24EApp, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2415));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2416, v_t_2418}));
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_e_241, 0);
    V v_a_2420 = heff_field(v_e_241, 1);
    V v_b_2421 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2422 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2420));
    V v_cell_2423 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_t_2422, heff_hole()});
    V v_u_2424 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2423));
    heff_drop(v_u_2424);
    V t_0 = v_m_240;
    V t_1 = v_b_2421;
    V t_2 = v_cell_2423;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_e_241, 0);
    V v_ts_2426 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2431 = (g_list_2emap_24tok2(v_ru_24e_241_24ERecord, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2425));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2426}));
  }
  case TAG_EProj: {
    V v_e2_2432 = heff_field(v_e_241, 0);
    V v_l_2433 = heff_field(v_e_241, 1);
    V v_sh_2434 = heff_field(v_e_241, 2);
    V v_t_2435 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_t_2436 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_e2_2432));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2436, v_l_2433, v_sh_2434, v_t_2435}));
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_e_241, 0);
    V v_args_2438 = heff_field(v_e_241, 1);
    V v_ts_2439 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2438));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2437, v_t_2441, v_ts_2439}));
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_e_241, 0);
    V v_arms_2443 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_s_2442));
    V v_t_2450 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2443));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2444, v_t_2450}));
  }
  case TAG_EPrim: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EPrimCall: {
    V v_p_2452 = heff_field(v_e_241, 0);
    V v_args_2453 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2455 = (g_list_2emap_24tok2(v_ru_24e_241_24EPrimCall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2453));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2452, v_t_2455}));
  }
  case TAG_ECall: {
    V v_g_2456 = heff_field(v_e_241, 0);
    V v_args_2457 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2459 = (g_list_2emap_24tok2(v_ru_24e_241_24ECall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2457));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2456, v_t_2459}));
  }
  case TAG_EInt: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EStr: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBytes: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFixed: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat32: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBool: {
    V v_c_2467 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_2469 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam6, 1, 1, (V[]){heff_dup(v_m_240)}), v_c_2467));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EBool, 1, (V[]){v_t_2469}));
  }
  case TAG_ESet: {
    V v_xs_2470 = heff_field(v_e_241, 0);
    V v_a_2471 = heff_field(v_e_241, 1);
    V v_b_2472 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2473 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2471));
    V v_cell_2474 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2470, v_t_2473, heff_hole()});
    V v_u_2475 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2474));
    heff_drop(v_u_2475);
    V t_0 = v_m_240;
    V t_1 = v_b_2472;
    V t_2 = v_cell_2474;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2476 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_2478 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam7, 1, 1, (V[]){heff_dup(v_m_240)}), v_es_2476));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EValues, 1, (V[]){v_t_2478}));
  }
  case TAG_EFix: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2esubstGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2417; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam1(V self, V *args) {
  V v_p_2427 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_l_2428 = heff_field(v_p_2427, 0);
    V v_e2_2429 = heff_field(v_p_2427, 1);
    V v_ru_24p_2427_24MkPair = heff_take_reuse_n(v_p_2427, 3ULL, 2);
    V v_t_2430 = ({ V a_0 = v_m_240; V a_1 = v_e2_2429; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24p_2427_24MkPair, TAG_MkPair, 2, (V[]){v_l_2428, v_t_2430});
  }
  default: return heff_nomatch(v_p_2427);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam2(V self, V *args) {
  V v_a_2440 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2440; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam3(V self, V *args) {
  V v_a_2445 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2445)) {
  case TAG_MkArm: {
    V v_t_2446 = heff_field(v_a_2445, 0);
    V v_vs_2447 = heff_field(v_a_2445, 1);
    V v_b_2448 = heff_field(v_a_2445, 2);
    V v_ru_24a_2445_24MkArm = heff_take_reuse_n(v_a_2445, 7ULL, 3);
    V v_t_2449 = ({ V a_0 = v_m_240; V a_1 = v_b_2448; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24a_2445_24MkArm, TAG_MkArm, 3, (V[]){v_t_2446, v_vs_2447, v_t_2449});
  }
  default: return heff_nomatch(v_a_2445);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam4(V self, V *args) {
  V v_a_2454 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2454; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam5(V self, V *args) {
  V v_a_2458 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2458; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam6(V self, V *args) {
  V v_a_2468 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2468; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam7(V self, V *args) {
  V v_a_2477 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2477; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
Clo g_heff_2ecompile_2eir_2elamW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2elamW_entry, 2, 0};

V g_heff_2ecompile_2eir_2elamW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
      V v_x_249 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_248));
      if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
        heff_drop(v_rest_243);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x21_242, 0);
      V v_args_2411 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_args_2411, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2412});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2414 = heff_field(v_x21_242, 1);
      V v_b_2415 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2416;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2417, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2419;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2425 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2427 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2425, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2427;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2428 = heff_field(v_x21_242, 0);
      V v_arms_2429 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2430 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2429, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_t_2430});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2433 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2433, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2434;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2436 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2436, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2437;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2445 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2446 = ({ V a_0 = v_c_2445; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2445); r_; });
      V t_0 = v_x_240;
      V t_1 = v_t_2446;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2448 = heff_field(v_x21_242, 1);
      V v_b_2449 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2450 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2448, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2449, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2450;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2451 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2452 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2451, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2452;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2elamW(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_x1_2411 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(v_f_240, v_b_2410));
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Nothing: {
      heff_drop(v_x_248);
      heff_drop(v_a_249);
      heff_drop_cell(v_ru_24e_241_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_2412 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Just = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2411_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2412})});
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  case TAG_ERecord: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_e_241, 0);
    V v_arms_2423 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    HeffT2 v_t_2430 = (g_prelude_2etraverse_24s1760019503x148599044_24cpr(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_lam0, 1, 1, (V[]){v_f_240}), v_arms_2423));
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_x_2433 = v_field_2432;
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2422, v_x_2433})});
      } else {
        heff_drop(v_s_2422);
        heff_drop_cell(v_ru_24e_241_24EMatch, 2);
        heff_drop(v_field_2432);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_EPrim: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ESet: {
    V v_xs_2447 = heff_field(v_e_241, 0);
    V v_a_2448 = heff_field(v_e_241, 1);
    V v_b_2449 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_x1_2450 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(v_f_240, v_b_2449));
    switch (heff_tag_of(v_x1_2450)) {
    case TAG_Nothing: {
      heff_drop(v_xs_2447);
      heff_drop(v_a_2448);
      heff_drop_cell(v_ru_24e_241_24ESet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_2451 = heff_field(v_x1_2450, 0);
      V v_ru_24x1_2450_24Just = heff_take_reuse_n(v_x1_2450, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2450_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2447, v_a_2448, v_x_2451})});
    }
    default: return heff_nomatch(v_x1_2450);
    }
  }
  case TAG_EValues: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355_lam0(V self, V *args) {
  V v_x2_2424 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkArm: {
    V v_t_2425 = heff_field(v_x2_2424, 0);
    V v_vs_2426 = heff_field(v_x2_2424, 1);
    V v_b_2427 = heff_field(v_x2_2424, 2);
    V v_ru_24x2_2424_24MkArm = heff_take_reuse_n(v_x2_2424, 7ULL, 3);
    V v_x1_2428 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s602075336x1245665355(v_f_240, v_b_2427));
    switch (heff_tag_of(v_x1_2428)) {
    case TAG_Nothing: {
      heff_drop(v_t_2425);
      heff_drop(v_vs_2426);
      heff_drop_cell(v_ru_24x2_2424_24MkArm, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_2429 = heff_field(v_x1_2428, 0);
      V v_ru_24x1_2428_24Just = heff_take_reuse_n(v_x1_2428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2428_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_2424_24MkArm, TAG_MkArm, 3, (V[]){v_t_2425, v_vs_2426, v_x_2429})});
    }
    default: return heff_nomatch(v_x1_2428);
    }
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
Clo g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_entry, 3, 0};

V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794(V v_lit_240, V v_lit_241, V v_rest_242) {
top: ;
  return heff_tag_n(TAG_Cons, 2, (V[]){v_lit_241, v_rest_242});
}
V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_s_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_s_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_a_246 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam2, 1, 3, (V[]){v_a_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2415 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_a_2416 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_x_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam3, 1, 1, (V[]){v_a_2416});
  }
  case TAG_CNot: {
    V v_c_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2422 = (g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(v_c_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam4, 1, 1, (V[]){v_m_2422});
  }
  case TAG_CIf: {
    V v_a_2427 = heff_field(v_x2_27_240, 0);
    V v_b_2428 = heff_field(v_x2_27_240, 1);
    V v_c_2429 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam5, 1, 3, (V[]){v_m_2430, v_b_2428, v_c_2429});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam1(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam2(V self, V *args) {
  V v_n_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_a_248, 0);
    V v_n_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    V v_a_2411 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_y_245));
    V v_a_2412 = heff_tr(heff_call(v_a_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_a_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_a_2412, 0);
      V v_n_2414 = heff_field(v_a_2412, 1);
      heff_take_n(v_a_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24a_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_249, v_x_2413}), v_n_2414});
    }
    default: return heff_nomatch(v_a_2412);
    }
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam3(V self, V *args) {
  V v_n_2417 = args[0];
  V v_a_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2418 = heff_tr(heff_call(v_a_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_a_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_a_2418, 0);
    V v_n_2420 = heff_field(v_a_2418, 1);
    V v_ru_24a_2418_24MkPair = heff_take_reuse_n(v_a_2418, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2419}), v_n_2420});
  }
  default: return heff_nomatch(v_a_2418);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam4(V self, V *args) {
  V v_n_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_n_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2425}), v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_lam5(V self, V *args) {
  V v_n_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_c_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_n_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_n_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_m_2435 = (g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(v_b_2428));
    V v_x2_2436 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_n_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_n_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_m_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(v_c_2429));
      V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_n_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2433, v_x_2437, v_x_2441}), v_n_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
Clo g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393_entry, 2, 0};

V g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_fs_243 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_t_246;
      if ((heff_dup(v_acc_241) == NTAG(TAG_True))) {
        heff_drop(v_acc_241);
        v_t_246 = NTAG(TAG_True);
      } else {
        heff_drop(v_acc_241);
        v_t_246 = (g_heff_2ecompile_2erunes_2ereads(heff_dup(v_e_245)));
      }
      V t_0 = v_fs_243;
      V t_1 = v_t_246;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eir_2eappendI_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eir_2eappendI_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI_24tok2(a[0], a[1], a[2]);
}