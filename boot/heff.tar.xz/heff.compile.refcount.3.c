// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CReturn 19985
#define TAG_DFun 8330
#define TAG_F32 16337
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkWrapper 39179
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RBox 28228
#define TAG_RCall 39004
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RInt 34920
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_body 9524841
#define LBL_borrowed 695465691
#define LBL_cells 295903083
#define LBL_entry 298026124
#define LBL_key 315609
#define LBL_lent 9813446
#define LBL_n 328
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_sigs 10025609
#define LBL_sts 323756
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_tl 10463
#define LBL_tokens 1078955205
#define LBL_wrapper 1827365593
static uint32_t shape_key__params[] = {LBL_key, LBL_params};
static uint32_t shape_key__params__lent__entry__body__reprs__ret__wrapper[] = {LBL_key, LBL_params, LBL_lent, LBL_entry, LBL_body, LBL_reprs, LBL_ret, LBL_wrapper};
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
V g_heff_2ecompile_2eborrow_2eelemI(V, V);
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemI_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2erefcount_2echangedOf(V, V, V);
V g_heff_2ecompile_2erefcount_2echangedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2echangedOf_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efreeOf(V, V);
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeOf_clo;
V g_heff_2ecompile_2erefcount_2efunPlain(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunPlain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunPlain_clo;
V g_heff_2ecompile_2erefcount_2efunRc(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunRc_clo;
V g_heff_2ecompile_2erefcount_2efunWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunWith_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvTl_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvTl_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_24tok1_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eintPrims_get(void);
V g_heff_2ecompile_2erefcount_2eintW(V, V);
V g_heff_2ecompile_2erefcount_2eintW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eintW_clo;
V g_heff_2ecompile_2erefcount_2ejustsOf(V);
V g_heff_2ecompile_2erefcount_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_clo;
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(V, V);
V g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700_clo;
V g_heff_2ecompile_2erefcount_2ekeptFrom(V, V);
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2enaturalOf(V, V);
V g_heff_2ecompile_2erefcount_2enaturalOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enaturalOf_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_clo;
V g_heff_2ecompile_2erefcount_2eoperandsOf(V);
V g_heff_2ecompile_2erefcount_2eoperandsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsOf_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2_clo;
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082_clo;
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereusedOf(V);
V g_heff_2ecompile_2erefcount_2ereusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusedOf_clo;
V g_heff_2ecompile_2erefcount_2estrAs(V, V);
V g_heff_2ecompile_2erefcount_2estrAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estrAs_clo;
V g_heff_2ecompile_2erefcount_2estrAs_24tok1(V, V, V);
V g_heff_2ecompile_2erefcount_2estrAs_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estrAs_24tok1_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2ethreaded(V, V);
V g_heff_2ecompile_2erefcount_2ethreaded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreaded_clo;
HeffT2 g_heff_2ecompile_2erefcount_2etokenOp_24cpr(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenTl(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etokenTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etokenTl_clo;
V g_heff_2ecompile_2erefcount_2etyAt(V, V);
V g_heff_2ecompile_2erefcount_2etyAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etyAt_clo;
V g_heff_2ecompile_2erefcount_2eunboxOf(V, V);
V g_heff_2ecompile_2erefcount_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxOf_clo;
V g_heff_2ecompile_2erefcount_2eunboxParams(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eunboxParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eunboxParams_clo;
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_clo;
V g_heff_2ecompile_2erefcount_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eupdatedIn_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewrapArg(V, V, V);
V g_heff_2ecompile_2erefcount_2ewrapArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewrapArg_clo;
V g_heff_2ecompile_2erefcount_2ewrapUnbox(V, V, V);
V g_heff_2ecompile_2erefcount_2ewrapUnbox_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewrapUnbox_clo;
V g_heff_2ecompile_2erefcount_2ewrapperOf(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ewrapperOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewrapperOf_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2ereadRepr(V, V);
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereadRepr_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1678884672x1211895143(V, V);
V g_list_2eany_24s1678884672x1211895143_entry(V self, V *a);
extern Clo g_list_2eany_24s1678884672x1211895143_clo;
V g_list_2eany_24s1687778528x1571134043(V, V);
V g_list_2eany_24s1687778528x1571134043_entry(V self, V *a);
extern Clo g_list_2eany_24s1687778528x1571134043_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1813831864x676242789(V, V, V, V);
V g_list_2efoldl_24s1813831864x676242789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1813831864x676242789_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s1982386833x551161312(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1982386833x551161312_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1982386833x551161312_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s531657185x2070920831(V, V);
V g_list_2emap_24s531657185x2070920831_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2efreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efreeOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2efreeOf(V v_xs_240, V v_t_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_241}), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_bs_246 = v_field_244;
    V v_ms_247 = v_field_245;
    V v_bs_248 = (g_prelude_2e_2b_2b(v_xs_240, v_bs_246));
    V v_ms_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_247));
    V v_t_2410 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_248; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_248); r_; });
    return ({ V a_0 = v_t_2410; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_249; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efreeOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2efvTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvTl_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvTl(V v_t_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_240}), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_bs_245 = v_field_243;
    V v_ms_246 = v_field_244;
    V v_bs_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_245));
    V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_246));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_247; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_247); r_; });
    return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvTl(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ekeptFrom_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ekeptFrom(V v_ls_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(v_ls_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2ekeptFrom(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erefcount_2eupdatedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eupdatedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eupdatedIn_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eupdatedIn(V v_ce_240, V v_live_241, V v_ls_242, V v_fs_243) {
top: ;
  V v_owned_244 = heff_take_field(v_ce_240, 4);
  V v_borrowed_245 = heff_get_n(v_ce_240, 6, 17);
  V v_x_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_243));
  if (heff_intLt_c(MK_INT(62LL), v_x_246)) {
    heff_drop(v_fs_243);
    heff_drop(v_owned_244);
    heff_drop(v_borrowed_245);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_247 = (g_list_2emap_24s531657185x2070920831(v_ls_242, v_fs_243));
    V v_t_248 = (g_heff_2ecompile_2erefcount_2ejustsOf(v_t_247));
    V v_x1_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2eupdatedIn_lam0, 1, 3, (V[]){v_owned_244, heff_dup(v_live_241), v_borrowed_245}), v_t_248));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 2);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eupdatedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2eupdatedIn(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2eupdatedIn_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_owned_244 = heff_env(self)[0];
  V v_live_241 = heff_env(self)[1];
  V v_borrowed_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = v_owned_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_owned_244); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_x1_2411 = ({ V a_0 = v_x_249; V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    if (!(heff_dup(v_x1_2411) == NTAG(TAG_True))) {
      heff_drop(v_x1_2411);
      V v_x1_2412 = ({ V a_0 = v_x_249; V a_1 = v_borrowed_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_249); heff_drop(v_borrowed_245); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
      heff_drop(v_x1_2412);
      return v_ret_24bool;
    } else {
      heff_drop(v_x_249);
      heff_drop(v_borrowed_245);
      heff_drop(v_x1_2411);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_249);
    heff_drop(v_live_241);
    heff_drop(v_borrowed_245);
    heff_drop(v_t_2410);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2ecompile_2erefcount_2etyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etyAt_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2etyAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_FtOther);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return heff_dup(v_t_242);
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_ts_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2etyAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2etyAt(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2ecoerce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecoerce_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ecoerce(V v_from_240, V v_to_241, V v_v_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2erepr_2ereprEq(v_from_240, v_to_241));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_from_240);
    heff_drop(v_to_241);
    heff_drop(v_t_243);
    return v_v_242;
  } else {
    heff_drop(v_t_243);
    V v_t_245;
    switch (heff_tag_of(v_to_241)) {
    case TAG_RepV: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_to_241);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_to_241);
      heff_drop(v_t_245);
      return heff_tag_n(TAG_RBox, 2, (V[]){v_from_240, v_v_242});
    } else {
      heff_drop(v_t_245);
      switch (heff_tag_of(v_from_240)) {
      case TAG_RepV: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_241, v_v_242));
      }
      case TAG_RepFix: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_241, heff_tag_n(TAG_RBox, 2, (V[]){v_from_240, v_v_242})));
      }
      case TAG_RepF64: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_241, heff_tag_n(TAG_RBox, 2, (V[]){v_from_240, v_v_242})));
      }
      case TAG_RepInt: {
        return (g_heff_2ecompile_2erefcount_2eunboxOf(v_to_241, heff_tag_n(TAG_RBox, 2, (V[]){v_from_240, v_v_242})));
      }
      default: return heff_nomatch(v_from_240);
      }
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecoerce(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2enaturalOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2enaturalOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2enaturalOf(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        return v_x_246;
      } else {
        heff_drop(v_field_245);
        return NTAG(TAG_RepV);
      }
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SInt: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SFloat: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SStr: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SBytes: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SFixed: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SFloat32: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SPrimFn: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SLam: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_STag: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SRec: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SProj: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_RepV);
  }
  case TAG_SPrim: {
    V v_p_2427 = heff_field(v_v_241, 0);
    heff_drop_rec(v_ce_240, 17);
    HeffT2 v_t_2429 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_2427));
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_s_2432 = v_field_2431;
        return heff_get_n(v_s_2432, 1, 2);
      } else {
        heff_drop(v_field_2431);
        return NTAG(TAG_RepV);
      }
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erefcount_2enaturalOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2enaturalOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2etokenTl_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2etokenTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etokenTl_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2etokenTl(V v_k_240, V v_tk_241, V v_ru_242, V v_n_243, V v_x5_244) {
top: ;
  V v_sts_245 = heff_take_field(v_k_240, 0);
  V v_tl_246 = heff_get_n(v_k_240, 1, 2);
  switch (heff_tag_of(v_x5_244)) {
  case TAG_TSeq: {
    V v_ss_247 = heff_field(v_x5_244, 0);
    V v_t_248 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24TSeq = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    V v_it_249 = heff_tr(heff_call(v_sts_245, 1, (V[]){heff_dup(v_ss_247)}));
    switch (heff_tag_of(v_it_249)) {
    case TAG_MkPair: {
      V v_it1_2410 = heff_field(v_it_249, 0);
      V v_ss2_2411 = heff_field(v_it_249, 1);
      V v_ru_24it_249_24MkPair = heff_take_reuse_n(v_it_249, 3ULL, 2);
      if ((heff_dup(v_it1_2410) == NTAG(TAG_True))) {
        heff_drop(v_tl_246);
        heff_drop(v_ss_247);
        heff_drop(v_it1_2410);
        return heff_tag_at_n(v_ru_24it_249_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_at_n(v_ru_24x5_244_24TSeq, TAG_TSeq, 2, (V[]){v_ss2_2411, v_t_248})});
      } else {
        heff_drop(v_it1_2410);
        heff_drop(v_ss2_2411);
        V v_t_2412 = heff_tr(heff_call(v_tl_246, 1, (V[]){v_t_248}));
        switch (heff_tag_of(v_t_2412)) {
        case TAG_MkPair: {
          V v_b_2413 = heff_field(v_t_2412, 0);
          V v_t2_2414 = heff_field(v_t_2412, 1);
          heff_take_n(v_t_2412, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it_249_24MkPair, TAG_MkPair, 2, (V[]){v_b_2413, heff_tag_at_n(v_ru_24x5_244_24TSeq, TAG_TSeq, 2, (V[]){v_ss_247, v_t2_2414})});
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
    }
    default: return heff_nomatch(v_it_249);
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24TReturn = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_sts_245);
    heff_drop(v_tl_246);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2erefcount_2etokenOp_24cpr(v_tk_241, v_ru_242, v_n_243, v_o_2415));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_b_2419 = v_field_2417;
      V v_o2_2420 = v_field_2418;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2419, heff_tag_at_n(v_ru_24x5_244_24TReturn, TAG_TReturn, 1, (V[]){v_o2_2420})});
    }
  }
  case TAG_TLoop: {
    V v_vs_2421 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24TLoop = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    heff_drop(v_sts_245);
    heff_drop(v_tl_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), heff_tag_at_n(v_ru_24x5_244_24TLoop, TAG_TLoop, 1, (V[]){v_vs_2421})});
  }
  case TAG_TIf: {
    V v_c_2422 = heff_field(v_x5_244, 0);
    V v_t_2423 = heff_field(v_x5_244, 1);
    V v_e_2424 = heff_field(v_x5_244, 2);
    V v_ru_24x5_244_24TIf = heff_take_reuse_n(v_x5_244, 7ULL, 3);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    heff_drop(v_sts_245);
    V v_t_2425 = heff_tr(heff_call(heff_dup(v_tl_246), 1, (V[]){v_t_2423}));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_MkPair: {
      V v_bt_2426 = heff_field(v_t_2425, 0);
      V v_t2_2427 = heff_field(v_t_2425, 1);
      V v_ru_24t_2425_24MkPair = heff_take_reuse_n(v_t_2425, 3ULL, 2);
      V v_t_2428 = heff_tr(heff_call(v_tl_246, 1, (V[]){v_e_2424}));
      switch (heff_tag_of(v_t_2428)) {
      case TAG_MkPair: {
        V v_be_2429 = heff_field(v_t_2428, 0);
        V v_e2_2430 = heff_field(v_t_2428, 1);
        heff_take_n(v_t_2428, 3ULL, 2);
        V v_t_2431 = heff_bool(((heff_dup(v_bt_2426) == NTAG(TAG_True)) || (heff_dup(v_be_2429) == NTAG(TAG_True))));
        heff_drop(v_bt_2426);
        heff_drop(v_be_2429);
        return heff_tag_at_n(v_ru_24t_2425_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, heff_tag_at_n(v_ru_24x5_244_24TIf, TAG_TIf, 3, (V[]){v_c_2422, v_t2_2427, v_e2_2430})});
      }
      default: return heff_nomatch(v_t_2428);
      }
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_TCase: {
    V v_v_2432 = heff_field(v_x5_244, 0);
    V v_arms_2433 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24TCase = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    heff_drop(v_tk_241);
    heff_drop(v_ru_242);
    heff_drop(v_n_243);
    heff_drop(v_sts_245);
    V v_ps_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etokenTl_lam0, 1, 1, (V[]){v_tl_246}), v_arms_2433));
    V v_b_2442 = (g_list_2eany_24s910662703x1730636603(v_ps_2441));
    V v_as2_2443 = (g_list_2emap_24s1173914895x100384474(v_ps_2441));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2442, heff_tag_at_n(v_ru_24x5_244_24TCase, TAG_TCase, 2, (V[]){v_v_2432, v_as2_2443})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2erefcount_2etokenTl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2etokenTl(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erefcount_2etokenTl_lam0(V self, V *args) {
  V v_arm_2434 = args[0];
  V v_tl_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_arm_2434)) {
  case TAG_MkArm: {
    V v_t_2435 = heff_field(v_arm_2434, 0);
    V v_vs_2436 = heff_field(v_arm_2434, 1);
    V v_b_2437 = heff_field(v_arm_2434, 2);
    V v_ru_24arm_2434_24MkArm = heff_take_reuse_n(v_arm_2434, 7ULL, 3);
    V v_x3_2438 = heff_tr(heff_call(v_tl_246, 1, (V[]){v_b_2437}));
    switch (heff_tag_of(v_x3_2438)) {
    case TAG_MkPair: {
      V v_b_2439 = heff_field(v_x3_2438, 0);
      V v_x_2440 = heff_field(v_x3_2438, 1);
      V v_ru_24x3_2438_24MkPair = heff_take_reuse_n(v_x3_2438, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x3_2438_24MkPair, TAG_MkPair, 2, (V[]){v_b_2439, heff_tag_at_n(v_ru_24arm_2434_24MkArm, TAG_MkArm, 3, (V[]){v_t_2435, v_vs_2436, v_x_2440})});
    }
    default: return heff_nomatch(v_x3_2438);
    }
  }
  default: return heff_nomatch(v_arm_2434);
  }
}
Clo g_heff_2ecompile_2erefcount_2ereusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereusedOf_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2ereusedOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_SVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SInt: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SFloat: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SStr: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SBytes: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SFixed: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SFloat32: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrimFn: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        V v_argv_2418 = heff_field(v_x121_243, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_Nil: {
          V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2418));
          return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownTag, 1, (V[]){v_t_2420})});
        }
        case TAG_Cons: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_SRec: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ereusedOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2ereusedOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2eoperandsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsOf_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2eoperandsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_OSimple: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_SVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SFixed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_SFloat32: {
      heff_take_na(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SLam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_STag: {
      V v_argv_2415 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 3);
      return v_argv_2415;
    }
    case TAG_SRec: {
      V v_fs_2417 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24SRec = heff_take_reuse_n(v_x11_241, 1ULL, 2);
      return (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x11_241_24SRec, v_fs_2417));
    }
    case TAG_SProj: {
      V v_e_2419 = heff_field(v_x11_241, 0);
      V v_l_2420 = heff_field(v_x11_241, 1);
      V v_sh_2421 = heff_field(v_x11_241, 2);
      V v_t_2422 = heff_field(v_x11_241, 3);
      V v_ru_24x11_241_24SProj = heff_take_reuse_n(v_x11_241, 15ULL, 4);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24SProj, TAG_SProj, 4, (V[]){v_e_2419, v_l_2420, v_sh_2421, v_t_2422}), NTAG(TAG_Nil)});
    }
    case TAG_SPrim: {
      V v_argv_2424 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 2);
      return v_argv_2424;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  case TAG_OCall: {
    V v_argv_2426 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_argv_2426;
  }
  case TAG_OApply: {
    V v_f_2427 = heff_field(v_x1_240, 0);
    V v_argv_2428 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24OApply = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24OApply, TAG_Cons, 2, (V[]){v_f_2427, v_argv_2428});
  }
  case TAG_OPrim: {
    V v_argv_2430 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_argv_2430;
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsOf(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2eintW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eintW_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eintW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_IVal: {
      V v_x211_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_244)) {
      case TAG_SVar: {
        heff_take_n(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x211_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x211_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SLam: {
        V v_x2112_2416 = heff_field(v_x211_244, 1);
        heff_take_n(v_x211_244, 2ULL, 2);
        switch (heff_tag_of(v_x2112_2416)) {
        case TAG_MkBlock: {
          V v_t_2417 = heff_field(v_x2112_2416, 0);
          heff_take_n(v_x2112_2416, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2417}), v_rest_243});
          V t_0 = v_x_240;
          V t_1 = v_t_2418;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_x2112_2416);
        }
      }
      case TAG_STag: {
        V v_argv_2420 = heff_field(v_x211_244, 1);
        heff_take_n(v_x211_244, 2ULL, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2420));
        V v_t_2423 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2422));
        V t_0 = v_x_240;
        V t_1 = v_t_2423;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2424 = heff_field(v_x211_244, 0);
        heff_take_n(v_x211_244, 1ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2426 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2424));
        V v_t_2427 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2426));
        V t_0 = v_x_240;
        V t_1 = v_t_2427;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SProj: {
        V v_e_2428 = heff_field(v_x211_244, 0);
        heff_take_n(v_x211_244, 1ULL, 4);
        V v_t_2432 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_e_2428}), v_rest_243});
        V t_0 = v_x_240;
        V t_1 = v_t_2432;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_SPrim: {
        V v_p_2433 = heff_field(v_x211_244, 0);
        V v_argv_2434 = heff_field(v_x211_244, 1);
        heff_take_n(v_x211_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2435 = ({ V a_0 = v_p_2433; V b_1 = heff_dup(g_heff_2ecompile_2erefcount_2eintPrims_get()); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_p_2433); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
          heff_drop(v_t_2435);
          V v_t_2436 = (g_list_2eany_24s1678884672x1211895143(v_x_240, v_argv_2434));
          if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
            heff_drop(v_rest_243);
            heff_drop(v_argv_2434);
            heff_drop(v_t_2436);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2436);
            V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2434));
            V v_t_2438 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2437));
            V t_0 = v_x_240;
            V t_1 = v_t_2438;
            v_x_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop(v_t_2435);
          V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2434));
          V v_t_2440 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2439));
          V t_0 = v_x_240;
          V t_1 = v_t_2440;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      default: return heff_nomatch(v_x211_244);
      }
    }
    case TAG_IOp: {
      V v_x211_2441 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_2441)) {
      case TAG_OSimple: {
        V v_v_2442 = heff_field(v_x211_2441, 0);
        heff_take_n(v_x211_2441, 1ULL, 1);
        V v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2442}), v_rest_243});
        V t_0 = v_x_240;
        V t_1 = v_t_2443;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_OCall: {
        V v_argv_2445 = heff_field(v_x211_2441, 1);
        heff_take_n(v_x211_2441, 2ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2445));
        V v_t_2447 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2446));
        V t_0 = v_x_240;
        V t_1 = v_t_2447;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2448 = heff_field(v_x211_2441, 0);
        V v_argv_2449 = heff_field(v_x211_2441, 1);
        heff_take_n(v_x211_2441, 3ULL, 2);
        V v_t_2450 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_2448, v_argv_2449})));
        V v_t_2451 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2450));
        V t_0 = v_x_240;
        V t_1 = v_t_2451;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_OPrim: {
        V v_p_2452 = heff_field(v_x211_2441, 0);
        V v_argv_2453 = heff_field(v_x211_2441, 1);
        heff_take_n(v_x211_2441, 3ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2454 = ({ V a_0 = v_p_2452; V b_1 = heff_dup(g_heff_2ecompile_2erefcount_2eintPrims_get()); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_p_2452); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
          heff_drop(v_t_2454);
          V v_t_2455 = (g_list_2eany_24s1678884672x1211895143(v_x_240, v_argv_2453));
          if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
            heff_drop(v_rest_243);
            heff_drop(v_argv_2453);
            heff_drop(v_t_2455);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2455);
            V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2453));
            V v_t_2457 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2456));
            V t_0 = v_x_240;
            V t_1 = v_t_2457;
            v_x_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop(v_t_2454);
          V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2453));
          V v_t_2459 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_2458));
          V t_0 = v_x_240;
          V t_1 = v_t_2459;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2460 = heff_field(v_x211_2441, 0);
        heff_take_n(v_x211_2441, 1ULL, 1);
        V v_t_2461 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2460}), v_rest_243});
        V t_0 = v_x_240;
        V t_1 = v_t_2461;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x211_2441);
      }
    }
    case TAG_ICond: {
      V v_x211_2462 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ICond = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_2462)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x21_242_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x21_242_24ICond, 1);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PRel: {
        V v_p_2463 = heff_field(v_x211_2462, 0);
        V v_a_2464 = heff_field(v_x211_2462, 1);
        V v_b_2465 = heff_field(v_x211_2462, 2);
        heff_take_n(v_x211_2462, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ICond, 1);
        V v_t_2466 = ({ V a_0 = v_p_2463; V b_1 = heff_dup(g_heff_2ecompile_2erefcount_2eintPrims_get()); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_p_2463); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
          heff_drop(v_t_2466);
          V v_t_2467 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_2465), NTAG(TAG_Nil)});
          V v_t_2468 = ({ V a_0 = v_x_240; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2464), v_t_2467}); V r_ = (g_list_2eany_24s1678884672x1211895143(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
            heff_drop(v_rest_243);
            heff_drop(v_a_2464);
            heff_drop(v_b_2465);
            heff_drop(v_t_2468);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2468);
            V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2465}), v_rest_243});
            V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2464}), v_t_2469});
            V t_0 = v_x_240;
            V t_1 = v_t_2470;
            v_x_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop(v_t_2466);
          V v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2465}), v_rest_243});
          V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2464}), v_t_2471});
          V t_0 = v_x_240;
          V t_1 = v_t_2472;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_PBool: {
        V v_v_2473 = heff_field(v_x211_2462, 0);
        heff_take_n(v_x211_2462, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ICond, 1);
        V v_t_2474 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2473}), v_rest_243});
        V t_0 = v_x_240;
        V t_1 = v_t_2474;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2475 = heff_field(v_x211_2462, 0);
        heff_take_n(v_x211_2462, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ICond, 1);
        V v_t_2476 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2475}), v_rest_243});
        V t_0 = v_x_240;
        V t_1 = v_t_2476;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2477 = heff_field(v_x211_2462, 0);
        V v_b_2478 = heff_field(v_x211_2462, 1);
        V v_c_2479 = heff_field(v_x211_2462, 2);
        heff_take_n(v_x211_2462, 7ULL, 3);
        V v_t_2480 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2479}), v_rest_243});
        V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ICond, TAG_ICond, 1, (V[]){v_b_2478}), v_t_2480});
        V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2477}), v_t_2481});
        V t_0 = v_x_240;
        V t_1 = v_t_2482;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PLet: {
        V v_o_2484 = heff_field(v_x211_2462, 1);
        V v_c_2485 = heff_field(v_x211_2462, 2);
        heff_take_n(v_x211_2462, 6ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ICond, 1);
        V v_t_2486 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2485}), v_rest_243});
        V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2484}), v_t_2486});
        V t_0 = v_x_240;
        V t_1 = v_t_2487;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x211_2462);
      }
    }
    case TAG_ISts: {
      V v_x211_2488 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ISts = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_2488)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x21_242_24ISts, 1);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_Cons: {
        V v_x2111_2489 = heff_field(v_x211_2488, 0);
        V v_ss_2490 = heff_field(v_x211_2488, 1);
        V v_ru_24x211_2488_24Cons = heff_take_reuse_n(v_x211_2488, 3ULL, 2);
        switch (heff_tag_of(v_x2111_2489)) {
        case TAG_SLet: {
          V v_o_2492 = heff_field(v_x2111_2489, 1);
          heff_take_n(v_x2111_2489, 2ULL, 2);
          heff_drop_cell(v_ru_24x21_242_24ISts, 1);
          V v_t_2493 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2490}), v_rest_243});
          V v_t_2494 = heff_tag_at_n(v_ru_24x211_2488_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2492}), v_t_2493});
          V t_0 = v_x_240;
          V t_1 = v_t_2494;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SDecl: {
          heff_take_n(v_x2111_2489, 0ULL, 1);
          heff_drop_cell(v_ru_24x21_242_24ISts, 1);
          heff_drop_cell(v_ru_24x211_2488_24Cons, 2);
          V v_t_2496 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2490}), v_rest_243});
          V t_0 = v_x_240;
          V t_1 = v_t_2496;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SSet: {
          V v_o_2498 = heff_field(v_x2111_2489, 1);
          heff_take_n(v_x2111_2489, 2ULL, 2);
          heff_drop_cell(v_ru_24x21_242_24ISts, 1);
          V v_t_2499 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2490}), v_rest_243});
          V v_t_24100 = heff_tag_at_n(v_ru_24x211_2488_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2498}), v_t_2499});
          V t_0 = v_x_240;
          V t_1 = v_t_24100;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24101 = heff_field(v_x2111_2489, 0);
          V v_ts_24102 = heff_field(v_x2111_2489, 1);
          V v_fs_24103 = heff_field(v_x2111_2489, 2);
          heff_take_n(v_x2111_2489, 7ULL, 3);
          V v_t_24104 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2490}), v_rest_243});
          V v_t_24105 = heff_tag_at_n(v_ru_24x211_2488_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ISts, TAG_ISts, 1, (V[]){v_fs_24103}), v_t_24104});
          V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24102}), v_t_24105});
          V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24101}), v_t_24106});
          V t_0 = v_x_240;
          V t_1 = v_t_24107;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24108 = heff_field(v_x2111_2489, 0);
          V v_arms_24109 = heff_field(v_x2111_2489, 1);
          heff_take_n(v_x2111_2489, 3ULL, 2);
          heff_drop_cell(v_ru_24x21_242_24ISts, 1);
          V v_t_24110 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2490}), v_rest_243});
          V v_t_24111 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24109));
          V v_t_24112 = (g_list_2efoldl_24s1104809983x118204267(v_t_24110, v_t_24111));
          V v_t_24113 = heff_tag_at_n(v_ru_24x211_2488_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24108}), v_t_24112});
          V t_0 = v_x_240;
          V t_1 = v_t_24113;
          v_x_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_x2111_2489);
        }
      }
      default: return heff_nomatch(v_x211_2488);
      }
    }
    case TAG_ITl: {
      V v_x211_24114 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ITl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_24114)) {
      case TAG_TSeq: {
        V v_ss_24115 = heff_field(v_x211_24114, 0);
        V v_t_24116 = heff_field(v_x211_24114, 1);
        V v_ru_24x211_24114_24TSeq = heff_take_reuse_n(v_x211_24114, 3ULL, 2);
        heff_drop_cell(v_ru_24x21_242_24ITl, 1);
        V v_t_24117 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24116}), v_rest_243});
        V v_t_24118 = heff_tag_at_n(v_ru_24x211_24114_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24115}), v_t_24117});
        V t_0 = v_x_240;
        V t_1 = v_t_24118;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24119 = heff_field(v_x211_24114, 0);
        heff_take_n(v_x211_24114, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ITl, 1);
        V v_t_24120 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24119}), v_rest_243});
        V t_0 = v_x_240;
        V t_1 = v_t_24120;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24121 = heff_field(v_x211_24114, 0);
        heff_take_n(v_x211_24114, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x21_242_24ITl, 1);
        V v_t_24122 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24121));
        V v_t_24123 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_243, v_t_24122));
        V t_0 = v_x_240;
        V t_1 = v_t_24123;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24124 = heff_field(v_x211_24114, 0);
        V v_t_24125 = heff_field(v_x211_24114, 1);
        V v_e_24126 = heff_field(v_x211_24114, 2);
        heff_take_n(v_x211_24114, 7ULL, 3);
        V v_t_24127 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_e_24126}), v_rest_243});
        V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ITl, TAG_ITl, 1, (V[]){v_t_24125}), v_t_24127});
        V v_t_24129 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24124}), v_t_24128});
        V t_0 = v_x_240;
        V t_1 = v_t_24129;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24130 = heff_field(v_x211_24114, 0);
        V v_arms_24131 = heff_field(v_x211_24114, 1);
        heff_take_n(v_x211_24114, 3ULL, 2);
        heff_drop_cell(v_ru_24x21_242_24ITl, 1);
        V v_t_24132 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24131));
        V v_t_24133 = (g_list_2efoldl_24s421921225x565177679(v_rest_243, v_t_24132));
        V v_t_24134 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24130}), v_t_24133});
        V t_0 = v_x_240;
        V t_1 = v_t_24134;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x211_24114);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eintW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2eintW(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapperOf_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapperOf_str1, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapperOf_str2, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ewrapperOf_str3, 4, "box$");
V g_heff_2ecompile_2erefcount_2ewrapperOf_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ewrapperOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ewrapperOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewrapperOf_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2ewrapperOf(V v_ce_240, V v_key_241, V v_bi_242, V v_sg_243, V v_xs_244) {
top: ;
  V v_params_245 = heff_take_field(v_sg_243, 0);
  V v_result_246 = heff_get_n(v_sg_243, 1, 2);
  V v_t_2414 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2erefcount_2ewrapperOf_lam0, 2, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_params_245), heff_dup(v_xs_244)));
  V v_t_2415 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_params_245), heff_dup(v_xs_244)));
  V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_244));
  V v_t_2417 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2416, MK_INT(1LL))));
  V v_t_2427 = (g_list_2efoldl_24f1686830387x1555365313(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2erefcount_2ewrapperOf_lam1, 2, 1, (V[]){heff_dup(v_bi_242)}), v_t_2415, v_t_2417));
  V v_t_2428 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2427); r_; });
  V v_from_2429 = heff_dup(v_result_246);
  V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2ewrapArg_clo), 1, (V[]){v_ce_240}));
  V v_t_2431 = (g_list_2ezipWith(v_t_2430, v_params_245, v_xs_244));
  V v_v_2432 = heff_tag_n(TAG_RCall, 4, (V[]){v_key_241, NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){v_result_246}), v_t_2431});
  V v_t_2434;
  switch (heff_tag_of(v_from_2429)) {
  case TAG_RepV: {
    v_t_2434 = v_v_2432;
    break;
  }
  case TAG_RepFix: {
    v_t_2434 = heff_tag_n(TAG_RBox, 2, (V[]){v_from_2429, v_v_2432});
    break;
  }
  case TAG_RepF64: {
    v_t_2434 = heff_tag_n(TAG_RBox, 2, (V[]){v_from_2429, v_v_2432});
    break;
  }
  case TAG_RepInt: {
    v_t_2434 = heff_tag_n(TAG_RBox, 2, (V[]){v_from_2429, v_v_2432});
    break;
  }
  default: heff_nomatch(v_from_2429);
  }
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2434}), NTAG(TAG_Nil)});
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2435));
  return heff_tag_n(TAG_MkWrapper, 2, (V[]){v_t_2414, v_t_2436});
}
V g_heff_2ecompile_2erefcount_2ewrapperOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ewrapperOf(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ewrapperOf_lam0(V self, V *args) {
  V v_rp_247 = args[0];
  V v_x_248 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_rp_247)) {
  case TAG_RepV: {
    HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2411;
        heff_drop(v_x_2412);
        return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapperOf_str0), v_x_248);
      } else {
        heff_drop(v_field_2411);
        return v_x_248;
      }
    }
  }
  case TAG_RepFix: {
    heff_take_n(v_rp_247, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapperOf_str1), v_x_248);
  }
  case TAG_RepF64: {
    heff_drop_rec(v_ce_240, 17);
    return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapperOf_str2), v_x_248);
  }
  case TAG_RepInt: {
    heff_drop_rec(v_ce_240, 17);
    return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2ewrapperOf_str3), v_x_248);
  }
  default: return heff_nomatch(v_rp_247);
  }
}
V g_heff_2ecompile_2erefcount_2ewrapperOf_lam1(V self, V *args) {
  V v_p_2418 = args[0];
  V v_i_2419 = args[1];
  V v_bi_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = ({ V a_0 = v_i_2419; V a_1 = v_bi_242; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_bi_242); r_; });
  V v_t_2423;
  switch (heff_tag_of(v_p_2418)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_dup(heff_field(v_p_2418, 0));
    v_t_2423 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_p_2418);
  }
  V v_t_2426;
  switch (heff_tag_of(v_p_2418)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_p_2418, 1);
    heff_take_n(v_p_2418, 2ULL, 2);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_p_2418);
  }
  return ({ V a_0 = v_t_2420; V a_1 = v_t_2423; V a_2 = v_t_2426; V r_ = (g_heff_2ecompile_2erefcount_2ewrapUnbox(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
}
Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V v_ce_240, V v_live_241, V v_x4_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_x5_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rp_244 = heff_field(v_x4_242, 0);
    V v_rps_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x5_243)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_rp_244);
      heff_drop(v_rps_245);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_246 = heff_field(v_x5_243, 0);
      V v_es_247 = heff_field(v_x5_243, 1);
      V v_ru_24x5_243_24Cons = heff_take_reuse_n(v_x5_243, 3ULL, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_247)));
      V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_live_2410 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x5_243_24Cons, v_t_249, heff_dup(v_live_241)));
      V v_t_2411 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2410, v_rp_244, v_e_246));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(v_ce_240, v_live_241, v_rps_245, v_es_247, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_x5_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_str1, 1, ",");
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam4(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301(V v_ce_240, V v_live_241, V v_fs_242, V v_ts_243, V v_x_244, V v_changed_245) {
top: ;
  V v_ls_246 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
  V v_t_2412 = (g_heff_2ecompile_2erefcount_2ekeepBits_24f1436113831x213050700(heff_clo_n(g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam0, 1, 2, (V[]){v_ls_246, heff_dup(v_x_244)}), v_fs_242));
  V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_242));
  V v_t_2414 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2413, MK_INT(1LL))));
  V v_is_2417 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam1, 1, 1, (V[]){heff_dup(v_changed_245)}), v_t_2414));
  V v_t_2418 = ({ V a_0 = MK_INT(16LL); V a_1 = MK_INT(3LL); V a_2 = MK_INT(0LL); V a_3 = v_is_2417; V r_ = (g_list_2efoldl_24s1813831864x676242789(a_0, a_1, a_2, a_3)); heff_drop(v_is_2417); r_; });
  V v_ps_2428 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam2, 1, 1, (V[]){heff_dup(v_ts_243)}), heff_dup(v_changed_245)));
  V v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = MK_INT(2LL); V a_5 = MK_INT(0LL); V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(3LL); V a_9 = MK_INT(0LL); V a_10 = MK_INT(1LL); V a_11 = MK_INT(0LL); V a_12 = MK_INT(0LL); V a_13 = v_ps_2428; V r_ = (g_list_2efoldl_24s1982386833x551161312(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_ps_2428); r_; });
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_242));
  V v_t_2431 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
  V v_rps_2437 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam3, 1, 1, (V[]){heff_dup(v_ts_243)}), heff_dup(v_changed_245)));
  V v_vs_2438 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_changed_245)));
  V v_t_2439 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(heff_dup(v_ce_240), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), v_live_241}), heff_dup(v_rps_2437), v_vs_2438));
  V v_t_2440 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2437, v_t_2439));
  V v_t_2441 = (g_list_2ezipWith_24s1029292936x211450510(heff_dup(v_changed_245), v_t_2440));
  V v_t_2455 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam4, 1, 2, (V[]){v_fs_242, v_ce_240}); V a_1 = v_changed_245; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_changed_245); r_; });
  return heff_tag_n(TAG_RRecIn, 8, (V[]){v_x_244, v_t_2412, v_t_2418, v_t_2429, v_t_2430, v_t_2431, v_t_2441, v_t_2455});
}
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam0(V self, V *args) {
  V v_f_247 = args[0];
  V v_ls_246 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_248 = ({ V a_0 = v_ls_246; V a_1 = v_f_247; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(a_0, a_1)); heff_drop(v_ls_246); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_y_2411 = v_field_2410;
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_244, v_y_2411, 0));
      heff_drop(v_x_244);
      heff_drop(v_y_2411);
      return v_ret_24bool;
    } else {
      heff_drop(v_x_244);
      heff_drop(v_field_2410);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam1(V self, V *args) {
  V v_i_2415 = args[0];
  V v_changed_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = ({ V a_0 = v_i_2415; V a_1 = v_changed_245; V r_ = (g_list_2eany_24s1687778528x1571134043(a_0, a_1)); heff_drop(v_changed_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2416) == NTAG(TAG_True)));
  heff_drop(v_x1_2416);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam2(V self, V *args) {
  V v_p_2419 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422;
  switch (heff_tag_of(v_p_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_dup(heff_field(v_p_2419, 0));
    v_t_2422 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_p_2419);
  }
  V v_i_2425;
  switch (heff_tag_of(v_p_2419)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_p_2419, 0);
    heff_take_n(v_p_2419, 1ULL, 2);
    v_i_2425 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_p_2419);
  }
  V v_t_2426 = ({ V a_0 = heff_dup(v_i_2425); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erefcount_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  V v_t_2427 = (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2425, v_t_2426));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_t_2427});
}
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam3(V self, V *args) {
  V v_p_2432 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_i_2435;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_p_2432, 0);
    heff_take_n(v_p_2432, 1ULL, 2);
    v_i_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_t_2436 = ({ V a_0 = heff_dup(v_i_2435); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erefcount_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2435, v_t_2436));
}
V g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_lam4(V self, V *args) {
  V v_p_2442 = args[0];
  V v_fs_242 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_sh_2443 = (g_list_2emap_24s1937570095x2110149801(v_fs_242));
  V v_t_2446;
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_x_2444 = heff_field(v_p_2442, 0);
    heff_take_n(v_p_2442, 1ULL, 2);
    v_t_2446 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_p_2442);
  }
  V v_t_2449;
  switch (heff_tag_of(v_sh_2443)) {
  case TAG_Nil: {
    v_t_2449 = ((V)&g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2447 = heff_field(v_sh_2443, 0);
    V v_xs_2448 = heff_field(v_sh_2443, 1);
    heff_take_n(v_sh_2443, 3ULL, 2);
    v_t_2449 = ({ V a_0 = ((V)&g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301_str1); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
    break;
  }
  default: heff_nomatch(v_sh_2443);
  }
  HeffT2 v_t_2450 = ({ V b_0 = heff_get_n(v_ce_240, 14, 17); V a_1 = v_t_2449; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2449); r_; });
  V v_t_2454;
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      V v_x_2453 = v_field_2452;
      v_t_2454 = v_x_2453;
    } else {
      heff_drop(v_field_2452);
      v_t_2454 = NTAG(TAG_Nil);
    }
  }
  return ({ V a_0 = v_t_2446; V a_1 = v_t_2454; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_t_2454); r_; });
}
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(V v_ce_240, V v_live_241, V v_fs_242, V v_ts_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_242));
    V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(1LL))));
    V v_ps_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_lam0, 1, 1, (V[]){heff_dup(v_ts_243)}), v_t_247));
    V v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = MK_INT(2LL); V a_5 = MK_INT(0LL); V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(3LL); V a_9 = MK_INT(0LL); V a_10 = MK_INT(1LL); V a_11 = MK_INT(0LL); V a_12 = MK_INT(0LL); V a_13 = v_ps_2411; V r_ = (g_list_2efoldl_24s1982386833x551161312(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_ps_2411); r_; });
    V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_242));
    V v_t_2414 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2413, MK_INT(1LL))));
    V v_rps_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_lam1, 1, 1, (V[]){heff_dup(v_ts_243)}), v_t_2414));
    V v_vs_2418 = (g_list_2emap_24s1173914895x100384474(v_fs_242));
    V v_t_2419 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, heff_dup(v_rps_2417), v_vs_2418));
    V v_t_2420 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2417, v_t_2419));
    return heff_tag_n(TAG_RRec, 3, (V[]){v_t_245, v_t_2412, v_t_2420});
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x6_244, 0);
    V v_t_2422 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
    V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_x_2421; V a_2 = heff_dup(v_fs_242); V r_ = (g_heff_2ecompile_2erefcount_2echangedOf(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    return (g_heff_2ecompile_2erefcount_2eupdateVal_24s589331116x1422372301(v_ce_240, v_live_241, v_fs_242, v_ts_243, heff_dup(v_x_2421), v_t_2423));
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_lam0(V self, V *args) {
  V v_i_248 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = ({ V a_0 = heff_dup(v_i_248); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erefcount_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  V v_t_2410 = (g_heff_2ecompile_2erepr_2eslotRepr(heff_dup(v_i_248), v_t_249));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_i_248, v_t_2410});
}
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_lam1(V self, V *args) {
  V v_i_2415 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = ({ V a_0 = heff_dup(v_i_2415); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erefcount_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2415, v_t_2416));
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str8, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str9, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str10, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str11, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str12, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str13, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str14, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str15, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str16, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str17, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str18, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str19, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str20, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str21, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str22, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str23, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str24, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str25, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str26, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str27, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str29, 1, ",");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str30, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str31, 14, "arrayReplicate");
Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V v_ce_240, V v_live_241, V v_want_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_v_243)) {
  case TAG_SVar: {
    V v_t_245 = (g_heff_2ecompile_2erefcount_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_246 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_245, v_want_242, v_t_246));
  }
  case TAG_SGlobal: {
    V v_t_248 = (g_heff_2ecompile_2erefcount_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_249 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_248, v_want_242, v_t_249));
  }
  case TAG_SInt: {
    V v_n_2410 = heff_field(v_v_243, 0);
    V v_ru_24v_243_24SInt = heff_take_reuse_n(v_v_243, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    V v_t_2412;
    switch (heff_tag_of(v_want_242)) {
    case TAG_RepV: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_RepFix: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_want_242);
    }
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_want_242);
      heff_drop_cell(v_ru_24v_243_24SInt, 1);
      heff_drop(v_t_2412);
      return heff_tag_n(TAG_RFixU, 2, (V[]){NTAG(TAG_I64), v_n_2410});
    } else {
      heff_drop(v_t_2412);
      V v_t_2414;
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2414 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_want_242);
        heff_drop(v_t_2414);
        return heff_tag_at_n(v_ru_24v_243_24SInt, TAG_RInt, 1, (V[]){v_n_2410});
      } else {
        heff_drop(v_t_2414);
        switch (heff_tag_of(v_want_242)) {
        case TAG_RepV: {
          return heff_tag_n(TAG_RBox, 2, (V[]){NTAG(TAG_RepV), heff_tag_at_n(v_ru_24v_243_24SInt, TAG_RInt, 1, (V[]){v_n_2410})});
        }
        case TAG_RepFix: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_n(v_ru_24v_243_24SInt, TAG_RInt, 1, (V[]){v_n_2410})));
        }
        case TAG_RepF64: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_n(v_ru_24v_243_24SInt, TAG_RInt, 1, (V[]){v_n_2410})));
        }
        case TAG_RepInt: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_n(v_ru_24v_243_24SInt, TAG_RInt, 1, (V[]){v_n_2410})));
        }
        default: return heff_nomatch(v_want_242);
        }
      }
    }
  }
  case TAG_SFloat: {
    double v_x_2416 = heff_tflat_f64(v_v_243, 0);
    V v_ru_24v_243_24SFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    V v_t_2418;
    switch (heff_tag_of(v_want_242)) {
    case TAG_RepV: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_RepFix: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_RepInt: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_want_242);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_want_242);
      heff_drop(v_t_2418);
      return heff_tag_at_nf(v_ru_24v_243_24SFloat, TAG_RF64U, 1, 1u, (V[]){heff_word_f64(v_x_2416)});
    } else {
      heff_drop(v_t_2418);
      V v_t_2420;
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2420 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2420 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_want_242);
        heff_drop(v_t_2420);
        return heff_tag_at_nf(v_ru_24v_243_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2416)});
      } else {
        heff_drop(v_t_2420);
        switch (heff_tag_of(v_want_242)) {
        case TAG_RepV: {
          return heff_tag_n(TAG_RBox, 2, (V[]){NTAG(TAG_RepV), heff_tag_at_nf(v_ru_24v_243_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2416)})});
        }
        case TAG_RepFix: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_nf(v_ru_24v_243_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2416)})));
        }
        case TAG_RepF64: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_nf(v_ru_24v_243_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2416)})));
        }
        case TAG_RepInt: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_nf(v_ru_24v_243_24SFloat, TAG_RFloat, 1, 1u, (V[]){heff_word_f64(v_x_2416)})));
        }
        default: return heff_nomatch(v_want_242);
        }
      }
    }
  }
  case TAG_SStr: {
    V v_s_2422 = heff_field(v_v_243, 0);
    V v_ru_24v_243_24SStr = heff_take_reuse_n(v_v_243, 1ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return (g_heff_2ecompile_2erefcount_2estrAs_24tok1(v_ru_24v_243_24SStr, v_want_242, v_s_2422));
  }
  case TAG_SBytes: {
    V v_t_2424 = (g_heff_2ecompile_2erefcount_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2425 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2424, v_want_242, v_t_2425));
  }
  case TAG_SFixed: {
    V v_w_2426 = heff_field(v_v_243, 0);
    V v_n_2427 = heff_field(v_v_243, 1);
    V v_ru_24v_243_24SFixed = heff_take_reuse_n(v_v_243, 3ULL, 2);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    switch (heff_tag_of(v_want_242)) {
    case TAG_RepV: {
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixed, 2, (V[]){v_w_2426, v_n_2427})));
    }
    case TAG_RepFix: {
      V v_b_2428 = heff_dup(heff_field(v_want_242, 0));
      V v_t_2429;
      switch (heff_tag_of(v_w_2426)) {
      case TAG_I8: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str0);
        break;
      }
      case TAG_I16: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str1);
        break;
      }
      case TAG_I32: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str2);
        break;
      }
      case TAG_I64: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str3);
        break;
      }
      case TAG_U8: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str4);
        break;
      }
      case TAG_U16: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str5);
        break;
      }
      case TAG_U32: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str6);
        break;
      }
      case TAG_U64: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str7);
        break;
      }
      case TAG_F32: {
        v_t_2429 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str8);
        break;
      }
      default: heff_nomatch(v_w_2426);
      }
      V v_t_2430;
      switch (heff_tag_of(v_b_2428)) {
      case TAG_I8: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str9);
        break;
      }
      case TAG_I16: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str10);
        break;
      }
      case TAG_I32: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str11);
        break;
      }
      case TAG_I64: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str12);
        break;
      }
      case TAG_U8: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str13);
        break;
      }
      case TAG_U16: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str14);
        break;
      }
      case TAG_U32: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str15);
        break;
      }
      case TAG_U64: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str16);
        break;
      }
      case TAG_F32: {
        v_t_2430 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str17);
        break;
      }
      default: heff_nomatch(v_b_2428);
      }
      if (heff_strEq_c(v_t_2429, v_t_2430)) {
        heff_drop_tag(v_want_242, 1);
        return heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixU, 2, (V[]){v_w_2426, v_n_2427});
      } else {
        return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixed, 2, (V[]){v_w_2426, v_n_2427})));
      }
    }
    case TAG_RepF64: {
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixed, 2, (V[]){v_w_2426, v_n_2427})));
    }
    case TAG_RepInt: {
      return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixed, 2, (V[]){v_w_2426, v_n_2427})));
    }
    default: return heff_nomatch(v_want_242);
    }
  }
  case TAG_SFloat32: {
    double v_x_2431 = heff_tflat_f64(v_v_243, 0);
    V v_ru_24v_243_24SFloat32 = heff_take_reuse_na(v_v_243, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    V v_t_2434;
    switch (heff_tag_of(v_want_242)) {
    case TAG_RepV: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_RepFix: {
      V v_b_2432 = heff_dup(heff_field(v_want_242, 0));
      V v_t_2433;
      switch (heff_tag_of(v_b_2432)) {
      case TAG_I8: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str18);
        break;
      }
      case TAG_I16: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str19);
        break;
      }
      case TAG_I32: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str20);
        break;
      }
      case TAG_I64: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str21);
        break;
      }
      case TAG_U8: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str22);
        break;
      }
      case TAG_U16: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str23);
        break;
      }
      case TAG_U32: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str24);
        break;
      }
      case TAG_U64: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str25);
        break;
      }
      case TAG_F32: {
        v_t_2433 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str26);
        break;
      }
      default: heff_nomatch(v_b_2432);
      }
      v_t_2434 = heff_bool(heff_strEq_c_lent(((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str27), v_t_2433, 1));
      heff_drop(v_t_2433);
      break;
    }
    case TAG_RepF64: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_RepInt: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_want_242);
    }
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_want_242);
      heff_drop(v_t_2434);
      return heff_tag_at_nf(v_ru_24v_243_24SFloat32, TAG_RF32U, 1, 1u, (V[]){heff_word_f64(v_x_2431)});
    } else {
      heff_drop(v_t_2434);
      V v_t_2436;
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2436 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop(v_want_242);
        heff_drop(v_t_2436);
        return heff_tag_at_nf(v_ru_24v_243_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2431)});
      } else {
        heff_drop(v_t_2436);
        switch (heff_tag_of(v_want_242)) {
        case TAG_RepV: {
          return heff_tag_n(TAG_RBox, 2, (V[]){NTAG(TAG_RepV), heff_tag_at_nf(v_ru_24v_243_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2431)})});
        }
        case TAG_RepFix: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_nf(v_ru_24v_243_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2431)})));
        }
        case TAG_RepF64: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_nf(v_ru_24v_243_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2431)})));
        }
        case TAG_RepInt: {
          return (g_heff_2ecompile_2erefcount_2eunboxOf(v_want_242, heff_tag_at_nf(v_ru_24v_243_24SFloat32, TAG_RF32, 1, 1u, (V[]){heff_word_f64(v_x_2431)})));
        }
        default: return heff_nomatch(v_want_242);
        }
      }
    }
  }
  case TAG_SPrimFn: {
    V v_t_2439 = (g_heff_2ecompile_2erefcount_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2440 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2439, v_want_242, v_t_2440));
  }
  case TAG_SLam: {
    V v_t_2443 = (g_heff_2ecompile_2erefcount_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2444 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2443, v_want_242, v_t_2444));
  }
  case TAG_STag: {
    V v_t_2448 = (g_heff_2ecompile_2erefcount_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2449 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2448, v_want_242, v_t_2449));
  }
  case TAG_SRec: {
    V v_t_2452 = (g_heff_2ecompile_2erefcount_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2453 = (g_heff_2ecompile_2erefcount_2evalF_24s933178503x985841218(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erefcount_2ecoerce(v_t_2452, v_want_242, v_t_2453));
  }
  case TAG_SProj: {
    V v_e_2454 = heff_field(v_v_243, 0);
    V v_l_2455 = heff_field(v_v_243, 1);
    V v_sh_2456 = heff_field(v_v_243, 2);
    V v_t_2457 = heff_field(v_v_243, 3);
    V v_ru_24v_243_24SProj = heff_take_reuse_n(v_v_243, 15ULL, 4);
    HeffT2 v_t_2458 = (g_heff_2ecompile_2erefcount_2eindexIn_24cpr(v_l_2455, MK_INT(0LL), heff_dup(v_sh_2456)));
    V v_t_2470;
    {
      V v_field_2460 = v_t_2458.f[1];
      int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
      if ((v_tag_2459 == ((int64_t)0ULL))) {
        V v_i_2461 = v_field_2460;
        V v_t_2464;
        switch (heff_tag_of(v_sh_2456)) {
        case TAG_Nil: {
          v_t_2464 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str28);
          break;
        }
        case TAG_Cons: {
          V v_x_2462 = heff_dup(heff_field(v_sh_2456, 0));
          V v_xs_2463 = heff_dup(heff_field(v_sh_2456, 1));
          v_t_2464 = ({ V a_0 = ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str29); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
          break;
        }
        default: heff_nomatch(v_sh_2456);
        }
        HeffT2 v_t_2465 = ({ V a_0 = heff_rfield(v_ce_240, 14); V a_1 = v_t_2464; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2464); r_; });
        V v_t_2469;
        {
          V v_field_2467 = v_t_2465.f[1];
          int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
          if ((v_tag_2466 == ((int64_t)0ULL))) {
            V v_x_2468 = v_field_2467;
            v_t_2469 = v_x_2468;
          } else {
            heff_drop(v_field_2467);
            v_t_2469 = NTAG(TAG_Nil);
          }
        }
        v_t_2470 = ({ V a_0 = v_i_2461; V a_1 = v_t_2469; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_t_2469); r_; });
      } else {
        heff_drop(v_field_2460);
        v_t_2470 = NTAG(TAG_False);
      }
    }
    V v_t_2471 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2456));
    V v_t_2472 = (g_heff_2ecompile_2erefcount_2eindexIn(v_l_2455, MK_INT(0LL), heff_dup(v_sh_2456)));
    V v_t_2473 = (g_heff_2ecompile_2erefcount_2eindexIn(v_l_2455, MK_INT(0LL), heff_dup(v_sh_2456)));
    V v_t_2474 = (g_heff_2ecompile_2erepr_2ereadRepr(v_t_2473, heff_dup(v_t_2457)));
    return (g_heff_2ecompile_2erefcount_2eprojAs_24s1380839775x295272082(v_ce_240, v_live_241, v_want_242, heff_tag_at_n(v_ru_24v_243_24SProj, TAG_SProj, 4, (V[]){heff_dup(v_e_2454), v_l_2455, v_sh_2456, v_t_2457}), v_e_2454, v_t_2470, v_t_2471, v_t_2472, v_t_2474));
  }
  case TAG_SPrim: {
    V v_p_2475 = heff_field(v_v_243, 0);
    V v_argv_2476 = heff_field(v_v_243, 1);
    V v_ru_24v_243_24SPrim = heff_take_reuse_n(v_v_243, 3ULL, 2);
    HeffT2 v_t_2477 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_2475));
    {
      V v_field_2479 = v_t_2477.f[1];
      int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
      if ((v_tag_2478 == ((int64_t)0ULL))) {
        V v_sh_2480 = v_field_2479;
        V v_result_2481 = heff_take_field(v_sh_2480, 1);
        V v_args_2482 = heff_get_n(v_sh_2480, 0, 2);
        V v_t_2483 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, v_args_2482, v_argv_2476));
        return (g_heff_2ecompile_2erefcount_2ecoerce(v_result_2481, v_want_242, heff_tag_at_n(v_ru_24v_243_24SPrim, TAG_RPrimU, 2, (V[]){v_p_2475, v_t_2483})));
      } else {
        heff_drop(v_field_2479);
        V v_t_2484;
        if (heff_strEq_c_lent(v_p_2475, ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str30), 2)) {
          v_t_2484 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(2LL)});
        } else {
          if (heff_strEq_c_lent(v_p_2475, ((V)&g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_str31), 2)) {
            v_t_2484 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(1LL)});
          } else {
            v_t_2484 = NTAG(TAG_Nothing);
          }
        }
        V v_t_2485 = (g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_24tok2(v_ru_24v_243_24SPrim, v_ce_240, v_live_241, v_p_2475, v_argv_2476, v_t_2484));
        return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2485));
      }
    }
  }
  default: return heff_nomatch(v_v_243);
  }
}
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2efunWith_str0, 4, "box$");
V g_heff_2ecompile_2erefcount_2efunWith_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2efunWith_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2efunWith_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2efunWith_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2efunWith_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2efunWith_lam5(V self, V *args);
V g_heff_2ecompile_2erefcount_2efunWith_lam6(V self, V *args);
V g_heff_2ecompile_2erefcount_2efunWith_lam7(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2efunWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efunWith_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2efunWith(V v_ce_240, V v_key_241, V v_xs_242, V v_b_243, V v_bi_244, V v_rps_245, V v_sg_246) {
top: ;
  V v_t_2414 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam0, 2, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_rps_245), heff_dup(v_xs_242)));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2eunboxParams(heff_dup(v_ce_240), v_bi_244, v_rps_245, heff_dup(v_xs_242)));
  V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2417 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2416, MK_INT(1LL))));
  V v_t_2418 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2417));
  V v_t_2424 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam1, 1, 1, (V[]){heff_dup(v_bi_244)}), v_t_2418));
  V v_owned_2425 = (g_list_2emap_24s1937570095x2110149801(v_t_2424));
  V v_wanted_2426 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_b_243)));
  V v_xs_2429 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam2, 1, 1, (V[]){v_wanted_2426}), v_owned_2425));
  V v_xs_2435 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam3, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2429));
  V v_t_2436 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2435));
  V v_t_2437 = (g_list_2emap_24s1796125103x644876049(v_t_2436));
  V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2439 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2438, MK_INT(1LL))));
  V v_t_2440 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2439));
  V v_t_2446 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam4, 1, 1, (V[]){heff_dup(v_bi_244)}), v_t_2440));
  V v_owned_2447 = (g_list_2emap_24s1937570095x2110149801(v_t_2446));
  V v_wanted_2448 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_b_243)));
  V v_xs_2450 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam5, 1, 1, (V[]){v_wanted_2448}), v_owned_2447));
  V v_t_2456 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam6, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2450));
  V v_t_2457 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2458 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2457, MK_INT(1LL))));
  V v_t_2459 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2458));
  V v_t_2464 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2efunWith_lam7, 1, 1, (V[]){heff_dup(v_bi_244)}), v_t_2459));
  V v_t_2465 = (g_list_2emap_24s1937570095x2110149801(v_t_2464));
  V v_t_2466 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__params, (V[]){heff_dup(v_key_241), heff_dup(v_xs_242)})});
  V v_t_2467 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_b_243, NTAG(TAG_Nil)));
  V v_t_2468 = (g_list_2efoldl_24s976906006x1321876394(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2467));
  V v_t_2469 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_2468; V r_ = (g_list_2efoldl_24s1548442597x958354846(a_0, a_1)); heff_drop(v_t_2468); r_; });
  V v_t_2470 = (g_heff_2ecompile_2erefcount_2ewithFrame(v_t_2466, MK_INT(0LL), v_t_2469));
  V v_t_2471 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2465, v_t_2470));
  V v_ce_2472 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2456, NTAG(TAG_Nil), v_t_2471));
  V v_t_2473 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2472, v_b_243));
  V v_t_2474 = (g_prelude_2e_2b_2b(v_t_2437, v_t_2473));
  V v_t_2475 = (g_heff_2ecompile_2erefcount_2ethreaded(heff_dup(v_xs_242), v_t_2474));
  HeffT2 v_t_2476 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_key_241));
  V v_t_2480;
  {
    V v_field_2478 = v_t_2476.f[1];
    int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
    if ((v_tag_2477 == ((int64_t)0ULL))) {
      V v_s_2479 = v_field_2478;
      v_t_2480 = heff_get_n(v_s_2479, 1, 2);
    } else {
      heff_drop(v_field_2478);
      v_t_2480 = NTAG(TAG_RepV);
    }
  }
  V v_t_2483;
  switch (heff_tag_of(v_sg_246)) {
  case TAG_Nothing: {
    heff_drop(v_xs_242);
    v_t_2483 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x_2481 = heff_field(v_sg_246, 0);
    V v_ru_24sg_246_24Just = heff_take_reuse_n(v_sg_246, 1ULL, 1);
    V v_t_2482 = (g_heff_2ecompile_2erefcount_2ewrapperOf(heff_dup(v_ce_240), heff_dup(v_key_241), v_bi_244, v_x_2481, v_xs_242));
    v_t_2483 = heff_tag_at_n(v_ru_24sg_246_24Just, TAG_Just, 1, (V[]){v_t_2482});
    break;
  }
  default: heff_nomatch(v_sg_246);
  }
  V v_t_2484 = heff_rec_n(8, shape_key__params__lent__entry__body__reprs__ret__wrapper, (V[]){v_key_241, v_t_2414, v_bi_244, v_t_2415, v_t_2475, heff_get_n(v_ce_240, 10, 17), v_t_2480, v_t_2483});
  return heff_tag_n(TAG_DFun, 1, (V[]){v_t_2484});
}
V g_heff_2ecompile_2erefcount_2efunWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efunWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erefcount_2efunWith_lam0(V self, V *args) {
  V v_rp_247 = args[0];
  V v_x_248 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_rp_247)) {
  case TAG_RepV: {
    HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2411;
        heff_drop(v_x_2412);
        return heff_strAppend(((V)&g_heff_2ecompile_2erefcount_2efunWith_str0), v_x_248);
      } else {
        heff_drop(v_field_2411);
        return v_x_248;
      }
    }
  }
  case TAG_RepFix: {
    heff_take_n(v_rp_247, 0ULL, 1);
    heff_drop_rec(v_ce_240, 17);
    return v_x_248;
  }
  case TAG_RepF64: {
    heff_drop_rec(v_ce_240, 17);
    return v_x_248;
  }
  case TAG_RepInt: {
    heff_drop_rec(v_ce_240, 17);
    return v_x_248;
  }
  default: return heff_nomatch(v_rp_247);
  }
}
V g_heff_2ecompile_2erefcount_2efunWith_lam1(V self, V *args) {
  V v_p_2419 = args[0];
  V v_bi_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422;
  switch (heff_tag_of(v_p_2419)) {
  case TAG_MkPair: {
    V v_y_2421 = heff_field(v_p_2419, 1);
    heff_take_n(v_p_2419, 2ULL, 2);
    v_t_2422 = v_y_2421;
    break;
  }
  default: heff_nomatch(v_p_2419);
  }
  V v_x1_2423 = ({ V a_0 = v_t_2422; V a_1 = v_bi_244; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_bi_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2423) == NTAG(TAG_True)));
  heff_drop(v_x1_2423);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2efunWith_lam2(V self, V *args) {
  V v_v_2427 = args[0];
  V v_wanted_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2428 = ({ V a_0 = v_v_2427; V a_1 = v_wanted_2426; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2427); heff_drop(v_wanted_2426); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
  heff_drop(v_x1_2428);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2efunWith_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2431 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2430; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2430); r_; });
  {
    V v_field_2433 = v_t_2431.f[1];
    int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2432 == ((int64_t)0ULL)) ? ({ V v_x_2434 = heff_dup(v_field_2433); int c_ = 0; heff_drop(v_x_2434); c_; }) : 1));
    heff_drop(v_field_2433);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2erefcount_2efunWith_lam4(V self, V *args) {
  V v_p_2441 = args[0];
  V v_bi_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444;
  switch (heff_tag_of(v_p_2441)) {
  case TAG_MkPair: {
    V v_y_2443 = heff_field(v_p_2441, 1);
    heff_take_n(v_p_2441, 2ULL, 2);
    v_t_2444 = v_y_2443;
    break;
  }
  default: heff_nomatch(v_p_2441);
  }
  V v_x1_2445 = ({ V a_0 = v_t_2444; V a_1 = v_bi_244; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_bi_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2445) == NTAG(TAG_True)));
  heff_drop(v_x1_2445);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2efunWith_lam5(V self, V *args) {
  V v_v_2449 = args[0];
  V v_wanted_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2449; V a_1 = v_wanted_2448; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2449); heff_drop(v_wanted_2448); r_; });
}
V g_heff_2ecompile_2erefcount_2efunWith_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2452 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2451; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2451); r_; });
  {
    V v_field_2454 = v_t_2452.f[1];
    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2453 == ((int64_t)0ULL)) ? ({ V v_x_2455 = heff_dup(v_field_2454); int c_ = 0; heff_drop(v_x_2455); c_; }) : 1));
    heff_drop(v_field_2454);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2erefcount_2efunWith_lam7(V self, V *args) {
  V v_p_2460 = args[0];
  V v_bi_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463;
  switch (heff_tag_of(v_p_2460)) {
  case TAG_MkPair: {
    V v_y_2462 = heff_field(v_p_2460, 1);
    heff_take_n(v_p_2460, 2ULL, 2);
    v_t_2463 = v_y_2462;
    break;
  }
  default: heff_nomatch(v_p_2460);
  }
  return ({ V a_0 = v_t_2463; V a_1 = v_bi_244; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_bi_244); r_; });
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2efunRc_str0, 0, "");
Clo g_heff_2ecompile_2erefcount_2efunRc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efunRc_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2efunRc(V v_ce_240, V v_key_241, V v_xs_242, V v_b_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 15)), 1, 2);
  HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_key_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_n_248 = v_field_247;
      switch (heff_tag_of(v_xs_242)) {
      case TAG_Nil: {
        heff_drop(v_n_248);
        HEFF_LAST return g_heff_2ecompile_2erefcount_2efunPlain(v_ce_240, v_key_241, NTAG(TAG_Nil), v_b_243);
      }
      case TAG_Cons: {
        V v_tok_249 = heff_field(v_xs_242, 0);
        V v_xs_2410 = heff_field(v_xs_242, 1);
        V v_ru_24xs_242_24Cons = heff_take_reuse_n(v_xs_242, 3ULL, 2);
        V v_t_2411 = (g_heff_2ecompile_2erefcount_2ewithKnown(heff_dup(v_tok_249), heff_tag_n(TAG_KnownCell, 1, (V[]){heff_dup(v_n_248)}), v_ce_240));
        HeffT2 v_t_2412 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_tok_249), heff_rec_n(2, shape_n__tag, (V[]){v_n_248, ((V)&g_heff_2ecompile_2erefcount_2efunRc_str0)}), v_b_243));
        V v_t_2417;
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          heff_drop(v_x_2415);
          V v_y_2416 = v_field_2414;
          v_t_2417 = v_y_2416;
        }
        HEFF_LAST return g_heff_2ecompile_2erefcount_2efunPlain(v_t_2411, v_key_241, heff_tag_at_n(v_ru_24xs_242_24Cons, TAG_Cons, 2, (V[]){v_tok_249, v_xs_2410}), v_t_2417);
      }
      default: return heff_nomatch(v_xs_242);
      }
    } else {
      heff_drop(v_field_247);
      HEFF_LAST return g_heff_2ecompile_2erefcount_2efunPlain(v_ce_240, v_key_241, v_xs_242, v_b_243);
    }
  }
}
V g_heff_2ecompile_2erefcount_2efunRc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efunRc(a[0], a[1], a[2], a[3]);
}