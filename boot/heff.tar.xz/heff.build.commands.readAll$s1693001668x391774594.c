// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_cwd 308458
#define LBL_implicit 319715269
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_named 305943379
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594(V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0(V v_path_240, V v_hd_241, V v_k_242, V v_before_243, V v_rest_244, V v_x_245) {
top: ;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_ru_24x_245_24Left = heff_take_reuse_n(v_x_245, 0ULL, 1);
    heff_drop(v_before_243);
    heff_drop(v_rest_244);
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str0), v_path_240), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str1));
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_247, NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_at_n(v_ru_24x_245_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_245, 0);
    V v_ru_24x_245_24Right = heff_take_reuse_n(v_x_245, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_245_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam2_clo)})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s535099379x685970669(v_t_2429, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam3, 1, 6, (V[]){v_hd_241, v_path_240, v_before_243, v_rest_244, v_y_2422, v_k_242})));
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_drop(v_x_2421);
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam1, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  return v_s_2423;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam6(V self, V *args) {
  V v_i_2447 = args[0];
  V v_before_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2447; V a_1 = v_before_243; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_i_2447); heff_drop(v_before_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_2431 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_lib_2433 = heff_env(self)[2];
  V v_mod_2434 = heff_env(self)[3];
  V v_cwd_2435 = heff_env(self)[4];
  V v_style_2436 = heff_env(self)[5];
  V v_before_243 = heff_env(self)[6];
  V v_y_2422 = heff_env(self)[7];
  V v_k_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_m_2440 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str12), v_st_2431}), heff_dup(v_path_240)));
  V v_ps_2441 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str14), v_lib_2433, v_mod_2434, v_cwd_2435, v_style_2436});
  HeffT2 v_t_2442 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_2441), heff_get_n(v_ps_2441, 2, 6), heff_dup(v_path_240)));
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    V v_library_2446 = heff_bool(((v_tag_2443 == ((int64_t)0ULL)) && ({ V v_x_2445 = heff_dup(v_field_2444); int c_ = 1; heff_drop(v_x_2445); c_; })));
    heff_drop(v_field_2444);
    V v_t_2448 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam6, 1, 1, (V[]){v_before_243}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
    V v_t_2449 = heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_2440), v_m_2440, heff_dup(v_path_240), v_path_240, v_y_2422, NTAG(TAG_Nil), v_t_2448, v_library_2446});
    V v_x_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_x_2439});
    V f_ = v_k_242;
    args[0] = v_x_2450;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_st_2431 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_rest_244 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_y_2422 = heff_env(self)[5];
  V v_k_242 = heff_env(self)[6];
  V v_lib_2433 = heff_take_field(v_x_2432, 0);
  V v_mod_2434 = heff_take_field(v_x_2432, 1);
  V v_cwd_2435 = heff_take_field(v_x_2432, 2);
  V v_style_2436 = heff_get_n(v_x_2432, 3, 5);
  V v_t_2437 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str7), heff_dup(v_st_2431)}), heff_dup(v_path_240)));
  heff_clo_take(self, 7);
  V v_t_2438 = (g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_dup(v_before_243)}), v_rest_244));
  V f_ = v_t_2438;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam5, 1, 9, (V[]){v_st_2431, v_path_240, v_lib_2433, v_mod_2434, v_cwd_2435, v_style_2436, v_before_243, v_y_2422, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_rest_244 = heff_env(self)[3];
  V v_y_2422 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  V v_st_2431;
  if (heff_strEq_c(v_x_2430, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_str2))) {
    v_st_2431 = NTAG(TAG_Windows);
  } else {
    v_st_2431 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_lam4, 1, 7, (V[]){v_st_2431, v_path_240, v_before_243, v_rest_244, v_hd_241, v_y_2422, v_k_242})));
}