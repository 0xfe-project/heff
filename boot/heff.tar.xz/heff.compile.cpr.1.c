// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BadShape 33347
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_NoShape 40346
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_RecordShape 6130
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_TagShape 40544
#define TAG_Tip 31527
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_cons 9554936
#define LBL_group 299987609
#define LBL_index 301704428
#define LBL_kinds 303412089
#define LBL_labels 836724522
#define LBL_lets 9813631
#define LBL_numbered 1006183371
#define LBL_places 961367927
#define LBL_record 1012233084
#define LBL_tag 324116
#define LBL_tuple 312083426
#define LBL_tys 324872
#define LBL_vals 10107449
static uint32_t shape_kinds__cons[] = {LBL_kinds, LBL_cons};
static uint32_t shape_lets__vals[] = {LBL_lets, LBL_vals};
static uint32_t shape_tag__index__tys__places[] = {LBL_tag, LBL_index, LBL_tys, LBL_places};
static uint32_t shape_tuple__numbered__kinds__record__labels__cons__group[] = {LBL_tuple, LBL_numbered, LBL_kinds, LBL_record, LBL_labels, LBL_cons, LBL_group};
V g_heff_2ecompile_2ecpr_2eaddOut(V, V);
V g_heff_2ecompile_2ecpr_2eaddOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eaddOut_clo;
V g_heff_2ecompile_2ecpr_2eapart(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapart_clo;
V g_heff_2ecompile_2ecpr_2eapart_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapart_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapart_24dps_clo;
V g_heff_2ecompile_2ecpr_2eapartW(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapartW_clo;
V g_heff_2ecompile_2ecpr_2earmBodyAs(V, V, V, V);
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo;
V g_heff_2ecompile_2ecpr_2earmOf(V, V);
V g_heff_2ecompile_2ecpr_2earmOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmOf_clo;
HeffT2 g_heff_2ecompile_2ecpr_2earmOf_24cpr(V, V);
V g_heff_2ecompile_2ecpr_2eboundAll(V, V);
V g_heff_2ecompile_2ecpr_2eboundAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eboundAll_clo;
V g_heff_2ecompile_2ecpr_2eboundOne(V, V);
V g_heff_2ecompile_2ecpr_2eboundOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eboundOne_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOf(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOf_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOut(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo;
V g_heff_2ecompile_2ecpr_2echosen(V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_clo;
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V, V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo;
V g_heff_2ecompile_2ecpr_2edropCalling(V);
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edropCalling_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecpr_2efitting_24cpr(V);
V g_heff_2ecompile_2ecpr_2efreeAt(V, V, V, V);
V g_heff_2ecompile_2ecpr_2efreeAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efreeAt_clo;
V g_heff_2ecompile_2ecpr_2elabelAt(V, V, V);
V g_heff_2ecompile_2ecpr_2elabelAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elabelAt_clo;
V g_heff_2ecompile_2ecpr_2elaid(V);
V g_heff_2ecompile_2ecpr_2elaid_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elaid_clo;
HeffT2 g_heff_2ecompile_2ecpr_2elayoutOf_24cpr(V, V);
V g_heff_2ecompile_2ecpr_2elayoutsAt(V, V, V);
V g_heff_2ecompile_2ecpr_2elayoutsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elayoutsAt_clo;
V g_heff_2ecompile_2ecpr_2eletCallIn(V, V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2eletCallIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eletCallIn_clo;
V g_heff_2ecompile_2ecpr_2eletRw(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2eletRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eletRw_clo;
V g_heff_2ecompile_2ecpr_2ematchCallIn(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ematchCallIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ematchCallIn_clo;
V g_heff_2ecompile_2ecpr_2ematchRw(V, V, V, V);
V g_heff_2ecompile_2ecpr_2ematchRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ematchRw_clo;
V g_heff_2ecompile_2ecpr_2eoutsW(V, V);
V g_heff_2ecompile_2ecpr_2eoutsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutsW_clo;
V g_heff_2ecompile_2ecpr_2eplaceOne(V, V);
V g_heff_2ecompile_2ecpr_2eplaceOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eplaceOne_clo;
V g_heff_2ecompile_2ecpr_2eplacedAt(V, V, V);
V g_heff_2ecompile_2ecpr_2eplacedAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eplacedAt_clo;
HeffT2 g_heff_2ecompile_2ecpr_2erecordLayout_24cpr(V, V, V);
V g_heff_2ecompile_2ecpr_2erw(V, V);
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2erw_clo;
V g_heff_2ecompile_2ecpr_2esameLabels(V, V);
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esameLabels_clo;
V g_heff_2ecompile_2ecpr_2eshapesOf(V, V);
V g_heff_2ecompile_2ecpr_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eshapesOf_clo;
V g_heff_2ecompile_2ecpr_2esiteLet(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2esiteLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteLet_clo;
HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V, V, V);
V g_heff_2ecompile_2ecpr_2etaggedWith(V, V, V, V);
V g_heff_2ecompile_2ecpr_2etaggedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etaggedWith_clo;
V g_heff_2ecompile_2ecpr_2etakenApart(V, V, V);
V g_heff_2ecompile_2ecpr_2etakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etakenApart_clo;
V g_heff_2ecompile_2ecpr_2etupleOfCon(V, V, V);
V g_heff_2ecompile_2ecpr_2etupleOfCon_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etupleOfCon_clo;
V g_heff_2ecompile_2ecpr_2etupleVars(V);
V g_heff_2ecompile_2ecpr_2etupleVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etupleVars_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24s1016340684x604821087(V, V);
V g_list_2efoldl_24s1016340684x604821087_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1016340684x604821087_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1431636639x1417377628(V, V);
V g_list_2efoldl_24s1431636639x1417377628_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1431636639x1417377628_clo;
V g_list_2efoldl_24s1980014771x775787011(V, V);
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1980014771x775787011_clo;
V g_list_2efoldl_24s271650647x1598714891(V, V);
V g_list_2efoldl_24s271650647x1598714891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s271650647x1598714891_clo;
V g_list_2efoldl_24s613227028x1491044459(V, V);
V g_list_2efoldl_24s613227028x1491044459_entry(V self, V *a);
extern Clo g_list_2efoldl_24s613227028x1491044459_clo;
V g_list_2efoldl_24s651278233x871164524(V, V);
V g_list_2efoldl_24s651278233x871164524_entry(V self, V *a);
extern Clo g_list_2efoldl_24s651278233x871164524_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1263350589x621576050(V);
V g_list_2emap_24s1263350589x621576050_entry(V self, V *a);
extern Clo g_list_2emap_24s1263350589x621576050_clo;
V g_list_2emap_24s1902028738x441242582(V);
V g_list_2emap_24s1902028738x441242582_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1680834068x1673006787(V, V);
V g_list_2ezipWith_24s1680834068x1673006787_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1267794550x535874087(V, V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s1267794550x535874087_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1267794550x535874087_clo;
V g_prelude_2etraverse_24s1673840189x4008143(V, V);
V g_prelude_2etraverse_24s1673840189x4008143_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1673840189x4008143_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_heff_2ecompile_2ecpr_2eoutsW_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutsW_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eoutsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eoutsW_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eoutsW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_245;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_247;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      heff_take_n(v_x21_242, 0ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2410;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      heff_take_n(v_x21_242, 0ULL, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2413;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_b_2416 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 4ULL, 3);
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_2416, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x21_242, 0);
      V v_ts_2418 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2419 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2417)));
      V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2417; V r_ = (g_list_2efoldl_24f2092936166x2062766724(a_0, a_1, a_2)); heff_drop(v_fs_2417); r_; });
      V v_t_2421 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2420, MK_INT(1LL))));
      V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eoutsW_lam0, 1, 1, (V[]){v_ts_2418}), v_t_2421));
      V v_t_2424 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutRecord, 2, (V[]){v_t_2419, v_t_2423}), v_acc_240});
      V t_0 = v_t_2424;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      heff_take_n(v_x21_242, 0ULL, 4);
      V v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2429;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_t_2430 = heff_field(v_x21_242, 0);
      V v_as_2431 = heff_field(v_x21_242, 1);
      V v_ts_2432 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2431; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_as_2431); r_; });
      V v_t_2434 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2433, MK_INT(1LL))));
      V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eoutsW_lam1, 1, 1, (V[]){v_ts_2432}), v_t_2434));
      V v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutTag, 2, (V[]){v_t_2430, v_t_2436}), v_acc_240});
      V t_0 = v_t_2437;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_arms_2439 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2440 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2439, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2440;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      V v_t_2442 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2442;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_242, 0ULL, 2);
      V v_t_2445 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2445;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2446 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2448 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutCall, 1, (V[]){v_g_2446}), v_acc_240});
      V t_0 = v_t_2448;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      V v_t_2450 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2450;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      V v_t_2452 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2452;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      V v_t_2454 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2454;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      V v_t_2456 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2456;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      V v_t_2459 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2459;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      V v_t_2461 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2461;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      V v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_240});
      V t_0 = v_t_2464;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2eoutsW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eoutsW(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eoutsW_lam0(V self, V *args) {
  V v_i_2422 = args[0];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2422; V a_1 = v_ts_2418; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2418); r_; });
}
V g_heff_2ecompile_2ecpr_2eoutsW_lam1(V self, V *args) {
  V v_i_2435 = args[0];
  V v_ts_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2435; V a_1 = v_ts_2432; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2432); r_; });
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2edropCalling_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2edropCalling_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2edropCalling_entry, 1, 0};

V g_heff_2ecompile_2ecpr_2edropCalling(V v_m_240) {
top: ;
  V v_t_241 = (g_std_2emap_2etoListOnto(v_m_240, NTAG(TAG_Nil)));
  V v_ps_2414 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2ecpr_2edropCalling_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_t_241));
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2414; V r_ = (g_list_2efoldl_24s651278233x871164524(a_0, a_1)); heff_drop(v_ps_2414); r_; });
}
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2edropCalling(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam1(V self, V *args) {
  V v_g_248 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V a_0 = v_m_240; V a_1 = v_g_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_m_240); heff_drop(v_g_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2413 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2413); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam0(V self, V *args) {
  V v_p_242 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245;
  switch (heff_tag_of(v_p_242)) {
  case TAG_MkPair: {
    V v_y_244 = heff_field(v_p_242, 1);
    heff_take_n(v_p_242, 2ULL, 2);
    v_t_245 = v_y_244;
    break;
  }
  default: heff_nomatch(v_p_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
  V v_t_247 = (g_list_2efoldl_24s1980014771x775787011(NTAG(TAG_Nil), v_t_246));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edropCalling_lam1, 1, 1, (V[]){v_m_240}); V a_1 = v_t_247; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_247); r_; });
}
Clo g_heff_2ecompile_2ecpr_2etaggedWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2etaggedWith_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2etaggedWith(V v_m_240, V v_t_241, V v_ts_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_240, v_t_241, v_ts_242));
    return heff_tag_n(TAG_TagShape, 1, (V[]){v_t_244});
  }
  case TAG_Just: {
    V v_ts0_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts0_245));
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
    if (heff_intEq_c(v_t_246, v_t_247)) {
      V v_t_249 = (g_list_2ezipWith_24s1680834068x1673006787(v_ts0_245, v_ts_242));
      V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_240, v_t_241, v_t_249));
      return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_TagShape, 1, (V[]){v_t_2410});
    } else {
      heff_drop(v_m_240);
      heff_drop(v_t_241);
      heff_drop(v_ts_242);
      heff_drop(v_ts0_245);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_BadShape);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2etaggedWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2etaggedWith(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2ecpr_2eaddOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eaddOut_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eaddOut(V v_s_240, V v_o_241) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OutTag: {
    V v_t_242 = heff_field(v_o_241, 0);
    V v_ts_243 = heff_field(v_o_241, 1);
    heff_take_n(v_o_241, 3ULL, 2);
    switch (heff_tag_of(v_s_240)) {
    case TAG_NoShape: {
      V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_dup(g_std_2emap_2eempty_get()), v_t_242, v_ts_243));
      return heff_tag_n(TAG_TagShape, 1, (V[]){v_t_244});
    }
    case TAG_RecordShape: {
      heff_take_n(v_s_240, 0ULL, 2);
      heff_drop(v_t_242);
      heff_drop(v_ts_243);
      return NTAG(TAG_BadShape);
    }
    case TAG_TagShape: {
      V v_m_247 = heff_field(v_s_240, 0);
      heff_take_n(v_s_240, 1ULL, 1);
      V v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411(v_m_247, v_t_242));
      return (g_heff_2ecompile_2ecpr_2etaggedWith(v_m_247, v_t_242, v_ts_243, v_t_248));
    }
    case TAG_BadShape: {
      heff_drop(v_t_242);
      heff_drop(v_ts_243);
      return NTAG(TAG_BadShape);
    }
    default: return heff_nomatch(v_s_240);
    }
  }
  case TAG_OutRecord: {
    V v_o1_249 = heff_field(v_o_241, 0);
    V v_o2_2410 = heff_field(v_o_241, 1);
    V v_ru_24o_241_24OutRecord = heff_take_reuse_n(v_o_241, 3ULL, 2);
    switch (heff_tag_of(v_s_240)) {
    case TAG_NoShape: {
      return heff_tag_at_n(v_ru_24o_241_24OutRecord, TAG_RecordShape, 2, (V[]){v_o1_249, v_o2_2410});
    }
    case TAG_RecordShape: {
      V v_ls_2411 = heff_field(v_s_240, 0);
      V v_ts_2412 = heff_field(v_s_240, 1);
      heff_take_n(v_s_240, 3ULL, 2);
      V v_t_2413 = ({ V a_0 = v_ls_2411; V a_1 = v_o1_249; V r_ = (g_heff_2ecompile_2ecpr_2esameLabels(a_0, a_1)); heff_drop(v_o1_249); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = (g_list_2ezipWith_24s1680834068x1673006787(v_ts_2412, v_o2_2410));
        return heff_tag_at_n(v_ru_24o_241_24OutRecord, TAG_RecordShape, 2, (V[]){v_ls_2411, v_t_2414});
      } else {
        heff_drop(v_o2_2410);
        heff_drop_cell(v_ru_24o_241_24OutRecord, 2);
        heff_drop(v_ls_2411);
        heff_drop(v_ts_2412);
        heff_drop(v_t_2413);
        return NTAG(TAG_BadShape);
      }
    }
    case TAG_TagShape: {
      heff_take_n(v_s_240, 0ULL, 1);
      heff_drop(v_o1_249);
      heff_drop(v_o2_2410);
      heff_drop_cell(v_ru_24o_241_24OutRecord, 2);
      return NTAG(TAG_BadShape);
    }
    case TAG_BadShape: {
      heff_drop(v_o1_249);
      heff_drop(v_o2_2410);
      heff_drop_cell(v_ru_24o_241_24OutRecord, 2);
      return NTAG(TAG_BadShape);
    }
    default: return heff_nomatch(v_s_240);
    }
  }
  case TAG_OutCall: {
    heff_take_n(v_o_241, 0ULL, 1);
    return v_s_240;
  }
  case TAG_OutOther: {
    heff_drop(v_s_240);
    return NTAG(TAG_BadShape);
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2ecpr_2eaddOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eaddOut(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecpr_2efreeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2efreeAt_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2efreeAt(V v_k_240, V v_used_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k2_244 = heff_field(v_x4_243, 0);
    V v_ks_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2ecompile_2erepr_2ereprEq(v_k_240, v_k2_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x1_247 = (g_list_2eany_24s120814613x1439363162(heff_dup(v_i_242), v_used_241));
      if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
        heff_drop(v_x1_247);
        V t_0 = v_k_240;
        V t_1 = v_used_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_ks_245;
        v_k_240 = t_0;
        v_used_241 = t_1;
        v_i_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      } else {
        heff_drop(v_x1_247);
        return heff_tag_n(TAG_Just, 1, (V[]){v_i_242});
      }
    } else {
      heff_drop(v_t_246);
      V t_0 = v_k_240;
      V t_1 = v_used_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_ks_245;
      v_k_240 = t_0;
      v_used_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2efreeAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2ecpr_2efreeAt(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecpr_2eplaceOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eplaceOne_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eplaceOne(V v_p_240, V v_t_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_t_241)) {
  case TAG_FtFloat: {
    v_t_245 = NTAG(TAG_RepF64);
    break;
  }
  case TAG_FtFixed: {
    V v_w_242 = heff_dup(heff_field(v_t_241, 0));
    int64_t v_t_243;
    switch (heff_tag_of(v_w_242)) {
    case TAG_I8: {
      v_t_243 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_243 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_243 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_243 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_243 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_243 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_243 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_243 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_243 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_242);
    }
    if ((v_t_243 == ((int64_t)64ULL))) {
      v_t_245 = heff_tag_n(TAG_RepFix, 1, (V[]){v_w_242});
    } else {
      heff_drop(v_w_242);
      v_t_245 = NTAG(TAG_RepV);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_245 = NTAG(TAG_RepV);
    break;
  }
  case TAG_FtAny: {
    v_t_245 = NTAG(TAG_RepV);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_249;
  switch (heff_tag_of(v_t_241)) {
  case TAG_FtFloat: {
    v_t_249 = NTAG(TAG_RepF64);
    break;
  }
  case TAG_FtFixed: {
    V v_w_246 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24FtFixed = heff_take_reuse_n(v_t_241, 1ULL, 1);
    int64_t v_t_247;
    switch (heff_tag_of(v_w_246)) {
    case TAG_I8: {
      v_t_247 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_247 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_247 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_247 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_247 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_247 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_246);
    }
    if ((v_t_247 == ((int64_t)64ULL))) {
      v_t_249 = heff_tag_at_n(v_ru_24t_241_24FtFixed, TAG_RepFix, 1, (V[]){v_w_246});
    } else {
      heff_drop(v_w_246);
      heff_drop_cell(v_ru_24t_241_24FtFixed, 1);
      v_t_249 = NTAG(TAG_RepV);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_249 = NTAG(TAG_RepV);
    break;
  }
  case TAG_FtAny: {
    v_t_249 = NTAG(TAG_RepV);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = heff_rfield(v_p_240, 1); V a_2 = MK_INT(0LL); V a_3 = heff_rfield(v_p_240, 0); V r_ = (g_heff_2ecompile_2ecpr_2efreeAt(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  return ({ V a_0 = v_p_240; V a_1 = v_t_245; V a_2 = v_t_2410; V r_ = (g_heff_2ecompile_2ecpr_2eplacedAt(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
}
V g_heff_2ecompile_2ecpr_2eplaceOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eplaceOne(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ecpr_2efitting_24cpr(V v_lay_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_lay_240, 5)));
  if (heff_intLe_c(v_t_241, MK_INT(4LL))) {
    V v_t_243 = heff_dup(heff_rfield(v_lay_240, 1));
    V v_t_245;
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_dup(heff_rfield(v_lay_240, 2))});
    } else {
      heff_drop(v_t_243);
      v_t_245 = heff_dup(heff_rfield(v_lay_240, 2));
    }
    V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    if (heff_intLe_c(v_t_246, MK_INT(4LL))) {
      V v_t_248 = heff_dup(heff_rfield(v_lay_240, 2));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        heff_drop_rec(v_lay_240, 7);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        heff_take_n(v_t_248, 0ULL, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_lay_240}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_248)}});
      }
    } else {
      heff_drop_rec(v_lay_240, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop_rec(v_lay_240, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str3, 1, "#");

HeffT2 g_heff_2ecompile_2ecpr_2erecordLayout_24cpr(V v_root_240, V v_ls_241, V v_ts_242) {
top: ;
  V v_rs_243 = (g_list_2emap_24s1263350589x621576050(heff_dup(v_ts_242)));
  V v_x2_244 = (g_list_2emap_24s2090270526x1588636862(v_rs_243));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = (g_list_2emap_24s1263350589x621576050(heff_dup(v_ts_242)));
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_tag__index__tys__places, (V[]){((V)&g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str2), MK_INT(0LL), v_ts_242, v_t_2410}), NTAG(TAG_Nil)});
  V v_t_2412 = heff_rec_n(7, shape_tuple__numbered__kinds__record__labels__cons__group, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2erecordLayout_24cpr_str3), v_t_247), NTAG(TAG_False), v_t_248, NTAG(TAG_True), v_ls_241, v_t_2411, v_root_240});
  return (g_heff_2ecompile_2ecpr_2efitting_24cpr(v_t_2412));
}

HeffT2 g_heff_2ecompile_2ecpr_2elayoutOf_24cpr(V v_root_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_NoShape: {
    heff_drop(v_root_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RecordShape: {
    V v_ls_242 = heff_field(v_s_241, 0);
    V v_ts_243 = heff_field(v_s_241, 1);
    return (g_heff_2ecompile_2ecpr_2erecordLayout_24cpr(v_root_240, heff_dup(v_ls_242), heff_dup(v_ts_243)));
  }
  case TAG_TagShape: {
    V v_m_244 = heff_field(v_s_241, 0);
    V v_x_245 = (g_std_2emap_2esize(v_m_244));
    V v_t_246 = heff_rec_n(2, shape_kinds__cons, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_247 = (g_std_2emap_2etoListOnto(v_m_244, NTAG(TAG_Nil)));
    V v_t_248 = ({ V a_0 = v_t_246; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1431636639x1417377628(a_0, a_1)); heff_drop(v_t_247); r_; });
    return (g_heff_2ecompile_2ecpr_2etagLayout_24cpr(v_root_240, heff_intLt(MK_INT(1LL), v_x_245), v_t_248));
  }
  case TAG_BadShape: {
    heff_drop(v_root_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_s_241)}});
  }
}
Clo g_heff_2ecompile_2ecpr_2elaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elaid_entry, 1, 0};

V g_heff_2ecompile_2ecpr_2elaid(V v_m_240) {
top: ;
  V v_t_241 = (g_std_2emap_2etoListOnto(v_m_240, NTAG(TAG_Nil)));
  V v_t_242 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_241; V r_ = (g_list_2efoldl_24s271650647x1598714891(a_0, a_1)); heff_drop(v_t_241); r_; });
  V v_t_243 = (g_std_2emap_2etoListOnto(v_m_240, NTAG(TAG_Nil)));
  V v_t_244 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s271650647x1598714891(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_shapes_245 = ({ V a_0 = v_t_244; V a_1 = v_m_240; V r_ = (g_heff_2ecompile_2ecpr_2eshapesOf(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = ({ V a_0 = v_shapes_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_shapes_245); r_; });
  V v_t_247 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s613227028x1491044459(a_0, a_1)); heff_drop(v_t_246); r_; });
  return ({ V a_0 = v_t_242; V a_1 = v_t_247; V a_2 = v_m_240; V r_ = (g_heff_2ecompile_2ecpr_2elayoutsAt(a_0, a_1, a_2)); heff_drop(v_t_242); heff_drop(v_t_247); r_; });
}
V g_heff_2ecompile_2ecpr_2elaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2elaid(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2ecpr_2earmOf_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_as_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_dup(heff_field(v_a_242, 0));
      v_t_247 = v_t_244;
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_t_240, 1)) {
      heff_drop(v_as_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_242}});
    } else {
      heff_drop(v_a_242);
      V t_0 = v_t_240;
      V t_1 = v_as_243;
      v_t_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2ecpr_2eapartW_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eapartW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eapartW_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2eapartW(V v_lay_240, V v_x_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lay_240, 7);
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_249 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_249, v_rest_245});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x41_244, 0);
      V v_as_2411 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI(v_as_2411, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2412});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2414 = heff_field(v_x41_244, 1);
      V v_b_2415 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_2416 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_245})});
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2416;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2417, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2419;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 4);
      V v_t_2460;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_EVar: {
        V v_y_2424 = heff_dup(heff_field(v_e_2420, 0));
        if (heff_strEq_c_lent(v_x_241, v_y_2424, 2)) {
          V v_t_2426 = heff_dup(heff_rfield(v_lay_240, 3));
          if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
            heff_drop(v_t_2426);
            v_t_2460 = heff_intAdd(v_n_242, MK_INT(1LL));
          } else {
            heff_drop(v_t_2426);
            v_t_2460 = v_n_242;
          }
        } else {
          v_t_2460 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2460 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2460 = v_n_242;
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_t_2460;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_245});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2462 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2464 = (g_heff_2ecompile_2eir_2eappendI(v_as_2462, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2464;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2465 = heff_field(v_x41_244, 0);
      V v_arms_2466 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_24110;
      switch (heff_tag_of(v_s_2465)) {
      case TAG_EVar: {
        V v_y_2467 = heff_dup(heff_field(v_s_2465, 0));
        if (heff_strEq_c_lent(v_x_241, v_y_2467, 2)) {
          V v_t_2469 = heff_dup(heff_rfield(v_lay_240, 3));
          if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
            heff_drop(v_t_2469);
            v_t_24110 = v_n_242;
          } else {
            heff_drop(v_t_2469);
            V v_t_2476 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2ecpr_2eapartW_lam0, 1, 1, (V[]){heff_dup(v_arms_2466)}), heff_rfield(v_lay_240, 5)));
            if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
              heff_drop(v_t_2476);
              v_t_24110 = heff_intAdd(v_n_242, MK_INT(1LL));
            } else {
              heff_drop(v_t_2476);
              v_t_24110 = v_n_242;
            }
          }
        } else {
          v_t_24110 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_24110 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_24110 = v_n_242;
        break;
      }
      default: heff_nomatch(v_s_2465);
      }
      V v_t_24111 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2466, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_t_24110;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_2465, v_t_24111});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_24114 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_24115 = (g_heff_2ecompile_2eir_2eappendI(v_as_24114, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_24115;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_as_24117 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_24118 = (g_heff_2ecompile_2eir_2eappendI(v_as_24117, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_24118;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2eapartW(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eapartW_lam0(V self, V *args) {
  V v_c_2470 = args[0];
  V v_arms_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2471 = ({ V b_0 = heff_get_n(v_c_2470, 0, 4); V a_1 = v_arms_2466; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2473 = v_t_2471.f[1];
    int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2472 == ((int64_t)0ULL)) && ({ V v_x11_2475 = heff_dup(v_field_2473); int c_ = 1; heff_drop(v_x11_2475); c_; })));
    heff_drop(v_field_2473);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2ecpr_2esiteLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esiteLet_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2esiteLet(V v_k_240, V v_acc_241, V v_x_242, V v_a_243, V v_b_244) {
top: ;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    heff_take_n(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_ELam: {
    heff_take_n(v_a_243, 0ULL, 2);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EApp: {
    heff_take_n(v_a_243, 0ULL, 2);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_ELet: {
    heff_take_n(v_a_243, 0ULL, 3);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_ERecord: {
    heff_take_n(v_a_243, 0ULL, 2);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EProj: {
    heff_take_n(v_a_243, 0ULL, 4);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_ETag: {
    heff_take_n(v_a_243, 0ULL, 3);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EMatch: {
    heff_take_n(v_a_243, 0ULL, 2);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EPrim: {
    heff_take_n(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_243, 0ULL, 2);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_ECall: {
    V v_g_2428 = heff_field(v_a_243, 0);
    V v_ru_24a_243_24ECall = heff_take_reuse_n(v_a_243, 1ULL, 2);
    HeffT2 v_t_2430 = ({ V a_0 = v_k_240; V a_1 = v_g_2428; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_g_2428); r_; });
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_lay_2434 = v_field_2432;
        V v_t_2435 = (g_heff_2ecompile_2ecpr_2etakenApart(heff_dup(v_lay_2434), v_x_242, v_b_244));
        if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
          heff_drop(v_t_2435);
          return heff_tag_at_n(v_ru_24a_243_24ECall, TAG_Cons, 2, (V[]){heff_get_n(v_lay_2434, 6, 7), v_acc_241});
        } else {
          heff_drop_cell(v_ru_24a_243_24ECall, 2);
          heff_drop_rec(v_lay_2434, 7);
          heff_drop(v_t_2435);
          return v_acc_241;
        }
      } else {
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24a_243_24ECall, 2);
        heff_drop(v_field_2432);
        return v_acc_241;
      }
    }
  }
  case TAG_EInt: {
    heff_take_n(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EFloat: {
    heff_take_na(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EStr: {
    heff_take_n(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EBytes: {
    heff_take_n(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EFixed: {
    heff_take_n(v_a_243, 0ULL, 2);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_243, 0ULL, 1);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_b_244);
    return v_acc_241;
  }
  case TAG_EFix: {
    heff_take_n(v_a_243, 0ULL, 2);
    heff_drop(v_b_244);
    return v_acc_241;
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2ecpr_2esiteLet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2esiteLet(a0, a[1], a2, a[3], a[4]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecpr_2elabelAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elabelAt_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2elabelAt(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 0)) {
      return v_i_241;
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2elabelAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2elabelAt(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eapart_str0, 0, "");
V g_heff_2ecompile_2ecpr_2eapart_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam3(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eapart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eapart_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2eapart(V v_lay_240, V v_x_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_ELam: {
    V v_ys_246 = heff_field(v_x4_243, 0);
    V v_b_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24ELam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24x4_243_24ELam, TAG_ELam, 2, (V[]){v_ys_246, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2ecpr_2eapart_24dps(v_lay_240, v_x_241, v_vs_242, v_b_247, heff_dup(v_cell_248), MK_INT(1LL)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_x4_243, 0);
    V v_as_2411 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2412 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242), v_f_2410));
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_2414 = (g_list_2emap(v_t_2413, v_as_2411));
    return heff_tag_at_n(v_ru_24x4_243_24EApp, TAG_EApp, 2, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_ELet: {
    V v_y_2415 = heff_field(v_x4_243, 0);
    V v_a_2416 = heff_field(v_x4_243, 1);
    V v_b_2417 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24ELet = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    V v_t_2418 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242), v_a_2416));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x4_243_24ELet, TAG_ELet, 3, (V[]){v_y_2415, v_t_2418, heff_hole()});
    V v_u_2420 = (g_heff_2ecompile_2ecpr_2eapart_24dps(v_lay_240, v_x_241, v_vs_242, v_b_2417, heff_dup(v_cell_2419), MK_INT(2LL)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_x4_243, 0);
    V v_ts_2422 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24ERecord = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam0, 1, 3, (V[]){v_lay_240, v_x_241, v_vs_242}), v_fs_2421));
    return heff_tag_at_n(v_ru_24x4_243_24ERecord, TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2422});
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x4_243, 0);
    V v_l_2433 = heff_field(v_x4_243, 1);
    V v_sh_2434 = heff_field(v_x4_243, 2);
    V v_t_2435 = heff_field(v_x4_243, 3);
    V v_ru_24x4_243_24EProj = heff_take_reuse_n(v_x4_243, 15ULL, 4);
    V v_t_2470;
    switch (heff_tag_of(v_e_2432)) {
    case TAG_EVar: {
      V v_y_2436 = heff_dup(heff_field(v_e_2432, 0));
      v_t_2470 = heff_strEq_lent(v_x_241, v_y_2436, 2);
      break;
    }
    case TAG_EGlobal: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_2432);
    }
    if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop(v_e_2432);
      heff_drop(v_sh_2434);
      heff_drop(v_t_2435);
      heff_drop_cell(v_ru_24x4_243_24EProj, 4);
      heff_drop(v_t_2470);
      V v_i_2471 = ({ V a_0 = v_l_2433; V a_1 = MK_INT(0LL); V a_2 = heff_rfield(v_lay_240, 4); V r_ = (g_heff_2ecompile_2ecpr_2elabelAt(a_0, a_1, a_2)); heff_drop(v_l_2433); r_; });
      V v_t_2472 = heff_get_n(v_lay_240, 1, 7);
      V v_t_2473;
      if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
        heff_drop(v_t_2472);
        v_t_2473 = heff_intAdd(v_i_2471, MK_INT(1LL));
      } else {
        heff_drop(v_t_2472);
        v_t_2473 = v_i_2471;
      }
      HeffT3 v_t_2474 = ({ V a_0 = v_t_2473; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
      V v_t_2481;
      {
        V v_field_2476 = v_t_2474.f[1];
        V v_field_2477 = v_t_2474.f[2];
        int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
        if ((v_tag_2475 == ((int64_t)0ULL))) {
          V v_x_2479 = v_field_2476;
          V v_x12_2480 = v_field_2477;
          heff_drop(v_x12_2480);
          v_t_2481 = v_x_2479;
        } else {
          heff_drop(v_field_2476);
          heff_drop(v_field_2477);
          v_t_2481 = ((V)&g_heff_2ecompile_2ecpr_2eapart_str0);
        }
      }
      return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2481});
    } else {
      heff_drop(v_t_2470);
      V v_t_2482 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(v_lay_240, v_x_241, v_vs_242, v_e_2432));
      return heff_tag_at_n(v_ru_24x4_243_24EProj, TAG_EProj, 4, (V[]){v_t_2482, v_l_2433, v_sh_2434, v_t_2435});
    }
  }
  case TAG_ETag: {
    V v_t_2483 = heff_field(v_x4_243, 0);
    V v_as_2484 = heff_field(v_x4_243, 1);
    V v_ts_2485 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24ETag = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    V v_t_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_2487 = (g_list_2emap(v_t_2486, v_as_2484));
    return heff_tag_at_n(v_ru_24x4_243_24ETag, TAG_ETag, 3, (V[]){v_t_2483, v_t_2487, v_ts_2485});
  }
  case TAG_EMatch: {
    V v_s_2488 = heff_field(v_x4_243, 0);
    V v_arms_2489 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EMatch = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_24124;
    switch (heff_tag_of(v_s_2488)) {
    case TAG_EVar: {
      V v_y_2490 = heff_dup(heff_field(v_s_2488, 0));
      v_t_24124 = heff_strEq_lent(v_x_241, v_y_2490, 2);
      break;
    }
    case TAG_EGlobal: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24124 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2488);
    }
    if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
      heff_drop(v_s_2488);
      heff_drop_cell(v_ru_24x4_243_24EMatch, 2);
      heff_drop(v_t_24124);
      V v_go_24125 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){heff_dup(v_lay_240), v_x_241, heff_dup(v_vs_242)}));
      V v_arms_24131 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam1, 1, 1, (V[]){v_go_24125}), v_arms_2489));
      return ({ V a_0 = v_vs_242; V a_1 = heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam2, 1, 3, (V[]){v_arms_24131, heff_dup(v_lay_240), heff_dup(v_vs_242)}); V a_2 = heff_get_n(v_lay_240, 5, 7); V r_ = (g_heff_2ecompile_2ecpr_2echosen(a_0, a_1, a_2)); heff_drop(v_vs_242); r_; });
    } else {
      heff_drop(v_t_24124);
      V v_t_24134 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242), v_s_2488));
      V v_go_24135 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
      V v_t_24141 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam3, 1, 1, (V[]){v_go_24135}), v_arms_2489));
      return heff_tag_at_n(v_ru_24x4_243_24EMatch, TAG_EMatch, 2, (V[]){v_t_24134, v_t_24141});
    }
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EPrimCall: {
    V v_p_24143 = heff_field(v_x4_243, 0);
    V v_as_24144 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EPrimCall = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_24145 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_24146 = (g_list_2emap(v_t_24145, v_as_24144));
    return heff_tag_at_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_24143, v_t_24146});
  }
  case TAG_ECall: {
    V v_g_24147 = heff_field(v_x4_243, 0);
    V v_as_24148 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24ECall = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_24149 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_24150 = (g_list_2emap(v_t_24149, v_as_24148));
    return heff_tag_at_n(v_ru_24x4_243_24ECall, TAG_ECall, 2, (V[]){v_g_24147, v_t_24150});
  }
  case TAG_EInt: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EStr: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  case TAG_EFix: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return v_x4_243;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2eapart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eapart(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecpr_2eapart_lam0(V self, V *args) {
  V v_p_2423 = args[0];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_p_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2429;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_p_2423, 1);
    heff_take_n(v_p_2423, 2ULL, 2);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2430 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(v_lay_240, v_x_241, v_vs_242, v_t_2429));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2430});
}
V g_heff_2ecompile_2ecpr_2eapart_lam1(V self, V *args) {
  V v_x2_24126 = args[0];
  V v_go_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_MkArm: {
    V v_t_24127 = heff_field(v_x2_24126, 0);
    V v_ws_24128 = heff_field(v_x2_24126, 1);
    V v_b_24129 = heff_field(v_x2_24126, 2);
    V v_ru_24x2_24126_24MkArm = heff_take_reuse_n(v_x2_24126, 7ULL, 3);
    V v_t_24130 = heff_tr(heff_call(v_go_24125, 1, (V[]){v_b_24129}));
    return heff_tag_at_n(v_ru_24x2_24126_24MkArm, TAG_MkArm, 3, (V[]){v_t_24127, v_ws_24128, v_t_24130});
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2ecompile_2ecpr_2eapart_lam2(V self, V *args) {
  V v_c_24132 = args[0];
  V v_arms_24131 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24133 = (g_heff_2ecompile_2ecpr_2earmOf(heff_rfield(v_c_24132, 0), v_arms_24131));
  return ({ V a_0 = v_lay_240; V a_1 = v_vs_242; V a_2 = v_c_24132; V a_3 = v_t_24133; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_242); r_; });
}
V g_heff_2ecompile_2ecpr_2eapart_lam3(V self, V *args) {
  V v_x2_24136 = args[0];
  V v_go_24135 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkArm: {
    V v_t_24137 = heff_field(v_x2_24136, 0);
    V v_ws_24138 = heff_field(v_x2_24136, 1);
    V v_b_24139 = heff_field(v_x2_24136, 2);
    V v_ru_24x2_24136_24MkArm = heff_take_reuse_n(v_x2_24136, 7ULL, 3);
    V v_t_24140 = heff_tr(heff_call(v_go_24135, 1, (V[]){v_b_24139}));
    return heff_tag_at_n(v_ru_24x2_24136_24MkArm, TAG_MkArm, 3, (V[]){v_t_24137, v_ws_24138, v_t_24140});
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eapart_24dps_str0, 0, "");
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam3(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eapart_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eapart_24dps_entry, 6, 0};

V g_heff_2ecompile_2ecpr_2eapart_24dps(V v_lay_240, V v_x_241, V v_vs_242, V v_x4_243, V v_d_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_ELam: {
    V v_ys_248 = heff_field(v_x4_243, 0);
    V v_b_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24ELam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x4_243_24ELam, TAG_ELam, 2, (V[]){v_ys_248, heff_hole()});
    V v_u_2411 = heff_setField(v_d_244, v_i_245, heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_lay_240;
    V t_1 = v_x_241;
    V t_2 = v_vs_242;
    V t_3 = v_b_249;
    V t_4 = v_cell_2410;
    V t_5 = MK_INT(1LL);
    v_lay_240 = t_0;
    v_x_241 = t_1;
    v_vs_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x4_243, 0);
    V v_as_2413 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2414 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242), v_f_2412));
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_2416 = (g_list_2emap(v_t_2415, v_as_2413));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2414, v_t_2416}));
  }
  case TAG_ELet: {
    V v_y_2417 = heff_field(v_x4_243, 0);
    V v_a_2418 = heff_field(v_x4_243, 1);
    V v_b_2419 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24ELet = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    V v_t_2420 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242), v_a_2418));
    V v_cell_2421 = heff_tag_at_n(v_ru_24x4_243_24ELet, TAG_ELet, 3, (V[]){v_y_2417, v_t_2420, heff_hole()});
    V v_u_2422 = heff_setField(v_d_244, v_i_245, heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_lay_240;
    V t_1 = v_x_241;
    V t_2 = v_vs_242;
    V t_3 = v_b_2419;
    V t_4 = v_cell_2421;
    V t_5 = MK_INT(2LL);
    v_lay_240 = t_0;
    v_x_241 = t_1;
    v_vs_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_x4_243, 0);
    V v_ts_2424 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_24dps_lam0, 1, 3, (V[]){v_lay_240, v_x_241, v_vs_242}), v_fs_2423));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2433, v_ts_2424}));
  }
  case TAG_EProj: {
    V v_e_2434 = heff_field(v_x4_243, 0);
    V v_l_2435 = heff_field(v_x4_243, 1);
    V v_sh_2436 = heff_field(v_x4_243, 2);
    V v_t_2437 = heff_field(v_x4_243, 3);
    heff_take_n(v_x4_243, 15ULL, 4);
    V v_t_2472;
    switch (heff_tag_of(v_e_2434)) {
    case TAG_EVar: {
      V v_y_2438 = heff_dup(heff_field(v_e_2434, 0));
      v_t_2472 = heff_strEq_lent(v_x_241, v_y_2438, 2);
      break;
    }
    case TAG_EGlobal: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2472 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_2434);
    }
    if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop(v_e_2434);
      heff_drop(v_sh_2436);
      heff_drop(v_t_2437);
      heff_drop(v_t_2472);
      V v_i_2473 = ({ V a_0 = v_l_2435; V a_1 = MK_INT(0LL); V a_2 = heff_rfield(v_lay_240, 4); V r_ = (g_heff_2ecompile_2ecpr_2elabelAt(a_0, a_1, a_2)); heff_drop(v_l_2435); r_; });
      V v_t_2474 = heff_get_n(v_lay_240, 1, 7);
      V v_t_2475;
      if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
        heff_drop(v_t_2474);
        v_t_2475 = heff_intAdd(v_i_2473, MK_INT(1LL));
      } else {
        heff_drop(v_t_2474);
        v_t_2475 = v_i_2473;
      }
      HeffT3 v_t_2476 = ({ V a_0 = v_t_2475; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
      V v_t_2483;
      {
        V v_field_2478 = v_t_2476.f[1];
        V v_field_2479 = v_t_2476.f[2];
        int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
        if ((v_tag_2477 == ((int64_t)0ULL))) {
          V v_x_2481 = v_field_2478;
          V v_x12_2482 = v_field_2479;
          heff_drop(v_x12_2482);
          v_t_2483 = v_x_2481;
        } else {
          heff_drop(v_field_2478);
          heff_drop(v_field_2479);
          v_t_2483 = ((V)&g_heff_2ecompile_2ecpr_2eapart_24dps_str0);
        }
      }
      return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2483}));
    } else {
      heff_drop(v_t_2472);
      V v_t_2484 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(v_lay_240, v_x_241, v_vs_242, v_e_2434));
      return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2484, v_l_2435, v_sh_2436, v_t_2437}));
    }
  }
  case TAG_ETag: {
    V v_t_2485 = heff_field(v_x4_243, 0);
    V v_as_2486 = heff_field(v_x4_243, 1);
    V v_ts_2487 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_t_2488 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_2489 = (g_list_2emap(v_t_2488, v_as_2486));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2485, v_t_2489, v_ts_2487}));
  }
  case TAG_EMatch: {
    V v_s_2490 = heff_field(v_x4_243, 0);
    V v_arms_2491 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_24126;
    switch (heff_tag_of(v_s_2490)) {
    case TAG_EVar: {
      V v_y_2492 = heff_dup(heff_field(v_s_2490, 0));
      v_t_24126 = heff_strEq_lent(v_x_241, v_y_2492, 2);
      break;
    }
    case TAG_EGlobal: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2490);
    }
    if ((heff_dup(v_t_24126) == NTAG(TAG_True))) {
      heff_drop(v_s_2490);
      heff_drop(v_t_24126);
      V v_go_24127 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){heff_dup(v_lay_240), v_x_241, heff_dup(v_vs_242)}));
      V v_arms_24133 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_24dps_lam1, 1, 1, (V[]){v_go_24127}), v_arms_2491));
      V v_t_24136 = ({ V a_0 = v_vs_242; V a_1 = heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_24dps_lam2, 1, 3, (V[]){v_arms_24133, heff_dup(v_lay_240), heff_dup(v_vs_242)}); V a_2 = heff_get_n(v_lay_240, 5, 7); V r_ = heff_tr(g_heff_2ecompile_2ecpr_2echosen(a_0, a_1, a_2)); heff_drop(v_vs_242); r_; });
      return heff_setField(v_d_244, v_i_245, v_t_24136);
    } else {
      heff_drop(v_t_24126);
      V v_t_24137 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242), v_s_2490));
      V v_go_24138 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
      V v_t_24144 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_24dps_lam3, 1, 1, (V[]){v_go_24138}), v_arms_2491));
      return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_24137, v_t_24144}));
    }
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EPrimCall: {
    V v_p_24146 = heff_field(v_x4_243, 0);
    V v_as_24147 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_24148 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_24149 = (g_list_2emap(v_t_24148, v_as_24147));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24146, v_t_24149}));
  }
  case TAG_ECall: {
    V v_g_24150 = heff_field(v_x4_243, 0);
    V v_as_24151 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_24152 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eapart_clo), 3, (V[]){v_lay_240, v_x_241, v_vs_242}));
    V v_t_24153 = (g_list_2emap(v_t_24152, v_as_24151));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_ECall, 2, (V[]){v_g_24150, v_t_24153}));
  }
  case TAG_EInt: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EStr: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_EFix: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_x_241);
    heff_drop(v_vs_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2eapart_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eapart_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam0(V self, V *args) {
  V v_p_2425 = args[0];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428;
  switch (heff_tag_of(v_p_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_dup(heff_field(v_p_2425, 0));
    v_t_2428 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_p_2425);
  }
  V v_t_2431;
  switch (heff_tag_of(v_p_2425)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_field(v_p_2425, 1);
    heff_take_n(v_p_2425, 2ULL, 2);
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_p_2425);
  }
  V v_t_2432 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(v_lay_240, v_x_241, v_vs_242, v_t_2431));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_t_2432});
}
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam1(V self, V *args) {
  V v_x2_24128 = args[0];
  V v_go_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkArm: {
    V v_t_24129 = heff_field(v_x2_24128, 0);
    V v_ws_24130 = heff_field(v_x2_24128, 1);
    V v_b_24131 = heff_field(v_x2_24128, 2);
    V v_ru_24x2_24128_24MkArm = heff_take_reuse_n(v_x2_24128, 7ULL, 3);
    V v_t_24132 = heff_tr(heff_call(v_go_24127, 1, (V[]){v_b_24131}));
    return heff_tag_at_n(v_ru_24x2_24128_24MkArm, TAG_MkArm, 3, (V[]){v_t_24129, v_ws_24130, v_t_24132});
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam2(V self, V *args) {
  V v_c_24134 = args[0];
  V v_arms_24133 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24135 = (g_heff_2ecompile_2ecpr_2earmOf(heff_rfield(v_c_24134, 0), v_arms_24133));
  return ({ V a_0 = v_lay_240; V a_1 = v_vs_242; V a_2 = v_c_24134; V a_3 = v_t_24135; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_242); r_; });
}
V g_heff_2ecompile_2ecpr_2eapart_24dps_lam3(V self, V *args) {
  V v_x2_24139 = args[0];
  V v_go_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24139)) {
  case TAG_MkArm: {
    V v_t_24140 = heff_field(v_x2_24139, 0);
    V v_ws_24141 = heff_field(v_x2_24139, 1);
    V v_b_24142 = heff_field(v_x2_24139, 2);
    V v_ru_24x2_24139_24MkArm = heff_take_reuse_n(v_x2_24139, 7ULL, 3);
    V v_t_24143 = heff_tr(heff_call(v_go_24138, 1, (V[]){v_b_24142}));
    return heff_tag_at_n(v_ru_24x2_24139_24MkArm, TAG_MkArm, 3, (V[]){v_t_24140, v_ws_24141, v_t_24143});
  }
  default: return heff_nomatch(v_x2_24139);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2etupleVars_str0, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etupleVars_str1, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etupleVars_str2, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etupleVars_str3, 1, "$");
Clo g_heff_2ecompile_2ecpr_2etupleVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2etupleVars_entry, 1, 0};

V g_heff_2ecompile_2ecpr_2etupleVars(V v_lay_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_lay_240, 1));
  V v_t_243;
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    V v_t_242 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_dup(heff_rfield(v_lay_240, 2))});
  } else {
    heff_drop(v_t_241);
    v_t_243 = heff_dup(heff_rfield(v_lay_240, 2));
  }
  V v_t_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_244, MK_INT(1LL))));
  return heff_tail(((V)&g_prelude_2etraverse_24s1267794550x535874087_clo), 8, (V[]){v_lay_240, MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2etupleVars_str0), ((V)&g_heff_2ecompile_2ecpr_2etupleVars_str1), ((V)&g_heff_2ecompile_2ecpr_2etupleVars_str2), ((V)&g_heff_2ecompile_2ecpr_2etupleVars_str3), MK_INT(1LL), v_t_245});
}
V g_heff_2ecompile_2ecpr_2etupleVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2etupleVars(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eletCallIn_str0, 4, "$cpr");
Clo g_heff_2ecompile_2ecpr_2eletCallIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eletCallIn_entry, 6, 0};

V g_heff_2ecompile_2ecpr_2eletCallIn(V v_x_240, V v_g_241, V v_as_242, V v_b_243, V v_x5_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_as_242}), v_b_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_z_245});
  }
  case TAG_Just: {
    V v_lay_247 = heff_field(v_x5_244, 0);
    V v_t_248 = (g_heff_2ecompile_2ecpr_2etakenApart(heff_dup(v_lay_247), v_x_240, heff_dup(v_b_243)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_m_249 = heff_tr(g_heff_2ecompile_2ecpr_2etupleVars(heff_dup(v_lay_247)));
      V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_245}));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_n_2412 = heff_field(v_x2_2410, 1);
        V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
        V v_t_2413 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_241, ((V)&g_heff_2ecompile_2ecpr_2eletCallIn_str0)), v_as_242});
        V v_t_2414 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(heff_dup(v_lay_247), v_x_240, heff_dup(v_x_2411), v_b_243));
        V v_t_2415 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(heff_rfield(v_lay_247, 0)), v_x_2411, v_t_2414});
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        V v_x_2417 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2413, v_t_2416});
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_n_2412});
      }
      default: return heff_nomatch(v_x2_2410);
      }
    } else {
      heff_drop(v_t_248);
      V v_t_2418 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_as_242}), v_b_243});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_z_245});
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecpr_2eletCallIn_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2ecpr_2eletCallIn(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2ecpr_2eletRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eletRw_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2eletRw(V v_k_240, V v_x_241, V v_a_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_ECall: {
    V v_g_2428 = heff_field(v_a_242, 0);
    V v_as_2429 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    V v_t_2430 = (g_std_2emap_2elookup_24s1963842891x1660122411(v_k_240, v_g_2428));
    return ({ V a_0 = v_x_241; V a_1 = v_g_2428; V a_2 = v_as_2429; V a_3 = v_b_243; V a_4 = v_t_2430; V a_5 = v_z_244; V r_ = (g_heff_2ecompile_2ecpr_2eletCallIn(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2430); r_; });
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_b_243}), v_z_244});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2ecpr_2eletRw_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2eletRw(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2ecpr_2ematchRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ematchRw_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2ematchRw(V v_k_240, V v_s_241, V v_arms_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_ECall: {
    V v_g_2427 = heff_field(v_s_241, 0);
    V v_as_2428 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 3ULL, 2);
    V v_t_2429 = (g_std_2emap_2elookup_24s1963842891x1660122411(v_k_240, v_g_2427));
    return ({ V a_0 = v_g_2427; V a_1 = v_as_2428; V a_2 = v_arms_242; V a_3 = v_t_2429; V a_4 = v_z_243; V r_ = (g_heff_2ecompile_2ecpr_2ematchCallIn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2429); r_; });
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_z_243});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2ecpr_2ematchRw_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2ematchRw(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2erw_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam4(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam6(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam5(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam7(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam8(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam9(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam12(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam11(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam10(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam13(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam14(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam15(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam16(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam17(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam18(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam19(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam20(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam21(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam22(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam23(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2erw_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2erw(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, v_b_247));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_241, 0);
    V v_as_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = (g_heff_2ecompile_2ecpr_2erw(heff_dup(v_k_240), v_f_2413));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam3, 1, 3, (V[]){v_m_2415, v_k_240, v_as_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = (g_heff_2ecompile_2ecpr_2erw(heff_dup(v_k_240), v_a_2426));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam4, 1, 4, (V[]){v_m_2428, v_k_240, v_b_2427, v_x_2425});
  }
  case TAG_ERecord: {
    V v_fs_2437 = heff_field(v_x2_241, 0);
    V v_ts_2438 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_go_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2erw_clo), 1, (V[]){v_k_240}));
    V v_m_2448 = (g_prelude_2etraverse_24s1673840189x4008143(heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam5, 1, 1, (V[]){v_go_2439}), v_fs_2437));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam7, 1, 2, (V[]){v_m_2448, v_ts_2438});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x2_241, 0);
    V v_l_2454 = heff_field(v_x2_241, 1);
    V v_sh_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2457 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, v_e_2453));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam8, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x2_241, 0);
    V v_as_2463 = heff_field(v_x2_241, 1);
    V v_ts_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2erw_clo), 1, (V[]){v_k_240}));
    V v_m_2466 = (g_prelude_2etraverse_24s1673840189x4008143(v_t_2465, v_as_2463));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam9, 1, 3, (V[]){v_m_2466, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_x2_241, 0);
    V v_arms_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2473 = (g_heff_2ecompile_2ecpr_2erw(heff_dup(v_k_240), v_s_2471));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam10, 1, 3, (V[]){v_m_2473, v_k_240, v_arms_2472});
  }
  case TAG_EPrim: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2494 = heff_field(v_x2_241, 0);
    V v_as_2495 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2erw_clo), 1, (V[]){v_k_240}));
    V v_m_2497 = (g_prelude_2etraverse_24s1673840189x4008143(v_t_2496, v_as_2495));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam14, 1, 2, (V[]){v_m_2497, v_p_2494});
  }
  case TAG_ECall: {
    V v_g_24102 = heff_field(v_x2_241, 0);
    V v_as_24103 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24104 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2erw_clo), 1, (V[]){v_k_240}));
    V v_m_24105 = (g_prelude_2etraverse_24s1673840189x4008143(v_t_24104, v_as_24103));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam15, 1, 2, (V[]){v_m_24105, v_g_24102});
  }
  case TAG_EInt: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFix: {
    heff_drop(v_k_240);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam23, 1, 1, (V[]){v_x2_241});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2erw(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2erw_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_243});
}
V g_heff_2ecompile_2ecpr_2erw_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_245});
}
V g_heff_2ecompile_2ecpr_2erw_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_as_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2erw_clo), 1, (V[]){v_k_240}));
    V v_m_2421 = (g_prelude_2etraverse_24s1673840189x4008143(v_t_2420, v_as_2414));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_n_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_n_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam4(V self, V *args) {
  V v_n_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2427 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_n_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_m_2433 = (g_heff_2ecompile_2ecpr_2erw(heff_dup(v_k_240), v_b_2427));
    V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2432}));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_n_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      return ({ V a_0 = v_k_240; V a_1 = v_x_2425; V a_2 = v_x_2431; V a_3 = v_x_2435; V a_4 = v_n_2436; V r_ = (g_heff_2ecompile_2ecpr_2eletRw(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_240); r_; });
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam6(V self, V *args) {
  V v_n_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_n_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_n_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2441, v_x_2446}), v_n_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam5(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_go_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_l_2441 = heff_field(v_x2_2440, 0);
    V v_e_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    V v_m_2443 = heff_tr(heff_call(v_go_2439, 1, (V[]){v_e_2442}));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam6, 1, 2, (V[]){v_m_2443, v_l_2441});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam7(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_ts_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2451, v_ts_2438}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam8(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam9(V self, V *args) {
  V v_n_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_n_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_n_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2469, v_ts_2464}), v_n_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam12(V self, V *args) {
  V v_n_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_t_2480 = heff_env(self)[1];
  V v_ws_2481 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_n_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_n_2487 = heff_field(v_x2_2485, 1);
    V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2480, v_ws_2481, v_x_2486}), v_n_2487});
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam11(V self, V *args) {
  V v_x2_2479 = args[0];
  V v_go_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2479)) {
  case TAG_MkArm: {
    V v_t_2480 = heff_field(v_x2_2479, 0);
    V v_ws_2481 = heff_field(v_x2_2479, 1);
    V v_b_2482 = heff_field(v_x2_2479, 2);
    heff_take_n(v_x2_2479, 7ULL, 3);
    V v_m_2483 = heff_tr(heff_call(v_go_2478, 1, (V[]){v_b_2482}));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam12, 1, 3, (V[]){v_m_2483, v_t_2480, v_ws_2481});
  }
  default: return heff_nomatch(v_x2_2479);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam10(V self, V *args) {
  V v_n_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_arms_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_n_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_n_2477 = heff_field(v_x2_2475, 1);
    heff_take_n(v_x2_2475, 3ULL, 2);
    V v_go_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2erw_clo), 1, (V[]){heff_dup(v_k_240)}));
    V v_m_2488 = (g_prelude_2etraverse_24s1673840189x4008143(heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam11, 1, 1, (V[]){v_go_2478}), v_arms_2472));
    V v_x2_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_n_2477}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_n_2491 = heff_field(v_x2_2489, 1);
      heff_take_n(v_x2_2489, 3ULL, 2);
      return ({ V a_0 = v_k_240; V a_1 = v_x_2476; V a_2 = v_x_2490; V a_3 = v_n_2491; V r_ = (g_heff_2ecompile_2ecpr_2ematchRw(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam13(V self, V *args) {
  V v_n_2493 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_2493});
}
V g_heff_2ecompile_2ecpr_2erw_lam14(V self, V *args) {
  V v_n_2498 = args[0];
  V v_m_2497 = heff_env(self)[0];
  V v_p_2494 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2499 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_n_2498}));
  switch (heff_tag_of(v_x2_2499)) {
  case TAG_MkPair: {
    V v_x_24100 = heff_field(v_x2_2499, 0);
    V v_n_24101 = heff_field(v_x2_2499, 1);
    V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2494, v_x_24100}), v_n_24101});
  }
  default: return heff_nomatch(v_x2_2499);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam15(V self, V *args) {
  V v_n_24106 = args[0];
  V v_m_24105 = heff_env(self)[0];
  V v_g_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24107 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_n_24106}));
  switch (heff_tag_of(v_x2_24107)) {
  case TAG_MkPair: {
    V v_x_24108 = heff_field(v_x2_24107, 0);
    V v_n_24109 = heff_field(v_x2_24107, 1);
    V v_ru_24x2_24107_24MkPair = heff_take_reuse_n(v_x2_24107, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24107_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24102, v_x_24108}), v_n_24109});
  }
  default: return heff_nomatch(v_x2_24107);
  }
}
V g_heff_2ecompile_2ecpr_2erw_lam16(V self, V *args) {
  V v_n_24111 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24111});
}
V g_heff_2ecompile_2ecpr_2erw_lam17(V self, V *args) {
  V v_n_24113 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24113});
}
V g_heff_2ecompile_2ecpr_2erw_lam18(V self, V *args) {
  V v_n_24115 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24115});
}
V g_heff_2ecompile_2ecpr_2erw_lam19(V self, V *args) {
  V v_n_24117 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24117});
}
V g_heff_2ecompile_2ecpr_2erw_lam20(V self, V *args) {
  V v_n_24120 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24120});
}
V g_heff_2ecompile_2ecpr_2erw_lam21(V self, V *args) {
  V v_n_24122 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24122});
}
V g_heff_2ecompile_2ecpr_2erw_lam22(V self, V *args) {
  V v_n_24123 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24123});
}
V g_heff_2ecompile_2ecpr_2erw_lam23(V self, V *args) {
  V v_n_24126 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24126});
}
V g_heff_2ecompile_2ecpr_2etupleOfCon_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2etupleOfCon_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2etupleOfCon_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2etupleOfCon(V v_lay_240, V v_c_241, V v_es_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_lay_240, 1));
  V v_t_245;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_dup(heff_rfield(v_c_241, 1))});
    v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_243);
    v_t_245 = NTAG(TAG_Nil);
  }
  V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_lay_240, 2)));
  V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(1LL))));
  V v_t_2416 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2etupleOfCon_lam0, 2, 2, (V[]){v_c_241, v_es_242}), v_t_247, heff_dup(heff_rfield(v_lay_240, 2))));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_245, v_t_2416));
  V v_t_2418 = heff_take_field(v_lay_240, 1);
  V v_t_2420;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    V v_t_2419 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_dup(heff_rfield(v_lay_240, 2))});
  } else {
    heff_drop(v_t_2418);
    v_t_2420 = heff_dup(heff_rfield(v_lay_240, 2));
  }
  V v_t_2421 = (g_list_2emap_24s1902028738x441242582(v_t_2420));
  return heff_tag_n(TAG_ETag, 3, (V[]){heff_get_n(v_lay_240, 0, 7), v_t_2417, v_t_2421});
}
V g_heff_2ecompile_2ecpr_2etupleOfCon_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2etupleOfCon(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2etupleOfCon_lam0(V self, V *args) {
  V v_i_248 = args[0];
  V v_k_249 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_es_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = (g_heff_2ecompile_2ecpr_2efieldAt_24cpr(v_i_248, heff_get_n(v_c_241, 3, 4), v_es_242));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_k_249);
      V v_x_2414 = v_field_2412;
      return v_x_2414;
    } else {
      heff_drop(v_field_2412);
      switch (heff_tag_of(v_k_249)) {
      case TAG_RepV: {
        return heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_RepFix: {
        V v_w_2415 = heff_field(v_k_249, 0);
        heff_take_n(v_k_249, 1ULL, 1);
        return heff_tag_n(TAG_EFixed, 2, (V[]){v_w_2415, MK_INT(0LL)});
      }
      case TAG_RepF64: {
        return heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64((0.0))});
      }
      case TAG_RepInt: {
        return heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
      }
      default: return heff_nomatch(v_k_249);
      }
    }
  }
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundAll_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eboundAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eboundAll_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eboundAll(V v_b_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam0, 1, 1, (V[]){v_b_240});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_es_244 = heff_field(v_x2_241, 1);
    V v_m_245 = (g_heff_2ecompile_2ecpr_2eboundOne(v_b_240, heff_dup(v_e_243)));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam1, 1, 2, (V[]){v_m_245, heff_dup(v_es_244)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2eboundAll_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2eboundAll(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_b_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_240, v_n_242});
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_es_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_es_244; V r_ = (g_heff_2ecompile_2ecpr_2eboundAll(a_0, a_1)); heff_drop(v_es_244); r_; });
    V f_ = v_t_2410;
    args[0] = v_n_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOut_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOut(V v_lay_240, V v_c_241, V v_es_242) {
top: ;
  V v_t_243 = heff_rec_n(2, shape_lets__vals, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_m_244 = (g_heff_2ecompile_2ecpr_2eboundAll(v_t_243, v_es_242));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOut_lam0, 1, 3, (V[]){v_m_244, v_lay_240, v_c_241});
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2ebuiltOut(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_e_249 = (g_heff_2ecompile_2ecpr_2etupleOfCon(v_lay_240, v_c_241, heff_take_field(v_x_247, 1)));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_247, 0, 2)));
    V v_x_2411 = ({ V a_0 = v_e_249; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1016340684x604821087(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2411, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_str1, 0, "");
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOf_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOf(V v_lay_240, V v_vs_241, V v_c_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_lay_240, 3));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_2416 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_lam0, 2, 2, (V[]){heff_dup(v_lay_240), heff_dup(v_vs_241)}), heff_get_n(v_lay_240, 4, 7), heff_take_field(v_c_242, 3)));
    return heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2416, heff_get_n(v_c_242, 2, 4)});
  } else {
    heff_drop(v_t_243);
    V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_lam1, 1, 2, (V[]){v_lay_240, heff_dup(v_vs_241)}), heff_take_field(v_c_242, 3)));
    return heff_tag_n(TAG_ETag, 3, (V[]){heff_dup(heff_rfield(v_c_242, 0)), v_t_2428, heff_get_n(v_c_242, 2, 4)});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2ebuiltOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam0(V self, V *args) {
  V v_l_244 = args[0];
  V v_i_245 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_get_n(v_lay_240, 1, 7);
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_247 = heff_intAdd(v_i_245, MK_INT(1LL));
  } else {
    heff_drop(v_t_246);
    v_t_247 = v_i_245;
  }
  HeffT3 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  V v_t_2415;
  {
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2410;
      V v_x12_2414 = v_field_2411;
      heff_drop(v_x12_2414);
      v_t_2415 = v_x_2413;
    } else {
      heff_drop(v_field_2410);
      heff_drop(v_field_2411);
      v_t_2415 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_l_244, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2415})});
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam1(V self, V *args) {
  V v_i_2417 = args[0];
  V v_lay_240 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_get_n(v_lay_240, 1, 7);
  V v_t_2419;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    v_t_2419 = heff_intAdd(v_i_2417, MK_INT(1LL));
  } else {
    heff_drop(v_t_2418);
    v_t_2419 = v_i_2417;
  }
  HeffT3 v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  V v_t_2427;
  {
    V v_field_2422 = v_t_2420.f[1];
    V v_field_2423 = v_t_2420.f[2];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_x_2425 = v_field_2422;
      V v_x12_2426 = v_field_2423;
      heff_drop(v_x12_2426);
      v_t_2427 = v_x_2425;
    } else {
      heff_drop(v_field_2422);
      heff_drop(v_field_2423);
      v_t_2427 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_str1);
    }
  }
  return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2427});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str1, 4, "True");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str2, 5, "False");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str3, 7, "int64Eq");
Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V v_lit_240, V v_lit_241, V v_vs_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_243, 0);
    V v_x32_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_243_24Cons, 2);
      return (g_heff_2ecompile_2ecpr_2ebuiltOf(v_lit_240, v_lit_241, v_c_244));
    }
    case TAG_Cons: {
      V v_yes_248 = (g_heff_2ecompile_2ecpr_2ebuiltOf(heff_dup(v_lit_240), v_lit_241, heff_dup(v_c_244)));
      V v_no_249 = (g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(v_lit_240, v_lit_241, v_vs_242, v_x32_245));
      V v_t_2412;
      switch (heff_tag_of(v_vs_242)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_vs_242, 0);
        v_t_2412 = heff_dup(v_x_2410);
        break;
      }
      default: heff_nomatch(v_vs_242);
      }
      V v_t_2413 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_get_n(v_c_244, 1, 4)});
      V v_t_2414 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2412}), v_t_2414});
      V v_t_2416 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str1), NTAG(TAG_Nil), v_yes_248});
      V v_t_2417 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str2), NTAG(TAG_Nil), v_no_249});
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str3), v_t_2415}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2418})});
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}