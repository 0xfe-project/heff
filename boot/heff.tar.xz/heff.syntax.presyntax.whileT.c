// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EVar 52881
#define LBL_depth 296830685
#define LBL_head 9693863
#define LBL_muts 9858798
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr_str0, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr_str1, 1, "#");

HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr(V v_sp_240, V v_cx_241) {
top: ;
  V v_muts_242 = heff_take_field(v_cx_241, 1);
  V v_depth_243 = heff_get_n(v_cx_241, 4, 6);
  V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr_str1), v_t_244));
  V v_f_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_245}), v_sp_240});
  V v_f_247 = v_muts_242;
  V v_f_248 = v_depth_243;
  return ((HeffT4){{v_f_246, v_f_247, NTAG(TAG_True), v_f_248}});
}
Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(V v_sp_240, V v_cx_241) {
top: ;
  HeffT4 v_t_242 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr(v_sp_240, v_cx_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    return heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_field_243, v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr_str0, 5, "after");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr_str1, 1, "#");

HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr(V v_sp_240, V v_cx_241) {
top: ;
  V v_muts_242 = heff_take_field(v_cx_241, 1);
  V v_depth_243 = heff_get_n(v_cx_241, 4, 6);
  V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr_str1), v_t_244));
  V v_f_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_245}), v_sp_240});
  V v_f_247 = v_muts_242;
  V v_f_248 = v_depth_243;
  return ((HeffT4){{v_f_246, v_f_247, NTAG(TAG_True), v_f_248}});
}
Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241(V v_sp_240, V v_cx_241) {
top: ;
  HeffT4 v_t_242 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr(v_sp_240, v_cx_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    return heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_field_243, v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241(a[0], a[1]);
}