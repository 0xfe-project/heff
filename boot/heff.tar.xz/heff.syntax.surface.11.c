// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclTest 38719
#define TAG_DeclWatch 51419
#define TAG_Doc 16324
#define TAG_ETag 50948
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eabGo(V, V);
V g_heff_2esyntax_2esurface_2eabGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabGo_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDeclDone(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclDone_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclDone_clo;
V g_heff_2esyntax_2esurface_2efixDeclOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo;
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_clo;
V g_heff_2esyntax_2esurface_2erestOfDecl(V, V, V);
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo;
HeffT2 g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etakeSyms(V);
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_clo;
V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V, V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(V, V, V, V, V);
V g_list_2efoldl_24f158727028x1528233175(V, V, V);
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a);
extern Clo g_list_2efoldl_24f158727028x1528233175_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;

HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V v_f_240, V v_xs_241, V v_st_242) {
top: ;
  V v_m_243 = (g_prelude_2etraverse_24s499544530x2060473942(v_f_240, v_xs_241));
  V v_x1_244 = heff_tr(heff_call(v_m_243, 1, (V[]){heff_dup(v_st_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Left = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_st_242, 8);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_245_24Left, TAG_Left, 1, (V[]){v_e_247}), v_st_246}});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_f_249 = ({ V rv_1 = heff_get_n(v_st_242, 1, 8); V rr_ = heff_rec_reuse_nf(v_st_246, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Right, 1, (V[]){v_x_248}), v_f_249}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
  }
}
Clo g_heff_2esyntax_2esurface_2edotAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edotAt_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edotAt(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return heff_strLength_lent(v_s_240, 0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return heff_box_word(v_i_241);
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edotAt(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econL(V v_r_240, V v_c_241, V v_args_242) {
top: ;
  V v_m_243 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_args_242));
  return heff_clo_n(g_heff_2esyntax_2esurface_2econL_lam0, 1, 2, (V[]){v_m_243, v_c_241});
}
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_rec(v_c_241, 9);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x11_246_24Right, TAG_ETag, 1, (V[]){heff_dup(heff_rfield(v_c_241, 1))});
      V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_241, 3), heff_get_n(v_c_241, 4, 9)});
      V v_x_2412 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2411}), v_x_249));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2412}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str0, 45, "an integer's segment is of 1 to 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str1, 45, "an integer's segment is of 1 to 64 bits, not ");
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V v_inPat_240, V v_sp_241, V v_v_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0_clo);
  }
  case TAG_Just: {
    V v_n_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    if (heff_intLt_c_lent(v_n_246, MK_INT(1LL), 2)) {
      heff_drop(v_v_242);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1, 1, 2, (V[]){v_n_246, v_sp_241});
    } else {
      if (heff_intLt_c_lent(MK_INT(64LL), v_n_246, 1)) {
        heff_drop(v_v_242);
        return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam2, 1, 2, (V[]){v_n_246, v_sp_241});
      } else {
        HEFF_LAST return g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(v_inPat_240, v_sp_241, v_v_242, v_n_246);
      }
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str0), heff_intShow(v_n_246));
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_249, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2410}), v_st_248});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam2(V self, V *args) {
  V v_st_2412 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str1), heff_intShow(v_n_246));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2413, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2414}), v_st_2412});
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0, 1, 1, (V[]){v_st_242});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x5_243, 0);
    V v_rest_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_m_247 = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(heff_dup(v_fix_240), v_lenient_241, v_st_242, v_r_245));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1, 1, 4, (V[]){v_m_247, v_fix_240, heff_dup(v_lenient_241), v_rest_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_st_242}), v_st_244});
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_fix_240 = heff_env(self)[1];
  V v_lenient_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop(v_rest_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      V v_t_2414 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_x_2413; V a_3 = v_rest_246; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
      V f_ = v_t_2414;
      args[0] = v_st_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(V v_e0_240, V v_rest_241, V v_st_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_242, 5));
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 6));
  V v_m_245 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_t_243), v_t_244, heff_dup(v_rest_241)));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_e0_240);
      heff_drop(v_rest_241);
      heff_drop(v_t_243);
      heff_drop(v_t_244);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      heff_take_n(v_x11_247, 0ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e0_240), NTAG(TAG_Nil)});
      V v_t_2412 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_2411});
      V v_m_2413 = ({ V a_0 = v_t_243; V a_1 = v_t_244; V a_2 = v_t_2412; V a_3 = v_rest_241; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a_0, a_1, a_2, a_3)); heff_drop(v_t_244); r_; });
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_e0_240);
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_st_2419 = (g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(v_x_2418));
          V v_t_2420 = heff_get_n(v_st_2419, 1, 2);
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            v_t_2423 = v_e0_240;
            break;
          }
          case TAG_Cons: {
            V v_x_2421 = heff_field(v_t_2420, 0);
            heff_take_n(v_t_2420, 1ULL, 2);
            heff_drop(v_e0_240);
            v_t_2423 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2423}), v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erestOfDecl_str0, 3, "eof");
Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erestOfDecl_entry, 3, 0};

V g_heff_2esyntax_2esurface_2erestOfDecl(V v_ts_240, V v_j_241, V v_acc_242) {
top: ;
  V v_t_246;
  if (heff_intLe_c_lent(MK_INT(0LL), v_j_241, 1)) {
    if (heff_intLt_c(heff_dup(v_j_241), heff_arrayLength_lent(v_ts_240, 0))) {
      V v_t_245 = heff_arrayIndex_lent(v_ts_240, v_j_241, 0);
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      v_t_246 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_246 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_j_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Just: {
    V v_t_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2erestOfDecl_str0))) {
      heff_drop(v_j_241);
      heff_drop_rec(v_t_247, 7);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    } else {
      V v_t_249 = heff_dup(heff_rfield(v_t_247, 6));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        if (heff_intEq_c(heff_dup(heff_rfield(v_t_247, 5)), MK_INT(0LL))) {
          heff_drop(v_j_241);
          heff_drop_rec(v_t_247, 7);
          return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
        } else {
          V t_0 = v_ts_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
          v_ts_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_t_249);
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
        v_ts_240 = t_0;
        v_j_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2erestOfDecl(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etakeSyms_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2etakeSyms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakeSyms_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakeSyms(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_u_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_241, 0)), ((V)&g_heff_2esyntax_2esurface_2etakeSyms_str0))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_u_241, heff_hole()});
      V v_u_245 = (g_heff_2esyntax_2esurface_2etakeSyms_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_u_241, 7);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etakeSyms(a[0]);
}
Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDeclOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDeclOf(V v_ts_240, V v_box_24k_241, V v_t_242) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  V v_rest_243 = (g_heff_2esyntax_2esurface_2erestOfDecl(v_ts_240, heff_box_word((v_k_241 + ((int64_t)1ULL))), NTAG(TAG_Nil)));
  V v_t_244 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_rest_243)));
  V v_t_245 = heff_rec_n(4, shape_above__below__loosest__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_rest_243));
  V v_t_247 = (g_heff_2esyntax_2esurface_2edropN(v_t_246, heff_dup(v_rest_243)));
  V v_t_248 = (g_heff_2esyntax_2esurface_2eabGo(v_t_245, v_t_247));
  return ({ V a_0 = v_t_242; V a_1 = v_rest_243; V a_2 = v_t_244; V a_3 = v_t_248; V r_ = (g_heff_2esyntax_2esurface_2efixDeclDone(a_0, a_1, a_2, a_3)); heff_drop(v_rest_243); r_; });
}
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efixDeclOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr_str0, 7, "doctest");

HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V v_d_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    V v_ru_24d_240_24DImport = heff_take_reuse_n(v_d_240, 0ULL, 1);
    V v_t_243 = heff_tag_at_n(v_ru_24d_240_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_z_241}});
  }
  case TAG_DFixity: {
    heff_take_n(v_d_240, 0ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_246, v_z_241}});
  }
  case TAG_DSig: {
    V v_names_247 = heff_field(v_d_240, 0);
    V v_ty_249 = heff_field(v_d_240, 2);
    heff_take_n(v_d_240, 5ULL, 3);
    V v_t_2412;
    switch (heff_tag_of(v_names_247)) {
    case TAG_Nil: {
      v_t_2412 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_t_2410 = heff_dup(heff_field(v_names_247, 0));
      v_t_2412 = heff_get_n(v_t_2410, 3, 9);
      break;
    }
    default: heff_nomatch(v_names_247);
    }
    return ({ V a_0 = NTAG(TAG_AsDefinition); V a_1 = v_t_2412; V a_2 = v_names_247; V a_3 = v_ty_249; V a_4 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_247); r_; });
  }
  case TAG_DInstance: {
    V v_kw_2413 = heff_field(v_d_240, 0);
    V v_names_2414 = heff_field(v_d_240, 1);
    V v_ty_2416 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return ({ V a_0 = NTAG(TAG_AsInstance); V a_1 = heff_get_n(v_kw_2413, 3, 9); V a_2 = v_names_2414; V a_3 = v_ty_2416; V a_4 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_2414); r_; });
  }
  case TAG_DEqn: {
    V v_names_2417 = heff_field(v_d_240, 0);
    V v_pats_2418 = heff_field(v_d_240, 1);
    V v_rhs_2420 = heff_field(v_d_240, 3);
    V v_w_2421 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 27ULL, 5);
    return ({ V a_0 = v_names_2417; V a_1 = v_pats_2418; V a_2 = v_rhs_2420; V a_3 = v_w_2421; V a_4 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_names_2417); heff_drop(v_w_2421); r_; });
  }
  case TAG_DData: {
    V v_kw_2422 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2423 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2424 = heff_dup(heff_field(v_d_240, 2));
    V v_universe_2425 = heff_dup(heff_field(v_d_240, 3));
    V v_alts_2426 = heff_dup(heff_field(v_d_240, 4));
    return ({ V a_0 = v_d_240; V a_1 = v_kw_2422; V a_2 = v_name_2423; V a_3 = v_params_2424; V a_4 = v_universe_2425; V a_5 = v_alts_2426; V a_6 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_universe_2425); heff_drop(v_alts_2426); r_; });
  }
  case TAG_DType: {
    V v_kw_2427 = heff_field(v_d_240, 0);
    V v_name_2428 = heff_field(v_d_240, 1);
    V v_params_2429 = heff_field(v_d_240, 2);
    V v_body_2431 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(v_kw_2427, v_name_2428, v_params_2429, v_body_2431, v_z_241));
  }
  case TAG_DTheory: {
    V v_kw_2432 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2433 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2434 = heff_dup(heff_field(v_d_240, 2));
    V v_fields_2436 = heff_dup(heff_field(v_d_240, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(v_d_240, v_kw_2432, v_name_2433, v_params_2434, v_fields_2436, v_z_241));
  }
  case TAG_DPrimitive: {
    V v_kw_2437 = heff_field(v_d_240, 0);
    V v_x_2438 = heff_field(v_d_240, 1);
    V v_ty_2440 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(v_kw_2437, v_x_2438, v_ty_2440, v_z_241));
  }
  case TAG_DTest: {
    V v_kw_2441 = heff_field(v_d_240, 0);
    V v_x_2442 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DTest = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2442, 3), heff_dup(heff_rfield(v_x_2442, 4))});
    V v_t_2444 = heff_tag_at_n(v_ru_24d_240_24DTest, TAG_DeclTest, 2, (V[]){heff_dup(heff_rfield(v_x_2442, 1)), v_t_2443});
    V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2441, 3, 9), heff_get_n(v_x_2442, 4, 9)});
    V v_t_2446 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
    V v_f_2448 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2447});
    return ((HeffT2){{v_f_2448, v_z_241}});
  }
  case TAG_DWatch: {
    V v_w_2449 = heff_field(v_d_240, 0);
    V v_e_2450 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DWatch = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_x1_2451 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_2450), v_z_241));
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_MkPair: {
      V v_x11_2452 = heff_field(v_x1_2451, 0);
      V v_st_2453 = heff_field(v_x1_2451, 1);
      V v_ru_24x1_2451_24MkPair = heff_take_reuse_n(v_x1_2451, 3ULL, 2);
      switch (heff_tag_of(v_x11_2452)) {
      case TAG_Left: {
        V v_e_2454 = heff_field(v_x11_2452, 0);
        V v_ru_24x11_2452_24Left = heff_take_reuse_n(v_x11_2452, 1ULL, 1);
        heff_drop_rec(v_w_2449, 9);
        heff_drop(v_e_2450);
        heff_drop_cell(v_ru_24d_240_24DWatch, 2);
        heff_drop_cell(v_ru_24x1_2451_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2452_24Left, TAG_Left, 1, (V[]){v_e_2454}), v_st_2453}});
      }
      case TAG_Right: {
        V v_x_2455 = heff_field(v_x11_2452, 0);
        V v_ru_24x11_2452_24Right = heff_take_reuse_n(v_x11_2452, 1ULL, 1);
        V v_t_2456 = (g_heff_2esyntax_2ecst_2elastE(v_e_2450));
        V v_e_2457 = heff_get_n(v_t_2456, 4, 9);
        V v_t_2458 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_w_2449, 3), v_e_2457});
        V v_d_2459 = heff_tag_at_n(v_ru_24d_240_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_2455}), v_t_2458});
        V v_t_2461;
        if (heff_strEq_c(heff_get_n(v_w_2449, 0, 9), ((V)&g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr_str0))) {
          v_t_2461 = heff_tag_n(TAG_Doc, 1, (V[]){v_d_2459});
        } else {
          v_t_2461 = heff_tag_n(TAG_Whole, 1, (V[]){v_d_2459});
        }
        V v_x_2462 = heff_tag_at_n(v_ru_24x1_2451_24MkPair, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2452_24Right, TAG_Right, 1, (V[]){v_x_2462}), v_st_2453}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2452)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2451)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_d_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(a[0], a[1], a[2]);
}