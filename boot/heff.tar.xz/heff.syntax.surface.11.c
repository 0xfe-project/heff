// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclTest 38719
#define TAG_DeclWatch 51419
#define TAG_Doc 16324
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_Left 13886
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sig 30557
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_head 9693863
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eabGo(V, V);
V g_heff_2esyntax_2esurface_2eabGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabGo_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2earrowNames_24tok1(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDeclDone(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclDone_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclDone_clo;
V g_heff_2esyntax_2esurface_2efixDeclOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo;
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo;
V g_heff_2esyntax_2esurface_2elamBody(V, V);
V g_heff_2esyntax_2esurface_2elamBody_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBody_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2epickSig_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_clo;
V g_heff_2esyntax_2esurface_2erestOfDecl(V, V, V);
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etakeSyms(V);
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_clo;
V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V, V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(V, V, V, V, V);
V g_list_2efoldl_24f158727028x1528233175(V, V, V);
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a);
extern Clo g_list_2efoldl_24f158727028x1528233175_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;

HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V v_f_240, V v_xs_241, V v_st_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_242, 1));
  V v_m_244 = (g_prelude_2etraverse_24s499544530x2060473942(v_f_240, v_xs_241));
  V v_x1_245 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Left = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      heff_drop(v_t_243);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_246_24Left, TAG_Left, 1, (V[]){v_e_248}), v_st_247}});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_f_2410 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_nf(v_st_247, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_x_249}), v_f_2410}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
  }
}
Clo g_heff_2esyntax_2esurface_2edotAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edotAt_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edotAt(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return heff_strLength_lent(v_s_240, 0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return heff_box_word(v_i_241);
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edotAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epickSig_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2epickSig_24cpr_str1, 0, "");

HeffT2 g_heff_2esyntax_2esurface_2epickSig_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_it_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      V v_f_245 = heff_dup(heff_field(v_it_242, 1));
      v_t_2414 = v_f_245;
      break;
    }
    case TAG_Eqn: {
      V v_f_249 = heff_dup(heff_field(v_it_242, 0));
      v_t_2414 = v_f_249;
      break;
    }
    case TAG_Whole: {
      v_t_2414 = ((V)&g_heff_2esyntax_2esurface_2epickSig_24cpr_str0);
      break;
    }
    case TAG_Doc: {
      v_t_2414 = ((V)&g_heff_2esyntax_2esurface_2epickSig_24cpr_str1);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if (heff_strEq_c_lent(v_t_2414, v_f_240, 1)) {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_it_242, v_rest_243})}});
    } else {
      HeffT2 v_t_2415 = (g_heff_2esyntax_2esurface_2epickSig_24cpr(v_f_240, v_rest_243));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x21_2418 = v_field_2417;
          switch (heff_tag_of(v_x21_2418)) {
          case TAG_MkPair: {
            V v_s_2419 = heff_field(v_x21_2418, 0);
            V v_more_2420 = heff_field(v_x21_2418, 1);
            V v_ru_24x21_2418_24MkPair = heff_take_reuse_n(v_x21_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x21_2418_24MkPair, TAG_MkPair, 2, (V[]){v_s_2419, heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_it_242, v_more_2420})});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x21_2418)}});
          }
        } else {
          heff_drop(v_it_242);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_field_2417);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econL(V v_r_240, V v_c_241, V v_args_242) {
top: ;
  V v_text_243 = heff_take_field(v_c_241, 1);
  V v_start_244 = heff_take_field(v_c_241, 3);
  V v_end_245 = heff_get_n(v_c_241, 4, 9);
  V v_m_246 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_args_242));
  return heff_clo_n(g_heff_2esyntax_2esurface_2econL_lam0, 1, 4, (V[]){v_m_246, v_text_243, v_start_244, v_end_245});
}
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_start_244 = heff_env(self)[2];
  V v_end_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_text_243);
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Right, TAG_ETag, 1, (V[]){v_text_243}), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245})});
      V v_x_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2413, v_x_2412));
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2414}), v_st_2410});
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(v_z_240, v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2esurface_2elamBody(heff_dup(v_x_242), heff_dup(v_a_244)));
    V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_ELam, 2, (V[]){heff_dup(heff_rfield(v_x_242, 0)), v_t_245});
    V v_t_247 = heff_get_n(heff_get_n(v_x_242, 1, 3), 0, 2);
    V v_t_2410;
    switch (heff_tag_of(v_a_244)) {
    case TAG_At: {
      V v_a_249 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 2ULL, 2);
      v_t_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_t_2411 = ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_t_2410, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2411});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str0, 45, "an integer's segment is of 1 to 64 bits, not ");
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V v_inPat_240, V v_sp_241, V v_v_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0_clo);
  }
  case TAG_Just: {
    V v_n_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    if ((heff_intLt_c_lent(v_n_246, MK_INT(1LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_246, 1))) {
      heff_drop(v_v_242);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1, 1, 2, (V[]){v_n_246, v_sp_241});
    } else {
      HEFF_LAST return g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(v_inPat_240, v_sp_241, v_v_242, v_n_246);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str0), heff_intShow(v_n_246));
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_248, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0, 1, 1, (V[]){v_st_242});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x5_243, 0);
    V v_rest_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_m_247 = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(heff_dup(v_fix_240), v_lenient_241, v_st_242, v_r_245));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1, 1, 4, (V[]){v_m_247, v_fix_240, heff_dup(v_lenient_241), v_rest_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_st_242}), v_st_244});
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_fix_240 = heff_env(self)[1];
  V v_lenient_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop(v_rest_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      V v_t_2414 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_x_2413; V a_3 = v_rest_246; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
      V f_ = v_t_2414;
      args[0] = v_st_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(V v_e0_240, V v_rest_241, V v_st_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_242, 5));
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 6));
  V v_m_245 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_t_243), v_t_244, heff_dup(v_rest_241)));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_e0_240);
      heff_drop(v_rest_241);
      heff_drop(v_t_243);
      heff_drop(v_t_244);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      heff_take_n(v_x11_247, 0ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e0_240), NTAG(TAG_Nil)});
      V v_t_2412 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_2411});
      V v_m_2413 = ({ V a_0 = v_t_243; V a_1 = v_t_244; V a_2 = v_t_2412; V a_3 = v_rest_241; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a_0, a_1, a_2, a_3)); heff_drop(v_t_244); r_; });
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_e0_240);
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_st_2419 = (g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(v_x_2418));
          V v_t_2420 = heff_get_n(v_st_2419, 1, 2);
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            v_t_2423 = v_e0_240;
            break;
          }
          case TAG_Cons: {
            V v_x_2421 = heff_field(v_t_2420, 0);
            heff_take_n(v_t_2420, 1ULL, 2);
            heff_drop(v_e0_240);
            v_t_2423 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2423}), v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erestOfDecl_str0, 3, "eof");
Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erestOfDecl_entry, 3, 0};

V g_heff_2esyntax_2esurface_2erestOfDecl(V v_ts_240, V v_box_24j_241, V v_acc_242) {
  int64_t v_j_241 = heff_unbox_word(v_box_24j_241);
top: ;
  if (((((int64_t)0ULL) <= v_j_241) && (v_j_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_243 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_j_241), 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2erestOfDecl_str0)) || ((heff_dup(heff_rfield(v_t_243, 6)) == NTAG(TAG_True)) && heff_intEq_c(heff_dup(heff_rfield(v_t_243, 5)), MK_INT(0LL))))) {
      heff_drop_rec(v_t_243, 7);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    } else {
      V t_0 = v_ts_240;
      int64_t t_1 = (v_j_241 + ((int64_t)1ULL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_acc_242});
      v_ts_240 = t_0;
      v_j_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
  } else {
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
}
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2erestOfDecl(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etakeSyms_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2etakeSyms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakeSyms_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakeSyms(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_u_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_241, 0)), ((V)&g_heff_2esyntax_2esurface_2etakeSyms_str0))) {
      V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_u_241, heff_hole()});
      V v_u_244 = (g_heff_2esyntax_2esurface_2etakeSyms_24dps(v_rest_242, heff_dup(v_cell_243)));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop_rec(v_u_241, 7);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etakeSyms(a[0]);
}
Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDeclOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDeclOf(V v_ts_240, V v_box_24k_241, V v_t_242) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  V v_rest_243 = (g_heff_2esyntax_2esurface_2erestOfDecl(v_ts_240, heff_box_word((v_k_241 + ((int64_t)1ULL))), NTAG(TAG_Nil)));
  V v_t_244 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_rest_243)));
  V v_t_245 = heff_rec_n(4, shape_above__below__loosest__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_rest_243));
  V v_t_247 = (g_heff_2esyntax_2esurface_2edropN(v_t_246, heff_dup(v_rest_243)));
  V v_t_248 = (g_heff_2esyntax_2esurface_2eabGo(v_t_245, v_t_247));
  return ({ V a_0 = v_t_242; V a_1 = v_rest_243; V a_2 = v_t_244; V a_3 = v_t_248; V r_ = (g_heff_2esyntax_2esurface_2efixDeclDone(a_0, a_1, a_2, a_3)); heff_drop(v_rest_243); r_; });
}
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efixDeclOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr_str0, 7, "doctest");

HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V v_d_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    V v_ru_24d_240_24DImport = heff_take_reuse_n(v_d_240, 0ULL, 1);
    V v_t_243 = heff_tag_at_n(v_ru_24d_240_24DImport, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_z_241}});
  }
  case TAG_DFixity: {
    heff_take_n(v_d_240, 0ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_246, v_z_241}});
  }
  case TAG_DSig: {
    V v_names_247 = heff_field(v_d_240, 0);
    V v_ty_2410 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 9ULL, 4);
    V v_t_2415;
    switch (heff_tag_of(v_names_247)) {
    case TAG_Nil: {
      v_t_2415 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_dup(heff_field(v_names_247, 0));
      switch (heff_tag_of(v_x_2411)) {
      case TAG_Nil: {
        v_t_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        V v_t_2413 = heff_field(v_x_2411, 0);
        heff_take_n(v_x_2411, 1ULL, 2);
        v_t_2415 = heff_get_n(v_t_2413, 3, 9);
        break;
      }
      default: heff_nomatch(v_x_2411);
      }
      break;
    }
    default: heff_nomatch(v_names_247);
    }
    return (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(NTAG(TAG_AsDefinition), v_t_2415, v_names_247, v_ty_2410, v_z_241));
  }
  case TAG_DInstance: {
    V v_kw_2416 = heff_field(v_d_240, 0);
    V v_names_2417 = heff_field(v_d_240, 1);
    V v_ty_2419 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_names_2417, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_24cpr(NTAG(TAG_AsInstance), heff_get_n(v_kw_2416, 3, 9), v_t_2420, v_ty_2419, v_z_241));
  }
  case TAG_DEqn: {
    V v_names_2421 = heff_field(v_d_240, 0);
    V v_pats_2422 = heff_field(v_d_240, 1);
    V v_rhs_2424 = heff_field(v_d_240, 3);
    V v_w_2425 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 27ULL, 5);
    return ({ V a_0 = v_names_2421; V a_1 = v_pats_2422; V a_2 = v_rhs_2424; V a_3 = v_w_2425; V a_4 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_2425); r_; });
  }
  case TAG_DData: {
    V v_kw_2426 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2427 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2428 = heff_dup(heff_field(v_d_240, 2));
    V v_universe_2429 = heff_dup(heff_field(v_d_240, 3));
    V v_alts_2430 = heff_dup(heff_field(v_d_240, 4));
    return ({ V a_0 = v_d_240; V a_1 = v_kw_2426; V a_2 = v_name_2427; V a_3 = v_params_2428; V a_4 = v_universe_2429; V a_5 = v_alts_2430; V a_6 = v_z_241; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_alts_2430); r_; });
  }
  case TAG_DType: {
    V v_kw_2431 = heff_field(v_d_240, 0);
    V v_name_2432 = heff_field(v_d_240, 1);
    V v_params_2433 = heff_field(v_d_240, 2);
    V v_body_2435 = heff_field(v_d_240, 4);
    heff_take_n(v_d_240, 23ULL, 5);
    return (g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(v_kw_2431, v_name_2432, v_params_2433, v_body_2435, v_z_241));
  }
  case TAG_DTheory: {
    V v_kw_2436 = heff_dup(heff_field(v_d_240, 0));
    V v_name_2437 = heff_dup(heff_field(v_d_240, 1));
    V v_params_2438 = heff_dup(heff_field(v_d_240, 2));
    V v_fields_2440 = heff_dup(heff_field(v_d_240, 4));
    return (g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(v_d_240, v_kw_2436, v_name_2437, v_params_2438, v_fields_2440, v_z_241));
  }
  case TAG_DMutual: {
    V v_kw_2441 = heff_field(v_d_240, 0);
    V v_ds_2442 = heff_field(v_d_240, 1);
    heff_take_n(v_d_240, 3ULL, 2);
    return (g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(v_kw_2441, v_ds_2442, v_z_241));
  }
  case TAG_DPrimitive: {
    V v_kw_2443 = heff_field(v_d_240, 0);
    V v_x_2444 = heff_field(v_d_240, 1);
    V v_ty_2446 = heff_field(v_d_240, 3);
    heff_take_n(v_d_240, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eprimitiveL_24s507592473x2101780878_24cpr(v_kw_2443, v_x_2444, v_ty_2446, v_z_241));
  }
  case TAG_DTest: {
    V v_kw_2447 = heff_field(v_d_240, 0);
    V v_x_2448 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DTest = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_text_2449 = heff_take_field(v_x_2448, 1);
    V v_start_2450 = heff_take_field(v_x_2448, 3);
    V v_end_2451 = heff_get_n(v_x_2448, 4, 9);
    V v_t_2452 = heff_tag_at_n(v_ru_24d_240_24DTest, TAG_DeclTest, 2, (V[]){v_text_2449, heff_rec_n(2, shape_start__end, (V[]){v_start_2450, heff_dup(v_end_2451)})});
    V v_t_2453 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_2447, 3, 9), v_end_2451});
    V v_t_2454 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2452, v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
    V v_f_2456 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2455});
    return ((HeffT2){{v_f_2456, v_z_241}});
  }
  case TAG_DWatch: {
    V v_w_2457 = heff_field(v_d_240, 0);
    V v_e_2458 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24DWatch = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_start_2459 = heff_take_field(v_w_2457, 3);
    V v_kind_2460 = heff_get_n(v_w_2457, 0, 9);
    V v_x1_2461 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_2458), v_z_241));
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_MkPair: {
      V v_x11_2462 = heff_field(v_x1_2461, 0);
      V v_st_2463 = heff_field(v_x1_2461, 1);
      V v_ru_24x1_2461_24MkPair = heff_take_reuse_n(v_x1_2461, 3ULL, 2);
      switch (heff_tag_of(v_x11_2462)) {
      case TAG_Left: {
        V v_e_2464 = heff_field(v_x11_2462, 0);
        V v_ru_24x11_2462_24Left = heff_take_reuse_n(v_x11_2462, 1ULL, 1);
        heff_drop(v_e_2458);
        heff_drop_cell(v_ru_24d_240_24DWatch, 2);
        heff_drop(v_start_2459);
        heff_drop(v_kind_2460);
        heff_drop_cell(v_ru_24x1_2461_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2462_24Left, TAG_Left, 1, (V[]){v_e_2464}), v_st_2463}});
      }
      case TAG_Right: {
        V v_x_2465 = heff_field(v_x11_2462, 0);
        V v_ru_24x11_2462_24Right = heff_take_reuse_n(v_x11_2462, 1ULL, 1);
        V v_t_2466 = (g_heff_2esyntax_2ecst_2elastE(v_e_2458));
        V v_e_2467 = heff_get_n(v_t_2466, 4, 9);
        V v_d_2468 = heff_tag_at_n(v_ru_24d_240_24DWatch, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_x_2465}), heff_rec_n(2, shape_start__end, (V[]){v_start_2459, v_e_2467})});
        V v_t_2469;
        if (heff_strEq_c(v_kind_2460, ((V)&g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr_str0))) {
          v_t_2469 = heff_tag_n(TAG_Doc, 1, (V[]){v_d_2468});
        } else {
          v_t_2469 = heff_tag_n(TAG_Whole, 1, (V[]){v_d_2468});
        }
        V v_x_2470 = heff_tag_at_n(v_ru_24x1_2461_24MkPair, TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2462_24Right, TAG_Right, 1, (V[]){v_x_2470}), v_st_2463}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2462)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2461)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_d_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_24tok1_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
V g_heff_2esyntax_2esurface_2earrowNames_24tok1_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2earrowNames_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowNames_24tok1_entry, 7, 0};

V g_heff_2esyntax_2esurface_2earrowNames_24tok1(V v_tok_240, V v_rhs_241, V v_g_242, V v_ty_243, V v_braces_244, V v_dflt_245, V v_orig_246) {
top: ;
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_242)));
  V v_t_248 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_242)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_247, 0, 2), heff_get_n(v_t_248, 1, 2)});
  V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a_0)); heff_drop_tag(v_t_249, 2); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_orig_246);
    heff_drop(v_t_2410);
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_242)));
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_242));
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2411, 0, 2), heff_get_n(v_t_2412, 1, 2)});
    return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2earrowNames_24tok1_lam0, 2, 3, (V[]){v_braces_244, v_ty_243, v_dflt_245}); V a_1 = v_rhs_241; V a_2 = v_t_2413; V r_ = (g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop_tag(v_t_2413, 2); r_; });
  } else {
    heff_drop(v_g_242);
    heff_drop(v_ty_243);
    heff_drop(v_dflt_245);
    heff_drop(v_t_2410);
    switch (heff_tag_of(v_braces_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_tok_240, 1);
      V v_t_2485 = (g_heff_2esyntax_2esurface_2eplainBinder(heff_dup(v_orig_246)));
      V v_t_2488;
      switch (heff_tag_of(v_orig_246)) {
      case TAG_At: {
        V v_s_2487 = heff_field(v_orig_246, 1);
        heff_take_n(v_orig_246, 2ULL, 2);
        v_t_2488 = v_s_2487;
        break;
      }
      default: heff_nomatch(v_orig_246);
      }
      V v_t_2491;
      switch (heff_tag_of(v_rhs_241)) {
      case TAG_At: {
        V v_s_2490 = heff_dup(heff_field(v_rhs_241, 1));
        v_t_2491 = v_s_2490;
        break;
      }
      default: heff_nomatch(v_rhs_241);
      }
      V v_t_2492 = ({ V rv_1 = heff_get_n(v_t_2491, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2488, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EPi, 2, (V[]){v_t_2485, v_rhs_241}), v_t_2492});
    }
    case TAG_Just: {
      V v_bsp_2493 = heff_field(v_braces_244, 0);
      V v_ru_24braces_244_24Just = heff_take_reuse_n(v_braces_244, 1ULL, 1);
      heff_drop(v_orig_246);
      V v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_24tok1_str0)}), heff_dup(v_bsp_2493)});
      V v_t_2495 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24braces_244_24Just, TAG_PiAnon, 1, (V[]){v_t_2494}), heff_dup(v_rhs_241)});
      V v_t_2498;
      switch (heff_tag_of(v_rhs_241)) {
      case TAG_At: {
        V v_s_2497 = heff_field(v_rhs_241, 1);
        heff_take_n(v_rhs_241, 2ULL, 2);
        v_t_2498 = v_s_2497;
        break;
      }
      default: heff_nomatch(v_rhs_241);
      }
      V v_t_2499 = ({ V rv_1 = heff_get_n(v_t_2498, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2493, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2495, v_t_2499});
    }
    default: return heff_nomatch(v_braces_244);
    }
  }
}
V g_heff_2esyntax_2esurface_2earrowNames_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowNames_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2esurface_2earrowNames_24tok1_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_b_2415 = args[1];
  V v_braces_244 = heff_env(self)[0];
  V v_ty_243 = heff_env(self)[1];
  V v_dflt_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_At: {
    V v_it1_2416 = heff_field(v_x_2414, 0);
    V v_ysp_2417 = heff_field(v_x_2414, 1);
    V v_ru_24x_2414_24At = heff_take_reuse_n(v_x_2414, 3ULL, 2);
    switch (heff_tag_of(v_it1_2416)) {
    case TAG_EVar: {
      V v_y_2418 = heff_field(v_it1_2416, 0);
      heff_take_n(v_it1_2416, 1ULL, 1);
      switch (heff_tag_of(v_braces_244)) {
      case TAG_Nothing: {
        heff_drop(v_dflt_245);
        V v_t_2419 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiNamed, 3, (V[]){v_y_2418, heff_dup(v_ysp_2417), v_ty_243}), heff_dup(v_b_2415)});
        V v_t_2422;
        switch (heff_tag_of(v_b_2415)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_b_2415, 1);
          heff_take_n(v_b_2415, 2ULL, 2);
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_b_2415);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_ysp_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2414_24At, TAG_At, 2, (V[]){v_t_2419, v_t_2423});
      }
      case TAG_Just: {
        V v_bsp_2424 = heff_field(v_braces_244, 0);
        heff_take_n(v_braces_244, 1ULL, 1);
        V v_t_2425 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiImplicit, 5, (V[]){v_y_2418, v_ysp_2417, heff_dup(v_bsp_2424), v_ty_243, v_dflt_245}), heff_dup(v_b_2415)});
        V v_t_2428;
        switch (heff_tag_of(v_b_2415)) {
        case TAG_At: {
          V v_s_2427 = heff_field(v_b_2415, 1);
          heff_take_n(v_b_2415, 2ULL, 2);
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_b_2415);
        }
        V v_t_2429 = ({ V rv_1 = heff_get_n(v_t_2428, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2414_24At, TAG_At, 2, (V[]){v_t_2425, v_t_2429});
      }
      default: return heff_nomatch(v_braces_244);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ETag: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EInt: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EString: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EBinary: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ERune: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EWord: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EApp: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EProject: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EPi: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ELam: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_2416, 0ULL, 4);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ESig: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ESum: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EDo: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EAssign: {
      heff_take_n(v_it1_2416, 0ULL, 3);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EWhile: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EFor: {
      heff_take_n(v_it1_2416, 0ULL, 3);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EIfThen: {
      heff_take_n(v_it1_2416, 0ULL, 2);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EBreak: {
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EContinue: {
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EReturn: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ENest: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ELazy: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ETuple: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_ETry: {
      heff_take_n(v_it1_2416, 0ULL, 1);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    case TAG_EWith: {
      heff_take_n(v_it1_2416, 0ULL, 4);
      heff_drop(v_braces_244);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_245);
      heff_drop_rec(v_ysp_2417, 2);
      heff_drop_cell(v_ru_24x_2414_24At, 2);
      return v_b_2415;
    }
    default: return heff_nomatch(v_it1_2416);
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_24tok2_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ebind_24tok2(V v_tok_240, V v_m_241, V v_f_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(heff_call(v_m_241, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop(v_f_242);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      return heff_tail(v_f_242, 2, (V[]){v_x_248, v_st_246});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind_24tok2(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry, 7, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24tok2(V v_tok_240, V v_inPat_241, V v_sp_242, V v_e_243, V v_v_244, V v_s_245, V v_st_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2esegmentOf_24cpr(v_inPat_241, v_sp_242, v_e_243, v_v_244, v_s_245, v_st_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_field_248, v_field_249});
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24tok2(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}