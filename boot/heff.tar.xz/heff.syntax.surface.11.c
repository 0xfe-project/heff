// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclTheory 39552
#define TAG_ESig 50235
#define TAG_ETag 50948
#define TAG_Eqn 17358
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_MkPChain 26104
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_above__below__loosest__errors[] = {LBL_above, LBL_below, LBL_loosest, LBL_errors};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eabGo(V, V);
V g_heff_2esyntax_2esurface_2eabGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eabGo_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
V g_heff_2esyntax_2esurface_2eeqnL(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnL_clo;
V g_heff_2esyntax_2esurface_2efixDeclDone(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclDone_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclDone_clo;
V g_heff_2esyntax_2esurface_2efixDeclOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo;
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420_clo;
V g_heff_2esyntax_2esurface_2epchainOf(V);
V g_heff_2esyntax_2esurface_2epchainOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epchainOf_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_clo;
V g_heff_2esyntax_2esurface_2erestOfDecl(V, V, V);
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo;
V g_heff_2esyntax_2esurface_2etakeSyms(V);
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_clo;
V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V, V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldL(V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldL_clo;
V g_heff_2esyntax_2esurface_2etheoryL(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etheoryL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryL_clo;
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2efoldl_24f158727028x1528233175(V, V, V);
V g_list_2efoldl_24f158727028x1528233175_entry(V self, V *a);
extern Clo g_list_2efoldl_24f158727028x1528233175_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
Clo g_heff_2esyntax_2esurface_2edotAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edotAt_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edotAt(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strLength(v_s_240);
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(46LL))) {
      heff_drop(v_s_240);
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edotAt(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econL(V v_r_240, V v_c_241, V v_args_242) {
top: ;
  V v_m_243 = (g_heff_2esyntax_2esurface_2etraverseS(heff_get_n(v_r_240, 0, 3), v_args_242));
  return heff_clo_n(g_heff_2esyntax_2esurface_2econL_lam0, 1, 2, (V[]){v_m_243, v_c_241});
}
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2econL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_rec(v_c_241, 9);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x11_246_24Right, TAG_ETag, 1, (V[]){heff_dup(heff_rfield(v_c_241, 1))});
      V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_241, 3), heff_get_n(v_c_241, 4, 9)});
      V v_x_2412 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2411}), v_x_249));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2412}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str0, 62, "an integer's segment is of 8 to 64 bits, a multiple of 8, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str1, 62, "an integer's segment is of 8 to 64 bits, a multiple of 8, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str2, 62, "an integer's segment is of 8 to 64 bits, a multiple of 8, not ");
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V v_inPat_240, V v_sp_241, V v_v_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0_clo);
  }
  case TAG_Just: {
    V v_n_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    if (heff_intLt_c(heff_dup(v_n_246), MK_INT(8LL))) {
      heff_drop(v_v_242);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1, 1, 2, (V[]){v_n_246, v_sp_241});
    } else {
      if (heff_intLt_c(MK_INT(64LL), heff_dup(v_n_246))) {
        heff_drop(v_v_242);
        return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam2, 1, 2, (V[]){v_n_246, v_sp_241});
      } else {
        if (heff_intEq_c(heff_intMod(heff_dup(v_n_246), MK_INT(8LL)), MK_INT(0LL))) {
          HEFF_LAST return g_heff_2esyntax_2esurface_2eintegerFits_24s877108364x1811585420(v_inPat_240, v_sp_241, v_v_242, v_n_246);
        } else {
          heff_drop(v_v_242);
          return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam3, 1, 2, (V[]){v_n_246, v_sp_241});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str0), heff_intShow(v_n_246));
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_249, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2410}), v_st_248});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam2(V self, V *args) {
  V v_st_2412 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str1), heff_intShow(v_n_246));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2413, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2414}), v_st_2412});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_lam3(V self, V *args) {
  V v_st_2416 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_str2), heff_intShow(v_n_246));
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2417, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0, 1, 1, (V[]){v_st_242});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x5_243, 0);
    V v_rest_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_m_247 = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(heff_dup(v_fix_240), v_lenient_241, v_st_242, v_r_245));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1, 1, 4, (V[]){v_m_247, v_fix_240, heff_dup(v_lenient_241), v_rest_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_st_242}), v_st_244});
}
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_fix_240 = heff_env(self)[1];
  V v_lenient_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop(v_rest_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      V v_t_2414 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_x_2413; V a_3 = v_rest_246; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
      V f_ = v_t_2414;
      args[0] = v_st_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2esyntax_2esurface_2epchainOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epchainOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epchainOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PCon: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  case TAG_PAtom: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  case TAG_PParen: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  case TAG_PList: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  case TAG_POp: {
    V v_l_2411 = heff_field(v_p_240, 0);
    V v_op_2412 = heff_field(v_p_240, 1);
    V v_r_2413 = heff_field(v_p_240, 2);
    heff_take_n(v_p_240, 7ULL, 3);
    V v_x3_2414 = (g_heff_2esyntax_2esurface_2epchainOf(v_r_2413));
    switch (heff_tag_of(v_x3_2414)) {
    case TAG_MkPChain: {
      V v_rh_2415 = heff_field(v_x3_2414, 0);
      V v_rest_2416 = heff_field(v_x3_2414, 1);
      V v_ru_24x3_2414_24MkPChain = heff_take_reuse_n(v_x3_2414, 3ULL, 2);
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_op_2412, v_rh_2415}), v_rest_2416});
      return heff_tag_at_n(v_ru_24x3_2414_24MkPChain, TAG_MkPChain, 2, (V[]){v_l_2411, v_t_2417});
    }
    default: return heff_nomatch(v_x3_2414);
    }
  }
  case TAG_PRec: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  case TAG_PField: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  case TAG_PAs: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  case TAG_PSeg: {
    return heff_tag_n(TAG_MkPChain, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2esurface_2epchainOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epchainOf(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(V v_e0_240, V v_rest_241, V v_st_242) {
top: ;
  V v_x_243 = heff_dup(heff_rfield(v_st_242, 5));
  V v_x_244 = heff_dup(heff_rfield(v_st_242, 6));
  V v_m_245 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_x_243), v_x_244, heff_dup(v_rest_241)));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_e0_240);
      heff_drop(v_rest_241);
      heff_drop(v_x_243);
      heff_drop(v_x_244);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      heff_take_n(v_x11_247, 0ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e0_240), NTAG(TAG_Nil)});
      V v_t_2412 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_2411});
      V v_m_2413 = ({ V a_0 = v_x_243; V a_1 = v_x_244; V a_2 = v_t_2412; V a_3 = v_rest_241; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_e0_240);
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_st_2419 = (g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(v_x_2418));
          V v_t_2420 = heff_get_n(v_st_2419, 1, 2);
          V v_t_2423;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            v_t_2423 = v_e0_240;
            break;
          }
          case TAG_Cons: {
            V v_x_2421 = heff_field(v_t_2420, 0);
            heff_take_n(v_t_2420, 1ULL, 2);
            heff_drop(v_e0_240);
            v_t_2423 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2423}), v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eeqnL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eeqnL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eeqnL_entry, 6, 0};

V g_heff_2esyntax_2esurface_2eeqnL(V v_r_240, V v_names_241, V v_pats_242, V v_rhs_243, V v_w_244, V v_st_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_f_247 = heff_get_n(v_t_246, 0, 2);
  V v_x2_248 = (g_map_2elookup_24s1546226666x2146984184(v_f_247, heff_rfield(v_st_245, 3)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    v_t_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_x1_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2410}), v_st_245});
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_pats_242);
      heff_drop(v_rhs_243);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_t_2416 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_pv_2417 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_x_2415));
      V v_t_2418 = ({ V rv_4 = v_pv_2417; V rr_ = heff_rec_reuse_nf(v_st_2413, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_x1_2419 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2416, v_t_2418});
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x11_2420 = heff_field(v_x1_2419, 0);
        V v_st_2421 = heff_field(v_x1_2419, 1);
        V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
        switch (heff_tag_of(v_x11_2420)) {
        case TAG_Left: {
          V v_e_2422 = heff_field(v_x11_2420, 0);
          heff_take_n(v_x11_2420, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop(v_pats_242);
          heff_drop(v_rhs_243);
          heff_drop(v_x_2415);
          return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2420, 0ULL, 1);
          V v_m_2424 = (g_heff_2esyntax_2esurface_2etraverseS(heff_dup(heff_rfield(v_r_240, 1)), heff_dup(v_pats_242)));
          V v_x1_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_st_2421}));
          switch (heff_tag_of(v_x1_2425)) {
          case TAG_MkPair: {
            V v_x11_2426 = heff_field(v_x1_2425, 0);
            V v_st_2427 = heff_field(v_x1_2425, 1);
            heff_take_n(v_x1_2425, 3ULL, 2);
            switch (heff_tag_of(v_x11_2426)) {
            case TAG_Left: {
              V v_e_2428 = heff_field(v_x11_2426, 0);
              heff_take_n(v_x11_2426, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop(v_pats_242);
              heff_drop(v_rhs_243);
              heff_drop(v_x_2415);
              return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2428}), v_st_2427});
            }
            case TAG_Right: {
              V v_x_2429 = heff_field(v_x11_2426, 0);
              heff_take_n(v_x11_2426, 1ULL, 1);
              heff_drop_cell(v_ru_24x1_2419_24MkPair, 2);
              V v_t_2430 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_x_2415));
              V v_t_2431 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2430}));
              V v_t_2432 = ({ V a_0 = v_t_2431; V a_1 = v_pats_242; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_242); r_; });
              V v_t_2433 = ({ V a_0 = v_x_2415; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_x_2415); r_; });
              V v_t_2434 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2432, v_t_2433));
              V v_m_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_243}));
              V v_t_2436 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2427, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
              return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2434, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_lam0, 1, 5, (V[]){v_m_2435, heff_dup(v_w_244), v_r_240, heff_dup(v_names_241), v_x_2429}), v_t_2436));
            }
            default: return heff_nomatch(v_x11_2426);
            }
          }
          default: return heff_nomatch(v_x1_2425);
          }
        }
        default: return heff_nomatch(v_x11_2420);
        }
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2esyntax_2esurface_2eeqnL(a[0], a1, a[2], a[3], a4, a[5]); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_lam1(V self, V *args) {
  V v_st_2443 = args[0];
  V v_x_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2442}), v_st_2443});
}
V g_heff_2esyntax_2esurface_2eeqnL_lam0(V self, V *args) {
  V v_st_2437 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_w_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_names_241 = heff_env(self)[3];
  V v_x_2429 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2438 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_st_2437}));
  switch (heff_tag_of(v_x1_2438)) {
  case TAG_MkPair: {
    V v_x11_2439 = heff_field(v_x1_2438, 0);
    V v_st_2440 = heff_field(v_x1_2438, 1);
    V v_ru_24x1_2438_24MkPair = heff_take_reuse_n(v_x1_2438, 3ULL, 2);
    switch (heff_tag_of(v_x11_2439)) {
    case TAG_Left: {
      V v_e_2441 = heff_field(v_x11_2439, 0);
      heff_take_n(v_x11_2439, 1ULL, 1);
      heff_drop(v_w_244);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_names_241);
      heff_drop(v_x_2429);
      return heff_tag_at_n(v_ru_24x1_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2441}), v_st_2440});
    }
    case TAG_Right: {
      V v_x_2442 = heff_field(v_x11_2439, 0);
      heff_take_n(v_x11_2439, 1ULL, 1);
      V v_m_2447;
      switch (heff_tag_of(v_w_244)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 3);
        v_m_2447 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_lam1, 1, 1, (V[]){v_x_2442});
        break;
      }
      case TAG_Just: {
        V v_it1_2444 = heff_field(v_w_244, 0);
        heff_take_n(v_w_244, 1ULL, 1);
        switch (heff_tag_of(v_it1_2444)) {
        case TAG_MkPair: {
          V v_kw_2445 = heff_field(v_it1_2444, 0);
          V v_ds_2446 = heff_field(v_it1_2444, 1);
          heff_take_n(v_it1_2444, 3ULL, 2);
          v_m_2447 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_clo), 4, (V[]){v_r_240, v_kw_2445, v_ds_2446, v_x_2442}));
          break;
        }
        default: heff_nomatch(v_it1_2444);
        }
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      V v_x1_2448 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_st_2440}));
      switch (heff_tag_of(v_x1_2448)) {
      case TAG_MkPair: {
        V v_x11_2449 = heff_field(v_x1_2448, 0);
        V v_st_2450 = heff_field(v_x1_2448, 1);
        V v_ru_24x1_2448_24MkPair = heff_take_reuse_n(v_x1_2448, 3ULL, 2);
        switch (heff_tag_of(v_x11_2449)) {
        case TAG_Left: {
          V v_e_2451 = heff_field(v_x11_2449, 0);
          heff_take_n(v_x11_2449, 1ULL, 1);
          heff_drop(v_names_241);
          heff_drop(v_x_2429);
          heff_drop_cell(v_ru_24x1_2448_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2451}), v_st_2450});
        }
        case TAG_Right: {
          V v_x_2452 = heff_field(v_x11_2449, 0);
          heff_take_n(v_x11_2449, 1ULL, 1);
          V v_t_2453 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
          V v_t_2454 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
          V v_t_2455 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
          V v_t_2456 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2454, 0, 2), heff_get_n(v_t_2455, 1, 2), v_x_2429, heff_dup(v_x_2452)});
          V v_t_2459;
          switch (heff_tag_of(v_names_241)) {
          case TAG_Nil: {
            v_t_2459 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2457 = heff_dup(heff_field(v_names_241, 0));
            v_t_2459 = heff_get_n(v_t_2457, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_241);
          }
          V v_t_2462;
          switch (heff_tag_of(v_x_2452)) {
          case TAG_At: {
            V v_s_2461 = heff_dup(heff_field(v_x_2452, 1));
            v_t_2462 = v_s_2461;
            break;
          }
          default: heff_nomatch(v_x_2452);
          }
          V v_t_2463 = ({ V rv_0 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_t_2462, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2466;
          switch (heff_tag_of(v_names_241)) {
          case TAG_Nil: {
            v_t_2466 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2464 = heff_field(v_names_241, 0);
            heff_take_n(v_names_241, 1ULL, 2);
            v_t_2466 = heff_get_n(v_t_2464, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_241);
          }
          V v_t_2469;
          switch (heff_tag_of(v_x_2452)) {
          case TAG_At: {
            V v_s_2468 = heff_field(v_x_2452, 1);
            heff_take_n(v_x_2452, 2ULL, 2);
            v_t_2469 = v_s_2468;
            break;
          }
          default: heff_nomatch(v_x_2452);
          }
          V v_t_2470 = ({ V rv_0 = v_t_2466; V rr_ = heff_rec_reuse_nf(v_t_2469, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2471 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2453, 0, 2), heff_tag_at_n(v_ru_24x1_2448_24MkPair, TAG_At, 2, (V[]){v_t_2456, v_t_2463}), v_t_2470});
          V v_x_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2472}), v_st_2450});
        }
        default: return heff_nomatch(v_x11_2449);
        }
      }
      default: return heff_nomatch(v_x1_2448);
      }
    }
    default: return heff_nomatch(v_x11_2439);
    }
  }
  default: return heff_nomatch(v_x1_2438);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etheoryL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryL_entry, 7, 0};

V g_heff_2esyntax_2esurface_2etheoryL(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_fields_245, V v_z_246) {
top: ;
  V v_m_248 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_244));
  V v_x1_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop_rec(v_name_243, 9);
      heff_drop(v_fields_245);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      V v_t_2414 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2413)));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2414, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_lam1, 1, 6, (V[]){v_r_240, v_fields_245, v_name_243, v_d_241, v_kw_242, v_x_2413}), v_st_2411));
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryL(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2esurface_2etheoryL_lam0(V self, V *args) {
  V v_m_247 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_247));
}
V g_heff_2esyntax_2esurface_2etheoryL_lam2(V self, V *args) {
  V v_f_2416 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2etheoryFieldL(v_r_240, v_f_2416));
}
V g_heff_2esyntax_2esurface_2etheoryL_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_fields_245 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_kw_242 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2417 = (g_heff_2esyntax_2esurface_2eblock(heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_lam2, 1, 1, (V[]){v_r_240}), v_fields_245, v_st_2415));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      heff_take_n(v_x11_2418, 1ULL, 1);
      heff_drop_rec(v_name_243, 9);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_x_2413);
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_243, 3), heff_take_field(v_name_243, 4)});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_241)));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_242, 3)), v_e_2424});
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_ESig, 1, (V[]){v_x_2421}), v_t_2425});
      V v_t_2427 = heff_tag_n(TAG_DeclTheory, 4, (V[]){heff_get_n(v_name_243, 1, 9), v_t_2422, v_x_2413, v_t_2426});
      V v_t_2428 = (g_heff_2esyntax_2ecst_2elastD(v_d_241));
      V v_e_2429 = heff_get_n(v_t_2428, 4, 9);
      V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242, 3, 9), v_e_2429});
      V v_t_2431 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_t_2430})});
      V v_x_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2432}), v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erestOfDecl_str0, 3, "eof");
Clo g_heff_2esyntax_2esurface_2erestOfDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erestOfDecl_entry, 3, 0};

V g_heff_2esyntax_2esurface_2erestOfDecl(V v_ts_240, V v_j_241, V v_acc_242) {
top: ;
  V v_t_246;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_j_241))) {
    if (heff_intLt_c(heff_dup(v_j_241), heff_arrayLength(heff_dup(v_ts_240)))) {
      V v_t_245 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_241));
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      v_t_246 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_246 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_ts_240);
    heff_drop(v_j_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Just: {
    V v_t_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2erestOfDecl_str0))) {
      heff_drop(v_ts_240);
      heff_drop(v_j_241);
      heff_drop_rec(v_t_247, 7);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    } else {
      V v_t_249 = heff_dup(heff_rfield(v_t_247, 6));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        if (heff_intEq_c(heff_dup(heff_rfield(v_t_247, 5)), MK_INT(0LL))) {
          heff_drop(v_ts_240);
          heff_drop(v_j_241);
          heff_drop_rec(v_t_247, 7);
          return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
        } else {
          V t_0 = v_ts_240;
          V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
          v_ts_240 = t_0;
          v_j_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_t_249);
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
        v_ts_240 = t_0;
        v_j_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2esyntax_2esurface_2erestOfDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erestOfDecl(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etakeSyms_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2etakeSyms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakeSyms_entry, 1, 0};

V g_heff_2esyntax_2esurface_2etakeSyms(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_u_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_241, 0)), ((V)&g_heff_2esyntax_2esurface_2etakeSyms_str0))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_u_241, heff_hole()});
      V v_u_245 = (g_heff_2esyntax_2esurface_2etakeSyms_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_u_241, 7);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakeSyms_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etakeSyms(a[0]);
}
Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDeclOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDeclOf(V v_ts_240, V v_k_241, V v_t_242) {
top: ;
  V v_rest_243 = (g_heff_2esyntax_2esurface_2erestOfDecl(v_ts_240, heff_intAdd(v_k_241, MK_INT(1LL)), NTAG(TAG_Nil)));
  V v_t_244 = (g_heff_2esyntax_2esurface_2etakeSyms(heff_dup(v_rest_243)));
  V v_t_245 = heff_rec_n(4, shape_above__below__loosest__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24f158727028x1528233175(MK_INT(1LL), MK_INT(0LL), v_rest_243));
  V v_t_247 = (g_heff_2esyntax_2esurface_2edropN(v_t_246, heff_dup(v_rest_243)));
  V v_t_248 = (g_heff_2esyntax_2esurface_2eabGo(v_t_245, v_t_247));
  return ({ V a_0 = v_t_242; V a_1 = v_rest_243; V a_2 = v_t_244; V a_3 = v_t_248; V r_ = (g_heff_2esyntax_2esurface_2efixDeclDone(a_0, a_1, a_2, a_3)); heff_drop(v_rest_243); r_; });
}
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixDeclOf(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(a[0], a[1], a[2]);
}