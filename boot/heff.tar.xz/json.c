// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expected 48537
#define TAG_Failed 62128
#define TAG_Finished 10465
#define TAG_Got 19224
#define TAG_InArray 20296
#define TAG_InObject 18783
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Value 50841
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2ecolonThen(V, V, V, V);
V g_json_2ecolonThen_entry(V self, V *a);
extern Clo g_json_2ecolonThen_clo;
V g_json_2edigitsEnd(V, V);
V g_json_2edigitsEnd_entry(V self, V *a);
extern Clo g_json_2edigitsEnd_clo;
V g_json_2edigitsValue(V, V, V, V);
V g_json_2edigitsValue_entry(V self, V *a);
extern Clo g_json_2edigitsValue_clo;
V g_json_2eescapeAt(V, V);
V g_json_2eescapeAt_entry(V self, V *a);
extern Clo g_json_2eescapeAt_clo;
V g_json_2eescapeGo(V, V, V);
V g_json_2eescapeGo_entry(V self, V *a);
extern Clo g_json_2eescapeGo_clo;
HeffT2 g_json_2eescapeText_24cpr(V, V);
V g_json_2eexponentEnd(V, V);
V g_json_2eexponentEnd_entry(V self, V *a);
extern Clo g_json_2eexponentEnd_clo;
V g_json_2eexponentValue(V, V, V);
V g_json_2eexponentValue_entry(V self, V *a);
extern Clo g_json_2eexponentValue_clo;
double g_json_2efloatOf_w(V, V, V, V, V, V);
V g_json_2efloatOf(V, V, V, V, V, V);
V g_json_2efloatOf_entry(V self, V *a);
extern Clo g_json_2efloatOf_clo;
V g_json_2egotIn(V, V, V, V, V);
V g_json_2egotIn_entry(V self, V *a);
extern Clo g_json_2egotIn_clo;
V g_json_2ehex4(V, V);
V g_json_2ehex4_entry(V self, V *a);
extern Clo g_json_2ehex4_clo;
V g_json_2ehexValue(V);
V g_json_2ehexValue_entry(V self, V *a);
extern Clo g_json_2ehexValue_clo;
V g_json_2ekeyThen(V, V, V, V);
V g_json_2ekeyThen_entry(V self, V *a);
extern Clo g_json_2ekeyThen_clo;
HeffT2 g_json_2enumberAfterDigits_24cpr(V, V, V, V);
HeffT2 g_json_2enumberAt_24cpr(V, V);
double g_json_2epow10_w(V);
V g_json_2epow10(V);
V g_json_2epow10_entry(V self, V *a);
extern Clo g_json_2epow10_clo;
double g_json_2escaled_w(V, V);
V g_json_2escaled(V, V);
V g_json_2escaled_entry(V self, V *a);
extern Clo g_json_2escaled_clo;
V g_json_2eskipSpace(V, V);
V g_json_2eskipSpace_entry(V self, V *a);
extern Clo g_json_2eskipSpace_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
V g_json_2estringFrom(V, V, V, V);
V g_json_2estringFrom_entry(V self, V *a);
extern Clo g_json_2estringFrom_clo;
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
HeffT2 g_json_2eunicodeEscape_24cpr(V, V);
V g_json_2evalueAt(V, V, V);
V g_json_2evalueAt_entry(V self, V *a);
extern Clo g_json_2evalueAt_clo;
HeffT2 g_list_2efind_24s465947678x1101118081_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s925333445x1396764769(V, V, V, V, V, V);
V g_list_2emap_24s925333445x1396764769_entry(V self, V *a);
extern Clo g_list_2emap_24s925333445x1396764769_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_json_2eescapeAt_str0, 2, "\\\"");
HEFF_LIT(g_json_2eescapeAt_str1, 2, "\\\\");
HEFF_LIT(g_json_2eescapeAt_str2, 2, "\\n");
HEFF_LIT(g_json_2eescapeAt_str3, 2, "\\r");
HEFF_LIT(g_json_2eescapeAt_str4, 2, "\\t");
HEFF_LIT(g_json_2eescapeAt_str5, 2, "\\b");
HEFF_LIT(g_json_2eescapeAt_str6, 2, "\\f");
HEFF_LIT(g_json_2eescapeAt_str7, 16, "0123456789abcdef");
HEFF_LIT(g_json_2eescapeAt_str8, 16, "0123456789abcdef");
HEFF_LIT(g_json_2eescapeAt_str9, 4, "\\u00");
Clo g_json_2eescapeAt_clo = {{0x80000000u, K_CLO, 0}, g_json_2eescapeAt_entry, 2, 0};

V g_json_2eescapeAt(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
    heff_drop(v_i_241);
    return ((V)&g_json_2eescapeAt_str0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
      heff_drop(v_i_241);
      return ((V)&g_json_2eescapeAt_str1);
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)10ULL))) {
        heff_drop(v_i_241);
        return ((V)&g_json_2eescapeAt_str2);
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)13ULL))) {
          heff_drop(v_i_241);
          return ((V)&g_json_2eescapeAt_str3);
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)9ULL))) {
            heff_drop(v_i_241);
            return ((V)&g_json_2eescapeAt_str4);
          } else {
            if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)8ULL))) {
              heff_drop(v_i_241);
              return ((V)&g_json_2eescapeAt_str5);
            } else {
              if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)12ULL))) {
                heff_drop(v_i_241);
                return ((V)&g_json_2eescapeAt_str6);
              } else {
                if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)32ULL))) {
                  V v_c_2410 = heff_strByteAt_lent(v_s_240, v_i_241, 2);
                  int64_t v_d_2411 = heff_word_div(heff_peek_word(v_c_2410), ((int64_t)16ULL));
                  V v_t_2412 = heff_strSlice(((V)&g_json_2eescapeAt_str7), heff_box_word(v_d_2411), heff_box_word((v_d_2411 + ((int64_t)1ULL))));
                  int64_t v_d_2413 = heff_word_mod(heff_unbox_word(v_c_2410), ((int64_t)16ULL));
                  V v_t_2414 = heff_strSlice(((V)&g_json_2eescapeAt_str8), heff_box_word(v_d_2413), heff_box_word((v_d_2413 + ((int64_t)1ULL))));
                  return heff_strAppend(((V)&g_json_2eescapeAt_str9), heff_strAppend(v_t_2412, v_t_2414));
                } else {
                  return heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_json_2eescapeAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2eescapeAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_json_2eescapeGo_clo = {{0x80000000u, K_CLO, 0}, g_json_2eescapeGo_entry, 3, 0};

V g_json_2eescapeGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V v_t_245 = (g_json_2eescapeAt(v_s_240, heff_dup(v_i_241)));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_strAppend(v_acc_242, v_t_245);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      V v_t_246 = heff_strRuneWidth_lent(v_s_240, v_i_241, 0);
      V v_t_247 = heff_runeToInt(heff_strRuneAt_lent(v_s_240, v_i_241, 0));
      V v_t_2410;
      if (heff_intEq_c(v_t_247, heff_runeToInt(MK_INT(65533LL)))) {
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(65533LL), NTAG(TAG_Nil)});
        v_t_2410 = heff_strOfRunes(v_t_249);
      } else {
        v_t_2410 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_t_246)));
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, v_t_246);
      V t_2 = heff_strAppend(v_acc_242, v_t_2410);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
  }
}
V g_json_2eescapeGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2eescapeGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2estringify_str0, 4, "null");
HEFF_LIT(g_json_2estringify_str1, 4, "true");
HEFF_LIT(g_json_2estringify_str2, 5, "false");
HEFF_LIT(g_json_2estringify_str3, 0, "");
HEFF_LIT(g_json_2estringify_str4, 1, "\"");
HEFF_LIT(g_json_2estringify_str5, 1, "\"");
HEFF_LIT(g_json_2estringify_str6, 0, "");
HEFF_LIT(g_json_2estringify_str7, 1, ",");
HEFF_LIT(g_json_2estringify_str8, 1, "[");
HEFF_LIT(g_json_2estringify_str9, 1, "]");
HEFF_LIT(g_json_2estringify_str10, 1, "\"");
HEFF_LIT(g_json_2estringify_str11, 0, "");
HEFF_LIT(g_json_2estringify_str12, 1, "\"");
HEFF_LIT(g_json_2estringify_str13, 1, ":");
HEFF_LIT(g_json_2estringify_str14, 0, "");
HEFF_LIT(g_json_2estringify_str15, 1, ",");
HEFF_LIT(g_json_2estringify_str16, 1, "{");
HEFF_LIT(g_json_2estringify_str17, 1, "}");
Clo g_json_2estringify_clo = {{0x80000000u, K_CLO, 0}, g_json_2estringify_entry, 1, 0};

V g_json_2estringify(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JNull: {
    return ((V)&g_json_2estringify_str0);
  }
  case TAG_JBool: {
    V v_b_241 = heff_field(v_x1_240, 0);
    if ((heff_dup(v_b_241) == NTAG(TAG_True))) {
      return ((V)&g_json_2estringify_str1);
    } else {
      return ((V)&g_json_2estringify_str2);
    }
  }
  case TAG_JInt: {
    V v_i_242 = heff_field(v_x1_240, 0);
    return heff_intShow(heff_dup(v_i_242));
  }
  case TAG_JFloat: {
    V v_x_243 = heff_tget_v(v_x1_240, 0);
    return heff_floatShow(v_x_243);
  }
  case TAG_JString: {
    V v_s_244 = heff_field(v_x1_240, 0);
    V v_t_245 = (g_json_2eescapeGo(v_s_244, MK_INT(0LL), ((V)&g_json_2estringify_str3)));
    return heff_strAppend(((V)&g_json_2estringify_str4), heff_strAppend(v_t_245, ((V)&g_json_2estringify_str5)));
  }
  case TAG_JArray: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_x2_247 = (g_list_2emap(((V)&g_json_2estringify_clo), heff_dup(v_xs_246)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_json_2estringify_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_json_2estringify_str7); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strAppend(((V)&g_json_2estringify_str8), heff_strAppend(v_t_2410, ((V)&g_json_2estringify_str9)));
  }
  case TAG_JObject: {
    V v_fs_2411 = heff_field(v_x1_240, 0);
    V v_x2_2412 = (g_list_2emap_24s925333445x1396764769(((V)&g_json_2estringify_str10), MK_INT(0LL), ((V)&g_json_2estringify_str11), ((V)&g_json_2estringify_str12), ((V)&g_json_2estringify_str13), heff_dup(v_fs_2411)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_json_2estringify_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_json_2estringify_str15); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    return heff_strAppend(((V)&g_json_2estringify_str16), heff_strAppend(v_t_2415, ((V)&g_json_2estringify_str17)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_json_2estringify_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2estringify(a0); heff_drop(a0); return r;
}
Clo g_json_2eskipSpace_clo = {{0x80000000u, K_CLO, 0}, g_json_2eskipSpace_entry, 2, 0};

V g_json_2eskipSpace(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if ((heff_peek_word(v_c_242) == ((int64_t)32ULL))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    if ((heff_peek_word(v_c_242) == ((int64_t)10ULL))) {
      heff_drop(v_c_242);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      if ((heff_peek_word(v_c_242) == ((int64_t)13ULL))) {
        heff_drop(v_c_242);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        if ((heff_unbox_word(v_c_242) == ((int64_t)9ULL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_i_241 = t_1;
          goto top;
        } else {
          return v_i_241;
        }
      }
    }
  }
}
V g_json_2eskipSpace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2eskipSpace(a0, a[1]); heff_drop(a0); return r;
}
Clo g_json_2edigitsEnd_clo = {{0x80000000u, K_CLO, 0}, g_json_2edigitsEnd_entry, 2, 0};

V g_json_2edigitsEnd(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if ((((int64_t)48ULL) <= heff_peek_word(v_c_242))) {
    if ((heff_unbox_word(v_c_242) <= ((int64_t)57ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      return v_i_241;
    }
  } else {
    heff_drop(v_c_242);
    return v_i_241;
  }
}
V g_json_2edigitsEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2edigitsEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_json_2edigitsValue_clo = {{0x80000000u, K_CLO, 0}, g_json_2edigitsValue_entry, 4, 0};

V g_json_2edigitsValue(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_acc_243;
  } else {
    V v_t_245 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(10LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_j_242;
    V t_3 = heff_intSub(v_t_245, MK_INT(48LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_j_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_json_2edigitsValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2edigitsValue(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_json_2epow10_clo = {{0x80000000u, K_CLO, 0}, g_json_2epow10_entry, 1, 0};

double g_json_2epow10_w(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 == ((int64_t)0ULL))) {
    return (1.0);
  } else {
    if (((v_k_240 % ((int64_t)2ULL)) == ((int64_t)1ULL))) {
      double v_t_243 = (g_json_2epow10_w(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
      return ((10.0) * v_t_243);
    } else {
      double v_x_244 = (g_json_2epow10_w(heff_box_word((v_k_240 / ((int64_t)2ULL)))));
      return (v_x_244 * v_x_244);
    }
  }
}
V g_json_2epow10(V v_box_24k_240) {
  return heff_box_f64((g_json_2epow10_w(v_box_24k_240)));
}
V g_json_2epow10_entry(V self, V *a) {
  (void)self;
  return g_json_2epow10(a[0]);
}
Clo g_json_2escaled_clo = {{0x80000000u, K_CLO, 0}, g_json_2escaled_entry, 2, 0};

double g_json_2escaled_w(V v_m_240, V v_e_241) {
top: ;
  if (heff_intLe_c_lent(MK_INT(0LL), v_e_241, 1)) {
    V v_t_244;
    if (heff_intLt_c_lent(MK_INT(400LL), v_e_241, 1)) {
      heff_drop(v_e_241);
      v_t_244 = MK_INT(400LL);
    } else {
      v_t_244 = v_e_241;
    }
    double v_t_245 = (g_json_2epow10_w(v_t_244));
    return (heff_from_int_f64(v_m_240) * v_t_245);
  } else {
    if (heff_intLt_c_lent(v_e_241, MK_INT(-300LL), 2)) {
      double v_t_247 = (g_json_2epow10_w(MK_INT(300LL)));
      double v_t_248 = (heff_from_int_f64(v_m_240) / v_t_247);
      int64_t v_t_2410;
      if (heff_intLt_c_lent(v_e_241, MK_INT(-700LL), 2)) {
        heff_drop(v_e_241);
        v_t_2410 = ((int64_t)400ULL);
      } else {
        v_t_2410 = ((((int64_t)0ULL) - heff_unbox_word(v_e_241)) - ((int64_t)300ULL));
      }
      double v_t_2411 = (g_json_2epow10_w(heff_box_word(v_t_2410)));
      return (v_t_248 / v_t_2411);
    } else {
      double v_t_2412 = (g_json_2epow10_w(heff_box_word((((int64_t)0ULL) - heff_unbox_word(v_e_241)))));
      return (heff_from_int_f64(v_m_240) / v_t_2412);
    }
  }
}
V g_json_2escaled(V v_m_240, V v_e_241) {
  return heff_box_f64((g_json_2escaled_w(v_m_240, v_e_241)));
}
V g_json_2escaled_entry(V self, V *a) {
  (void)self;
  return g_json_2escaled(a[0], a[1]);
}
Clo g_json_2eexponentEnd_clo = {{0x80000000u, K_CLO, 0}, g_json_2eexponentEnd_entry, 2, 0};

V g_json_2eexponentEnd(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)43ULL))) {
    HEFF_LAST return g_json_2edigitsEnd(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL))) {
      HEFF_LAST return g_json_2edigitsEnd(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)));
    } else {
      HEFF_LAST return g_json_2edigitsEnd(v_s_240, v_i_241);
    }
  }
}
V g_json_2eexponentEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2eexponentEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_json_2eexponentValue_clo = {{0x80000000u, K_CLO, 0}, g_json_2eexponentValue_entry, 3, 0};

V g_json_2eexponentValue(V v_s_240, V v_i_241, V v_j_242) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL))) {
    V v_t_244 = (g_json_2edigitsValue(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_j_242, MK_INT(0LL)));
    return heff_intSub(MK_INT(0LL), v_t_244);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)43ULL))) {
      return (g_json_2edigitsValue(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_j_242, MK_INT(0LL)));
    } else {
      return (g_json_2edigitsValue(v_s_240, v_i_241, v_j_242, MK_INT(0LL)));
    }
  }
}
V g_json_2eexponentValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2eexponentValue(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_json_2efloatOf_clo = {{0x80000000u, K_CLO, 0}, g_json_2efloatOf_entry, 6, 0};

double g_json_2efloatOf_w(V v_s_240, V v_start_241, V v_d_242, V v_p_243, V v_f_244, V v_end_245) {
top: ;
  V v_whole_246 = (g_json_2edigitsValue(v_s_240, v_d_242, heff_dup(v_p_243), MK_INT(0LL)));
  V v_fraction_248;
  if (heff_intLt_c_lent(v_p_243, v_f_244, 0)) {
    v_fraction_248 = (g_json_2edigitsValue(v_s_240, heff_intAdd(heff_dup(v_p_243), MK_INT(1LL)), heff_dup(v_f_244), v_whole_246));
  } else {
    v_fraction_248 = v_whole_246;
  }
  V v_e_2410;
  if (heff_intLt_c_lent(v_f_244, v_end_245, 0)) {
    v_e_2410 = (g_json_2eexponentValue(v_s_240, heff_intAdd(heff_dup(v_f_244), MK_INT(1LL)), v_end_245));
  } else {
    heff_drop(v_end_245);
    v_e_2410 = MK_INT(0LL);
  }
  V v_t_2412;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_start_241, 0)) == ((int64_t)45ULL))) {
    v_t_2412 = heff_intSub(MK_INT(0LL), v_fraction_248);
  } else {
    v_t_2412 = v_fraction_248;
  }
  V v_t_2414;
  if (heff_intLt_c_lent(v_p_243, v_f_244, 0)) {
    v_t_2414 = heff_intSub(heff_intSub(v_f_244, v_p_243), MK_INT(1LL));
  } else {
    heff_drop(v_p_243);
    heff_drop(v_f_244);
    v_t_2414 = MK_INT(0LL);
  }
  return (g_json_2escaled_w(v_t_2412, heff_intSub(v_e_2410, v_t_2414)));
}
V g_json_2efloatOf(V v_s_240, V v_start_241, V v_d_242, V v_p_243, V v_f_244, V v_end_245) {
  return heff_box_f64((g_json_2efloatOf_w(v_s_240, v_start_241, v_d_242, v_p_243, v_f_244, v_end_245)));
}
V g_json_2efloatOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_json_2efloatOf(a0, a1, a[2], a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_json_2enumberAfterDigits_24cpr_str0, 7, "a digit");
HEFF_LIT(g_json_2enumberAfterDigits_24cpr_str1, 7, "a digit");

HeffT2 g_json_2enumberAfterDigits_24cpr(V v_s_240, V v_start_241, V v_d_242, V v_p_243) {
top: ;
  V v_f_245;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_p_243, 0)) == ((int64_t)46ULL))) {
    v_f_245 = (g_json_2edigitsEnd(v_s_240, heff_intAdd(heff_dup(v_p_243), MK_INT(1LL))));
  } else {
    v_f_245 = heff_dup(v_p_243);
  }
  V v_hasExponent_247 = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_f_245, 0)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_f_245, 0)) == ((int64_t)69ULL))));
  V v_end_248;
  if ((heff_dup(v_hasExponent_247) == NTAG(TAG_True))) {
    v_end_248 = (g_json_2eexponentEnd(v_s_240, heff_intAdd(heff_dup(v_f_245), MK_INT(1LL))));
  } else {
    v_end_248 = heff_dup(v_f_245);
  }
  if (heff_intEq_c(heff_dup(v_f_245), heff_intAdd(heff_dup(v_p_243), MK_INT(1LL)))) {
    heff_drop(v_d_242);
    heff_drop(v_p_243);
    heff_drop(v_hasExponent_247);
    heff_drop(v_end_248);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Expected, 2, (V[]){v_f_245, ((V)&g_json_2enumberAfterDigits_24cpr_str0)})}});
  } else {
    V v_t_2413 = heff_bool(((heff_dup(v_hasExponent_247) == NTAG(TAG_True)) && ({ V v_c_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_end_248), MK_INT(1LL))); int c_ = ((((int64_t)48ULL) <= heff_peek_word(v_c_2410)) ? !(heff_peek_word(v_c_2410) <= ((int64_t)57ULL)) : 1); heff_drop(v_c_2410); c_; })));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_d_242);
      heff_drop(v_p_243);
      heff_drop(v_f_245);
      heff_drop(v_hasExponent_247);
      heff_drop(v_t_2413);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Expected, 2, (V[]){v_end_248, ((V)&g_json_2enumberAfterDigits_24cpr_str1)})}});
    } else {
      heff_drop(v_t_2413);
      if (heff_intEq_c_lent(v_f_245, v_p_243, 0)) {
        if ((heff_dup(v_hasExponent_247) == NTAG(TAG_True))) {
          heff_drop(v_hasExponent_247);
          double v_t_2415 = (g_json_2efloatOf_w(v_s_240, v_start_241, v_d_242, v_p_243, v_f_245, heff_dup(v_end_248)));
          V v_f_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_JFloat, 1, 1u, (V[]){heff_word_f64(v_t_2415)}), v_end_248});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2416}});
        } else {
          heff_drop(v_f_245);
          heff_drop(v_hasExponent_247);
          V v_n_2417 = (g_json_2edigitsValue(v_s_240, v_d_242, v_p_243, MK_INT(0LL)));
          V v_t_2419;
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_start_241, 0)) == ((int64_t)45ULL))) {
            v_t_2419 = heff_intSub(MK_INT(0LL), v_n_2417);
          } else {
            v_t_2419 = v_n_2417;
          }
          V v_f_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_JInt, 1, (V[]){v_t_2419}), v_end_248});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2420}});
        }
      } else {
        heff_drop(v_hasExponent_247);
        double v_t_2421 = (g_json_2efloatOf_w(v_s_240, v_start_241, v_d_242, v_p_243, v_f_245, heff_dup(v_end_248)));
        V v_f_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_JFloat, 1, 1u, (V[]){heff_word_f64(v_t_2421)}), v_end_248});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2422}});
      }
    }
  }
}
HEFF_LIT(g_json_2enumberAt_24cpr_str0, 7, "a value");
HEFF_LIT(g_json_2enumberAt_24cpr_str1, 7, "a digit");
HEFF_LIT(g_json_2enumberAt_24cpr_str2, 7, "a value");
HEFF_LIT(g_json_2enumberAt_24cpr_str3, 7, "a digit");

HeffT2 g_json_2enumberAt_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_d_243;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)45ULL))) {
    v_d_243 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL));
  } else {
    v_d_243 = heff_dup(v_i_241);
  }
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_d_243, 0)) == ((int64_t)48ULL))) {
    return ({ V a_0 = v_s_240; V a_1 = v_i_241; V a_2 = heff_dup(v_d_243); V a_3 = heff_intAdd(v_d_243, MK_INT(1LL)); HeffT2 r_ = (g_json_2enumberAfterDigits_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_i_241); r_; });
  } else {
    V v_c_245 = heff_strByteAt_lent(v_s_240, v_d_243, 0);
    if ((((int64_t)48ULL) <= heff_peek_word(v_c_245))) {
      if ((heff_unbox_word(v_c_245) <= ((int64_t)57ULL))) {
        V v_t_248 = (g_json_2edigitsEnd(v_s_240, heff_dup(v_d_243)));
        return ({ V a_0 = v_s_240; V a_1 = v_i_241; V a_2 = v_d_243; V a_3 = v_t_248; HeffT2 r_ = (g_json_2enumberAfterDigits_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_i_241); r_; });
      } else {
        V v_t_2410;
        if (heff_intEq_c_lent(v_d_243, v_i_241, 2)) {
          v_t_2410 = ((V)&g_json_2enumberAt_24cpr_str0);
        } else {
          v_t_2410 = ((V)&g_json_2enumberAt_24cpr_str1);
        }
        V v_f_2411 = heff_tag_n(TAG_Expected, 2, (V[]){v_d_243, v_t_2410});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      }
    } else {
      heff_drop(v_c_245);
      V v_t_2413;
      if (heff_intEq_c_lent(v_d_243, v_i_241, 2)) {
        v_t_2413 = ((V)&g_json_2enumberAt_24cpr_str2);
      } else {
        v_t_2413 = ((V)&g_json_2enumberAt_24cpr_str3);
      }
      V v_f_2414 = heff_tag_n(TAG_Expected, 2, (V[]){v_d_243, v_t_2413});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
    }
  }
}
Clo g_json_2ehexValue_clo = {{0x80000000u, K_CLO, 0}, g_json_2ehexValue_entry, 1, 0};

V g_json_2ehexValue(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_t_242 = heff_bool(((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    return heff_box_word((v_c_240 - ((int64_t)48ULL)));
  } else {
    heff_drop(v_t_242);
    if ((((int64_t)97ULL) <= v_c_240)) {
      if ((v_c_240 <= ((int64_t)102ULL))) {
        return heff_box_word((v_c_240 - ((int64_t)87ULL)));
      } else {
        if ((((int64_t)65ULL) <= v_c_240)) {
          if ((v_c_240 <= ((int64_t)70ULL))) {
            return heff_intSub(heff_box_word(v_c_240), MK_INT(55LL));
          } else {
            return MK_INT(-65536LL);
          }
        } else {
          return MK_INT(-65536LL);
        }
      }
    } else {
      if ((((int64_t)65ULL) <= v_c_240)) {
        if ((v_c_240 <= ((int64_t)70ULL))) {
          return heff_box_word((v_c_240 - ((int64_t)55ULL)));
        } else {
          return MK_INT(-65536LL);
        }
      } else {
        return MK_INT(-65536LL);
      }
    }
  }
}
V g_json_2ehexValue_entry(V self, V *a) {
  (void)self;
  return g_json_2ehexValue(a[0]);
}
Clo g_json_2ehex4_clo = {{0x80000000u, K_CLO, 0}, g_json_2ehex4_entry, 2, 0};

V g_json_2ehex4(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = (g_json_2ehexValue(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
  V v_t_243 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
  V v_t_244 = (g_json_2ehexValue(v_t_243));
  V v_t_245 = heff_intAdd(heff_intMul(v_t_242, MK_INT(4096LL)), heff_intMul(v_t_244, MK_INT(256LL)));
  V v_t_246 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)));
  V v_t_247 = (g_json_2ehexValue(v_t_246));
  V v_t_248 = heff_intAdd(v_t_245, heff_intMul(v_t_247, MK_INT(16LL)));
  V v_t_249 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(3LL)));
  V v_t_2410 = (g_json_2ehexValue(v_t_249));
  return heff_intAdd(v_t_248, v_t_2410);
}
V g_json_2ehex4_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2ehex4(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2eunicodeEscape_24cpr_str0, 23, "four hexadecimal digits");

HeffT2 g_json_2eunicodeEscape_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = (g_json_2ehex4(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
  V v_lo_243 = (g_json_2ehex4(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(7LL))));
  if (heff_intLt_c_lent(v_c_242, MK_INT(0LL), 2)) {
    heff_drop(v_c_242);
    heff_drop(v_lo_243);
    V v_f_245 = heff_tag_n(TAG_Expected, 2, (V[]){heff_intAdd(v_i_241, MK_INT(1LL)), ((V)&g_json_2eunicodeEscape_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
  } else {
    if (heff_intLe_c_lent(MK_INT(55296LL), v_c_242, 1)) {
      if (heff_intLt_c_lent(v_c_242, MK_INT(56320LL), 2)) {
        V v_t_248 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(5LL)));
        if ((heff_unbox_word(v_t_248) == ((int64_t)92ULL))) {
          V v_t_2410 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(6LL)));
          if ((heff_unbox_word(v_t_2410) == ((int64_t)117ULL))) {
            if (heff_intLe_c_lent(MK_INT(56320LL), v_lo_243, 1)) {
              if (heff_intLt_c_lent(v_lo_243, MK_INT(57344LL), 2)) {
                int64_t v_t_2414 = ((heff_unbox_word(v_c_242) - ((int64_t)55296ULL)) * ((int64_t)1024ULL));
                int64_t v_t_2415 = ((((int64_t)65536ULL) + v_t_2414) + (heff_unbox_word(v_lo_243) - ((int64_t)56320ULL)));
                V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(heff_box_word(v_t_2415)), NTAG(TAG_Nil)});
                V v_f_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strOfRunes(v_t_2416), heff_intAdd(v_i_241, MK_INT(11LL))});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2417}});
              } else {
                heff_drop(v_lo_243);
                V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_c_242), NTAG(TAG_Nil)});
                V v_f_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strOfRunes(v_t_2418), heff_intAdd(v_i_241, MK_INT(5LL))});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2419}});
              }
            } else {
              heff_drop(v_lo_243);
              V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_c_242), NTAG(TAG_Nil)});
              V v_f_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strOfRunes(v_t_2420), heff_intAdd(v_i_241, MK_INT(5LL))});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2421}});
            }
          } else {
            heff_drop(v_lo_243);
            V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_c_242), NTAG(TAG_Nil)});
            V v_f_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strOfRunes(v_t_2422), heff_intAdd(v_i_241, MK_INT(5LL))});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2423}});
          }
        } else {
          heff_drop(v_lo_243);
          V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_c_242), NTAG(TAG_Nil)});
          V v_f_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strOfRunes(v_t_2424), heff_intAdd(v_i_241, MK_INT(5LL))});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2425}});
        }
      } else {
        heff_drop(v_lo_243);
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_c_242), NTAG(TAG_Nil)});
        V v_f_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strOfRunes(v_t_2426), heff_intAdd(v_i_241, MK_INT(5LL))});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2427}});
      }
    } else {
      heff_drop(v_lo_243);
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_c_242), NTAG(TAG_Nil)});
      V v_f_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strOfRunes(v_t_2428), heff_intAdd(v_i_241, MK_INT(5LL))});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2429}});
    }
  }
}
HEFF_LIT(g_json_2eescapeText_24cpr_str0, 1, "\"");
HEFF_LIT(g_json_2eescapeText_24cpr_str1, 1, "\\");
HEFF_LIT(g_json_2eescapeText_24cpr_str2, 1, "/");
HEFF_LIT(g_json_2eescapeText_24cpr_str3, 1, "\012");
HEFF_LIT(g_json_2eescapeText_24cpr_str4, 1, "\011");
HEFF_LIT(g_json_2eescapeText_24cpr_str5, 1, "\015");
HEFF_LIT(g_json_2eescapeText_24cpr_str6, 1, "\010");
HEFF_LIT(g_json_2eescapeText_24cpr_str7, 1, "\014");
HEFF_LIT(g_json_2eescapeText_24cpr_str8, 9, "an escape");

HeffT2 g_json_2eescapeText_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if ((heff_peek_word(v_c_242) == ((int64_t)34ULL))) {
    heff_drop(v_c_242);
    V v_f_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str0), heff_intAdd(v_i_241, MK_INT(1LL))});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_244}});
  } else {
    if ((heff_peek_word(v_c_242) == ((int64_t)92ULL))) {
      heff_drop(v_c_242);
      V v_f_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str1), heff_intAdd(v_i_241, MK_INT(1LL))});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_246}});
    } else {
      if ((heff_peek_word(v_c_242) == ((int64_t)47ULL))) {
        heff_drop(v_c_242);
        V v_f_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str2), heff_intAdd(v_i_241, MK_INT(1LL))});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_248}});
      } else {
        if ((heff_peek_word(v_c_242) == ((int64_t)110ULL))) {
          heff_drop(v_c_242);
          V v_f_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str3), heff_intAdd(v_i_241, MK_INT(1LL))});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2410}});
        } else {
          if ((heff_peek_word(v_c_242) == ((int64_t)116ULL))) {
            heff_drop(v_c_242);
            V v_f_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str4), heff_intAdd(v_i_241, MK_INT(1LL))});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2412}});
          } else {
            if ((heff_peek_word(v_c_242) == ((int64_t)114ULL))) {
              heff_drop(v_c_242);
              V v_f_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str5), heff_intAdd(v_i_241, MK_INT(1LL))});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2414}});
            } else {
              if ((heff_peek_word(v_c_242) == ((int64_t)98ULL))) {
                heff_drop(v_c_242);
                V v_f_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str6), heff_intAdd(v_i_241, MK_INT(1LL))});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2416}});
              } else {
                if ((heff_peek_word(v_c_242) == ((int64_t)102ULL))) {
                  heff_drop(v_c_242);
                  V v_f_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_json_2eescapeText_24cpr_str7), heff_intAdd(v_i_241, MK_INT(1LL))});
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2418}});
                } else {
                  if ((heff_unbox_word(v_c_242) == ((int64_t)117ULL))) {
                    HEFF_LAST return g_json_2eunicodeEscape_24cpr(v_s_240, v_i_241);
                  } else {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2eescapeText_24cpr_str8)})}});
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_json_2estringFrom_str0, 3, "'\"'");
HEFF_LIT(g_json_2estringFrom_str1, 31, "a character, or an escape of it");
Clo g_json_2estringFrom_clo = {{0x80000000u, K_CLO, 0}, g_json_2estringFrom_entry, 4, 0};

V g_json_2estringFrom(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  V v_c_244 = heff_strByteAt_lent(v_s_240, v_i_242, 0);
  if ((heff_peek_word(v_c_244) == ((int64_t)34ULL))) {
    heff_drop(v_c_244);
    V v_t_246 = heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 2));
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_i_242, MK_INT(1LL))});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_247});
  } else {
    if ((heff_peek_word(v_c_244) == ((int64_t)92ULL))) {
      heff_drop(v_c_244);
      HeffT2 v_t_249 = (g_json_2eescapeText_24cpr(v_s_240, heff_intAdd(heff_dup(v_i_242), MK_INT(1LL))));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop(v_start_241);
          heff_drop(v_i_242);
          heff_drop(v_acc_243);
          V v_e_2413 = v_field_2411;
          return heff_tag_n(TAG_Left, 1, (V[]){v_e_2413});
        } else {
          V v_it1_2414 = v_field_2411;
          switch (heff_tag_of(v_it1_2414)) {
          case TAG_MkPair: {
            V v_t_2415 = heff_field(v_it1_2414, 0);
            V v_j_2416 = heff_field(v_it1_2414, 1);
            heff_take_n(v_it1_2414, 3ULL, 2);
            V v_t_2417 = heff_strAppend(heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 6), v_t_2415);
            V t_0 = v_s_240;
            V t_1 = heff_dup(v_j_2416);
            V t_2 = v_j_2416;
            V t_3 = heff_strAppend(v_acc_243, v_t_2417);
            v_s_240 = t_0;
            v_start_241 = t_1;
            v_i_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          }
          default: return heff_nomatch(v_it1_2414);
          }
        }
      }
    } else {
      if ((heff_peek_word(v_c_244) < ((int64_t)0ULL))) {
        heff_drop(v_start_241);
        heff_drop(v_acc_243);
        heff_drop(v_c_244);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2estringFrom_str0)})});
      } else {
        if ((heff_unbox_word(v_c_244) < ((int64_t)32ULL))) {
          heff_drop(v_start_241);
          heff_drop(v_acc_243);
          return heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2estringFrom_str1)})});
        } else {
          V t_0 = v_s_240;
          V t_1 = v_start_241;
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_acc_243;
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_i_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
  }
}
V g_json_2estringFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2estringFrom(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2ecolonThen_str0, 3, "':'");
Clo g_json_2ecolonThen_clo = {{0x80000000u, K_CLO, 0}, g_json_2ecolonThen_entry, 4, 0};

V g_json_2ecolonThen(V v_s_240, V v_fs_241, V v_frames_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Left = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_fs_241);
    heff_drop(v_frames_242);
    return heff_tag_at_n(v_ru_24x4_243_24Left, TAG_Failed, 1, (V[]){v_e_244});
  }
  case TAG_Right: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Right = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_k_246 = heff_field(v_x41_245, 0);
      V v_j_247 = heff_field(v_x41_245, 1);
      V v_ru_24x41_245_24MkPair = heff_take_reuse_n(v_x41_245, 3ULL, 2);
      V v_c_248 = (g_json_2eskipSpace(v_s_240, v_j_247));
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_c_248, 0)) == ((int64_t)58ULL))) {
        heff_drop_cell(v_ru_24x4_243_24Right, 1);
        V v_t_2410 = heff_tag_at_n(v_ru_24x41_245_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_InObject, 2, (V[]){v_fs_241, v_k_246}), v_frames_242});
        return heff_tag_n(TAG_Value, 2, (V[]){heff_intAdd(v_c_248, MK_INT(1LL)), v_t_2410});
      } else {
        heff_drop(v_fs_241);
        heff_drop(v_frames_242);
        heff_drop(v_k_246);
        heff_drop_cell(v_ru_24x41_245_24MkPair, 2);
        return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_c_248, ((V)&g_json_2ecolonThen_str0)})});
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_json_2ecolonThen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2ecolonThen(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2ekeyThen_str0, 0, "");
HEFF_LIT(g_json_2ekeyThen_str1, 8, "a string");
HEFF_LIT(g_json_2ekeyThen_str2, 8, "a string");
Clo g_json_2ekeyThen_clo = {{0x80000000u, K_CLO, 0}, g_json_2ekeyThen_entry, 4, 0};

V g_json_2ekeyThen(V v_s_240, V v_i_241, V v_fs_242, V v_frames_243) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
    V v_t_246;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
      v_t_246 = (g_json_2estringFrom(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_intAdd(v_i_241, MK_INT(1LL)), ((V)&g_json_2ekeyThen_str0)));
    } else {
      v_t_246 = heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2ekeyThen_str1)})});
    }
    HEFF_LAST return g_json_2ecolonThen(v_s_240, v_fs_242, v_frames_243, v_t_246);
  } else {
    heff_drop(v_fs_242);
    heff_drop(v_frames_243);
    return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2ekeyThen_str2)})});
  }
}
V g_json_2ekeyThen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2ekeyThen(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2evalueAt_str0, 0, "");
HEFF_LIT(g_json_2evalueAt_str1, 8, "a string");
HEFF_LIT(g_json_2evalueAt_str2, 4, "null");
HEFF_LIT(g_json_2evalueAt_str3, 7, "a value");
HEFF_LIT(g_json_2evalueAt_str4, 4, "true");
HEFF_LIT(g_json_2evalueAt_str5, 7, "a value");
HEFF_LIT(g_json_2evalueAt_str6, 5, "false");
HEFF_LIT(g_json_2evalueAt_str7, 7, "a value");
Clo g_json_2evalueAt_clo = {{0x80000000u, K_CLO, 0}, g_json_2evalueAt_entry, 3, 0};

V g_json_2evalueAt(V v_s_240, V v_i_241, V v_frames_242) {
top: ;
  V v_c_243 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if ((heff_peek_word(v_c_243) == ((int64_t)34ULL))) {
    heff_drop(v_c_243);
    V v_x3_246;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
      v_x3_246 = (g_json_2estringFrom(v_s_240, heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_intAdd(v_i_241, MK_INT(1LL)), ((V)&g_json_2evalueAt_str0)));
    } else {
      v_x3_246 = heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2evalueAt_str1)})});
    }
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Left = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      heff_drop(v_frames_242);
      return heff_tag_at_n(v_ru_24x3_246_24Left, TAG_Failed, 1, (V[]){v_e_247});
    }
    case TAG_Right: {
      V v_x31_248 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Right = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      switch (heff_tag_of(v_x31_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x31_248, 0);
        V v_j_2410 = heff_field(v_x31_248, 1);
        heff_take_n(v_x31_248, 3ULL, 2);
        return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_at_n(v_ru_24x3_246_24Right, TAG_JString, 1, (V[]){v_x_249}), v_j_2410, v_frames_242});
      }
      default: return heff_nomatch(v_x31_248);
      }
    }
    default: return heff_nomatch(v_x3_246);
    }
  } else {
    if ((heff_peek_word(v_c_243) == ((int64_t)123ULL))) {
      heff_drop(v_c_243);
      V v_j_2412 = (g_json_2eskipSpace(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL))));
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2412, 0)) == ((int64_t)125ULL))) {
        V v_t_2414 = heff_tag_n(TAG_JObject, 1, (V[]){NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Got, 3, (V[]){v_t_2414, heff_intAdd(v_j_2412, MK_INT(1LL)), v_frames_242});
      } else {
        return (g_json_2ekeyThen(v_s_240, v_j_2412, NTAG(TAG_Nil), v_frames_242));
      }
    } else {
      if ((heff_peek_word(v_c_243) == ((int64_t)91ULL))) {
        heff_drop(v_c_243);
        V v_j_2416 = (g_json_2eskipSpace(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL))));
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2416, 0)) == ((int64_t)93ULL))) {
          V v_t_2418 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Got, 3, (V[]){v_t_2418, heff_intAdd(v_j_2416, MK_INT(1LL)), v_frames_242});
        } else {
          V v_t_2419 = heff_tag_n(TAG_InArray, 1, (V[]){NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Value, 2, (V[]){v_j_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_frames_242})});
        }
      } else {
        if ((heff_peek_word(v_c_243) == ((int64_t)110ULL))) {
          heff_drop(v_c_243);
          V v_t_2421 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(4LL)));
          if (heff_strEq_c(v_t_2421, ((V)&g_json_2evalueAt_str2))) {
            return heff_tag_n(TAG_Got, 3, (V[]){NTAG(TAG_JNull), heff_intAdd(v_i_241, MK_INT(4LL)), v_frames_242});
          } else {
            heff_drop(v_frames_242);
            return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2evalueAt_str3)})});
          }
        } else {
          if ((heff_peek_word(v_c_243) == ((int64_t)116ULL))) {
            heff_drop(v_c_243);
            V v_t_2424 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(4LL)));
            if (heff_strEq_c(v_t_2424, ((V)&g_json_2evalueAt_str4))) {
              V v_t_2426 = heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
              return heff_tag_n(TAG_Got, 3, (V[]){v_t_2426, heff_intAdd(v_i_241, MK_INT(4LL)), v_frames_242});
            } else {
              heff_drop(v_frames_242);
              return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2evalueAt_str5)})});
            }
          } else {
            if ((heff_unbox_word(v_c_243) == ((int64_t)102ULL))) {
              V v_t_2428 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(5LL)));
              if (heff_strEq_c(v_t_2428, ((V)&g_json_2evalueAt_str6))) {
                V v_t_2430 = heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
                return heff_tag_n(TAG_Got, 3, (V[]){v_t_2430, heff_intAdd(v_i_241, MK_INT(5LL)), v_frames_242});
              } else {
                heff_drop(v_frames_242);
                return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2evalueAt_str7)})});
              }
            } else {
              HeffT2 v_t_2431 = (g_json_2enumberAt_24cpr(v_s_240, v_i_241));
              {
                V v_field_2433 = v_t_2431.f[1];
                int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
                if ((v_tag_2432 == ((int64_t)0ULL))) {
                  heff_drop(v_frames_242);
                  V v_e_2435 = v_field_2433;
                  return heff_tag_n(TAG_Failed, 1, (V[]){v_e_2435});
                } else {
                  V v_x31_2436 = v_field_2433;
                  switch (heff_tag_of(v_x31_2436)) {
                  case TAG_MkPair: {
                    V v_x_2437 = heff_field(v_x31_2436, 0);
                    V v_j_2438 = heff_field(v_x31_2436, 1);
                    heff_take_n(v_x31_2436, 3ULL, 2);
                    return heff_tag_n(TAG_Got, 3, (V[]){v_x_2437, v_j_2438, v_frames_242});
                  }
                  default: return heff_nomatch(v_x31_2436);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_json_2evalueAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2evalueAt(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2egotIn_str0, 10, "',' or ']'");
HEFF_LIT(g_json_2egotIn_str1, 10, "',' or '}'");
Clo g_json_2egotIn_clo = {{0x80000000u, K_CLO, 0}, g_json_2egotIn_entry, 5, 0};

V g_json_2egotIn(V v_s_240, V v_v_241, V v_i_242, V v_x4_243, V v_frames_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_InArray: {
    V v_xs_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24InArray = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)44ULL))) {
      V v_t_247 = heff_tag_at_n(v_ru_24x4_243_24InArray, TAG_InArray, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_241, v_xs_245})});
      return heff_tag_n(TAG_Value, 2, (V[]){heff_intAdd(v_i_242, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_frames_244})});
    } else {
      heff_drop_cell(v_ru_24x4_243_24InArray, 1);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)93ULL))) {
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_v_241, v_xs_245})));
        return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_n(TAG_JArray, 1, (V[]){v_t_249}), heff_intAdd(v_i_242, MK_INT(1LL)), v_frames_244});
      } else {
        heff_drop(v_v_241);
        heff_drop(v_frames_244);
        heff_drop(v_xs_245);
        return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2egotIn_str0)})});
      }
    }
  }
  case TAG_InObject: {
    V v_fs_2410 = heff_field(v_x4_243, 0);
    V v_k_2411 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24InObject = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)44ULL))) {
      V v_t_2413 = (g_json_2eskipSpace(v_s_240, heff_intAdd(v_i_242, MK_INT(1LL))));
      V v_t_2414 = heff_tag_at_n(v_ru_24x4_243_24InObject, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2411, v_v_241}), v_fs_2410});
      return (g_json_2ekeyThen(v_s_240, v_t_2413, v_t_2414, v_frames_244));
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)125ULL))) {
        V v_t_2416 = heff_tag_at_n(v_ru_24x4_243_24InObject, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2411, v_v_241}), v_fs_2410});
        V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2416));
        return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2417}), heff_intAdd(v_i_242, MK_INT(1LL)), v_frames_244});
      } else {
        heff_drop(v_v_241);
        heff_drop(v_frames_244);
        heff_drop(v_fs_2410);
        heff_drop(v_k_2411);
        return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24InObject, TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2egotIn_str1)})});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_json_2egotIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2egotIn(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2esteps_24cpr_str0, 7, "the end");

HeffT2 g_json_2esteps_24cpr(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Value: {
    V v_i_242 = heff_field(v_x2_241, 0);
    V v_frames_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_json_2eskipSpace(v_s_240, v_i_242));
    V v_t_245 = (g_json_2evalueAt(v_s_240, v_t_244, v_frames_243));
    V t_0 = v_s_240;
    V t_1 = v_t_245;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_Got: {
    V v_v_246 = heff_field(v_x2_241, 0);
    V v_i_247 = heff_field(v_x2_241, 1);
    V v_frames_248 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_i_249 = (g_json_2eskipSpace(v_s_240, v_i_247));
    V v_t_2413;
    switch (heff_tag_of(v_frames_248)) {
    case TAG_Nil: {
      if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_249))) {
        heff_drop(v_i_249);
        v_t_2413 = heff_tag_n(TAG_Finished, 1, (V[]){v_v_246});
      } else {
        heff_drop(v_v_246);
        v_t_2413 = heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_249, ((V)&g_json_2esteps_24cpr_str0)})});
      }
      break;
    }
    case TAG_Cons: {
      V v_f_2411 = heff_field(v_frames_248, 0);
      V v_frames_2412 = heff_field(v_frames_248, 1);
      heff_take_n(v_frames_248, 3ULL, 2);
      v_t_2413 = (g_json_2egotIn(v_s_240, v_v_246, v_i_249, v_f_2411, v_frames_2412));
      break;
    }
    default: heff_nomatch(v_frames_248);
    }
    V t_0 = v_s_240;
    V t_1 = v_t_2413;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_Finished: {
    V v_v_2414 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_v_2414}});
  }
  case TAG_Failed: {
    V v_e_2415 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2415}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_json_2eat_24cpr(V v_x1_240, V v_j_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_j_241}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ks_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_j_241)) {
    case TAG_JNull: {
      heff_drop(v_k_242);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_j_241, 0ULL, 1);
      heff_drop(v_k_242);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_j_241, 0ULL, 1);
      heff_drop(v_k_242);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_j_241, 0ULL, 1);
      heff_drop(v_k_242);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_j_241, 0ULL, 1);
      heff_drop(v_k_242);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_j_241, 0ULL, 1);
      heff_drop(v_k_242);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_249 = heff_field(v_j_241, 0);
      V v_ru_24j_241_24JObject = heff_take_reuse_n(v_j_241, 1ULL, 1);
      HeffT2 v_t_2410 = ({ V a_0 = v_k_242; V a_1 = v_fs_249; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(a_0, a_1)); heff_drop(v_k_242); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_p_2414 = v_field_2412;
          V v_t_2417;
          switch (heff_tag_of(v_p_2414)) {
          case TAG_MkPair: {
            V v_y_2416 = heff_field(v_p_2414, 1);
            heff_take_n(v_p_2414, 2ULL, 2);
            v_t_2417 = v_y_2416;
            break;
          }
          default: heff_nomatch(v_p_2414);
          }
          v_t_2418 = heff_tag_at_n(v_ru_24j_241_24JObject, TAG_Just, 1, (V[]){v_t_2417});
        } else {
          heff_drop_cell(v_ru_24j_241_24JObject, 1);
          heff_drop(v_field_2412);
          v_t_2418 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_j_241);
    }
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      heff_drop(v_ks_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_v_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      V t_0 = v_ks_243;
      V t_1 = v_v_2419;
      v_x1_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2418)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}