// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define LBL_arity 294440695
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_callers 780494982
#define LBL_changed 970801394
#define LBL_dirty 296951788
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_hoped 300822210
#define LBL_imps 9731822
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_params 951713969
#define LBL_result 1012715336
#define LBL_round 310062504
#define LBL_sigs 10025609
static uint32_t shape_changed__imps[] = {LBL_changed, LBL_imps};
static uint32_t shape_facts__base__imps__hoped__callers[] = {LBL_facts, LBL_base, LBL_imps, LBL_hoped, LBL_callers};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_round__dirty[] = {LBL_round, LBL_dirty};
static uint32_t shape_sigs__flat[] = {LBL_sigs, LBL_flat};
static uint32_t shape_sigs__imps[] = {LBL_sigs, LBL_imps};
HeffT2 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eranges_2ewordPrims_get(void);
HeffT2 g_heff_2ecompile_2erepr_2ehopeSig_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V, V, V, V);
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_heff_2ecompile_2eworker_2ecycleOf(V, V);
V g_heff_2ecompile_2eworker_2ecycleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ecycleOf_clo;
V g_heff_2ecompile_2eworker_2efallDirty(V, V);
V g_heff_2ecompile_2eworker_2efallDirty_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efallDirty_clo;
V g_heff_2ecompile_2eworker_2efallDirtyAll(V);
V g_heff_2ecompile_2eworker_2efallDirtyAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efallDirtyAll_clo;
V g_heff_2ecompile_2eworker_2efallImp(V, V, V, V, V, V);
V g_heff_2ecompile_2eworker_2efallImp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efallImp_clo;
V g_heff_2ecompile_2eworker_2efallen(V);
V g_heff_2ecompile_2eworker_2efallen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efallen_clo;
V g_heff_2ecompile_2eworker_2efalls(V, V, V, V);
V g_heff_2ecompile_2eworker_2efalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efalls_clo;
V g_heff_2ecompile_2eworker_2ehopeOne(V, V, V, V);
V g_heff_2ecompile_2eworker_2ehopeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ehopeOne_clo;
V g_heff_2ecompile_2eworker_2ehopingWith(V, V, V);
V g_heff_2ecompile_2eworker_2ehopingWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ehopingWith_clo;
V g_heff_2ecompile_2eworker_2eimpIn(V, V);
V g_heff_2ecompile_2eworker_2eimpIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eimpIn_clo;
V g_heff_2ecompile_2eworker_2ejumpsOf(V, V);
V g_heff_2ecompile_2eworker_2ejumpsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ejumpsOf_clo;
V g_heff_2ecompile_2eworker_2emeetCycles(V, V);
V g_heff_2ecompile_2eworker_2emeetCycles_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2emeetCycles_clo;
V g_heff_2ecompile_2eworker_2emeetIn(V, V, V);
V g_heff_2ecompile_2eworker_2emeetIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2emeetIn_clo;
V g_heff_2ecompile_2eworker_2enextOf(V, V, V);
V g_heff_2ecompile_2eworker_2enextOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enextOf_clo;
V g_heff_2ecompile_2eworker_2enumericPrim(V);
V g_heff_2ecompile_2eworker_2enumericPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericPrim_clo;
V g_heff_2ecompile_2eworker_2enumericW(V);
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericW_clo;
V g_heff_2ecompile_2eworker_2ereachGo(V, V, V);
V g_heff_2ecompile_2eworker_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ereachGo_clo;
V g_heff_2ecompile_2eworker_2erounds(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2erounds_clo;
V g_heff_2ecompile_2eworker_2etailCalls(V);
V g_heff_2ecompile_2eworker_2etailCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2etailCalls_clo;
V g_heff_2ecompile_2eworker_2eweighImp(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eweighImp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eweighImp_clo;
V g_heff_2ecompile_2eworker_2eweighOne(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eweighOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eweighOne_clo;
V g_heff_2ecompile_2eworker_2eweighedWith(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eweighedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eweighedWith_clo;
V g_heff_2ecompile_2eworker_2ewithSig(V, V, V);
V g_heff_2ecompile_2eworker_2ewithSig_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ewithSig_clo;
V g_heff_2ecompile_2eworker_2eworkers(V, V);
V g_heff_2ecompile_2eworker_2eworkers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eworkers_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2eany_24s469347062x492258493(V);
V g_list_2eany_24s469347062x492258493_entry(V self, V *a);
extern Clo g_list_2eany_24s469347062x492258493_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1418838819x1907320638(V, V);
V g_list_2efoldl_24s1418838819x1907320638_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1418838819x1907320638_clo;
V g_list_2efoldl_24s1885006984x1134653659(V, V);
V g_list_2efoldl_24s1885006984x1134653659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1885006984x1134653659_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s2086705387x1592057803(V, V, V, V, V);
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2086705387x1592057803_clo;
V g_list_2efoldl_24s2103009317x1481930218(V, V);
V g_list_2efoldl_24s2103009317x1481930218_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2103009317x1481930218_clo;
V g_list_2efoldl_24s319398146x1205310166(V, V, V, V);
V g_list_2efoldl_24s319398146x1205310166_entry(V self, V *a);
extern Clo g_list_2efoldl_24s319398146x1205310166_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s740336339x1862813792(V, V);
V g_list_2efoldl_24s740336339x1862813792_entry(V self, V *a);
extern Clo g_list_2efoldl_24s740336339x1862813792_clo;
V g_list_2efoldl_24s932544939x1448830416(V, V);
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1300907700x23410576(V);
V g_list_2emap_24f1300907700x23410576_entry(V self, V *a);
extern Clo g_list_2emap_24f1300907700x23410576_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1448987994x473765958(V, V);
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_clo;
V g_list_2ezipWith_24s151204990x680105425(V, V);
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2eworker_2enumericPrim_str0, 4, "word");
Clo g_heff_2ecompile_2eworker_2enumericPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2enumericPrim_entry, 1, 0};

V g_heff_2ecompile_2eworker_2enumericPrim(V v_p_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_242 == ((int64_t)0ULL)) && ({ V v_x11_245 = heff_dup(v_field_243); int c_ = ((((int64_t)4ULL) < heff_unbox_word(heff_strLength_lent(v_p_240, 0))) ? (heff_strEq_c(heff_strSlice_lent(v_p_240, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2ecompile_2eworker_2enumericPrim_str0)) ? ({ V v_x1_248 = ({ V a_0 = v_p_240; V b_1 = heff_dup(g_heff_2ecompile_2eranges_2ewordPrims_get()); V r_ = (g_list_2eany_24s1230506745x754542351(a_0, b_1)); heff_drop(b_1); r_; }); int c_ = !(heff_dup(v_x1_248) == NTAG(TAG_True)); heff_drop(v_x1_248); c_; }) : 1) : 1); heff_drop(v_x11_245); c_; })));
    heff_drop(v_field_243);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eworker_2enumericPrim_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2enumericPrim(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eworker_2enumericW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2enumericW_entry, 1, 0};

V g_heff_2ecompile_2eworker_2enumericW(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELam: {
      V v_b_246 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 2);
      V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_246, v_x12_242});
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EApp: {
      V v_f_247 = heff_field(v_x11_241, 0);
      V v_args_248 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      V v_t_249 = (g_heff_2ecompile_2eir_2eappendI(v_args_248, v_x12_242));
      V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_f_247, v_t_249});
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2411 = heff_field(v_x11_241, 1);
      V v_b_2412 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 6ULL, 3);
      V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2412, v_x12_242})});
      V t_0 = v_t_2413;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2414 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2416 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2414, v_x12_242));
      V t_0 = v_t_2416;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2417 = heff_field(v_x11_241, 0);
      V v_t_2420 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 9ULL, 4);
      switch (heff_tag_of(v_t_2420)) {
      case TAG_FtFloat: {
        heff_drop(v_x12_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_e_2417);
        return NTAG(TAG_True);
      }
      case TAG_FtFixed: {
        heff_take_n(v_t_2420, 0ULL, 1);
        heff_drop(v_x12_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_e_2417);
        return NTAG(TAG_True);
      }
      case TAG_FtOther: {
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_e_2417, v_x12_242});
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_FtAny: {
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_e_2417, v_x12_242});
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_t_2420);
      }
    }
    case TAG_ETag: {
      V v_args_2423 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI(v_args_2423, v_x12_242));
      V t_0 = v_t_2425;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2426 = heff_field(v_x11_241, 0);
      V v_arms_2427 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_x12_242));
      V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_2426, v_t_2428});
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_p_2430 = heff_field(v_x11_241, 0);
      V v_args_2431 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2432 = ({ V a_0 = v_p_2430; V r_ = (g_heff_2ecompile_2eworker_2enumericPrim(a_0)); heff_drop(v_p_2430); r_; });
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_x12_242);
        heff_drop(v_args_2431);
        heff_drop(v_t_2432);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2432);
        V v_t_2433 = (g_heff_2ecompile_2eir_2eappendI(v_args_2431, v_x12_242));
        V t_0 = v_t_2433;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_ECall: {
      V v_args_2435 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2436 = (g_heff_2ecompile_2eir_2eappendI(v_args_2435, v_x12_242));
      V t_0 = v_t_2436;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2enumericW(a[0]);
}
Clo g_heff_2ecompile_2eworker_2eimpIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2eimpIn_entry, 2, 0};

V g_heff_2ecompile_2eworker_2eimpIn(V v_imps_240, V v_d_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_imps_240, heff_rfield(v_d_241, 0)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_241, 3);
      V v_md_246 = v_field_244;
      return v_md_246;
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), heff_take_field(v_d_241, 2)));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_b_2410 = v_field_248;
        V v_n_2411 = v_field_249;
        V v_t_2412 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
        V v_t_2413 = ({ V rv_2 = v_b_2410; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        HeffT2 v_t_2414 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2412, v_t_2413, v_n_2411));
        {
          V v_field_2415 = v_t_2414.f[0];
          V v_field_2416 = v_t_2414.f[1];
          V v_x_2417 = v_field_2415;
          V v_y_2418 = v_field_2416;
          heff_drop(v_y_2418);
          return v_x_2417;
        }
      }
    }
  }
}
V g_heff_2ecompile_2eworker_2eimpIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2eimpIn(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eworker_2eweighedWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2eweighedWith_entry, 5, 0};

V g_heff_2ecompile_2eworker_2eweighedWith(V v_acc_240, V v_k_241, V v_md_242, V v_old_243, V v_new_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2erepr_2ereprsEq(heff_rfield(v_old_243, 0), heff_rfield(v_new_244, 0)));
  V v_t_247;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = ({ V b_0 = heff_get_n(v_old_243, 1, 2); V a_1 = heff_rfield(v_new_244, 1); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop_rec(v_new_244, 2);
      heff_drop(v_t_246);
      v_t_247 = heff_dup(heff_rfield(v_acc_240, 0));
    } else {
      heff_drop(v_t_246);
      v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_241), v_new_244}), heff_dup(heff_rfield(v_acc_240, 0))});
    }
  } else {
    heff_drop_rec(v_old_243, 2);
    heff_drop(v_t_245);
    v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_241), v_new_244}), heff_dup(heff_rfield(v_acc_240, 0))});
  }
  V v_t_248 = (g_std_2emap_2einsert_24s93785294x875597928(heff_get_n(v_acc_240, 1, 2), v_k_241, v_md_242));
  return heff_rec_n(2, shape_changed__imps, (V[]){v_t_247, v_t_248});
}
V g_heff_2ecompile_2eworker_2eweighedWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2eweighedWith(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2eworker_2eweighImp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2eweighImp_entry, 5, 0};

V g_heff_2ecompile_2eworker_2eweighImp(V v_facts_240, V v_sg_241, V v_acc_242, V v_k_243, V v_md_244) {
top: ;
  switch (heff_tag_of(v_md_244)) {
  case TAG_MkDef: {
    V v_md3_247 = heff_dup(heff_field(v_md_244, 2));
    switch (heff_tag_of(v_md3_247)) {
    case TAG_DefFun: {
      V v_xs_248 = heff_field(v_md3_247, 0);
      V v_md32_249 = heff_field(v_md3_247, 1);
      heff_take_n(v_md3_247, 3ULL, 2);
      switch (heff_tag_of(v_md32_249)) {
      case TAG_MkBlock: {
        V v_t_2410 = heff_field(v_md32_249, 0);
        heff_take_n(v_md32_249, 1ULL, 1);
        V v_n_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
        V v_t_2412 = (g_list_2ereplicate(v_n_2411, NTAG(TAG_RepV)));
        V v_d_2413 = heff_rec_n(2, shape_params__result, (V[]){v_t_2412, NTAG(TAG_RepV)});
        HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_sg_241, v_k_243));
        V v_t_2419;
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            heff_drop_rec(v_d_2413, 2);
            V v_x_2418 = v_field_2416;
            v_t_2419 = v_x_2418;
          } else {
            heff_drop(v_field_2416);
            v_t_2419 = v_d_2413;
          }
        }
        V v_n_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
        V v_t_2421 = (g_list_2ereplicate(v_n_2420, NTAG(TAG_RepV)));
        V v_d_2422 = heff_rec_n(2, shape_params__result, (V[]){v_t_2421, NTAG(TAG_RepV)});
        HeffT2 v_t_2423 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_sg_241, v_k_243));
        V v_t_2443;
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          V v_old_2428;
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop_rec(v_d_2422, 2);
            V v_x_2427 = v_field_2425;
            v_old_2428 = v_x_2427;
          } else {
            heff_drop(v_field_2425);
            v_old_2428 = v_d_2422;
          }
          V v_t_2429 = heff_rec_n(2, shape_sigs__flat, (V[]){v_sg_241, heff_take_field(v_facts_240, 5)});
          HeffT2 v_t_2430 = ({ V b_0 = heff_get_n(v_facts_240, 1, 10); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_2435;
          {
            V v_field_2432 = v_t_2430.f[1];
            int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
            v_t_2435 = heff_bool(((v_tag_2431 == ((int64_t)0ULL)) && ({ V v_x_2434 = heff_dup(v_field_2432); int c_ = 1; heff_drop(v_x_2434); c_; })));
            heff_drop(v_field_2432);
          }
          HeffT2 v_t_2436 = ({ V a_0 = v_t_2429; V a_1 = v_t_2435; V a_2 = v_xs_248; V a_3 = v_t_2410; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eproposeSig_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2435); r_; });
          {
            V v_field_2437 = v_t_2436.f[0];
            V v_field_2438 = v_t_2436.f[1];
            V v_t_2439 = (g_list_2ezipWith_24s1448987994x473765958(heff_take_field(v_old_2428, 0), v_field_2437));
            V v_old_2440 = heff_get_n(v_old_2428, 1, 2);
            V v_t_2442;
            switch (heff_tag_of(v_old_2440)) {
            case TAG_RepV: {
              v_t_2442 = v_field_2438;
              break;
            }
            case TAG_RepFix: {
              heff_drop(v_field_2438);
              v_t_2442 = v_old_2440;
              break;
            }
            case TAG_RepF64: {
              heff_drop(v_field_2438);
              v_t_2442 = v_old_2440;
              break;
            }
            case TAG_RepInt: {
              heff_drop(v_field_2438);
              v_t_2442 = v_old_2440;
              break;
            }
            default: heff_nomatch(v_old_2440);
            }
            v_t_2443 = heff_rec_n(2, shape_params__result, (V[]){v_t_2439, v_t_2442});
          }
        }
        HEFF_LAST return g_heff_2ecompile_2eworker_2eweighedWith(v_acc_242, v_k_243, v_md_244, v_t_2419, v_t_2443);
      }
      default: return heff_nomatch(v_md32_249);
      }
    }
    case TAG_DefVal: {
      heff_take_n(v_md3_247, 0ULL, 1);
      heff_drop_rec(v_facts_240, 10);
      heff_drop(v_sg_241);
      heff_drop(v_k_243);
      heff_drop_tag(v_md_244, 3);
      return v_acc_242;
    }
    default: return heff_nomatch(v_md3_247);
    }
  }
  default: return heff_nomatch(v_md_244);
  }
}
V g_heff_2ecompile_2eworker_2eweighImp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2eweighImp(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2eworker_2eweighOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2eweighOne_entry, 5, 0};

V g_heff_2ecompile_2eworker_2eweighOne(V v_facts_240, V v_defs_241, V v_sg_242, V v_acc_243, V v_k_244) {
top: ;
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_defs_241, v_k_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_d_249 = v_field_247;
      V v_t_2410 = heff_dup(heff_rfield(v_d_249, 2));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_EVar: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EGlobal: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_ELam: {
        heff_take_n(v_t_2410, 0ULL, 2);
        V v_t_2415 = (g_heff_2ecompile_2eworker_2eimpIn(heff_rfield(v_acc_243, 1), v_d_249));
        HEFF_LAST return g_heff_2ecompile_2eworker_2eweighImp(v_facts_240, v_sg_242, v_acc_243, v_k_244, v_t_2415);
      }
      case TAG_EApp: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_ELet: {
        heff_take_n(v_t_2410, 0ULL, 3);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_ERecord: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EProj: {
        heff_take_n(v_t_2410, 0ULL, 4);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_ETag: {
        heff_take_n(v_t_2410, 0ULL, 3);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EMatch: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EPrim: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_ECall: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EInt: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EFloat: {
        heff_take_na(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EStr: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EBytes: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EFixed: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EFloat32: {
        heff_take_na(v_t_2410, 0ULL, 1);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EAbandon: {
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      case TAG_EFix: {
        heff_take_n(v_t_2410, 0ULL, 2);
        heff_drop(v_facts_240);
        heff_drop(v_sg_242);
        heff_drop(v_k_244);
        heff_drop_rec(v_d_249, 3);
        return v_acc_243;
      }
      default: return heff_nomatch(v_t_2410);
      }
    } else {
      heff_drop(v_facts_240);
      heff_drop(v_sg_242);
      heff_drop(v_k_244);
      heff_drop(v_field_247);
      return v_acc_243;
    }
  }
}
V g_heff_2ecompile_2eworker_2eweighOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eworker_2eweighOne(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eworker_2enextOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2enextOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2enextOf_entry, 3, 0};

V g_heff_2ecompile_2eworker_2enextOf(V v_callers_240, V v_r_241, V v_w_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s591739608x1065283968(heff_get_n(v_r_241, 0, 2), heff_rfield(v_w_242, 0)));
  V v_t_244 = heff_rec_n(2, shape_sigs__imps, (V[]){v_t_243, heff_take_field(v_w_242, 1)});
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_w_242, 0, 2)));
  V v_xs_2420 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eworker_2enextOf_lam0, 2, 1, (V[]){heff_dup(v_callers_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  V v_m_2421 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  return heff_rec_n(2, shape_round__dirty, (V[]){v_t_244, v_t_2423});
}
V g_heff_2ecompile_2eworker_2enextOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2enextOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eworker_2enextOf_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_callers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_dup(heff_field(v_x_247, 0));
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_t_2413;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 2);
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  HeffT2 v_t_2414 = ({ V a_0 = v_callers_240; V a_1 = v_t_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_callers_240); heff_drop(v_t_2413); r_; });
  V v_t_2419;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2416);
      v_t_2419 = NTAG(TAG_Nil);
    }
  }
  return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2419}), v_acc_246));
}
Clo g_heff_2ecompile_2eworker_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2erounds_entry, 5, 0};

V g_heff_2ecompile_2eworker_2erounds(V v_facts_240, V v_defs_241, V v_callers_242, V v_box_24n_243, V v_nx_244) {
  int64_t v_n_243 = heff_unbox_word(v_box_24n_243);
top: ;
  if ((v_n_243 <= ((int64_t)0ULL))) {
    heff_drop(v_facts_240);
    return heff_get_n(v_nx_244, 0, 2);
  } else {
    V v_t_246 = heff_dup(heff_rfield(v_nx_244, 1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_facts_240);
      return heff_get_n(v_nx_244, 0, 2);
    }
    case TAG_Cons: {
      heff_take_n(v_t_246, 0ULL, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_nx_244, 0)), 0, 2);
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_nx_244, 0)), 1, 2);
      V v_t_2411 = heff_rec_n(2, shape_changed__imps, (V[]){NTAG(TAG_Nil), v_t_2410});
      V v_t_2412 = (g_list_2efoldl_24s2086705387x1592057803(heff_dup(v_facts_240), v_defs_241, v_t_249, v_t_2411, heff_rfield(v_nx_244, 1)));
      V v_t_2413 = (g_heff_2ecompile_2eworker_2enextOf(v_callers_242, heff_get_n(v_nx_244, 0, 2), v_t_2412));
      V t_0 = v_facts_240;
      V t_1 = v_defs_241;
      V t_2 = v_callers_242;
      int64_t t_3 = (v_n_243 - ((int64_t)1ULL));
      V t_4 = v_t_2413;
      v_facts_240 = t_0;
      v_defs_241 = t_1;
      v_callers_242 = t_2;
      v_n_243 = t_3;
      v_nx_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2ecompile_2eworker_2erounds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eworker_2erounds(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eworker_2etailCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2etailCalls_entry, 1, 0};

V g_heff_2ecompile_2eworker_2etailCalls(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2420));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1418838819x1907320638(a_0, a_1)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    V v_g_2425 = heff_field(v_e_240, 0);
    V v_args_2426 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2426; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2426); r_; });
    return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_g_2425, v_t_2427}), NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eworker_2etailCalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2etailCalls(a[0]);
}
V g_heff_2ecompile_2eworker_2ejumpsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2ejumpsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ejumpsOf_entry, 2, 0};

V g_heff_2ecompile_2eworker_2ejumpsOf(V v_ar_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 2);
    V v_n_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    V v_t_248 = (g_heff_2ecompile_2eworker_2etailCalls(v_b_246));
    V v_t_2419 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eworker_2ejumpsOf_lam0, 1, 3, (V[]){v_d_241, v_n_247, heff_dup(v_ar_240)}), v_t_248));
    return (g_list_2emap_24s1937570095x2110149801(v_t_2419));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eworker_2ejumpsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2ejumpsOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eworker_2ejumpsOf_lam0(V self, V *args) {
  V v_x4_249 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_n_247 = heff_env(self)[1];
  V v_ar_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x4_249)) {
  case TAG_MkPair: {
    V v_g_2410 = heff_field(v_x4_249, 0);
    V v_m_2411 = heff_field(v_x4_249, 1);
    heff_take_n(v_x4_249, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2410), heff_get_n(v_d_241, 0, 3))) {
      heff_drop(v_n_247);
      heff_drop(v_ar_240);
      heff_drop(v_g_2410);
      heff_drop(v_m_2411);
      return NTAG(TAG_False);
    } else {
      if (heff_intEq_c_lent(v_m_2411, v_n_247, 1)) {
        HeffT2 v_t_2414 = ({ V a_0 = v_ar_240; V a_1 = v_g_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_ar_240); heff_drop(v_g_2410); r_; });
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          V v_ret_24bool = heff_bool(((v_tag_2415 == ((int64_t)0ULL)) && ({ V v_m_2418 = heff_dup(v_field_2416); int c_ = heff_intEq_c_lent(v_n_247, v_m_2418, 0); heff_drop(v_m_2418); c_; })));
          heff_drop(v_n_247);
          heff_drop(v_field_2416);
          return v_ret_24bool;
        }
      } else {
        heff_drop(v_n_247);
        heff_drop(v_ar_240);
        heff_drop(v_g_2410);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x4_249);
  }
}
Clo g_heff_2ecompile_2eworker_2ereachGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ereachGo_entry, 3, 0};

V g_heff_2ecompile_2eworker_2ereachGo(V v_js_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        V t_0 = v_js_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_js_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_seen_241, heff_dup(v_k_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2411 = ({ V a_0 = v_js_240; V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
        V v_t_2416;
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2413;
            v_t_2416 = v_x_2415;
          } else {
            heff_drop(v_field_2413);
            v_t_2416 = NTAG(TAG_Nil);
          }
        }
        V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2416, v_rest_244));
        V t_0 = v_js_240;
        V t_1 = v_t_2410;
        V t_2 = v_t_2417;
        v_js_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eworker_2ereachGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2ereachGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eworker_2ecycleOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2ecycleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ecycleOf_entry, 2, 0};

V g_heff_2ecompile_2eworker_2ecycleOf(V v_js_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_js_240, v_k_241));
  V v_t_247;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      v_t_247 = v_x_246;
    } else {
      heff_drop(v_field_244);
      v_t_247 = NTAG(TAG_Nil);
    }
  }
  V v_m_248 = (g_heff_2ecompile_2eworker_2ereachGo(v_js_240, heff_dup(g_std_2emap_2eempty_get()), v_t_247));
  V v_t_249 = ({ V a_0 = v_m_248; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_248); r_; });
  V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(v_t_249));
  HEFF_LAST return g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eworker_2ecycleOf_lam0, 1, 2, (V[]){heff_dup(v_js_240), heff_dup(v_k_241)}), v_t_2410);
}
V g_heff_2ecompile_2eworker_2ecycleOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eworker_2ecycleOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eworker_2ecycleOf_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_js_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2412 = ({ V a_0 = v_js_240; V a_1 = v_h_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_h_2411); r_; });
  V v_t_2417;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2414;
      v_t_2417 = v_x_2416;
    } else {
      heff_drop(v_field_2414);
      v_t_2417 = NTAG(TAG_Nil);
    }
  }
  V v_m_2418 = ({ V a_0 = v_js_240; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_2417; V r_ = (g_heff_2ecompile_2eworker_2ereachGo(a_0, a_1, a_2)); heff_drop(v_js_240); r_; });
  HeffT2 v_t_2419 = ({ V a_0 = v_m_2418; V a_1 = v_k_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_m_2418); heff_drop(v_k_241); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2420 == ((int64_t)0ULL)) && ({ V v_x_2423 = heff_dup(v_field_2421); int c_ = 1; heff_drop(v_x_2423); c_; })));
    heff_drop(v_field_2421);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2eworker_2ewithSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ewithSig_entry, 3, 0};

V g_heff_2ecompile_2eworker_2ewithSig(V v_sg_240, V v_k_241, V v_s_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_s_242, 1));
  switch (heff_tag_of(v_t_243)) {
  case TAG_RepV: {
    V v_t_244 = (g_list_2eany_24s469347062x492258493(heff_rfield(v_s_242, 0)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_sg_240, v_k_241, v_s_242);
    } else {
      heff_drop_rec(v_s_242, 2);
      heff_drop(v_t_244);
      return ({ V a_0 = v_sg_240; V a_1 = v_k_241; V r_ = (g_std_2emap_2edelete_24s1614046289x1611773644(a_0, a_1)); heff_drop(v_k_241); r_; });
    }
  }
  case TAG_RepFix: {
    heff_take_n(v_t_243, 0ULL, 1);
    HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_sg_240, v_k_241, v_s_242);
  }
  case TAG_RepF64: {
    HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_sg_240, v_k_241, v_s_242);
  }
  case TAG_RepInt: {
    HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_sg_240, v_k_241, v_s_242);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eworker_2ewithSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2ewithSig(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eworker_2emeetIn_lam1(V self, V *args);
V g_heff_2ecompile_2eworker_2emeetIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2emeetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2emeetIn_entry, 3, 0};

V g_heff_2ecompile_2eworker_2emeetIn(V v_sg_240, V v_s_241, V v_ks_242) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eworker_2emeetIn_lam0, 2, 3, (V[]){v_s_241, heff_dup(v_sg_240), heff_dup(v_ks_242)}); V a_1 = v_sg_240; V a_2 = v_ks_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ks_242); r_; });
}
V g_heff_2ecompile_2eworker_2emeetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2emeetIn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eworker_2emeetIn_lam1(V self, V *args) {
  V v_h_245 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_241, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_247 = (g_list_2ereplicate(v_n_246, NTAG(TAG_RepV)));
  V v_d_248 = heff_rec_n(2, shape_params__result, (V[]){v_t_247, NTAG(TAG_RepV)});
  HeffT2 v_t_249 = ({ V a_0 = v_sg_240; V a_1 = v_h_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_sg_240); heff_drop(v_h_245); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_248, 2);
      V v_x_2413 = v_field_2411;
      return v_x_2413;
    } else {
      heff_drop(v_field_2411);
      return v_d_248;
    }
  }
}
V g_heff_2ecompile_2eworker_2emeetIn_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_k_244 = args[1];
  V v_s_241 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  V v_ks_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eworker_2emeetIn_lam1, 1, 2, (V[]){heff_dup(v_s_241), v_sg_240}), v_ks_242));
  V v_t_2415 = ({ V a_0 = v_s_241; V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s932544939x1448830416(a_0, a_1)); heff_drop(v_t_2414); r_; });
  return (g_heff_2ecompile_2eworker_2ewithSig(v_m_243, v_k_244, v_t_2415));
}
V g_heff_2ecompile_2eworker_2emeetCycles_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2emeetCycles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2emeetCycles_entry, 2, 0};

V g_heff_2ecompile_2eworker_2emeetCycles(V v_js_240, V v_sg_241) {
top: ;
  V v_t_242 = (g_std_2emap_2etoListOnto(v_sg_241, NTAG(TAG_Nil)));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eworker_2emeetCycles_lam0, 2, 1, (V[]){heff_dup(v_js_240)}); V a_1 = v_sg_241; V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2ecompile_2eworker_2emeetCycles_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2emeetCycles(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eworker_2emeetCycles_lam0(V self, V *args) {
  V v_sg_243 = args[0];
  V v_x3_244 = args[1];
  V v_js_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_244)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_244, 0);
    V v_s_246 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    V v_xs_247 = (g_heff_2ecompile_2eworker_2ecycleOf(v_js_240, v_k_245));
    V v_x_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    if (heff_intLe_c(MK_INT(2LL), v_x_248)) {
      V v_t_2410 = ({ V a_0 = v_js_240; V a_1 = v_k_245; V r_ = (g_heff_2ecompile_2eworker_2ecycleOf(a_0, a_1)); heff_drop(v_js_240); heff_drop(v_k_245); r_; });
      return (g_heff_2ecompile_2eworker_2emeetIn(v_sg_243, v_s_246, v_t_2410));
    } else {
      heff_drop(v_js_240);
      heff_drop(v_k_245);
      heff_drop(v_s_246);
      return v_sg_243;
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
Clo g_heff_2ecompile_2eworker_2ehopeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ehopeOne_entry, 4, 0};

V g_heff_2ecompile_2eworker_2ehopeOne(V v_facts_240, V v_sg_241, V v_acc_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_k_244 = heff_field(v_p_243, 0);
    V v_p2_245 = heff_field(v_p_243, 1);
    switch (heff_tag_of(v_p2_245)) {
    case TAG_MkDef: {
      V v_p23_248 = heff_field(v_p2_245, 2);
      switch (heff_tag_of(v_p23_248)) {
      case TAG_DefFun: {
        V v_xs_249 = heff_field(v_p23_248, 0);
        V v_p232_2410 = heff_field(v_p23_248, 1);
        switch (heff_tag_of(v_p232_2410)) {
        case TAG_MkBlock: {
          V v_t_2411 = heff_field(v_p232_2410, 0);
          V v_n_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
          V v_t_2413 = (g_list_2ereplicate(v_n_2412, NTAG(TAG_RepV)));
          V v_d_2414 = heff_rec_n(2, shape_params__result, (V[]){v_t_2413, NTAG(TAG_RepV)});
          HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_sg_241, v_k_244));
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            V v_old_2420;
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              heff_drop_rec(v_d_2414, 2);
              V v_x_2419 = v_field_2417;
              v_old_2420 = v_x_2419;
            } else {
              heff_drop(v_field_2417);
              v_old_2420 = v_d_2414;
            }
            V v_n_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
            V v_t_2422 = (g_list_2ereplicate(v_n_2421, NTAG(TAG_RepV)));
            V v_d_2423 = heff_rec_n(2, shape_params__result, (V[]){v_t_2422, NTAG(TAG_RepV)});
            HeffT2 v_t_2424 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_sg_241, v_k_244));
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              V v_old_2429;
              if ((v_tag_2425 == ((int64_t)0ULL))) {
                heff_drop_rec(v_d_2423, 2);
                V v_x_2428 = v_field_2426;
                v_old_2429 = v_x_2428;
              } else {
                heff_drop(v_field_2426);
                v_old_2429 = v_d_2423;
              }
              V v_t_2430 = heff_rec_n(2, shape_sigs__flat, (V[]){v_sg_241, heff_take_field(v_facts_240, 5)});
              HeffT2 v_t_2431 = ({ V b_0 = heff_get_n(v_facts_240, 1, 10); V a_1 = v_k_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_2436;
              {
                V v_field_2433 = v_t_2431.f[1];
                int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
                v_t_2436 = heff_bool(((v_tag_2432 == ((int64_t)0ULL)) && ({ V v_x_2435 = heff_dup(v_field_2433); int c_ = 1; heff_drop(v_x_2435); c_; })));
                heff_drop(v_field_2433);
              }
              HeffT2 v_t_2437 = ({ V a_0 = v_t_2430; V a_1 = v_t_2436; V a_2 = heff_dup(v_xs_249); V a_3 = heff_dup(v_t_2411); HeffT2 r_ = (g_heff_2ecompile_2erepr_2ehopeSig_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2436); r_; });
              {
                V v_field_2438 = v_t_2437.f[0];
                V v_field_2439 = v_t_2437.f[1];
                V v_t_2440 = (g_list_2ezipWith_24s1448987994x473765958(heff_take_field(v_old_2429, 0), v_field_2438));
                V v_old_2441 = heff_get_n(v_old_2429, 1, 2);
                V v_t_2443;
                switch (heff_tag_of(v_old_2441)) {
                case TAG_RepV: {
                  v_t_2443 = v_field_2439;
                  break;
                }
                case TAG_RepFix: {
                  heff_drop(v_field_2439);
                  v_t_2443 = v_old_2441;
                  break;
                }
                case TAG_RepF64: {
                  heff_drop(v_field_2439);
                  v_t_2443 = v_old_2441;
                  break;
                }
                case TAG_RepInt: {
                  heff_drop(v_field_2439);
                  v_t_2443 = v_old_2441;
                  break;
                }
                default: heff_nomatch(v_old_2441);
                }
                V v_new_2444 = heff_rec_n(2, shape_params__result, (V[]){v_t_2440, v_t_2443});
                V v_t_2445 = (g_heff_2ecompile_2erepr_2ereprsEq(heff_rfield(v_old_2420, 0), heff_rfield(v_new_2444, 0)));
                if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
                  heff_drop(v_t_2445);
                  V v_t_2446 = ({ V b_0 = heff_get_n(v_old_2420, 1, 2); V a_1 = heff_rfield(v_new_2444, 1); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(b_0, a_1)); heff_drop(b_0); r_; });
                  if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
                    heff_drop_rec(v_new_2444, 2);
                    heff_drop(v_t_2446);
                    return v_acc_242;
                  } else {
                    heff_drop(v_t_2446);
                    return (g_std_2emap_2einsert_24s93785294x875597928(v_acc_242, heff_dup(v_k_244), v_new_2444));
                  }
                } else {
                  heff_drop_rec(v_old_2420, 2);
                  heff_drop(v_t_2445);
                  return (g_std_2emap_2einsert_24s93785294x875597928(v_acc_242, heff_dup(v_k_244), v_new_2444));
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_p232_2410);
        }
      }
      case TAG_DefVal: {
        heff_drop_rec(v_facts_240, 10);
        heff_drop(v_sg_241);
        return v_acc_242;
      }
      default: return heff_nomatch(v_p23_248);
      }
    }
    default: return heff_nomatch(v_p2_245);
    }
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_heff_2ecompile_2eworker_2ehopeOne_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eworker_2ehopeOne(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eworker_2efallImp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2efallImp_entry, 6, 0};

V g_heff_2ecompile_2eworker_2efallImp(V v_facts_240, V v_base_241, V v_sg_242, V v_acc_243, V v_k_244, V v_md_245) {
top: ;
  switch (heff_tag_of(v_md_245)) {
  case TAG_MkDef: {
    V v_md3_248 = heff_field(v_md_245, 2);
    switch (heff_tag_of(v_md3_248)) {
    case TAG_DefFun: {
      V v_xs_249 = heff_field(v_md3_248, 0);
      V v_md32_2410 = heff_field(v_md3_248, 1);
      switch (heff_tag_of(v_md32_2410)) {
      case TAG_MkBlock: {
        V v_t_2411 = heff_field(v_md32_2410, 0);
        V v_n_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
        V v_t_2413 = (g_list_2ereplicate(v_n_2412, NTAG(TAG_RepV)));
        V v_d_2414 = heff_rec_n(2, shape_params__result, (V[]){v_t_2413, NTAG(TAG_RepV)});
        HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_sg_242, v_k_244));
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          V v_old_2420;
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            heff_drop_rec(v_d_2414, 2);
            V v_x_2419 = v_field_2417;
            v_old_2420 = v_x_2419;
          } else {
            heff_drop(v_field_2417);
            v_old_2420 = v_d_2414;
          }
          V v_n_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
          V v_t_2422 = (g_list_2ereplicate(v_n_2421, NTAG(TAG_RepV)));
          V v_d_2423 = heff_rec_n(2, shape_params__result, (V[]){v_t_2422, NTAG(TAG_RepV)});
          HeffT2 v_t_2424 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_base_241, v_k_244));
          {
            V v_field_2426 = v_t_2424.f[1];
            int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
            V v_old_2429;
            if ((v_tag_2425 == ((int64_t)0ULL))) {
              heff_drop_rec(v_d_2423, 2);
              V v_x_2428 = v_field_2426;
              v_old_2429 = v_x_2428;
            } else {
              heff_drop(v_field_2426);
              v_old_2429 = v_d_2423;
            }
            V v_n_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
            V v_t_2431 = (g_list_2ereplicate(v_n_2430, NTAG(TAG_RepV)));
            V v_d_2432 = heff_rec_n(2, shape_params__result, (V[]){v_t_2431, NTAG(TAG_RepV)});
            HeffT2 v_t_2433 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_sg_242, v_k_244));
            {
              V v_field_2435 = v_t_2433.f[1];
              int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
              V v_a_2438;
              if ((v_tag_2434 == ((int64_t)0ULL))) {
                heff_drop_rec(v_d_2432, 2);
                V v_x_2437 = v_field_2435;
                v_a_2438 = v_x_2437;
              } else {
                heff_drop(v_field_2435);
                v_a_2438 = v_d_2432;
              }
              V v_t_2439 = heff_rec_n(2, shape_sigs__flat, (V[]){v_sg_242, heff_take_field(v_facts_240, 5)});
              HeffT2 v_t_2440 = ({ V b_0 = heff_get_n(v_facts_240, 1, 10); V a_1 = v_k_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_2445;
              {
                V v_field_2442 = v_t_2440.f[1];
                int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                v_t_2445 = heff_bool(((v_tag_2441 == ((int64_t)0ULL)) && ({ V v_x_2444 = heff_dup(v_field_2442); int c_ = 1; heff_drop(v_x_2444); c_; })));
                heff_drop(v_field_2442);
              }
              HeffT2 v_t_2446 = ({ V a_0 = v_t_2439; V a_1 = v_t_2445; V a_2 = heff_dup(v_xs_249); V a_3 = heff_dup(v_t_2411); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eproposeSig_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2445); r_; });
              {
                V v_field_2447 = v_t_2446.f[0];
                V v_field_2448 = v_t_2446.f[1];
                V v_t_2449 = (g_list_2ezipWith_24s151204990x680105425(heff_take_field(v_a_2438, 0), v_field_2447));
                V v_a_2450 = heff_get_n(v_a_2438, 1, 2);
                V v_t_2451 = ({ V a_0 = v_a_2450; V a_1 = v_field_2448; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_field_2448); r_; });
                V v_t_2452;
                if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
                  heff_drop(v_t_2451);
                  v_t_2452 = v_a_2450;
                } else {
                  heff_drop(v_a_2450);
                  heff_drop(v_t_2451);
                  v_t_2452 = NTAG(TAG_RepV);
                }
                V v_t_2453 = (g_list_2ezipWith_24s1448987994x473765958(heff_take_field(v_old_2429, 0), v_t_2449));
                V v_old_2454 = heff_get_n(v_old_2429, 1, 2);
                V v_t_2456;
                switch (heff_tag_of(v_old_2454)) {
                case TAG_RepV: {
                  v_t_2456 = v_t_2452;
                  break;
                }
                case TAG_RepFix: {
                  heff_drop(v_t_2452);
                  v_t_2456 = v_old_2454;
                  break;
                }
                case TAG_RepF64: {
                  heff_drop(v_t_2452);
                  v_t_2456 = v_old_2454;
                  break;
                }
                case TAG_RepInt: {
                  heff_drop(v_t_2452);
                  v_t_2456 = v_old_2454;
                  break;
                }
                default: heff_nomatch(v_old_2454);
                }
                V v_new_2457 = heff_rec_n(2, shape_params__result, (V[]){v_t_2453, v_t_2456});
                V v_t_2458 = (g_heff_2ecompile_2erepr_2ereprsEq(heff_rfield(v_old_2420, 0), heff_rfield(v_new_2457, 0)));
                if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
                  heff_drop(v_t_2458);
                  V v_t_2459 = ({ V b_0 = heff_get_n(v_old_2420, 1, 2); V a_1 = heff_rfield(v_new_2457, 1); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(b_0, a_1)); heff_drop(b_0); r_; });
                  if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
                    heff_drop(v_k_244);
                    heff_drop_rec(v_new_2457, 2);
                    heff_drop(v_t_2459);
                    return v_acc_243;
                  } else {
                    heff_drop(v_t_2459);
                    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_244, v_new_2457}), v_acc_243});
                  }
                } else {
                  heff_drop_rec(v_old_2420, 2);
                  heff_drop(v_t_2458);
                  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_244, v_new_2457}), v_acc_243});
                }
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_md32_2410);
      }
    }
    case TAG_DefVal: {
      heff_drop_rec(v_facts_240, 10);
      heff_drop(v_sg_242);
      heff_drop(v_k_244);
      return v_acc_243;
    }
    default: return heff_nomatch(v_md3_248);
    }
  }
  default: return heff_nomatch(v_md_245);
  }
}
V g_heff_2ecompile_2eworker_2efallImp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ecompile_2eworker_2efallImp(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
V g_heff_2ecompile_2eworker_2efallDirty_lam0(V self, V *args);
V g_heff_2ecompile_2eworker_2efallDirty_lam1(V self, V *args);
Clo g_heff_2ecompile_2eworker_2efallDirty_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2efallDirty_entry, 2, 0};

V g_heff_2ecompile_2eworker_2efallDirty(V v_fl_240, V v_cs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_241));
  V v_xs_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eworker_2efallDirty_lam0, 2, 1, (V[]){heff_dup(v_fl_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_m_2418 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2417; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2417); r_; });
  V v_t_2419 = ({ V a_0 = v_m_2418; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2418); r_; });
  V v_t_2420 = (g_list_2emap_24s1937570095x2110149801(v_t_2419));
  HEFF_LAST return g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eworker_2efallDirty_lam1, 1, 1, (V[]){v_fl_240}), v_t_2420);
}
V g_heff_2ecompile_2eworker_2efallDirty_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2efallDirty(a[0], a[1]);
}
V g_heff_2ecompile_2eworker_2efallDirty_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_fl_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_x_244, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_2410;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 2);
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_fl_240, 4, 5); V a_1 = v_t_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2410); r_; });
  V v_t_2416;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      v_t_2416 = v_x_2415;
    } else {
      heff_drop(v_field_2413);
      v_t_2416 = NTAG(TAG_Nil);
    }
  }
  return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2416}), v_acc_243));
}
V g_heff_2ecompile_2eworker_2efallDirty_lam1(V self, V *args) {
  V v_k_2421 = args[0];
  V v_fl_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2422 = ({ V b_0 = heff_get_n(v_fl_240, 3, 5); V a_1 = v_k_2421; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2421); r_; });
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2423 == ((int64_t)0ULL)) && ({ V v_x_2426 = heff_dup(v_field_2424); int c_ = 1; heff_drop(v_x_2426); c_; })));
    heff_drop(v_field_2424);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eworker_2efalls_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2efalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2efalls_entry, 4, 0};

V g_heff_2ecompile_2eworker_2efalls(V v_fl_240, V v_box_24n_241, V v_sg_242, V v_cs_243) {
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  if ((v_n_241 <= ((int64_t)0ULL))) {
    heff_drop_rec(v_fl_240, 5);
    heff_drop(v_cs_243);
    return v_sg_242;
  } else {
    switch (heff_tag_of(v_cs_243)) {
    case TAG_Nil: {
      heff_drop_rec(v_fl_240, 5);
      return v_sg_242;
    }
    case TAG_Cons: {
      V v_t_247 = (g_list_2efoldl_24s591739608x1065283968(heff_dup(v_sg_242), v_cs_243));
      V v_sg_248 = (g_list_2efoldl_24s591739608x1065283968(v_sg_242, v_cs_243));
      V v_dirty_249 = (g_heff_2ecompile_2eworker_2efallDirty(heff_dup(v_fl_240), v_cs_243));
      V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eworker_2efalls_lam0, 2, 2, (V[]){heff_dup(v_fl_240), v_sg_248}); V a_1 = NTAG(TAG_Nil); V a_2 = v_dirty_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_dirty_249); r_; });
      V t_0 = v_fl_240;
      int64_t t_1 = (v_n_241 - ((int64_t)1ULL));
      V t_2 = v_t_247;
      V t_3 = v_t_2417;
      v_fl_240 = t_0;
      v_n_241 = t_1;
      v_sg_242 = t_2;
      v_cs_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_cs_243);
    }
  }
}
V g_heff_2ecompile_2eworker_2efalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2efalls(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eworker_2efalls_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_k_2411 = args[1];
  V v_fl_240 = heff_env(self)[0];
  V v_sg_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_fl_240, 2), v_k_2411));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_md_2416 = v_field_2414;
      return ({ V a_0 = heff_dup(heff_rfield(v_fl_240, 0)); V b_1 = heff_get_n(v_fl_240, 1, 5); V a_2 = v_sg_248; V a_3 = v_acc_2410; V a_4 = v_k_2411; V a_5 = v_md_2416; V r_ = (g_heff_2ecompile_2eworker_2efallImp(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); heff_drop(v_md_2416); r_; });
    } else {
      heff_drop(v_k_2411);
      heff_drop_rec(v_fl_240, 5);
      heff_drop(v_sg_248);
      heff_drop(v_field_2414);
      return v_acc_2410;
    }
  }
}
V g_heff_2ecompile_2eworker_2efallDirtyAll_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2efallDirtyAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2efallDirtyAll_entry, 1, 0};

V g_heff_2ecompile_2eworker_2efallDirtyAll(V v_fl_240) {
top: ;
  V v_xs_241 = (g_std_2emap_2etoListOnto(heff_rfield(v_fl_240, 3), NTAG(TAG_Nil)));
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_xs_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eworker_2efallDirtyAll_lam0, 2, 1, (V[]){v_fl_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_m_2418 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2417; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2417); r_; });
  V v_t_2419 = ({ V a_0 = v_m_2418; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2418); r_; });
  HEFF_LAST return g_list_2emap_24s1937570095x2110149801(v_t_2419);
}
V g_heff_2ecompile_2eworker_2efallDirtyAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2efallDirtyAll(a[0]);
}
V g_heff_2ecompile_2eworker_2efallDirtyAll_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_fl_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_x_244, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_2410;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 2);
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_fl_240, 4, 5); V a_1 = v_t_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2410); r_; });
  V v_t_2416;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      v_t_2416 = v_x_2415;
    } else {
      heff_drop(v_field_2413);
      v_t_2416 = NTAG(TAG_Nil);
    }
  }
  return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2416}), v_acc_243));
}
V g_heff_2ecompile_2eworker_2efallen_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2efallen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2efallen_entry, 1, 0};

V g_heff_2ecompile_2eworker_2efallen(V v_fl_240) {
top: ;
  V v_t_241 = (g_std_2emap_2etoListOnto(heff_rfield(v_fl_240, 3), NTAG(TAG_Nil)));
  V v_t_242 = ({ V a_0 = heff_dup(heff_rfield(v_fl_240, 1)); V a_1 = v_t_241; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_t_241); r_; });
  V v_t_243 = (g_std_2emap_2etoListOnto(heff_rfield(v_fl_240, 3), NTAG(TAG_Nil)));
  V v_sg_244 = ({ V a_0 = heff_dup(heff_rfield(v_fl_240, 1)); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_std_2emap_2etoListOnto(heff_rfield(v_fl_240, 3), NTAG(TAG_Nil)));
  V v_dirty_246 = (g_list_2emap_24s1937570095x2110149801(v_t_245));
  V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eworker_2efallen_lam0, 2, 2, (V[]){heff_dup(v_fl_240), v_sg_244}); V a_1 = NTAG(TAG_Nil); V a_2 = v_dirty_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_dirty_246); r_; });
  return (g_heff_2ecompile_2eworker_2efalls(v_fl_240, MK_INT(64LL), v_t_242, v_t_2414));
}
V g_heff_2ecompile_2eworker_2efallen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2efallen(a[0]);
}
V g_heff_2ecompile_2eworker_2efallen_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_k_248 = args[1];
  V v_fl_240 = heff_env(self)[0];
  V v_sg_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_fl_240, 2), v_k_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_md_2413 = v_field_2411;
      return ({ V a_0 = heff_dup(heff_rfield(v_fl_240, 0)); V b_1 = heff_get_n(v_fl_240, 1, 5); V a_2 = v_sg_244; V a_3 = v_acc_247; V a_4 = v_k_248; V a_5 = v_md_2413; V r_ = (g_heff_2ecompile_2eworker_2efallImp(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); heff_drop(v_md_2413); r_; });
    } else {
      heff_drop(v_k_248);
      heff_drop_rec(v_fl_240, 5);
      heff_drop(v_sg_244);
      heff_drop(v_field_2411);
      return v_acc_247;
    }
  }
}
Clo g_heff_2ecompile_2eworker_2ehopingWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ehopingWith_entry, 3, 0};

V g_heff_2ecompile_2eworker_2ehopingWith(V v_facts_240, V v_defs_241, V v_fl_242) {
top: ;
  V v_t_243 = (g_std_2emap_2esize(heff_rfield(v_fl_242, 3)));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop(v_facts_240);
    return heff_get_n(v_fl_242, 1, 5);
  } else {
    V v_sg_245 = (g_heff_2ecompile_2eworker_2efallen(heff_dup(v_fl_242)));
    V v_t_246 = (g_std_2emap_2etoListOnto(v_sg_245, NTAG(TAG_Nil)));
    V v_t_247 = ({ V a_0 = v_sg_245; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s2103009317x1481930218(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_248 = heff_rec_n(2, shape_sigs__imps, (V[]){v_t_247, heff_dup(heff_rfield(v_fl_242, 2))});
    V v_t_249 = (g_heff_2ecompile_2eworker_2efallDirtyAll(heff_dup(v_fl_242)));
    V v_r_2410 = ({ V a_0 = v_facts_240; V a_1 = v_defs_241; V b_2 = heff_get_n(v_fl_242, 4, 5); V a_3 = MK_INT(64LL); V a_4 = heff_rec_n(2, shape_round__dirty, (V[]){v_t_248, v_t_249}); V r_ = (g_heff_2ecompile_2eworker_2erounds(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    return heff_get_n(v_r_2410, 0, 2);
  }
}
V g_heff_2ecompile_2eworker_2ehopingWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eworker_2ehopingWith(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eworker_2eworkers_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2eworkers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2eworkers_entry, 2, 0};

V g_heff_2ecompile_2eworker_2eworkers(V v_facts_240, V v_defs_241) {
top: ;
  V v_t_245 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eworker_2eworkers_lam0, 2, 1, (V[]){heff_dup(v_facts_240)}), heff_dup(g_std_2emap_2eempty_get()), v_defs_241));
  V v_defs_246 = (g_list_2efoldl_24s740336339x1862813792(heff_dup(g_std_2emap_2eempty_get()), v_defs_241));
  V v_callers_247 = (g_list_2efoldl_24s1885006984x1134653659(heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_defs_241)));
  V v_t_248 = (g_list_2efoldl_24s740336339x1862813792(heff_dup(g_std_2emap_2eempty_get()), v_defs_241));
  V v_t_249 = (g_list_2efoldl_24s1885006984x1134653659(heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_defs_241)));
  V v_xs_2410 = (g_list_2emap_24f1300907700x23410576(v_defs_241));
  V v_m_2411 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2410; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2410); r_; });
  V v_t_2412 = ({ V a_0 = v_m_2411; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2411); r_; });
  V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(v_t_2412));
  V v_t_2414 = heff_rec_n(2, shape_round__dirty, (V[]){heff_rec_n(2, shape_sigs__imps, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())}), v_t_2413});
  V v_r_2415 = ({ V a_0 = heff_dup(v_facts_240); V a_1 = v_t_248; V a_2 = v_t_249; V a_3 = MK_INT(64LL); V a_4 = v_t_2414; V r_ = (g_heff_2ecompile_2eworker_2erounds(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_248); heff_drop(v_t_249); r_; });
  V v_t_2416 = (g_std_2emap_2etoListOnto(heff_rfield(v_r_2415, 1), NTAG(TAG_Nil)));
  V v_t_2417 = ({ V a_0 = heff_dup(v_facts_240); V a_1 = heff_dup(heff_rfield(v_r_2415, 0)); V a_2 = heff_dup(g_std_2emap_2eempty_get()); V a_3 = v_t_2416; V r_ = (g_list_2efoldl_24s319398146x1205310166(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = heff_rec_n(5, shape_facts__base__imps__hoped__callers, (V[]){heff_dup(v_facts_240), heff_take_field(v_r_2415, 0), heff_get_n(v_r_2415, 1, 2), v_t_2417, v_callers_247});
  V v_t_2419 = ({ V a_0 = v_facts_240; V a_1 = v_defs_246; V a_2 = v_t_2418; V r_ = (g_heff_2ecompile_2eworker_2ehopingWith(a_0, a_1, a_2)); heff_drop(v_defs_246); r_; });
  return ({ V a_0 = v_t_245; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2eworker_2emeetCycles(a_0, a_1)); heff_drop(v_t_245); r_; });
}
V g_heff_2ecompile_2eworker_2eworkers_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2eworkers(a[0], a[1]);
}
V g_heff_2ecompile_2eworker_2eworkers_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_d_243 = args[1];
  V v_facts_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V b_0 = heff_get_n(v_facts_240, 0, 10); V a_1 = heff_dup(v_d_243); V r_ = (g_heff_2ecompile_2eworker_2ejumpsOf(b_0, a_1)); heff_drop(b_0); r_; });
  return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, heff_get_n(v_d_243, 0, 3), v_t_244));
}