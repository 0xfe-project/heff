// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_EBool 8245
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_ITl 20301
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_RetClass 33382
#define TAG_Wants 58903
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_base 9511832
#define LBL_bounce 563936691
#define LBL_callers 780494982
#define LBL_changed 970801394
#define LBL_comp 9554902
#define LBL_defs 9574869
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_hoped 300822210
#define LBL_imps 9731822
#define LBL_log 316862
#define LBL_params 951713969
#define LBL_result 1012715336
#define LBL_sigs 10025609
static uint32_t shape_changed__imps[] = {LBL_changed, LBL_imps};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_sigs__flat[] = {LBL_sigs, LBL_flat};
static uint32_t shape_sigs__imps__log[] = {LBL_sigs, LBL_imps, LBL_log};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdRels(V);
V g_heff_2ecompile_2eir_2econdRels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdRels_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2erepr_2ehope(V);
V g_heff_2ecompile_2erepr_2ehope_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ehope_clo;
V g_heff_2ecompile_2erepr_2enoStats_get(void);
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V, V, V, V);
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_heff_2ecompile_2erepr_2eretName_get(void);
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erepr_2ewalk(V, V, V, V);
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewalk_clo;
V g_heff_2ecompile_2eworker_2ecycleOf(V, V);
V g_heff_2ecompile_2eworker_2ecycleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ecycleOf_clo;
V g_heff_2ecompile_2eworker_2efallImp(V, V, V, V, V, V);
V g_heff_2ecompile_2eworker_2efallImp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efallImp_clo;
V g_heff_2ecompile_2eworker_2efallsIn(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2efallsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2efallsIn_clo;
V g_heff_2ecompile_2eworker_2ehopeOne(V, V, V, V);
V g_heff_2ecompile_2eworker_2ehopeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ehopeOne_clo;
V g_heff_2ecompile_2eworker_2enumericW(V);
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericW_clo;
V g_heff_2ecompile_2eworker_2ereachGo(V, V, V);
V g_heff_2ecompile_2eworker_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ereachGo_clo;
V g_heff_2ecompile_2eworker_2eroundsIn(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eroundsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eroundsIn_clo;
V g_heff_2ecompile_2eworker_2etouched(V, V);
V g_heff_2ecompile_2eworker_2etouched_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2etouched_clo;
V g_heff_2ecompile_2eworker_2eweighImp(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eweighImp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eweighImp_clo;
V g_heff_2ecompile_2eworker_2ewithSig(V, V, V);
V g_heff_2ecompile_2eworker_2ewithSig_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2ewithSig_clo;
V g_list_2eany_24s1598387467x1906338007(V);
V g_list_2eany_24s1598387467x1906338007_entry(V self, V *a);
extern Clo g_list_2eany_24s1598387467x1906338007_clo;
V g_list_2eany_24s469347062x492258493(V);
V g_list_2eany_24s469347062x492258493_entry(V self, V *a);
extern Clo g_list_2eany_24s469347062x492258493_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1081467548x958897672(V, V, V);
V g_list_2efoldl_24s1081467548x958897672_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1081467548x958897672_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1854174827x1081689521(V, V);
V g_list_2efoldl_24s1854174827x1081689521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854174827x1081689521_clo;
V g_list_2efoldl_24s1884746541x1630112285(V, V);
V g_list_2efoldl_24s1884746541x1630112285_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1884746541x1630112285_clo;
V g_list_2efoldl_24s2086705387x1592057803(V, V, V, V, V);
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2086705387x1592057803_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1917875516x88484758(V);
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1448987994x473765958(V, V);
V g_list_2ezipWith_24s1448987994x473765958_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_clo;
V g_list_2ezipWith_24s151204990x680105425(V, V);
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eworker_2enumericW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2enumericW_entry, 1, 0};

V g_heff_2ecompile_2eworker_2enumericW(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EProj: {
      V v_e_243 = heff_field(v_x11_241, 0);
      V v_t_246 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 9ULL, 4);
      switch (heff_tag_of(v_t_246)) {
      case TAG_FtFloat: {
        heff_drop(v_x12_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_e_243);
        return NTAG(TAG_True);
      }
      case TAG_FtFixed: {
        heff_take_n(v_t_246, 0ULL, 1);
        heff_drop(v_x12_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_e_243);
        return NTAG(TAG_True);
      }
      case TAG_FtOther: {
        V t_0 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_e_243, v_x12_242});
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_FtAny: {
        V t_0 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_e_243, v_x12_242});
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_EPrimCall: {
      V v_p_248 = heff_field(v_x11_241, 0);
      V v_args_249 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_248));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        V v_t_2414;
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x11_2413 = v_field_2412;
          heff_drop(v_x11_2413);
          switch (heff_tag_of(v_p_248)) {
          case TAG_WordAdd: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordSub: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordMul: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordDiv: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordMod: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordQuot: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordRem: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordEq: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordLt: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordLe: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          case TAG_WordToFloat: {
            v_t_2414 = NTAG(TAG_False);
            break;
          }
          default: {
            heff_drop(v_p_248);
            v_t_2414 = NTAG(TAG_True);
            break;
          }
          }
        } else {
          heff_drop(v_p_248);
          heff_drop(v_field_2412);
          v_t_2414 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_x12_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_args_249);
          heff_drop(v_t_2414);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2414);
          V v_t_2415 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24Cons, v_args_249, v_x12_242));
          V t_0 = v_t_2415;
          v_x1_240 = t_0;
          goto top;
        }
      }
    }
    case TAG_EFloat: {
      heff_take_nf(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_True);
    }
    case TAG_EBool: {
      V v_c_2420 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2421 = (g_heff_2ecompile_2eir_2econdRels(v_c_2420));
      V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_list_2eany_24s1598387467x1906338007(a_0)); heff_drop(v_t_2421); r_; });
      if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
        heff_drop(v_x12_242);
        heff_drop(v_c_2420);
        heff_drop(v_t_2422);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2422);
        V v_t_2423 = ({ V a_0 = v_c_2420; V a_1 = v_x12_242; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2420); r_; });
        V t_0 = v_t_2423;
        v_x1_240 = t_0;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2424 = (g_heff_2ecompile_2eir_2epartsOnto(v_x11_241, v_x12_242));
      V t_0 = v_t_2424;
      v_x1_240 = t_0;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2enumericW(a[0]);
}
Clo g_heff_2ecompile_2eworker_2eweighImp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2eweighImp_entry, 5, 0};

V g_heff_2ecompile_2eworker_2eweighImp(V v_facts_240, V v_sg_241, V v_acc_242, V v_k_243, V v_md_244) {
top: ;
  V v_bounce_245 = heff_take_field(v_facts_240, 1);
  V v_flat_246 = heff_get_n(v_facts_240, 5, 12);
  switch (heff_tag_of(v_md_244)) {
  case TAG_MkDef: {
    V v_md3_249 = heff_dup(heff_field(v_md_244, 2));
    switch (heff_tag_of(v_md3_249)) {
    case TAG_DefFun: {
      V v_xs_2410 = heff_field(v_md3_249, 0);
      V v_md32_2411 = heff_field(v_md3_249, 1);
      V v_ru_24md3_249_24DefFun = heff_take_reuse_n(v_md3_249, 3ULL, 2);
      switch (heff_tag_of(v_md32_2411)) {
      case TAG_MkBlock: {
        V v_t_2412 = heff_field(v_md32_2411, 0);
        heff_take_n(v_md32_2411, 1ULL, 1);
        V v_acc_2413 = v_acc_242;
        V v_changed_2414 = heff_take_field(v_acc_2413, 0);
        V v_imps_2415 = heff_take_field(v_acc_2413, 1);
        V v_k_2416 = heff_dup(v_k_243);
        V v_md_2417 = v_md_244;
        V v_n_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
        V v_t_2419 = (g_list_2ereplicate(v_n_2418, NTAG(TAG_RepV)));
        V v_d_2420 = heff_rec_n(2, shape_params__result, (V[]){v_t_2419, NTAG(TAG_RepV)});
        HeffT2 v_t_2421 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_sg_241, v_k_243));
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          V v_old_2425;
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            heff_drop_rec(v_d_2420, 2);
            V v_x_2424 = v_field_2423;
            v_old_2425 = v_x_2424;
          } else {
            heff_drop(v_field_2423);
            v_old_2425 = v_d_2420;
          }
          V v_params_2426 = heff_take_field(v_old_2425, 0);
          V v_result_2427 = heff_take_field(v_old_2425, 1);
          V v_n_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
          V v_t_2429 = (g_list_2ereplicate(v_n_2428, NTAG(TAG_RepV)));
          V v_d_2430 = ({ V rv_0 = v_t_2429; V rv_1 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_old_2425, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          HeffT2 v_t_2431 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_sg_241, v_k_243));
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            V v_old_2435;
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              heff_drop_rec(v_d_2430, 2);
              V v_x_2434 = v_field_2433;
              v_old_2435 = v_x_2434;
            } else {
              heff_drop(v_field_2433);
              v_old_2435 = v_d_2430;
            }
            V v_params_2436 = heff_take_field(v_old_2435, 0);
            V v_result_2437 = heff_take_field(v_old_2435, 1);
            HeffT2 v_t_2438 = ({ V a_0 = v_bounce_245; V a_1 = v_k_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_bounce_245); heff_drop(v_k_243); r_; });
            {
              V v_field_2440 = v_t_2438.f[1];
              int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
              V v_t_2442 = heff_bool(((v_tag_2439 == ((int64_t)0ULL)) && ({ V v_x_2441 = heff_dup(v_field_2440); int c_ = 1; heff_drop(v_x_2441); c_; })));
              heff_drop(v_field_2440);
              HeffT2 v_t_2443 = ({ V b_0 = heff_rec_n(2, shape_sigs__flat, (V[]){v_sg_241, v_flat_246}); V a_1 = v_t_2442; V a_2 = v_xs_2410; V a_3 = v_t_2412; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eproposeSig_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2442); r_; });
              {
                V v_field_2444 = v_t_2443.f[0];
                V v_field_2445 = v_t_2443.f[1];
                V v_t_2446 = (g_list_2ezipWith_24s1448987994x473765958(v_params_2436, v_field_2444));
                V v_old_2447 = v_result_2437;
                V v_t_2449;
                switch (heff_tag_of(v_old_2447)) {
                case TAG_RepV: {
                  v_t_2449 = v_field_2445;
                  break;
                }
                case TAG_RepFix: {
                  heff_drop(v_field_2445);
                  v_t_2449 = v_old_2447;
                  break;
                }
                case TAG_RepF64: {
                  heff_drop(v_field_2445);
                  v_t_2449 = v_old_2447;
                  break;
                }
                case TAG_RepInt: {
                  heff_drop(v_field_2445);
                  v_t_2449 = v_old_2447;
                  break;
                }
                default: heff_nomatch(v_old_2447);
                }
                V v_new_2450 = ({ V rv_0 = v_t_2446; V rv_1 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_old_2435, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_2451 = ({ V a_0 = v_params_2426; V a_1 = heff_rfield(v_new_2450, 0); V r_ = (g_heff_2ecompile_2erepr_2ereprsEq(a_0, a_1)); heff_drop(v_params_2426); r_; });
                V v_t_2453;
                if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
                  heff_drop(v_t_2451);
                  V v_t_2452 = ({ V a_0 = v_result_2427; V a_1 = heff_rfield(v_new_2450, 1); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_result_2427); r_; });
                  if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
                    heff_drop_cell(v_ru_24md3_249_24DefFun, 2);
                    heff_drop_rec(v_new_2450, 2);
                    heff_drop(v_t_2452);
                    v_t_2453 = v_changed_2414;
                  } else {
                    heff_drop(v_t_2452);
                    v_t_2453 = heff_tag_at_n(v_ru_24md3_249_24DefFun, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_2416), v_new_2450}), v_changed_2414});
                  }
                } else {
                  heff_drop(v_result_2427);
                  heff_drop(v_t_2451);
                  v_t_2453 = heff_tag_at_n(v_ru_24md3_249_24DefFun, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_2416), v_new_2450}), v_changed_2414});
                }
                V v_t_2454 = ({ V a_0 = v_imps_2415; V a_1 = v_k_2416; V a_2 = v_md_2417; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_2416); heff_drop(v_md_2417); r_; });
                return ({ V rv_0 = v_t_2453; V rv_1 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_acc_2413, 0ULL, 2, shape_changed__imps, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_md32_2411);
      }
    }
    case TAG_DefVal: {
      heff_take_n(v_md3_249, 0ULL, 1);
      heff_drop(v_sg_241);
      heff_drop(v_k_243);
      heff_drop(v_bounce_245);
      heff_drop(v_flat_246);
      switch (heff_tag_of(v_md_244)) {
      case TAG_MkDef: {
        heff_take_n(v_md_244, 0ULL, 3);
        return v_acc_242;
      }
      default: return heff_nomatch(v_md_244);
      }
    }
    default: return heff_nomatch(v_md3_249);
    }
  }
  default: return heff_nomatch(v_md_244);
  }
}
V g_heff_2ecompile_2eworker_2eweighImp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2eweighImp(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2eworker_2ereachGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ereachGo_entry, 3, 0};

V g_heff_2ecompile_2eworker_2ereachGo(V v_js_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_js_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_js_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_241, v_k_243, NTAG(TAG_MkUnit)));
        HeffT2 v_t_2410 = ({ V a_0 = v_js_240; V a_1 = v_k_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          V v_t_2414;
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2412;
            v_t_2414 = v_x_2413;
          } else {
            heff_drop(v_field_2412);
            v_t_2414 = NTAG(TAG_Nil);
          }
          V v_t_2415 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2414, v_rest_244));
          V t_0 = v_js_240;
          V t_1 = v_t_249;
          V t_2 = v_t_2415;
          v_js_240 = t_0;
          v_seen_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eworker_2ereachGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2ereachGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eworker_2ecycleOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eworker_2ecycleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ecycleOf_entry, 2, 0};

V g_heff_2ecompile_2eworker_2ecycleOf(V v_js_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_js_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_t_246;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_245 = v_field_244;
      v_t_246 = v_x_245;
    } else {
      heff_drop(v_field_244);
      v_t_246 = NTAG(TAG_Nil);
    }
    V v_m_247 = (g_heff_2ecompile_2eworker_2ereachGo(v_js_240, heff_dup(g_std_2eordmap_2eempty_get()), v_t_246));
    V v_t_248 = ({ V a_0 = v_m_247; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_247); r_; });
    V v_t_249 = (g_list_2emap_24s1937570095x2110149801(v_t_248));
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eworker_2ecycleOf_lam0, 1, 2, (V[]){heff_dup(v_js_240), heff_dup(v_k_241)}); V a_1 = v_t_249; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  }
}
V g_heff_2ecompile_2eworker_2ecycleOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eworker_2ecycleOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eworker_2ecycleOf_lam0(V self, V *args) {
  V v_h_2410 = args[0];
  V v_js_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  HeffT2 v_t_2411 = ({ V a_0 = v_js_240; V a_1 = v_h_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_h_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_t_2415;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      v_t_2415 = v_x_2414;
    } else {
      heff_drop(v_field_2413);
      v_t_2415 = NTAG(TAG_Nil);
    }
    heff_clo_take(self, 2);
    V v_m_2416 = ({ V a_0 = v_js_240; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_2415; V r_ = (g_heff_2ecompile_2eworker_2ereachGo(a_0, a_1, a_2)); heff_drop(v_js_240); r_; });
    HeffT2 v_t_2417 = ({ V a_0 = v_m_2416; V a_1 = v_k_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_m_2416); heff_drop(v_k_241); r_; });
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2418 == ((int64_t)0ULL)) && ({ V v_x_2420 = heff_dup(v_field_2419); int c_ = 1; heff_drop(v_x_2420); c_; })));
      heff_drop(v_field_2419);
      return v_ret_24bool;
    }
  }
}
Clo g_heff_2ecompile_2eworker_2ewithSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ewithSig_entry, 3, 0};

V g_heff_2ecompile_2eworker_2ewithSig(V v_sg_240, V v_k_241, V v_s_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_s_242, 1));
  switch (heff_tag_of(v_t_243)) {
  case TAG_RepV: {
    V v_t_244 = (g_list_2eany_24s469347062x492258493(heff_rfield(v_s_242, 0)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return ({ V a_0 = v_sg_240; V a_1 = v_k_241; V a_2 = v_s_242; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop_rec(v_s_242, 2); r_; });
    } else {
      heff_drop_rec(v_s_242, 2);
      heff_drop(v_t_244);
      return (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_sg_240, v_k_241));
    }
  }
  case TAG_RepFix: {
    heff_take_n(v_t_243, 0ULL, 1);
    return ({ V a_0 = v_sg_240; V a_1 = v_k_241; V a_2 = v_s_242; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop_rec(v_s_242, 2); r_; });
  }
  case TAG_RepF64: {
    return ({ V a_0 = v_sg_240; V a_1 = v_k_241; V a_2 = v_s_242; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop_rec(v_s_242, 2); r_; });
  }
  case TAG_RepInt: {
    return ({ V a_0 = v_sg_240; V a_1 = v_k_241; V a_2 = v_s_242; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop_rec(v_s_242, 2); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eworker_2ewithSig_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eworker_2ewithSig(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eworker_2ehopeOne_lam0(V self, V *args);
V g_heff_2ecompile_2eworker_2ehopeOne_lam1(V self, V *args);
Clo g_heff_2ecompile_2eworker_2ehopeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2ehopeOne_entry, 4, 0};

V g_heff_2ecompile_2eworker_2ehopeOne(V v_facts_240, V v_sg_241, V v_acc_242, V v_p_243) {
top: ;
  V v_flat_244 = heff_take_field(v_facts_240, 5);
  V v_bounce_245 = heff_get_n(v_facts_240, 1, 12);
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_243, 0);
    V v_p2_247 = heff_field(v_p_243, 1);
    V v_ru_24p_243_24MkPair = heff_take_reuse_n(v_p_243, 3ULL, 2);
    switch (heff_tag_of(v_p2_247)) {
    case TAG_MkDef: {
      V v_p23_2410 = heff_field(v_p2_247, 2);
      V v_ru_24p2_247_24MkDef = heff_take_reuse_n(v_p2_247, 4ULL, 3);
      switch (heff_tag_of(v_p23_2410)) {
      case TAG_DefFun: {
        V v_xs_2411 = heff_field(v_p23_2410, 0);
        V v_p232_2412 = heff_field(v_p23_2410, 1);
        V v_ru_24p23_2410_24DefFun = heff_take_reuse_n(v_p23_2410, 3ULL, 2);
        switch (heff_tag_of(v_p232_2412)) {
        case TAG_MkBlock: {
          V v_t_2413 = heff_field(v_p232_2412, 0);
          V v_ru_24p232_2412_24MkBlock = heff_take_reuse_n(v_p232_2412, 1ULL, 1);
          V v_n_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
          V v_t_2415 = (g_list_2ereplicate(v_n_2414, NTAG(TAG_RepV)));
          V v_d_2416 = heff_rec_n(2, shape_params__result, (V[]){v_t_2415, NTAG(TAG_RepV)});
          HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_sg_241, v_k_246));
          {
            V v_field_2419 = v_t_2417.f[1];
            int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
            V v_old_2421;
            if ((v_tag_2418 == ((int64_t)0ULL))) {
              heff_drop_rec(v_d_2416, 2);
              V v_x_2420 = v_field_2419;
              v_old_2421 = v_x_2420;
            } else {
              heff_drop(v_field_2419);
              v_old_2421 = v_d_2416;
            }
            V v_params_2422 = heff_take_field(v_old_2421, 0);
            V v_result_2423 = heff_take_field(v_old_2421, 1);
            V v_n_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
            V v_t_2425 = (g_list_2ereplicate(v_n_2424, NTAG(TAG_RepV)));
            V v_d_2426 = ({ V rv_0 = v_t_2425; V rv_1 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_old_2421, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            HeffT2 v_t_2427 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_sg_241, v_k_246));
            {
              V v_field_2429 = v_t_2427.f[1];
              int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
              V v_old_2431;
              if ((v_tag_2428 == ((int64_t)0ULL))) {
                heff_drop_rec(v_d_2426, 2);
                V v_x_2430 = v_field_2429;
                v_old_2431 = v_x_2430;
              } else {
                heff_drop(v_field_2429);
                v_old_2431 = v_d_2426;
              }
              V v_params_2432 = heff_take_field(v_old_2431, 0);
              V v_result_2433 = heff_take_field(v_old_2431, 1);
              V v_sg_2434 = heff_rec_n(2, shape_sigs__flat, (V[]){v_sg_241, v_flat_244});
              HeffT2 v_t_2435 = ({ V a_0 = v_bounce_245; V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_bounce_245); r_; });
              {
                V v_field_2437 = v_t_2435.f[1];
                int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
                V v_bounces_2439 = heff_bool(((v_tag_2436 == ((int64_t)0ULL)) && ({ V v_x_2438 = heff_dup(v_field_2437); int c_ = 1; heff_drop(v_x_2438); c_; })));
                heff_drop(v_field_2437);
                V v_xs_2440 = v_xs_2411;
                V v_t_2441 = v_t_2413;
                V v_t_2442 = (g_list_2emap_24s1917875516x88484758(heff_dup(v_xs_2440)));
                V v_t_2443 = (g_list_2efoldl_24s1854174827x1081689521(NTAG(TAG_Nil), v_t_2442));
                V v_t_2444 = heff_tag_at_n(v_ru_24p2_247_24MkDef, TAG_ITl, 3, (V[]){heff_dup(v_xs_2440), NTAG(TAG_RetClass), v_t_2441});
                V v_t_2445 = heff_tag_at_n(v_ru_24p_243_24MkPair, TAG_Cons, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
                V v_t_2446 = ({ V a_0 = v_sg_2434; V a_1 = NTAG(TAG_False); V a_2 = v_t_2443; V a_3 = v_t_2445; V r_ = (g_heff_2ecompile_2erepr_2ewalk(a_0, a_1, a_2, a_3)); heff_drop_rec(v_sg_2434, 2); r_; });
                V v_t_2447 = heff_tag_at_n(v_ru_24p23_2410_24DefFun, TAG_Wants, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), NTAG(TAG_RepV)});
                V v_evs_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2446});
                V v_pins_2449 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2448));
                V v_t_2450 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2448));
                V v_evs_2454 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eworker_2ehopeOne_lam0, 2, 1, (V[]){v_pins_2449}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2450; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2450); r_; });
                V v_parent_2455 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2454));
                V v_evs_2456 = v_evs_2454;
                V v_bounces_2457 = v_bounces_2439;
                V v_xs_2458 = v_xs_2440;
                V v_stats_2459 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2455, v_evs_2456));
                V v_t_2468 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eworker_2ehopeOne_lam1, 1, 2, (V[]){heff_dup(v_parent_2455), v_stats_2459}), v_xs_2458));
                V v_t_2477;
                if ((heff_dup(v_bounces_2457) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24p232_2412_24MkBlock, 1);
                  heff_drop(v_parent_2455);
                  heff_drop(v_evs_2456);
                  heff_drop(v_bounces_2457);
                  v_t_2477 = NTAG(TAG_RepV);
                } else {
                  heff_drop(v_bounces_2457);
                  V v_stats_2469 = ({ V a_0 = v_parent_2455; V a_1 = v_evs_2456; V r_ = (g_heff_2ecompile_2erepr_2estatsOf(a_0, a_1)); heff_drop(v_evs_2456); r_; });
                  V v_t_2470 = ({ V a_0 = v_ru_24p232_2412_24MkBlock; V a_1 = v_parent_2455; V b_2 = heff_dup(g_heff_2ecompile_2erepr_2eretName_get()); V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                  V v_t_2471 = ({ V a_0 = v_parent_2455; V a_1 = heff_dup(g_heff_2ecompile_2erepr_2eretName_get()); V a_2 = v_t_2470; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_2455); r_; });
                  HeffT2 v_t_2472 = ({ V a_0 = v_stats_2469; V a_1 = v_t_2471; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_stats_2469); heff_drop(v_t_2471); r_; });
                  {
                    V v_field_2474 = v_t_2472.f[1];
                    int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
                    V v_t_2476;
                    if ((v_tag_2473 == ((int64_t)0ULL))) {
                      V v_x_2475 = v_field_2474;
                      v_t_2476 = v_x_2475;
                    } else {
                      heff_drop(v_field_2474);
                      v_t_2476 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
                    }
                    v_t_2477 = (g_heff_2ecompile_2erepr_2ehope(v_t_2476));
                  }
                }
                V v_new_2478 = ({ V rv_0 = v_t_2468; V rv_1 = v_t_2477; V rr_ = heff_rec_reuse_nf(v_old_2431, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_params_2479 = heff_take_field(v_new_2478, 0);
                V v_result_2480 = heff_take_field(v_new_2478, 1);
                V v_t_2481 = (g_list_2ezipWith_24s1448987994x473765958(v_params_2432, v_params_2479));
                V v_old_2482 = v_result_2433;
                V v_t_2484;
                switch (heff_tag_of(v_old_2482)) {
                case TAG_RepV: {
                  v_t_2484 = v_result_2480;
                  break;
                }
                case TAG_RepFix: {
                  heff_drop(v_result_2480);
                  v_t_2484 = v_old_2482;
                  break;
                }
                case TAG_RepF64: {
                  heff_drop(v_result_2480);
                  v_t_2484 = v_old_2482;
                  break;
                }
                case TAG_RepInt: {
                  heff_drop(v_result_2480);
                  v_t_2484 = v_old_2482;
                  break;
                }
                default: heff_nomatch(v_old_2482);
                }
                V v_new_2485 = ({ V rv_0 = v_t_2481; V rv_1 = v_t_2484; V rr_ = heff_rec_reuse_nf(v_new_2478, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_2486 = ({ V a_0 = v_params_2422; V a_1 = heff_rfield(v_new_2485, 0); V r_ = (g_heff_2ecompile_2erepr_2ereprsEq(a_0, a_1)); heff_drop(v_params_2422); r_; });
                if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
                  heff_drop(v_t_2486);
                  V v_t_2487 = ({ V a_0 = v_result_2423; V a_1 = heff_rfield(v_new_2485, 1); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_result_2423); r_; });
                  if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
                    heff_drop(v_k_246);
                    heff_drop_rec(v_new_2485, 2);
                    heff_drop(v_t_2487);
                    return v_acc_242;
                  } else {
                    heff_drop(v_t_2487);
                    return ({ V a_0 = v_acc_242; V a_1 = v_k_246; V a_2 = v_new_2485; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_246); heff_drop_rec(v_new_2485, 2); r_; });
                  }
                } else {
                  heff_drop(v_result_2423);
                  heff_drop(v_t_2486);
                  return ({ V a_0 = v_acc_242; V a_1 = v_k_246; V a_2 = v_new_2485; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_246); heff_drop_rec(v_new_2485, 2); r_; });
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_p232_2412);
        }
      }
      case TAG_DefVal: {
        heff_take_n(v_p23_2410, 0ULL, 1);
        heff_drop(v_sg_241);
        heff_drop(v_flat_244);
        heff_drop(v_bounce_245);
        heff_drop(v_k_246);
        heff_drop_cell(v_ru_24p_243_24MkPair, 2);
        heff_drop_cell(v_ru_24p2_247_24MkDef, 3);
        return v_acc_242;
      }
      default: return heff_nomatch(v_p23_2410);
      }
    }
    default: return heff_nomatch(v_p2_247);
    }
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_heff_2ecompile_2eworker_2ehopeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2ehopeOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eworker_2ehopeOne_lam0(V self, V *args) {
  V v_acc_2451 = args[0];
  V v_x_2452 = args[1];
  V v_pins_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = ({ V a_0 = v_pins_2449; V a_1 = v_x_2452; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2449); r_; });
  return (g_prelude_2e_2b_2b(v_t_2453, v_acc_2451));
}
V g_heff_2ecompile_2eworker_2ehopeOne_lam1(V self, V *args) {
  V v_x_2460 = args[0];
  V v_parent_2455 = heff_env(self)[0];
  V v_stats_2459 = heff_env(self)[1];
  V v_t_2461 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_2455, v_x_2460));
  heff_clo_take(self, 2);
  V v_t_2462 = ({ V a_0 = v_parent_2455; V a_1 = v_x_2460; V a_2 = v_t_2461; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_2455); r_; });
  HeffT2 v_t_2463 = ({ V a_0 = v_stats_2459; V a_1 = v_t_2462; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_stats_2459); heff_drop(v_t_2462); r_; });
  {
    V v_field_2465 = v_t_2463.f[1];
    int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
    V v_t_2467;
    if ((v_tag_2464 == ((int64_t)0ULL))) {
      V v_x_2466 = v_field_2465;
      v_t_2467 = v_x_2466;
    } else {
      heff_drop(v_field_2465);
      v_t_2467 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
    return (g_heff_2ecompile_2erepr_2ehope(v_t_2467));
  }
}
Clo g_heff_2ecompile_2eworker_2efallImp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2efallImp_entry, 6, 0};

V g_heff_2ecompile_2eworker_2efallImp(V v_facts_240, V v_base_241, V v_sg_242, V v_acc_243, V v_k_244, V v_md_245) {
top: ;
  V v_bounce_246 = heff_take_field(v_facts_240, 1);
  V v_flat_247 = heff_get_n(v_facts_240, 5, 12);
  switch (heff_tag_of(v_md_245)) {
  case TAG_MkDef: {
    V v_md3_2410 = heff_field(v_md_245, 2);
    switch (heff_tag_of(v_md3_2410)) {
    case TAG_DefFun: {
      V v_xs_2411 = heff_field(v_md3_2410, 0);
      V v_md32_2412 = heff_field(v_md3_2410, 1);
      switch (heff_tag_of(v_md32_2412)) {
      case TAG_MkBlock: {
        V v_t_2413 = heff_field(v_md32_2412, 0);
        V v_n_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
        V v_t_2415 = (g_list_2ereplicate(v_n_2414, NTAG(TAG_RepV)));
        V v_d_2416 = heff_rec_n(2, shape_params__result, (V[]){v_t_2415, NTAG(TAG_RepV)});
        HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_sg_242, v_k_244));
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          V v_old_2421;
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            heff_drop_rec(v_d_2416, 2);
            V v_x_2420 = v_field_2419;
            v_old_2421 = v_x_2420;
          } else {
            heff_drop(v_field_2419);
            v_old_2421 = v_d_2416;
          }
          V v_params_2422 = heff_take_field(v_old_2421, 0);
          V v_result_2423 = heff_take_field(v_old_2421, 1);
          V v_n_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
          V v_t_2425 = (g_list_2ereplicate(v_n_2424, NTAG(TAG_RepV)));
          V v_d_2426 = ({ V rv_0 = v_t_2425; V rv_1 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_old_2421, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          HeffT2 v_t_2427 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_base_241, v_k_244));
          {
            V v_field_2429 = v_t_2427.f[1];
            int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
            V v_old_2431;
            if ((v_tag_2428 == ((int64_t)0ULL))) {
              heff_drop_rec(v_d_2426, 2);
              V v_x_2430 = v_field_2429;
              v_old_2431 = v_x_2430;
            } else {
              heff_drop(v_field_2429);
              v_old_2431 = v_d_2426;
            }
            V v_params_2432 = heff_take_field(v_old_2431, 0);
            V v_result_2433 = heff_take_field(v_old_2431, 1);
            V v_n_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
            V v_t_2435 = (g_list_2ereplicate(v_n_2434, NTAG(TAG_RepV)));
            V v_d_2436 = ({ V rv_0 = v_t_2435; V rv_1 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_old_2431, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            HeffT2 v_t_2437 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_sg_242, v_k_244));
            {
              V v_field_2439 = v_t_2437.f[1];
              int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
              V v_a_2441;
              if ((v_tag_2438 == ((int64_t)0ULL))) {
                heff_drop_rec(v_d_2436, 2);
                V v_x_2440 = v_field_2439;
                v_a_2441 = v_x_2440;
              } else {
                heff_drop(v_field_2439);
                v_a_2441 = v_d_2436;
              }
              V v_params_2442 = heff_take_field(v_a_2441, 0);
              V v_result_2443 = heff_take_field(v_a_2441, 1);
              HeffT2 v_t_2444 = ({ V a_0 = v_bounce_246; V a_1 = v_k_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_bounce_246); r_; });
              {
                V v_field_2446 = v_t_2444.f[1];
                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                V v_t_2448 = heff_bool(((v_tag_2445 == ((int64_t)0ULL)) && ({ V v_x_2447 = heff_dup(v_field_2446); int c_ = 1; heff_drop(v_x_2447); c_; })));
                heff_drop(v_field_2446);
                HeffT2 v_t_2449 = ({ V b_0 = heff_rec_n(2, shape_sigs__flat, (V[]){v_sg_242, v_flat_247}); V a_1 = v_t_2448; V a_2 = heff_dup(v_xs_2411); V a_3 = heff_dup(v_t_2413); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eproposeSig_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2448); r_; });
                {
                  V v_field_2450 = v_t_2449.f[0];
                  V v_field_2451 = v_t_2449.f[1];
                  V v_t_2452 = (g_list_2ezipWith_24s151204990x680105425(v_params_2442, v_field_2450));
                  V v_a_2453 = v_result_2443;
                  V v_t_2454 = ({ V a_0 = v_a_2453; V a_1 = v_field_2451; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_field_2451); r_; });
                  V v_t_2455;
                  if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
                    heff_drop(v_t_2454);
                    v_t_2455 = v_a_2453;
                  } else {
                    heff_drop(v_a_2453);
                    heff_drop(v_t_2454);
                    v_t_2455 = NTAG(TAG_RepV);
                  }
                  V v_t_2456 = (g_list_2ezipWith_24s1448987994x473765958(v_params_2432, v_t_2452));
                  V v_old_2457 = v_result_2433;
                  V v_t_2459;
                  switch (heff_tag_of(v_old_2457)) {
                  case TAG_RepV: {
                    v_t_2459 = v_t_2455;
                    break;
                  }
                  case TAG_RepFix: {
                    heff_drop(v_t_2455);
                    v_t_2459 = v_old_2457;
                    break;
                  }
                  case TAG_RepF64: {
                    heff_drop(v_t_2455);
                    v_t_2459 = v_old_2457;
                    break;
                  }
                  case TAG_RepInt: {
                    heff_drop(v_t_2455);
                    v_t_2459 = v_old_2457;
                    break;
                  }
                  default: heff_nomatch(v_old_2457);
                  }
                  V v_new_2460 = ({ V rv_0 = v_t_2456; V rv_1 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_a_2441, 0ULL, 2, shape_params__result, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
                  V v_t_2461 = ({ V a_0 = v_params_2422; V a_1 = heff_rfield(v_new_2460, 0); V r_ = (g_heff_2ecompile_2erepr_2ereprsEq(a_0, a_1)); heff_drop(v_params_2422); r_; });
                  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
                    heff_drop(v_t_2461);
                    V v_t_2462 = ({ V a_0 = v_result_2423; V a_1 = heff_rfield(v_new_2460, 1); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_result_2423); r_; });
                    if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
                      heff_drop(v_k_244);
                      heff_drop_rec(v_new_2460, 2);
                      heff_drop(v_t_2462);
                      return v_acc_243;
                    } else {
                      heff_drop(v_t_2462);
                      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_244, v_new_2460}), v_acc_243});
                    }
                  } else {
                    heff_drop(v_result_2423);
                    heff_drop(v_t_2461);
                    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_244, v_new_2460}), v_acc_243});
                  }
                }
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_md32_2412);
      }
    }
    case TAG_DefVal: {
      heff_drop(v_sg_242);
      heff_drop(v_k_244);
      heff_drop(v_bounce_246);
      heff_drop(v_flat_247);
      return v_acc_243;
    }
    default: return heff_nomatch(v_md3_2410);
    }
  }
  default: return heff_nomatch(v_md_245);
  }
}
V g_heff_2ecompile_2eworker_2efallImp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ecompile_2eworker_2efallImp(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
V g_heff_2ecompile_2eworker_2etouched_lam0(V self, V *args);
V g_heff_2ecompile_2eworker_2etouched_lam1(V self, V *args);
Clo g_heff_2ecompile_2eworker_2etouched_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2etouched_entry, 2, 0};

V g_heff_2ecompile_2eworker_2etouched(V v_c_240, V v_ks_241) {
top: ;
  V v_callers_242 = heff_take_field(v_c_240, 2);
  V v_defs_243 = heff_get_n(v_c_240, 1, 3);
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ks_241));
  V v_xs_2413 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eworker_2etouched_lam0, 2, 1, (V[]){v_callers_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_244); r_; });
  V v_m_2414 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2413; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2413); r_; });
  V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2414); r_; });
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(v_t_2415));
  return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eworker_2etouched_lam1, 1, 1, (V[]){v_defs_243}); V a_1 = v_t_2416; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2ecompile_2eworker_2etouched_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2etouched(a[0], a[1]);
}
V g_heff_2ecompile_2eworker_2etouched_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_callers_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V a_0 = v_callers_242; V a_1 = v_x_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_callers_242); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_t_2411;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_249);
      v_t_2411 = NTAG(TAG_Nil);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_acc_245));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_t_2412});
  }
}
V g_heff_2ecompile_2eworker_2etouched_lam1(V self, V *args) {
  V v_k_2417 = args[0];
  V v_defs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2418 = ({ V a_0 = v_defs_243; V a_1 = v_k_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_defs_243); heff_drop(v_k_2417); r_; });
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2419 == ((int64_t)0ULL)) && ({ V v_x_2421 = heff_dup(v_field_2420); int c_ = 1; heff_drop(v_x_2421); c_; })));
    heff_drop(v_field_2420);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2eworker_2eroundsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2eroundsIn_entry, 5, 0};

V g_heff_2ecompile_2eworker_2eroundsIn(V v_c_240, V v_i_241, V v_evs_242, V v_dirty_243, V v_s_244) {
top: ;
  if (heff_intLt_c_lent(MK_INT(64LL), v_i_241, 1)) {
    heff_drop(v_i_241);
    heff_drop(v_dirty_243);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_242));
    V v_cs_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1884746541x1630112285(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_247 = ({ V a_0 = heff_take_field(v_s_244, 0); V a_1 = v_cs_246; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_cs_246); r_; });
    return ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_244, 6ULL, 3, shape_sigs__imps__log, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    switch (heff_tag_of(v_dirty_243)) {
    case TAG_Nil: {
      heff_drop(v_i_241);
      switch (heff_tag_of(v_evs_242)) {
      case TAG_Nil: {
        return v_s_244;
      }
      case TAG_Cons: {
        V v_x31_248 = heff_field(v_evs_242, 0);
        V v_rest_249 = heff_field(v_evs_242, 1);
        V v_ru_24evs_242_24Cons = heff_take_reuse_n(v_evs_242, 3ULL, 2);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_j_2410 = heff_field(v_x31_248, 0);
          V v_cs_2411 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2412 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24evs_242_24Cons, heff_dup(v_cs_2411)));
          V v_t_2413 = (g_heff_2ecompile_2eworker_2etouched(heff_dup(v_c_240), v_t_2412));
          V v_t_2414 = ({ V a_0 = heff_take_field(v_s_244, 0); V a_1 = v_cs_2411; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_cs_2411); r_; });
          V v_t_2415 = ({ V rv_0 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_s_244, 6ULL, 3, shape_sigs__imps__log, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V t_0 = v_c_240;
          V t_1 = heff_intAdd(v_j_2410, MK_INT(1LL));
          V t_2 = v_rest_249;
          V t_3 = v_t_2413;
          V t_4 = v_t_2415;
          v_c_240 = t_0;
          v_i_241 = t_1;
          v_evs_242 = t_2;
          v_dirty_243 = t_3;
          v_s_244 = t_4;
          goto top;
        }
        default: return heff_nomatch(v_x31_248);
        }
      }
      default: return heff_nomatch(v_evs_242);
      }
    }
    case TAG_Cons: {
      V v_c_2418 = heff_dup(v_c_240);
      V v_go_2419 = ((V)&g_heff_2ecompile_2eworker_2eroundsIn_clo);
      V v_i_2420 = heff_dup(v_i_241);
      V v_s_2421 = heff_dup(v_s_244);
      V v_sigs_2422 = heff_take_field(v_s_2421, 0);
      V v_log_2423 = heff_get_n(v_s_2421, 2, 3);
      V v_t_2424 = heff_rec_n(2, shape_changed__imps, (V[]){NTAG(TAG_Nil), heff_take_field(v_s_244, 1)});
      V v_w_2425 = ({ V a_0 = heff_rfield(v_c_240, 0); V a_1 = heff_rfield(v_c_240, 1); V a_2 = heff_rfield(v_s_244, 0); V a_3 = v_t_2424; V a_4 = v_dirty_243; V r_ = (g_list_2efoldl_24s2086705387x1592057803(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_dirty_243, 2); r_; });
      V v_changed_2426 = heff_take_field(v_w_2425, 0);
      V v_imps_2427 = heff_get_n(v_w_2425, 1, 2);
      V v_x6_2433;
      switch (heff_tag_of(v_evs_242)) {
      case TAG_Nil: {
        heff_drop(v_i_241);
        v_x6_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_x21_2428 = heff_field(v_evs_242, 0);
        V v_rest_2429 = heff_field(v_evs_242, 1);
        V v_ru_24evs_242_24Cons = heff_take_reuse_n(v_evs_242, 3ULL, 2);
        switch (heff_tag_of(v_x21_2428)) {
        case TAG_MkPair: {
          V v_j_2430 = heff_field(v_x21_2428, 0);
          V v_cs_2431 = heff_field(v_x21_2428, 1);
          V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
          if (heff_intEq_c_lent(v_i_241, v_j_2430, 1)) {
            heff_drop_cell(v_ru_24evs_242_24Cons, 2);
            heff_drop(v_j_2430);
            v_x6_2433 = heff_tag_at_n(v_ru_24x21_2428_24MkPair, TAG_MkPair, 2, (V[]){v_cs_2431, v_rest_2429});
          } else {
            V v_t_2432 = heff_tag_re_n(v_ru_24evs_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_2428_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_j_2430, v_cs_2431}), v_rest_2429});
            v_x6_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_t_2432});
          }
          break;
        }
        default: heff_nomatch(v_x21_2428);
        }
        break;
      }
      default: heff_nomatch(v_evs_242);
      }
      switch (heff_tag_of(v_x6_2433)) {
      case TAG_MkPair: {
        V v_cs_2434 = heff_field(v_x6_2433, 0);
        V v_rest_2435 = heff_field(v_x6_2433, 1);
        V v_ru_24x6_2433_24MkPair = heff_take_reuse_n(v_x6_2433, 3ULL, 2);
        V v_t_2436 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x6_2433_24MkPair, heff_dup(v_changed_2426)));
        V v_t_2437 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_cs_2434)));
        V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2437));
        V v_t_2439 = (g_heff_2ecompile_2eworker_2etouched(heff_dup(v_c_2418), v_t_2438));
        V v_own_2440 = v_changed_2426;
        V v_t_2441 = (g_list_2efoldl_24s744304057x1932700078(v_sigs_2422, v_own_2440));
        V v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_cs_2434; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_cs_2434); r_; });
        V v_t_2443 = (g_list_2efoldl_24s1081467548x958897672(v_i_2420, v_log_2423, v_own_2440));
        return heff_tail(v_go_2419, 5, (V[]){v_c_2418, heff_intAdd(v_i_2420, MK_INT(1LL)), v_rest_2435, v_t_2439, ({ V rv_0 = v_t_2442; V rv_1 = v_imps_2427; V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_s_244, 0ULL, 3, shape_sigs__imps__log, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; })});
      }
      default: return heff_nomatch(v_x6_2433);
      }
    }
    default: return heff_nomatch(v_dirty_243);
    }
  }
}
V g_heff_2ecompile_2eworker_2eroundsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworker_2eroundsIn(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eworker_2efallsIn_lam0(V self, V *args);
V g_heff_2ecompile_2eworker_2efallsIn_lam1(V self, V *args);
V g_heff_2ecompile_2eworker_2efallsIn_lam2(V self, V *args);
Clo g_heff_2ecompile_2eworker_2efallsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworker_2efallsIn_entry, 5, 0};

V g_heff_2ecompile_2eworker_2efallsIn(V v_fc_240, V v_j_241, V v_evs_242, V v_dirty_243, V v_s_244) {
top: ;
  if (heff_intLt_c_lent(MK_INT(63LL), v_j_241, 1)) {
    heff_drop_rec(v_fc_240, 3);
    heff_drop(v_j_241);
    heff_drop(v_dirty_243);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_242));
    V v_cs_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1884746541x1630112285(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_247 = ({ V a_0 = heff_take_field(v_s_244, 0); V a_1 = v_cs_246; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_cs_246); r_; });
    return ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_244, 6ULL, 3, shape_sigs__imps__log, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    switch (heff_tag_of(v_dirty_243)) {
    case TAG_Nil: {
      heff_drop(v_j_241);
      V v_fc_248 = v_fc_240;
      V v_go_249 = ((V)&g_heff_2ecompile_2eworker_2efallsIn_clo);
      V v_x3_2410 = v_evs_242;
      V v_s_2411 = v_s_244;
      switch (heff_tag_of(v_x3_2410)) {
      case TAG_Nil: {
        heff_drop_rec(v_fc_248, 3);
        heff_drop(v_go_249);
        return v_s_2411;
      }
      case TAG_Cons: {
        V v_x31_2412 = heff_field(v_x3_2410, 0);
        V v_rest_2413 = heff_field(v_x3_2410, 1);
        V v_ru_24x3_2410_24Cons = heff_take_reuse_n(v_x3_2410, 3ULL, 2);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_j_2414 = heff_field(v_x31_2412, 0);
          V v_cs_2415 = heff_field(v_x31_2412, 1);
          heff_take_n(v_x31_2412, 3ULL, 2);
          V v_t_2416 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x3_2410_24Cons, heff_dup(v_cs_2415)));
          V v_ks_2417 = (g_heff_2ecompile_2eworker_2etouched(heff_dup(heff_rfield(v_fc_248, 0)), v_t_2416));
          V v_t_2423 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eworker_2efallsIn_lam0, 1, 1, (V[]){heff_dup(v_fc_248)}); V a_1 = v_ks_2417; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_2424 = ({ V a_0 = heff_take_field(v_s_2411, 0); V a_1 = v_cs_2415; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_cs_2415); r_; });
          V v_t_2425 = ({ V rv_0 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_s_2411, 6ULL, 3, shape_sigs__imps__log, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tail(v_go_249, 5, (V[]){v_fc_248, heff_intAdd(v_j_2414, MK_INT(1LL)), v_rest_2413, v_t_2423, v_t_2425});
        }
        default: return heff_nomatch(v_x31_2412);
        }
      }
      default: return heff_nomatch(v_x3_2410);
      }
    }
    case TAG_Cons: {
      V v_fc_2428 = heff_dup(v_fc_240);
      V v_go_2429 = ((V)&g_heff_2ecompile_2eworker_2efallsIn_clo);
      V v_j_2430 = heff_dup(v_j_241);
      V v_s_2431 = heff_dup(v_s_244);
      V v_facts_2432 = heff_get_n(heff_dup(heff_rfield(v_fc_240, 0)), 0, 3);
      V v_sg_2433 = heff_dup(heff_rfield(v_s_244, 0));
      V v_own_2440 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eworker_2efallsIn_lam1, 2, 4, (V[]){v_s_244, v_facts_2432, v_fc_240, v_sg_2433}); V a_1 = NTAG(TAG_Nil); V a_2 = v_dirty_243; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop_tag(v_dirty_243, 2); r_; });
      V v_x6_2446;
      switch (heff_tag_of(v_evs_242)) {
      case TAG_Nil: {
        heff_drop(v_j_241);
        v_x6_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_x21_2441 = heff_field(v_evs_242, 0);
        V v_rest_2442 = heff_field(v_evs_242, 1);
        V v_ru_24evs_242_24Cons = heff_take_reuse_n(v_evs_242, 3ULL, 2);
        switch (heff_tag_of(v_x21_2441)) {
        case TAG_MkPair: {
          V v_j_2443 = heff_field(v_x21_2441, 0);
          V v_cs_2444 = heff_field(v_x21_2441, 1);
          V v_ru_24x21_2441_24MkPair = heff_take_reuse_n(v_x21_2441, 3ULL, 2);
          if (heff_intEq_c_lent(v_j_241, v_j_2443, 1)) {
            heff_drop_cell(v_ru_24evs_242_24Cons, 2);
            heff_drop(v_j_2443);
            v_x6_2446 = heff_tag_at_n(v_ru_24x21_2441_24MkPair, TAG_MkPair, 2, (V[]){v_cs_2444, v_rest_2442});
          } else {
            V v_t_2445 = heff_tag_re_n(v_ru_24evs_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_2441_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_j_2443, v_cs_2444}), v_rest_2442});
            v_x6_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_t_2445});
          }
          break;
        }
        default: heff_nomatch(v_x21_2441);
        }
        break;
      }
      default: heff_nomatch(v_evs_242);
      }
      switch (heff_tag_of(v_x6_2446)) {
      case TAG_MkPair: {
        V v_cs_2447 = heff_field(v_x6_2446, 0);
        V v_rest_2448 = heff_field(v_x6_2446, 1);
        V v_ru_24x6_2446_24MkPair = heff_take_reuse_n(v_x6_2446, 3ULL, 2);
        V v_t_2449 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x6_2446_24MkPair, heff_dup(v_own_2440)));
        V v_t_2450 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_cs_2447)));
        V v_t_2451 = (g_prelude_2e_2b_2b(v_t_2449, v_t_2450));
        V v_ks_2452 = (g_heff_2ecompile_2eworker_2etouched(heff_dup(heff_rfield(v_fc_2428, 0)), v_t_2451));
        V v_t_2458 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eworker_2efallsIn_lam2, 1, 1, (V[]){heff_dup(v_fc_2428)}); V a_1 = v_ks_2452; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2459 = (g_list_2efoldl_24s744304057x1932700078(heff_take_field(v_s_2431, 0), v_own_2440));
        V v_t_2460 = ({ V a_0 = v_t_2459; V a_1 = v_cs_2447; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_cs_2447); r_; });
        V v_t_2461 = (g_list_2efoldl_24s1081467548x958897672(v_j_2430, heff_take_field(v_s_2431, 2), v_own_2440));
        V v_t_2462 = ({ V rv_0 = v_t_2460; V rv_2 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_s_2431, 2ULL, 3, shape_sigs__imps__log, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        return heff_tail(v_go_2429, 5, (V[]){v_fc_2428, heff_intAdd(v_j_2430, MK_INT(1LL)), v_rest_2448, v_t_2458, v_t_2462});
      }
      default: return heff_nomatch(v_x6_2446);
      }
    }
    default: return heff_nomatch(v_dirty_243);
    }
  }
}
V g_heff_2ecompile_2eworker_2efallsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworker_2efallsIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eworker_2efallsIn_lam0(V self, V *args) {
  V v_k_2418 = args[0];
  V v_fc_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = ({ V b_0 = heff_get_n(v_fc_248, 2, 3); V a_1 = v_k_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2418); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2420 == ((int64_t)0ULL)) && ({ V v_x_2422 = heff_dup(v_field_2421); int c_ = 1; heff_drop(v_x_2422); c_; })));
    heff_drop(v_field_2421);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eworker_2efallsIn_lam1(V self, V *args) {
  V v_acc_2434 = args[0];
  V v_k_2435 = args[1];
  V v_s_244 = heff_env(self)[0];
  V v_facts_2432 = heff_env(self)[1];
  V v_fc_240 = heff_env(self)[2];
  V v_sg_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_s_244, 1, 3); V a_1 = v_k_2435; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    if ((v_tag_2437 == ((int64_t)0ULL))) {
      V v_md_2439 = v_field_2438;
      return ({ V a_0 = v_facts_2432; V b_1 = heff_get_n(v_fc_240, 1, 3); V a_2 = v_sg_2433; V a_3 = v_acc_2434; V a_4 = v_k_2435; V a_5 = v_md_2439; V r_ = (g_heff_2ecompile_2eworker_2efallImp(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); heff_drop(v_md_2439); r_; });
    } else {
      heff_drop(v_k_2435);
      heff_drop(v_facts_2432);
      heff_drop_rec(v_fc_240, 3);
      heff_drop(v_sg_2433);
      heff_drop(v_field_2438);
      return v_acc_2434;
    }
  }
}
V g_heff_2ecompile_2eworker_2efallsIn_lam2(V self, V *args) {
  V v_k_2453 = args[0];
  V v_fc_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2454 = ({ V b_0 = heff_get_n(v_fc_2428, 2, 3); V a_1 = v_k_2453; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2453); r_; });
  {
    V v_field_2456 = v_t_2454.f[1];
    int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2455 == ((int64_t)0ULL)) && ({ V v_x_2457 = heff_dup(v_field_2456); int c_ = 1; heff_drop(v_x_2457); c_; })));
    heff_drop(v_field_2456);
    return v_ret_24bool;
  }
}