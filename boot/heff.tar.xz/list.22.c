// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_AtLeast0 52203
#define TAG_AtVar 7142
#define TAG_AtWord 2344
#define TAG_Below 46697
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_Flagged 28540
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkEquation 38417
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_Positional 16703
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_SError 24172
#define LBL_arity 294440695
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_count 296209705
#define LBL_end 310101
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_labels 836724522
#define LBL_lams 9809570
#define LBL_library 398066429
#define LBL_long 9823043
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_n 328
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_params 951713969
#define LBL_parent 951717845
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_rest 9992347
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_underLam 296337946
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__arity__at__rest[] = {LBL_key, LBL_arity, LBL_at, LBL_rest};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ecompile_2ebounds_2efixSt(V, V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixSt_clo;
V g_heff_2ecompile_2efuse_2epathCalls(V, V);
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2epathCalls_clo;
V g_heff_2ecompile_2efuse_2eselfOut(V, V);
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_24tok1_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V, V);
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1220384081x1312205021(V);
V g_list_2eall_24s1220384081x1312205021_entry(V self, V *a);
extern Clo g_list_2eall_24s1220384081x1312205021_clo;
V g_list_2eall_24s1395959145x1097496552(V, V);
V g_list_2eall_24s1395959145x1097496552_entry(V self, V *a);
extern Clo g_list_2eall_24s1395959145x1097496552_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1137631697x622554211(V, V);
V g_list_2eany_24s1137631697x622554211_entry(V self, V *a);
extern Clo g_list_2eany_24s1137631697x622554211_clo;
V g_list_2eany_24s1255781029x1672221493(V, V);
V g_list_2eany_24s1255781029x1672221493_entry(V self, V *a);
extern Clo g_list_2eany_24s1255781029x1672221493_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eascending_24s1147438953x64854941(V, V, V);
V g_list_2eascending_24s1147438953x64854941_entry(V self, V *a);
extern Clo g_list_2eascending_24s1147438953x64854941_clo;
V g_list_2eascending_24s1547370222x166817322(V, V, V);
V g_list_2eascending_24s1547370222x166817322_entry(V self, V *a);
extern Clo g_list_2eascending_24s1547370222x166817322_clo;
V g_list_2ecollapse_24s1189723159x1707000933(V, V, V, V);
V g_list_2ecollapse_24s1189723159x1707000933_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1189723159x1707000933_clo;
V g_list_2edescending_24s1092102222x1336838254(V, V, V);
V g_list_2edescending_24s1092102222x1336838254_entry(V self, V *a);
extern Clo g_list_2edescending_24s1092102222x1336838254_clo;
V g_list_2edescending_24s1706700342x2062518382(V, V, V);
V g_list_2edescending_24s1706700342x2062518382_entry(V self, V *a);
extern Clo g_list_2edescending_24s1706700342x2062518382_clo;
HeffT2 g_list_2efind_24s670012890x84869279_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1325733028x1311723093(V, V, V);
V g_list_2efoldl_24f1325733028x1311723093_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1325733028x1311723093_clo;
V g_list_2efoldl_24f545139853x5269120(V, V);
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a);
extern Clo g_list_2efoldl_24f545139853x5269120_clo;
V g_list_2efoldl_24s1271133029x1548514599(V, V);
V g_list_2efoldl_24s1271133029x1548514599_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1271133029x1548514599_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1533929316x1834489357(V, V);
V g_list_2efoldl_24s1533929316x1834489357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1533929316x1834489357_clo;
V g_list_2efoldl_24s1606891938x229778616(V, V);
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1606891938x229778616_clo;
V g_list_2efoldl_24s2104458007x128868622(V, V);
V g_list_2efoldl_24s2104458007x128868622_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2104458007x128868622_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s547379716x1342911792(V, V, V);
V g_list_2efoldl_24s547379716x1342911792_entry(V self, V *a);
extern Clo g_list_2efoldl_24s547379716x1342911792_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1066353734x1075193228(V, V);
V g_list_2ekeepIf_24s1066353734x1075193228_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1066353734x1075193228_clo;
V g_list_2ekeepIf_24s1066353734x1075193228_24dps(V, V, V);
V g_list_2ekeepIf_24s1066353734x1075193228_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1066353734x1075193228_24dps_clo;
V g_list_2ekeepIf_24s2085003797x1793382462_24dps(V, V, V);
V g_list_2ekeepIf_24s2085003797x1793382462_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2085003797x1793382462_24dps_clo;
V g_list_2ekeepIf_24s689992630x418898235_24dps(V, V, V);
V g_list_2ekeepIf_24s689992630x418898235_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_24dps_clo;
V g_list_2ekeepIf_24s920421308x594300259(V, V, V);
V g_list_2ekeepIf_24s920421308x594300259_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s920421308x594300259_clo;
V g_list_2ekeepIf_24s920421308x594300259_24dps(V, V, V, V);
V g_list_2ekeepIf_24s920421308x594300259_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s920421308x594300259_24dps_clo;
V g_list_2ekeepIf_24s958254147x1083401940_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1141799624x1826918381_24dps(V, V, V, V);
V g_list_2emap_24f1141799624x1826918381_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1141799624x1826918381_24dps_clo;
V g_list_2emap_24f2081800072x871100793_24dps(V, V);
V g_list_2emap_24f2081800072x871100793_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2081800072x871100793_24dps_clo;
V g_list_2emap_24f904804876x285797696_24dps(V, V, V, V);
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_24dps_clo;
V g_list_2emap_24s1366476796x894764441(V, V);
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_clo;
V g_list_2emap_24s1366476796x894764441_24dps(V, V, V);
V g_list_2emap_24s1366476796x894764441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_24dps_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1415906091x1371825187_24dps(V, V);
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_24dps_clo;
V g_list_2emap_24s1417440002x1148747973(V, V, V, V, V, V);
V g_list_2emap_24s1417440002x1148747973_entry(V self, V *a);
extern Clo g_list_2emap_24s1417440002x1148747973_clo;
V g_list_2emap_24s1417440002x1148747973_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s1417440002x1148747973_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1417440002x1148747973_24dps_clo;
V g_list_2emap_24s1512396752x1753792987_24dps(V, V, V, V);
V g_list_2emap_24s1512396752x1753792987_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1512396752x1753792987_24dps_clo;
V g_list_2emap_24s1524528409x1420927362(V);
V g_list_2emap_24s1524528409x1420927362_entry(V self, V *a);
extern Clo g_list_2emap_24s1524528409x1420927362_clo;
V g_list_2emap_24s1524528409x1420927362_24dps(V, V);
V g_list_2emap_24s1524528409x1420927362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1524528409x1420927362_24dps_clo;
V g_list_2emap_24s1534167768x1221742344(V);
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_clo;
V g_list_2emap_24s1534167768x1221742344_24dps(V, V);
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_24dps_clo;
V g_list_2emap_24s159228909x554161698_24dps(V, V, V, V, V);
V g_list_2emap_24s159228909x554161698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_24dps_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s1675313341x192238134_24dps(V, V);
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_24dps_clo;
V g_list_2emap_24s1791433880x1360378684_24dps(V, V);
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_24dps_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1846289357x1055790465_24dps(V, V, V);
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s2087317732x355496638_24dps(V, V);
V g_list_2emap_24s2087317732x355496638_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_24dps_clo;
V g_list_2emap_24s224183526x935259397(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s224183526x935259397_entry(V self, V *a);
extern Clo g_list_2emap_24s224183526x935259397_clo;
V g_list_2emap_24s224183526x935259397_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s224183526x935259397_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s224183526x935259397_24dps_clo;
V g_list_2emap_24s24324293x740715900_24dps(V, V, V);
V g_list_2emap_24s24324293x740715900_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s24324293x740715900_24dps_clo;
V g_list_2emap_24s391650521x1406868658_24dps(V, V);
V g_list_2emap_24s391650521x1406868658_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391650521x1406868658_24dps_clo;
V g_list_2emap_24s866308031x234213482_24dps(V, V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2epushRun_24s226385754x906688275(V, V, V, V, V);
V g_list_2epushRun_24s226385754x906688275_entry(V self, V *a);
extern Clo g_list_2epushRun_24s226385754x906688275_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_list_2ezipWith_24s634456687x1151454243_24dps(V, V, V);
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_list_2efoldl_24s65689923x209800052_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s65689923x209800052_entry, 3, 0};

V g_list_2efoldl_24s65689923x209800052(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x3_242, 1);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s65689923x209800052(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eall_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_entry, 2, 0};

V g_list_2eall(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1415906091x1371825187_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_entry, 1, 0};

V g_list_2emap_24s1415906091x1371825187(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1415906091x1371825187_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187(a[0]);
}
Clo g_list_2emap_24s1937570095x2110149801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_entry, 1, 0};

V g_list_2emap_24s1937570095x2110149801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1937570095x2110149801_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801(a[0]);
}
Clo g_list_2eascending_24s1547370222x166817322_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s1547370222x166817322_entry, 3, 0};

V g_list_2eascending_24s1547370222x166817322(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 6);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_242, 0);
    V v_ys_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_intLe_c(heff_get_n(v_x_240, 0, 6), heff_dup(heff_rfield(v_y_244, 0)))) {
      V t_0 = heff_dup(v_y_244);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_acc_241});
      V t_2 = v_ys_245;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    } else {
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_ys_245})});
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2eascending_24s1547370222x166817322_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s1547370222x166817322(a[0], a[1], a[2]);
}
Clo g_list_2edescending_24s1706700342x2062518382_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s1706700342x2062518382_entry, 3, 0};

V g_list_2edescending_24s1706700342x2062518382(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 6);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x4_242, 0);
    V v_ys_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_intLe_c(heff_get_n(v_x_240, 0, 6), heff_dup(heff_rfield(v_y_243, 0)))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_ys_244})});
    } else {
      V t_0 = heff_dup(v_y_243);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_acc_241});
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2edescending_24s1706700342x2062518382_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s1706700342x2062518382(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1137631697x622554211_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1137631697x622554211_entry, 2, 0};

V g_list_2eany_24s1137631697x622554211(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(v_x_242))) {
      heff_drop_rec(v_lit_240, 7);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1137631697x622554211_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1137631697x622554211(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s1220384081x1312205021_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1220384081x1312205021_entry, 1, 0};

V g_list_2eall_24s1220384081x1312205021(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if ((heff_dup(v_x_241) == NTAG(TAG_True))) {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1220384081x1312205021_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1220384081x1312205021(a0); heff_drop(a0); return r;
}
V g_list_2emap_24s1512396752x1753792987_24dps_lam0(V self, V *args);
Clo g_list_2emap_24s1512396752x1753792987_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1512396752x1753792987_24dps_entry, 4, 0};

V g_list_2emap_24s1512396752x1753792987_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_th_246 = heff_dup(v_lit_240);
    V v_tags_247 = heff_take_field(v_th_246, 1);
    V v_at_248 = heff_get_n(v_th_246, 0, 2);
    V v_go_249 = heff_dup(v_lit_241);
    V v_s_2410 = v_x_244;
    V v_t_24143;
    switch (heff_tag_of(v_s_2410)) {
    case TAG_CDrop: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CLet: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CDecl: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CSet: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CAbandon: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CIf: {
      V v_c_2417 = heff_field(v_s_2410, 0);
      V v_a_2418 = heff_field(v_s_2410, 1);
      V v_b_2419 = heff_field(v_s_2410, 2);
      V v_ru_24s_2410_24CIf = heff_take_reuse_n(v_s_2410, 7ULL, 3);
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      V v_t_2420 = heff_tr(heff_call(heff_dup(v_go_249), 1, (V[]){v_a_2418}));
      V v_t_2421 = heff_tr(heff_call(v_go_249, 1, (V[]){v_b_2419}));
      v_t_24143 = heff_tag_at_n(v_ru_24s_2410_24CIf, TAG_CIf, 3, (V[]){v_c_2417, v_t_2420, v_t_2421});
      break;
    }
    case TAG_CSwitch: {
      V v_e_2422 = heff_field(v_s_2410, 0);
      V v_arms_2423 = heff_field(v_s_2410, 1);
      V v_r_2424 = heff_field(v_s_2410, 2);
      V v_ru_24s_2410_24CSwitch = heff_take_reuse_n(v_s_2410, 7ULL, 3);
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      V v_t_2435 = (g_list_2emap(heff_clo_n(g_list_2emap_24s1512396752x1753792987_24dps_lam0, 1, 1, (V[]){v_go_249}), v_arms_2423));
      v_t_24143 = heff_tag_at_n(v_ru_24s_2410_24CSwitch, TAG_CSwitch, 3, (V[]){v_e_2422, v_t_2435, v_r_2424});
      break;
    }
    case TAG_CReturn: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CInPlace: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CRoomed: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CTail: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CLoop: {
      V v_ps_2443 = heff_field(v_s_2410, 0);
      V v_vs_2444 = heff_field(v_s_2410, 1);
      V v_ru_24s_2410_24CLoop = heff_take_reuse_n(v_s_2410, 3ULL, 2);
      heff_drop(v_go_249);
      V v_ts_2445 = v_tags_247;
      HeffT2 v_t_2446 = (g_heff_2ecompile_2erefcount_2enthValue_24cpr(v_at_248, v_vs_2444));
      V v_x3_24134;
      {
        V v_field_2448 = v_t_2446.f[1];
        int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
        if ((v_tag_2447 == ((int64_t)0ULL))) {
          V v_v1_2449 = v_field_2448;
          switch (heff_tag_of(v_v1_2449)) {
          case TAG_RLocal: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDup: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RClo: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGet: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetRaw: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RInt: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFloat: {
            heff_take_na(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RStr: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBytes: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixed: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32: {
            heff_take_na(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RNTag: {
            V v_t_2462 = heff_field(v_v1_2449, 0);
            V v_ru_24v1_2449_24RNTag = heff_take_reuse_n(v_v1_2449, 1ULL, 1);
            V v_t_2463 = ({ V a_0 = v_t_2462; V a_1 = v_ts_2445; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_ts_2445); r_; });
            if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
              heff_drop(v_t_2463);
              v_x3_24134 = heff_tag_at_n(v_ru_24v1_2449_24RNTag, TAG_Just, 1, (V[]){v_t_2462});
            } else {
              heff_drop(v_t_2462);
              heff_drop_cell(v_ru_24v1_2449_24RNTag, 1);
              heff_drop(v_t_2463);
              v_x3_24134 = NTAG(TAG_Nothing);
            }
            break;
          }
          case TAG_RTag: {
            heff_take_n(v_v1_2449, 0ULL, 3);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTagIn: {
            heff_take_n(v_v1_2449, 0ULL, 4);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRec: {
            heff_take_n(v_v1_2449, 0ULL, 3);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRecIn: {
            heff_take_n(v_v1_2449, 0ULL, 8);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RField: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDupE: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldV: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetN: {
            heff_take_n(v_v1_2449, 0ULL, 3);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldU: {
            heff_take_n(v_v1_2449, 0ULL, 4);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetNU: {
            heff_take_n(v_v1_2449, 0ULL, 5);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RWord: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTakeField: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetLabel: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimFn: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrim: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RLam: {
            heff_take_n(v_v1_2449, 0ULL, 4);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RCall: {
            heff_take_n(v_v1_2449, 0ULL, 4);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RApply: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBool: {
            heff_take_n(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RAbandon: {
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBox: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RUnbox: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPeek: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimU: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimAt: {
            heff_take_n(v_v1_2449, 0ULL, 3);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixU: {
            heff_take_n(v_v1_2449, 0ULL, 2);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32U: {
            heff_take_na(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF64U: {
            heff_take_na(v_v1_2449, 0ULL, 1);
            heff_drop(v_ts_2445);
            v_x3_24134 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2449);
          }
        } else {
          heff_drop(v_ts_2445);
          heff_drop(v_field_2448);
          v_x3_24134 = NTAG(TAG_Nothing);
        }
      }
      switch (heff_tag_of(v_x3_24134)) {
      case TAG_Nothing: {
        v_t_24143 = heff_tag_at_n(v_ru_24s_2410_24CLoop, TAG_CLoop, 2, (V[]){v_ps_2443, v_vs_2444});
        break;
      }
      case TAG_Just: {
        V v_t_24135 = heff_field(v_x3_24134, 0);
        heff_take_n(v_x3_24134, 1ULL, 1);
        heff_drop_cell(v_ru_24s_2410_24CLoop, 2);
        v_t_24143 = heff_tag_n(TAG_CLoopTo, 3, (V[]){v_t_24135, v_ps_2443, v_vs_2444});
        break;
      }
      default: heff_nomatch(v_x3_24134);
      }
      break;
    }
    case TAG_CLoopTo: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CLabel: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    case TAG_CJump: {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_go_249);
      v_t_24143 = v_s_2410;
      break;
    }
    default: heff_nomatch(v_s_2410);
    }
    V v_cell_24144 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_24143, heff_hole()});
    V v_u_24145 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_24144));
    heff_drop(v_u_24145);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_24144;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1512396752x1753792987_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1512396752x1753792987_24dps(a[0], a[1], a[2], a[3]);
}
V g_list_2emap_24s1512396752x1753792987_24dps_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_go_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkCArm: {
    V v_t_2426 = heff_field(v_x2_2425, 0);
    V v_fs_2427 = heff_field(v_x2_2425, 1);
    V v_fl_2428 = heff_field(v_x2_2425, 2);
    V v_su_2429 = heff_field(v_x2_2425, 3);
    V v_pl_2430 = heff_field(v_x2_2425, 4);
    V v_tk_2431 = heff_field(v_x2_2425, 5);
    V v_body_2432 = heff_field(v_x2_2425, 6);
    V v_lv_2433 = heff_field(v_x2_2425, 7);
    V v_ru_24x2_2425_24MkCArm = heff_take_reuse_n(v_x2_2425, 255ULL, 8);
    V v_t_2434 = heff_tr(heff_call(v_go_249, 1, (V[]){v_body_2432}));
    return heff_tag_at_n(v_ru_24x2_2425_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2426, v_fs_2427, v_fl_2428, v_su_2429, v_pl_2430, v_tk_2431, v_t_2434, v_lv_2433});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
Clo g_list_2emap_24s1417440002x1148747973_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1417440002x1148747973_entry, 6, 0};

V g_list_2emap_24s1417440002x1148747973(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2ebounds_2efixSt(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_lit_243, heff_dup(v_lit_244), v_x_246));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1417440002x1148747973_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1417440002x1148747973_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24s1417440002x1148747973(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s2104458007x128868622_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2104458007x128868622_entry, 2, 0};

V g_list_2efoldl_24s2104458007x128868622(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_x_242, NTAG(TAG_Nil)));
    V v_t_245 = (g_list_2emap_24s1415906091x1371825187(v_t_244));
    V v_t_246 = ({ V a_0 = v_z_240; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s278088687x1269971185(a_0, a_1)); heff_drop(v_t_245); r_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2104458007x128868622_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2104458007x128868622(a[0], a1); heff_drop(a1); return r;
}
V g_list_2eall_24s1395959145x1097496552_lam0(V self, V *args);
V g_list_2eall_24s1395959145x1097496552_lam1(V self, V *args);
Clo g_list_2eall_24s1395959145x1097496552_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1395959145x1097496552_entry, 2, 0};

V g_list_2eall_24s1395959145x1097496552(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_244 = heff_dup(v_lit_240);
    V v_a_245 = v_x_242;
    V v_n_246 = heff_take_field(v_a_245, 1);
    V v_labels_247 = heff_get_n(v_a_245, 2, 3);
    if ((heff_intLt_c_lent(MK_INT(0LL), v_n_246, 1) && ({ V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_labels_247)); int c_ = (heff_intLe_c_lent(v_t_2422, MK_INT(16LL), 2) && ({ V v_c_2423 = (g_list_2eall(heff_clo_n(g_list_2eall_24s1395959145x1097496552_lam0, 1, 2, (V[]){heff_dup(v_c_244), heff_dup(v_n_246)}), v_labels_247)); int c_ = ((heff_dup(v_c_2423) == NTAG(TAG_True)) && ({ V v_t_2424 = (g_list_2efoldl(heff_clo_n(g_list_2eall_24s1395959145x1097496552_lam1, 2, 1, (V[]){heff_dup(v_c_244)}), MK_INT(0LL), v_labels_247)); int c_ = heff_intLe_c_lent(v_t_2424, MK_INT(4000LL), 2); heff_drop(v_t_2424); c_; })); heff_drop(v_c_2423); c_; })); heff_drop(v_t_2422); c_; }))) {
      heff_drop_rec(v_c_244, 5);
      heff_drop(v_n_246);
      heff_drop(v_labels_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_xs_243);
      heff_drop_rec(v_c_244, 5);
      heff_drop(v_n_246);
      heff_drop(v_labels_247);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s1395959145x1097496552_entry(V self, V *a) {
  (void)self;
  return g_list_2eall_24s1395959145x1097496552(a[0], a[1]);
}
V g_list_2eall_24s1395959145x1097496552_lam0(V self, V *args) {
  V v_l_248 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_n_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_c_244, 4, 5); V a_1 = v_l_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_l_248); r_; });
  V v_t_2413;
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2411;
      v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2412, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    } else {
      heff_drop(v_field_2411);
      v_t_2413 = MK_INT(0LL);
    }
  }
  V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_t_2413, v_n_246, 0));
  heff_drop(v_n_246);
  heff_drop(v_t_2413);
  return v_ret_24bool;
}
V g_list_2eall_24s1395959145x1097496552_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_l_2415 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_c_244, 4, 5); V a_1 = v_l_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_l_2415); r_; });
  V v_t_2421;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_2419, 1, 2), NTAG(TAG_Nil)});
      v_t_2421 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2420));
    } else {
      heff_drop(v_field_2418);
      v_t_2421 = MK_INT(0LL);
    }
  }
  return heff_intAdd(v_n_2414, v_t_2421);
}
Clo g_list_2efoldl_24s1606891938x229778616_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1606891938x229778616_entry, 2, 0};

V g_list_2efoldl_24s1606891938x229778616(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1606891938x229778616(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s866308031x234213482_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s866308031x234213482_24dps_entry, 6, 0};

V g_list_2emap_24s866308031x234213482_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_key_248 = heff_dup(v_lit_240);
    V v_n_249 = heff_dup(v_lit_241);
    V v_at_2410 = heff_dup(v_lit_242);
    V v_l_2411 = heff_dup(v_lit_243);
    V v_x5_2412 = v_x_246;
    V v_t_2438;
    switch (heff_tag_of(v_x5_2412)) {
    case TAG_MkArm: {
      V v_vs_2414 = heff_field(v_x5_2412, 1);
      V v_b_2415 = heff_field(v_x5_2412, 2);
      heff_take_n(v_x5_2412, 6ULL, 3);
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_2415), NTAG(TAG_Nil)});
      V v_t_2417 = (g_heff_2ecompile_2eir_2ecountW(v_l_2411, MK_INT(0LL), v_t_2416));
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2415), NTAG(TAG_Nil)});
      V v_t_2419 = ({ V a_0 = v_l_2411; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_l_2411); r_; });
      V v_x_2420 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2417, v_t_2419}), 0, 2);
      if (heff_intLt_c(MK_INT(0LL), v_x_2420)) {
        heff_drop(v_key_248);
        heff_drop(v_n_249);
        heff_drop(v_at_2410);
        heff_drop(v_vs_2414);
        heff_drop(v_b_2415);
        v_t_2438 = NTAG(TAG_Nothing);
      } else {
        V v_t_2421 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2415)));
        V v_xs_2422 = (g_heff_2ecompile_2eir_2enubI(v_t_2421));
        V v_x1_2423 = ({ V a_0 = v_key_248; V a_1 = v_xs_2422; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2422); r_; });
        if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
          heff_drop(v_key_248);
          heff_drop(v_n_249);
          heff_drop(v_at_2410);
          heff_drop(v_vs_2414);
          heff_drop(v_b_2415);
          heff_drop(v_x1_2423);
          v_t_2438 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
        } else {
          heff_drop(v_x1_2423);
          V v_x1_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2414));
          switch (heff_tag_of(v_x1_2424)) {
          case TAG_Nil: {
            heff_drop(v_key_248);
            heff_drop(v_n_249);
            heff_drop(v_at_2410);
            heff_drop(v_b_2415);
            v_t_2438 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_x_2425 = heff_field(v_x1_2424, 0);
            V v_ru_24x1_2424_24Cons = heff_take_reuse_n(v_x1_2424, 1ULL, 2);
            V v_me_2427 = heff_rec_n(4, shape_key__arity__at__rest, (V[]){v_key_248, v_n_249, v_at_2410, v_x_2425});
            V v_b_2428 = v_b_2415;
            V v_it_2429 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_2427), heff_dup(v_b_2428)));
            switch (heff_tag_of(v_it_2429)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x1_2424_24Cons, 2);
              heff_drop_rec(v_me_2427, 4);
              heff_drop(v_b_2428);
              v_t_2438 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2430 = heff_field(v_it_2429, 0);
              V v_ru_24it_2429_24Just = heff_take_reuse_n(v_it_2429, 1ULL, 1);
              if (heff_intEq_c(v_it1_2430, MK_INT(1LL))) {
                V v_x_2431 = heff_dup(heff_rfield(v_me_2427, 3));
                V v_e_2432 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_2427, v_b_2428));
                V v_t_2433 = heff_tag_at_n(v_ru_24x1_2424_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_e_2432), NTAG(TAG_Nil)});
                V v_t_2434 = (g_heff_2ecompile_2eir_2ecountW(v_x_2431, MK_INT(0LL), v_t_2433));
                V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2432, NTAG(TAG_Nil)});
                V v_t_2436 = ({ V a_0 = v_x_2431; V a_1 = v_t_2435; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2431); r_; });
                V v_x_2437 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2434, v_t_2436}), 0, 2);
                if (heff_intLt_c(MK_INT(0LL), v_x_2437)) {
                  heff_drop_cell(v_ru_24it_2429_24Just, 1);
                  v_t_2438 = NTAG(TAG_Nothing);
                } else {
                  v_t_2438 = heff_tag_at_n(v_ru_24it_2429_24Just, TAG_Just, 1, (V[]){NTAG(TAG_True)});
                }
              } else {
                heff_drop_cell(v_ru_24x1_2424_24Cons, 2);
                heff_drop_rec(v_me_2427, 4);
                heff_drop(v_b_2428);
                heff_drop_cell(v_ru_24it_2429_24Just, 1);
                v_t_2438 = NTAG(TAG_Nothing);
              }
              break;
            }
            default: heff_nomatch(v_it_2429);
            }
            break;
          }
          default: heff_nomatch(v_x1_2424);
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x5_2412);
    }
    V v_cell_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, heff_hole()});
    V v_u_2440 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2439));
    heff_drop(v_u_2440);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_2439;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s866308031x234213482_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s866308031x234213482_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1524528409x1420927362_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1524528409x1420927362_entry, 1, 0};

V g_list_2emap_24s1524528409x1420927362(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24Given = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_243));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24Given, TAG_Given, 1, (V[]){v_t_244});
      break;
    }
    case TAG_GivenU: {
      V v_a_245 = heff_field(v_x_241, 0);
      V v_a_246 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24GivenU = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_246));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24GivenU, TAG_GivenU, 2, (V[]){v_a_245, v_t_247});
      break;
    }
    case TAG_LentVar: {
      v_t_2412 = v_x_241;
      break;
    }
    case TAG_LentValue: {
      V v_a_2410 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24LentValue = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_2411 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_2410));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24LentValue, TAG_LentValue, 1, (V[]){v_t_2411});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s1524528409x1420927362_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1524528409x1420927362_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1524528409x1420927362(a[0]);
}
Clo g_list_2emap_24s391650521x1406868658_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391650521x1406868658_24dps_entry, 2, 0};

V g_list_2emap_24s391650521x1406868658_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391650521x1406868658_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391650521x1406868658_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1066353734x1075193228_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1066353734x1075193228_entry, 2, 0};

V g_list_2ekeepIf_24s1066353734x1075193228(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_AtLeast0: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      switch (heff_tag_of(v_a_244)) {
      case TAG_AtVar: {
        V v_a_245 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        if (!heff_strEq_c_lent(v_lit_240, v_a_245, 0)) {
          heff_drop(v_a_245);
          V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
          V v_u_247 = (g_list_2ekeepIf_24s1066353734x1075193228_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
          heff_drop(v_u_247);
          return v_cell_246;
        } else {
          heff_drop_tag(v_x_242, 1);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_a_245);
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_AtWord: {
        heff_take_n(v_a_244, 0ULL, 1);
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2410 = (g_list_2ekeepIf_24s1066353734x1075193228_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
      default: return heff_nomatch(v_a_244);
      }
    }
    case TAG_Below: {
      V v_a_2411 = heff_dup(heff_field(v_x_242, 0));
      V v_a_2412 = heff_dup(heff_field(v_x_242, 1));
      V v_t_2415;
      switch (heff_tag_of(v_a_2411)) {
      case TAG_AtVar: {
        V v_a_2413 = heff_field(v_a_2411, 0);
        heff_take_n(v_a_2411, 1ULL, 1);
        v_t_2415 = heff_bool(heff_strEq_c_lent(v_lit_240, v_a_2413, 0));
        heff_drop(v_a_2413);
        break;
      }
      case TAG_AtWord: {
        heff_take_n(v_a_2411, 0ULL, 1);
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      if (((heff_dup(v_t_2415) == NTAG(TAG_True)) ? 0 : !heff_strEq_c_lent(v_lit_240, v_a_2412, 0))) {
        heff_drop(v_a_2412);
        heff_drop(v_t_2415);
        V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_2417 = (g_list_2ekeepIf_24s1066353734x1075193228_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2416)));
        heff_drop(v_u_2417);
        return v_cell_2416;
      } else {
        heff_drop_tag(v_x_242, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_a_2412);
        heff_drop(v_t_2415);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1066353734x1075193228_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1066353734x1075193228(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1366476796x894764441_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1366476796x894764441_entry, 2, 0};

V g_list_2emap_24s1366476796x894764441(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1366476796x894764441_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1366476796x894764441(a[0], a[1]);
}
Clo g_list_2emap_24s24324293x740715900_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s24324293x740715900_24dps_entry, 3, 0};

V g_list_2emap_24s24324293x740715900_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2411 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_247, heff_dup(v_lit_240)), v_t_2411);
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2413;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s24324293x740715900_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s24324293x740715900_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1533929316x1834489357_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1533929316x1834489357_entry, 2, 0};

V g_list_2efoldl_24s1533929316x1834489357(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      v_t_2412 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_t_249, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1533929316x1834489357_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1533929316x1834489357(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1846289357x1055790465_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1846289357x1055790465_24dps_entry, 3, 0};

V g_list_2emap_24s1846289357x1055790465_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1846289357x1055790465_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s547379716x1342911792_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s547379716x1342911792_entry, 3, 0};

V g_list_2efoldl_24s547379716x1342911792(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_2419;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        if ((heff_strEq_c_lent(v_a_247, v_lit_240, 0) ? 0 : !heff_strEq_c_lent(v_a_247, v_a_245, 0))) {
          V v_t_248 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_a_247), heff_dup(v_a_245)));
          v_t_2419 = heff_tr(heff_call(heff_get_n(v_t_248, 3, 5), 1, (V[]){v_z_241}));
        } else {
          v_t_2419 = v_z_241;
        }
        break;
      }
      case TAG_PTag: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PLit: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PRec: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PAs: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PBin: {
        v_t_2419 = v_z_241;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2419;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s547379716x1342911792_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s547379716x1342911792(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s958254147x1083401940_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s958254147x1083401940_24dps_entry, 13, 0};

V g_list_2ekeepIf_24s958254147x1083401940_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411, V v_d_2412) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_2412, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    V v_xs_2414 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_a_2415 = heff_dup(heff_rfield(v_x_2413, 0));
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2415, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2415);
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){v_x_2413, heff_hole()});
      V v_u_2417 = heff_setField(v_d_2412, MK_INT(1LL), heff_dup(v_cell_2416));
      heff_drop(v_u_2417);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_cell_2416;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    } else {
      heff_drop_rec(v_x_2413, 2);
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_a_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_d_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2ekeepIf_24s958254147x1083401940_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2ekeepIf_24s958254147x1083401940_24dps(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11], a[12]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
HEFF_LIT(g_list_2emap_24s1534167768x1221742344_str0, 56, "only the library that goes with heff declares primitives");
Clo g_list_2emap_24s1534167768x1221742344_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534167768x1221742344_entry, 1, 0};

V g_list_2emap_24s1534167768x1221742344(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1534167768x1221742344_str0), v_sp_244, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1534167768x1221742344_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534167768x1221742344(a[0]);
}
Clo g_list_2efoldl_24s1271133029x1548514599_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1271133029x1548514599_entry, 2, 0};

V g_list_2efoldl_24s1271133029x1548514599(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 6)), heff_dup(heff_rfield(v_x_242, 4))));
    V v_a_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 5), v_t_244));
    V v_t_246 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_a_245, 0))));
    V v_a_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V a_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1271133029x1548514599_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1271133029x1548514599(a[0], a[1]);
}
V g_list_2ecollapse_24s1189723159x1707000933_lam0(V self, V *args);
Clo g_list_2ecollapse_24s1189723159x1707000933_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s1189723159x1707000933_entry, 4, 0};

V g_list_2ecollapse_24s1189723159x1707000933(V v_lit_240, V v_lit_241, V v_run_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_run_242;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_rest_245 = heff_field(v_x3_243, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_below_247 = heff_field(v_x31_244, 1);
      V v_t_2411 = (g_list_2emerge(heff_clo_n(g_list_2ecollapse_24s1189723159x1707000933_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), heff_dup(v_below_247), v_run_242));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_2411;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_run_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2ecollapse_24s1189723159x1707000933_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2ecollapse_24s1189723159x1707000933(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_list_2ecollapse_24s1189723159x1707000933_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_249 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2410 = heff_strCompare(v_a_248, v_a_249);
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2410, v_lit_240, 0) || heff_intEq_c_lent(v_a_2410, v_lit_241, 0)));
  heff_drop(v_lit_240);
  heff_drop(v_lit_241);
  heff_drop(v_a_2410);
  return v_ret_24bool;
}
Clo g_list_2emap_24s224183526x935259397_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s224183526x935259397_entry, 10, 0};

V g_list_2emap_24s224183526x935259397(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_id_2412 = heff_take_field(v_x_2410, 0);
    V v_assoc_2413 = heff_take_field(v_x_2410, 1);
    V v_loosest_2414 = heff_take_field(v_x_2410, 3);
    V v_ops_2415 = heff_get_n(v_x_2410, 2, 5);
    V v_t_2416;
    switch (heff_tag_of(v_assoc_2413)) {
    case TAG_AssocLeft: {
      v_t_2416 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2416 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2416 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_assoc_2413);
    }
    V v_t_2417 = heff_strAppend(heff_strAppend(v_id_2412, heff_dup(v_lit_240)), heff_intShow(v_t_2416));
    V v_t_2418;
    if ((heff_dup(v_loosest_2414) == NTAG(TAG_True))) {
      heff_drop(v_loosest_2414);
      v_t_2418 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_loosest_2414);
      v_t_2418 = heff_dup(v_lit_245);
    }
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2417, v_t_2418), heff_dup(v_lit_246));
    V v_t_2422;
    switch (heff_tag_of(v_ops_2415)) {
    case TAG_Nil: {
      v_t_2422 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2420 = heff_field(v_ops_2415, 0);
      V v_a_2421 = heff_field(v_ops_2415, 1);
      heff_take_n(v_ops_2415, 3ULL, 2);
      v_t_2422 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2420; V a_2 = v_a_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2421); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2415);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, v_t_2422), heff_hole()});
    V v_u_2424 = (g_list_2emap_24s224183526x935259397_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_xs_2411, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s224183526x935259397_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s224183526x935259397(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2ezipWith_24s634456687x1151454243_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634456687x1151454243_entry, 2, 0};

V g_list_2ezipWith_24s634456687x1151454243(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 3), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s634456687x1151454243_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634456687x1151454243(a[0], a[1]);
}
Clo g_list_2emap_24s1791433880x1360378684_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1791433880x1360378684_24dps_entry, 2, 0};

V g_list_2emap_24s1791433880x1360378684_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1791433880x1360378684_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2087317732x355496638_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2087317732x355496638_24dps_entry, 2, 0};

V g_list_2emap_24s2087317732x355496638_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2087317732x355496638_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2087317732x355496638_24dps(a[0], a[1]);
}
Clo g_list_2eascending_24s1147438953x64854941_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s1147438953x64854941_entry, 3, 0};

V g_list_2eascending_24s1147438953x64854941(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 5);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_242, 0);
    V v_ys_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_240, 0)), 1, 2);
    V v_t_247 = heff_get_n(heff_get_n(v_x_240, 0, 5), 0, 2);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 1, 2);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 0, 2);
    if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249))) {
      V t_0 = heff_dup(v_y_244);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_acc_241});
      V t_2 = v_ys_245;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    } else {
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_ys_245})});
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2eascending_24s1147438953x64854941_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s1147438953x64854941(a[0], a[1], a[2]);
}
Clo g_list_2edescending_24s1092102222x1336838254_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s1092102222x1336838254_entry, 3, 0};

V g_list_2edescending_24s1092102222x1336838254(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 5);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x4_242, 0);
    V v_ys_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_240, 0)), 1, 2);
    V v_t_246 = heff_get_n(heff_get_n(v_x_240, 0, 5), 0, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_y_243, 0)), 1, 2);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_243, 0)), 0, 2);
    if (heff_intLe_c(heff_intSub(v_t_245, v_t_246), heff_intSub(v_t_247, v_t_248))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_ys_244})});
    } else {
      V t_0 = heff_dup(v_y_243);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_acc_241});
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2edescending_24s1092102222x1336838254_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s1092102222x1336838254(a[0], a[1], a[2]);
}
V g_list_2epushRun_24s226385754x906688275_lam0(V self, V *args);
Clo g_list_2epushRun_24s226385754x906688275_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s226385754x906688275_entry, 5, 0};

V g_list_2epushRun_24s226385754x906688275(V v_lit_240, V v_lit_241, V v_k_242, V v_run_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_244, 0);
    V v_rest_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_j_247 = heff_field(v_x41_245, 0);
      V v_below_248 = heff_field(v_x41_245, 1);
      V v_ru_24x41_245_24MkPair = heff_take_reuse_n(v_x41_245, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_247, v_k_242, 0)) {
        heff_drop_cell(v_ru_24x4_244_24Cons, 2);
        heff_drop(v_j_247);
        heff_drop_cell(v_ru_24x41_245_24MkPair, 2);
        V v_t_2412 = (g_list_2emerge(heff_clo_n(g_list_2epushRun_24s226385754x906688275_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_below_248, v_run_243));
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
        V t_3 = v_t_2412;
        V t_4 = v_rest_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_k_242 = t_2;
        v_run_243 = t_3;
        v_x4_244 = t_4;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        V v_t_2413 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_245_24MkPair, TAG_MkPair, 2, (V[]){v_j_247, v_below_248}), v_rest_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), v_t_2413});
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2epushRun_24s226385754x906688275_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s226385754x906688275(a[0], a[1], a[2], a[3], a[4]);
}
V g_list_2epushRun_24s226385754x906688275_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2411 = heff_strCompare(heff_get_n(v_a_249, 0, 2), heff_get_n(v_a_2410, 0, 2));
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2411, v_lit_240, 0) || heff_intEq_c_lent(v_a_2411, v_lit_241, 0)));
  heff_drop(v_lit_240);
  heff_drop(v_lit_241);
  heff_drop(v_a_2411);
  return v_ret_24bool;
}
Clo g_list_2emap_24s1675313341x192238134_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_entry, 1, 0};

V g_list_2emap_24s1675313341x192238134(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_fsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 2ULL, 4);
        v_t_249 = v_fsp_246;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1675313341x192238134_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134(a[0]);
}
Clo g_list_2ekeepIf_24s2085003797x1793382462_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2085003797x1793382462_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s2085003797x1793382462_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2085003797x1793382462_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2085003797x1793382462_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str0, 4, "std.");
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str1, 1, "`");
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str2, 81, "` is an effect of the system (lib/std/), for C: it has no provider for --backend=");
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str3, 1, "`");
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str4, 89, "` is the system's (lib/std/), for C: it imports an effect with no provider for --backend=");
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str5, 1, "`");
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str6, 19, "` is that effect: `");
HEFF_LIT(g_list_2emap_24s159228909x554161698_24dps_str7, 2, "` ");
Clo g_list_2emap_24s159228909x554161698_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159228909x554161698_24dps_entry, 5, 0};

V g_list_2emap_24s159228909x554161698_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_host_247 = heff_dup(v_lit_240);
    V v_sources_248 = heff_dup(v_lit_241);
    V v_only_249 = heff_dup(v_lit_242);
    V v_s_2410 = v_x_245;
    V v_t_2435;
    if (((heff_dup(heff_rfield(v_s_2410, 7)) == NTAG(TAG_True)) ? !heff_strEq_c(heff_strSlice(heff_dup(heff_rfield(v_s_2410, 0)), MK_INT(0LL), MK_INT(4LL)), ((V)&g_list_2emap_24s159228909x554161698_24dps_str0)) : 1)) {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_host_247);
      heff_drop(v_sources_248);
      heff_drop(v_only_249);
      heff_drop_rec(v_s_2410, 8);
      v_t_2435 = NTAG(TAG_Nothing);
    } else {
      V v_t_2411 = (g_list_2eany_24s1477604419x1568736711(heff_rfield(v_s_2410, 0), v_only_249));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_sources_248);
        heff_drop(v_only_249);
        heff_drop(v_t_2411);
        V v_t_2412 = heff_strAppend(((V)&g_list_2emap_24s159228909x554161698_24dps_str1), heff_dup(heff_rfield(v_s_2410, 0)));
        V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_list_2emap_24s159228909x554161698_24dps_str2)), v_host_247);
        V v_t_2414 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_2410, 0, 8), MK_INT(352LL), v_t_2413, NTAG(TAG_Nothing)});
        v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
      } else {
        heff_drop(v_t_2411);
        V v_t_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_s_2410, 0)), NTAG(TAG_Nil)});
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        HeffT2 v_t_2417 = ({ V a_0 = v_sources_248; V a_1 = v_only_249; V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2416; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_sources_248); heff_drop(v_only_249); r_; });
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_x_2420 = v_field_2419;
            V v_host_2421 = v_host_247;
            V v_s_2422 = v_s_2410;
            V v_path_2423 = v_x_2420;
            V v_t_2424 = heff_strAppend(((V)&g_list_2emap_24s159228909x554161698_24dps_str3), heff_dup(heff_rfield(v_s_2422, 0)));
            V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_list_2emap_24s159228909x554161698_24dps_str4)), v_host_2421);
            V v_x1_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_2423)));
            V v_t_2429;
            switch (heff_tag_of(v_x1_2426)) {
            case TAG_Nil: {
              v_t_2429 = heff_dup(heff_rfield(v_s_2422, 0));
              break;
            }
            case TAG_Cons: {
              V v_x_2427 = heff_field(v_x1_2426, 0);
              heff_take_n(v_x1_2426, 1ULL, 2);
              v_t_2429 = v_x_2427;
              break;
            }
            default: heff_nomatch(v_x1_2426);
            }
            V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s159228909x554161698_24dps_str5), v_t_2429), ((V)&g_list_2emap_24s159228909x554161698_24dps_str6));
            V v_t_2431 = heff_strAppend(v_t_2430, heff_dup(heff_rfield(v_s_2422, 0)));
            V v_t_2432 = (g_heff_2ebuild_2ecommands_2eimportsOn(v_path_2423));
            V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_list_2emap_24s159228909x554161698_24dps_str7)), v_t_2432);
            V v_t_2434 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_2422, 0, 8), MK_INT(352LL), v_t_2425, heff_tag_n(TAG_Just, 1, (V[]){v_t_2433})});
            v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2434});
          } else {
            heff_drop(v_host_247);
            heff_drop_rec(v_s_2410, 8);
            heff_drop(v_field_2419);
            v_t_2435 = NTAG(TAG_Nothing);
          }
        }
      }
    }
    V v_cell_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_hole()});
    V v_u_2437 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2436));
    heff_drop(v_u_2437);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2436;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s159228909x554161698_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s159228909x554161698_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2eany_24s1255781029x1672221493_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1255781029x1672221493_entry, 2, 0};

V g_list_2eany_24s1255781029x1672221493(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_x_242))) {
      heff_drop_rec(v_lit_240, 2);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1255781029x1672221493_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1255781029x1672221493(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s689992630x418898235_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s689992630x418898235_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s689992630x418898235_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_lit_240, 0);
      v_t_2410 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (!heff_strEq_c_lent(v_t_247, v_t_2410, 0)) {
      heff_drop(v_t_247);
      heff_drop(v_t_2410);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2412 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2411;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_247);
      heff_drop(v_t_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s689992630x418898235_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s689992630x418898235_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s670012890x84869279_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ekeepIf_24s920421308x594300259_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s920421308x594300259_entry, 3, 0};

V g_list_2ekeepIf_24s920421308x594300259(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = heff_strSlice(v_t_247, heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_248, v_lit_241, 1)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s920421308x594300259_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s920421308x594300259_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s920421308x594300259(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1325733028x1311723093_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1325733028x1311723093_entry, 3, 0};

V g_list_2efoldl_24f1325733028x1311723093(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if ((heff_dup(v_x_243) == NTAG(TAG_True))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1325733028x1311723093_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1325733028x1311723093(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f2081800072x871100793_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2081800072x871100793_24dps_entry, 2, 0};

V g_list_2emap_24f2081800072x871100793_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_path_244 = heff_take_field(v_x_242, 1);
    V v_name_245 = heff_get_n(v_x_242, 0, 3);
    if (heff_strEq_c(v_path_244, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_name_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_xs_243;
      V t_1 = v_cell_246;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f2081800072x871100793_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2081800072x871100793_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f904804876x285797696_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f904804876x285797696_24dps_entry, 4, 0};

V g_list_2emap_24f904804876x285797696_24dps(V v_f_240, V v_box_24a_241, V v_box_24b_242, V v_d_243) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
  int64_t v_b_242 = heff_unbox_word(v_box_24b_242);
top: ;
  if ((v_b_242 < v_a_241)) {
    heff_drop(v_f_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_box_word(v_a_241)}));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_f_240;
    int64_t t_1 = (v_a_241 + ((int64_t)1ULL));
    int64_t t_2 = v_b_242;
    V t_3 = v_cell_245;
    v_f_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f904804876x285797696_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1141799624x1826918381_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1141799624x1826918381_24dps_entry, 4, 0};

V g_list_2emap_24f1141799624x1826918381_24dps(V v_lit_240, V v_p_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_244, 0, 8));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1141799624x1826918381_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1141799624x1826918381_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f545139853x5269120_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f545139853x5269120_entry, 2, 0};

V g_list_2efoldl_24f545139853x5269120(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 0));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Positional: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_z_240;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Flagged: {
      heff_take_n(v_t_244, 0ULL, 1);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f545139853x5269120(a[0], a[1]);
}