// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_absolute 325777132
#define LBL_drive 297211300
#define LBL_segments 1801007612
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2ejoin_2eonto_240_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2epath_2ejoin_2eonto_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ejoin_2eonto_240_entry, 2, 0};

V g_std_2epath_2ejoin_2eonto_240(V v_p_240, V v_q_241) {
top: ;
  V v_t_242 = heff_strEq(heff_get(heff_dup(v_q_241), LBL_drive), ((V)&g_std_2epath_2ejoin_2eonto_240_str0));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_get(heff_dup(v_q_241), LBL_absolute);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(v_p_240, LBL_drive), NTAG(TAG_True), heff_get(v_q_241, LBL_segments)});
    }
    case TAG_False: {
      V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_p_240), LBL_segments), heff_get(v_q_241, LBL_segments)));
      return heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_240), LBL_drive), heff_get(v_p_240, LBL_absolute), v_t_244});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    heff_drop(v_p_240);
    return v_q_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2ejoin_2eonto_240(a[0], a[1]);
}