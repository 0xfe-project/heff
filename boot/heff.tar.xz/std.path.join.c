// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_absolute 325777132
#define LBL_drive 297211300
#define LBL_segments 1801007612
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
HEFF_LIT(g_std_2epath_2ejoin_2eonto_240_str0, 0, "");
Clo g_std_2epath_2ejoin_2eonto_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ejoin_2eonto_240_entry, 2, 0};

V g_std_2epath_2ejoin_2eonto_240(V v_p_240, V v_q_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_q_241, 0)), ((V)&g_std_2epath_2ejoin_2eonto_240_str0))) {
    V v_t_243 = heff_take_field(v_q_241, 1);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return ({ V rv_1 = NTAG(TAG_True); V rv_2 = heff_get_n(v_q_241, 2, 3); V rr_ = heff_rec_reuse_nf(v_p_240, 1ULL, 3, shape_drive__absolute__segments, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      heff_drop(v_t_243);
      V v_t_244 = (g_prelude_2e_2b_2b(heff_take_field(v_p_240, 2), heff_get_n(v_q_241, 2, 3)));
      return ({ V rv_2 = v_t_244; V rr_ = heff_rec_reuse_nf(v_p_240, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    }
  } else {
    heff_drop_rec(v_p_240, 3);
    return v_q_241;
  }
}
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2ejoin_2eonto_240(a[0], a[1]);
}