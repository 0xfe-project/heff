// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2ejoin_2eonto_240_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2epath_2ejoin_2eonto_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ejoin_2eonto_240_entry, 2, 0};

V g_std_2epath_2ejoin_2eonto_240(V v_p_240, V v_q_241) {
top: ;
  V v_t_242 = heff_strEq(heff_get(heff_dup(v_q_241), LBL_drive), ((V)&g_std_2epath_2ejoin_2eonto_240_str0));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    V v_t_243 = heff_get(heff_dup(v_q_241), LBL_absolute);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_t_243);
      return heff_rec(3, shape_68_1_280, (V[]){heff_get(v_p_240, LBL_drive), NTAG(TAG_True), heff_get(v_q_241, LBL_segments)});
    }
    case TAG_False: {
      heff_drop(v_t_243);
      V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_p_240), LBL_segments), heff_get(v_q_241, LBL_segments)));
      return heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_240), LBL_drive), heff_get(v_p_240, LBL_absolute), v_t_244});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    heff_drop(v_p_240);
    heff_drop(v_t_242);
    return v_q_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2ejoin_2eonto_240(a[0], a[1]);
}