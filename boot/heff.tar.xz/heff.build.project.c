// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_run 322821
#define LBL_ships 310766033
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
#define LBL_version 583465758
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_backend__run__ships[] = {LBL_backend, LBL_run, LBL_ships};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__dir[] = {LBL_name, LBL_dir};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(V);
V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_clo;
V g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920(V);
V g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_clo;
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo;
V g_heff_2ebuild_2eproject_2eandList(V);
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_clo;
V g_heff_2ebuild_2eproject_2ebackendOf(V);
V g_heff_2ebuild_2eproject_2ebackendOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ebackendOf_clo;
V g_heff_2ebuild_2eproject_2ebuildOf(V);
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ebuildOf_clo;
V g_heff_2ebuild_2eproject_2echeckNames(V, V, V, V);
V g_heff_2ebuild_2eproject_2echeckNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2echeckNames_clo;
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
V g_heff_2ebuild_2eproject_2edeclsGo(V, V, V, V, V);
V g_heff_2ebuild_2eproject_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2edeclsGo_clo;
V g_heff_2ebuild_2eproject_2efieldsAre(V, V);
V g_heff_2ebuild_2eproject_2efieldsAre_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsAre_clo;
V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083(V, V, V);
V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_clo;
V g_heff_2ebuild_2eproject_2efieldsIn(V, V, V);
V g_heff_2ebuild_2eproject_2efieldsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsIn_clo;
V g_heff_2ebuild_2eproject_2efieldsSaid(V);
V g_heff_2ebuild_2eproject_2efieldsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsSaid_clo;
V g_heff_2ebuild_2eproject_2eisName(V);
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisName_clo;
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
V g_heff_2ebuild_2eproject_2eitems(V);
V g_heff_2ebuild_2eproject_2eitems_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eitems_clo;
V g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252(V, V, V);
V g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_clo;
V g_heff_2ebuild_2eproject_2eleftOutNames(V);
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo;
V g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(V, V);
V g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_clo;
V g_heff_2ebuild_2eproject_2emajorMismatch(V, V);
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo;
V g_heff_2ebuild_2eproject_2enameOf(V);
V g_heff_2ebuild_2eproject_2enameOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enameOf_clo;
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2enextDecl(V, V);
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enextDecl_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2eproject_2epackageOf4(V, V, V, V);
V g_heff_2ebuild_2eproject_2epackageOf4_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf4_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2ereadBuild(V);
V g_heff_2ebuild_2eproject_2ereadBuild_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ereadBuild_clo;
V g_heff_2ebuild_2eproject_2ereadPackage(V);
V g_heff_2ebuild_2eproject_2ereadPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ereadPackage_clo;
V g_heff_2ebuild_2eproject_2ereplaceOf(V);
V g_heff_2ebuild_2eproject_2ereplaceOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ereplaceOf_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireOf(V);
V g_heff_2ebuild_2eproject_2erequireOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erequireOf_clo;
V g_heff_2ebuild_2eproject_2eshipWrong(V);
V g_heff_2ebuild_2eproject_2eshipWrong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eshipWrong_clo;
V g_heff_2ebuild_2eproject_2eshowPackage(V);
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eshowPackage_clo;
V g_heff_2ebuild_2eproject_2espanGo(V, V);
V g_heff_2ebuild_2eproject_2espanGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2espanGo_clo;
V g_heff_2ebuild_2eproject_2estr(V);
V g_heff_2ebuild_2eproject_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2estr_clo;
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
V g_heff_2ebuild_2eproject_2esumGo(V, V);
V g_heff_2ebuild_2eproject_2esumGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumGo_clo;
V g_heff_2ebuild_2eproject_2esumLine(V, V);
V g_heff_2ebuild_2eproject_2esumLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumLine_clo;
V g_heff_2ebuild_2eproject_2etwiceGo(V, V);
V g_heff_2ebuild_2eproject_2etwiceGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2etwiceGo_clo;
V g_heff_2ebuild_2eproject_2eunrequired(V, V);
V g_heff_2ebuild_2eproject_2eunrequired_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eunrequired_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2eproject_2eversionOf(V);
V g_heff_2ebuild_2eproject_2eversionOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversionOf_clo;
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_list_2eall_24s107199714x217634386(V, V, V);
V g_list_2eall_24s107199714x217634386_entry(V self, V *a);
extern Clo g_list_2eall_24s107199714x217634386_clo;
V g_list_2eall_24s1821787051x863686734(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s1821787051x863686734_entry(V self, V *a);
extern Clo g_list_2eall_24s1821787051x863686734_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s1626183354x549349049(V);
V g_list_2emap_24s1626183354x549349049_entry(V self, V *a);
extern Clo g_list_2emap_24s1626183354x549349049_clo;
V g_list_2emap_24s336317878x1053990440(V);
V g_list_2emap_24s336317878x1053990440_entry(V self, V *a);
extern Clo g_list_2emap_24s336317878x1053990440_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s546447922x1671206170(V, V);
V g_list_2emap_24s546447922x1671206170_entry(V self, V *a);
extern Clo g_list_2emap_24s546447922x1671206170_clo;
V g_list_2ezipWith_24s568889179x755145155(V, V);
V g_list_2ezipWith_24s568889179x755145155_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s568889179x755145155_clo;
V g_list_2ezipWith_24s868949484x1127836054(V, V);
V g_list_2ezipWith_24s868949484x1127836054_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s868949484x1127836054_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2enextDecl_str0, 3, "eof");
Clo g_heff_2ebuild_2eproject_2enextDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enextDecl_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enextDecl(V v_ts_240, V v_i_241) {
top: ;
  V v_t_242 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2enextDecl_str0))) {
    heff_drop(v_ts_240);
    heff_drop_rec(v_t_242, 7);
    return v_i_241;
  } else {
    V v_t_244 = heff_take_field(v_t_242, 6);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      if (heff_intEq_c(heff_get_n(v_t_242, 5, 7), MK_INT(0LL))) {
        heff_drop(v_ts_240);
        return v_i_241;
      } else {
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_ts_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_False: {
      heff_drop_rec(v_t_242, 7);
      V t_0 = v_ts_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_ts_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
}
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2enextDecl(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str0, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str1, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str3, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str4, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str5, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
Clo g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_entry, 3, 0};

V g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  V v_it_243 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(heff_dup(v_ts_240), v_i_241));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Left: {
    V v_p_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Left = heff_take_reuse_n(v_it_243, 1ULL, 1);
    heff_drop(v_ts_240);
    heff_drop(v_acc_242);
    return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Left, 1, (V[]){v_p_244});
  }
  case TAG_Right: {
    V v_it1_245 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Right = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_it1_245, 0);
      V v_j_247 = heff_field(v_it1_245, 1);
      V v_ru_24it1_245_24MkPair = heff_take_reuse_n(v_it1_245, 3ULL, 2);
      V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_247));
      V v_t_2410;
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_248, 0)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str0))) {
        v_t_2410 = heff_strEq(heff_get_n(v_t_248, 1, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str1));
      } else {
        heff_drop_rec(v_t_248, 7);
        v_t_2410 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24it_243_24Right, 1);
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_j_247, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24it1_245_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_acc_242});
        v_ts_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      case TAG_False: {
        V v_t_2411 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_247));
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_2411, 0)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str2))) {
          if (heff_strEq_c(heff_get_n(v_t_2411, 1, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str3))) {
            heff_drop(v_ts_240);
            V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24it1_245_24MkPair, TAG_Cons, 2, (V[]){v_x_246, v_acc_242})));
            V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, heff_intAdd(v_j_247, MK_INT(1LL))});
            return heff_tag_at_n(v_ru_24it_243_24Right, TAG_Right, 1, (V[]){v_t_2415});
          } else {
            heff_drop(v_acc_242);
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            V v_t_2416 = heff_arrayIndex(v_ts_240, v_j_247);
            V v_t_2417 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2416, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str4)});
            return heff_tag_at_n(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2417});
          }
        } else {
          heff_drop(v_acc_242);
          heff_drop(v_x_246);
          heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
          heff_drop_rec(v_t_2411, 7);
          V v_t_2418 = heff_arrayIndex(v_ts_240, v_j_247);
          V v_t_2419 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2418, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_str5)});
          return heff_tag_at_n(v_ru_24it_243_24Right, TAG_Left, 1, (V[]){v_t_2419});
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str0, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str1, 23, "expected a field's name");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str2, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str3, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str4, 12, "expected `=`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str5, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str6, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str7, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str8, 1, "}");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str9, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str10, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
Clo g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_entry, 3, 0};

V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  V v_t_245;
  if (heff_strEq_c(heff_get_n(v_t_243, 0, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str0))) {
    v_t_245 = NTAG(TAG_False);
  } else {
    v_t_245 = NTAG(TAG_True);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_acc_242);
    V v_t_246 = heff_arrayIndex(v_ts_240, v_i_241);
    V v_t_247 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_246, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str1)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_247});
  }
  case TAG_False: {
    V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    V v_x1_2411;
    if (heff_strEq_c(heff_get_n(v_t_248, 0, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str2))) {
      V v_t_2410 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      v_x1_2411 = heff_strEq(heff_get_n(v_t_2410, 1, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str3));
    } else {
      v_x1_2411 = NTAG(TAG_False);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2411);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_acc_242);
      V v_t_2413 = heff_arrayIndex(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)));
      V v_t_2414 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str4)});
      return heff_tag_n(TAG_Left, 1, (V[]){v_t_2414});
    }
    case TAG_False: {
      V v_it_2415 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
      switch (heff_tag_of(v_it_2415)) {
      case TAG_Left: {
        V v_p_2416 = heff_field(v_it_2415, 0);
        V v_ru_24it_2415_24Left = heff_take_reuse_n(v_it_2415, 1ULL, 1);
        heff_drop(v_ts_240);
        heff_drop(v_i_241);
        heff_drop(v_acc_242);
        return heff_tag_at_n(v_ru_24it_2415_24Left, TAG_Left, 1, (V[]){v_p_2416});
      }
      case TAG_Right: {
        V v_it1_2417 = heff_field(v_it_2415, 0);
        V v_ru_24it_2415_24Right = heff_take_reuse_n(v_it_2415, 1ULL, 1);
        switch (heff_tag_of(v_it1_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_it1_2417, 0);
          V v_j_2419 = heff_field(v_it1_2417, 1);
          V v_ru_24it1_2417_24MkPair = heff_take_reuse_n(v_it1_2417, 3ULL, 2);
          V v_t_2420 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_2419));
          V v_t_2422;
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_2420, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str5))) {
            v_t_2422 = heff_strEq(heff_get_n(v_t_2420, 1, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str6));
          } else {
            heff_drop_rec(v_t_2420, 7);
            v_t_2422 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2422)) {
          case TAG_True: {
            heff_drop_cell(v_ru_24it_2415_24Right, 1);
            V v_t_2423 = heff_arrayIndex(heff_dup(v_ts_240), v_i_241);
            V v_t_2424 = heff_tag_at_n(v_ru_24it1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_t_2423, 1, 7), v_x_2418});
            V t_0 = v_ts_240;
            V t_1 = heff_intAdd(v_j_2419, MK_INT(1LL));
            V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_acc_242});
            v_ts_240 = t_0;
            v_i_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          }
          case TAG_False: {
            V v_t_2425 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_2419));
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2425, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str7))) {
              if (heff_strEq_c(heff_get_n(v_t_2425, 1, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str8))) {
                V v_t_2428 = heff_arrayIndex(v_ts_240, v_i_241);
                V v_t_2429 = heff_tag_at_n(v_ru_24it1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_t_2428, 1, 7), v_x_2418});
                V v_xs_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_acc_242});
                V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
                V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, heff_intAdd(v_j_2419, MK_INT(1LL))});
                return heff_tag_at_n(v_ru_24it_2415_24Right, TAG_Right, 1, (V[]){v_t_2432});
              } else {
                heff_drop(v_i_241);
                heff_drop(v_acc_242);
                heff_drop(v_x_2418);
                heff_drop_cell(v_ru_24it1_2417_24MkPair, 2);
                V v_t_2433 = heff_arrayIndex(v_ts_240, v_j_2419);
                V v_t_2434 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2433, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str9)});
                return heff_tag_at_n(v_ru_24it_2415_24Right, TAG_Left, 1, (V[]){v_t_2434});
              }
            } else {
              heff_drop(v_i_241);
              heff_drop(v_acc_242);
              heff_drop(v_x_2418);
              heff_drop_cell(v_ru_24it1_2417_24MkPair, 2);
              heff_drop_rec(v_t_2425, 7);
              V v_t_2435 = heff_arrayIndex(v_ts_240, v_j_2419);
              V v_t_2436 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2435, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str10)});
              return heff_tag_at_n(v_ru_24it_2415_24Right, TAG_Left, 1, (V[]){v_t_2436});
            }
          }
          default: return heff_nomatch(v_t_2422);
          }
        }
        default: return heff_nomatch(v_it1_2417);
        }
      }
      default: return heff_nomatch(v_it_2415);
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str0, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str1, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str3, 1, "[");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str4, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str5, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str6, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str7, 1, "{");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str8, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str9, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
Clo g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_entry, 2, 0};

V g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(V v_ts_240, V v_i_241) {
top: ;
  V v_t_242 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  if (heff_strEq_c(heff_get_n(v_t_242, 0, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str0))) {
    V v_t_244 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
    V v_t_245 = heff_arrayIndex(v_ts_240, heff_dup(v_i_241));
    V v_t_246 = heff_tag_n(TAG_LStr, 2, (V[]){heff_get_n(v_t_244, 1, 7), v_t_245});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_i_241, MK_INT(1LL))});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_247});
  } else {
    V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
    if (heff_strEq_c(heff_get_n(v_t_248, 0, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str1))) {
      V v_t_2410 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
      V v_t_2411 = heff_arrayIndex(v_ts_240, heff_dup(v_i_241));
      V v_t_2412 = heff_tag_n(TAG_LTag, 2, (V[]){heff_get_n(v_t_2410, 1, 7), v_t_2411});
      V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, heff_intAdd(v_i_241, MK_INT(1LL))});
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2413});
    } else {
      V v_t_2414 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
      V v_t_2416;
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_2414, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str2))) {
        v_t_2416 = heff_strEq(heff_get_n(v_t_2414, 1, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str3));
      } else {
        heff_drop_rec(v_t_2414, 7);
        v_t_2416 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        V v_t_2417 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_2417, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str4))) {
          if (heff_strEq_c(heff_get_n(v_t_2417, 1, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str5))) {
            V v_t_2420 = heff_arrayIndex(v_ts_240, heff_dup(v_i_241));
            V v_t_2421 = heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_2420});
            V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, heff_intAdd(v_i_241, MK_INT(2LL))});
            return heff_tag_n(TAG_Right, 1, (V[]){v_t_2422});
          } else {
            V v_t_2423 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
            V v_x2_2424 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
            switch (heff_tag_of(v_x2_2424)) {
            case TAG_Left: {
              V v_p_2425 = heff_field(v_x2_2424, 0);
              V v_ru_24x2_2424_24Left = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
              heff_drop(v_t_2423);
              return heff_tag_at_n(v_ru_24x2_2424_24Left, TAG_Left, 1, (V[]){v_p_2425});
            }
            case TAG_Right: {
              V v_x21_2426 = heff_field(v_x2_2424, 0);
              V v_ru_24x2_2424_24Right = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
              switch (heff_tag_of(v_x21_2426)) {
              case TAG_MkPair: {
                V v_xs_2427 = heff_field(v_x21_2426, 0);
                V v_j_2428 = heff_field(v_x21_2426, 1);
                V v_ru_24x21_2426_24MkPair = heff_take_reuse_n(v_x21_2426, 3ULL, 2);
                V v_t_2429 = heff_tag_at_n(v_ru_24x21_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LList, 2, (V[]){v_xs_2427, v_t_2423}), v_j_2428});
                return heff_tag_at_n(v_ru_24x2_2424_24Right, TAG_Right, 1, (V[]){v_t_2429});
              }
              default: return heff_nomatch(v_x21_2426);
              }
            }
            default: return heff_nomatch(v_x2_2424);
            }
          }
        } else {
          heff_drop_rec(v_t_2417, 7);
          V v_t_2430 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
          V v_x2_2431 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
          switch (heff_tag_of(v_x2_2431)) {
          case TAG_Left: {
            V v_p_2432 = heff_field(v_x2_2431, 0);
            V v_ru_24x2_2431_24Left = heff_take_reuse_n(v_x2_2431, 1ULL, 1);
            heff_drop(v_t_2430);
            return heff_tag_at_n(v_ru_24x2_2431_24Left, TAG_Left, 1, (V[]){v_p_2432});
          }
          case TAG_Right: {
            V v_x21_2433 = heff_field(v_x2_2431, 0);
            V v_ru_24x2_2431_24Right = heff_take_reuse_n(v_x2_2431, 1ULL, 1);
            switch (heff_tag_of(v_x21_2433)) {
            case TAG_MkPair: {
              V v_xs_2434 = heff_field(v_x21_2433, 0);
              V v_j_2435 = heff_field(v_x21_2433, 1);
              V v_ru_24x21_2433_24MkPair = heff_take_reuse_n(v_x21_2433, 3ULL, 2);
              V v_t_2436 = heff_tag_at_n(v_ru_24x21_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LList, 2, (V[]){v_xs_2434, v_t_2430}), v_j_2435});
              return heff_tag_at_n(v_ru_24x2_2431_24Right, TAG_Right, 1, (V[]){v_t_2436});
            }
            default: return heff_nomatch(v_x21_2433);
            }
          }
          default: return heff_nomatch(v_x2_2431);
          }
        }
      }
      case TAG_False: {
        V v_t_2437 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_2437, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str6))) {
          if (heff_strEq_c(heff_get_n(v_t_2437, 1, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str7))) {
            V v_t_2440 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
            V v_x2_2441 = (g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
            switch (heff_tag_of(v_x2_2441)) {
            case TAG_Left: {
              V v_p_2442 = heff_field(v_x2_2441, 0);
              V v_ru_24x2_2441_24Left = heff_take_reuse_n(v_x2_2441, 1ULL, 1);
              heff_drop(v_t_2440);
              return heff_tag_at_n(v_ru_24x2_2441_24Left, TAG_Left, 1, (V[]){v_p_2442});
            }
            case TAG_Right: {
              V v_x21_2443 = heff_field(v_x2_2441, 0);
              V v_ru_24x2_2441_24Right = heff_take_reuse_n(v_x2_2441, 1ULL, 1);
              switch (heff_tag_of(v_x21_2443)) {
              case TAG_MkPair: {
                V v_fs_2444 = heff_field(v_x21_2443, 0);
                V v_j_2445 = heff_field(v_x21_2443, 1);
                V v_ru_24x21_2443_24MkPair = heff_take_reuse_n(v_x21_2443, 3ULL, 2);
                V v_t_2446 = heff_tag_at_n(v_ru_24x21_2443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LRec, 2, (V[]){v_fs_2444, v_t_2440}), v_j_2445});
                return heff_tag_at_n(v_ru_24x2_2441_24Right, TAG_Right, 1, (V[]){v_t_2446});
              }
              default: return heff_nomatch(v_x21_2443);
              }
            }
            default: return heff_nomatch(v_x2_2441);
            }
          } else {
            V v_t_2447 = heff_arrayIndex(v_ts_240, v_i_241);
            V v_t_2448 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2447, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str8)});
            return heff_tag_n(TAG_Left, 1, (V[]){v_t_2448});
          }
        } else {
          heff_drop_rec(v_t_2437, 7);
          V v_t_2449 = heff_arrayIndex(v_ts_240, v_i_241);
          V v_t_2450 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2449, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_str9)});
          return heff_tag_n(TAG_Left, 1, (V[]){v_t_2450});
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
  }
}
V g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str0, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str1, 13, " defines no `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str3, 2, "kw");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str4, 6, "import");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str5, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str6, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str8, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str9, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str10, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str11, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str12, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str13, 38, "` is a literal, and nothing follows it");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str14, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str15, 38, "` is a literal, and nothing follows it");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str16, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str17, 27, "` is defined more than once");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str18, 21, " holds imports, and `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_str19, 50, "` (its signature and its definition), nothing else");
Clo g_heff_2ebuild_2eproject_2edeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2edeclsGo_entry, 5, 0};

V g_heff_2ebuild_2eproject_2edeclsGo(V v_file_240, V v_name_241, V v_ts_242, V v_i_243, V v_found_244) {
top: ;
  V v_t_245 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
  if (heff_strEq_c(heff_get_n(v_t_245, 0, 7), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str0))) {
    switch (heff_tag_of(v_found_244)) {
    case TAG_Nothing: {
      V v_t_247 = heff_arrayIndex(v_ts_242, v_i_243);
      V v_t_248 = heff_strAppend(v_file_240, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_str1), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str2))));
      V v_t_249 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_247, 2, 7), v_t_248});
      return heff_tag_n(TAG_Left, 1, (V[]){v_t_249});
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_found_244, 0);
      V v_ru_24found_244_24Just = heff_take_reuse_n(v_found_244, 1ULL, 1);
      heff_drop(v_file_240);
      heff_drop(v_name_241);
      heff_drop(v_ts_242);
      heff_drop(v_i_243);
      return heff_tag_at_n(v_ru_24found_244_24Just, TAG_Right, 1, (V[]){v_x_2410});
    }
    default: return heff_nomatch(v_found_244);
    }
  } else {
    V v_t_2411 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
    V v_t_2414;
    if (heff_strEq_c(heff_get_n(v_t_2411, 0, 7), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str3))) {
      V v_t_2413 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
      v_t_2414 = heff_strEq(heff_get_n(v_t_2413, 1, 7), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str4));
    } else {
      v_t_2414 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V v_t_2415 = (g_heff_2ebuild_2eproject_2enextDecl(heff_dup(v_ts_242), heff_intAdd(v_i_243, MK_INT(1LL))));
      V t_0 = v_file_240;
      V t_1 = v_name_241;
      V t_2 = v_ts_242;
      V t_3 = v_t_2415;
      V t_4 = v_found_244;
      v_file_240 = t_0;
      v_name_241 = t_1;
      v_ts_242 = t_2;
      v_i_243 = t_3;
      v_found_244 = t_4;
      goto top;
    }
    case TAG_False: {
      V v_t_2416 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
      V v_t_2422;
      if (heff_strEq_c(heff_get_n(v_t_2416, 0, 7), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str5))) {
        V v_t_2418 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
        if (heff_strEq_c(heff_get_n(v_t_2418, 1, 7), heff_dup(v_name_241))) {
          V v_t_2420 = heff_arrayIndex(heff_dup(v_ts_242), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_2420, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str6))) {
            v_t_2422 = heff_strEq(heff_get_n(v_t_2420, 1, 7), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str7));
          } else {
            heff_drop_rec(v_t_2420, 7);
            v_t_2422 = NTAG(TAG_False);
          }
        } else {
          v_t_2422 = NTAG(TAG_False);
        }
      } else {
        v_t_2422 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2422)) {
      case TAG_True: {
        V v_t_2423 = (g_heff_2ebuild_2eproject_2enextDecl(heff_dup(v_ts_242), heff_intAdd(v_i_243, MK_INT(1LL))));
        V t_0 = v_file_240;
        V t_1 = v_name_241;
        V t_2 = v_ts_242;
        V t_3 = v_t_2423;
        V t_4 = v_found_244;
        v_file_240 = t_0;
        v_name_241 = t_1;
        v_ts_242 = t_2;
        v_i_243 = t_3;
        v_found_244 = t_4;
        goto top;
      }
      case TAG_False: {
        V v_t_2424 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
        V v_t_2430;
        if (heff_strEq_c(heff_get_n(v_t_2424, 0, 7), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str8))) {
          V v_t_2426 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_i_243));
          if (heff_strEq_c(heff_get_n(v_t_2426, 1, 7), heff_dup(v_name_241))) {
            V v_t_2428 = heff_arrayIndex(heff_dup(v_ts_242), heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2428, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str9))) {
              v_t_2430 = heff_strEq(heff_get_n(v_t_2428, 1, 7), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str10));
            } else {
              heff_drop_rec(v_t_2428, 7);
              v_t_2430 = NTAG(TAG_False);
            }
          } else {
            v_t_2430 = NTAG(TAG_False);
          }
        } else {
          v_t_2430 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2430)) {
        case TAG_True: {
          switch (heff_tag_of(v_found_244)) {
          case TAG_Nothing: {
            V v_it_2431 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(heff_dup(v_ts_242), heff_intAdd(v_i_243, MK_INT(2LL))));
            switch (heff_tag_of(v_it_2431)) {
            case TAG_Left: {
              V v_p_2432 = heff_field(v_it_2431, 0);
              V v_ru_24it_2431_24Left = heff_take_reuse_n(v_it_2431, 1ULL, 1);
              heff_drop(v_file_240);
              heff_drop(v_name_241);
              heff_drop(v_ts_242);
              return heff_tag_at_n(v_ru_24it_2431_24Left, TAG_Left, 1, (V[]){v_p_2432});
            }
            case TAG_Right: {
              V v_it1_2433 = heff_field(v_it_2431, 0);
              V v_ru_24it_2431_24Right = heff_take_reuse_n(v_it_2431, 1ULL, 1);
              switch (heff_tag_of(v_it1_2433)) {
              case TAG_MkPair: {
                V v_x_2434 = heff_field(v_it1_2433, 0);
                V v_j_2435 = heff_field(v_it1_2433, 1);
                heff_take_n(v_it1_2433, 3ULL, 2);
                V v_t_2436 = heff_arrayIndex(heff_dup(v_ts_242), heff_dup(v_j_2435));
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_2436, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str11))) {
                  heff_drop_rec(v_t_2436, 7);
                  V t_0 = v_file_240;
                  V t_1 = v_name_241;
                  V t_2 = v_ts_242;
                  V t_3 = v_j_2435;
                  V t_4 = heff_tag_at_n(v_ru_24it_2431_24Right, TAG_Just, 1, (V[]){v_x_2434});
                  v_file_240 = t_0;
                  v_name_241 = t_1;
                  v_ts_242 = t_2;
                  v_i_243 = t_3;
                  v_found_244 = t_4;
                  goto top;
                } else {
                  V v_t_2438 = heff_take_field(v_t_2436, 6);
                  switch (heff_tag_of(v_t_2438)) {
                  case TAG_True: {
                    if (heff_intEq_c(heff_get_n(v_t_2436, 5, 7), MK_INT(0LL))) {
                      V t_0 = v_file_240;
                      V t_1 = v_name_241;
                      V t_2 = v_ts_242;
                      V t_3 = v_j_2435;
                      V t_4 = heff_tag_at_n(v_ru_24it_2431_24Right, TAG_Just, 1, (V[]){v_x_2434});
                      v_file_240 = t_0;
                      v_name_241 = t_1;
                      v_ts_242 = t_2;
                      v_i_243 = t_3;
                      v_found_244 = t_4;
                      goto top;
                    } else {
                      heff_drop(v_file_240);
                      heff_drop(v_x_2434);
                      V v_t_2440 = heff_arrayIndex(v_ts_242, v_j_2435);
                      V v_t_2441 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_str12), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str13)));
                      V v_t_2442 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2440, 2, 7), v_t_2441});
                      return heff_tag_at_n(v_ru_24it_2431_24Right, TAG_Left, 1, (V[]){v_t_2442});
                    }
                  }
                  case TAG_False: {
                    heff_drop(v_file_240);
                    heff_drop(v_x_2434);
                    heff_drop_rec(v_t_2436, 7);
                    V v_t_2443 = heff_arrayIndex(v_ts_242, v_j_2435);
                    V v_t_2444 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_str14), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str15)));
                    V v_t_2445 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2443, 2, 7), v_t_2444});
                    return heff_tag_at_n(v_ru_24it_2431_24Right, TAG_Left, 1, (V[]){v_t_2445});
                  }
                  default: return heff_nomatch(v_t_2438);
                  }
                }
              }
              default: return heff_nomatch(v_it1_2433);
              }
            }
            default: return heff_nomatch(v_it_2431);
            }
          }
          case TAG_Just: {
            V v_ru_24found_244_24Just = heff_take_reuse_n(v_found_244, 0ULL, 1);
            heff_drop(v_file_240);
            V v_t_2447 = heff_arrayIndex(v_ts_242, v_i_243);
            V v_t_2448 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_str16), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str17)));
            V v_t_2449 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2447, 2, 7), v_t_2448});
            return heff_tag_at_n(v_ru_24found_244_24Just, TAG_Left, 1, (V[]){v_t_2449});
          }
          default: return heff_nomatch(v_found_244);
          }
        }
        case TAG_False: {
          heff_drop(v_found_244);
          V v_t_2450 = heff_arrayIndex(v_ts_242, v_i_243);
          V v_t_2451 = heff_strAppend(v_file_240, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_str18), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_str19))));
          V v_t_2452 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2450, 2, 7), v_t_2451});
          return heff_tag_n(TAG_Left, 1, (V[]){v_t_2452});
        }
        default: return heff_nomatch(v_t_2430);
        }
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
}
V g_heff_2ebuild_2eproject_2edeclsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2edeclsGo(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ebuild_2eproject_2erangeFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erangeFrom_entry, 2, 0};

V g_heff_2ebuild_2eproject_2erangeFrom(V v_i_240, V v_n_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), heff_dup(v_i_240))) {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  } else {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_240), (g_heff_2ebuild_2eproject_2erangeFrom(heff_intAdd(v_i_240, MK_INT(1LL)), v_n_241))});
  }
}
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erangeFrom(a[0], a[1]);
}
V g_heff_2ebuild_2eproject_2eisNumber_lam0(V self, V *args);
Clo g_heff_2ebuild_2eproject_2eisNumber_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisNumber_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisNumber(V v_s_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength(heff_dup(v_s_240)))) {
    V v_t_242 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength(heff_dup(v_s_240))));
    V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eproject_2eisNumber_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), v_t_242));
    V v_t_245 = ({ V a_0 = MK_INT(48LL); V a_1 = MK_INT(57LL); V a_2 = v_t_244; V r_ = (g_list_2eall_24s107199714x217634386(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      if (heff_intEq_c(heff_strLength(heff_dup(v_s_240)), MK_INT(1LL))) {
        heff_drop(v_s_240);
        return NTAG(TAG_True);
      } else {
        if (heff_intEq_c(heff_strByteAt(v_s_240, MK_INT(0LL)), MK_INT(48LL))) {
          return NTAG(TAG_False);
        } else {
          return NTAG(TAG_True);
        }
      }
    }
    case TAG_False: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_245);
    }
  } else {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eisNumber(a[0]);
}
V g_heff_2ebuild_2eproject_2eisNumber_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strByteAt(v_s_240, v_i_243);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_str0, 1, ".");
Clo g_heff_2ebuild_2eproject_2eversion_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eversion_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eversion(V v_v_240) {
top: ;
  V v_it_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2eversion_str0), v_v_240, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    V v_ru_24it_241_24Cons = heff_take_reuse_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24it_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      V v_ru_24it2_243_24Cons = heff_take_reuse_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24it_241_24Cons, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24it2_243_24Cons, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_c_246 = heff_field(v_it22_245, 0);
        V v_it222_247 = heff_field(v_it22_245, 1);
        heff_take_n(v_it22_245, 3ULL, 2);
        switch (heff_tag_of(v_it222_247)) {
        case TAG_Nil: {
          V v_t_248 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_a_242)));
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            V v_t_249 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_b_244)));
            switch (heff_tag_of(v_t_249)) {
            case TAG_True: {
              V v_t_2410 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_c_246)));
              switch (heff_tag_of(v_t_2410)) {
              case TAG_True: {
                V v_t_2411 = heff_tag_at_n(v_ru_24it_241_24Cons, TAG_Cons, 2, (V[]){v_c_246, NTAG(TAG_Nil)});
                V v_t_2412 = heff_tag_at_n(v_ru_24it2_243_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, v_t_2411})});
                return heff_tag_n(TAG_Just, 1, (V[]){(g_list_2emap_24s546447922x1671206170(MK_INT(0LL), v_t_2412))});
              }
              case TAG_False: {
                heff_drop(v_a_242);
                heff_drop_cell(v_ru_24it_241_24Cons, 2);
                heff_drop(v_b_244);
                heff_drop_cell(v_ru_24it2_243_24Cons, 2);
                heff_drop(v_c_246);
                return NTAG(TAG_Nothing);
              }
              default: return heff_nomatch(v_t_2410);
              }
            }
            case TAG_False: {
              heff_drop(v_a_242);
              heff_drop_cell(v_ru_24it_241_24Cons, 2);
              heff_drop(v_b_244);
              heff_drop_cell(v_ru_24it2_243_24Cons, 2);
              heff_drop(v_c_246);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_249);
            }
          }
          case TAG_False: {
            heff_drop(v_a_242);
            heff_drop_cell(v_ru_24it_241_24Cons, 2);
            heff_drop(v_b_244);
            heff_drop_cell(v_ru_24it2_243_24Cons, 2);
            heff_drop(v_c_246);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_248);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_247, 0ULL, 2);
          heff_drop(v_a_242);
          heff_drop_cell(v_ru_24it_241_24Cons, 2);
          heff_drop(v_b_244);
          heff_drop_cell(v_ru_24it2_243_24Cons, 2);
          heff_drop(v_c_246);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it222_247);
        }
      }
      default: return heff_nomatch(v_it22_245);
      }
    }
    default: return heff_nomatch(v_it2_243);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eversion(a[0]);
}
Clo g_heff_2ebuild_2eproject_2ecompatible_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ecompatible_entry, 2, 0};

V g_heff_2ebuild_2eproject_2ecompatible(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_wa_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_wb_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_wc_246 = heff_field(v_x122_245, 0);
        V v_x1222_247 = heff_field(v_x122_245, 1);
        switch (heff_tag_of(v_x1222_247)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x2_241)) {
          case TAG_Nil: {
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_ra_248 = heff_field(v_x2_241, 0);
            V v_x22_249 = heff_field(v_x2_241, 1);
            switch (heff_tag_of(v_x22_249)) {
            case TAG_Nil: {
              return NTAG(TAG_False);
            }
            case TAG_Cons: {
              V v_rb_2410 = heff_field(v_x22_249, 0);
              V v_x222_2411 = heff_field(v_x22_249, 1);
              switch (heff_tag_of(v_x222_2411)) {
              case TAG_Nil: {
                return NTAG(TAG_False);
              }
              case TAG_Cons: {
                V v_rc_2412 = heff_field(v_x222_2411, 0);
                V v_x2222_2413 = heff_field(v_x222_2411, 1);
                switch (heff_tag_of(v_x2222_2413)) {
                case TAG_Nil: {
                  if (heff_intEq_c(heff_dup(v_wa_242), MK_INT(0LL))) {
                    if (heff_intEq_c(heff_dup(v_ra_248), MK_INT(0LL))) {
                      if (heff_intEq_c(heff_dup(v_rb_2410), heff_dup(v_wb_244))) {
                        return heff_intLe(heff_dup(v_wc_246), heff_dup(v_rc_2412));
                      } else {
                        return NTAG(TAG_False);
                      }
                    } else {
                      return NTAG(TAG_False);
                    }
                  } else {
                    if (heff_intEq_c(heff_dup(v_ra_248), heff_dup(v_wa_242))) {
                      if (heff_intLt_c(heff_dup(v_wb_244), heff_dup(v_rb_2410))) {
                        return NTAG(TAG_True);
                      } else {
                        if (heff_intEq_c(heff_dup(v_rb_2410), heff_dup(v_wb_244))) {
                          return heff_intLe(heff_dup(v_wc_246), heff_dup(v_rc_2412));
                        } else {
                          return NTAG(TAG_False);
                        }
                      }
                    } else {
                      return NTAG(TAG_False);
                    }
                  }
                }
                case TAG_Cons: {
                  return NTAG(TAG_False);
                }
                default: return heff_nomatch(v_x2222_2413);
                }
              }
              default: return heff_nomatch(v_x222_2411);
              }
            }
            default: return heff_nomatch(v_x22_249);
            }
          }
          default: return heff_nomatch(v_x2_241);
          }
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x1222_247);
        }
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2ecompatible(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ebuild_2eproject_2eisName_lam0(V self, V *args);
Clo g_heff_2ebuild_2eproject_2eisName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisName_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisName(V v_x_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength(heff_dup(v_x_240)))) {
    if (heff_intLe_c(MK_INT(97LL), heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)))) {
      if (heff_intLe_c(heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(122LL))) {
        V v_t_244 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength(heff_dup(v_x_240))));
        V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eproject_2eisName_lam0, 1, 1, (V[]){v_x_240}), v_t_244));
        return ({ V a_0 = MK_INT(97LL); V a_1 = MK_INT(122LL); V a_2 = MK_INT(65LL); V a_3 = MK_INT(90LL); V a_4 = MK_INT(48LL); V a_5 = MK_INT(57LL); V a_6 = MK_INT(95LL); V a_7 = MK_INT(95LL); V a_8 = MK_INT(48LL); V a_9 = MK_INT(57LL); V a_10 = MK_INT(95LL); V a_11 = MK_INT(95LL); V a_12 = v_t_246; V r_ = (g_list_2eall_24s1821787051x863686734(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_t_246); r_; });
      } else {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eisName(a[0]);
}
V g_heff_2ebuild_2eproject_2eisName_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strByteAt(v_x_240, v_i_245);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eproject_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_str2), (g_heff_2ebuild_2eproject_2eandList(v_x12_242))));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2eandList(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_f_241, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_241, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_241, 0, 2), (g_heff_2ebuild_2eproject_2eleftOutNames(v_rest_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str3, 2, " (");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str4, 17, " may be left out)");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str5, 15, "the fields are ");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str6, 15, ", in this order");
Clo g_heff_2ebuild_2eproject_2efieldsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2efieldsSaid_entry, 1, 0};

V g_heff_2ebuild_2eproject_2efieldsSaid(V v_fields_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s1626183354x549349049(heff_dup(v_fields_240)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x1_245 = (g_heff_2ebuild_2eproject_2eleftOutNames(heff_dup(v_fields_240)));
  V v_t_2410;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    heff_drop(v_fields_240);
    v_t_2410 = ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str2);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    V v_t_248 = (g_heff_2ebuild_2eproject_2eleftOutNames(v_fields_240));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2ebuild_2eproject_2eandList(a_0)); heff_drop(v_t_248); r_; });
    v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str3), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str4)));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  return heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str5), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str6), v_t_2410)));
}
V g_heff_2ebuild_2eproject_2efieldsSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2efieldsSaid(a[0]);
}
Clo g_heff_2ebuild_2eproject_2efieldsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2efieldsIn_entry, 3, 0};

V g_heff_2ebuild_2eproject_2efieldsIn(V v_t_240, V v_x2_241, V v_written_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    switch (heff_tag_of(v_written_242)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_written_242, 0ULL, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_written_242);
    }
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_it_2412;
    switch (heff_tag_of(v_written_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_it_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x21_247 = heff_dup(heff_field(v_written_242, 0));
      V v_more_248 = heff_dup(heff_field(v_written_242, 1));
      switch (heff_tag_of(v_x21_247)) {
      case TAG_MkPair: {
        V v_y_249 = heff_field(v_x21_247, 0);
        V v_v_2410 = heff_field(v_x21_247, 1);
        heff_take_n(v_x21_247, 3ULL, 2);
        if (heff_strEq_c(heff_dup(heff_rfield(v_f_245, 0)), v_y_249)) {
          v_it_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_v_2410, v_more_248})});
        } else {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_more_248);
          heff_drop(v_v_2410);
          v_it_2412 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_written_242);
    }
    switch (heff_tag_of(v_it_2412)) {
    case TAG_Nothing: {
      V v_t_2413 = heff_get_n(v_f_245, 1, 2);
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop(v_t_240);
        heff_drop(v_written_242);
        heff_drop(v_rest_246);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_mk_2414 = heff_field(v_t_2413, 0);
        V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
        V v_v_2415 = heff_tr(heff_apply(v_mk_2414, 1, (V[]){heff_dup(v_t_240)}));
        V v_x2_2416 = (g_heff_2ebuild_2eproject_2efieldsIn(v_t_240, v_rest_246, v_written_242));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24t_2413_24Just, 1);
          heff_drop(v_v_2415);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_vs_2417 = heff_field(v_x2_2416, 0);
          heff_take_n(v_x2_2416, 1ULL, 1);
          return heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_2415, v_vs_2417})});
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_Just: {
      V v_it1_2418 = heff_field(v_it_2412, 0);
      V v_ru_24it_2412_24Just = heff_take_reuse_n(v_it_2412, 1ULL, 1);
      heff_drop(v_written_242);
      heff_drop_rec(v_f_245, 2);
      switch (heff_tag_of(v_it1_2418)) {
      case TAG_MkPair: {
        V v_v_2419 = heff_field(v_it1_2418, 0);
        V v_more_2420 = heff_field(v_it1_2418, 1);
        heff_take_n(v_it1_2418, 3ULL, 2);
        V v_x2_2421 = (g_heff_2ebuild_2eproject_2efieldsIn(v_t_240, v_rest_246, v_more_2420));
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24it_2412_24Just, 1);
          heff_drop(v_v_2419);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_vs_2422 = heff_field(v_x2_2421, 0);
          heff_take_n(v_x2_2421, 1ULL, 1);
          return heff_tag_at_n(v_ru_24it_2412_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_2419, v_vs_2422})});
        }
        default: return heff_nomatch(v_x2_2421);
        }
      }
      default: return heff_nomatch(v_it1_2418);
      }
    }
    default: return heff_nomatch(v_it_2412);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eproject_2efieldsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2efieldsIn(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_str2, 25, "expected a record `{...}`");
Clo g_heff_2ebuild_2eproject_2efieldsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2efieldsAre_entry, 2, 0};

V g_heff_2ebuild_2eproject_2efieldsAre(V v_fields_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x_241)) {
  case TAG_LStr: {
    heff_drop(v_fields_240);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_245 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_245);
      break;
    }
    case TAG_LTag: {
      V v_t_247 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_247);
      break;
    }
    case TAG_LList: {
      V v_t_249 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_249);
      break;
    }
    case TAG_LRec: {
      V v_t_2411 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_2411);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2413 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_str0)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2413});
  }
  case TAG_LTag: {
    heff_drop(v_fields_240);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2417 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2417);
      break;
    }
    case TAG_LTag: {
      V v_t_2419 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2419);
      break;
    }
    case TAG_LList: {
      V v_t_2421 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2421);
      break;
    }
    case TAG_LRec: {
      V v_t_2423 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2423);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_str1)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2425});
  }
  case TAG_LList: {
    heff_drop(v_fields_240);
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2429 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2429);
      break;
    }
    case TAG_LTag: {
      V v_t_2431 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2431);
      break;
    }
    case TAG_LList: {
      V v_t_2433 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2433);
      break;
    }
    case TAG_LRec: {
      V v_t_2435 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2435);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2437 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_str2)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2437});
  }
  case TAG_LRec: {
    V v_fs_2438 = heff_field(v_x_241, 0);
    V v_t_2439 = heff_field(v_x_241, 1);
    V v_t_2440 = (g_heff_2ebuild_2eproject_2efieldsIn(heff_dup(v_t_2439), heff_dup(v_fields_240), heff_dup(v_fs_2438)));
    switch (heff_tag_of(v_t_2440)) {
    case TAG_Nothing: {
      V v_msg_2441 = (g_heff_2ebuild_2eproject_2efieldsSaid(v_fields_240));
      V v_t_2442 = heff_rec_n(2, shape_at__msg, (V[]){heff_dup(heff_rfield(v_t_2439, 2)), v_msg_2441});
      return heff_tag_n(TAG_Left, 1, (V[]){v_t_2442});
    }
    case TAG_Just: {
      V v_xs_2443 = heff_field(v_t_2440, 0);
      V v_ru_24t_2440_24Just = heff_take_reuse_n(v_t_2440, 1ULL, 1);
      heff_drop(v_fields_240);
      return heff_tag_at_n(v_ru_24t_2440_24Just, TAG_Right, 1, (V[]){v_xs_2443});
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  default: return heff_nomatch(v_x_241);
  }
}
V g_heff_2ebuild_2eproject_2efieldsAre_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2efieldsAre(a[0], a[1]); heff_drop(a[1]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_str0, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_str1, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_str2, 17, "expected a string");
Clo g_heff_2ebuild_2eproject_2estr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2estr_entry, 1, 0};

V g_heff_2ebuild_2eproject_2estr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_s_241 = heff_field(v_x_240, 0);
    return heff_tag_n(TAG_Right, 1, (V[]){heff_dup(v_s_241)});
  }
  case TAG_LTag: {
    V v_t_2413;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_246);
      break;
    }
    case TAG_LTag: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_248);
      break;
    }
    case TAG_LList: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2410);
      break;
    }
    case TAG_LRec: {
      V v_t_2412 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2412);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2414 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_str0)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2414});
  }
  case TAG_LList: {
    V v_t_2425;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LTag: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LList: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2422);
      break;
    }
    case TAG_LRec: {
      V v_t_2424 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2424);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2426 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2425, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_str1)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2426});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_str2)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2438});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2ebuild_2eproject_2estr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2estr(a[0]); heff_drop(a[0]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_str0, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_str1, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_str2, 23, "expected a list `[...]`");
Clo g_heff_2ebuild_2eproject_2eitems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eitems_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eitems(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_244);
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_246);
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_248);
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_2410);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_str0)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2412});
  }
  case TAG_LTag: {
    V v_t_2423;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2416 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2416);
      break;
    }
    case TAG_LTag: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LList: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LRec: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2422);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_str1)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2424});
  }
  case TAG_LList: {
    V v_xs_2425 = heff_field(v_x_240, 0);
    return heff_tag_n(TAG_Right, 1, (V[]){heff_dup(v_xs_2425)});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_str2)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2438});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2ebuild_2eproject_2eitems_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2eitems(a[0]); heff_drop(a[0]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eversionOf_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eversionOf_str1, 45, "` is no version: write `a.b.c`, three numbers");
Clo g_heff_2ebuild_2eproject_2eversionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eversionOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eversionOf(V v_x_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2eproject_2estr(v_x_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Left: {
    V v_p_242 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Left = heff_take_reuse_n(v_t_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24t_241_24Left, TAG_Left, 1, (V[]){v_p_242});
  }
  case TAG_Right: {
    V v_v_243 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Right = heff_take_reuse_n(v_t_241, 1ULL, 1);
    V v_t_244 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_v_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_2413;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_246 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_246);
        break;
      }
      case TAG_LTag: {
        V v_t_248 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_248);
        break;
      }
      case TAG_LList: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LRec: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2412);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eversionOf_str0), heff_strAppend(v_v_243, ((V)&g_heff_2ebuild_2eproject_2eversionOf_str1)));
      V v_t_2415 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), v_t_2414});
      return heff_tag_at_n(v_ru_24t_241_24Right, TAG_Left, 1, (V[]){v_t_2415});
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      return heff_tag_at_n(v_ru_24t_241_24Right, TAG_Right, 1, (V[]){v_v_243});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ebuild_2eproject_2eversionOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2eversionOf(a[0]); heff_drop(a[0]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2enameOf_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2enameOf_str1, 83, "` cannot be imported by: a name is a lowercase letter, then letters, digits and `_`");
Clo g_heff_2ebuild_2eproject_2enameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enameOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2enameOf(V v_x_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2eproject_2estr(v_x_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Left: {
    V v_p_242 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Left = heff_take_reuse_n(v_t_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24t_241_24Left, TAG_Left, 1, (V[]){v_p_242});
  }
  case TAG_Right: {
    V v_n_243 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Right = heff_take_reuse_n(v_t_241, 1ULL, 1);
    V v_t_244 = (g_heff_2ebuild_2eproject_2eisName(heff_dup(v_n_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24t_241_24Right, TAG_Right, 1, (V[]){v_n_243});
    }
    case TAG_False: {
      V v_t_2413;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_246 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_246);
        break;
      }
      case TAG_LTag: {
        V v_t_248 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_248);
        break;
      }
      case TAG_LList: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LRec: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2413 = heff_dup(v_t_2412);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2enameOf_str0), heff_strAppend(v_n_243, ((V)&g_heff_2ebuild_2eproject_2enameOf_str1)));
      V v_t_2415 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), v_t_2414});
      return heff_tag_at_n(v_ru_24t_241_24Right, TAG_Left, 1, (V[]){v_t_2415});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ebuild_2eproject_2enameOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2enameOf(a[0]); heff_drop(a[0]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str2, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str3, 8, "version ");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str4, 44, " is fetched from a path without a /vN ending");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str6, 8, "version ");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str7, 35, " is fetched from a path ending in /");
Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2emajorMismatch_entry, 2, 0};

V g_heff_2ebuild_2eproject_2emajorMismatch(V v_path_240, V v_v_241) {
top: ;
  V v_x2_242 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_v_241)));
  V v_x1_244;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    v_x1_244 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    v_x1_244 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    v_x2_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    v_x2_247 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_n_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_n_249 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_n_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2412;
  if (heff_intLe_c(MK_INT(2LL), heff_dup(v_n_249))) {
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str0), heff_intShow(v_n_249));
    v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  } else {
    heff_drop(v_n_249);
    v_t_2412 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_xs_2413 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str1), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
    V v_x_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_x_2417 = v_path_240;
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 2);
      heff_drop(v_path_240);
      v_x_2417 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_x_2417)))) {
      if (heff_strEq_c(heff_strSlice(heff_dup(v_x_2417), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str2))) {
        V v_t_2420 = heff_strSlice(heff_dup(v_x_2417), MK_INT(1LL), heff_strLength(v_x_2417));
        V v_t_2421 = (g_heff_2ebuild_2eproject_2eisNumber(v_t_2420));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str3), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str4)));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
        }
        case TAG_False: {
          heff_drop(v_v_241);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2421);
        }
      } else {
        heff_drop(v_v_241);
        heff_drop(v_x_2417);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_v_241);
      heff_drop(v_x_2417);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_Just: {
    V v_suffix_2423 = heff_field(v_t_2412, 0);
    V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 1ULL, 1);
    V v_xs_2424 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str5), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    V v_t_2428;
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nil: {
      v_t_2428 = v_path_240;
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 2);
      heff_drop(v_path_240);
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
    if (heff_strEq_c(v_t_2428, heff_dup(v_suffix_2423))) {
      heff_drop(v_v_241);
      heff_drop(v_suffix_2423);
      heff_drop_cell(v_ru_24t_2412_24Just, 1);
      return NTAG(TAG_Nothing);
    } else {
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str6), heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str7), v_suffix_2423)));
      return heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Just, 1, (V[]){v_t_2430});
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2emajorMismatch(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_str1, 4, "path");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_str2, 7, "version");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_str6, 25, "expected a record `{...}`");
Clo g_heff_2ebuild_2eproject_2erequireOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erequireOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2erequireOf(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_str2), NTAG(TAG_Nothing)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244})});
  V v_it_246 = (g_heff_2ebuild_2eproject_2efieldsAre(v_t_245, v_x_240));
  switch (heff_tag_of(v_it_246)) {
  case TAG_Left: {
    V v_p_247 = heff_field(v_it_246, 0);
    V v_ru_24it_246_24Left = heff_take_reuse_n(v_it_246, 1ULL, 1);
    return heff_tag_at_n(v_ru_24it_246_24Left, TAG_Left, 1, (V[]){v_p_247});
  }
  case TAG_Right: {
    V v_it1_248 = heff_field(v_it_246, 0);
    V v_ru_24it_246_24Right = heff_take_reuse_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_Nil: {
      V v_t_2417;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2417 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LTag: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2417 = heff_dup(v_t_2412);
        break;
      }
      case TAG_LList: {
        V v_t_2414 = heff_field(v_x_240, 1);
        v_t_2417 = heff_dup(v_t_2414);
        break;
      }
      case TAG_LRec: {
        V v_t_2416 = heff_field(v_x_240, 1);
        v_t_2417 = heff_dup(v_t_2416);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2418 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2417, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_str3)});
      return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_t_2418});
    }
    case TAG_Cons: {
      V v_n_2419 = heff_field(v_it1_248, 0);
      V v_it12_2420 = heff_field(v_it1_248, 1);
      heff_take_n(v_it1_248, 3ULL, 2);
      switch (heff_tag_of(v_it12_2420)) {
      case TAG_Nil: {
        heff_drop(v_n_2419);
        V v_t_2429;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2422 = heff_field(v_x_240, 1);
          v_t_2429 = heff_dup(v_t_2422);
          break;
        }
        case TAG_LTag: {
          V v_t_2424 = heff_field(v_x_240, 1);
          v_t_2429 = heff_dup(v_t_2424);
          break;
        }
        case TAG_LList: {
          V v_t_2426 = heff_field(v_x_240, 1);
          v_t_2429 = heff_dup(v_t_2426);
          break;
        }
        case TAG_LRec: {
          V v_t_2428 = heff_field(v_x_240, 1);
          v_t_2429 = heff_dup(v_t_2428);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2430 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2429, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_str4)});
        return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_t_2430});
      }
      case TAG_Cons: {
        V v_p_2431 = heff_field(v_it12_2420, 0);
        V v_it122_2432 = heff_field(v_it12_2420, 1);
        heff_take_n(v_it12_2420, 3ULL, 2);
        switch (heff_tag_of(v_it122_2432)) {
        case TAG_Nil: {
          heff_drop(v_n_2419);
          heff_drop(v_p_2431);
          V v_t_2441;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2434 = heff_field(v_x_240, 1);
            v_t_2441 = heff_dup(v_t_2434);
            break;
          }
          case TAG_LTag: {
            V v_t_2436 = heff_field(v_x_240, 1);
            v_t_2441 = heff_dup(v_t_2436);
            break;
          }
          case TAG_LList: {
            V v_t_2438 = heff_field(v_x_240, 1);
            v_t_2441 = heff_dup(v_t_2438);
            break;
          }
          case TAG_LRec: {
            V v_t_2440 = heff_field(v_x_240, 1);
            v_t_2441 = heff_dup(v_t_2440);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2442 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2441, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_str5)});
          return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_t_2442});
        }
        case TAG_Cons: {
          V v_v_2443 = heff_field(v_it122_2432, 0);
          V v_it1222_2444 = heff_field(v_it122_2432, 1);
          heff_take_n(v_it122_2432, 3ULL, 2);
          switch (heff_tag_of(v_it1222_2444)) {
          case TAG_Nil: {
            V v_t_2445 = ({ V a_0 = v_n_2419; V r_ = (g_heff_2ebuild_2eproject_2enameOf(a_0)); heff_drop(v_n_2419); r_; });
            switch (heff_tag_of(v_t_2445)) {
            case TAG_Left: {
              V v_e_2446 = heff_field(v_t_2445, 0);
              heff_take_n(v_t_2445, 1ULL, 1);
              heff_drop(v_p_2431);
              heff_drop(v_v_2443);
              return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_e_2446});
            }
            case TAG_Right: {
              V v_name_2447 = heff_field(v_t_2445, 0);
              heff_take_n(v_t_2445, 1ULL, 1);
              V v_t_2448 = ({ V a_0 = v_v_2443; V r_ = (g_heff_2ebuild_2eproject_2eversionOf(a_0)); heff_drop(v_v_2443); r_; });
              switch (heff_tag_of(v_t_2448)) {
              case TAG_Left: {
                V v_e_2449 = heff_field(v_t_2448, 0);
                heff_take_n(v_t_2448, 1ULL, 1);
                heff_drop(v_p_2431);
                heff_drop(v_name_2447);
                return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_e_2449});
              }
              case TAG_Right: {
                V v_ver_2450 = heff_field(v_t_2448, 0);
                heff_take_n(v_t_2448, 1ULL, 1);
                V v_t_2451 = (g_heff_2ebuild_2eproject_2estr(v_p_2431));
                switch (heff_tag_of(v_t_2451)) {
                case TAG_Left: {
                  V v_p_2452 = heff_field(v_t_2451, 0);
                  heff_take_n(v_t_2451, 1ULL, 1);
                  heff_drop(v_p_2431);
                  heff_drop(v_name_2447);
                  heff_drop(v_ver_2450);
                  return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_p_2452});
                }
                case TAG_Right: {
                  V v_path_2453 = heff_field(v_t_2451, 0);
                  heff_take_n(v_t_2451, 1ULL, 1);
                  V v_t_2454 = (g_heff_2ebuild_2eproject_2emajorMismatch(heff_dup(v_path_2453), heff_dup(v_ver_2450)));
                  switch (heff_tag_of(v_t_2454)) {
                  case TAG_Nothing: {
                    heff_drop(v_p_2431);
                    return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Right, 1, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_2447, v_path_2453, v_ver_2450})});
                  }
                  case TAG_Just: {
                    V v_why_2455 = heff_field(v_t_2454, 0);
                    heff_take_n(v_t_2454, 1ULL, 1);
                    heff_drop(v_name_2447);
                    heff_drop(v_ver_2450);
                    heff_drop(v_path_2453);
                    V v_t_2464;
                    switch (heff_tag_of(v_p_2431)) {
                    case TAG_LStr: {
                      V v_t_2457 = heff_field(v_p_2431, 1);
                      heff_take_n(v_p_2431, 2ULL, 2);
                      v_t_2464 = v_t_2457;
                      break;
                    }
                    case TAG_LTag: {
                      V v_t_2459 = heff_field(v_p_2431, 1);
                      heff_take_n(v_p_2431, 2ULL, 2);
                      v_t_2464 = v_t_2459;
                      break;
                    }
                    case TAG_LList: {
                      V v_t_2461 = heff_field(v_p_2431, 1);
                      heff_take_n(v_p_2431, 2ULL, 2);
                      v_t_2464 = v_t_2461;
                      break;
                    }
                    case TAG_LRec: {
                      V v_t_2463 = heff_field(v_p_2431, 1);
                      heff_take_n(v_p_2431, 2ULL, 2);
                      v_t_2464 = v_t_2463;
                      break;
                    }
                    default: heff_nomatch(v_p_2431);
                    }
                    V v_e_2465 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2464, 2, 7), v_why_2455});
                    return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_e_2465});
                  }
                  default: return heff_nomatch(v_t_2454);
                  }
                }
                default: return heff_nomatch(v_t_2451);
                }
              }
              default: return heff_nomatch(v_t_2448);
              }
            }
            default: return heff_nomatch(v_t_2445);
            }
          }
          case TAG_Cons: {
            heff_take_n(v_it1222_2444, 0ULL, 2);
            heff_drop(v_n_2419);
            heff_drop(v_p_2431);
            heff_drop(v_v_2443);
            V v_t_2476;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2469 = heff_field(v_x_240, 1);
              v_t_2476 = heff_dup(v_t_2469);
              break;
            }
            case TAG_LTag: {
              V v_t_2471 = heff_field(v_x_240, 1);
              v_t_2476 = heff_dup(v_t_2471);
              break;
            }
            case TAG_LList: {
              V v_t_2473 = heff_field(v_x_240, 1);
              v_t_2476 = heff_dup(v_t_2473);
              break;
            }
            case TAG_LRec: {
              V v_t_2475 = heff_field(v_x_240, 1);
              v_t_2476 = heff_dup(v_t_2475);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_t_2477 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2476, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_str6)});
            return heff_tag_at_n(v_ru_24it_246_24Right, TAG_Left, 1, (V[]){v_t_2477});
          }
          default: return heff_nomatch(v_it1222_2444);
          }
        }
        default: return heff_nomatch(v_it122_2432);
        }
      }
      default: return heff_nomatch(v_it12_2420);
      }
    }
    default: return heff_nomatch(v_it1_248);
    }
  }
  default: return heff_nomatch(v_it_246);
  }
}
V g_heff_2ebuild_2eproject_2erequireOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2erequireOf(a[0]); heff_drop(a[0]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_str1, 3, "dir");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_str4, 25, "expected a record `{...}`");
Clo g_heff_2ebuild_2eproject_2ereplaceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ereplaceOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2ereplaceOf(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_it_244 = (g_heff_2ebuild_2eproject_2efieldsAre(heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_243}), v_x_240));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Left: {
    V v_p_245 = heff_field(v_it_244, 0);
    V v_ru_24it_244_24Left = heff_take_reuse_n(v_it_244, 1ULL, 1);
    return heff_tag_at_n(v_ru_24it_244_24Left, TAG_Left, 1, (V[]){v_p_245});
  }
  case TAG_Right: {
    V v_it1_246 = heff_field(v_it_244, 0);
    V v_ru_24it_244_24Right = heff_take_reuse_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_Nil: {
      V v_t_2415;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_248 = heff_field(v_x_240, 1);
        v_t_2415 = heff_dup(v_t_248);
        break;
      }
      case TAG_LTag: {
        V v_t_2410 = heff_field(v_x_240, 1);
        v_t_2415 = heff_dup(v_t_2410);
        break;
      }
      case TAG_LList: {
        V v_t_2412 = heff_field(v_x_240, 1);
        v_t_2415 = heff_dup(v_t_2412);
        break;
      }
      case TAG_LRec: {
        V v_t_2414 = heff_field(v_x_240, 1);
        v_t_2415 = heff_dup(v_t_2414);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2416 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2415, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_str2)});
      return heff_tag_at_n(v_ru_24it_244_24Right, TAG_Left, 1, (V[]){v_t_2416});
    }
    case TAG_Cons: {
      V v_n_2417 = heff_field(v_it1_246, 0);
      V v_it12_2418 = heff_field(v_it1_246, 1);
      heff_take_n(v_it1_246, 3ULL, 2);
      switch (heff_tag_of(v_it12_2418)) {
      case TAG_Nil: {
        heff_drop(v_n_2417);
        V v_t_2427;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2420 = heff_field(v_x_240, 1);
          v_t_2427 = heff_dup(v_t_2420);
          break;
        }
        case TAG_LTag: {
          V v_t_2422 = heff_field(v_x_240, 1);
          v_t_2427 = heff_dup(v_t_2422);
          break;
        }
        case TAG_LList: {
          V v_t_2424 = heff_field(v_x_240, 1);
          v_t_2427 = heff_dup(v_t_2424);
          break;
        }
        case TAG_LRec: {
          V v_t_2426 = heff_field(v_x_240, 1);
          v_t_2427 = heff_dup(v_t_2426);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2428 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2427, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_str3)});
        return heff_tag_at_n(v_ru_24it_244_24Right, TAG_Left, 1, (V[]){v_t_2428});
      }
      case TAG_Cons: {
        V v_d_2429 = heff_field(v_it12_2418, 0);
        V v_it122_2430 = heff_field(v_it12_2418, 1);
        heff_take_n(v_it12_2418, 3ULL, 2);
        switch (heff_tag_of(v_it122_2430)) {
        case TAG_Nil: {
          V v_t_2431 = ({ V a_0 = v_n_2417; V r_ = (g_heff_2ebuild_2eproject_2enameOf(a_0)); heff_drop(v_n_2417); r_; });
          switch (heff_tag_of(v_t_2431)) {
          case TAG_Left: {
            V v_e_2432 = heff_field(v_t_2431, 0);
            heff_take_n(v_t_2431, 1ULL, 1);
            heff_drop(v_d_2429);
            return heff_tag_at_n(v_ru_24it_244_24Right, TAG_Left, 1, (V[]){v_e_2432});
          }
          case TAG_Right: {
            V v_name_2433 = heff_field(v_t_2431, 0);
            heff_take_n(v_t_2431, 1ULL, 1);
            V v_t_2434 = ({ V a_0 = v_d_2429; V r_ = (g_heff_2ebuild_2eproject_2estr(a_0)); heff_drop(v_d_2429); r_; });
            switch (heff_tag_of(v_t_2434)) {
            case TAG_Left: {
              V v_e_2435 = heff_field(v_t_2434, 0);
              heff_take_n(v_t_2434, 1ULL, 1);
              heff_drop(v_name_2433);
              return heff_tag_at_n(v_ru_24it_244_24Right, TAG_Left, 1, (V[]){v_e_2435});
            }
            case TAG_Right: {
              V v_dir_2436 = heff_field(v_t_2434, 0);
              heff_take_n(v_t_2434, 1ULL, 1);
              return heff_tag_at_n(v_ru_24it_244_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_name__dir, (V[]){v_name_2433, v_dir_2436})});
            }
            default: return heff_nomatch(v_t_2434);
            }
          }
          default: return heff_nomatch(v_t_2431);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it122_2430, 0ULL, 2);
          heff_drop(v_n_2417);
          heff_drop(v_d_2429);
          V v_t_2447;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2440 = heff_field(v_x_240, 1);
            v_t_2447 = heff_dup(v_t_2440);
            break;
          }
          case TAG_LTag: {
            V v_t_2442 = heff_field(v_x_240, 1);
            v_t_2447 = heff_dup(v_t_2442);
            break;
          }
          case TAG_LList: {
            V v_t_2444 = heff_field(v_x_240, 1);
            v_t_2447 = heff_dup(v_t_2444);
            break;
          }
          case TAG_LRec: {
            V v_t_2446 = heff_field(v_x_240, 1);
            v_t_2447 = heff_dup(v_t_2446);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2448 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2447, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_str4)});
          return heff_tag_at_n(v_ru_24it_244_24Right, TAG_Left, 1, (V[]){v_t_2448});
        }
        default: return heff_nomatch(v_it122_2430);
        }
      }
      default: return heff_nomatch(v_it12_2418);
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2ebuild_2eproject_2ereplaceOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2ereplaceOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ebuild_2eproject_2etwiceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2etwiceGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2etwiceGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_seen_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})});
      }
      case TAG_False: {
        heff_drop(v_x_245);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_n_244, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eproject_2etwiceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2etwiceGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2eunrequired_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eunrequired_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eunrequired(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_names_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_n_244);
        heff_drop(v_x_245);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_rest_243);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eproject_2eunrequired_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2eunrequired(a[0], a[1]); heff_drop(a[0]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str1, 31, "` is replaced, but not required");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str3, 19, "` is replaced twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str5, 19, "` is required twice");
Clo g_heff_2ebuild_2eproject_2echeckNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2echeckNames_entry, 4, 0};

V g_heff_2ebuild_2eproject_2echeckNames(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s868949484x1127836054(v_rxs_240, heff_dup(v_rs_241)));
  V v_it_245 = (g_heff_2ebuild_2eproject_2etwiceGo(NTAG(TAG_Nil), v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_list_2ezipWith_24s568889179x755145155(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
    V v_it_247 = (g_heff_2ebuild_2eproject_2etwiceGo(NTAG(TAG_Nil), v_t_246));
    switch (heff_tag_of(v_it_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_list_2emap_24s336317878x1053990440(v_rs_241));
      V v_t_249 = (g_list_2ezipWith_24s568889179x755145155(v_pxs_242, v_ps_243));
      V v_it_2410 = ({ V a_0 = v_t_248; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2eproject_2eunrequired(a_0, a_1)); heff_drop(v_t_248); r_; });
      switch (heff_tag_of(v_it_2410)) {
      case TAG_Nothing: {
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_Just: {
        V v_it1_2411 = heff_field(v_it_2410, 0);
        V v_ru_24it_2410_24Just = heff_take_reuse_n(v_it_2410, 1ULL, 1);
        switch (heff_tag_of(v_it1_2411)) {
        case TAG_MkPair: {
          V v_n_2412 = heff_field(v_it1_2411, 0);
          V v_x_2413 = heff_field(v_it1_2411, 1);
          heff_take_n(v_it1_2411, 3ULL, 2);
          V v_t_2422;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_LStr: {
            V v_t_2415 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2415;
            break;
          }
          case TAG_LTag: {
            V v_t_2417 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2417;
            break;
          }
          case TAG_LList: {
            V v_t_2419 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2419;
            break;
          }
          case TAG_LRec: {
            V v_t_2421 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2421;
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_str0), heff_strAppend(v_n_2412, ((V)&g_heff_2ebuild_2eproject_2echeckNames_str1)));
          V v_t_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2422, 2, 7), v_t_2423});
          return heff_tag_at_n(v_ru_24it_2410_24Just, TAG_Left, 1, (V[]){v_t_2424});
        }
        default: return heff_nomatch(v_it1_2411);
        }
      }
      default: return heff_nomatch(v_it_2410);
      }
    }
    case TAG_Just: {
      V v_it1_2425 = heff_field(v_it_247, 0);
      V v_ru_24it_247_24Just = heff_take_reuse_n(v_it_247, 1ULL, 1);
      heff_drop(v_rs_241);
      heff_drop(v_pxs_242);
      heff_drop(v_ps_243);
      switch (heff_tag_of(v_it1_2425)) {
      case TAG_MkPair: {
        V v_n_2426 = heff_field(v_it1_2425, 0);
        V v_x_2427 = heff_field(v_it1_2425, 1);
        heff_take_n(v_it1_2425, 3ULL, 2);
        V v_t_2436;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_LStr: {
          V v_t_2429 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2429;
          break;
        }
        case TAG_LTag: {
          V v_t_2431 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2431;
          break;
        }
        case TAG_LList: {
          V v_t_2433 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2433;
          break;
        }
        case TAG_LRec: {
          V v_t_2435 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2435;
          break;
        }
        default: heff_nomatch(v_x_2427);
        }
        V v_t_2437 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_str2), heff_strAppend(v_n_2426, ((V)&g_heff_2ebuild_2eproject_2echeckNames_str3)));
        V v_t_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), v_t_2437});
        return heff_tag_at_n(v_ru_24it_247_24Just, TAG_Left, 1, (V[]){v_t_2438});
      }
      default: return heff_nomatch(v_it1_2425);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
  case TAG_Just: {
    V v_it1_2439 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    heff_drop(v_rs_241);
    heff_drop(v_pxs_242);
    heff_drop(v_ps_243);
    switch (heff_tag_of(v_it1_2439)) {
    case TAG_MkPair: {
      V v_n_2440 = heff_field(v_it1_2439, 0);
      V v_x_2441 = heff_field(v_it1_2439, 1);
      heff_take_n(v_it1_2439, 3ULL, 2);
      V v_t_2450;
      switch (heff_tag_of(v_x_2441)) {
      case TAG_LStr: {
        V v_t_2443 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2443;
        break;
      }
      case TAG_LTag: {
        V v_t_2445 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2445;
        break;
      }
      case TAG_LList: {
        V v_t_2447 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2447;
        break;
      }
      case TAG_LRec: {
        V v_t_2449 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2449;
        break;
      }
      default: heff_nomatch(v_x_2441);
      }
      V v_t_2451 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_str4), heff_strAppend(v_n_2440, ((V)&g_heff_2ebuild_2eproject_2echeckNames_str5)));
      V v_t_2452 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2450, 2, 7), v_t_2451});
      return heff_tag_at_n(v_ru_24it_245_24Just, TAG_Left, 1, (V[]){v_t_2452});
    }
    default: return heff_nomatch(v_it1_2439);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eproject_2echeckNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2echeckNames(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2eproject_2erequireOf(a_0)); heff_drop(v_x_241); r_; });
    V v_x2_244 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920(v_rest_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_p_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_x2_244);
      return heff_tag_at_n(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_p_245});
    }
    case TAG_Right: {
      V v_y_246 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Left: {
        V v_p_247 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_y_246);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_p_247});
      }
      case TAG_Right: {
        V v_ys_248 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_248})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2eproject_2ereplaceOf(a_0)); heff_drop(v_x_241); r_; });
    V v_x2_244 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(v_rest_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_p_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_x2_244);
      return heff_tag_at_n(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_p_245});
    }
    case TAG_Right: {
      V v_y_246 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Left: {
        V v_p_247 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_y_246);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_p_247});
      }
      case TAG_Right: {
        V v_ys_248 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_248})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(a[0]);
}
Clo g_heff_2ebuild_2eproject_2epackageOf4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf4_entry, 4, 0};

V g_heff_2ebuild_2eproject_2epackageOf4(V v_m_240, V v_h_241, V v_rq_242, V v_rp_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2eproject_2estr(v_m_240));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Left: {
    V v_p_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Left = heff_take_reuse_n(v_t_244, 1ULL, 1);
    return heff_tag_at_n(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_p_245});
  }
  case TAG_Right: {
    V v_mpath_246 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Right = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_247 = (g_heff_2ebuild_2eproject_2eversionOf(v_h_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Left: {
      V v_p_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_mpath_246);
      return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_248});
    }
    case TAG_Right: {
      V v_hv_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_2410 = (g_heff_2ebuild_2eproject_2eitems(v_rq_242));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Left: {
        V v_p_2411 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        heff_drop(v_mpath_246);
        heff_drop(v_hv_249);
        return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2411});
      }
      case TAG_Right: {
        V v_rxs_2412 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        V v_t_2413 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920(heff_dup(v_rxs_2412)));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Left: {
          V v_p_2414 = heff_field(v_t_2413, 0);
          heff_take_n(v_t_2413, 1ULL, 1);
          heff_drop(v_mpath_246);
          heff_drop(v_hv_249);
          heff_drop(v_rxs_2412);
          return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2414});
        }
        case TAG_Right: {
          V v_rs_2415 = heff_field(v_t_2413, 0);
          heff_take_n(v_t_2413, 1ULL, 1);
          V v_t_2416 = (g_heff_2ebuild_2eproject_2eitems(v_rp_243));
          switch (heff_tag_of(v_t_2416)) {
          case TAG_Left: {
            V v_p_2417 = heff_field(v_t_2416, 0);
            heff_take_n(v_t_2416, 1ULL, 1);
            heff_drop(v_mpath_246);
            heff_drop(v_hv_249);
            heff_drop(v_rxs_2412);
            heff_drop(v_rs_2415);
            return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2417});
          }
          case TAG_Right: {
            V v_pxs_2418 = heff_field(v_t_2416, 0);
            heff_take_n(v_t_2416, 1ULL, 1);
            V v_t_2419 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(heff_dup(v_pxs_2418)));
            switch (heff_tag_of(v_t_2419)) {
            case TAG_Left: {
              V v_p_2420 = heff_field(v_t_2419, 0);
              heff_take_n(v_t_2419, 1ULL, 1);
              heff_drop(v_mpath_246);
              heff_drop(v_hv_249);
              heff_drop(v_rxs_2412);
              heff_drop(v_rs_2415);
              heff_drop(v_pxs_2418);
              return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2420});
            }
            case TAG_Right: {
              V v_ps_2421 = heff_field(v_t_2419, 0);
              heff_take_n(v_t_2419, 1ULL, 1);
              V v_t_2422 = (g_heff_2ebuild_2eproject_2echeckNames(v_rxs_2412, heff_dup(v_rs_2415), v_pxs_2418, heff_dup(v_ps_2421)));
              switch (heff_tag_of(v_t_2422)) {
              case TAG_Left: {
                V v_p_2423 = heff_field(v_t_2422, 0);
                heff_take_n(v_t_2422, 1ULL, 1);
                heff_drop(v_mpath_246);
                heff_drop(v_hv_249);
                heff_drop(v_rs_2415);
                heff_drop(v_ps_2421);
                return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_p_2423});
              }
              case TAG_Right: {
                heff_take_n(v_t_2422, 0ULL, 1);
                return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Right, 1, (V[]){heff_rec_n(4, shape_module__heff__require__replace, (V[]){v_mpath_246, v_hv_249, v_rs_2415, v_ps_2421})});
              }
              default: return heff_nomatch(v_t_2422);
              }
            }
            default: return heff_nomatch(v_t_2419);
            }
          }
          default: return heff_nomatch(v_t_2416);
          }
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2eproject_2epackageOf4_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2epackageOf4(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str0, 6, "module");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str1, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str2, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str3, 7, "replace");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str6, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str7, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str8, 25, "expected a record `{...}`");
V g_heff_2ebuild_2eproject_2epackageOf_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_lam0, 1, 0};
V g_heff_2ebuild_2eproject_2epackageOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_lam1, 1, 0};
Clo g_heff_2ebuild_2eproject_2epackageOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epackageOf(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageOf_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageOf_str1), NTAG(TAG_Nothing)});
  V v_t_244 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageOf_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageOf_lam0_clo)})});
  V v_t_246 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageOf_str3), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageOf_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_247})});
  V v_it_249 = (g_heff_2ebuild_2eproject_2efieldsAre(heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_248}), v_x_240));
  switch (heff_tag_of(v_it_249)) {
  case TAG_Left: {
    V v_p_2410 = heff_field(v_it_249, 0);
    V v_ru_24it_249_24Left = heff_take_reuse_n(v_it_249, 1ULL, 1);
    return heff_tag_at_n(v_ru_24it_249_24Left, TAG_Left, 1, (V[]){v_p_2410});
  }
  case TAG_Right: {
    V v_it1_2411 = heff_field(v_it_249, 0);
    V v_ru_24it_249_24Right = heff_take_reuse_n(v_it_249, 1ULL, 1);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_Nil: {
      V v_t_2420;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_2413 = heff_field(v_x_240, 1);
        v_t_2420 = heff_dup(v_t_2413);
        break;
      }
      case TAG_LTag: {
        V v_t_2415 = heff_field(v_x_240, 1);
        v_t_2420 = heff_dup(v_t_2415);
        break;
      }
      case TAG_LList: {
        V v_t_2417 = heff_field(v_x_240, 1);
        v_t_2420 = heff_dup(v_t_2417);
        break;
      }
      case TAG_LRec: {
        V v_t_2419 = heff_field(v_x_240, 1);
        v_t_2420 = heff_dup(v_t_2419);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2421 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2420, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str4)});
      return heff_tag_at_n(v_ru_24it_249_24Right, TAG_Left, 1, (V[]){v_t_2421});
    }
    case TAG_Cons: {
      V v_m_2422 = heff_field(v_it1_2411, 0);
      V v_it12_2423 = heff_field(v_it1_2411, 1);
      heff_take_n(v_it1_2411, 3ULL, 2);
      switch (heff_tag_of(v_it12_2423)) {
      case TAG_Nil: {
        heff_drop(v_m_2422);
        V v_t_2432;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2425 = heff_field(v_x_240, 1);
          v_t_2432 = heff_dup(v_t_2425);
          break;
        }
        case TAG_LTag: {
          V v_t_2427 = heff_field(v_x_240, 1);
          v_t_2432 = heff_dup(v_t_2427);
          break;
        }
        case TAG_LList: {
          V v_t_2429 = heff_field(v_x_240, 1);
          v_t_2432 = heff_dup(v_t_2429);
          break;
        }
        case TAG_LRec: {
          V v_t_2431 = heff_field(v_x_240, 1);
          v_t_2432 = heff_dup(v_t_2431);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2433 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2432, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str5)});
        return heff_tag_at_n(v_ru_24it_249_24Right, TAG_Left, 1, (V[]){v_t_2433});
      }
      case TAG_Cons: {
        V v_h_2434 = heff_field(v_it12_2423, 0);
        V v_it122_2435 = heff_field(v_it12_2423, 1);
        heff_take_n(v_it12_2423, 3ULL, 2);
        switch (heff_tag_of(v_it122_2435)) {
        case TAG_Nil: {
          heff_drop(v_m_2422);
          heff_drop(v_h_2434);
          V v_t_2444;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2437 = heff_field(v_x_240, 1);
            v_t_2444 = heff_dup(v_t_2437);
            break;
          }
          case TAG_LTag: {
            V v_t_2439 = heff_field(v_x_240, 1);
            v_t_2444 = heff_dup(v_t_2439);
            break;
          }
          case TAG_LList: {
            V v_t_2441 = heff_field(v_x_240, 1);
            v_t_2444 = heff_dup(v_t_2441);
            break;
          }
          case TAG_LRec: {
            V v_t_2443 = heff_field(v_x_240, 1);
            v_t_2444 = heff_dup(v_t_2443);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2445 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2444, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str6)});
          return heff_tag_at_n(v_ru_24it_249_24Right, TAG_Left, 1, (V[]){v_t_2445});
        }
        case TAG_Cons: {
          V v_rq_2446 = heff_field(v_it122_2435, 0);
          V v_it1222_2447 = heff_field(v_it122_2435, 1);
          heff_take_n(v_it122_2435, 3ULL, 2);
          switch (heff_tag_of(v_it1222_2447)) {
          case TAG_Nil: {
            heff_drop(v_m_2422);
            heff_drop(v_h_2434);
            heff_drop(v_rq_2446);
            V v_t_2456;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2449 = heff_field(v_x_240, 1);
              v_t_2456 = heff_dup(v_t_2449);
              break;
            }
            case TAG_LTag: {
              V v_t_2451 = heff_field(v_x_240, 1);
              v_t_2456 = heff_dup(v_t_2451);
              break;
            }
            case TAG_LList: {
              V v_t_2453 = heff_field(v_x_240, 1);
              v_t_2456 = heff_dup(v_t_2453);
              break;
            }
            case TAG_LRec: {
              V v_t_2455 = heff_field(v_x_240, 1);
              v_t_2456 = heff_dup(v_t_2455);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_t_2457 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2456, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str7)});
            return heff_tag_at_n(v_ru_24it_249_24Right, TAG_Left, 1, (V[]){v_t_2457});
          }
          case TAG_Cons: {
            V v_rp_2458 = heff_field(v_it1222_2447, 0);
            V v_it12222_2459 = heff_field(v_it1222_2447, 1);
            heff_take_n(v_it1222_2447, 3ULL, 2);
            switch (heff_tag_of(v_it12222_2459)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24it_249_24Right, 1);
              return ({ V a_0 = v_m_2422; V a_1 = v_h_2434; V a_2 = v_rq_2446; V a_3 = v_rp_2458; V r_ = (g_heff_2ebuild_2eproject_2epackageOf4(a_0, a_1, a_2, a_3)); heff_drop(v_m_2422); heff_drop(v_h_2434); heff_drop(v_rq_2446); heff_drop(v_rp_2458); r_; });
            }
            case TAG_Cons: {
              heff_take_n(v_it12222_2459, 0ULL, 2);
              heff_drop(v_m_2422);
              heff_drop(v_h_2434);
              heff_drop(v_rq_2446);
              heff_drop(v_rp_2458);
              V v_t_2470;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2463 = heff_field(v_x_240, 1);
                v_t_2470 = heff_dup(v_t_2463);
                break;
              }
              case TAG_LTag: {
                V v_t_2465 = heff_field(v_x_240, 1);
                v_t_2470 = heff_dup(v_t_2465);
                break;
              }
              case TAG_LList: {
                V v_t_2467 = heff_field(v_x_240, 1);
                v_t_2470 = heff_dup(v_t_2467);
                break;
              }
              case TAG_LRec: {
                V v_t_2469 = heff_field(v_x_240, 1);
                v_t_2470 = heff_dup(v_t_2469);
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_t_2471 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2470, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str8)});
              return heff_tag_at_n(v_ru_24it_249_24Right, TAG_Left, 1, (V[]){v_t_2471});
            }
            default: return heff_nomatch(v_it12222_2459);
            }
          }
          default: return heff_nomatch(v_it1222_2447);
          }
        }
        default: return heff_nomatch(v_it122_2435);
        }
      }
      default: return heff_nomatch(v_it12_2423);
      }
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_it_249);
  }
}
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2epackageOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ebuild_2eproject_2epackageOf_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_243});
}
V g_heff_2ebuild_2eproject_2epackageOf_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_245});
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadPackage_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadPackage_str1, 7, "package");
Clo g_heff_2ebuild_2eproject_2ereadPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ereadPackage_entry, 1, 0};

V g_heff_2ebuild_2eproject_2ereadPackage(V v_src_240) {
top: ;
  V v_t_241 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_242 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_240), v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_243 = heff_get_n(v_l_242, 1, 3);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    V v_t_244 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_l_245 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_240, v_t_244, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_246 = heff_arrayFromList(heff_get_n(v_l_245, 0, 3));
    V v_t_247 = (g_heff_2ebuild_2eproject_2edeclsGo(((V)&g_heff_2ebuild_2eproject_2ereadPackage_str0), ((V)&g_heff_2ebuild_2eproject_2ereadPackage_str1), v_t_246, MK_INT(0LL), NTAG(TAG_Nothing)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Left: {
      V v_p_248 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Left = heff_take_reuse_n(v_t_247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_247_24Left, TAG_Left, 1, (V[]){v_p_248});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      return ({ V a_0 = v_x_249; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_249); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Cons: {
    V v_e_2410 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    heff_drop(v_src_240);
    V v_t_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_take_field(v_e_2410, 0), heff_get_n(v_e_2410, 2, 3)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2eproject_2ereadPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2ereadPackage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str0, 35, "expected a backend: C, Node or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str1, 1, "C");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str2, 1, "c");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str3, 4, "Node");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str4, 4, "node");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str5, 4, "Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str7, 11, "no backend ");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str8, 17, ": C, Node or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str9, 35, "expected a backend: C, Node or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_str10, 35, "expected a backend: C, Node or Page");
Clo g_heff_2ebuild_2eproject_2ebackendOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebackendOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2ebackendOf(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_244);
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_246);
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_248);
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_2410);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_str0)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2412});
  }
  case TAG_LTag: {
    V v_x1_2413 = heff_field(v_x_240, 0);
    V v_t_2414 = heff_field(v_x_240, 1);
    if (heff_strEq_c(heff_dup(v_x1_2413), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_str1))) {
      return heff_tag_n(TAG_Right, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebackendOf_str2)});
    } else {
      if (heff_strEq_c(heff_dup(v_x1_2413), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_str3))) {
        return heff_tag_n(TAG_Right, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebackendOf_str4)});
      } else {
        if (heff_strEq_c(heff_dup(v_x1_2413), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_str5))) {
          return heff_tag_n(TAG_Right, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebackendOf_str6)});
        } else {
          V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ebackendOf_str7), heff_strAppend(heff_dup(v_x1_2413), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_str8)));
          V v_t_2419 = heff_rec_n(2, shape_at__msg, (V[]){heff_dup(heff_rfield(v_t_2414, 2)), v_t_2418});
          return heff_tag_n(TAG_Left, 1, (V[]){v_t_2419});
        }
      }
    }
  }
  case TAG_LList: {
    V v_t_2430;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2423 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2423);
      break;
    }
    case TAG_LTag: {
      V v_t_2425 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2425);
      break;
    }
    case TAG_LList: {
      V v_t_2427 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2427);
      break;
    }
    case TAG_LRec: {
      V v_t_2429 = heff_field(v_x_240, 1);
      v_t_2430 = heff_dup(v_t_2429);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2431 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2430, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_str9)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
  }
  case TAG_LRec: {
    V v_t_2442;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2435 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2435);
      break;
    }
    case TAG_LTag: {
      V v_t_2437 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2437);
      break;
    }
    case TAG_LList: {
      V v_t_2439 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2439);
      break;
    }
    case TAG_LRec: {
      V v_t_2441 = heff_field(v_x_240, 1);
      v_t_2442 = heff_dup(v_t_2441);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2443 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2442, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_str10)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2443});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2ebuild_2eproject_2ebackendOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2ebackendOf(a[0]); heff_drop(a[0]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str0, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str1, 72, "a program ships no `bin`: the heff home's bin/ is where the programs are");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str4, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str6, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str7, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str8, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str9, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str10, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str12, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str13, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str14, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str15, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_str16, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
Clo g_heff_2ebuild_2eproject_2eshipWrong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eshipWrong_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eshipWrong(V v_n_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_n_240), ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str0))) {
    heff_drop(v_n_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2eshipWrong_str1)});
  } else {
    if (heff_strEq_c(heff_dup(v_n_240), ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str2))) {
      V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_str3), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str4)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
    } else {
      if (heff_strEq_c(heff_dup(v_n_240), ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str5))) {
        V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_str6), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str7)));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
      } else {
        if (heff_strEq_c(heff_dup(v_n_240), ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str8))) {
          V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_str9), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str10)));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
        } else {
          V v_x3_248 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eproject_2eshipWrong_str11), heff_dup(v_n_240), MK_INT(0LL)));
          switch (heff_tag_of(v_x3_248)) {
          case TAG_Nothing: {
            V v_x3_249 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eproject_2eshipWrong_str12), heff_dup(v_n_240), MK_INT(0LL)));
            switch (heff_tag_of(v_x3_249)) {
            case TAG_Nothing: {
              heff_drop(v_n_240);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 0ULL, 1);
              V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_str13), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str14)));
              return heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_t_2411});
            }
            default: return heff_nomatch(v_x3_249);
            }
          }
          case TAG_Just: {
            V v_ru_24x3_248_24Just = heff_take_reuse_n(v_x3_248, 0ULL, 1);
            V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_str15), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_str16)));
            return heff_tag_at_n(v_ru_24x3_248_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x3_248);
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eproject_2eshipWrong_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eshipWrong(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2eproject_2estr(v_x_241));
    V v_x1_2418;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Left: {
      V v_p_244 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Left = heff_take_reuse_n(v_t_243, 1ULL, 1);
      heff_drop(v_x_241);
      v_x1_2418 = heff_tag_at_n(v_ru_24t_243_24Left, TAG_Left, 1, (V[]){v_p_244});
      break;
    }
    case TAG_Right: {
      V v_n_245 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Right = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_246 = (g_heff_2ebuild_2eproject_2eshipWrong(heff_dup(v_n_245)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop(v_x_241);
        v_x1_2418 = heff_tag_at_n(v_ru_24t_243_24Right, TAG_Right, 1, (V[]){v_n_245});
        break;
      }
      case TAG_Just: {
        V v_why_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        heff_drop(v_n_245);
        V v_t_2416;
        switch (heff_tag_of(v_x_241)) {
        case TAG_LStr: {
          V v_t_249 = heff_field(v_x_241, 1);
          heff_take_n(v_x_241, 2ULL, 2);
          v_t_2416 = v_t_249;
          break;
        }
        case TAG_LTag: {
          V v_t_2411 = heff_field(v_x_241, 1);
          heff_take_n(v_x_241, 2ULL, 2);
          v_t_2416 = v_t_2411;
          break;
        }
        case TAG_LList: {
          V v_t_2413 = heff_field(v_x_241, 1);
          heff_take_n(v_x_241, 2ULL, 2);
          v_t_2416 = v_t_2413;
          break;
        }
        case TAG_LRec: {
          V v_t_2415 = heff_field(v_x_241, 1);
          heff_take_n(v_x_241, 2ULL, 2);
          v_t_2416 = v_t_2415;
          break;
        }
        default: heff_nomatch(v_x_241);
        }
        V v_t_2417 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2416, 2, 7), v_why_247});
        v_x1_2418 = heff_tag_at_n(v_ru_24t_243_24Right, TAG_Left, 1, (V[]){v_t_2417});
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_x2_2419 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Left: {
      V v_p_2420 = heff_field(v_x1_2418, 0);
      V v_ru_24x1_2418_24Left = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_x2_2419);
      return heff_tag_at_n(v_ru_24x1_2418_24Left, TAG_Left, 1, (V[]){v_p_2420});
    }
    case TAG_Right: {
      V v_y_2421 = heff_field(v_x1_2418, 0);
      V v_ru_24x1_2418_24Right = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Left: {
        V v_p_2422 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_y_2421);
        return heff_tag_at_n(v_ru_24x1_2418_24Right, TAG_Left, 1, (V[]){v_p_2422});
      }
      case TAG_Right: {
        V v_ys_2423 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2418_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_2421, v_ys_2423})});
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
    default: return heff_nomatch(v_x1_2418);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str0, 7, "backend");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str1, 3, "run");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str2, 5, "ships");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str6, 25, "expected a record `{...}`");
V g_heff_2ebuild_2eproject_2ebuildOf_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2ebuildOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_lam0, 1, 0};
Clo g_heff_2ebuild_2eproject_2ebuildOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2ebuildOf(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_str1), NTAG(TAG_Nothing)});
  V v_t_244 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  V v_it_247 = (g_heff_2ebuild_2eproject_2efieldsAre(v_t_246, v_x_240));
  switch (heff_tag_of(v_it_247)) {
  case TAG_Left: {
    V v_p_248 = heff_field(v_it_247, 0);
    V v_ru_24it_247_24Left = heff_take_reuse_n(v_it_247, 1ULL, 1);
    return heff_tag_at_n(v_ru_24it_247_24Left, TAG_Left, 1, (V[]){v_p_248});
  }
  case TAG_Right: {
    V v_it1_249 = heff_field(v_it_247, 0);
    V v_ru_24it_247_24Right = heff_take_reuse_n(v_it_247, 1ULL, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_Nil: {
      V v_t_2418;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_2411 = heff_field(v_x_240, 1);
        v_t_2418 = heff_dup(v_t_2411);
        break;
      }
      case TAG_LTag: {
        V v_t_2413 = heff_field(v_x_240, 1);
        v_t_2418 = heff_dup(v_t_2413);
        break;
      }
      case TAG_LList: {
        V v_t_2415 = heff_field(v_x_240, 1);
        v_t_2418 = heff_dup(v_t_2415);
        break;
      }
      case TAG_LRec: {
        V v_t_2417 = heff_field(v_x_240, 1);
        v_t_2418 = heff_dup(v_t_2417);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2419 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2418, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str3)});
      return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_t_2419});
    }
    case TAG_Cons: {
      V v_b_2420 = heff_field(v_it1_249, 0);
      V v_it12_2421 = heff_field(v_it1_249, 1);
      heff_take_n(v_it1_249, 3ULL, 2);
      switch (heff_tag_of(v_it12_2421)) {
      case TAG_Nil: {
        heff_drop(v_b_2420);
        V v_t_2430;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2423 = heff_field(v_x_240, 1);
          v_t_2430 = heff_dup(v_t_2423);
          break;
        }
        case TAG_LTag: {
          V v_t_2425 = heff_field(v_x_240, 1);
          v_t_2430 = heff_dup(v_t_2425);
          break;
        }
        case TAG_LList: {
          V v_t_2427 = heff_field(v_x_240, 1);
          v_t_2430 = heff_dup(v_t_2427);
          break;
        }
        case TAG_LRec: {
          V v_t_2429 = heff_field(v_x_240, 1);
          v_t_2430 = heff_dup(v_t_2429);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2431 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2430, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str4)});
        return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_t_2431});
      }
      case TAG_Cons: {
        V v_r_2432 = heff_field(v_it12_2421, 0);
        V v_it122_2433 = heff_field(v_it12_2421, 1);
        heff_take_n(v_it12_2421, 3ULL, 2);
        switch (heff_tag_of(v_it122_2433)) {
        case TAG_Nil: {
          heff_drop(v_b_2420);
          heff_drop(v_r_2432);
          V v_t_2442;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2435 = heff_field(v_x_240, 1);
            v_t_2442 = heff_dup(v_t_2435);
            break;
          }
          case TAG_LTag: {
            V v_t_2437 = heff_field(v_x_240, 1);
            v_t_2442 = heff_dup(v_t_2437);
            break;
          }
          case TAG_LList: {
            V v_t_2439 = heff_field(v_x_240, 1);
            v_t_2442 = heff_dup(v_t_2439);
            break;
          }
          case TAG_LRec: {
            V v_t_2441 = heff_field(v_x_240, 1);
            v_t_2442 = heff_dup(v_t_2441);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2443 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2442, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str5)});
          return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_t_2443});
        }
        case TAG_Cons: {
          V v_s_2444 = heff_field(v_it122_2433, 0);
          V v_it1222_2445 = heff_field(v_it122_2433, 1);
          heff_take_n(v_it122_2433, 3ULL, 2);
          switch (heff_tag_of(v_it1222_2445)) {
          case TAG_Nil: {
            V v_t_2446 = ({ V a_0 = v_b_2420; V r_ = (g_heff_2ebuild_2eproject_2ebackendOf(a_0)); heff_drop(v_b_2420); r_; });
            switch (heff_tag_of(v_t_2446)) {
            case TAG_Left: {
              V v_p_2447 = heff_field(v_t_2446, 0);
              heff_take_n(v_t_2446, 1ULL, 1);
              heff_drop(v_r_2432);
              heff_drop(v_s_2444);
              return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_p_2447});
            }
            case TAG_Right: {
              V v_backend_2448 = heff_field(v_t_2446, 0);
              heff_take_n(v_t_2446, 1ULL, 1);
              V v_t_2449 = ({ V a_0 = v_r_2432; V r_ = (g_heff_2ebuild_2eproject_2estr(a_0)); heff_drop(v_r_2432); r_; });
              switch (heff_tag_of(v_t_2449)) {
              case TAG_Left: {
                V v_p_2450 = heff_field(v_t_2449, 0);
                heff_take_n(v_t_2449, 1ULL, 1);
                heff_drop(v_s_2444);
                heff_drop(v_backend_2448);
                return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_p_2450});
              }
              case TAG_Right: {
                V v_run_2451 = heff_field(v_t_2449, 0);
                heff_take_n(v_t_2449, 1ULL, 1);
                V v_t_2452 = ({ V a_0 = v_s_2444; V r_ = (g_heff_2ebuild_2eproject_2eitems(a_0)); heff_drop(v_s_2444); r_; });
                switch (heff_tag_of(v_t_2452)) {
                case TAG_Left: {
                  V v_p_2453 = heff_field(v_t_2452, 0);
                  heff_take_n(v_t_2452, 1ULL, 1);
                  heff_drop(v_backend_2448);
                  heff_drop(v_run_2451);
                  return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_p_2453});
                }
                case TAG_Right: {
                  V v_xs_2454 = heff_field(v_t_2452, 0);
                  heff_take_n(v_t_2452, 1ULL, 1);
                  V v_t_2455 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_xs_2454));
                  switch (heff_tag_of(v_t_2455)) {
                  case TAG_Left: {
                    V v_p_2456 = heff_field(v_t_2455, 0);
                    heff_take_n(v_t_2455, 1ULL, 1);
                    heff_drop(v_backend_2448);
                    heff_drop(v_run_2451);
                    return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_p_2456});
                  }
                  case TAG_Right: {
                    V v_ships_2457 = heff_field(v_t_2455, 0);
                    heff_take_n(v_t_2455, 1ULL, 1);
                    return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Right, 1, (V[]){heff_rec_n(3, shape_backend__run__ships, (V[]){v_backend_2448, v_run_2451, v_ships_2457})});
                  }
                  default: return heff_nomatch(v_t_2455);
                  }
                }
                default: return heff_nomatch(v_t_2452);
                }
              }
              default: return heff_nomatch(v_t_2449);
              }
            }
            default: return heff_nomatch(v_t_2446);
            }
          }
          case TAG_Cons: {
            heff_take_n(v_it1222_2445, 0ULL, 2);
            heff_drop(v_b_2420);
            heff_drop(v_r_2432);
            heff_drop(v_s_2444);
            V v_t_2468;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2461 = heff_field(v_x_240, 1);
              v_t_2468 = heff_dup(v_t_2461);
              break;
            }
            case TAG_LTag: {
              V v_t_2463 = heff_field(v_x_240, 1);
              v_t_2468 = heff_dup(v_t_2463);
              break;
            }
            case TAG_LList: {
              V v_t_2465 = heff_field(v_x_240, 1);
              v_t_2468 = heff_dup(v_t_2465);
              break;
            }
            case TAG_LRec: {
              V v_t_2467 = heff_field(v_x_240, 1);
              v_t_2468 = heff_dup(v_t_2467);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_t_2469 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2468, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str6)});
            return heff_tag_at_n(v_ru_24it_247_24Right, TAG_Left, 1, (V[]){v_t_2469});
          }
          default: return heff_nomatch(v_it1222_2445);
          }
        }
        default: return heff_nomatch(v_it122_2433);
        }
      }
      default: return heff_nomatch(v_it12_2421);
      }
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  default: return heff_nomatch(v_it_247);
  }
}
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2ebuildOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ebuild_2eproject_2ebuildOf_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_243});
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_str1, 5, "build");
Clo g_heff_2ebuild_2eproject_2ereadBuild_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ereadBuild_entry, 1, 0};

V g_heff_2ebuild_2eproject_2ereadBuild(V v_src_240) {
top: ;
  V v_t_241 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_242 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_240), v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_243 = heff_get_n(v_l_242, 1, 3);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    V v_t_244 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_l_245 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_240, v_t_244, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_246 = heff_arrayFromList(heff_get_n(v_l_245, 0, 3));
    V v_t_247 = (g_heff_2ebuild_2eproject_2edeclsGo(((V)&g_heff_2ebuild_2eproject_2ereadBuild_str0), ((V)&g_heff_2ebuild_2eproject_2ereadBuild_str1), v_t_246, MK_INT(0LL), NTAG(TAG_Nothing)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Left: {
      V v_p_248 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Left = heff_take_reuse_n(v_t_247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_247_24Left, TAG_Left, 1, (V[]){v_p_248});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      return ({ V a_0 = v_x_249; V r_ = (g_heff_2ebuild_2eproject_2ebuildOf(a_0)); heff_drop(v_x_249); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Cons: {
    V v_e_2410 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    heff_drop(v_src_240);
    V v_t_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_take_field(v_e_2410, 0), heff_get_n(v_e_2410, 2, 3)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2eproject_2ereadBuild_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2ereadBuild(a[0]);
}
Clo g_heff_2ebuild_2eproject_2enewerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewerGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewerGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c(heff_dup(v_y_244), heff_dup(v_x_242))) {
        return NTAG(TAG_True);
      } else {
        if (heff_intEq_c(heff_dup(v_x_242), heff_dup(v_y_244))) {
          V t_0 = v_xs_243;
          V t_1 = v_ys_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2enewerGo(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str2, 1, "/");
Clo g_heff_2ebuild_2eproject_2erepoOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erepoOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2erepoOf(V v_path_240) {
top: ;
  V v_xs_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2erepoOf_str0), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_x_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    v_x_245 = heff_dup(v_path_240);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    v_x_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_x_245)))) {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_245), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ebuild_2eproject_2erepoOf_str1))) {
      V v_t_248 = heff_strSlice(heff_dup(v_x_245), MK_INT(1LL), heff_strLength(v_x_245));
      V v_t_249 = (g_heff_2ebuild_2eproject_2eisNumber(v_t_248));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        V v_xs_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2erepoOf_str2), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nil: {
          v_t_2414 = heff_dup(v_path_240);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_t_2411, 0);
          heff_take_n(v_t_2411, 1ULL, 2);
          v_t_2414 = v_x_2412;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        V v_t_2415 = heff_intSub(heff_strLength(heff_dup(v_path_240)), heff_strLength(v_t_2414));
        return heff_strSlice(v_path_240, MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL)));
      }
      case TAG_False: {
        return v_path_240;
      }
      default: return heff_nomatch(v_t_249);
      }
    } else {
      heff_drop(v_x_245);
      return v_path_240;
    }
  } else {
    heff_drop(v_x_245);
    return v_path_240;
  }
}
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erepoOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str0, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str1, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str3, 30, "` is no version: write `a.b.c`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str4, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
Clo g_heff_2ebuild_2eproject_2esumLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2esumLine_entry, 2, 0};

V g_heff_2ebuild_2eproject_2esumLine(V v_at_240, V v_line_241) {
top: ;
  V v_it_242 = (g_prelude_2ewordsFrom(v_line_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_it2_244 = heff_field(v_it_242, 1);
    V v_ru_24it_242_24Cons = heff_take_reuse_n(v_it_242, 3ULL, 2);
    switch (heff_tag_of(v_it2_244)) {
    case TAG_Nil: {
      heff_drop(v_p_243);
      heff_drop_cell(v_ru_24it_242_24Cons, 2);
      return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_str0)})});
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_it2_244, 0);
      V v_it22_246 = heff_field(v_it2_244, 1);
      heff_take_n(v_it2_244, 3ULL, 2);
      switch (heff_tag_of(v_it22_246)) {
      case TAG_Nil: {
        heff_drop(v_p_243);
        heff_drop_cell(v_ru_24it_242_24Cons, 2);
        heff_drop(v_v_245);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_str1)})});
      }
      case TAG_Cons: {
        V v_h_247 = heff_field(v_it22_246, 0);
        V v_it222_248 = heff_field(v_it22_246, 1);
        heff_take_n(v_it22_246, 3ULL, 2);
        switch (heff_tag_of(v_it222_248)) {
        case TAG_Nil: {
          V v_t_249 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_v_245)));
          switch (heff_tag_of(v_t_249)) {
          case TAG_Nothing: {
            heff_drop(v_p_243);
            heff_drop_cell(v_ru_24it_242_24Cons, 2);
            heff_drop(v_h_247);
            V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2esumLine_str2), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eproject_2esumLine_str3)));
            return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, v_t_2410})});
          }
          case TAG_Just: {
            V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 0ULL, 1);
            heff_drop(v_at_240);
            V v_t_2412 = heff_tag_at_n(v_ru_24it_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_p_243, v_v_245, v_h_247}), NTAG(TAG_Nil)});
            return heff_tag_at_n(v_ru_24t_249_24Just, TAG_Right, 1, (V[]){v_t_2412});
          }
          default: return heff_nomatch(v_t_249);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_248, 0ULL, 2);
          heff_drop(v_p_243);
          heff_drop_cell(v_ru_24it_242_24Cons, 2);
          heff_drop(v_v_245);
          heff_drop(v_h_247);
          return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_str4)})});
        }
        default: return heff_nomatch(v_it222_248);
        }
      }
      default: return heff_nomatch(v_it22_246);
      }
    }
    default: return heff_nomatch(v_it2_244);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2ebuild_2eproject_2esumLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2esumLine(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2esumGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2esumGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2esumGo(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ebuild_2eproject_2esumLine(heff_dup(v_at_240), heff_dup(v_l_242)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Left: {
      V v_p_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Left = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_at_240);
      return heff_tag_at_n(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_p_245});
    }
    case TAG_Right: {
      V v_xs_246 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Right = heff_take_reuse_n(v_t_244, 1ULL, 1);
      V v_t_247 = heff_intAdd(v_at_240, heff_strLength(heff_dup(v_l_242)));
      V v_x3_248 = (g_heff_2ebuild_2eproject_2esumGo(heff_intAdd(v_t_247, MK_INT(1LL)), v_rest_243));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Left: {
        V v_x_249 = heff_field(v_x3_248, 0);
        heff_take_n(v_x3_248, 1ULL, 1);
        heff_drop(v_xs_246);
        return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){v_x_249});
      }
      case TAG_Right: {
        V v_y_2410 = heff_field(v_x3_248, 0);
        heff_take_n(v_x3_248, 1ULL, 1);
        return heff_tag_at_n(v_ru_24t_244_24Right, TAG_Right, 1, (V[]){(g_prelude_2e_2b_2b(v_xs_246, v_y_2410))});
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eproject_2esumGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2eproject_2esumGo(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ebuild_2eproject_2esumBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2esumBefore_entry, 2, 0};

V g_heff_2ebuild_2eproject_2esumBefore(V v_a_240, V v_b_241) {
top: ;
  if (heff_strLt_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
    heff_drop_rec(v_a_240, 3);
    heff_drop_rec(v_b_241, 3);
    return NTAG(TAG_True);
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
      V v_x2_244 = (g_heff_2ebuild_2eproject_2eversion(heff_get_n(v_a_240, 1, 3)));
      V v_t_246;
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        v_t_246 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_245 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        v_t_246 = v_x_245;
        break;
      }
      default: heff_nomatch(v_x2_244);
      }
      V v_x2_247 = (g_heff_2ebuild_2eproject_2eversion(heff_get_n(v_b_241, 1, 3)));
      V v_t_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_t_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_x1_2410 = ({ V a_0 = v_t_246; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_t_249); r_; });
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2410);
      }
    } else {
      heff_drop_rec(v_a_240, 3);
      heff_drop_rec(v_b_241, 3);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2esumBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str0, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str2, 2, "\\\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str3, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str5, 2, "\\\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str6, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str7, 1, "\"");
Clo g_heff_2ebuild_2eproject_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2equoted_entry, 1, 0};

V g_heff_2ebuild_2eproject_2equoted(V v_s_240) {
top: ;
  V v_x2_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2equoted_str0), v_s_240, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2eproject_2equoted_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str2); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2equoted_str3), v_s_244, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2eproject_2equoted_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str5); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(((V)&g_heff_2ebuild_2eproject_2equoted_str6), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2eproject_2equoted_str7)));
}
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2equoted(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str4, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str5, 4, " = [");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str6, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str10, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str11, 7, "replace");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str12, 4, " = [");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str13, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str14, 11, "{ module = ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str15, 9, ", heff = ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str16, 2, " }");
Clo g_heff_2ebuild_2eproject_2eshowPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eshowPackage_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eshowPackage(V v_pk_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_pk_240, 0)));
  V v_t_242 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_pk_240, 1)));
  V v_items_243 = (g_list_2emap_24s1381986540x1952410492(heff_take_field(v_pk_240, 2)));
  V v_t_249;
  switch (heff_tag_of(v_items_243)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str0);
    break;
  }
  case TAG_Cons: {
    V v_t_248;
    switch (heff_tag_of(v_items_243)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_items_243, 0);
      V v_xs_247 = heff_field(v_items_243, 1);
      heff_take_n(v_items_243, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_items_243);
    }
    v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str3), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str4), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str5), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str6)))));
    break;
  }
  default: heff_nomatch(v_items_243);
  }
  V v_items_2410 = (g_list_2emap_24s404123879x745642248(heff_get_n(v_pk_240, 3, 4)));
  V v_t_2416;
  switch (heff_tag_of(v_items_2410)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str7);
    break;
  }
  case TAG_Cons: {
    V v_t_2415;
    switch (heff_tag_of(v_items_2410)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_items_2410, 0);
      V v_xs_2414 = heff_field(v_items_2410, 1);
      heff_take_n(v_items_2410, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str9); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_items_2410);
    }
    v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str10), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str11), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str12), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str13)))));
    break;
  }
  default: heff_nomatch(v_items_2410);
  }
  return heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str14), heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str15), heff_strAppend(v_t_242, heff_strAppend(v_t_249, heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str16)))))));
}
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eshowPackage(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_str0, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_str1, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_str2, 7, "package");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_str3, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_str4, 1, "=");
Clo g_heff_2ebuild_2eproject_2espanGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2espanGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2espanGo(V v_ts_240, V v_i_241) {
top: ;
  V v_t_242 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
  if (heff_strEq_c(heff_get_n(v_t_242, 0, 7), ((V)&g_heff_2ebuild_2eproject_2espanGo_str0))) {
    heff_drop(v_ts_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_244 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
    if (heff_strEq_c(heff_get_n(v_t_244, 0, 7), ((V)&g_heff_2ebuild_2eproject_2espanGo_str1))) {
      V v_t_246 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
      if (heff_strEq_c(heff_get_n(v_t_246, 1, 7), ((V)&g_heff_2ebuild_2eproject_2espanGo_str2))) {
        V v_t_248 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_248, 0)), ((V)&g_heff_2ebuild_2eproject_2espanGo_str3))) {
          if (heff_strEq_c(heff_get_n(v_t_248, 1, 7), ((V)&g_heff_2ebuild_2eproject_2espanGo_str4))) {
            V v_it_2411 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
            switch (heff_tag_of(v_it_2411)) {
            case TAG_Left: {
              heff_take_n(v_it_2411, 0ULL, 1);
              heff_drop(v_ts_240);
              heff_drop(v_i_241);
              return NTAG(TAG_Nothing);
            }
            case TAG_Right: {
              V v_it1_2413 = heff_field(v_it_2411, 0);
              V v_ru_24it_2411_24Right = heff_take_reuse_n(v_it_2411, 1ULL, 1);
              switch (heff_tag_of(v_it1_2413)) {
              case TAG_MkPair: {
                V v_j_2415 = heff_field(v_it1_2413, 1);
                V v_ru_24it1_2413_24MkPair = heff_take_reuse_n(v_it1_2413, 2ULL, 2);
                V v_t_2416 = heff_arrayIndex(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(2LL)));
                V v_t_2417 = heff_arrayIndex(v_ts_240, heff_intSub(v_j_2415, MK_INT(1LL)));
                V v_t_2418 = heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_t_2416, 2, 7), heff_get_n(v_t_2417, 3, 7)});
                return heff_tag_at_n(v_ru_24it_2411_24Right, TAG_Just, 1, (V[]){v_t_2418});
              }
              default: return heff_nomatch(v_it1_2413);
              }
            }
            default: return heff_nomatch(v_it_2411);
            }
          } else {
            V v_t_2419 = (g_heff_2ebuild_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
            V t_0 = v_ts_240;
            V t_1 = v_t_2419;
            v_ts_240 = t_0;
            v_i_241 = t_1;
            goto top;
          }
        } else {
          heff_drop_rec(v_t_248, 7);
          V v_t_2420 = (g_heff_2ebuild_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
          V t_0 = v_ts_240;
          V t_1 = v_t_2420;
          v_ts_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
      } else {
        V v_t_2421 = (g_heff_2ebuild_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
        V t_0 = v_ts_240;
        V t_1 = v_t_2421;
        v_ts_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    } else {
      V v_t_2422 = (g_heff_2ebuild_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
      V t_0 = v_ts_240;
      V t_1 = v_t_2422;
      v_ts_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2eproject_2espanGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2espanGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2ewithPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ewithPackage_entry, 2, 0};

V g_heff_2ebuild_2eproject_2ewithPackage(V v_src_240, V v_pk_241) {
top: ;
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_240), v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_244 = heff_arrayFromList(heff_get_n(v_l_243, 0, 3));
  V v_it_245 = (g_heff_2ebuild_2eproject_2espanGo(v_t_244, MK_INT(0LL)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_pk_241);
    return v_src_240;
  }
  case TAG_Just: {
    V v_it1_246 = heff_field(v_it_245, 0);
    heff_take_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_from_247 = heff_field(v_it1_246, 0);
      V v_to_248 = heff_field(v_it1_246, 1);
      heff_take_n(v_it1_246, 3ULL, 2);
      V v_t_249 = (g_heff_2ebuild_2eproject_2eshowPackage(v_pk_241));
      V v_t_2410 = heff_strSlice(heff_dup(v_src_240), v_to_248, heff_strLength(heff_dup(v_src_240)));
      return heff_strAppend(heff_strSlice(v_src_240, MK_INT(0LL), v_from_247), heff_strAppend(v_t_249, v_t_2410));
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2ewithPackage(a[0], a[1]);
}