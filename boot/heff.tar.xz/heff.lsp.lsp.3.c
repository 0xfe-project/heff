// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Timeout 14063
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_claim 296100950
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_errors 652506774
#define LBL_lib 316671
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_root__program[] = {LBL_root, LBL_program};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(V, V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
HeffT2 g_heff_2elsp_2elsp_2eclaimEdit_24cpr(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFix(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFix_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFix_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_clo;
V g_heff_2elsp_2elsp_2eclaimable(V);
V g_heff_2elsp_2elsp_2eclaimable_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimable_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595(V, V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_clo;
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680(V, V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_clo;
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360(V, V, V);
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_clo;
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478(V, V, V);
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eprobedIn(V, V, V);
V g_heff_2elsp_2elsp_2eprobedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedIn_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_clo;
V g_heff_2elsp_2elsp_2erenameVerdict_24tok1(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_24tok1_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788(V, V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(V, V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347(V, V);
V g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany_24s1032636598x1013662416(V);
V g_list_2eany_24s1032636598x1013662416_entry(V self, V *a);
extern Clo g_list_2eany_24s1032636598x1013662416_clo;
V g_list_2eany_24s325511642x189735065(V, V, V);
V g_list_2eany_24s325511642x189735065_entry(V self, V *a);
extern Clo g_list_2eany_24s325511642x189735065_clo;
HeffT2 g_list_2efind_24s1986081631x104660098_24cpr(V, V);
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s655928500x1399206842(V, V);
V g_list_2efoldl_24s655928500x1399206842_entry(V self, V *a);
extern Clo g_list_2efoldl_24s655928500x1399206842_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1201185697x960477413(V, V);
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2ekeepIf_24s738919255x1142813117(V, V, V, V);
V g_list_2ekeepIf_24s738919255x1142813117_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s738919255x1142813117_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f209282897x1211386325(V, V, V);
V g_prelude_2e_2b_2b_24f209282897x1211386325_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f209282897x1211386325_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2) || heff_intLe_c_lent(v_e_242, v_i_241, 0))) {
    heff_drop(v_n_243);
    if (heff_intLe_c_lent(v_i_241, v_e_242, 0)) {
      heff_drop(v_e_242);
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return v_e_242;
    }
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      V v_t_244 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_src_240, v_i_241, 0));
      V v_t_245 = heff_runeToInt(heff_strRuneAt_lent(v_src_240, v_i_241, 2));
      V v_t_246;
      if (heff_intLe_c(MK_INT(65536LL), v_t_245)) {
        v_t_246 = MK_INT(2LL);
      } else {
        v_t_246 = MK_INT(1LL);
      }
      V t_0 = v_src_240;
      V t_1 = v_t_244;
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, v_t_246);
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffset16(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}), heff_dup(v_params_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_246}), v_params_241));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2417;
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_2410 = v_field_245;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_JNull: {
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2412 = heff_field(v_it1_2410, 0);
          heff_take_n(v_it1_2410, 1ULL, 1);
          v_t_2417 = v_i_2412;
          break;
        }
        case TAG_JFloat: {
          double v_x_2413 = heff_tflat_f64(v_it1_2410, 0);
          heff_take_na(v_it1_2410, 0ULL, 1);
          v_t_2417 = heff_floor_f64(v_x_2413);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2410);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2417 = MK_INT(0LL);
      }
      V v_t_2425;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_it1_2418 = v_field_249;
        switch (heff_tag_of(v_it1_2418)) {
        case TAG_JNull: {
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2420 = heff_field(v_it1_2418, 0);
          heff_take_n(v_it1_2418, 1ULL, 1);
          v_t_2425 = v_i_2420;
          break;
        }
        case TAG_JFloat: {
          double v_x_2421 = heff_tflat_f64(v_it1_2418, 0);
          heff_take_na(v_it1_2418, 0ULL, 1);
          v_t_2425 = heff_floor_f64(v_x_2421);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2418);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2425 = MK_INT(0LL);
      }
      return (g_heff_2elsp_2elsp_2eoffsetGo(v_src_240, v_t_2417, v_t_2425, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetIn(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_24dps_entry, 3, 0};

V g_heff_2elsp_2elsp_2elinesFrom_24dps(V v_src_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str0), v_src_240, v_i_241, 1);
    V v_t_244;
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      v_t_244 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_244 = v_j_243;
    }
    V v_t_245 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_244, 4)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str1), v_src_240, v_i_241, 5);
    V v_t_249;
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_j_248);
      v_t_249 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_249 = v_j_248;
    }
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_t_249, MK_INT(1LL));
    V t_2 = v_cell_246;
    v_src_240 = t_0;
    v_i_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2espaceEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2espaceEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2espaceEnd(V v_l_240, V v_i_241) {
top: ;
  if ((heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_l_240, 0)) && ((heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)32ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)9ULL))))) {
    V t_0 = v_l_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_l_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2espaceEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str1, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 15, "codeActionKinds");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 18, "codeActionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str20, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str21, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str22, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str23, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10)}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11)}), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str20), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str21)})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str22), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str23), v_t_2424}), v_t_2428});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2429});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
Clo g_heff_2elsp_2elsp_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2etargetIn_entry, 5, 0};

V g_heff_2elsp_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244) {
top: ;
  HeffT2 v_t_245 = (g_list_2efind_24s1986081631x104660098_24cpr(v_f_241, heff_dup(v_program_244)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_248 = v_field_247;
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_248, 3)), heff_dup(heff_rfield(v_d_242, 1)))) {
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_248, NTAG(TAG_Nil)});
        V v_program_2410 = (g_prelude_2e_2b_2b_24f209282897x1211386325(v_t_249, v_f_241, heff_dup(v_program_244)));
        V v_off_2411 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_d_242, 1), heff_dup(v_p_243)));
        V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_2410)));
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_Nil: {
          heff_drop(v_f_241);
          heff_drop_rec(v_d_242, 2);
          heff_drop(v_p_243);
          heff_drop(v_program_244);
          heff_drop(v_program_2410);
          heff_drop(v_off_2411);
          return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        }
        case TAG_Cons: {
          V v_x_2413 = heff_field(v_x1_2412, 0);
          heff_take_n(v_x1_2412, 1ULL, 2);
          V v_t_2415 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_2413, 4)));
          V v_t_2416 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2415));
          V v_t_2417 = (g_heff_2ebuild_2equery_2etargetIn(v_program_2410, v_x_2413, v_t_2416, v_off_2411));
          switch (heff_tag_of(v_t_2417)) {
          case TAG_Nothing: {
            heff_drop(v_f_241);
            heff_drop_rec(v_d_242, 2);
            heff_drop(v_p_243);
            heff_drop(v_program_244);
            return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
          }
          case TAG_Just: {
            V v_t_2418 = heff_field(v_t_2417, 0);
            V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
            V v_target_2419 = heff_take_field(v_t_2418, 0);
            V v_name_2420 = heff_get_n(v_t_2418, 1, 2);
            V v_off_2421 = ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(b_0, a_1)); heff_drop(b_0); r_; });
            V v_occurrences_2422 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_244, heff_dup(v_target_2419), v_name_2420));
            V v_target_2423 = heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, v_target_2419, v_name_2420, v_occurrences_2422})});
            return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, v_off_2421, v_target_2423});
          }
          default: return heff_nomatch(v_t_2417);
          }
        }
        default: return heff_nomatch(v_x1_2412);
        }
      } else {
        heff_drop(v_f_241);
        heff_drop_rec(v_d_242, 2);
        heff_drop(v_p_243);
        heff_drop(v_program_244);
        heff_drop_rec(v_c_248, 14);
        return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      }
    } else {
      heff_drop(v_f_241);
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_p_243);
      heff_drop(v_program_244);
      heff_drop(v_field_247);
      return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    }
  }
}
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2etargetIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_r_241; V a_1 = v_rs_242; V r_ = (g_list_2ekeepIf_24s689992630x418898235(a_0, a_1)); heff_drop(v_r_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubRoots_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
Clo g_heff_2elsp_2elsp_2eclaimFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimFix_entry, 3, 0};

V g_heff_2elsp_2elsp_2eclaimFix(V v_d_240, V v_ds_241, V v_x3_242) {
top: ;
  V v_text_243 = heff_take_field(v_d_240, 1);
  V v_uri_244 = heff_get_n(v_d_240, 0, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_ds_241);
    heff_drop(v_text_243);
    heff_drop(v_uri_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_t_246 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_text_243), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    HeffT2 v_t_247 = ({ V a_0 = v_text_243; V a_1 = heff_dup(v_n_245); V b_2 = heff_get_n(v_t_246, 2, 4); HeffT2 r_ = (g_heff_2elsp_2elsp_2eclaimEdit_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2410 = v_field_249;
        V v_t_2411 = ({ V a_0 = v_uri_244; V a_1 = v_text_243; V a_2 = heff_dup(v_n_245); V a_3 = v_ds_241; V a_4 = v_x_2410; V r_ = (g_heff_2elsp_2elsp_2eclaimAction(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_243); r_; });
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_ds_241);
        heff_drop(v_text_243);
        heff_drop(v_uri_244);
        heff_drop(v_field_249);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eclaimFix_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eclaimFix(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_24cpr_str0, 14, "contentChanges");
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_24cpr_str1, 4, "text");

HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_24cpr_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, v_p_240));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_245 = v_field_244;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_JNull: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JBool: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JInt: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JString: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JArray: {
        V v_xs_2410 = heff_field(v_it1_245, 0);
        heff_take_n(v_it1_245, 1ULL, 1);
        V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x1_2411, 0);
          V v_ru_24x1_2411_24Cons = heff_take_reuse_n(v_x1_2411, 1ULL, 2);
          V v_t_2414 = heff_tag_at_n(v_ru_24x1_2411_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_24cpr_str1), NTAG(TAG_Nil)});
          HeffT2 v_t_2415 = (g_json_2eat_24cpr(v_t_2414, v_x_2412));
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              V v_it1_2418 = v_field_2417;
              switch (heff_tag_of(v_it1_2418)) {
              case TAG_JNull: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2418, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2418, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2418, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JString: {
                V v_s_2422 = heff_field(v_it1_2418, 0);
                heff_take_n(v_it1_2418, 1ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_s_2422}});
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2418, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2418, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2418)}});
              }
            } else {
              heff_drop(v_field_2417);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2411)}});
        }
      }
      case TAG_JObject: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2, 3, 0};
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_entry, 5, 0};

V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(V v_st_240, V v_f_241, V v_d_242, V v_z_243, V v_z_244) {
top: ;
  V v_docs_245 = heff_take_field(v_st_240, 0);
  V v_lib_246 = heff_get_n(v_st_240, 6, 7);
  V v_c_2427 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam0, 1, 1, (V[]){v_docs_245}), v_lib_246, v_f_241));
  return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam5, 1, 3, (V[]){v_z_243, v_d_242, v_z_244})});
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2411, 1, 2)});
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    v_t_2426 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    v_t_2426 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_Just, 1, (V[]){v_y_2425});
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_2422;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam4, 1, 1, (V[]){v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_docs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_docs_245; V a_1 = v_p_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_docs_245); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_p_247);
      V v_d_2411 = v_field_2410;
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam1, 2, 1, (V[]){v_d_2411});
    } else {
      heff_drop(v_field_2410);
      V v_path_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_247; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2416 = ({ V a_0 = v_path_2415; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2415); r_; });
      V v_c_2420 = heff_tr(heff_call(v_c_2416, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2_clo)}));
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3, 2, 1, (V[]){v_c_2420});
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_x_2435; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_full_2431 = heff_get_n(v_x_2430, 0, 2);
  V v_program_2432 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2431)));
  V v_t_2433 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2431));
  V v_t_2434 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_242, 1)), v_t_2433, heff_get_n(v_x_2428, 1, 5)));
  V v_diags_2436 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam7, 1, 1, (V[]){v_d_242}), v_t_2434));
  V f_ = v_z_244;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2432, v_diags_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2429 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2428)));
  V f_ = v_c_2429;
  heff_room[0] = v_z_243;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam6, 1, 3, (V[]){v_d_242, v_x_2428, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str5, 2, "id");
Clo g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_entry, 4, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(V v_wire_240, V v_id_241, V v_code_242, V v_msg_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str1)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_242})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_243})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str4), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_str5), v_id_241}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2410})});
  V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
  V v_t_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2413}));
  return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2414});
}
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_entry, 3, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(V v_wire_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(heff_dup(v_wire_240), v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam0, 2, 3, (V[]){v_c_243, v_st_241, v_wire_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2427 = heff_get_n(v_d_2412, 1, 2);
  HeffT2 v_t_2428 = ({ V a_0 = heff_rfield(v_x_2426, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
  V v_x_2434;
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_c_2431 = v_field_2430;
      V v_text_2432 = heff_take_field(v_c_2431, 0);
      V v_program_2433 = heff_get_n(v_c_2431, 1, 2);
      if (heff_strEq_c_lent(v_text_2432, v_text_2427, 1)) {
        v_x_2434 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2426, v_text_2427, v_program_2433});
      } else {
        heff_drop(v_program_2433);
        v_x_2434 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2426, v_text_2427, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2430);
      v_x_2434 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2426, v_text_2427, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_245;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2437 = heff_get_n(v_d_2412, 1, 2);
  HeffT2 v_t_2438 = ({ V a_0 = heff_rfield(v_x_2436, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
  V v_x_2444;
  {
    V v_field_2440 = v_t_2438.f[1];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_c_2441 = v_field_2440;
      V v_text_2442 = heff_take_field(v_c_2441, 0);
      V v_program_2443 = heff_get_n(v_c_2441, 1, 2);
      if (heff_strEq_c_lent(v_text_2442, v_text_2437, 1)) {
        v_x_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2436, v_text_2437, v_program_2443});
      } else {
        heff_drop(v_program_2443);
        v_x_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2436, v_text_2437, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2440);
      v_x_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2436, v_text_2437, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_245;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_wire_240);
    heff_drop(v_hd_244);
    V v_t_247 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_str0), NTAG(TAG_Nil)});
    V f_ = v_k_245;
    args[0] = v_t_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_248 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_f_248));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_d_2412 = v_field_2411;
        HeffT2 v_t_2413 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 1), v_f_248));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2416 = v_field_2415;
            if (heff_strEq_c(heff_get_n(v_c_2416, 0, 2), heff_dup(heff_rfield(v_d_2412, 1)))) {
              heff_drop(v_wire_240);
              heff_drop(v_hd_244);
              V v_text_2417 = heff_get_n(v_d_2412, 1, 2);
              HeffT2 v_t_2418 = ({ V a_0 = heff_rfield(v_st_241, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
              V v_x_2424;
              {
                V v_field_2420 = v_t_2418.f[1];
                int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                if ((v_tag_2419 == ((int64_t)0ULL))) {
                  V v_c_2421 = v_field_2420;
                  V v_text_2422 = heff_take_field(v_c_2421, 0);
                  V v_program_2423 = heff_get_n(v_c_2421, 1, 2);
                  if (heff_strEq_c_lent(v_text_2422, v_text_2417, 1)) {
                    v_x_2424 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2417, v_program_2423});
                  } else {
                    heff_drop(v_program_2423);
                    v_x_2424 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2417, NTAG(TAG_Nil)});
                  }
                } else {
                  heff_drop(v_field_2420);
                  v_x_2424 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2417, NTAG(TAG_Nil)});
                }
              }
              V f_ = v_k_245;
              args[0] = v_x_2424;
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              V v_c_2425 = (g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(v_wire_240, v_st_241, heff_dup(v_f_248)));
              V f_ = v_c_2425;
              heff_room[0] = v_hd_244;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam2, 1, 3, (V[]){v_d_2412, v_f_248, v_k_245});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          } else {
            heff_drop(v_field_2415);
            V v_c_2435 = (g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(v_wire_240, v_st_241, heff_dup(v_f_248)));
            V f_ = v_c_2435;
            heff_room[0] = v_hd_244;
            heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam3, 1, 3, (V[]){v_d_2412, v_f_248, v_k_245});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      } else {
        heff_drop(v_wire_240);
        heff_drop(v_hd_244);
        heff_drop(v_f_248);
        heff_drop(v_field_2411);
        V v_t_2445 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_str1), NTAG(TAG_Nil)});
        V f_ = v_k_245;
        args[0] = v_t_2445;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_lam1, 1, 4, (V[]){v_st_241, v_k_245, v_wire_240, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0, 2, 0};
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry, 2, 0};

V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_249, 0, 6), v_f_244});
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam2, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam6, 3, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam10, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam11(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_entry, 6, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950(V v_wire_240, V v_st_241, V v_root_242, V v_f_243, V v_z_244, V v_z_245) {
top: ;
  V v_docs_246 = heff_take_field(v_st_241, 0);
  V v_lib_247 = heff_take_field(v_st_241, 6);
  V v_checked_248 = heff_take_field(v_st_241, 1);
  V v_due_249 = heff_take_field(v_st_241, 2);
  V v_watch_2410 = heff_take_field(v_st_241, 4);
  V v_shutdown_2411 = heff_get_n(v_st_241, 5, 7);
  V v_t_2446 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam0, 1, 5, (V[]){v_wire_240, heff_dup(v_root_242), v_f_243, heff_dup(v_docs_246), heff_dup(v_lib_247)})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2446, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam11, 1, 8, (V[]){v_root_242, v_docs_246, v_checked_248, v_due_249, v_watch_2410, v_shutdown_2411, v_lib_247, v_z_245})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam2(V self, V *args) {
  V v_fs_2415 = args[0];
  return v_fs_2415;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam5(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_d_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2425, 1, 2)});
  V f_ = v_k_2427;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2432 = args[1];
  V v_k_2433 = args[2];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440;
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    heff_take_n(v_x_2437, 0ULL, 1);
    v_t_2440 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2439 = heff_field(v_x_2437, 0);
    V v_ru_24x_2437_24Right = heff_take_reuse_n(v_x_2437, 1ULL, 1);
    v_t_2440 = heff_tag_at_n(v_ru_24x_2437_24Right, TAG_Just, 1, (V[]){v_y_2439});
    break;
  }
  default: heff_nomatch(v_x_2437);
  }
  V f_ = v_k_2436;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam7(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam8, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam4(V self, V *args) {
  V v_p_2421 = args[0];
  V v_docs_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2422 = ({ V a_0 = v_docs_246; V a_1 = v_p_2421; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_docs_246); r_; });
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      heff_drop(v_p_2421);
      V v_d_2425 = v_field_2424;
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam5, 2, 1, (V[]){v_d_2425});
    } else {
      heff_drop(v_field_2424);
      V v_path_2429 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_2421; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2430 = ({ V a_0 = v_path_2429; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2429); r_; });
      V v_c_2434 = heff_tr(heff_call(v_c_2430, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam6_clo)}));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam7, 2, 1, (V[]){v_c_2434});
    }
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sources_2443 = (g_heff_2elsp_2elsp_2enubSources(v_x_2442));
  V v_x_2444 = (g_list_2efoldl_24s655928500x1399206842(NTAG(TAG_Nil), v_sources_2443));
  V f_ = v_k_2414;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_docs_246 = heff_env(self)[1];
  V v_lib_247 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_243, NTAG(TAG_Nil)});
  V v_files_2419 = (g_prelude_2e_2b_2b(v_x_2417, v_t_2418));
  V v_t_2420 = (g_heff_2elsp_2elsp_2enubPaths(v_files_2419));
  V v_c_2441 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam4, 1, 1, (V[]){v_docs_246}); V a_1 = v_lib_247; V a_2 = v_t_2420; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  V f_ = v_c_2441;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam9, 1, 1, (V[]){v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_wire_240 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_docs_246 = heff_env(self)[3];
  V v_lib_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){v_root_242, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam2_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2416, heff_dup(v_hd_2413), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam3, 1, 5, (V[]){v_f_243, v_docs_246, v_lib_247, v_hd_2413, v_k_2414})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam10(V self, V *args) {
  V v_r_2445 = args[0];
  return v_r_2445;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam0(V self, V *args) {
  V v_use_2412 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_docs_246 = heff_env(self)[3];
  V v_lib_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_use_2412;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam1, 2, 5, (V[]){v_wire_240, v_root_242, v_f_243, v_docs_246, v_lib_247});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam10_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_lam11(V self, V *args) {
  V v_x_2447 = args[0];
  V v_root_242 = heff_env(self)[0];
  V v_docs_246 = heff_env(self)[1];
  V v_checked_248 = heff_env(self)[2];
  V v_due_249 = heff_env(self)[3];
  V v_watch_2410 = heff_env(self)[4];
  V v_shutdown_2411 = heff_env(self)[5];
  V v_lib_247 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_program_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    heff_take_n(v_x_2447, 0ULL, 1);
    v_program_2450 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_program_2449 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    v_program_2450 = v_program_2449;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V v_t_2451 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_root__program, (V[]){v_root_242, heff_dup(v_program_2450)})});
  V v_t_2452 = heff_rec_n(2, shape_st__program, (V[]){heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){v_docs_246, v_checked_248, v_due_249, v_t_2451, v_watch_2410, v_shutdown_2411, v_lib_247}), v_program_2450});
  V f_ = v_z_245;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_entry, 3, 0};

V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360(V v_wire_240, V v_st_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680(heff_dup(v_wire_240), heff_dup(v_st_241), v_o_245));
    return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam1, 2, 4, (V[]){v_c_247, v_wire_240, v_st_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360(v_wire_240, v_st_241, v_rest_246));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam3, 1, 2, (V[]){v_k_249, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_lam2, 1, 5, (V[]){v_wire_240, v_st_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str7, 2, "id");
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam5, 3, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_entry, 4, 0};

V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595(V v_wire_240, V v_st_241, V v_id_242, V v_p_243) {
top: ;
  V v_c_244 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(heff_dup(v_wire_240), v_p_243));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam0, 2, 4, (V[]){v_c_244, v_id_242, v_wire_240, v_st_241});
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_d_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V v_t_2429 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2426, 1, 2)});
  V f_ = v_k_2428;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2433 = args[1];
  V v_k_2434 = args[2];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2438, 0);
    V v_ru_24x_2438_24Right = heff_take_reuse_n(v_x_2438, 1ULL, 1);
    v_t_2441 = heff_tag_at_n(v_ru_24x_2438_24Right, TAG_Just, 1, (V[]){v_y_2440});
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V f_ = v_k_2437;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam6(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam7, 1, 1, (V[]){v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam3(V self, V *args) {
  V v_q_2422 = args[0];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2423 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_q_2422; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      heff_drop(v_q_2422);
      V v_d_2426 = v_field_2425;
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam4, 2, 1, (V[]){v_d_2426});
    } else {
      heff_drop(v_field_2425);
      V v_path_2430 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_q_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2431 = ({ V a_0 = v_path_2430; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2430); r_; });
      V v_c_2435 = heff_tr(heff_call(v_c_2431, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam5_clo)}));
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam6, 2, 1, (V[]){v_c_2435});
    }
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_d_2421 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2444 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2443, 0, 5)));
  return (g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340(v_wire_240, v_st_241, v_id_242, v_d_2421, v_t_2444, v_hd_245, v_k_246));
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str1)})});
    V v_t_249 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str2), v_t_249}), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str3), v_id_242}), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2411})});
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2412, 1); r_; });
    V v_t_2414 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2414}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2415, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam2, 1, 2, (V[]){v_k_246, v_st_241})));
  }
  case TAG_Just: {
    V v_f_2417 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    HeffT2 v_t_2418 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_f_2417));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_247_24Just, 1);
        V v_d_2421 = v_field_2420;
        V v_c_2442 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam3, 1, 1, (V[]){heff_dup(v_st_241)}), heff_dup(heff_rfield(v_st_241, 6)), v_f_2417));
        V f_ = v_c_2442;
        heff_room[0] = heff_dup(v_hd_245);
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam8, 1, 6, (V[]){v_wire_240, v_st_241, v_id_242, v_d_2421, v_hd_245, v_k_246});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_f_2417);
        heff_drop(v_field_2420);
        V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str4), heff_tag_at_n(v_ru_24x_247_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str5)})});
        V v_t_2446 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str6), v_t_2446}), NTAG(TAG_Nil)});
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_str7), v_id_242}), v_t_2447});
        V v_t_2449 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2448})});
        V v_t_2450 = ({ V a_0 = v_t_2449; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2449, 1); r_; });
        V v_t_2451 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2450, NTAG(TAG_MkUnit)});
        V v_t_2452 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2451}));
        return (g_co_2eop_24s615738393x1686646143(v_t_2452, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam9, 1, 2, (V[]){v_k_246, v_st_241})));
      }
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_lam1, 1, 5, (V[]){v_id_242, v_wire_240, v_hd_245, v_k_246, v_st_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_str0, 1, " ");
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam3, 3, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam10, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam6(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_entry, 6, 0};

V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021(V v_wire_240, V v_st_241, V v_f_242, V v_program_243, V v_c_244, V v_s_245) {
top: ;
  V v_docs_246 = heff_take_field(v_st_241, 0);
  V v_lib_247 = heff_get_n(v_st_241, 6, 7);
  V v_c_2435 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam0, 1, 4, (V[]){heff_dup(v_f_242), v_c_244, heff_dup(v_s_245), v_docs_246}), v_lib_247, v_f_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam6, 2, 4, (V[]){v_c_2435, v_wire_240, v_program_243, v_s_245});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V v_src_2411 = heff_get_n(v_c_244, 3, 14);
  V v_t_2412 = heff_strSlice(heff_dup(v_src_2411), MK_INT(0LL), heff_take_field(v_s_245, 3));
  V v_t_2413 = heff_strSlice(heff_dup(v_src_2411), heff_take_field(v_s_245, 4), heff_strLength(v_src_2411));
  V v_t_2414 = heff_strAppend(heff_get_n(v_s_245, 0, 5), v_t_2413);
  V v_t_2415 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_str0), v_t_2414));
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_d_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2419, 1, 2)});
  V f_ = v_k_2421;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    heff_take_n(v_x_2431, 0ULL, 1);
    v_t_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2433 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    v_t_2434 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_Just, 1, (V[]){v_y_2433});
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V f_ = v_k_2430;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam5, 1, 1, (V[]){v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam0(V self, V *args) {
  V v_q_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_docs_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_q_248, v_f_242, 2)) {
    heff_drop(v_q_248);
    heff_drop(v_docs_246);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam1, 2, 2, (V[]){v_c_244, v_s_245});
  } else {
    heff_drop_rec(v_c_244, 14);
    heff_drop_rec(v_s_245, 5);
    HeffT2 v_t_2416 = ({ V a_0 = v_docs_246; V a_1 = v_q_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_docs_246); r_; });
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_q_248);
        V v_d_2419 = v_field_2418;
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam2, 2, 1, (V[]){v_d_2419});
      } else {
        heff_drop(v_field_2418);
        V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_q_248; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_c_2424 = ({ V a_0 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2423); r_; });
        V v_c_2428 = heff_tr(heff_call(v_c_2424, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam3_clo)}));
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam4, 2, 1, (V[]){v_c_2428});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam9(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_x_2438 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2440);
  V v_x1_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_2438, 0, 5)));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nil: {
    v_t_2445 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 2);
    v_t_2445 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2443});
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_x_2446 = (g_heff_2elsp_2elsp_2eprobedIn(v_program_243, v_s_245, v_t_2445));
  V f_ = v_k_2441;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam10(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam8(V self, V *args) {
  V v_use_2439 = args[0];
  V v_x_2438 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2439;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam9, 2, 3, (V[]){v_x_2438, v_program_243, v_s_245});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam10_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam11(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Left: {
    heff_take_n(v_x_2449, 0ULL, 1);
    v_t_2452 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_t_2451 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    v_t_2452 = v_t_2451;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V f_ = v_k_2437;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_hd_2436 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2448 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam8, 1, 3, (V[]){v_x_2438, v_program_243, v_s_245})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2448, v_hd_2436, heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam11, 1, 1, (V[]){v_k_2437})));
}
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam6(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_program_243 = heff_env(self)[2];
  V v_s_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_lam7, 1, 5, (V[]){v_wire_240, v_program_243, v_s_245, v_hd_2436, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str2, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str3, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str4, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str5, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str6, 5, "E0157");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str7, 8, "build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str8, 1, "/");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str9, 10, "package.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str10, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str11, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str12, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str13, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str14, 5, "E0157");
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam2, 2, 0};
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_entry, 3, 0};

V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207(V v_wire_240, V v_st_241, V v_p_242) {
top: ;
  V v_docs_243 = heff_take_field(v_st_241, 0);
  V v_lib_244 = heff_get_n(v_st_241, 6, 7);
  V v_c_245 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(v_wire_240, heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam0, 2, 4, (V[]){v_c_245, v_docs_243, v_p_242, v_lib_244});
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam2(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam4(V self, V *args) {
  V v_x_2448 = args[0];
  V v_f_249 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449 = (g_heff_2ebuild_2eload_2emoduleOf(v_x_2448, v_f_249));
  V v_x_2450 = (g_heff_2elsp_2elsp_2eclaimable(v_t_2449));
  V f_ = v_k_2447;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam3(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_f_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam4, 1, 2, (V[]){v_f_249, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam5(V self, V *args) {
  V v_x_2452 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_d_2413 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str10), NTAG(TAG_Nil)});
  HeffT2 v_t_2454 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str11), v_t_2453}), v_p_242));
  V v_t_2464;
  {
    V v_field_2456 = v_t_2454.f[1];
    int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
    if ((v_tag_2455 == ((int64_t)0ULL))) {
      V v_it1_2457 = v_field_2456;
      switch (heff_tag_of(v_it1_2457)) {
      case TAG_JNull: {
        v_t_2464 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2457, 0ULL, 1);
        v_t_2464 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2457, 0ULL, 1);
        v_t_2464 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2457, 0ULL, 1);
        v_t_2464 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2457, 0ULL, 1);
        v_t_2464 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2462 = heff_field(v_it1_2457, 0);
        heff_take_n(v_it1_2457, 1ULL, 1);
        v_t_2464 = v_xs_2462;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2457, 0ULL, 1);
        v_t_2464 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2457);
      }
    } else {
      heff_drop(v_field_2456);
      v_t_2464 = NTAG(TAG_Nil);
    }
  }
  V v_t_2465 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str12); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str13); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str14); V a_3 = v_t_2464; V r_ = (g_list_2ekeepIf_24s738919255x1142813117(a_0, b_1, b_2, a_3)); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_x_2466 = ({ V a_0 = v_d_2413; V a_1 = v_t_2465; V a_2 = v_x_2452; V r_ = (g_heff_2elsp_2elsp_2eclaimFix(a_0, a_1, a_2)); heff_drop(v_x_2452); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_docs_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_lib_244 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_docs_243);
    heff_drop(v_p_242);
    heff_drop(v_lib_244);
    heff_drop(v_hd_246);
    V f_ = v_k_247;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    HeffT2 v_t_2410 = ({ V a_0 = v_docs_243; V a_1 = v_f_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_docs_243); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_d_2413 = v_field_2412;
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str0), NTAG(TAG_Nil)});
        HeffT2 v_t_2415 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str1), v_t_2414}), heff_dup(v_p_242)));
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          V v_t_2425;
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_it1_2418 = v_field_2417;
            switch (heff_tag_of(v_it1_2418)) {
            case TAG_JNull: {
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2418, 0ULL, 1);
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2418, 0ULL, 1);
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2418, 0ULL, 1);
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_it1_2418, 0ULL, 1);
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            case TAG_JArray: {
              V v_xs_2423 = heff_field(v_it1_2418, 0);
              heff_take_n(v_it1_2418, 1ULL, 1);
              v_t_2425 = ({ V a_0 = v_xs_2423; V r_ = (g_list_2eany_24s1032636598x1013662416(a_0)); heff_drop(v_xs_2423); r_; });
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2418, 0ULL, 1);
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_it1_2418);
            }
          } else {
            heff_drop(v_field_2417);
            v_t_2425 = NTAG(TAG_True);
          }
          if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
            heff_drop(v_t_2425);
            V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str2), NTAG(TAG_Nil)});
            HeffT2 v_t_2427 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str3), v_t_2426}), heff_dup(v_p_242)));
            V v_t_2437;
            {
              V v_field_2429 = v_t_2427.f[1];
              int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
              if ((v_tag_2428 == ((int64_t)0ULL))) {
                V v_it1_2430 = v_field_2429;
                switch (heff_tag_of(v_it1_2430)) {
                case TAG_JNull: {
                  v_t_2437 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2430, 0ULL, 1);
                  v_t_2437 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_it1_2430, 0ULL, 1);
                  v_t_2437 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_it1_2430, 0ULL, 1);
                  v_t_2437 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2430, 0ULL, 1);
                  v_t_2437 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JArray: {
                  V v_xs_2435 = heff_field(v_it1_2430, 0);
                  heff_take_n(v_it1_2430, 1ULL, 1);
                  v_t_2437 = v_xs_2435;
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2430, 0ULL, 1);
                  v_t_2437 = NTAG(TAG_Nil);
                  break;
                }
                default: heff_nomatch(v_it1_2430);
                }
              } else {
                heff_drop(v_field_2429);
                v_t_2437 = NTAG(TAG_Nil);
              }
            }
            V v_x1_2438 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str4); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str5); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str6); V a_3 = v_t_2437; V r_ = (g_list_2ekeepIf_24s738919255x1142813117(a_0, b_1, b_2, a_3)); heff_drop(b_1); heff_drop(b_2); r_; });
            switch (heff_tag_of(v_x1_2438)) {
            case TAG_Nil: {
              heff_drop(v_p_242);
              heff_drop(v_lib_244);
              heff_drop(v_hd_246);
              heff_drop(v_f_249);
              heff_drop(v_d_2413);
              V f_ = v_k_247;
              args[0] = NTAG(TAG_Nil);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            }
            case TAG_Cons: {
              V v_ru_24x1_2438_24Cons = heff_take_reuse_n(v_x1_2438, 0ULL, 2);
              V v_t_2441 = heff_tag_at_n(v_ru_24x1_2438_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str7), NTAG(TAG_Nil)});
              V v_t_2442 = ({ V a_0 = v_f_249; V a_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str8); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_str9), v_t_2441}); V r_ = (g_list_2eany_24s325511642x189735065(a_0, a_1, b_2)); heff_drop(b_2); r_; });
              V v_c_2451;
              if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
                heff_drop(v_lib_244);
                heff_drop(v_f_249);
                heff_drop(v_t_2442);
                v_c_2451 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam2_clo);
              } else {
                heff_drop(v_t_2442);
                V v_c_2445 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_lib_244, heff_dup(v_f_249)));
                v_c_2451 = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam3, 2, 2, (V[]){v_c_2445, v_f_249});
              }
              V f_ = v_c_2451;
              heff_room[0] = v_hd_246;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam5, 1, 3, (V[]){v_p_242, v_d_2413, v_k_247});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
            default: return heff_nomatch(v_x1_2438);
            }
          } else {
            heff_drop(v_p_242);
            heff_drop(v_lib_244);
            heff_drop(v_hd_246);
            heff_drop(v_f_249);
            heff_drop(v_d_2413);
            heff_drop(v_t_2425);
            V f_ = v_k_247;
            args[0] = NTAG(TAG_Nil);
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        }
      } else {
        heff_drop(v_p_242);
        heff_drop(v_lib_244);
        heff_drop(v_hd_246);
        heff_drop(v_f_249);
        heff_drop(v_field_2412);
        V f_ = v_k_247;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_docs_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_lib_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_lam1, 1, 5, (V[]){v_k_247, v_docs_243, v_p_242, v_lib_244, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_str0, 8, "build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_str1, 1, "/");
HEFF_LIT(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_str2, 10, "package.hf");
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam2, 2, 0};
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_entry, 3, 0};

V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478(V v_wire_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(v_wire_240, v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam0, 2, 2, (V[]){v_c_243, v_st_241});
}
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_f_247 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = (g_heff_2ebuild_2eload_2emoduleOf(v_x_2415, v_f_247));
  V v_x_2417 = (g_heff_2elsp_2elsp_2eclaimable(v_t_2416));
  V f_ = v_k_2414;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam4, 1, 2, (V[]){v_f_247, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    v_t_2421 = NTAG(TAG_JNull);
    break;
  }
  case TAG_Just: {
    V v_n_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Just = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    v_t_2421 = heff_tag_at_n(v_ru_24x_2419_24Just, TAG_JString, 1, (V[]){v_n_2420});
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V f_ = v_k_245;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_JNull);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_str0), NTAG(TAG_Nil)});
    V v_t_249 = ({ V a_0 = v_f_247; V a_1 = ((V)&g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_str1); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_str2), v_t_248}); V r_ = (g_list_2eany_24s325511642x189735065(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_c_2418;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop_rec(v_st_241, 7);
      heff_drop(v_f_247);
      heff_drop(v_t_249);
      v_c_2418 = ((V)&g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam2_clo);
    } else {
      heff_drop(v_t_249);
      V v_c_2412 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_get_n(v_st_241, 6, 7), heff_dup(v_f_247)));
      v_c_2418 = heff_clo_n(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam3, 2, 2, (V[]){v_c_2412, v_f_247});
    }
    V f_ = v_c_2418;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam5, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_lam1, 1, 3, (V[]){v_k_245, v_st_241, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_entry, 5, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374(V v_wire_240, V v_st_241, V v_x2_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_c_247 = (g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(heff_dup(v_wire_240), v_st_241, heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_lam0, 1, 4, (V[]){v_wire_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_wire_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam8, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam12(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam12, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_entry, 4, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788(V v_wire_240, V v_st_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_245 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam0_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_245, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam1, 1, 4, (V[]){v_st_241, v_wire_240, v_z_242, v_z_243})));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return v_n_244;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018(v_wire_240, v_st_241, v_msg_2417, v_hd_2419, v_k_2420));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam5(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam3(V self, V *args) {
  V v_use_2418 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2418;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam4, 2, 3, (V[]){v_wire_240, v_st_241, v_msg_2417});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam5_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788(v_wire_240, v_x_2425, v_z_242, v_z_243));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2417 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2424 = (g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543(heff_dup(v_wire_240), v_st_241, v_msg_2417, v_x_2423));
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_z_242);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam7, 1, 3, (V[]){v_wire_240, v_z_242, v_z_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam8(V self, V *args) {
  V v_n_2426 = args[0];
  return v_n_2426;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam11(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_st_241 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_2433 = (g_list_2ekeepIf_24s1201185697x960477413(v_x_2428, v_t_2432));
  V v_t_2434 = (g_list_2emap_24s1415906091x1371825187(v_t_2433));
  return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_t_2434; V a_3 = v_hd_2430; V a_4 = v_k_2431; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s593615652x2060680374(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2434); r_; });
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam12(V self, V *args) {
  V v_r_2435 = args[0];
  return v_r_2435;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam10(V self, V *args) {
  V v_use_2429 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2429;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam11, 2, 3, (V[]){v_st_241, v_x_2428, v_wire_240});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam12_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam13(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_2439 = (g_list_2ekeepIf_24s1201185697x960477413(v_x_2428, v_t_2438));
  V v_fs_2440 = (g_list_2emap_24s1415906091x1371825187(v_t_2439));
  V v_t_2444;
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    heff_take_n(v_x_2437, 0ULL, 1);
    V v_t_2442 = ({ V a_0 = heff_take_field(v_st_241, 2); V a_1 = v_fs_2440; V r_ = (g_heff_2elsp_2elsp_2eundue(a_0, a_1)); heff_drop(v_fs_2440); r_; });
    v_t_2444 = ({ V rv_2 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_st_241, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  case TAG_Right: {
    V v_st2_2443 = heff_field(v_x_2437, 0);
    heff_take_n(v_x_2437, 1ULL, 1);
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_fs_2440);
    v_t_2444 = v_st2_2443;
    break;
  }
  default: heff_nomatch(v_x_2437);
  }
  return (g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788(v_wire_240, v_t_2444, v_z_242, v_z_243));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam9(V self, V *args) {
  V v_x_2428 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam10, 1, 3, (V[]){heff_dup(v_st_241), heff_dup(v_x_2428), heff_dup(v_wire_240)})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2436, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam13, 1, 5, (V[]){v_st_241, v_x_2428, v_wire_240, v_z_242, v_z_243})));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Message: {
    V v_msg_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Message = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2422 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam3, 1, 3, (V[]){heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_msg_2417)})})}));
    return (g_co_2eop_24s615738393x1686646143_24tok1(v_ru_24x_2416_24Message, v_t_2422, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam6, 1, 5, (V[]){v_wire_240, v_st_241, v_msg_2417, v_z_242, v_z_243})));
  }
  case TAG_Timeout: {
    V v_t_2427 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam8_clo)})}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2427, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam9, 1, 4, (V[]){v_wire_240, v_st_241, v_z_242, v_z_243})));
  }
  case TAG_Closed: {
    heff_drop_rec(v_st_241, 7);
    V v_t_2445 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){MK_INT(1LL)})}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2445, v_z_242, v_z_243));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_248 = (g_list_2emap_24s366344330x1145113647(v_t_247));
  V v_t_2414;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_x_246);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_249 = heff_field(v_t_248, 0);
    V v_ds_2410 = heff_field(v_t_248, 1);
    heff_take_n(v_t_248, 3ULL, 2);
    V v_t_2411 = ({ V a_0 = v_d_249; V a_1 = v_ds_2410; V r_ = (g_list_2efoldl_24s1096141254x104586789(a_0, a_1)); heff_drop(v_ds_2410); r_; });
    V v_y_2412 = heff_intSub(v_t_2411, v_x_246);
    V v_t_2413;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2412, 1)) {
      v_t_2413 = v_y_2412;
    } else {
      heff_drop(v_y_2412);
      v_t_2413 = MK_INT(0LL);
    }
    v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_c_2415 = ({ V a_0 = heff_dup(v_wire_240); V a_1 = v_t_2414; V r_ = (g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_z_242);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_lam2, 1, 4, (V[]){v_wire_240, v_st_241, v_z_242, v_z_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str0, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str1, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str3, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str4, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str5, 60, "` is already a name some of these occurrences would refer to");
Clo g_heff_2elsp_2elsp_2erenameVerdict_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameVerdict_24tok1_entry, 7, 0};

V g_heff_2elsp_2elsp_2erenameVerdict_24tok1(V v_tok_240, V v_before_241, V v_t_242, V v_new_243, V v_errorsBefore_244, V v_errorsAfter_245, V v_after_246) {
top: ;
  V v_t_2416;
  if (heff_intLt_c_lent(v_errorsBefore_244, v_errorsAfter_245, 0)) {
    heff_drop(v_after_246);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_245, v_errorsBefore_244));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str0), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str1)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str2), heff_strAppend(v_new_243, v_t_248));
    V v_t_2410 = heff_strAppend(heff_get_n(v_t_242, 2, 4), v_t_249);
    v_t_2416 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str3), v_t_2410)});
  } else {
    heff_drop(v_errorsBefore_244);
    heff_drop(v_errorsAfter_245);
    V v_t_2411 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_242), heff_dup(v_new_243)));
    V v_xs_2412 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_246, v_t_2411, v_new_243));
    V v_x_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    V v_y_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_242, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (!heff_intEq_c_lent(v_x_2413, v_y_2414, 0)) {
      heff_drop(v_x_2413);
      heff_drop(v_y_2414);
      V v_t_2415 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str4), heff_strAppend(v_new_243, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_24tok1_str5)));
      v_t_2416 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_new_243);
      heff_drop(v_x_2413);
      heff_drop(v_y_2414);
      v_t_2416 = NTAG(TAG_Nothing);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_241, 0, 2), v_t_2416});
}
V g_heff_2elsp_2elsp_2erenameVerdict_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameVerdict_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str5, 2, "id");
Clo g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_entry, 5, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1(V v_tok_240, V v_wire_241, V v_id_242, V v_code_243, V v_msg_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str0), heff_tag_at_n(v_tok_240, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str1)})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_243})});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_244})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str4), v_t_249}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_str5), v_id_242}), v_t_2410});
  V v_t_2412 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2411})});
  V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2412, 1); r_; });
  V v_t_2414 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tr(heff_call(v_wire_241, 1, (V[]){v_t_2414}));
  return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2415});
}
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_24tok1(a[0], a[1], a[2], a[3], a[4]);
}