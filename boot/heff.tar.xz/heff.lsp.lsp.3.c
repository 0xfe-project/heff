// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_ReadFile 6783
#define TAG_Send 26077
#define LBL_checked 974171621
#define LBL_claim 296100950
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_lib 316671
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_root__program[] = {LBL_root, LBL_program};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542(V, V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_clo;
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201(V, V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
HeffT2 g_heff_2elsp_2elsp_2eclaimEdit_24cpr(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFix(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFix_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFix_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s1013363202x963768326(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1013363202x963768326_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1013363202x963768326_clo;
V g_heff_2elsp_2elsp_2eclosed(V, V);
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclosed_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571(V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_clo;
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595(V, V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857(V, V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V);
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472(V, V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_clo;
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152(V, V, V);
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2emoduleNamed_24s222433081x601315597(V, V, V);
V g_heff_2elsp_2elsp_2emoduleNamed_24s222433081x601315597_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2emoduleNamed_24s222433081x601315597_clo;
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228(V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_clo;
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(V, V, V);
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_clo;
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128(V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_clo;
V g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515(V, V, V);
V g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032(V, V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_clo;
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_clo;
V g_heff_2elsp_2elsp_2esplitAction(V, V, V);
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitAction_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(V, V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291(V, V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
HeffT2 g_heff_2elsp_2esplit_2esplit_24cpr(V, V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl(V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2espotInDecl_clo;
V g_heff_2elsp_2esplit_2etypeUsedAt(V, V, V);
V g_heff_2elsp_2esplit_2etypeUsedAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2etypeUsedAt_clo;
HeffT2 g_heff_2elsp_2esplit_2eusedType_24cpr(V, V);
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1735462575x1745346429(V, V);
V g_list_2eany_24s1735462575x1745346429_entry(V self, V *a);
extern Clo g_list_2eany_24s1735462575x1745346429_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s951260806x709953240(V, V);
V g_list_2efilter_24s951260806x709953240_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_clo;
V g_list_2efilter_24s999680916x306845608(V, V);
V g_list_2efilter_24s999680916x306845608_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_clo;
HeffT2 g_list_2efind_24s1579782528x1030938804_24cpr(V, V);
HeffT2 g_list_2efind_24s465947678x1101118081_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s148011877x1447840770(V, V, V, V);
V g_list_2efoldl_24s148011877x1447840770_entry(V self, V *a);
extern Clo g_list_2efoldl_24s148011877x1447840770_clo;
V g_list_2efoldl_24s1907762870x769133410(V, V);
V g_list_2efoldl_24s1907762870x769133410_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1907762870x769133410_clo;
V g_list_2efoldl_24s2051016282x1892781518(V, V, V, V);
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2051016282x1892781518_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1818809633x296343841(V, V, V);
V g_prelude_2e_2b_2b_24f1818809633x296343841_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1818809633x296343841_clo;
V g_std_2emap_2edelete_24s339308281x1667047697(V, V);
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s339308281x1667047697_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  if (heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2)) {
    heff_drop(v_n_243);
    if (heff_intLe_c_lent(v_i_241, v_e_242, 0)) {
      heff_drop(v_e_242);
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return v_e_242;
    }
  } else {
    if (heff_intLe_c_lent(v_e_242, v_i_241, 0)) {
      heff_drop(v_n_243);
      if (heff_intLe_c_lent(v_i_241, v_e_242, 0)) {
        heff_drop(v_e_242);
        return v_i_241;
      } else {
        heff_drop(v_i_241);
        return v_e_242;
      }
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_e_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_e_242 = t_2;
        v_n_243 = t_3;
        goto top;
      } else {
        V v_t_249 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_src_240, v_i_241, 0));
        V v_t_2410 = heff_runeToInt(heff_strRuneAt_lent(v_src_240, v_i_241, 2));
        V v_t_2412;
        if (heff_intLe_c(MK_INT(65536LL), v_t_2410)) {
          v_t_2412 = MK_INT(2LL);
        } else {
          v_t_2412 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = v_t_249;
        V t_2 = v_e_242;
        V t_3 = heff_intSub(v_n_243, v_t_2412);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_e_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffset16(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}), heff_dup(v_params_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_246}), v_params_241));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2418;
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_2411 = v_field_245;
        switch (heff_tag_of(v_it1_2411)) {
        case TAG_JNull: {
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2413 = heff_field(v_it1_2411, 0);
          heff_take_n(v_it1_2411, 1ULL, 1);
          v_t_2418 = v_i_2413;
          break;
        }
        case TAG_JFloat: {
          double v_x_2414 = heff_tflat_f64(v_it1_2411, 0);
          heff_take_na(v_it1_2411, 0ULL, 1);
          v_t_2418 = heff_floor_f64(v_x_2414);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2411);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2418 = MK_INT(0LL);
      }
      V v_t_2427;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_it1_2420 = v_field_249;
        switch (heff_tag_of(v_it1_2420)) {
        case TAG_JNull: {
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2422 = heff_field(v_it1_2420, 0);
          heff_take_n(v_it1_2420, 1ULL, 1);
          v_t_2427 = v_i_2422;
          break;
        }
        case TAG_JFloat: {
          double v_x_2423 = heff_tflat_f64(v_it1_2420, 0);
          heff_take_na(v_it1_2420, 0ULL, 1);
          v_t_2427 = heff_floor_f64(v_x_2423);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2420);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2427 = MK_INT(0LL);
      }
      return (g_heff_2elsp_2elsp_2eoffsetGo(v_src_240, v_t_2418, v_t_2427, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetIn(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str1, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 15, "codeActionKinds");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 18, "codeActionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str20, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str21, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str22, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str23, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10)}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11)}), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str20), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str21)})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str22), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str23), v_t_2424}), v_t_2428});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2429});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
Clo g_heff_2elsp_2elsp_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2etargetIn_entry, 5, 0};

V g_heff_2elsp_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244) {
top: ;
  HeffT2 v_t_245 = (g_list_2efind_24s1579782528x1030938804_24cpr(v_f_241, heff_dup(v_program_244)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_247;
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_249, 3)), heff_dup(heff_rfield(v_d_242, 1)))) {
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_249, NTAG(TAG_Nil)});
        V v_program_2412 = (g_prelude_2e_2b_2b_24f1818809633x296343841(v_t_2411, v_f_241, heff_dup(v_program_244)));
        V v_off_2413 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_d_242, 1), heff_dup(v_p_243)));
        V v_x1_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_2412)));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nil: {
          heff_drop(v_f_241);
          heff_drop_rec(v_d_242, 2);
          heff_drop(v_p_243);
          heff_drop(v_program_244);
          heff_drop(v_program_2412);
          heff_drop(v_off_2413);
          return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        }
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 2);
          V v_t_2417 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_2415, 4)));
          V v_t_2418 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2417));
          V v_t_2419 = (g_heff_2ebuild_2equery_2etargetIn(v_program_2412, v_x_2415, v_t_2418, v_off_2413));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_Nothing: {
            heff_drop(v_f_241);
            heff_drop_rec(v_d_242, 2);
            heff_drop(v_p_243);
            heff_drop(v_program_244);
            return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
          }
          case TAG_Just: {
            V v_t_2420 = heff_field(v_t_2419, 0);
            V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 1ULL, 1);
            V v_off_2421 = ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(b_0, a_1)); heff_drop(b_0); r_; });
            V v_occurrences_2422 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_244, heff_dup(heff_rfield(v_t_2420, 0)), heff_rfield(v_t_2420, 1)));
            V v_t_2423 = heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, heff_take_field(v_t_2420, 0), heff_get_n(v_t_2420, 1, 2), v_occurrences_2422});
            V v_target_2424 = heff_tag_at_n(v_ru_24t_2419_24Just, TAG_Just, 1, (V[]){v_t_2423});
            return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, v_off_2421, v_target_2424});
          }
          default: return heff_nomatch(v_t_2419);
          }
        }
        default: return heff_nomatch(v_x1_2414);
        }
      } else {
        heff_drop(v_f_241);
        heff_drop_rec(v_d_242, 2);
        heff_drop(v_p_243);
        heff_drop(v_program_244);
        heff_drop_rec(v_c_249, 14);
        return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      }
    } else {
      heff_drop(v_f_241);
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_p_243);
      heff_drop(v_program_244);
      heff_drop(v_field_247);
      return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    }
  }
}
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2etargetIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_r_241; V a_1 = v_rs_242; V r_ = (g_list_2efilter_24s951260806x709953240(a_0, a_1)); heff_drop(v_r_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubRoots_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
Clo g_heff_2elsp_2elsp_2eclaimFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimFix_entry, 3, 0};

V g_heff_2elsp_2elsp_2eclaimFix(V v_d_240, V v_ds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_d_240, 2);
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_t_244 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(heff_rfield(v_d_240, 1)), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    HeffT2 v_t_245 = ({ V a_0 = heff_rfield(v_d_240, 1); V a_1 = heff_dup(v_n_243); V b_2 = heff_get_n(v_t_244, 2, 4); HeffT2 r_ = (g_heff_2elsp_2elsp_2eclaimEdit_24cpr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        V v_t_2410 = ({ V a_0 = heff_take_field(v_d_240, 0); V b_1 = heff_get_n(v_d_240, 1, 2); V a_2 = heff_dup(v_n_243); V a_3 = v_ds_241; V a_4 = v_x_249; V r_ = (g_heff_2elsp_2elsp_2eclaimAction(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      } else {
        heff_drop_rec(v_d_240, 2);
        heff_drop(v_ds_241);
        heff_drop(v_field_247);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eclaimFix_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eclaimFix(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_24cpr_str0, 14, "contentChanges");
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_24cpr_str1, 4, "text");

HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_24cpr_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, v_p_240));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JString: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_JArray: {
        V v_xs_2411 = heff_field(v_it1_246, 0);
        heff_take_n(v_it1_246, 1ULL, 1);
        V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2413 = heff_field(v_x1_2412, 0);
          V v_ru_24x1_2412_24Cons = heff_take_reuse_n(v_x1_2412, 1ULL, 2);
          V v_t_2415 = heff_tag_at_n(v_ru_24x1_2412_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_24cpr_str1), NTAG(TAG_Nil)});
          HeffT2 v_t_2416 = (g_json_2eat_24cpr(v_t_2415, v_x_2413));
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              V v_it1_2420 = v_field_2418;
              switch (heff_tag_of(v_it1_2420)) {
              case TAG_JNull: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2420, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2420, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2420, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JString: {
                V v_s_2424 = heff_field(v_it1_2420, 0);
                heff_take_n(v_it1_2420, 1ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_s_2424}});
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2420, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2420, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2420)}});
              }
            } else {
              heff_drop(v_field_2418);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2412)}});
        }
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_246)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str2, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str3, 31, "textDocument/publishDiagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str6, 6, "params");
Clo g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_entry, 3, 0};

V g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515(V v_wire_240, V v_uri_241, V v_ds_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str1)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str3)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str4), heff_tag_n(TAG_JString, 1, (V[]){v_uri_241})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_242})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_str6), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_249})});
  V v_t_2411 = ({ V b_0 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410}); V r_ = (g_json_2estringify(b_0)); heff_drop(b_0); r_; });
  V v_t_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2412}));
  return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2413});
}
V g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_entry, 3, 0};

V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201(V v_wire_240, V v_st_241, V v_f_242) {
top: ;
  V v_t_243 = (g_std_2emap_2edelete_24s339308281x1667047697(heff_dup(heff_rfield(v_st_241, 2)), v_f_242));
  V v_t_244 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_241, 0)), heff_dup(heff_rfield(v_st_241, 1)), v_t_243, heff_dup(heff_rfield(v_st_241, 3)), heff_dup(heff_rfield(v_st_241, 4)), heff_dup(heff_rfield(v_st_241, 5)), heff_dup(heff_rfield(v_st_241, 6))});
  V v_c_245 = (g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(heff_dup(v_wire_240), v_t_244, heff_dup(v_f_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam0, 2, 4, (V[]){v_c_245, v_st_241, v_f_242, v_wire_240});
}
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  V v_f_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413;
  switch (heff_tag_of(v_p_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_dup(heff_field(v_p_2410, 0));
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_p_2410);
  }
  if (heff_strEq_c_lent(v_t_2413, v_f_242, 1)) {
    heff_drop(v_p_2410);
    heff_drop(v_f_242);
    return NTAG(TAG_False);
  } else {
    V v_t_2417;
    switch (heff_tag_of(v_p_2410)) {
    case TAG_MkPair: {
      V v_y_2416 = heff_field(v_p_2410, 1);
      heff_take_n(v_p_2410, 2ULL, 2);
      v_t_2417 = v_y_2416;
      break;
    }
    default: heff_nomatch(v_p_2410);
    }
    return ({ V a_0 = v_f_242; V b_1 = heff_get_n(v_t_2417, 1, 2); V r_ = (g_list_2eany_24s1735462575x1745346429(a_0, b_1)); heff_drop(v_f_242); heff_drop(b_1); r_; });
  }
}
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = ({ V b_0 = heff_get_n(v_st_241, 1, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam2, 1, 1, (V[]){v_f_242}), v_t_249));
  V v_t_2419 = (g_list_2emap_24s1415906091x1371825187(v_t_2418));
  return ({ V a_0 = v_wire_240; V a_1 = v_x_248; V a_2 = v_t_2419; V a_3 = v_hd_246; V a_4 = v_k_247; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2419); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_lam1, 1, 5, (V[]){v_st_241, v_f_242, v_wire_240, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str2, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str3, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str5, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str6, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str7, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str13, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str14, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str17, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str18, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str19, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str20, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str22, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str23, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str24, 21, "textDocument/didClose");
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam3, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam5, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_entry, 4, 0};

V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228(V v_wire_240, V v_st_241, V v_m_242, V v_p_243) {
top: ;
  V v_c_244 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(heff_dup(v_wire_240), heff_dup(v_p_243)));
  return heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam0, 2, 5, (V[]){v_c_244, heff_dup(v_m_242), v_st_241, v_wire_240, v_p_243});
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2enotified_24s471260846x370540228(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam3(V self, V *args) {
  V v_n_2459 = args[0];
  return v_n_2459;
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam4(V self, V *args) {
  V v_x_2461 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_text_2458 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2462 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_dup(heff_rfield(v_st_241, 2)), heff_dup(v_f_2421), heff_intAdd(v_x_2461, MK_INT(200LL))));
  V v_s_2463 = (g_heff_2elsp_2elsp_2echanged(v_st_241, v_f_2421, v_text_2458));
  V v_t_2464 = ({ V rv_2 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_s_2463, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_246;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam5(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  heff_drop(v_hd_2473);
  V f_ = v_k_2474;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam6(V self, V *args) {
  V v_x_2476 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  V v_x_2477 = ({ V a_0 = v_st_241; V a_1 = v_f_2421; V r_ = (g_heff_2elsp_2elsp_2eclosed(a_0, a_1)); heff_drop(v_f_2421); r_; });
  V f_ = v_k_246;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str0), 2)) {
    heff_drop(v_x_247);
    heff_drop(v_m_242);
    heff_drop(v_p_243);
    V v_t_249 = heff_get_n(v_st_241, 5, 7);
    V v_t_2410;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = MK_INT(0LL);
    } else {
      heff_drop(v_t_249);
      v_t_2410 = MK_INT(1LL);
    }
    V v_t_2411 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_t_2410})}));
    return (g_co_2eop_24s495635622x733177935(v_t_2411, v_hd_245, v_k_246));
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str1), 2)) {
      heff_drop(v_x_247);
      heff_drop(v_m_242);
      heff_drop(v_p_243);
      V v_t_2413 = heff_dup(heff_rfield(v_st_241, 4));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = ({ V b_0 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_json_2estringify(b_0)); heff_drop(b_0); r_; });
        V v_t_2415 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
        V v_t_2416 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2415}));
        return (g_co_2eop_24s495635622x733177935(v_t_2416, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam2, 1, 2, (V[]){v_k_246, v_st_241})));
      } else {
        heff_drop(v_wire_240);
        heff_drop(v_hd_245);
        heff_drop(v_t_2413);
        V f_ = v_k_246;
        args[0] = v_st_241;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str2), 2)) {
        heff_drop(v_x_247);
        heff_drop(v_m_242);
        heff_drop(v_p_243);
        V v_t_2419 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 0), NTAG(TAG_Nil)));
        V v_t_2420 = (g_list_2emap_24s1415906091x1371825187(v_t_2419));
        return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_t_2420; V a_3 = v_hd_245; V a_4 = v_k_246; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2420); r_; });
      } else {
        switch (heff_tag_of(v_x_247)) {
        case TAG_Nothing: {
          heff_drop(v_m_242);
          heff_drop(v_wire_240);
          heff_drop(v_hd_245);
          heff_drop(v_p_243);
          V f_ = v_k_246;
          args[0] = v_st_241;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2421 = heff_field(v_x_247, 0);
          heff_take_n(v_x_247, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str3), 2)) {
            heff_drop(v_m_242);
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str4), NTAG(TAG_Nil)});
            HeffT2 v_t_2424 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str5), v_t_2423}), heff_dup(v_p_243)));
            V v_t_2449;
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str6), NTAG(TAG_Nil)});
              HeffT2 v_t_2428 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str7), v_t_2427}), v_p_243));
              {
                V v_field_2430 = v_t_2428.f[1];
                int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                V v_t_2439;
                if ((v_tag_2425 == ((int64_t)0ULL))) {
                  V v_it1_2432 = v_field_2426;
                  switch (heff_tag_of(v_it1_2432)) {
                  case TAG_JNull: {
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str8);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str9);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str10);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str11);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2436 = heff_field(v_it1_2432, 0);
                    heff_take_n(v_it1_2432, 1ULL, 1);
                    v_t_2439 = v_s_2436;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str12);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str13);
                    break;
                  }
                  default: heff_nomatch(v_it1_2432);
                  }
                } else {
                  heff_drop(v_field_2426);
                  v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str14);
                }
                V v_t_2448;
                if ((v_tag_2429 == ((int64_t)0ULL))) {
                  V v_it1_2441 = v_field_2430;
                  switch (heff_tag_of(v_it1_2441)) {
                  case TAG_JNull: {
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str15);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str16);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str17);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str18);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2445 = heff_field(v_it1_2441, 0);
                    heff_take_n(v_it1_2441, 1ULL, 1);
                    v_t_2448 = v_s_2445;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str19);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str20);
                    break;
                  }
                  default: heff_nomatch(v_it1_2441);
                  }
                } else {
                  heff_drop(v_field_2430);
                  v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str21);
                }
                v_t_2449 = heff_rec_n(2, shape_uri__text, (V[]){v_t_2439, v_t_2448});
              }
            }
            V v_d_2450 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_st_241, 0), heff_dup(v_f_2421), v_t_2449));
            V v_t_2451 = ({ V rv_0 = v_d_2450; V rr_ = heff_rec_reuse_nf(v_st_241, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2452 = (g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201(v_wire_240, v_t_2451, v_f_2421));
            V f_ = v_t_2452;
            heff_room[0] = v_hd_245;
            heff_room[1] = v_k_246;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str22), 2)) {
              heff_drop(v_m_242);
              HeffT2 v_t_2454 = (g_heff_2elsp_2elsp_2elastChange_24cpr(v_p_243));
              {
                V v_field_2456 = v_t_2454.f[1];
                int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                if ((v_tag_2455 == ((int64_t)0ULL))) {
                  V v_text_2458 = v_field_2456;
                  V v_t_2460 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam3_clo)})}));
                  return (g_co_2eop_24s495635622x733177935(v_t_2460, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam4, 1, 4, (V[]){v_st_241, v_f_2421, v_text_2458, v_k_246})));
                } else {
                  heff_drop(v_wire_240);
                  heff_drop(v_hd_245);
                  heff_drop(v_f_2421);
                  heff_drop(v_field_2456);
                  V f_ = v_k_246;
                  args[0] = v_st_241;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            } else {
              heff_drop(v_p_243);
              if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str23), 2)) {
                heff_drop(v_m_242);
                V v_t_2466 = (g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201(v_wire_240, v_st_241, v_f_2421));
                V f_ = v_t_2466;
                heff_room[0] = v_hd_245;
                heff_room[1] = v_k_246;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_str24))) {
                  HeffT2 v_t_2468 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_241, 0), v_f_2421));
                  V v_c_2475;
                  {
                    V v_field_2470 = v_t_2468.f[1];
                    int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                    if ((v_tag_2469 == ((int64_t)0ULL))) {
                      V v_d_2472 = v_field_2470;
                      v_c_2475 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515(v_wire_240, heff_get_n(v_d_2472, 0, 2), NTAG(TAG_Nil)));
                    } else {
                      heff_drop(v_wire_240);
                      heff_drop(v_field_2470);
                      v_c_2475 = ((V)&g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam5_clo);
                    }
                  }
                  V f_ = v_c_2475;
                  heff_room[0] = v_hd_245;
                  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam6, 1, 3, (V[]){v_st_241, v_f_2421, v_k_246});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  heff_drop(v_wire_240);
                  heff_drop(v_hd_245);
                  heff_drop(v_f_2421);
                  V f_ = v_k_246;
                  args[0] = v_st_241;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_247);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_lam1, 1, 6, (V[]){v_m_242, v_st_241, v_wire_240, v_hd_245, v_k_246, v_p_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_entry, 3, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2410, 0, 5), v_x_2412));
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam3, 1, 2, (V[]){v_x_2410, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam4, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_entry, 6, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212(V v_wire_240, V v_st_241, V v_root_242, V v_f_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_247 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){heff_dup(v_root_242), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam0_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_247, heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam1, 1, 5, (V[]){v_f_243, v_st_241, v_z_244, v_root_242, v_z_245})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam0(V self, V *args) {
  V v_fs_246 = args[0];
  return v_fs_246;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_d_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2417, 1, 2)});
  V f_ = v_k_2419;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam4(V self, V *args) {
  V v_t_2423 = args[0];
  return v_t_2423;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam2(V self, V *args) {
  V v_p_2412 = args[0];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2413 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      heff_drop(v_p_2412);
      V v_d_2417 = v_field_2415;
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam3, 2, 1, (V[]){v_d_2417});
    } else {
      heff_drop(v_field_2415);
      V v_path_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_2412; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
      V v_a_2424 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2422, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam4_clo)});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
      V f_ = ((V)&g_co_2eop_24s22628809x1035315751_clo);
      args[0] = v_t_2430;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_root_242 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_sources_2433 = (g_heff_2elsp_2elsp_2enubSources(v_x_2432));
  V v_x_2434 = (g_list_2efoldl_24s1907762870x769133410(NTAG(TAG_Nil), v_sources_2433));
  V v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_root__program, (V[]){v_root_242, heff_dup(v_x_2434)})});
  V v_t_2436 = ({ V rv_3 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_st_241, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V f_ = v_z_245;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_t_2436, v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_root_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_243, NTAG(TAG_Nil)});
  V v_files_2410 = (g_prelude_2e_2b_2b(v_x_248, v_t_249));
  V v_t_2411 = (g_heff_2elsp_2elsp_2enubPaths(v_files_2410));
  V v_c_2431 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam2, 1, 1, (V[]){heff_dup(v_st_241)}); V a_1 = heff_dup(heff_rfield(v_st_241, 6)); V a_2 = v_t_2411; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V f_ = v_c_2431;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_lam5, 1, 3, (V[]){v_root_242, v_st_241, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_entry, 4, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595(V v_wire_240, V v_st_241, V v_c_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    heff_drop(v_c_242);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_c_248 = (g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733(heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_c_242), v_y_246));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam1, 2, 5, (V[]){v_c_248, v_wire_240, v_st_241, v_c_242, v_rest_247});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2412 = (g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595(v_wire_240, v_st_241, v_c_242, v_rest_247));
  V f_ = v_c_2412;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam3, 1, 2, (V[]){v_k_2410, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_lam2, 1, 6, (V[]){v_wire_240, v_st_241, v_c_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam1, 1, 0};
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_entry, 3, 0};

V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472(V v_wire_240, V v_st_241, V v_o_242) {
top: ;
  V v_p_243 = heff_dup(heff_rfield(v_o_242, 0));
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2413;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_wire_240);
      heff_drop(v_p_243);
      V v_d_248 = v_field_246;
      v_c_2413 = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam0, 2, 1, (V[]){v_d_248});
    } else {
      heff_drop(v_field_246);
      V v_t_2412 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_243, ((V)&g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam1_clo)})}));
      v_c_2413 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2412}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam2, 2, 2, (V[]){v_c_2413, v_o_242});
}
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_get_n(v_d_248, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  return v_u_2411;
}
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2416})});
  V v_t_2418 = ({ V b_0 = heff_take_field(v_o_242, 1); V a_1 = heff_get_n(v_o_242, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_str1), v_t_2418}), NTAG(TAG_Nil)});
  V v_x_2420 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2419})});
  V f_ = v_k_2415;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_o_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_lam3, 1, 2, (V[]){v_o_242, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_str0, 0, "");
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam8, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_entry, 4, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032(V v_wire_240, V v_st_241, V v_t_242, V v_new_243) {
top: ;
  V v_c_244 = (g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(v_wire_240, heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 0))));
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam0, 2, 4, (V[]){v_c_244, v_t_242, v_new_243, v_st_241});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam2(V self, V *args) {
  V v_p_2411 = args[0];
  V v_os_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2412 = (g_list_2efilter_24s999680916x306845608(v_p_2411, v_os_248));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2411, v_os_2412});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam4(V self, V *args) {
  V v_p_2421 = args[0];
  V v_os_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2422 = (g_list_2efilter_24s999680916x306845608(v_p_2421, v_os_2418));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2421, v_os_2422});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam5(V self, V *args) {
  V v_b_2424 = args[0];
  V v_new_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2425 = heff_take_field(v_b_2424, 1);
  V v_t_2428;
  switch (heff_tag_of(v_os_2425)) {
  case TAG_Nil: {
    v_t_2428 = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2426 = heff_dup(heff_field(v_os_2425, 0));
    v_t_2428 = heff_get_n(v_x_2426, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_2425);
  }
  V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_2425));
  V v_t_2430 = ({ V b_0 = MK_INT(0LL); V a_1 = v_new_243; V a_2 = v_t_2428; V a_3 = v_t_2429; V r_ = (g_list_2efoldl_24s2051016282x1892781518(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2429); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_b_2424, 0, 2), v_t_2430});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam6(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_q_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V v_t_2441;
  switch (heff_tag_of(v_q_2436)) {
  case TAG_MkPair: {
    V v_y_2440 = heff_field(v_q_2436, 1);
    heff_take_n(v_q_2436, 2ULL, 2);
    v_t_2441 = v_y_2440;
    break;
  }
  default: heff_nomatch(v_q_2436);
  }
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam7(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_d_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2447);
  V v_t_2449 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2446, 1, 2)});
  V f_ = v_k_2448;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam8(V self, V *args) {
  V v_t_2452 = args[0];
  return v_t_2452;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam3(V self, V *args) {
  V v_p_2417 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_new_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2418 = heff_get_n(v_t_242, 3, 4);
  V v_t_2419 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2418)));
  V v_t_2420 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2419));
  V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam4, 1, 1, (V[]){v_os_2418}), v_t_2420));
  V v_texts_2431 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam5, 1, 1, (V[]){v_new_243}), v_t_2423));
  HeffT2 v_t_2432 = (g_list_2efind_24s465947678x1101118081_24cpr(v_p_2417, v_texts_2431));
  {
    V v_field_2434 = v_t_2432.f[1];
    int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
    if ((v_tag_2433 == ((int64_t)0ULL))) {
      heff_drop(v_p_2417);
      heff_drop_rec(v_st_241, 7);
      V v_q_2436 = v_field_2434;
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam6, 2, 1, (V[]){v_q_2436});
    } else {
      heff_drop(v_field_2434);
      HeffT2 v_t_2442 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_2417; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2444 = v_t_2442.f[1];
        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
        if ((v_tag_2443 == ((int64_t)0ULL))) {
          heff_drop(v_p_2417);
          V v_d_2446 = v_field_2444;
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam7, 2, 1, (V[]){v_d_2446});
        } else {
          heff_drop(v_field_2444);
          V v_path_2450 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_2417; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_2451 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2450; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2450); r_; });
          V v_a_2453 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2451, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam8_clo)});
          V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2453})});
          V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
          V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
          V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
          V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
          V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
          V f_ = ((V)&g_co_2eop_24s22628809x1035315751_clo);
          args[0] = v_t_2459;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam10(V self, V *args) {
  V v_c_2464 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2464, 1, 14)}));
  return ({ V a_0 = v_t_2465; V a_1 = v_x_2415; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2415); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam11(V self, V *args) {
  V v_c_2469 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2469, 1, 14)}));
  return ({ V a_0 = v_t_2470; V a_1 = v_x_2415; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2415); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam9(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_new_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_sources_2462 = (g_heff_2elsp_2elsp_2enubSources(v_x_2461));
  V v_x_2463 = (g_list_2efoldl_24s1907762870x769133410(NTAG(TAG_Nil), v_sources_2462));
  V v_program_2466 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam10, 1, 1, (V[]){heff_dup(v_x_2415)}), heff_dup(heff_rfield(v_x_247, 1))));
  V v_t_2467 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2466));
  V v_t_2468 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2467; V r_ = (g_list_2efoldl_24s148011877x1447840770(a_0, a_1, a_2, a_3)); heff_drop(v_t_2467); r_; });
  V v_program_2471 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam11, 1, 1, (V[]){v_x_2415}), heff_dup(v_x_2463)));
  V v_t_2472 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2471));
  V v_t_2473 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2472; V r_ = (g_list_2efoldl_24s148011877x1447840770(a_0, a_1, a_2, a_3)); heff_drop(v_t_2472); r_; });
  V v_x_2474 = (g_heff_2elsp_2elsp_2erenameVerdict(v_x_247, v_t_242, v_new_243, v_t_2468, v_t_2473, v_x_2463));
  V f_ = v_k_246;
  args[0] = v_x_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_new_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_os_248 = heff_dup(heff_rfield(v_t_242, 3));
  V v_t_249 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_248)));
  V v_t_2410 = (g_heff_2elsp_2elsp_2enubPaths(v_t_249));
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam2, 1, 1, (V[]){v_os_248}), v_t_2410));
  V v_t_2414 = (g_list_2emap_24s582709368x2113456071(v_t_2413));
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_247, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2elsp_2elsp_2enubPaths(heff_dup(v_x_2415)));
  V v_c_2460 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam3, 1, 3, (V[]){heff_dup(v_t_242), heff_dup(v_new_243), heff_dup(v_st_241)}); V a_1 = heff_get_n(v_st_241, 6, 7); V a_2 = v_t_2416; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1836091002x1154159740(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  V f_ = v_c_2460;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam9, 1, 5, (V[]){v_x_2415, v_x_247, v_t_242, v_new_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_new_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_lam1, 1, 5, (V[]){v_t_242, v_new_243, v_st_241, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_str0, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_str1, 5, "range");
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam0, 2, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_entry, 4, 0};

V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542(V v_wire_240, V v_st_241, V v_new_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_new_242);
    return ((V)&g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_p_248 = heff_dup(heff_rfield(v_b_246, 0));
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_241, 0), v_p_248));
    V v_c_2418;
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        heff_drop(v_p_248);
        V v_d_2413 = v_field_2411;
        v_c_2418 = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam1, 2, 1, (V[]){v_d_2413});
      } else {
        heff_drop(v_field_2411);
        V v_t_2417 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_248, ((V)&g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam2_clo)})}));
        v_c_2418 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2417}));
      }
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam3, 2, 6, (V[]){v_c_2418, v_wire_240, v_st_241, v_new_242, v_rest_247, v_b_246});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_get_n(v_d_2413, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam2(V self, V *args) {
  V v_u_2416 = args[0];
  return v_u_2416;
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam6(V self, V *args) {
  V v_o_2424 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = ({ V b_0 = heff_take_field(v_o_2424, 1); V a_1 = heff_get_n(v_o_2424, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_str0), heff_tag_n(TAG_JString, 1, (V[]){v_new_242})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_str1), v_t_2425}), v_t_2427});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428});
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_new_242 = heff_env(self)[0];
  V v_b_246 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam6, 1, 1, (V[]){v_new_242}), heff_get_n(v_b_246, 1, 2)));
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2421, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2429})});
  V v_x_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_x_2423});
  V f_ = v_k_2420;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2419 = heff_env(self)[4];
  V v_b_246 = heff_env(self)[5];
  V v_k_2420 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2422 = (g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542(v_wire_240, v_st_241, heff_dup(v_new_242), v_rest_247));
  V f_ = v_c_2422;
  heff_room[0] = v_hd_2419;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam5, 1, 4, (V[]){v_new_242, v_b_246, v_x_2421, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_b_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_lam4, 1, 7, (V[]){v_wire_240, v_st_241, v_new_242, v_rest_247, v_hd_2419, v_b_246, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str7, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str8, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str9, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str10, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str11, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str12, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str13, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str15, 2, "id");
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_entry, 7, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178(V v_wire_240, V v_st_241, V v_id_242, V v_d_243, V v_fix_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_244, heff_dup(heff_rfield(v_d_243, 1))));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_243, 2);
      V v_x_2411 = v_field_249;
      heff_drop(v_x_2411);
      V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str1)})});
      V v_t_2413 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str2), v_t_2413}), NTAG(TAG_Nil)});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str3), v_id_242}), v_t_2414});
      V v_t_2416 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415})});
      V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2416, 1); r_; });
      V v_t_2418 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2418}));
      return (g_co_2eop_24s495635622x733177935(v_t_2419, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam0, 1, 2, (V[]){v_z_246, v_st_241})));
    } else {
      V v_t_2421 = v_field_249;
      if (heff_strEq_c(heff_dup(v_t_2421), heff_dup(heff_rfield(v_d_243, 1)))) {
        heff_drop_rec(v_d_243, 2);
        heff_drop(v_t_2421);
        V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str5)})});
        V v_t_2424 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
        V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str6), v_t_2424}), NTAG(TAG_Nil)});
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str7), v_id_242}), v_t_2425});
        V v_t_2427 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2426})});
        V v_t_2428 = ({ V a_0 = v_t_2427; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2427, 1); r_; });
        V v_t_2429 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
        V v_t_2430 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2429}));
        return (g_co_2eop_24s495635622x733177935(v_t_2430, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam1, 1, 2, (V[]){v_z_246, v_st_241})));
      } else {
        V v_src_2432 = heff_dup(heff_rfield(v_d_243, 1));
        V v_t_2433 = heff_strLength(heff_get_n(v_d_243, 1, 2));
        V v_t_2434 = (g_heff_2elsp_2elsp_2eposition(v_src_2432, MK_INT(0LL)));
        V v_t_2436;
        if ((((int64_t)0ULL) <= heff_peek_word(v_t_2433))) {
          v_t_2436 = v_t_2433;
        } else {
          heff_drop(v_t_2433);
          v_t_2436 = MK_INT(0LL);
        }
        V v_t_2437 = ({ V a_0 = v_src_2432; V a_1 = v_t_2436; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_2432); r_; });
        V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str8), v_t_2437}), NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str9), v_t_2434}), v_t_2438});
        V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2439})});
        V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str11), heff_tag_n(TAG_JString, 1, (V[]){v_t_2421})});
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
        V v_t_2443 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2442})});
        V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
        V v_result_2445 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2444});
        V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str12), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str13)})});
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str14), v_result_2445}), NTAG(TAG_Nil)});
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_str15), v_id_242}), v_t_2447});
        V v_t_2449 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2448})});
        V v_t_2450 = ({ V a_0 = v_t_2449; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2449, 1); r_; });
        V v_t_2451 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2450, NTAG(TAG_MkUnit)});
        V v_t_2452 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2451}));
        return (g_co_2eop_24s495635622x733177935(v_t_2452, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam2, 1, 2, (V[]){v_z_246, v_st_241})));
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_lam2(V self, V *args) {
  V v_x_2453 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_str0, 1, " ");
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189(V v_st_240, V v_f_241, V v_program_242, V v_c_243, V v_s_244) {
top: ;
  V v_c_2432 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568(heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam0, 1, 4, (V[]){heff_dup(v_f_241), v_c_243, heff_dup(v_s_244), heff_dup(v_st_240)}), heff_get_n(v_st_240, 6, 7), v_f_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam4, 2, 3, (V[]){v_c_2432, v_program_242, v_s_244});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V v_src_249 = heff_get_n(v_c_243, 3, 14);
  V v_t_2410 = heff_strSlice(heff_dup(v_src_249), MK_INT(0LL), heff_take_field(v_s_244, 3));
  V v_t_2411 = heff_strSlice(heff_dup(v_src_249), heff_take_field(v_s_244, 4), heff_strLength(v_src_249));
  V v_t_2412 = heff_strAppend(heff_get_n(v_s_244, 0, 5), v_t_2411);
  V v_t_2413 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_str0), v_t_2412));
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_d_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2418, 1, 2)});
  V f_ = v_k_2420;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam3(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_q_245, v_f_241, 2)) {
    heff_drop(v_q_245);
    heff_drop_rec(v_st_240, 7);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam1, 2, 2, (V[]){v_c_243, v_s_244});
  } else {
    heff_drop_rec(v_c_243, 14);
    heff_drop_rec(v_s_244, 5);
    HeffT2 v_t_2414 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_q_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_q_245);
        V v_d_2418 = v_field_2416;
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam2, 2, 1, (V[]){v_d_2418});
      } else {
        heff_drop(v_field_2416);
        V v_path_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_q_245; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
        V v_a_2425 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2423, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam3_clo)});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
        V f_ = ((V)&g_co_2eop_24s22628809x1035315751_clo);
        args[0] = v_t_2431;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_program_242 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_k_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_2435, 0, 5)));
  V v_x_2444;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nil: {
    heff_drop(v_program_242);
    heff_drop_rec(v_s_244, 5);
    v_x_2444 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 2);
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_242));
    V v_xs_2440 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2439; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2439); r_; });
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2440));
    V v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_x_2437; V b_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabNext(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2443 = heff_intAdd(heff_take_field(v_s_244, 3), MK_INT(1LL));
    v_x_2444 = ({ V a_0 = v_t_2442; V b_1 = heff_get_n(v_s_244, 0, 5); V a_2 = v_t_2443; V r_ = (g_heff_2elsp_2esplit_2etypeUsedAt(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  V f_ = v_k_2434;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_program_242 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2432;
  args[0] = v_hd_2433;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189_lam5, 1, 3, (V[]){v_program_242, v_s_244, v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_entry, 8, 0};

V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246(V v_st_240, V v_f_241, V v_uri_242, V v_program_243, V v_c_244, V v_off_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam0, 1, 2, (V[]){heff_dup(v_c_244), v_off_245}), heff_dup(heff_rfield(v_c_244, 4))));
  HeffT2 v_t_2410 = (g_heff_2elsp_2esplit_2efirstJust_24cpr(v_t_249));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_s_2414 = v_field_2412;
      HeffT2 v_t_2415 = (g_heff_2elsp_2esplit_2eusedType_24cpr(heff_dup(v_c_244), heff_dup(v_s_2414)));
      V v_c_2422;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          heff_drop(v_st_240);
          heff_drop(v_f_241);
          V v_t_2419 = v_field_2417;
          v_c_2422 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam1, 2, 1, (V[]){v_t_2419});
        } else {
          heff_drop(v_field_2417);
          v_c_2422 = (g_heff_2elsp_2elsp_2eprobedType_24s1224382647x674786189(v_st_240, v_f_241, heff_dup(v_program_243), heff_dup(v_c_244), heff_dup(v_s_2414)));
        }
      }
      return heff_tail(v_c_2422, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam2, 1, 5, (V[]){v_program_243, v_c_244, v_s_2414, v_uri_242, v_z_247})});
    } else {
      heff_drop(v_st_240);
      heff_drop(v_f_241);
      heff_drop(v_uri_242);
      heff_drop(v_program_243);
      heff_drop_rec(v_c_244, 14);
      heff_drop(v_z_246);
      heff_drop(v_field_2412);
      return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_off_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = heff_get_n(v_c_244, 3, 14); V a_1 = v_off_245; V a_2 = v_d_248; V r_ = (g_heff_2elsp_2esplit_2espotInDecl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_program_243 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_s_2414 = heff_env(self)[2];
  V v_uri_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2431;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop(v_program_243);
    heff_drop_rec(v_c_244, 14);
    heff_drop(v_s_2414);
    heff_drop(v_uri_242);
    v_x_2431 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_t_2424 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    HeffT2 v_t_2425 = ({ V a_0 = v_program_243; V a_1 = heff_dup(v_c_244); V a_2 = v_s_2414; V a_3 = v_t_2424; HeffT2 r_ = (g_heff_2elsp_2esplit_2esplit_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2424); r_; });
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_x_2429 = v_field_2427;
        V v_t_2430 = ({ V a_0 = v_uri_242; V b_1 = heff_get_n(v_c_244, 3, 14); V a_2 = v_x_2429; V r_ = (g_heff_2elsp_2elsp_2esplitAction(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        v_x_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      } else {
        heff_drop_rec(v_c_244, 14);
        heff_drop(v_uri_242);
        heff_drop(v_field_2427);
        v_x_2431 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_z_247;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str2, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str3, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str4, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str5, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str6, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str7, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str8, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str9, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str10, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str11, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str12, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str13, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str14, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str15, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str16, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str17, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str18, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str19, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str20, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str21, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str22, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str23, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str24, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str25, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str26, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str27, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str28, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str30, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str31, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str32, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str34, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str35, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str36, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str37, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str39, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str40, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str41, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str42, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str43, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str44, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str45, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str46, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str47, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str48, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str49, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str50, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str51, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str52, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str54, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str55, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str56, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str57, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str58, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str59, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str60, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str61, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str62, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str63, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str64, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str65, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str66, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str67, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str68, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str69, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str70, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str71, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str72, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str73, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str74, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str75, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str76, 23, "textDocument/codeAction");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str77, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str78, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str79, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str80, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str81, 15, "heff/moduleName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str82, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str83, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str84, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str85, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str86, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam10, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam33(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam32(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam35(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam34(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam40(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam39(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam38(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam37(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam36(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam43(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam42(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam41(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam45(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam44(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_entry, 5, 0};

V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881(V v_wire_240, V v_st_241, V v_m_242, V v_id_243, V v_p_244) {
top: ;
  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str0), 2)) {
    heff_drop(v_m_242);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str2)})});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str3), heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get())}), NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str4), v_id_243}), v_t_247});
    V v_t_249 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})});
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_249, 1); r_; });
    V v_t_2411 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2411}));
    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam0, 2, 3, (V[]){v_t_2412, v_p_244, v_st_241});
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str9), 2)) {
      heff_drop(v_m_242);
      heff_drop(v_p_244);
      V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str11)})});
      V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str12), NTAG(TAG_JNull)});
      V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str13), v_id_243}), v_t_2434});
      V v_t_2436 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2435})});
      V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2436, 1); r_; });
      V v_t_2438 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
      V v_t_2439 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2438}));
      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam2, 2, 2, (V[]){v_t_2439, v_st_241});
    } else {
      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str14), 2)) {
        heff_drop(v_m_242);
        V v_c_2445 = (g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
        return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam4, 2, 4, (V[]){v_c_2445, v_p_244, v_id_243, v_wire_240});
      } else {
        if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str19), 2)) {
          heff_drop(v_m_242);
          V v_c_2459 = (g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
          return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam7, 2, 4, (V[]){v_c_2459, v_p_244, v_wire_240, v_id_243});
        } else {
          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str30), 2)) {
            heff_drop(v_m_242);
            V v_c_24106 = (g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
            return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam14, 2, 4, (V[]){v_c_24106, v_p_244, v_id_243, v_wire_240});
          } else {
            if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str35), 2)) {
              heff_drop(v_m_242);
              V v_c_24126 = (g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(heff_dup(v_wire_240), v_st_241, v_p_244));
              return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam17, 2, 3, (V[]){v_c_24126, v_id_243, v_wire_240});
            } else {
              if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str40), 2)) {
                heff_drop(v_m_242);
                V v_t_24146 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 0), NTAG(TAG_Nil)));
                V v_t_24147 = (g_list_2emap_24s1415906091x1371825187(v_t_24146));
                V v_c_24148 = (g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164(heff_dup(v_st_241), v_t_24147));
                return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam21, 2, 5, (V[]){v_c_24148, v_wire_240, v_st_241, v_p_244, v_id_243});
              } else {
                if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str54), 2)) {
                  heff_drop(v_m_242);
                  V v_c_24182 = (g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
                  return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam26, 2, 4, (V[]){v_c_24182, v_id_243, v_wire_240, v_p_244});
                } else {
                  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str65), 2)) {
                    heff_drop(v_m_242);
                    V v_c_24226 = (g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291(heff_dup(v_wire_240), v_st_241, v_p_244));
                    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam32, 2, 3, (V[]){v_c_24226, v_wire_240, v_id_243});
                  } else {
                    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str66), 2)) {
                      heff_drop(v_m_242);
                      V v_c_24231 = (g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
                      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam34, 2, 4, (V[]){v_c_24231, v_p_244, v_wire_240, v_id_243});
                    } else {
                      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str75), 2)) {
                        heff_drop(v_m_242);
                        return (g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857(v_wire_240, v_st_241, v_id_243, v_p_244));
                      } else {
                        if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str76), 2)) {
                          heff_drop(v_m_242);
                          V v_c_24250 = (g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
                          return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam36, 2, 4, (V[]){v_c_24250, v_wire_240, v_p_244, v_id_243});
                        } else {
                          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str81), 2)) {
                            heff_drop(v_m_242);
                            V v_c_24269 = (g_heff_2elsp_2elsp_2emoduleNamed_24s222433081x601315597(heff_dup(v_wire_240), heff_dup(v_st_241), v_p_244));
                            return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam41, 2, 4, (V[]){v_c_24269, v_id_243, v_wire_240, v_st_241});
                          } else {
                            heff_drop(v_p_244);
                            V v_c_24281 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(v_wire_240, v_id_243, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str86), v_m_242)));
                            return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam44, 2, 2, (V[]){v_c_24281, v_st_241});
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str5), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str7), v_t_2416})});
  HeffT2 v_t_2418 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str8), v_t_2417}), v_p_244));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    V v_t_2429;
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_it1_2422 = v_field_2420;
      switch (heff_tag_of(v_it1_2422)) {
      case TAG_JNull: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_2423 = heff_field(v_it1_2422, 0);
        heff_take_n(v_it1_2422, 1ULL, 1);
        v_t_2429 = v_b_2423;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2422);
      }
    } else {
      heff_drop(v_field_2420);
      v_t_2429 = NTAG(TAG_False);
    }
    V v_t_2430 = ({ V rv_4 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_st_241, 111ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V f_ = v_k_2414;
    args[0] = v_t_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s495635622x733177935(v_t_2412, v_hd_2413, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam1, 1, 3, (V[]){v_p_244, v_st_241, v_k_2414})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam3(V self, V *args) {
  V v_x_2442 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2442);
  V v_t_2443 = ({ V rv_5 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_st_241, 95ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 13311u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_k_2441;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam2(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_t_2439 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_2439, v_hd_2440, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam3, 1, 2, (V[]){v_st_241, v_k_2441})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam6(V self, V *args) {
  V v_x_2457 = args[0];
  V v_k_2447 = heff_env(self)[0];
  V v_x_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2457);
  V f_ = v_k_2447;
  args[0] = heff_get_n(v_x_2448, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_2446 = heff_env(self)[3];
  V v_k_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_result_2449 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2448), v_p_244));
  V v_t_2450 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str15), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str16)})});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str17), v_result_2449}), NTAG(TAG_Nil)});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str18), v_id_243}), v_t_2451});
  V v_t_2453 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2452})});
  V v_t_2454 = ({ V a_0 = v_t_2453; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2453, 1); r_; });
  V v_t_2455 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2454, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2455}));
  return (g_co_2eop_24s495635622x733177935(v_t_2456, v_hd_2446, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam6, 1, 2, (V[]){v_k_2447, v_x_2448})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2445;
  args[0] = heff_dup(v_hd_2446);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam5, 1, 5, (V[]){v_p_244, v_id_243, v_wire_240, v_hd_2446, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam9(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  V v_d_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2476);
  V f_ = v_k_2477;
  args[0] = heff_get_n(v_d_2475, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam10(V self, V *args) {
  V v_u_2478 = args[0];
  return v_u_2478;
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam12(V self, V *args) {
  V v_x_2483 = args[0];
  V v_d_2468 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_2481 = heff_env(self)[3];
  V v_k_2482 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2484 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str20), heff_tag_n(TAG_JString, 1, (V[]){v_x_2483})});
  V v_t_2485 = ({ V b_0 = heff_take_field(v_d_2468, 1); V a_1 = heff_get_n(v_d_2468, 2, 3); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str21), v_t_2485}), NTAG(TAG_Nil)});
  V v_result_2487 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str22), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str23)})});
  V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str24), v_result_2487}), NTAG(TAG_Nil)});
  V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str25), v_id_243}), v_t_2489});
  V v_t_2491 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, v_t_2490})});
  V v_t_2492 = ({ V a_0 = v_t_2491; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2491, 1); r_; });
  V v_t_2493 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2492, NTAG(TAG_MkUnit)});
  V v_t_2494 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2493}));
  return (g_co_2eop_24s495635622x733177935(v_t_2494, v_hd_2481, v_k_2482));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam11(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  V v_c_2480 = heff_env(self)[0];
  V v_d_2468 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2480;
  args[0] = heff_dup(v_hd_2481);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam12, 1, 5, (V[]){v_d_2468, v_id_243, v_wire_240, v_hd_2481, v_k_2482});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam13(V self, V *args) {
  V v_x_24104 = args[0];
  V v_k_2461 = heff_env(self)[0];
  V v_x_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24104);
  V f_ = v_k_2461;
  args[0] = heff_get_n(v_x_2462, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam8(V self, V *args) {
  V v_x_2462 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_hd_2460 = heff_env(self)[3];
  V v_k_2461 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2463 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_2462, 1), v_p_244));
  HeffT2 v_t_2464 = (g_heff_2ebuild_2equery_2edefinitionAt_24cpr(heff_dup(heff_rfield(v_x_2462, 2)), v_t_2463));
  V v_c_24103;
  {
    V v_field_2466 = v_t_2464.f[1];
    int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
    if ((v_tag_2465 == ((int64_t)0ULL))) {
      V v_d_2468 = v_field_2466;
      V v_p_2469 = heff_dup(heff_rfield(v_d_2468, 0));
      V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_x_2462, 0)), 0, 7);
      HeffT2 v_t_2471 = ({ V a_0 = v_t_2470; V a_1 = v_p_2469; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2470); r_; });
      V v_c_2480;
      {
        V v_field_2473 = v_t_2471.f[1];
        int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
        if ((v_tag_2472 == ((int64_t)0ULL))) {
          heff_drop(v_p_2469);
          V v_d_2475 = v_field_2473;
          v_c_2480 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam9, 2, 1, (V[]){v_d_2475});
        } else {
          heff_drop(v_field_2473);
          V v_t_2479 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_2469, ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam10_clo)})}));
          v_c_2480 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2479}));
        }
      }
      v_c_24103 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam11, 2, 4, (V[]){v_c_2480, v_d_2468, v_id_243, v_wire_240});
    } else {
      heff_drop(v_field_2466);
      V v_t_2495 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str26), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str27)})});
      V v_t_2496 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str28), NTAG(TAG_JNull)});
      V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2496, NTAG(TAG_Nil)});
      V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str29), v_id_243}), v_t_2497});
      V v_t_2499 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, v_t_2498})});
      V v_t_24100 = ({ V a_0 = v_t_2499; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2499, 1); r_; });
      V v_t_24101 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24100, NTAG(TAG_MkUnit)});
      V v_t_24102 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24101}));
      v_c_24103 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_24102}));
    }
  }
  V f_ = v_c_24103;
  heff_room[0] = v_hd_2460;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam13, 1, 2, (V[]){v_k_2461, v_x_2462});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam7(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_c_2459 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2459;
  args[0] = heff_dup(v_hd_2460);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam8, 1, 5, (V[]){v_p_244, v_wire_240, v_id_243, v_hd_2460, v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam16(V self, V *args) {
  V v_x_24124 = args[0];
  V v_k_24108 = heff_env(self)[0];
  V v_x_24109 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24124);
  V f_ = v_k_24108;
  args[0] = heff_get_n(v_x_24109, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam15(V self, V *args) {
  V v_x_24109 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_24107 = heff_env(self)[3];
  V v_k_24108 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_24110 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24109, 2))));
  V v_t_24115;
  switch (heff_tag_of(v_x1_24110)) {
  case TAG_Nil: {
    heff_drop(v_p_244);
    v_t_24115 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24111 = heff_field(v_x1_24110, 0);
    heff_take_n(v_x1_24110, 1ULL, 2);
    V v_t_24113 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_24109, 1), v_p_244));
    V v_t_24114 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24111, v_t_24113));
    v_t_24115 = (g_list_2emap_24s4199228x1154005405(v_t_24114));
    break;
  }
  default: heff_nomatch(v_x1_24110);
  }
  V v_result_24116 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24115});
  V v_t_24117 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str31), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str32)})});
  V v_t_24118 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str33), v_result_24116}), NTAG(TAG_Nil)});
  V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str34), v_id_243}), v_t_24118});
  V v_t_24120 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_t_24119})});
  V v_t_24121 = ({ V a_0 = v_t_24120; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24120, 1); r_; });
  V v_t_24122 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24121, NTAG(TAG_MkUnit)});
  V v_t_24123 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24122}));
  return (g_co_2eop_24s495635622x733177935(v_t_24123, v_hd_24107, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam16, 1, 2, (V[]){v_k_24108, v_x_24109})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam14(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k_24108 = args[1];
  V v_c_24106 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24106;
  args[0] = heff_dup(v_hd_24107);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam15, 1, 5, (V[]){v_p_244, v_id_243, v_wire_240, v_hd_24107, v_k_24108});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam19(V self, V *args) {
  V v_y_24134 = args[0];
  V v_x_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_x_24129, 1, 3); V a_1 = v_y_24134; V r_ = (g_heff_2elsp_2elsp_2edocSymbol(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam20(V self, V *args) {
  V v_x_24144 = args[0];
  V v_k_24128 = heff_env(self)[0];
  V v_x_24129 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24144);
  V f_ = v_k_24128;
  args[0] = heff_get_n(v_x_24129, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam18(V self, V *args) {
  V v_x_24129 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_24127 = heff_env(self)[2];
  V v_k_24128 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24130 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24129, 2))));
  V v_t_24135;
  switch (heff_tag_of(v_x1_24130)) {
  case TAG_Nil: {
    v_t_24135 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24131 = heff_field(v_x1_24130, 0);
    heff_take_n(v_x1_24130, 1ULL, 2);
    V v_t_24133 = (g_heff_2ebuild_2equery_2esymbols(v_x_24131));
    v_t_24135 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam19, 1, 1, (V[]){heff_dup(v_x_24129)}), v_t_24133));
    break;
  }
  default: heff_nomatch(v_x1_24130);
  }
  V v_result_24136 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24135});
  V v_t_24137 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str36), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str37)})});
  V v_t_24138 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str38), v_result_24136}), NTAG(TAG_Nil)});
  V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str39), v_id_243}), v_t_24138});
  V v_t_24140 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24137, v_t_24139})});
  V v_t_24141 = ({ V a_0 = v_t_24140; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24140, 1); r_; });
  V v_t_24142 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24141, NTAG(TAG_MkUnit)});
  V v_t_24143 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24142}));
  return (g_co_2eop_24s495635622x733177935(v_t_24143, v_hd_24127, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam20, 1, 2, (V[]){v_k_24128, v_x_24129})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam17(V self, V *args) {
  V v_hd_24127 = args[0];
  V v_k_24128 = args[1];
  V v_c_24126 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24126;
  args[0] = heff_dup(v_hd_24127);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam18, 1, 4, (V[]){v_id_243, v_wire_240, v_hd_24127, v_k_24128});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam25(V self, V *args) {
  V v_x_24180 = args[0];
  V v_k_24150 = heff_env(self)[0];
  V v_x_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24180);
  V f_ = v_k_24150;
  args[0] = heff_get_n(v_x_24154, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam24(V self, V *args) {
  V v_x_24171 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_24149 = heff_env(self)[2];
  V v_k_24150 = heff_env(self)[3];
  V v_x_24154 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24172 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str50), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str51)})});
  V v_t_24173 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str52), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24171})});
  V v_t_24174 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24173, NTAG(TAG_Nil)});
  V v_t_24175 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str53), v_id_243}), v_t_24174});
  V v_t_24176 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24172, v_t_24175})});
  V v_t_24177 = ({ V a_0 = v_t_24176; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24176, 1); r_; });
  V v_t_24178 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24177, NTAG(TAG_MkUnit)});
  V v_t_24179 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24178}));
  return (g_co_2eop_24s495635622x733177935(v_t_24179, v_hd_24149, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam25, 1, 2, (V[]){v_k_24150, v_x_24154})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam23(V self, V *args) {
  V v_x_24154 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_24149 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_k_24150 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24155 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str41), NTAG(TAG_Nil)});
  HeffT2 v_t_24156 = (g_json_2eat_24cpr(v_t_24155, v_p_244));
  V v_t_24168;
  {
    V v_field_24158 = v_t_24156.f[1];
    int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
    V v_t_24167;
    if ((v_tag_24157 == ((int64_t)0ULL))) {
      V v_it1_24160 = v_field_24158;
      switch (heff_tag_of(v_it1_24160)) {
      case TAG_JNull: {
        v_t_24167 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str42);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24160, 0ULL, 1);
        v_t_24167 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str43);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24160, 0ULL, 1);
        v_t_24167 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str44);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24160, 0ULL, 1);
        v_t_24167 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str45);
        break;
      }
      case TAG_JString: {
        V v_s_24164 = heff_field(v_it1_24160, 0);
        heff_take_n(v_it1_24160, 1ULL, 1);
        v_t_24167 = v_s_24164;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24160, 0ULL, 1);
        v_t_24167 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str46);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24160, 0ULL, 1);
        v_t_24167 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str47);
        break;
      }
      default: heff_nomatch(v_it1_24160);
      }
    } else {
      heff_drop(v_field_24158);
      v_t_24167 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str48);
    }
    v_t_24168 = ({ V a_0 = v_t_24167; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str49); V r_ = (g_heff_2elsp_2elsp_2elowerGo(a_0, a_1, a_2)); heff_drop(v_t_24167); r_; });
  }
  V v_t_24169 = (g_heff_2elsp_2elsp_2enubCheckedPaths(heff_dup(heff_rfield(v_x_24154, 1))));
  V v_c_24170 = ({ V a_0 = heff_dup(v_wire_240); V a_1 = heff_dup(heff_rfield(v_x_24154, 0)); V a_2 = v_t_24168; V a_3 = v_t_24169; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806(a_0, a_1, a_2, a_3)); heff_drop(v_t_24168); heff_drop(v_t_24169); r_; });
  V f_ = v_c_24170;
  heff_room[0] = heff_dup(v_hd_24149);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam24, 1, 5, (V[]){v_id_243, v_wire_240, v_hd_24149, v_k_24150, v_x_24154});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam22(V self, V *args) {
  V v_x_24151 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_24149 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_k_24150 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24152 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24151));
  V v_c_24153 = ({ V a_0 = heff_dup(v_wire_240); V a_1 = v_st_241; V a_2 = v_t_24152; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128(a_0, a_1, a_2)); heff_drop(v_t_24152); r_; });
  V f_ = v_c_24153;
  heff_room[0] = heff_dup(v_hd_24149);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam23, 1, 5, (V[]){v_p_244, v_wire_240, v_hd_24149, v_id_243, v_k_24150});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam21(V self, V *args) {
  V v_hd_24149 = args[0];
  V v_k_24150 = args[1];
  V v_c_24148 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24148;
  args[0] = heff_dup(v_hd_24149);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam22, 1, 6, (V[]){v_wire_240, v_st_241, v_hd_24149, v_p_244, v_id_243, v_k_24150});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam28(V self, V *args) {
  V v_o_24196 = args[0];
  V v_p_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24197 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str59), NTAG(TAG_Nil)});
  HeffT2 v_t_24198 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str60), v_t_24197}), v_p_244));
  {
    V v_field_24200 = v_t_24198.f[1];
    int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
    if ((v_tag_24199 == ((int64_t)0ULL))) {
      V v_it1_24202 = v_field_24200;
      switch (heff_tag_of(v_it1_24202)) {
      case TAG_JNull: {
        heff_drop_rec(v_o_24196, 4);
        return NTAG(TAG_True);
      }
      case TAG_JBool: {
        V v_b_24203 = heff_field(v_it1_24202, 0);
        heff_take_n(v_it1_24202, 1ULL, 1);
        V v_ret_24bool = heff_bool(((heff_dup(v_b_24203) == NTAG(TAG_True)) || ({ V v_t_24204 = heff_dup(heff_rfield(v_o_24196, 3)); int c_ = !(heff_dup(v_t_24204) == NTAG(TAG_True)); heff_drop(v_t_24204); c_; })));
        heff_drop_rec(v_o_24196, 4);
        heff_drop(v_b_24203);
        return v_ret_24bool;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24202, 0ULL, 1);
        heff_drop_rec(v_o_24196, 4);
        return NTAG(TAG_True);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24202, 0ULL, 1);
        heff_drop_rec(v_o_24196, 4);
        return NTAG(TAG_True);
      }
      case TAG_JString: {
        heff_take_n(v_it1_24202, 0ULL, 1);
        heff_drop_rec(v_o_24196, 4);
        return NTAG(TAG_True);
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24202, 0ULL, 1);
        heff_drop_rec(v_o_24196, 4);
        return NTAG(TAG_True);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24202, 0ULL, 1);
        heff_drop_rec(v_o_24196, 4);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24202);
      }
    } else {
      heff_drop_rec(v_o_24196, 4);
      heff_drop(v_field_24200);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam30(V self, V *args) {
  V v_x_24214 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_24212 = heff_env(self)[2];
  V v_k_24213 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24215 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str61), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str62)})});
  V v_t_24216 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str63), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24214})});
  V v_t_24217 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24216, NTAG(TAG_Nil)});
  V v_t_24218 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str64), v_id_243}), v_t_24217});
  V v_t_24219 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24215, v_t_24218})});
  V v_t_24220 = ({ V a_0 = v_t_24219; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24219, 1); r_; });
  V v_t_24221 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24220, NTAG(TAG_MkUnit)});
  V v_t_24222 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24221}));
  return (g_co_2eop_24s495635622x733177935(v_t_24222, v_hd_24212, v_k_24213));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam29(V self, V *args) {
  V v_hd_24212 = args[0];
  V v_k_24213 = args[1];
  V v_c_24211 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24211;
  args[0] = heff_dup(v_hd_24212);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam30, 1, 4, (V[]){v_id_243, v_wire_240, v_hd_24212, v_k_24213});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam31(V self, V *args) {
  V v_x_24224 = args[0];
  V v_k_24184 = heff_env(self)[0];
  V v_x_24185 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24224);
  V f_ = v_k_24184;
  args[0] = heff_get_n(v_x_24185, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam27(V self, V *args) {
  V v_x_24185 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_hd_24183 = heff_env(self)[3];
  V v_k_24184 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24186 = heff_dup(heff_rfield(v_x_24185, 2));
  V v_c_24223;
  switch (heff_tag_of(v_t_24186)) {
  case TAG_Nothing: {
    heff_drop(v_p_244);
    V v_t_24187 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str55), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str56)})});
    V v_t_24188 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str57), NTAG(TAG_JNull)});
    V v_t_24189 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24188, NTAG(TAG_Nil)});
    V v_t_24190 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str58), v_id_243}), v_t_24189});
    V v_t_24191 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24187, v_t_24190})});
    V v_t_24192 = ({ V a_0 = v_t_24191; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24191, 1); r_; });
    V v_t_24193 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24192, NTAG(TAG_MkUnit)});
    V v_t_24194 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24193}));
    v_c_24223 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_24194}));
    break;
  }
  case TAG_Just: {
    V v_t_24195 = heff_field(v_t_24186, 0);
    heff_take_n(v_t_24186, 1ULL, 1);
    V v_t_24210 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam28, 1, 1, (V[]){v_p_244}), heff_get_n(v_t_24195, 3, 4)));
    V v_c_24211 = (g_heff_2elsp_2elsp_2elocations_24s380836666x674785152(heff_dup(v_wire_240), heff_dup(heff_rfield(v_x_24185, 0)), v_t_24210));
    v_c_24223 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam29, 2, 3, (V[]){v_c_24211, v_id_243, v_wire_240});
    break;
  }
  default: heff_nomatch(v_t_24186);
  }
  V f_ = v_c_24223;
  heff_room[0] = v_hd_24183;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam31, 1, 2, (V[]){v_k_24184, v_x_24185});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam26(V self, V *args) {
  V v_hd_24183 = args[0];
  V v_k_24184 = args[1];
  V v_c_24182 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24182;
  args[0] = heff_dup(v_hd_24183);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam27, 1, 5, (V[]){v_id_243, v_wire_240, v_p_244, v_hd_24183, v_k_24184});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam33(V self, V *args) {
  V v_x_24229 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_hd_24227 = heff_env(self)[2];
  V v_k_24228 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342(v_wire_240, v_id_243, v_x_24229, v_hd_24227, v_k_24228));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam32(V self, V *args) {
  V v_hd_24227 = args[0];
  V v_k_24228 = args[1];
  V v_c_24226 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24226;
  args[0] = heff_dup(v_hd_24227);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam33, 1, 4, (V[]){v_wire_240, v_id_243, v_hd_24227, v_k_24228});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam35(V self, V *args) {
  V v_x_24234 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_hd_24232 = heff_env(self)[3];
  V v_k_24233 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24235 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str67), NTAG(TAG_Nil)});
  HeffT2 v_t_24236 = (g_json_2eat_24cpr(v_t_24235, v_p_244));
  V v_t_24247;
  {
    V v_field_24238 = v_t_24236.f[1];
    int64_t v_tag_24237 = ((int64_t)v_t_24236.f[0]);
    if ((v_tag_24237 == ((int64_t)0ULL))) {
      V v_it1_24240 = v_field_24238;
      switch (heff_tag_of(v_it1_24240)) {
      case TAG_JNull: {
        v_t_24247 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str68);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24240, 0ULL, 1);
        v_t_24247 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str69);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24240, 0ULL, 1);
        v_t_24247 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str70);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24240, 0ULL, 1);
        v_t_24247 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str71);
        break;
      }
      case TAG_JString: {
        V v_s_24244 = heff_field(v_it1_24240, 0);
        heff_take_n(v_it1_24240, 1ULL, 1);
        v_t_24247 = v_s_24244;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24240, 0ULL, 1);
        v_t_24247 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str72);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24240, 0ULL, 1);
        v_t_24247 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str73);
        break;
      }
      default: heff_nomatch(v_it1_24240);
      }
    } else {
      heff_drop(v_field_24238);
      v_t_24247 = ((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str74);
    }
  }
  return (g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992(v_wire_240, v_id_243, v_t_24247, v_x_24234, v_hd_24232, v_k_24233));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam34(V self, V *args) {
  V v_hd_24232 = args[0];
  V v_k_24233 = args[1];
  V v_c_24231 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24231;
  args[0] = heff_dup(v_hd_24232);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam35, 1, 5, (V[]){v_p_244, v_wire_240, v_id_243, v_hd_24232, v_k_24233});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam40(V self, V *args) {
  V v_x_24267 = args[0];
  V v_k_24252 = heff_env(self)[0];
  V v_x_24253 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24267);
  V f_ = v_k_24252;
  args[0] = heff_get_n(v_x_24253, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam39(V self, V *args) {
  V v_x_24257 = args[0];
  V v_x_24255 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_24251 = heff_env(self)[3];
  V v_k_24252 = heff_env(self)[4];
  V v_x_24253 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24258 = (g_prelude_2e_2b_2b(v_x_24257, v_x_24255));
  V v_result_24259 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24258});
  V v_t_24260 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str77), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str78)})});
  V v_t_24261 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str79), v_result_24259}), NTAG(TAG_Nil)});
  V v_t_24262 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str80), v_id_243}), v_t_24261});
  V v_t_24263 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24260, v_t_24262})});
  V v_t_24264 = ({ V a_0 = v_t_24263; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24263, 1); r_; });
  V v_t_24265 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24264, NTAG(TAG_MkUnit)});
  V v_t_24266 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24265}));
  return (g_co_2eop_24s495635622x733177935(v_t_24266, v_hd_24251, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam40, 1, 2, (V[]){v_k_24252, v_x_24253})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam38(V self, V *args) {
  V v_x_24255 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_x_24253 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_hd_24251 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_k_24252 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_24256 = (g_heff_2elsp_2elsp_2eclaimFixes_24s1013363202x963768326(heff_dup(v_wire_240), heff_dup(heff_rfield(v_x_24253, 0)), v_p_244));
  V f_ = v_c_24256;
  heff_room[0] = heff_dup(v_hd_24251);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam39, 1, 6, (V[]){v_x_24255, v_id_243, v_wire_240, v_hd_24251, v_k_24252, v_x_24253});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam37(V self, V *args) {
  V v_x_24253 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_hd_24251 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_k_24252 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24254 = (g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571(heff_dup(v_wire_240), heff_dup(v_x_24253), heff_dup(v_p_244)));
  V f_ = v_c_24254;
  heff_room[0] = heff_dup(v_hd_24251);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam38, 1, 6, (V[]){v_wire_240, v_x_24253, v_p_244, v_hd_24251, v_id_243, v_k_24252});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam36(V self, V *args) {
  V v_hd_24251 = args[0];
  V v_k_24252 = args[1];
  V v_c_24250 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24250;
  args[0] = heff_dup(v_hd_24251);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam37, 1, 5, (V[]){v_wire_240, v_p_244, v_hd_24251, v_id_243, v_k_24252});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam43(V self, V *args) {
  V v_x_24280 = args[0];
  V v_k_24271 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24280);
  V f_ = v_k_24271;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam42(V self, V *args) {
  V v_x_24272 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_24270 = heff_env(self)[2];
  V v_k_24271 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24273 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str82), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str83)})});
  V v_t_24274 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str84), v_x_24272}), NTAG(TAG_Nil)});
  V v_t_24275 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_str85), v_id_243}), v_t_24274});
  V v_t_24276 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24273, v_t_24275})});
  V v_t_24277 = ({ V a_0 = v_t_24276; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24276, 1); r_; });
  V v_t_24278 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24277, NTAG(TAG_MkUnit)});
  V v_t_24279 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24278}));
  return (g_co_2eop_24s495635622x733177935(v_t_24279, v_hd_24270, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam43, 1, 2, (V[]){v_k_24271, v_st_241})));
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam41(V self, V *args) {
  V v_hd_24270 = args[0];
  V v_k_24271 = args[1];
  V v_c_24269 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24269;
  args[0] = heff_dup(v_hd_24270);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam42, 1, 5, (V[]){v_id_243, v_wire_240, v_hd_24270, v_k_24271, v_st_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam45(V self, V *args) {
  V v_x_24284 = args[0];
  V v_k_24283 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24284);
  V f_ = v_k_24283;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam44(V self, V *args) {
  V v_hd_24282 = args[0];
  V v_k_24283 = args[1];
  V v_c_24281 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24281;
  args[0] = v_hd_24282;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_lam45, 1, 2, (V[]){v_k_24283, v_st_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}