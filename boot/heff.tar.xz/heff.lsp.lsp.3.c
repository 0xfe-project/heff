// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_ReadFile 6783
#define TAG_Send 26077
#define LBL_checked 974171621
#define LBL_decls 296817955
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_selection 2055983820
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_root__program[] = {LBL_root, LBL_program};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(V);
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V);
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889(V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_clo;
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958(V, V);
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_clo;
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(V, V);
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230(V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2esplit_2etypeUsedAt(V, V, V);
V g_heff_2elsp_2esplit_2etypeUsedAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2etypeUsedAt_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s951260806x709953240(V, V);
V g_list_2efilter_24s951260806x709953240_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_clo;
V g_list_2efilter_24s999680916x306845608(V, V);
V g_list_2efilter_24s999680916x306845608_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_clo;
HeffT2 g_list_2efind_24s1320851393x93733228_24cpr(V, V);
HeffT2 g_list_2efind_24s250366202x1057933814_24cpr(V, V, V);
HeffT2 g_list_2efind_24s465947678x1101118081_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2051016282x1892781518(V, V, V, V);
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2051016282x1892781518_clo;
V g_list_2efoldl_24s209635602x622053613(V, V);
V g_list_2efoldl_24s209635602x622053613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s209635602x622053613_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s513294106x1954328253(V, V, V, V);
V g_list_2efoldl_24s513294106x1954328253_entry(V self, V *a);
extern Clo g_list_2efoldl_24s513294106x1954328253_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f903834997x2034796740(V, V, V);
V g_prelude_2e_2b_2b_24f903834997x2034796740_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f903834997x2034796740_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  V v_t_245 = heff_bool((heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2) || heff_intLe_c_lent(v_e_242, v_i_241, 0)));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_n_243);
    heff_drop(v_t_245);
    if (heff_intLe_c_lent(v_i_241, v_e_242, 0)) {
      heff_drop(v_e_242);
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return v_e_242;
    }
  } else {
    heff_drop(v_t_245);
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      V v_t_248 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_src_240, v_i_241, 0));
      V v_t_249 = heff_runeToInt(heff_strRuneAt_lent(v_src_240, v_i_241, 2));
      V v_t_2411;
      if (heff_intLe_c(MK_INT(65536LL), v_t_249)) {
        v_t_2411 = MK_INT(2LL);
      } else {
        v_t_2411 = MK_INT(1LL);
      }
      V t_0 = v_src_240;
      V t_1 = v_t_248;
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, v_t_2411);
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffset16(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}), heff_dup(v_params_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_246}), v_params_241));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2418;
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_2411 = v_field_245;
        switch (heff_tag_of(v_it1_2411)) {
        case TAG_JNull: {
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2413 = heff_field(v_it1_2411, 0);
          heff_take_n(v_it1_2411, 1ULL, 1);
          v_t_2418 = v_i_2413;
          break;
        }
        case TAG_JFloat: {
          double v_x_2414 = heff_tflat_f64(v_it1_2411, 0);
          heff_take_na(v_it1_2411, 0ULL, 1);
          v_t_2418 = heff_floor_f64(v_x_2414);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2411, 0ULL, 1);
          v_t_2418 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2411);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2418 = MK_INT(0LL);
      }
      V v_t_2427;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_it1_2420 = v_field_249;
        switch (heff_tag_of(v_it1_2420)) {
        case TAG_JNull: {
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2422 = heff_field(v_it1_2420, 0);
          heff_take_n(v_it1_2420, 1ULL, 1);
          v_t_2427 = v_i_2422;
          break;
        }
        case TAG_JFloat: {
          double v_x_2423 = heff_tflat_f64(v_it1_2420, 0);
          heff_take_na(v_it1_2420, 0ULL, 1);
          v_t_2427 = heff_floor_f64(v_x_2423);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2420, 0ULL, 1);
          v_t_2427 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2420);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2427 = MK_INT(0LL);
      }
      return (g_heff_2elsp_2elsp_2eoffsetGo(v_src_240, v_t_2418, v_t_2427, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetIn(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str1, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 15, "codeActionKinds");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 18, "codeActionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str20, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str21, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str22, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10)}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str20)})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str21), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str22), v_t_2423}), v_t_2427});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
Clo g_heff_2elsp_2elsp_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2etargetIn_entry, 5, 0};

V g_heff_2elsp_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244) {
top: ;
  HeffT2 v_t_245 = (g_list_2efind_24s1320851393x93733228_24cpr(v_f_241, heff_dup(v_program_244)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_247;
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_249, 3)), heff_dup(heff_rfield(v_d_242, 1)))) {
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_249, NTAG(TAG_Nil)});
        V v_program_2412 = (g_prelude_2e_2b_2b_24f903834997x2034796740(v_t_2411, v_f_241, heff_dup(v_program_244)));
        V v_off_2413 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_d_242, 1), heff_dup(v_p_243)));
        V v_x1_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_2412)));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nil: {
          heff_drop(v_f_241);
          heff_drop_rec(v_d_242, 2);
          heff_drop(v_p_243);
          heff_drop(v_program_244);
          heff_drop(v_program_2412);
          heff_drop(v_off_2413);
          return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        }
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 2);
          V v_t_2417 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_2415, 4)));
          V v_t_2418 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2417));
          V v_t_2419 = (g_heff_2ebuild_2equery_2etargetIn(v_program_2412, v_x_2415, v_t_2418, v_off_2413));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_Nothing: {
            heff_drop(v_f_241);
            heff_drop_rec(v_d_242, 2);
            heff_drop(v_p_243);
            heff_drop(v_program_244);
            return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
          }
          case TAG_Just: {
            V v_t_2420 = heff_field(v_t_2419, 0);
            V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 1ULL, 1);
            V v_off_2421 = ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(b_0, a_1)); heff_drop(b_0); r_; });
            V v_occurrences_2422 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_244, heff_dup(heff_rfield(v_t_2420, 0)), heff_rfield(v_t_2420, 1)));
            V v_t_2423 = heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, heff_take_field(v_t_2420, 0), heff_get_n(v_t_2420, 1, 2), v_occurrences_2422});
            V v_target_2424 = heff_tag_at_n(v_ru_24t_2419_24Just, TAG_Just, 1, (V[]){v_t_2423});
            return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, v_off_2421, v_target_2424});
          }
          default: return heff_nomatch(v_t_2419);
          }
        }
        default: return heff_nomatch(v_x1_2414);
        }
      } else {
        heff_drop(v_f_241);
        heff_drop_rec(v_d_242, 2);
        heff_drop(v_p_243);
        heff_drop(v_program_244);
        heff_drop_rec(v_c_249, 13);
        return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      }
    } else {
      heff_drop(v_f_241);
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_p_243);
      heff_drop(v_program_244);
      heff_drop(v_field_247);
      return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    }
  }
}
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2etargetIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_r_241; V a_1 = v_rs_242; V r_ = (g_list_2efilter_24s951260806x709953240(a_0, a_1)); heff_drop(v_r_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubRoots_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_24cpr_str0, 14, "contentChanges");
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_24cpr_str1, 4, "text");

HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_24cpr_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, v_p_240));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      V v_t_2413;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        V v_xs_2411 = heff_field(v_it1_246, 0);
        V v_ru_24it1_246_24JArray = heff_take_reuse_n(v_it1_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24it1_246_24JArray, TAG_Just, 1, (V[]){v_xs_2411});
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_cs_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_x1_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_2414));
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2416 = heff_field(v_x1_2415, 0);
          V v_ru_24x1_2415_24Cons = heff_take_reuse_n(v_x1_2415, 1ULL, 2);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_2415_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_24cpr_str1), NTAG(TAG_Nil)});
          HeffT2 v_t_2419 = (g_json_2eat_24cpr(v_t_2418, v_x_2416));
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_it1_2423 = v_field_2421;
              switch (heff_tag_of(v_it1_2423)) {
              case TAG_JNull: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2423, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2423, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2423, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JString: {
                V v_s_2427 = heff_field(v_it1_2423, 0);
                heff_take_n(v_it1_2423, 1ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_s_2427}});
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2423, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2423, 0ULL, 1);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2423)}});
              }
            } else {
              heff_drop(v_field_2421);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2415)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2413)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam4, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777(V v_st_240, V v_root_241, V v_f_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){heff_dup(v_root_241), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_243), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam1, 1, 5, (V[]){v_f_242, v_st_240, v_hd_243, v_root_241, v_k_244})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam0(V self, V *args) {
  V v_fs_245 = args[0];
  return v_fs_245;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_d_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2419, 1, 2)});
  V f_ = v_k_2421;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam4(V self, V *args) {
  V v_t_2423 = args[0];
  return v_t_2423;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam2(V self, V *args) {
  V v_p_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop(v_p_2414);
      V v_d_2419 = v_field_2417;
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam3, 2, 1, (V[]){v_d_2419});
    } else {
      heff_drop(v_field_2417);
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_2414, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam4_clo)})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V f_ = ((V)&g_co_2eop_24s903439140x919002362_clo);
      args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_t_2428});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_sources_2431 = (g_heff_2elsp_2elsp_2enubSources(v_x_2430));
  V v_x_2432 = (g_list_2efoldl_24s209635602x622053613(NTAG(TAG_Nil), v_sources_2431));
  V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_root__program, (V[]){v_root_241, heff_dup(v_x_2432)})});
  V v_t_2434 = ({ V rv_3 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V f_ = v_k_244;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_t_2434, v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_242, NTAG(TAG_Nil)});
  V v_files_2412 = (g_prelude_2e_2b_2b(v_x_2410, v_t_2411));
  V v_t_2413 = (g_heff_2elsp_2elsp_2enubPaths(v_files_2412));
  V v_c_2429 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam2, 1, 1, (V[]){heff_dup(v_st_240)}); V a_1 = heff_dup(heff_rfield(v_st_240, 6)); V a_2 = v_t_2413; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
  V f_ = v_c_2429;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_lam5, 1, 3, (V[]){v_root_241, v_st_240, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str2, 8, "location");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str3, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str4, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str5, 4, "name");
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam1, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949(V v_st_240, V v_c_241, V v_y_242) {
top: ;
  V v_p_243 = heff_dup(heff_rfield(v_c_241, 1));
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2416;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_p_243);
      V v_d_248 = v_field_246;
      v_c_2416 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam0, 2, 1, (V[]){v_d_248});
    } else {
      heff_drop(v_field_246);
      V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_243, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam1_clo)})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      v_c_2416 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam2, 2, 3, (V[]){v_c_2416, v_y_242, v_c_241});
}
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_get_n(v_d_248, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  return v_u_2411;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_y_242 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_242, 0)});
  V v_t_2421 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_242, 1)});
  V v_t_2422 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_c_241, 0)});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2419})});
  V v_t_2424 = ({ V b_0 = heff_get_n(v_c_241, 3, 13); V a_1 = heff_get_n(v_y_242, 3, 5); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str1), v_t_2424}), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str2), v_t_2426}), NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str3), v_t_2422}), v_t_2427});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str4), v_t_2421}), v_t_2428});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_str5), v_t_2420}), v_t_2429});
  V v_x_2431 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430});
  V f_ = v_k_2418;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_lam3, 1, 3, (V[]){v_y_242, v_c_241, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_p_241});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_f_247 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2415 = (g_heff_2elsp_2elsp_2etargetIn(heff_take_field(v_x_2414, 0), v_f_247, v_d_2412, v_p_241, heff_get_n(v_x_2414, 1, 2)));
  V f_ = v_k_244;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    heff_drop(v_p_241);
    V v_t_246 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_f_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_d_2412 = v_field_2410;
        V v_c_2413 = (g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(v_st_240, heff_dup(v_f_247)));
        V f_ = v_c_2413;
        heff_room[0] = v_hd_243;
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam2, 1, 4, (V[]){v_f_247, v_d_2412, v_p_241, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_hd_243);
        heff_drop(v_p_241);
        heff_drop(v_f_247);
        heff_drop(v_field_2410);
        V v_t_2416 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        V f_ = v_k_244;
        args[0] = v_t_2416;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_lam1, 1, 4, (V[]){v_st_240, v_k_244, v_hd_243, v_p_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889(heff_dup(v_st_240), v_o_244));
    return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam1, 2, 3, (V[]){v_c_246, v_st_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_lam2, 1, 4, (V[]){v_st_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str4, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str6, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str7, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str8, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str10, 21, "` is not written here");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str11, 1, "`");
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_entry, 4, 0};

V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140(V v_id_240, V v_tg_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_tg_241, 2));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str1)})});
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str2), NTAG(TAG_JNull)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str3), v_id_240}), v_t_247});
    V v_t_249 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_248})});
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_249, 1); r_; });
    V v_a_2411 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s94900133x232571340(v_t_2415, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam0, 1, 2, (V[]){v_z_243, v_tg_241})));
  }
  case TAG_Just: {
    V v_t_2417 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    HeffT2 v_t_2418 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2417, 1)), heff_dup(heff_rfield(v_t_2417, 2)), heff_dup(heff_rfield(v_t_2417, 2))));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop_rec(v_t_2417, 4);
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        V v_why_2422 = v_field_2420;
        V v_c_2423 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(v_id_240, MK_INT(-32803LL), v_why_2422));
        return heff_tail(v_c_2423, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam1, 1, 2, (V[]){v_z_243, v_tg_241})});
      } else {
        heff_drop(v_field_2420);
        HeffT2 v_t_2425 = (g_list_2efind_24s250366202x1057933814_24cpr(heff_dup(v_t_2417), heff_dup(heff_rfield(v_tg_241, 1)), heff_dup(heff_rfield(v_t_2417, 3))));
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_o_2429 = v_field_2427;
            V v_t_2430 = ({ V b_0 = heff_take_field(v_o_2429, 1); V a_1 = heff_get_n(v_o_2429, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2431 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2417, 2, 4)});
            V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str4), v_t_2431}), NTAG(TAG_Nil)});
            V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str5), v_t_2430}), v_t_2432});
            V v_result_2434 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2433});
            V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str7)})});
            V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str8), v_result_2434}), NTAG(TAG_Nil)});
            V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str9), v_id_240}), v_t_2436});
            V v_t_2438 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2437})});
            V v_t_2439 = ({ V a_0 = v_t_2438; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2438, 1); r_; });
            V v_a_2440 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2439, NTAG(TAG_MkUnit)});
            V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2440})});
            V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
            V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
            V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
            return (g_co_2eop_24s94900133x232571340(v_t_2444, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam2, 1, 2, (V[]){v_z_243, v_tg_241})));
          } else {
            heff_drop_cell(v_ru_24t_244_24Just, 1);
            heff_drop(v_field_2427);
            V v_t_2446 = heff_strAppend(heff_get_n(v_t_2417, 2, 4), ((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str10));
            V v_c_2447 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(v_id_240, MK_INT(-32803LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_str11), v_t_2446)));
            return heff_tail(v_c_2447, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam3, 1, 2, (V[]){v_z_243, v_tg_241})});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam2(V self, V *args) {
  V v_x_2445 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_lam3(V self, V *args) {
  V v_x_2448 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_str0, 0, "");
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam8, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_entry, 3, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835(V v_st_240, V v_t_241, V v_new_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam0, 2, 4, (V[]){v_c_243, v_t_241, v_new_242, v_st_240});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  V v_os_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2411 = (g_list_2efilter_24s999680916x306845608(v_p_2410, v_os_247));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2410, v_os_2411});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam4(V self, V *args) {
  V v_p_2420 = args[0];
  V v_os_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2421 = (g_list_2efilter_24s999680916x306845608(v_p_2420, v_os_2417));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2420, v_os_2421});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam5(V self, V *args) {
  V v_b_2423 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2424 = heff_take_field(v_b_2423, 1);
  V v_t_2427;
  switch (heff_tag_of(v_os_2424)) {
  case TAG_Nil: {
    v_t_2427 = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2425 = heff_dup(heff_field(v_os_2424, 0));
    v_t_2427 = heff_get_n(v_x_2425, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_2424);
  }
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_2424));
  V v_t_2429 = ({ V b_0 = MK_INT(0LL); V a_1 = v_new_242; V a_2 = v_t_2427; V a_3 = v_t_2428; V r_ = (g_list_2efoldl_24s2051016282x1892781518(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2428); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_b_2423, 0, 2), v_t_2429});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam6(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_q_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V v_t_2440;
  switch (heff_tag_of(v_q_2435)) {
  case TAG_MkPair: {
    V v_y_2439 = heff_field(v_q_2435, 1);
    heff_take_n(v_q_2435, 2ULL, 2);
    v_t_2440 = v_y_2439;
    break;
  }
  default: heff_nomatch(v_q_2435);
  }
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam7(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_d_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2446);
  V v_t_2448 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2445, 1, 2)});
  V f_ = v_k_2447;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam8(V self, V *args) {
  V v_t_2449 = args[0];
  return v_t_2449;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam3(V self, V *args) {
  V v_p_2416 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2417 = heff_get_n(v_t_241, 3, 4);
  V v_t_2418 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2417)));
  V v_t_2419 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2418));
  V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam4, 1, 1, (V[]){v_os_2417}), v_t_2419));
  V v_texts_2430 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam5, 1, 1, (V[]){v_new_242}), v_t_2422));
  HeffT2 v_t_2431 = (g_list_2efind_24s465947678x1101118081_24cpr(v_p_2416, v_texts_2430));
  {
    V v_field_2433 = v_t_2431.f[1];
    int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
    if ((v_tag_2432 == ((int64_t)0ULL))) {
      heff_drop(v_p_2416);
      heff_drop_rec(v_st_240, 7);
      V v_q_2435 = v_field_2433;
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam6, 2, 1, (V[]){v_q_2435});
    } else {
      heff_drop(v_field_2433);
      HeffT2 v_t_2441 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_2416; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2443 = v_t_2441.f[1];
        int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
        if ((v_tag_2442 == ((int64_t)0ULL))) {
          heff_drop(v_p_2416);
          V v_d_2445 = v_field_2443;
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam7, 2, 1, (V[]){v_d_2445});
        } else {
          heff_drop(v_field_2443);
          V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_2416, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam8_clo)})});
          V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
          V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
          V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
          V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
          V f_ = ((V)&g_co_2eop_24s903439140x919002362_clo);
          args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_t_2454});
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam10(V self, V *args) {
  V v_c_2459 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2459, 1, 13)}));
  return ({ V a_0 = v_t_2460; V a_1 = v_x_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2414); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam11(V self, V *args) {
  V v_c_2464 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2464, 1, 13)}));
  return ({ V a_0 = v_t_2465; V a_1 = v_x_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2414); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_sources_2457 = (g_heff_2elsp_2elsp_2enubSources(v_x_2456));
  V v_x_2458 = (g_list_2efoldl_24s209635602x622053613(NTAG(TAG_Nil), v_sources_2457));
  V v_program_2461 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam10, 1, 1, (V[]){heff_dup(v_x_2414)}), heff_dup(heff_rfield(v_x_246, 1))));
  V v_t_2462 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2461));
  V v_t_2463 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2462; V r_ = (g_list_2efoldl_24s513294106x1954328253(a_0, a_1, a_2, a_3)); heff_drop(v_t_2462); r_; });
  V v_program_2466 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam11, 1, 1, (V[]){v_x_2414}), heff_dup(v_x_2458)));
  V v_t_2467 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2466));
  V v_t_2468 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2467; V r_ = (g_list_2efoldl_24s513294106x1954328253(a_0, a_1, a_2, a_3)); heff_drop(v_t_2467); r_; });
  V v_x_2469 = (g_heff_2elsp_2elsp_2erenameVerdict(v_x_246, v_t_241, v_new_242, v_t_2463, v_t_2468, v_x_2458));
  V f_ = v_k_245;
  args[0] = v_x_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_os_247 = heff_dup(heff_rfield(v_t_241, 3));
  V v_t_248 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_247)));
  V v_t_249 = (g_heff_2elsp_2elsp_2enubPaths(v_t_248));
  V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam2, 1, 1, (V[]){v_os_247}), v_t_249));
  V v_t_2413 = (g_list_2emap_24s582709368x2113456071(v_t_2412));
  V v_x_2414 = ({ V a_0 = v_t_2413; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_246, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
  V v_t_2415 = (g_heff_2elsp_2elsp_2enubPaths(heff_dup(v_x_2414)));
  V v_c_2455 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam3, 1, 3, (V[]){heff_dup(v_t_241), heff_dup(v_new_242), heff_dup(v_st_240)}); V a_1 = heff_get_n(v_st_240, 6, 7); V a_2 = v_t_2415; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
  V f_ = v_c_2455;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam9, 1, 5, (V[]){v_x_2414, v_x_246, v_t_241, v_new_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_lam1, 1, 5, (V[]){v_t_241, v_new_242, v_st_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_str0, 1, " ");
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488(V v_st_240, V v_f_241, V v_program_242, V v_c_243, V v_s_244) {
top: ;
  V v_c_2428 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam0, 1, 4, (V[]){heff_dup(v_f_241), v_c_243, heff_dup(v_s_244), heff_dup(v_st_240)}), heff_get_n(v_st_240, 6, 7), v_f_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam4, 2, 3, (V[]){v_c_2428, v_program_242, v_s_244});
}
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V v_src_249 = heff_get_n(v_c_243, 3, 13);
  V v_t_2410 = heff_strSlice(heff_dup(v_src_249), MK_INT(0LL), heff_take_field(v_s_244, 3));
  V v_t_2411 = heff_strSlice(heff_dup(v_src_249), heff_take_field(v_s_244, 4), heff_strLength(v_src_249));
  V v_t_2412 = heff_strAppend(heff_get_n(v_s_244, 0, 5), v_t_2411);
  V v_t_2413 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_str0), v_t_2412));
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_d_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2418, 1, 2)});
  V f_ = v_k_2420;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam3(V self, V *args) {
  V v_t_2422 = args[0];
  return v_t_2422;
}
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_q_245, v_f_241, 2)) {
    heff_drop(v_q_245);
    heff_drop_rec(v_st_240, 7);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam1, 2, 2, (V[]){v_c_243, v_s_244});
  } else {
    heff_drop_rec(v_c_243, 13);
    heff_drop_rec(v_s_244, 5);
    HeffT2 v_t_2414 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_q_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_q_245);
        V v_d_2418 = v_field_2416;
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam2, 2, 1, (V[]){v_d_2418});
      } else {
        heff_drop(v_field_2416);
        V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_q_245, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam3_clo)})});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V f_ = ((V)&g_co_2eop_24s903439140x919002362_clo);
        args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_t_2427});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_program_242 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_2431, 0, 5)));
  V v_x_2440;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nil: {
    heff_drop(v_program_242);
    heff_drop_rec(v_s_244, 5);
    v_x_2440 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 2);
    V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_242));
    V v_xs_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2435; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2435); r_; });
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2436));
    V v_t_2438 = ({ V a_0 = v_t_2437; V a_1 = v_x_2433; V b_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabNext(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2439 = heff_intAdd(heff_take_field(v_s_244, 3), MK_INT(1LL));
    v_x_2440 = ({ V a_0 = v_t_2438; V b_1 = heff_get_n(v_s_244, 0, 5); V a_2 = v_t_2439; V r_ = (g_heff_2elsp_2esplit_2etypeUsedAt(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V f_ = v_k_2430;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_program_242 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_lam5, 1, 3, (V[]){v_program_242, v_s_244, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}