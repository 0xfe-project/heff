// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_ReadFile 6783
#define TAG_Send 26077
#define LBL_checked 974171621
#define LBL_decls 296817955
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_rune 10007553
#define LBL_selection 2055983820
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
#define LBL_width 314485216
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_root__program[] = {LBL_root, LBL_program};
static uint32_t shape_rune__width[] = {LBL_rune, LBL_width};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2equery_2erenameRefused(V, V, V);
V g_heff_2ebuild_2equery_2erenameRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2erenameRefused_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266(V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558(V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_clo;
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(V);
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(V, V, V);
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_clo;
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_clo;
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(V, V);
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_clo;
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(V, V);
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_clo;
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s203746709x104822352(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s203746709x104822352_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s203746709x104822352_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2eutil_2ejson_2eat(V, V);
V g_heff_2eutil_2ejson_2eat_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eat_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s951260806x709953240(V, V);
V g_list_2efilter_24s951260806x709953240_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_clo;
V g_list_2efilter_24s999680916x306845608(V, V);
V g_list_2efilter_24s999680916x306845608_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_clo;
V g_list_2efind_24s1320851393x93733228(V, V);
V g_list_2efind_24s1320851393x93733228_entry(V self, V *a);
extern Clo g_list_2efind_24s1320851393x93733228_clo;
V g_list_2efind_24s250366202x1057933814(V, V, V);
V g_list_2efind_24s250366202x1057933814_entry(V self, V *a);
extern Clo g_list_2efind_24s250366202x1057933814_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s209635602x622053613(V, V);
V g_list_2efoldl_24s209635602x622053613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s209635602x622053613_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f903834997x2034796740(V, V, V);
V g_prelude_2e_2b_2b_24f903834997x2034796740_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f903834997x2034796740_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  V v_t_245 = heff_bool((heff_intLe_c(heff_dup(v_n_243), MK_INT(0LL)) || heff_intLe_c(heff_dup(v_e_242), heff_dup(v_i_241))));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_src_240);
    heff_drop(v_n_243);
    heff_drop(v_t_245);
    if (heff_intLe_c(heff_dup(v_i_241), heff_dup(v_e_242))) {
      heff_drop(v_e_242);
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return v_e_242;
    }
  } else {
    heff_drop(v_t_245);
    if (heff_intLt_c(heff_strByteAt_lent(v_src_240, v_i_241, 0), MK_INT(128LL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      V v_r_248 = heff_rec_n(2, shape_rune__width, (V[]){heff_strRuneAt_lent(v_src_240, v_i_241, 0), heff_strRuneWidth_lent(v_src_240, v_i_241, 0)});
      V v_t_249 = heff_intAdd(v_i_241, heff_take_field(v_r_248, 1));
      V v_t_2410 = heff_runeToInt(heff_get_n(v_r_248, 0, 2));
      V v_t_2412;
      if (heff_intLe_c(MK_INT(65536LL), v_t_2410)) {
        v_t_2412 = MK_INT(2LL);
      } else {
        v_t_2412 = MK_INT(1LL);
      }
      V t_0 = v_src_240;
      V t_1 = v_t_249;
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, v_t_2412);
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eoffset16(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}); V a_1 = heff_dup(v_params_241); V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
  V v_it_245 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_244}); V a_1 = v_params_241; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    v_t_2413 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_it1_246 = heff_field(v_it_243, 0);
    heff_take_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_JNull: {
      v_t_2413 = MK_INT(0LL);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_246, 0ULL, 1);
      v_t_2413 = MK_INT(0LL);
      break;
    }
    case TAG_JInt: {
      V v_i_248 = heff_field(v_it1_246, 0);
      heff_take_n(v_it1_246, 1ULL, 1);
      v_t_2413 = v_i_248;
      break;
    }
    case TAG_JFloat: {
      V v_x_249 = heff_field(v_it1_246, 0);
      heff_take_n(v_it1_246, 1ULL, 1);
      v_t_2413 = heff_floor_f64(heff_unbox_f64(v_x_249));
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_246, 0ULL, 1);
      v_t_2413 = MK_INT(0LL);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_246, 0ULL, 1);
      v_t_2413 = MK_INT(0LL);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_246, 0ULL, 1);
      v_t_2413 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_it1_246);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  V v_t_2421;
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    v_t_2421 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_it1_2414 = heff_field(v_it_245, 0);
    heff_take_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_2414)) {
    case TAG_JNull: {
      v_t_2421 = MK_INT(0LL);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2421 = MK_INT(0LL);
      break;
    }
    case TAG_JInt: {
      V v_i_2416 = heff_field(v_it1_2414, 0);
      heff_take_n(v_it1_2414, 1ULL, 1);
      v_t_2421 = v_i_2416;
      break;
    }
    case TAG_JFloat: {
      V v_x_2417 = heff_field(v_it1_2414, 0);
      heff_take_n(v_it1_2414, 1ULL, 1);
      v_t_2421 = heff_floor_f64(heff_unbox_f64(v_x_2417));
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2421 = MK_INT(0LL);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2421 = MK_INT(0LL);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_2414, 0ULL, 1);
      v_t_2421 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_it1_2414);
    }
    break;
  }
  default: heff_nomatch(v_it_245);
  }
  return (g_heff_2elsp_2elsp_2eoffsetGo(v_src_240, v_t_2413, v_t_2421, MK_INT(0LL), MK_INT(0LL)));
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eoffsetIn(a[0], a[1]);
}

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str1, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 15, "codeActionKinds");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 18, "codeActionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str20, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str21, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str22, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10)}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str20)})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str21), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str22), v_t_2423}), v_t_2427});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
Clo g_heff_2elsp_2elsp_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2etargetIn_entry, 5, 0};

V g_heff_2elsp_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244) {
top: ;
  V v_t_245 = (g_list_2efind_24s1320851393x93733228(heff_dup(v_f_241), v_program_244));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_p_243);
    heff_drop(v_program_244);
    return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_246, 3)), heff_dup(heff_rfield(v_d_242, 1)))) {
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_246, NTAG(TAG_Nil)});
      V v_program_249 = (g_prelude_2e_2b_2b_24f903834997x2034796740(v_t_248, heff_dup(v_f_241), heff_dup(v_program_244)));
      V v_off_2410 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_d_242, 1)), heff_dup(v_p_243)));
      V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_249)));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Nil: {
        heff_drop(v_f_241);
        heff_drop_rec(v_d_242, 2);
        heff_drop(v_p_243);
        heff_drop(v_program_244);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        heff_drop(v_program_249);
        heff_drop(v_off_2410);
        return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 2);
        V v_t_2414 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_2412, 4)));
        V v_t_2415 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2414));
        V v_t_2416 = ({ V a_0 = v_program_249; V a_1 = v_x_2412; V a_2 = v_t_2415; V a_3 = v_off_2410; V r_ = (g_heff_2ebuild_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_249); r_; });
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Nothing: {
          heff_drop(v_f_241);
          heff_drop_rec(v_d_242, 2);
          heff_drop(v_p_243);
          heff_drop(v_program_244);
          heff_drop_cell(v_ru_24t_245_24Just, 1);
          return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
        }
        case TAG_Just: {
          V v_t_2417 = heff_field(v_t_2416, 0);
          heff_take_n(v_t_2416, 1ULL, 1);
          V v_off_2418 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_get_n(v_d_242, 1, 2), v_p_243));
          V v_occurrences_2419 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_244, heff_dup(heff_rfield(v_t_2417, 0)), heff_dup(heff_rfield(v_t_2417, 1))));
          V v_t_2420 = heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, heff_take_field(v_t_2417, 0), heff_get_n(v_t_2417, 1, 2), v_occurrences_2419});
          V v_target_2421 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_t_2420});
          return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, v_off_2418, v_target_2421});
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    } else {
      heff_drop(v_f_241);
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_p_243);
      heff_drop(v_program_244);
      heff_drop_rec(v_c_246, 13);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2etargetIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_r_241; V a_1 = v_rs_242; V r_ = (g_list_2efilter_24s951260806x709953240(a_0, a_1)); heff_drop(v_r_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubRoots_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str2, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str3, 31, "textDocument/publishDiagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str6, 6, "params");
Clo g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_entry, 2, 0};

V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(V v_uri_240, V v_ds_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str1)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str3)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str4), heff_tag_n(TAG_JString, 1, (V[]){v_uri_240})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_241})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str6), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_248})});
  V v_t_2410 = ({ V b_0 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_249}); V r_ = (g_heff_2eutil_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  return heff_tail(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
}
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str0, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str1, 31, "workspace/didChangeWatchedFiles");
Clo g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_entry, 3, 0};

V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_t_245;
  if (heff_strEq_c(heff_strSlice_lent(v_m_241, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str0))) {
    v_t_245 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str1), 2)) {
      v_t_245 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_245 = v_st_240;
    }
  }
  HEFF_LAST return g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(v_t_245, v_m_241, v_p_242);
}
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(V v_st_240, V v_root_241, V v_f_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){heff_dup(v_root_241), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_243), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam1, 1, 5, (V[]){v_f_242, v_st_240, v_hd_243, v_root_241, v_k_244})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0(V self, V *args) {
  V v_fs_245 = args[0];
  return v_fs_245;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_d_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2418, 1, 2)});
  V f_ = v_k_2420;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam2(V self, V *args) {
  V v_p_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = ({ V a_0 = heff_dup(v_p_2412); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_2412, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3_clo)})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V f_ = ((V)&g_co_2eop_24s1084803226x1249263831_clo);
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_d_2418 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    heff_drop(v_p_2412);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam4, 2, 1, (V[]){v_d_2418});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_sources_2424 = (g_heff_2elsp_2elsp_2enubSources(v_x_2423));
  V v_x_2425 = (g_list_2efoldl_24s209635602x622053613(NTAG(TAG_Nil), v_sources_2424));
  V v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_root__program, (V[]){v_root_241, heff_dup(v_x_2425)})});
  V v_t_2427 = ({ V rv_3 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V f_ = v_k_244;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_t_2427, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_242, NTAG(TAG_Nil)});
  V v_files_2410 = (g_prelude_2e_2b_2b(v_x_248, v_t_249));
  V v_t_2411 = (g_heff_2elsp_2elsp_2enubPaths(v_files_2410));
  V v_c_2422 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam2, 1, 1, (V[]){heff_dup(v_st_240)}); V a_1 = heff_dup(heff_rfield(v_st_240, 6)); V a_2 = v_t_2411; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V f_ = v_c_2422;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam5, 1, 3, (V[]){v_root_241, v_st_240, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_entry, 2, 0};

V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_248 = heff_field(v_x21_245, 1);
      V v_c_249 = (g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(v_st_240, heff_dup(v_f_248)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam1, 2, 2, (V[]){v_c_249, heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(2, shape_st__program, (V[]){v_st_240, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_program_2415 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2412, 1, 2), heff_take_field(v_x_2414, 1)));
  V v_t_2416 = ({ V rv_1 = v_program_2415; V rr_ = heff_rec_reuse_nf(v_x_2414, 1ULL, 2, shape_st__program, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2411;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2413 = ({ V a_0 = heff_dup(heff_rfield(v_x_2412, 0)); V a_1 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(a_0, a_1)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2413;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam3, 1, 2, (V[]){v_x_2412, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam2, 1, 3, (V[]){v_rest_246, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str2, 8, "location");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str3, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str4, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str5, 4, "name");
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(V v_st_240, V v_c_241, V v_y_242) {
top: ;
  V v_p_243 = heff_dup(heff_rfield(v_c_241, 1));
  V v_t_244 = ({ V a_0 = heff_dup(v_p_243); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_2411;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_243, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    v_c_2411 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_247}));
    break;
  }
  case TAG_Just: {
    V v_d_248 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_p_243);
    v_c_2411 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam1, 2, 1, (V[]){v_d_248});
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam2, 2, 3, (V[]){v_c_2411, v_y_242, v_c_241});
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0(V self, V *args) {
  V v_u_245 = args[0];
  return v_u_245;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_get_n(v_d_248, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_y_242 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_242, 0)});
  V v_t_2416 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_242, 1)});
  V v_t_2417 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_c_241, 0)});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2414})});
  V v_t_2419 = (g_heff_2elsp_2elsp_2erange(heff_get_n(v_c_241, 3, 13), heff_get_n(v_y_242, 3, 5)));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str1), v_t_2419}), NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str2), v_t_2421}), NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str3), v_t_2417}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str4), v_t_2416}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str5), v_t_2415}), v_t_2424});
  V v_x_2426 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2425});
  V f_ = v_k_2413;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam3, 1, 3, (V[]){v_y_242, v_c_241, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0, 2, 0};
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(V v_st_240, V v_query_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_query_241);
    return ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_245)));
    V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam1, 1, 1, (V[]){heff_dup(v_query_241)}), v_t_247));
    V v_c_2412 = (g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(heff_dup(v_st_240), heff_dup(v_c_245), v_t_2411));
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam2, 2, 4, (V[]){v_c_2412, v_st_240, v_query_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam1(V self, V *args) {
  V v_y_248 = args[0];
  V v_query_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_249 = (g_heff_2elsp_2elsp_2elowerGo(heff_get_n(v_y_248, 0, 5), MK_INT(0LL), ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_str0)));
  V v_x_2410 = (g_prelude_2estrFind(v_query_241, v_s_249, MK_INT(0LL)));
  return heff_intLe(MK_INT(0LL), v_x_2410);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = (g_prelude_2e_2b_2b(v_x_2415, v_x_2417));
  V f_ = v_k_2414;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_query_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2416 = ({ V a_0 = v_st_240; V a_1 = v_query_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam4, 1, 2, (V[]){v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_query_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam3, 1, 5, (V[]){v_st_240, v_query_241, v_rest_246, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str5, 2, "id");
Clo g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_entry, 3, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(V v_id_240, V v_code_241, V v_msg_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str1)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_241})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_242})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str4), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str5), v_id_240}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_249})});
  V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
  V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  return heff_tail(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
}
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str4, 21, "` is not written here");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str5, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str6, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str7, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str8, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str9, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str10, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str11, 2, "id");
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_entry, 4, 0};

V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(V v_id_240, V v_tg_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_tg_241, 2));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str1)})});
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str2), NTAG(TAG_JNull)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str3), v_id_240}), v_t_247});
    V v_t_249 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_248})});
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_249, 1); r_; });
    V v_a_2411 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam0, 1, 2, (V[]){v_z_243, v_tg_241})));
  }
  case TAG_Just: {
    V v_t_2414 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2415 = (g_heff_2ebuild_2equery_2erenameRefused(heff_dup(heff_rfield(v_t_2414, 1)), heff_dup(heff_rfield(v_t_2414, 2)), heff_dup(heff_rfield(v_t_2414, 2))));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      V v_t_2416 = (g_list_2efind_24s250366202x1057933814(heff_dup(v_t_2414), heff_dup(heff_rfield(v_tg_241, 1)), heff_rfield(v_t_2414, 3)));
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        V v_t_2417 = heff_strAppend(heff_get_n(v_t_2414, 2, 4), ((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str4));
        V v_c_2418 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str5), v_t_2417)));
        return heff_tail(v_c_2418, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam1, 1, 2, (V[]){v_z_243, v_tg_241})});
      }
      case TAG_Just: {
        V v_o_2420 = heff_field(v_t_2416, 0);
        V v_ru_24t_2416_24Just = heff_take_reuse_n(v_t_2416, 1ULL, 1);
        V v_t_2421 = (g_heff_2elsp_2elsp_2erange(heff_take_field(v_o_2420, 1), heff_get_n(v_o_2420, 2, 4)));
        V v_t_2422 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2414, 2, 4)});
        V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str6), v_t_2422}), NTAG(TAG_Nil)});
        V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str7), v_t_2421}), v_t_2423});
        V v_result_2425 = heff_tag_at_n(v_ru_24t_2416_24Just, TAG_JObject, 1, (V[]){v_t_2424});
        V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str9)})});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str10), v_result_2425}), NTAG(TAG_Nil)});
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str11), v_id_240}), v_t_2427});
        V v_t_2429 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2428})});
        V v_t_2430 = ({ V a_0 = v_t_2429; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2429, 1); r_; });
        V v_a_2431 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
        V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2431})});
        return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam2, 1, 2, (V[]){v_z_243, v_tg_241})));
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_Just: {
      V v_why_2434 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_rec(v_t_2414, 4);
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      V v_c_2435 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), v_why_2434));
      return heff_tail(v_c_2435, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam3, 1, 2, (V[]){v_z_243, v_tg_241})});
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2413);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam2(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str7, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str8, 2, "id");
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam6(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_entry, 5, 0};

V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(V v_id_240, V v_new_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_tg_242, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_new_241);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str1)})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str2), NTAG(TAG_JNull)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str3), v_id_240}), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})});
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
    V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam0, 1, 2, (V[]){v_z_244, v_tg_242})));
  }
  case TAG_Just: {
    V v_t_2415 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2416 = (g_heff_2ebuild_2equery_2erenameRefused(heff_dup(heff_rfield(v_t_2415, 1)), heff_dup(heff_rfield(v_t_2415, 2)), heff_dup(v_new_241)));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      V v_c_2417 = (g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(heff_get_n(v_tg_242, 0, 3), heff_dup(v_t_2415), heff_dup(v_new_241)));
      return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam1, 1, 5, (V[]){v_t_2415, v_new_241, v_z_243, v_id_240, v_z_244})});
    }
    case TAG_Just: {
      V v_why_2453 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      heff_drop(v_new_241);
      heff_drop_rec(v_t_2415, 4);
      V v_c_2454 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), v_why_2453));
      return heff_tail(v_c_2454, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam6, 1, 2, (V[]){v_z_244, v_tg_242})});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam2(V self, V *args) {
  V v_p_2428 = args[0];
  V v_os_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2429 = (g_list_2efilter_24s999680916x306845608(heff_dup(v_p_2428), v_os_2425));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2428, v_os_2429});
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam4(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V v_t_2446;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_x_2444 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 2);
    v_t_2446 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_z_244;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str5)})});
  V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_x_2432})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
  V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str8), v_id_240}), v_t_2437});
  V v_t_2439 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2438})});
  V v_t_2440 = ({ V a_0 = v_t_2439; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2439, 1); r_; });
  V v_a_2441 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2440, NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2441})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam4, 1, 2, (V[]){v_x_2418, v_z_244})));
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2449);
  V v_t_2452;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 2);
    v_t_2452 = v_x_2450;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_z_244;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_t_2415 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_id_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_y_2420 = heff_dup(heff_field(v_x_2418, 1));
    v_t_2421 = v_y_2420;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    V v_t_2424;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2418, 0));
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    V v_os_2425 = heff_get_n(v_t_2415, 3, 4);
    V v_t_2426 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2425)));
    V v_t_2427 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2426));
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam2, 1, 1, (V[]){v_os_2425}), v_t_2427));
    V v_c_2431 = (g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266(v_t_2424, v_new_241, v_t_2430));
    V f_ = v_c_2431;
    heff_room[0] = heff_dup(v_z_243);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam3, 1, 4, (V[]){v_id_240, v_z_243, v_x_2418, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2447 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    heff_drop_rec(v_t_2415, 4);
    heff_drop(v_new_241);
    V v_c_2448 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), v_why_2447));
    V f_ = v_c_2448;
    heff_room[0] = v_z_243;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam5, 1, 2, (V[]){v_x_2418, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam6(V self, V *args) {
  V v_x_2455 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str2, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str11, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str12, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str13, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str14, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str15, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str16, 5, "start");
V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558(V v_a_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_lam0, 2, 3, (V[]){v_c_242, v_a_240, v_p_241});
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_a_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_a_240, 3);
    heff_drop(v_p_241);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_246 = heff_field(v_x_245, 0);
    V v_ru_24x_245_24Just = heff_take_reuse_n(v_x_245, 1ULL, 1);
    V v_x1_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_240, 2))));
    V v_t_2410;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_245_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      v_t_2410 = heff_tag_at_n(v_ru_24x_245_24Just, TAG_Just, 1, (V[]){v_x_248});
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_a_240, 3);
      heff_drop(v_p_241);
      heff_drop(v_hd_243);
      heff_drop(v_f_246);
      V f_ = v_k_244;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str0), NTAG(TAG_Nil)});
      V v_it_2413 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str1), v_t_2412}); V a_1 = heff_dup(v_p_241); V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2422;
      switch (heff_tag_of(v_it_2413)) {
      case TAG_Nothing: {
        v_t_2422 = heff_strEq(heff_dup(heff_rfield(v_c_2411, 3)), heff_dup(heff_rfield(v_a_240, 1)));
        break;
      }
      case TAG_Just: {
        V v_it1_2414 = heff_field(v_it_2413, 0);
        heff_take_n(v_it_2413, 1ULL, 1);
        V v_t_2421;
        switch (heff_tag_of(v_it1_2414)) {
        case TAG_JNull: {
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_it1_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        case TAG_JFloat: {
          heff_take_n(v_it1_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        case TAG_JArray: {
          V v_xs_2419 = heff_field(v_it1_2414, 0);
          heff_take_n(v_it1_2414, 1ULL, 1);
          v_t_2421 = ({ V a_0 = v_xs_2419; V r_ = (g_list_2eany_24s1497517957x114012878(a_0)); heff_drop(v_xs_2419); r_; });
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it1_2414);
        }
        v_t_2422 = heff_bool(((heff_dup(v_t_2421) == NTAG(TAG_True)) && heff_strEq_c(heff_dup(heff_rfield(v_c_2411, 3)), heff_dup(heff_rfield(v_a_240, 1)))));
        heff_drop(v_t_2421);
        break;
      }
      default: heff_nomatch(v_it_2413);
      }
      if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
        heff_drop(v_t_2422);
        V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str2), NTAG(TAG_Nil)});
        V v_it_2424 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str3), v_t_2423}); V a_1 = heff_dup(v_p_241); V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2432;
        switch (heff_tag_of(v_it_2424)) {
        case TAG_Nothing: {
          v_t_2432 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str4);
          break;
        }
        case TAG_Just: {
          V v_it1_2425 = heff_field(v_it_2424, 0);
          heff_take_n(v_it_2424, 1ULL, 1);
          switch (heff_tag_of(v_it1_2425)) {
          case TAG_JNull: {
            v_t_2432 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str5);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2425, 0ULL, 1);
            v_t_2432 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str6);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2425, 0ULL, 1);
            v_t_2432 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str7);
            break;
          }
          case TAG_JFloat: {
            heff_take_n(v_it1_2425, 0ULL, 1);
            v_t_2432 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str8);
            break;
          }
          case TAG_JString: {
            V v_s_2429 = heff_field(v_it1_2425, 0);
            heff_take_n(v_it1_2425, 1ULL, 1);
            v_t_2432 = v_s_2429;
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2425, 0ULL, 1);
            v_t_2432 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str9);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2425, 0ULL, 1);
            v_t_2432 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str10);
            break;
          }
          default: heff_nomatch(v_it1_2425);
          }
          break;
        }
        default: heff_nomatch(v_it_2424);
        }
        V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str11), NTAG(TAG_Nil)});
        V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str13), v_t_2433})});
        V v_it_2435 = ({ V a_0 = v_t_2434; V a_1 = heff_dup(v_p_241); V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_2434, 2); r_; });
        V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str14), NTAG(TAG_Nil)});
        V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_str16), v_t_2436})});
        V v_it_2438 = ({ V a_0 = v_t_2437; V a_1 = v_p_241; V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_2437, 2); r_; });
        V v_t_2446;
        switch (heff_tag_of(v_it_2435)) {
        case TAG_Nothing: {
          v_t_2446 = MK_INT(0LL);
          break;
        }
        case TAG_Just: {
          V v_it1_2439 = heff_field(v_it_2435, 0);
          heff_take_n(v_it_2435, 1ULL, 1);
          switch (heff_tag_of(v_it1_2439)) {
          case TAG_JNull: {
            v_t_2446 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2439, 0ULL, 1);
            v_t_2446 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2441 = heff_field(v_it1_2439, 0);
            heff_take_n(v_it1_2439, 1ULL, 1);
            v_t_2446 = v_i_2441;
            break;
          }
          case TAG_JFloat: {
            V v_x_2442 = heff_field(v_it1_2439, 0);
            heff_take_n(v_it1_2439, 1ULL, 1);
            v_t_2446 = heff_floor_f64(heff_unbox_f64(v_x_2442));
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2439, 0ULL, 1);
            v_t_2446 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2439, 0ULL, 1);
            v_t_2446 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2439, 0ULL, 1);
            v_t_2446 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2439);
          }
          break;
        }
        default: heff_nomatch(v_it_2435);
        }
        V v_t_2454;
        switch (heff_tag_of(v_it_2438)) {
        case TAG_Nothing: {
          v_t_2454 = MK_INT(0LL);
          break;
        }
        case TAG_Just: {
          V v_it1_2447 = heff_field(v_it_2438, 0);
          heff_take_n(v_it_2438, 1ULL, 1);
          switch (heff_tag_of(v_it1_2447)) {
          case TAG_JNull: {
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2449 = heff_field(v_it1_2447, 0);
            heff_take_n(v_it1_2447, 1ULL, 1);
            v_t_2454 = v_i_2449;
            break;
          }
          case TAG_JFloat: {
            V v_x_2450 = heff_field(v_it1_2447, 0);
            heff_take_n(v_it1_2447, 1ULL, 1);
            v_t_2454 = heff_floor_f64(heff_unbox_f64(v_x_2450));
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2447);
          }
          break;
        }
        default: heff_nomatch(v_it_2438);
        }
        V v_t_2455 = (g_heff_2elsp_2elsp_2eoffsetGo(heff_take_field(v_a_240, 1), v_t_2446, v_t_2454, MK_INT(0LL), MK_INT(0LL)));
        return (g_heff_2elsp_2elsp_2esplitIn_24s203746709x104822352(heff_dup(heff_rfield(v_a_240, 0)), v_f_246, v_t_2432, heff_get_n(v_a_240, 2, 3), v_c_2411, v_t_2455, v_hd_243, v_k_244));
      } else {
        heff_drop_rec(v_a_240, 3);
        heff_drop(v_p_241);
        heff_drop(v_hd_243);
        heff_drop(v_f_246);
        heff_drop_rec(v_c_2411, 13);
        heff_drop(v_t_2422);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_a_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s1431707183x2032297558_lam1, 1, 4, (V[]){v_k_244, v_a_240, v_p_241, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}