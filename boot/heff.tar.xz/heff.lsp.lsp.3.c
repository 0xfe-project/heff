// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_PathUri 23459
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Send 26077
#define TAG_Throw 56084
#define LBL_analysis 1868176469
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_claim 296100950
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_end 310101
#define LBL_error 298143266
#define LBL_errors 652506774
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1554102946x910234624(V, V, V);
V g_co_2eop_24s1554102946x910234624_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_clo;
V g_co_2eop_24s1554102946x910234624_24tok1(V, V, V, V);
V g_co_2eop_24s1554102946x910234624_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_24tok1_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739(V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_clo;
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260(V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078(V, V);
V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_clo;
V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_clo;
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2eescapeInto(V, V, V);
V g_json_2eescapeInto_entry(V self, V *a);
extern Clo g_json_2eescapeInto_clo;
V g_json_2ewriteInto(V, V);
V g_json_2ewriteInto_entry(V self, V *a);
extern Clo g_json_2ewriteInto_clo;
HeffT2 g_list_2efind_24s446714453x706785629_24cpr(V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2) || heff_intLe_c_lent(v_e_242, v_i_241, 0))) {
    heff_drop(v_n_243);
    if (heff_intLe_c_lent(v_i_241, v_e_242, 0)) {
      heff_drop(v_e_242);
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return v_e_242;
    }
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      HeffT2 v_t_244 = heff_strRuneDecode_lent(v_src_240, v_i_241, 0);
      {
        V v_rune_245 = v_t_244.f[0];
        V v_width_246 = v_t_244.f[1];
        V v_t_247;
        if (heff_intLe_c(MK_INT(65536LL), heff_runeToInt(v_rune_245))) {
          v_t_247 = MK_INT(2LL);
        } else {
          v_t_247 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, v_width_246);
        V t_2 = v_e_242;
        V t_3 = heff_intSub(v_n_243, v_t_247);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_e_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffset16(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}); V a_1 = heff_dup(v_params_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_246}); V a_1 = v_params_241; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2417;
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_2410 = v_field_245;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_JNull: {
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2412 = heff_field(v_it1_2410, 0);
          heff_take_n(v_it1_2410, 1ULL, 1);
          v_t_2417 = v_i_2412;
          break;
        }
        case TAG_JFloat: {
          double v_x_2413 = heff_tflat_f64(v_it1_2410, 0);
          heff_take_na(v_it1_2410, 0ULL, 1);
          v_t_2417 = heff_floor_f64(v_x_2413);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2410);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2417 = MK_INT(0LL);
      }
      V v_t_2425;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_it1_2418 = v_field_249;
        switch (heff_tag_of(v_it1_2418)) {
        case TAG_JNull: {
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2420 = heff_field(v_it1_2418, 0);
          heff_take_n(v_it1_2418, 1ULL, 1);
          v_t_2425 = v_i_2420;
          break;
        }
        case TAG_JFloat: {
          double v_x_2421 = heff_tflat_f64(v_it1_2418, 0);
          heff_take_na(v_it1_2418, 0ULL, 1);
          v_t_2425 = heff_floor_f64(v_x_2421);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2418);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2425 = MK_INT(0LL);
      }
      return (g_heff_2elsp_2elsp_2eoffsetGo(v_src_240, v_t_2417, v_t_2425, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetIn(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_24dps_entry, 3, 0};

V g_heff_2elsp_2elsp_2elinesFrom_24dps(V v_src_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_d_243 = heff_strLength_lent(v_src_240, 0);
    V v_j_244 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str0), v_src_240, v_i_241, 1);
    V v_t_245;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_t_245 = v_d_243;
    } else {
      heff_drop(v_d_243);
      v_t_245 = v_j_244;
    }
    V v_t_246 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_245, 4)});
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_d_249 = heff_strLength_lent(v_src_240, 0);
    V v_j_2410 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str1), v_src_240, v_i_241, 5);
    V v_t_2411;
    if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
      heff_drop(v_j_2410);
      v_t_2411 = v_d_249;
    } else {
      heff_drop(v_d_249);
      v_t_2411 = v_j_2410;
    }
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_t_2411, MK_INT(1LL));
    V t_2 = v_cell_247;
    v_src_240 = t_0;
    v_i_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str1, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 15, "codeActionKinds");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 18, "codeActionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 25, "documentHighlightProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str20, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str21, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str22, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str23, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str24, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10)}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11)}), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str20), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str21), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str22)})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str23), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str24), v_t_2425}), v_t_2429});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_r_241; V a_1 = v_rs_242; V r_ = (g_list_2ekeepIf_24s689992630x418898235(a_0, a_1)); heff_drop(v_r_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubRoots_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2, 1, 0};
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam7(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_entry, 5, 0};

V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(V v_st_240, V v_f_241, V v_d_242, V v_z_243, V v_z_244) {
top: ;
  V v_docs_245 = heff_take_field(v_st_240, 0);
  V v_lib_246 = heff_get_n(v_st_240, 6, 7);
  V v_c_2438 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam0, 1, 1, (V[]){v_docs_245}), v_lib_246, v_f_241));
  return heff_tail(v_c_2438, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam7, 1, 3, (V[]){v_z_243, v_d_242, v_z_244})});
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2411, 1, 2)});
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_err_2426 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Left = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2426})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2427));
  }
  case TAG_Right: {
    V v_x_2428 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam4, 2, 1, (V[]){v_x_2428});
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    heff_take_n(v_x_2434, 0ULL, 1);
    v_t_2437 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2436 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Right = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    v_t_2437 = heff_tag_at_n(v_ru_24x_2434_24Right, TAG_Just, 1, (V[]){v_y_2436});
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_k_2433;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2431;
  args[0] = v_hd_2432;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam6, 1, 1, (V[]){v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_docs_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_docs_245; V a_1 = v_p_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_245); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_p_247);
      V v_d_2411 = v_field_2410;
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam1, 2, 1, (V[]){v_d_2411});
    } else {
      heff_drop(v_field_2410);
      V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_247));
      V v_t_2416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2415; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2415); r_; });
      V v_a_2418 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2416, ((V)&g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam2_clo)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      V v_c_2431 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam3_clo)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam5, 2, 1, (V[]){v_c_2431});
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_x_2446; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_full_2442 = heff_get_n(v_x_2441, 0, 2);
  V v_program_2443 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2442)));
  V v_t_2444 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2442));
  V v_t_2445 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_242, 1)), v_t_2444, heff_get_n(v_x_2439, 1, 5)));
  V v_diags_2447 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam9, 1, 1, (V[]){v_d_242}), v_t_2445));
  V f_ = v_z_244;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2443, v_diags_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2440 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2439)));
  V f_ = v_c_2440;
  heff_room[0] = v_z_243;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_lam8, 1, 3, (V[]){v_d_242, v_x_2439, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str0, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str1, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str2, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str3, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str4, 59, "heff could not finish checking this file: it stopped here (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str5, 30, "); what follows is not checked");
V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_entry, 8, 0};

V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872(V v_st_240, V v_f_241, V v_d_242, V v_why_243, V v_ds_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Left: {
    heff_drop(v_st_240);
    heff_drop(v_f_241);
    heff_drop(v_z_246);
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str0), v_why_243), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str1));
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_249, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2411 = ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_t_2410; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
    V v_diags_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(2, shape_program__diags, (V[]){NTAG(TAG_Nil), v_diags_2412});
    return heff_tail(v_z_247, 1, (V[]){v_t_2413});
  }
  case TAG_Right: {
    V v_a_2414 = heff_field(v_x6_245, 0);
    V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ds_244));
    V v_c_2416 = (g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177(v_st_240, v_f_241, heff_dup(v_d_242), v_ds_244, MK_INT(0LL), v_t_2415, heff_dup(v_a_2414)));
    return heff_tail(v_c_2416, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_lam0, 1, 3, (V[]){v_d_242, v_why_243, v_z_247})});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872(a[0], a[1], a[2], a[3], a4, a5, a[6], a[7]); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_why_243 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_2418 = heff_get_n(v_d_242, 1, 2);
  V v_why_2419 = v_why_243;
  V v_s_2420 = v_x_2417;
  V v_analysis_2421 = heff_take_field(v_s_2420, 0);
  V v_at_2422 = heff_get_n(v_s_2420, 1, 2);
  V v_program_2423 = heff_take_field(v_analysis_2421, 0);
  V v_t_2429;
  switch (heff_tag_of(v_at_2422)) {
  case TAG_Nothing: {
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str2), v_why_2419), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str3));
    V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2424, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    v_t_2429 = ({ V a_0 = v_src_2418; V a_1 = v_t_2425; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(a_0, a_1)); heff_drop(v_src_2418); r_; });
    break;
  }
  case TAG_Just: {
    V v_t_2426 = heff_field(v_at_2422, 0);
    V v_ru_24at_2422_24Just = heff_take_reuse_n(v_at_2422, 1ULL, 1);
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str4), v_why_2419), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_str5));
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2427, heff_get_n(v_t_2426, 1, 2), NTAG(TAG_Nothing)});
    v_t_2429 = ({ V a_0 = v_ru_24at_2422_24Just; V a_1 = v_src_2418; V a_2 = v_t_2428; V r_ = (g_heff_2elsp_2elsp_2ediagnostic_24tok1(a_0, a_1, a_2)); heff_drop(v_src_2418); r_; });
    break;
  }
  default: heff_nomatch(v_at_2422);
  }
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_diags_2431 = (g_prelude_2e_2b_2b(heff_get_n(v_analysis_2421, 1, 2), v_t_2430));
  V v_x_2432 = heff_rec_n(2, shape_program__diags, (V[]){v_program_2423, v_diags_2431});
  V f_ = v_z_247;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_str0, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_str1, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_str2, 31, "textDocument/publishDiagnostics");
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam7(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(V v_st_240, V v_f_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_245 = v_field_244;
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam0, 2, 3, (V[]){v_st_240, v_f_241, v_d_245});
    } else {
      heff_drop(v_f_241);
      heff_drop(v_field_244);
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam7, 2, 1, (V[]){v_st_240});
    }
  }
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam2(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam1(V self, V *args) {
  V v_use_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_d_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_k_249 = heff_dup(heff_rfield(v_hd_246, 0));
  V v_t_2410 = heff_tr(g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(v_st_240, v_f_241, v_d_245, v_hd_246, v_k_249));
  V f_ = v_use_248;
  heff_room[0] = v_t_2410;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam2_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_a_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = v_a_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_program_2426 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_rec_n(2, shape_text__program, (V[]){heff_get_n(v_d_245, 1, 2), v_program_2426});
  V v_c_2434 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_240, 1), v_f_241, v_t_2433));
  V v_due_2435 = heff_take_field(v_st_240, 2);
  V v_project_2436 = heff_take_field(v_st_240, 3);
  V v_watch_2437 = heff_take_field(v_st_240, 4);
  V v_shutdown_2438 = heff_take_field(v_st_240, 5);
  V v_lib_2439 = heff_take_field(v_st_240, 6);
  V v_t_2440 = ({ V rv_1 = v_c_2434; V rv_2 = v_due_2435; V rv_3 = v_project_2436; V rv_4 = v_watch_2437; V rv_5 = v_shutdown_2438; V rv_6 = v_lib_2439; V rr_ = heff_rec_reuse_nf(v_st_240, 1ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_diags_2425 = heff_take_field(v_x_2424, 1);
  V v_program_2426 = heff_get_n(v_x_2424, 0, 2);
  V v_t_2427 = heff_tag_n(TAG_JString, 1, (V[]){heff_dup(heff_rfield(v_d_245, 0))});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_str0), heff_tag_n(TAG_JArray, 1, (V[]){v_diags_2425})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_str1), v_t_2427}), v_t_2429});
  V v_c_2431 = heff_tr(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078(((V)&g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430})));
  V f_ = v_c_2431;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam6, 1, 5, (V[]){v_d_245, v_program_2426, v_st_240, v_f_241, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2423;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2423 = heff_tr(heff_call(((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_clo), 4, (V[]){heff_dup(v_st_240), heff_dup(v_f_241), heff_dup(v_d_245), v_why_2419}));
    break;
  }
  case TAG_Right: {
    V v_a_2420 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2423 = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam4, 2, 1, (V[]){v_a_2420});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_t_2423;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam5, 1, 5, (V[]){v_d_245, v_hd_246, v_st_240, v_f_241, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam1, 1, 4, (V[]){heff_dup(v_hd_246), heff_dup(v_st_240), heff_dup(v_f_241), heff_dup(v_d_245)})})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2417;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam3, 1, 5, (V[]){v_st_240, v_f_241, v_d_245, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0, 2, 0};
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry, 2, 0};

V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_249, 0, 6), v_f_244});
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str0, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str4, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str17, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str19, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str20, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str21, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str22, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str23, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str24, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str25, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str26, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str27, 21, "` is not written here");
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_entry, 4, 0};

V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140(V v_id_240, V v_tg_241, V v_z_242, V v_z_243) {
top: ;
  V v_target_244 = heff_take_field(v_tg_241, 2);
  V v_st_245 = heff_take_field(v_tg_241, 0);
  V v_off_246 = heff_get_n(v_tg_241, 1, 3);
  switch (heff_tag_of(v_target_244)) {
  case TAG_Nothing: {
    heff_drop(v_off_246);
    V v_t_247 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str0), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str1), MK_INT(0LL)));
    V v_acc_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str2)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str3));
    V v_t_249 = (g_json_2eescapeInto(heff_strAppend(v_acc_248, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str4)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str5), MK_INT(0LL)));
    V v_acc_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str6));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_acc_2410, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str7)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str8));
    V v_t_2412 = (g_json_2eescapeInto(v_t_2411, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str9), MK_INT(0LL)));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str10)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str11));
    V v_acc_2414 = ({ V a_0 = v_t_2413; V a_1 = v_id_240; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_240); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(v_acc_2414, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str12)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str13));
    V v_t_2416 = (g_json_2eescapeInto(v_t_2415, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str14), MK_INT(0LL)));
    V v_acc_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str15)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str16));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str17)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str18));
    V v_a_2419 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s1554102946x910234624(v_a_2419, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam0, 1, 2, (V[]){v_z_243, v_st_245})));
  }
  case TAG_Just: {
    V v_t_2421 = heff_field(v_target_244, 0);
    V v_ru_24target_244_24Just = heff_take_reuse_n(v_target_244, 1ULL, 1);
    HeffT2 v_t_2422 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2421, 1)), heff_dup(heff_rfield(v_t_2421, 2)), heff_dup(heff_rfield(v_t_2421, 2))));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        heff_drop(v_off_246);
        heff_drop_rec(v_t_2421, 4);
        V v_why_2425 = v_field_2424;
        V v_c_2426 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(v_ru_24target_244_24Just, v_id_240, MK_INT(-32803LL), v_why_2425));
        return heff_tail(v_c_2426, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam1, 1, 2, (V[]){v_z_243, v_st_245})});
      } else {
        heff_drop(v_field_2424);
        HeffT2 v_t_2428 = (g_list_2efind_24s446714453x706785629_24cpr(heff_dup(v_t_2421), v_off_246, heff_rfield(v_t_2421, 3)));
        {
          V v_field_2430 = v_t_2428.f[1];
          int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
          if ((v_tag_2429 == ((int64_t)0ULL))) {
            V v_o_2431 = v_field_2430;
            V v_source_2432 = heff_take_field(v_o_2431, 1);
            V v_span_2433 = heff_get_n(v_o_2431, 2, 4);
            V v_t_2434 = ({ V a_0 = v_source_2432; V a_1 = v_span_2433; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_2432); r_; });
            V v_t_2435 = heff_tag_at_n(v_ru_24target_244_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2421, 2, 4)});
            V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str19), v_t_2435}), NTAG(TAG_Nil)});
            V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str20), v_t_2434}), v_t_2436});
            V v_result_2438 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2437});
            V v_t_2439 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str21), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str22)})});
            V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str23), v_result_2438}), NTAG(TAG_Nil)});
            V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str24), v_id_240}), v_t_2440});
            V v_t_2442 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_t_2441})});
            V v_t_2443 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str25); V a_1 = v_t_2442; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_2442, 1); r_; });
            V v_a_2444 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2443, NTAG(TAG_MkUnit)});
            return (g_co_2eop_24s1554102946x910234624(v_a_2444, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam2, 1, 2, (V[]){v_z_243, v_st_245})));
          } else {
            heff_drop(v_field_2430);
            V v_t_2446 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str26), heff_get_n(v_t_2421, 2, 4));
            V v_c_2447 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(v_ru_24target_244_24Just, v_id_240, MK_INT(-32803LL), heff_strAppend(v_t_2446, ((V)&g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_str27))));
            return heff_tail(v_c_2447, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam3, 1, 2, (V[]){v_z_243, v_st_245})});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_target_244);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam2(V self, V *args) {
  V v_x_2445 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_lam3(V self, V *args) {
  V v_x_2448 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_str0, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_str1, 5, "range");
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam0, 2, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_entry, 3, 0};

V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739(V v_st_240, V v_new_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_new_241);
    return ((V)&g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_path_247 = heff_take_field(v_b_245, 0);
    V v_occurrences_248 = heff_get_n(v_b_245, 1, 2);
    V v_p_249 = v_path_247;
    HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_p_249));
    V v_c_2422;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_p_249);
        V v_d_2413 = v_field_2412;
        v_c_2422 = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam1, 2, 1, (V[]){v_d_2413});
      } else {
        heff_drop(v_field_2412);
        V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_PathUri, 2, (V[]){v_p_249, ((V)&g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam2_clo)})});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
        v_c_2422 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
      }
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam3, 2, 5, (V[]){v_c_2422, v_st_240, v_new_241, v_rest_246, v_occurrences_248});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_get_n(v_d_2413, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam2(V self, V *args) {
  V v_u_2416 = args[0];
  return v_u_2416;
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam6(V self, V *args) {
  V v_o_2428 = args[0];
  V v_new_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_source_2429 = heff_take_field(v_o_2428, 1);
  V v_span_2430 = heff_get_n(v_o_2428, 2, 4);
  V v_t_2431 = ({ V a_0 = v_source_2429; V a_1 = v_span_2430; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_2429); r_; });
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_str0), heff_tag_n(TAG_JString, 1, (V[]){v_new_241})});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_str1), v_t_2431}), v_t_2433});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2434});
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_new_241 = heff_env(self)[0];
  V v_occurrences_248 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam6, 1, 1, (V[]){v_new_241}), v_occurrences_248));
  V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2435})});
  V v_x_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_x_2427});
  V f_ = v_k_2424;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2423 = heff_env(self)[3];
  V v_occurrences_248 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2426 = (g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739(v_st_240, heff_dup(v_new_241), v_rest_246));
  V f_ = v_c_2426;
  heff_room[0] = v_hd_2423;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam5, 1, 4, (V[]){v_new_241, v_occurrences_248, v_x_2425, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_new_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_occurrences_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_lam4, 1, 6, (V[]){v_st_240, v_new_241, v_rest_246, v_hd_2423, v_occurrences_248, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str0, 10, "package.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str1, 11, "/package.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str2, 8, "build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str3, 9, "/build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str4, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str5, 1, "\012");
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_entry, 2, 0};

V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260(V v_st_240, V v_f_241) {
top: ;
  if ((heff_strEq_c_lent(v_f_241, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str0), 2) || ({ int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)11ULL)); int c_ = ({ V v_t_2420 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_242), heff_strLength_lent(v_f_241, 0)); int c_ = (heff_strEq_c_lent(v_t_2420, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str1), 2) || (heff_strEq_c_lent(v_f_241, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str2), 2) || ({ int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)9ULL)); int c_ = ({ V v_t_2421 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_243), heff_strLength_lent(v_f_241, 0)); int c_ = heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str3), 2); heff_drop(v_t_2421); c_; }); c_; }))); heff_drop(v_t_2420); c_; }); c_; }))) {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_f_241);
    return ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam0_clo);
  } else {
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_get_n(v_st_240, 6, 7), heff_dup(v_f_241)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam1, 2, 2, (V[]){v_c_246, v_f_241});
  }
}
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_2410 = (g_heff_2ebuild_2eload_2emoduleOf(v_x_249, v_f_241));
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str4), heff_dup(v_n_2410)), ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_str5));
  V v_t_2412 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_t_2411, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_x2_2413 = heff_get_n(v_t_2412, 2, 4);
  V v_x_2419;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    heff_drop(v_n_2410);
    v_x_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2414 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Just = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    V v_name_2415 = heff_take_field(v_h_2414, 0);
    V v_error_2416 = heff_get_n(v_h_2414, 4, 5);
    switch (heff_tag_of(v_name_2415)) {
    case TAG_Nothing: {
      heff_drop(v_n_2410);
      heff_drop_cell(v_ru_24x2_2413_24Just, 1);
      heff_drop(v_error_2416);
      v_x_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_m_2417 = heff_field(v_name_2415, 0);
      heff_take_n(v_name_2415, 1ULL, 1);
      switch (heff_tag_of(v_error_2416)) {
      case TAG_Nothing: {
        if (heff_strEq_c_lent(v_m_2417, v_n_2410, 1)) {
          v_x_2419 = heff_tag_at_n(v_ru_24x2_2413_24Just, TAG_Just, 1, (V[]){v_n_2410});
        } else {
          heff_drop(v_n_2410);
          heff_drop_cell(v_ru_24x2_2413_24Just, 1);
          v_x_2419 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_Just: {
        heff_take_n(v_error_2416, 0ULL, 1);
        heff_drop(v_n_2410);
        heff_drop_cell(v_ru_24x2_2413_24Just, 1);
        heff_drop(v_m_2417);
        v_x_2419 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_error_2416);
      }
      break;
    }
    default: heff_nomatch(v_name_2415);
    }
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V f_ = v_k_248;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_lam2, 1, 2, (V[]){v_f_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_entry, 4, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065(v_st_240, heff_dup(v_f_244)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_lam0, 1, 3, (V[]){heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_247; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}