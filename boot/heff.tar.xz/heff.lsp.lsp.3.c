// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Attempt 14217
#define TAG_ByFields 9073
#define TAG_ByTags 55317
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_PathUri 23459
#define TAG_Right 62770
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_selection 2055983820
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_uri 325606
#define LBL_uses 10094739
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_name__span__start__equals__end[] = {LBL_name, LBL_span, LBL_start, LBL_equals, LBL_end};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
static uint32_t shape_title__start__end__text[] = {LBL_title, LBL_start, LBL_end, LBL_text};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V, V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524(V, V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_clo;
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747(V, V, V, V, V);
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(V, V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_clo;
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734(V, V, V);
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_clo;
V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085(V, V, V);
V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958(V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955(V, V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2esplit_2ealiasedTag(V, V);
V g_heff_2elsp_2esplit_2ealiasedTag_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ealiasedTag_clo;
V g_heff_2elsp_2esplit_2earrowOutside(V, V, V);
V g_heff_2elsp_2esplit_2earrowOutside_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2earrowOutside_clo;
V g_heff_2elsp_2esplit_2ecatMaybesS(V);
V g_heff_2elsp_2esplit_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ecatMaybesS_clo;
V g_heff_2elsp_2esplit_2edeclsOf(V);
V g_heff_2elsp_2esplit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2edeclsOf_clo;
V g_heff_2elsp_2esplit_2eextentEnd(V, V, V);
V g_heff_2elsp_2esplit_2eextentEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eextentEnd_clo;
V g_heff_2elsp_2esplit_2efirstJust(V);
V g_heff_2elsp_2esplit_2efirstJust_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efirstJust_clo;
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
V g_heff_2elsp_2esplit_2efreshNames(V, V);
V g_heff_2elsp_2esplit_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efreshNames_clo;
V g_heff_2elsp_2esplit_2ehintOf(V, V);
V g_heff_2elsp_2esplit_2ehintOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ehintOf_clo;
V g_heff_2elsp_2esplit_2eisOperator(V);
V g_heff_2elsp_2esplit_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eisOperator_clo;
V g_heff_2elsp_2esplit_2elineStart(V, V);
V g_heff_2elsp_2esplit_2elineStart_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elineStart_clo;
V g_heff_2elsp_2esplit_2enameEnd(V, V);
V g_heff_2elsp_2esplit_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enameEnd_clo;
V g_heff_2elsp_2esplit_2evarIn(V, V);
V g_heff_2elsp_2esplit_2evarIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2evarIn_clo;
V g_heff_2elsp_2esplit_2ewordsIn(V, V, V, V);
V g_heff_2elsp_2esplit_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ewordsIn_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1836353438x580818415(V, V);
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a);
extern Clo g_list_2eany_24s1836353438x580818415_clo;
V g_list_2eany_24s257543591x25063085(V, V);
V g_list_2eany_24s257543591x25063085_entry(V self, V *a);
extern Clo g_list_2eany_24s257543591x25063085_clo;
HeffT2 g_list_2efind_24s1338461068x888657721_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efind_24s633938771x532201311(V, V);
V g_list_2efind_24s633938771x532201311_entry(V self, V *a);
extern Clo g_list_2efind_24s633938771x532201311_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s198101905x967505038(V, V, V, V);
V g_list_2efoldl_24s198101905x967505038_entry(V self, V *a);
extern Clo g_list_2efoldl_24s198101905x967505038_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s661788424x2062432904(V, V);
V g_list_2efoldl_24s661788424x2062432904_entry(V self, V *a);
extern Clo g_list_2efoldl_24s661788424x2062432904_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2elookup_24s1507486579x90027037(V, V);
V g_list_2elookup_24s1507486579x90027037_entry(V self, V *a);
extern Clo g_list_2elookup_24s1507486579x90027037_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1170504272x1852564147(V);
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_clo;
V g_list_2emap_24s1387309293x1990579214(V);
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_clo;
V g_list_2emap_24s1628253759x601849359(V, V, V);
V g_list_2emap_24s1628253759x601849359_entry(V self, V *a);
extern Clo g_list_2emap_24s1628253759x601849359_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s2130584539x811126895(V, V, V);
V g_list_2ezipWith_24s2130584539x811126895_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2130584539x811126895_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2) || heff_intLe_c_lent(v_e_242, v_i_241, 0))) {
    heff_drop(v_n_243);
    if (heff_intLe_c_lent(v_i_241, v_e_242, 0)) {
      heff_drop(v_e_242);
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return v_e_242;
    }
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      HeffT2 v_t_244 = heff_strRuneDecode_lent(v_src_240, v_i_241, 0);
      {
        V v_rune_245 = v_t_244.f[0];
        V v_width_246 = v_t_244.f[1];
        V v_t_247;
        if (heff_intLe_c(MK_INT(65536LL), heff_runeToInt(v_rune_245))) {
          v_t_247 = MK_INT(2LL);
        } else {
          v_t_247 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, v_width_246);
        V t_2 = v_e_242;
        V t_3 = heff_intSub(v_n_243, v_t_247);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_e_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffset16(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}); V a_1 = heff_dup(v_params_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_246}); V a_1 = v_params_241; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2417;
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_2410 = v_field_245;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_JNull: {
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2412 = heff_field(v_it1_2410, 0);
          heff_take_n(v_it1_2410, 1ULL, 1);
          v_t_2417 = v_i_2412;
          break;
        }
        case TAG_JFloat: {
          double v_x_2413 = heff_tflat_f64(v_it1_2410, 0);
          heff_take_na(v_it1_2410, 0ULL, 1);
          v_t_2417 = heff_floor_f64(v_x_2413);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2410);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2417 = MK_INT(0LL);
      }
      V v_t_2425;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_it1_2418 = v_field_249;
        switch (heff_tag_of(v_it1_2418)) {
        case TAG_JNull: {
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2420 = heff_field(v_it1_2418, 0);
          heff_take_n(v_it1_2418, 1ULL, 1);
          v_t_2425 = v_i_2420;
          break;
        }
        case TAG_JFloat: {
          double v_x_2421 = heff_tflat_f64(v_it1_2418, 0);
          heff_take_na(v_it1_2418, 0ULL, 1);
          v_t_2425 = heff_floor_f64(v_x_2421);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2418);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2425 = MK_INT(0LL);
      }
      return (g_heff_2elsp_2elsp_2eoffsetGo(v_src_240, v_t_2417, v_t_2425, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetIn(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_24dps_entry, 3, 0};

V g_heff_2elsp_2elsp_2elinesFrom_24dps(V v_src_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_d_243 = heff_strLength_lent(v_src_240, 0);
    V v_j_244 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str0), v_src_240, v_i_241, 1);
    V v_t_245;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_t_245 = v_d_243;
    } else {
      heff_drop(v_d_243);
      v_t_245 = v_j_244;
    }
    V v_t_246 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_245, 4)});
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_d_249 = heff_strLength_lent(v_src_240, 0);
    V v_j_2410 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str1), v_src_240, v_i_241, 5);
    V v_t_2411;
    if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
      heff_drop(v_j_2410);
      v_t_2411 = v_d_249;
    } else {
      heff_drop(v_d_249);
      v_t_2411 = v_j_2410;
    }
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_t_2411, MK_INT(1LL));
    V t_2 = v_cell_247;
    v_src_240 = t_0;
    v_i_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str1, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 15, "codeActionKinds");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 18, "codeActionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 25, "documentHighlightProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str20, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str21, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str22, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str23, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str24, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10)}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11)}), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str20), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str21), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str22)})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str23), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str24), v_t_2425}), v_t_2429});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_r_241; V a_1 = v_rs_242; V r_ = (g_list_2ekeepIf_24s689992630x418898235(a_0, a_1)); heff_drop(v_r_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubRoots_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam0, 3, 0};
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_entry, 5, 0};

V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747(V v_e_240, V v_x1_241, V v_x2_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_x2_242);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Just: {
    V v_f_245 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nothing: {
      heff_drop(v_e_240);
      heff_drop(v_z_243);
      heff_drop(v_f_245);
      return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_text_246 = heff_field(v_x2_242, 0);
      heff_take_n(v_x2_242, 1ULL, 1);
      V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_f_245));
      V v_c_248 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_247; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_247); r_; });
      V v_t_249 = (g_exception_2eattempted(v_e_240));
      V v_c_2413 = heff_tr(heff_call(v_c_248, 2, (V[]){v_t_249, ((V)&g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam0_clo)}));
      return heff_tail(v_c_2413, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam1, 1, 2, (V[]){v_z_244, v_text_246})});
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_text_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    heff_drop(v_text_246);
    V f_ = v_z_244;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2416 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2417 = heff_bool(heff_strEq_c_lent(v_y_2416, v_text_246, 0));
    heff_drop(v_text_246);
    heff_drop(v_y_2416);
    V f_ = v_z_244;
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_str0, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_str1, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_str2, 31, "textDocument/publishDiagnostics");
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam3, 1, 0};
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam8(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_entry, 3, 0};

V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(V v_e_240, V v_st_241, V v_f_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_f_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_d_246 = v_field_245;
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam0, 2, 4, (V[]){v_e_240, v_st_241, v_f_242, v_d_246});
    } else {
      heff_drop(v_e_240);
      heff_drop(v_f_242);
      heff_drop(v_field_245);
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam8, 2, 1, (V[]){v_st_241});
    }
  }
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_d_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195(v_e_240, v_st_241, v_f_242, v_d_246, v_hd_2410, v_k_2411));
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam3(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam1(V self, V *args) {
  V v_use_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_d_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_use_249;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam2, 2, 4, (V[]){v_e_240, v_st_241, v_f_242, v_d_246});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam3_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_a_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = v_a_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_program_2426 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_rec_n(2, shape_text__program, (V[]){heff_get_n(v_d_246, 1, 2), v_program_2426});
  V v_c_2434 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_241, 1), v_f_242, v_t_2433));
  V v_due_2435 = heff_take_field(v_st_241, 2);
  V v_project_2436 = heff_take_field(v_st_241, 3);
  V v_watch_2437 = heff_take_field(v_st_241, 4);
  V v_shutdown_2438 = heff_take_field(v_st_241, 5);
  V v_lib_2439 = heff_take_field(v_st_241, 6);
  V v_t_2440 = ({ V rv_1 = v_c_2434; V rv_2 = v_due_2435; V rv_3 = v_project_2436; V rv_4 = v_watch_2437; V rv_5 = v_shutdown_2438; V rv_6 = v_lib_2439; V rr_ = heff_rec_reuse_nf(v_st_241, 1ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_k_248;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_diags_2425 = heff_take_field(v_x_2424, 1);
  V v_program_2426 = heff_get_n(v_x_2424, 0, 2);
  V v_t_2427 = heff_tag_n(TAG_JString, 1, (V[]){heff_dup(heff_rfield(v_d_246, 0))});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_str0), heff_tag_n(TAG_JArray, 1, (V[]){v_diags_2425})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_str1), v_t_2427}), v_t_2429});
  V v_c_2431 = heff_tr(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085(v_e_240, ((V)&g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430})));
  V f_ = v_c_2431;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam7, 1, 5, (V[]){v_d_246, v_program_2426, v_st_241, v_f_242, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_d_246 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2423 = heff_tr(heff_call(((V)&g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_clo), 5, (V[]){heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_f_242), heff_dup(v_d_246), v_why_2419}));
    break;
  }
  case TAG_Right: {
    V v_a_2420 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2423 = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam5, 2, 1, (V[]){v_a_2420});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_t_2423;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam6, 1, 6, (V[]){v_d_246, v_e_240, v_hd_247, v_st_241, v_f_242, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_d_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam1, 1, 4, (V[]){heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_f_242), heff_dup(v_d_246)})})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_247), heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam4, 1, 6, (V[]){v_e_240, v_st_241, v_f_242, v_d_246, v_hd_247, v_k_248})));
}
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_lam8(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_entry, 3, 0};

V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958(V v_e_240, V v_st_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam0, 2, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_x21_246 = heff_field(v_x2_242, 0);
    V v_rest_247 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_MkPair: {
      V v_f_249 = heff_field(v_x21_246, 1);
      V v_c_2410 = (g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(heff_dup(v_e_240), v_st_241, heff_dup(v_f_249), NTAG(TAG_Nothing)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam1, 2, 3, (V[]){v_c_2410, v_e_240, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(2, shape_st__program, (V[]){v_st_241, NTAG(TAG_Nil)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_program_2415 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2418 = heff_take_field(v_x_2417, 0);
  V v_program_2419 = heff_get_n(v_x_2417, 1, 2);
  V v_st_2420 = v_st_2418;
  V v_program_2421 = (g_prelude_2e_2b_2b(v_program_2415, v_program_2419));
  V f_ = v_k_2412;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_2420, v_program_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_247 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414 = heff_take_field(v_x_2413, 0);
  V v_program_2415 = heff_get_n(v_x_2413, 1, 2);
  V v_c_2416 = ({ V a_0 = v_e_240; V a_1 = v_st_2414; V a_2 = v_rest_247; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958(a_0, a_1, a_2)); heff_drop(v_rest_247); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam3, 1, 2, (V[]){v_program_2415, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_lam2, 1, 4, (V[]){v_e_240, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str0, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str1, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str2, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str3, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str5, 8, "location");
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam1, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_entry, 4, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711(V v_e_240, V v_st_241, V v_c_242, V v_y_243) {
top: ;
  V v_name_244 = heff_take_field(v_y_243, 0);
  V v_kind_245 = heff_take_field(v_y_243, 1);
  V v_selection_246 = heff_get_n(v_y_243, 3, 5);
  V v_path_247 = heff_take_field(v_c_242, 1);
  V v_module_248 = heff_take_field(v_c_242, 0);
  V v_source_249 = heff_get_n(v_c_242, 3, 14);
  V v_p_2410 = v_path_247;
  HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2423;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_e_240);
      heff_drop(v_p_2410);
      V v_d_2414 = v_field_2413;
      v_c_2423 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam0, 2, 1, (V[]){v_d_2414});
    } else {
      heff_drop(v_field_2413);
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_2410, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam1_clo)})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
      v_c_2423 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam2, 2, 6, (V[]){v_c_2423, v_name_244, v_kind_245, v_module_248, v_source_249, v_selection_246});
}
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_d_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_get_n(v_d_2414, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  return v_u_2417;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_name_244 = heff_env(self)[0];
  V v_kind_245 = heff_env(self)[1];
  V v_module_248 = heff_env(self)[2];
  V v_source_249 = heff_env(self)[3];
  V v_selection_246 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str0), heff_tag_n(TAG_JString, 1, (V[]){v_name_244})});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_245})});
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str2), heff_tag_n(TAG_JString, 1, (V[]){v_module_248})});
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str3), heff_tag_n(TAG_JString, 1, (V[]){v_x_2426})});
  V v_t_2431 = ({ V a_0 = v_source_249; V a_1 = v_selection_246; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_249); r_; });
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str4), v_t_2431}), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_str5), v_t_2433}), NTAG(TAG_Nil)});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2434})});
  V v_x_2436 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2435})});
  V f_ = v_k_2425;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_name_244 = heff_env(self)[1];
  V v_kind_245 = heff_env(self)[2];
  V v_module_248 = heff_env(self)[3];
  V v_source_249 = heff_env(self)[4];
  V v_selection_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_lam3, 1, 6, (V[]){v_name_244, v_kind_245, v_module_248, v_source_249, v_selection_246, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam2, 1, 0};
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_entry, 3, 0};

V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734(V v_e_240, V v_st_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_e_247 = heff_dup(v_e_240);
    V v_st_248 = heff_dup(v_st_241);
    V v_o_249 = v_o_245;
    V v_path_2410 = heff_take_field(v_o_249, 0);
    V v_source_2411 = heff_take_field(v_o_249, 1);
    V v_span_2412 = heff_get_n(v_o_249, 2, 4);
    V v_p_2413 = v_path_2410;
    HeffT2 v_t_2414 = ({ V b_0 = heff_get_n(v_st_248, 0, 7); V a_1 = v_p_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2426;
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_e_247);
        heff_drop(v_p_2413);
        V v_d_2417 = v_field_2416;
        v_c_2426 = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam1, 2, 1, (V[]){v_d_2417});
      } else {
        heff_drop(v_field_2416);
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_PathUri, 2, (V[]){v_p_2413, ((V)&g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam2_clo)})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
        v_c_2426 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_247, heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})}));
      }
    }
    V v_c_2434 = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam3, 2, 3, (V[]){v_c_2426, v_source_2411, v_span_2412});
    return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam5, 2, 4, (V[]){v_c_2434, v_e_240, v_st_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_d_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_get_n(v_d_2417, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam2(V self, V *args) {
  V v_u_2420 = args[0];
  return v_u_2420;
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_source_2411 = heff_env(self)[0];
  V v_span_2412 = heff_env(self)[1];
  V v_k_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2429})});
  V v_t_2431 = ({ V a_0 = v_source_2411; V a_1 = v_span_2412; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_2411); r_; });
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_str1), v_t_2431}), NTAG(TAG_Nil)});
  V v_x_2433 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_t_2432})});
  V f_ = v_k_2428;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_source_2411 = heff_env(self)[1];
  V v_span_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam4, 1, 3, (V[]){v_source_2411, v_span_2412, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2437, v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2435 = heff_env(self)[3];
  V v_k_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2438 = (g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734(v_e_240, v_st_241, v_rest_246));
  V f_ = v_c_2438;
  heff_room[0] = v_hd_2435;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam7, 1, 2, (V[]){v_k_2436, v_x_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam5(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2434;
  args[0] = heff_dup(v_hd_2435);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_lam6, 1, 5, (V[]){v_e_240, v_st_241, v_rest_246, v_hd_2435, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str1, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str3, 36, "` would make heff fail elaborating (");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str4, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str5, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str6, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str7, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str8, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str9, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str10, 60, "` is already a name some of these occurrences would refer to");
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam11(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam11, 3, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam17(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam17, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_entry, 4, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955(V v_e_240, V v_st_241, V v_t_242, V v_new_243) {
top: ;
  V v_e_244 = heff_dup(v_e_240);
  V v_st_245 = heff_dup(v_st_241);
  V v_t_246 = heff_dup(v_t_242);
  V v_target_247 = heff_take_field(v_t_246, 1);
  V v_name_248 = heff_take_field(v_t_246, 2);
  V v_path_249 = heff_get_n(v_t_246, 0, 4);
  V v_new_2410 = heff_dup(v_new_243);
  V v_t_2411 = heff_get_n(v_target_247, 2, 3);
  V v_c_2426;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    V v_t_2412 = v_name_248;
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_new_2410, NTAG(TAG_Nil)});
    V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2413})});
    v_c_2426 = (g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(v_e_244, v_st_245, v_path_249, v_t_2414));
    break;
  }
  case TAG_Just: {
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    HeffT2 v_t_2416 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_245, 1), v_path_249));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_e_244);
        heff_drop(v_name_248);
        heff_drop(v_path_249);
        heff_drop(v_new_2410);
        heff_drop_cell(v_ru_24t_2411_24Just, 1);
        V v_e_2419 = v_field_2418;
        v_c_2426 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam0, 2, 2, (V[]){v_st_245, v_e_2419});
      } else {
        heff_drop(v_field_2418);
        V v_t_2423 = v_name_248;
        V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_new_2410, NTAG(TAG_Nil)});
        V v_t_2425 = heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2424})});
        v_c_2426 = (g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(v_e_244, v_st_245, v_path_249, v_t_2425));
      }
    }
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam1, 2, 5, (V[]){v_c_2426, v_t_242, v_st_241, v_e_240, v_new_243});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam0(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_st_245 = heff_env(self)[0];
  V v_e_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2420);
  V v_t_2422 = heff_rec_n(2, shape_st__program, (V[]){v_st_245, heff_get_n(v_e_2419, 1, 2)});
  V f_ = v_k_2421;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam3(V self, V *args) {
  V v_p_2433 = args[0];
  V v_os_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2434 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2433, v_os_2430));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2433, v_os_2434});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam7(V self, V *args) {
  V v_p_2448 = args[0];
  V v_os_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2449 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2448, v_os_2445));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2448, v_os_2449});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam8(V self, V *args) {
  V v_b_2451 = args[0];
  V v_new_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_path_2452 = heff_take_field(v_b_2451, 0);
  V v_occurrences_2453 = heff_get_n(v_b_2451, 1, 2);
  V v_os_2454 = v_occurrences_2453;
  V v_t_2457;
  switch (heff_tag_of(v_os_2454)) {
  case TAG_Nil: {
    v_t_2457 = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2455 = heff_dup(heff_field(v_os_2454, 0));
    v_t_2457 = heff_get_n(v_x_2455, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_2454);
  }
  V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_2454));
  V v_t_2459 = ({ V b_0 = MK_INT(0LL); V a_1 = v_new_243; V a_2 = v_t_2457; V a_3 = v_t_2458; V r_ = (g_list_2efoldl_24s198101905x967505038(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2458); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2452, v_t_2459});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam9(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_q_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2465);
  V v_t_2469;
  switch (heff_tag_of(v_q_2464)) {
  case TAG_MkPair: {
    V v_y_2468 = heff_field(v_q_2464, 1);
    heff_take_n(v_q_2464, 2ULL, 2);
    v_t_2469 = v_y_2468;
    break;
  }
  default: heff_nomatch(v_q_2464);
  }
  V f_ = v_k_2466;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam10(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_d_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2474);
  V v_t_2476 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2473, 1, 2)});
  V f_ = v_k_2475;
  args[0] = v_t_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam11(V self, V *args) {
  V v_x_2480 = args[0];
  V v_hd_2481 = args[1];
  V v_k_2482 = args[2];
  heff_drop(v_hd_2481);
  V f_ = v_k_2482;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2480});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam13(V self, V *args) {
  V v_x_2486 = args[0];
  V v_k_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2489;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Left: {
    heff_take_n(v_x_2486, 0ULL, 1);
    v_t_2489 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2488 = heff_field(v_x_2486, 0);
    V v_ru_24x_2486_24Right = heff_take_reuse_n(v_x_2486, 1ULL, 1);
    v_t_2489 = heff_tag_at_n(v_ru_24x_2486_24Right, TAG_Just, 1, (V[]){v_y_2488});
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V f_ = v_k_2485;
  args[0] = v_t_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam12(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_c_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2483;
  args[0] = v_hd_2484;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam13, 1, 1, (V[]){v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam6(V self, V *args) {
  V v_p_2444 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_new_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_os_2445 = heff_get_n(v_t_242, 3, 4);
  V v_t_2446 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2445)));
  V v_t_2447 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2446));
  V v_t_2450 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam7, 1, 1, (V[]){v_os_2445}), v_t_2447));
  V v_texts_2460 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam8, 1, 1, (V[]){v_new_243}), v_t_2450));
  HeffT2 v_t_2461 = ({ V a_0 = v_p_2444; V a_1 = v_texts_2460; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_texts_2460); r_; });
  {
    V v_field_2463 = v_t_2461.f[1];
    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
    if ((v_tag_2462 == ((int64_t)0ULL))) {
      heff_drop(v_p_2444);
      heff_drop_rec(v_st_241, 7);
      heff_drop(v_e_240);
      V v_q_2464 = v_field_2463;
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam9, 2, 1, (V[]){v_q_2464});
    } else {
      heff_drop(v_field_2463);
      HeffT2 v_t_2470 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_2444; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2472 = v_t_2470.f[1];
        int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
        if ((v_tag_2471 == ((int64_t)0ULL))) {
          heff_drop(v_p_2444);
          heff_drop(v_e_240);
          V v_d_2473 = v_field_2472;
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam10, 2, 1, (V[]){v_d_2473});
        } else {
          heff_drop(v_field_2472);
          V v_path_2477 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_2444));
          V v_c_2478 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2477; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2477); r_; });
          V v_t_2479 = (g_exception_2eattempted(v_e_240));
          V v_c_2483 = heff_tr(heff_call(v_c_2478, 2, (V[]){v_t_2479, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam11_clo)}));
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam12, 2, 1, (V[]){v_c_2483});
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam16(V self, V *args) {
  V v_s_2495 = args[0];
  V v_x_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_s_2495; V a_1 = v_x_2437; V r_ = (g_list_2eany_24s257543591x25063085(a_0, a_1)); heff_drop(v_x_2437); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam15(V self, V *args) {
  V v_x_2493 = args[0];
  V v_x_2491 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_hd_2439 = heff_env(self)[3];
  V v_k_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2494 = (g_heff_2elsp_2elsp_2enubSources(v_x_2491));
  return (g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524(v_e_240, heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam16, 1, 1, (V[]){v_x_2437}), heff_dup(g_std_2eordmap_2eempty_get()), v_x_2493, v_t_2494, v_hd_2439, v_k_2440));
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam14(V self, V *args) {
  V v_x_2491 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_lib_2441 = heff_env(self)[1];
  V v_f_2442 = heff_env(self)[2];
  V v_hd_2439 = heff_env(self)[3];
  V v_x_2437 = heff_env(self)[4];
  V v_k_2440 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2492 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), v_lib_2441, v_f_2442));
  V f_ = v_c_2492;
  heff_room[0] = heff_dup(v_hd_2439);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam15, 1, 5, (V[]){v_x_2491, v_e_240, v_x_2437, v_hd_2439, v_k_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam5(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_new_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_lib_2441 = heff_dup(heff_rfield(v_st_241, 6));
  V v_f_2442 = heff_dup(heff_rfield(v_t_242, 0));
  V v_t_2443 = (g_heff_2elsp_2elsp_2enubPaths(heff_dup(v_x_2437)));
  V v_c_2490 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam6, 1, 4, (V[]){v_t_242, v_new_243, v_st_241, heff_dup(v_e_240)}); V a_2 = heff_dup(v_lib_2441); V a_3 = v_t_2443; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(a_0, a_1, a_2, a_3)); heff_drop(v_t_2443); r_; });
  V f_ = v_c_2490;
  args[0] = heff_dup(v_hd_2439);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam14, 1, 6, (V[]){v_e_240, v_lib_2441, v_f_2442, v_hd_2439, v_x_2437, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam17(V self, V *args) {
  V v_r_2496 = args[0];
  return v_r_2496;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam4(V self, V *args) {
  V v_use_2438 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_new_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_use_2438;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam5, 2, 5, (V[]){v_st_241, v_t_242, v_x_2437, v_e_240, v_new_243});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam17_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam19(V self, V *args) {
  V v_c_24112 = args[0];
  V v_x_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_c_24112; V a_1 = v_x_2437; V r_ = (g_list_2eany_24s1836353438x580818415(a_0, a_1)); heff_drop(v_x_2437); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam20(V self, V *args) {
  V v_c_24116 = args[0];
  V v_x_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_c_24116; V a_1 = v_x_2437; V r_ = (g_list_2eany_24s1836353438x580818415(a_0, a_1)); heff_drop(v_x_2437); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam18(V self, V *args) {
  V v_x_24102 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_new_243 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_x_2437 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_24131;
  switch (heff_tag_of(v_x_24102)) {
  case TAG_Left: {
    V v_x_24103 = heff_field(v_x_24102, 0);
    V v_ru_24x_24102_24Left = heff_take_reuse_n(v_x_24102, 1ULL, 1);
    heff_drop(v_x_2437);
    V v_t_24104 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str1), heff_get_n(v_t_242, 2, 4));
    V v_t_24105 = heff_strAppend(heff_strAppend(v_t_24104, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str2)), v_new_243);
    V v_t_24106 = heff_strAppend(heff_strAppend(v_t_24105, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str3)), v_x_24103);
    V v_t_24107 = heff_tag_at_n(v_ru_24x_24102_24Left, TAG_Just, 1, (V[]){heff_strAppend(v_t_24106, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str4))});
    v_x_24131 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_2429, 0, 2), v_t_24107});
    break;
  }
  case TAG_Right: {
    V v_y_24108 = heff_field(v_x_24102, 0);
    V v_ru_24x_24102_24Right = heff_take_reuse_n(v_x_24102, 1ULL, 1);
    V v_before_24109 = heff_dup(v_x_2429);
    V v_t_24110 = v_t_242;
    V v_new_24111 = v_new_243;
    V v_program_24113 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam19, 1, 1, (V[]){heff_dup(v_x_2437)}), heff_get_n(v_x_2429, 1, 2)));
    V v_t_24114 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24113));
    V v_errorsBefore_24115 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_24114; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_24114); r_; });
    V v_program_24117 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam20, 1, 1, (V[]){v_x_2437}), heff_dup(heff_rfield(v_y_24108, 0))));
    V v_t_24118 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24117));
    V v_errorsAfter_24119 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_24118; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_24118); r_; });
    V v_after_24120 = heff_get_n(v_y_24108, 0, 2);
    V v_t_24130;
    if (heff_intLt_c_lent(v_errorsBefore_24115, v_errorsAfter_24119, 0)) {
      heff_drop(v_after_24120);
      V v_t_24121 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str5), heff_get_n(v_t_24110, 2, 4));
      V v_t_24122 = heff_strAppend(heff_strAppend(v_t_24121, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str6)), v_new_24111);
      V v_t_24123 = heff_intShow(heff_intSub(v_errorsAfter_24119, v_errorsBefore_24115));
      V v_t_24124 = heff_strAppend(heff_strAppend(v_t_24122, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str7)), v_t_24123);
      v_t_24130 = heff_tag_at_n(v_ru_24x_24102_24Right, TAG_Just, 1, (V[]){heff_strAppend(v_t_24124, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str8))});
    } else {
      heff_drop(v_errorsBefore_24115);
      heff_drop(v_errorsAfter_24119);
      V v_t_24125 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_24110), heff_dup(v_new_24111)));
      V v_xs_24126 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_24120, v_t_24125, heff_dup(v_new_24111)));
      V v_x_24127 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24126; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_24126); r_; });
      V v_y_24128 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_24110, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (!heff_intEq_c_lent(v_x_24127, v_y_24128, 0)) {
        heff_drop(v_x_24127);
        heff_drop(v_y_24128);
        V v_t_24129 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str9), v_new_24111), ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_str10));
        v_t_24130 = heff_tag_at_n(v_ru_24x_24102_24Right, TAG_Just, 1, (V[]){v_t_24129});
      } else {
        heff_drop_cell(v_ru_24x_24102_24Right, 1);
        heff_drop(v_new_24111);
        heff_drop(v_x_24127);
        heff_drop(v_y_24128);
        v_t_24130 = NTAG(TAG_Nothing);
      }
    }
    v_x_24131 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_24109, 0, 2), v_t_24130});
    break;
  }
  default: heff_nomatch(v_x_24102);
  }
  V f_ = v_k_2428;
  args[0] = v_x_24131;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_new_243 = heff_env(self)[3];
  V v_hd_2427 = heff_env(self)[4];
  V v_k_2428 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_os_2430 = heff_dup(heff_rfield(v_t_242, 3));
  V v_t_2431 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2430)));
  V v_t_2432 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2431));
  V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam3, 1, 1, (V[]){v_os_2430}), v_t_2432));
  V v_t_2436 = (g_list_2emap_24s582709368x2113456071(v_t_2435));
  V v_x_2437 = ({ V a_0 = v_t_2436; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_2429, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2436); r_; });
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam4, 1, 5, (V[]){v_st_241, heff_dup(v_t_242), heff_dup(v_x_2437), heff_dup(v_e_240), heff_dup(v_new_243)})})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), v_hd_2427, heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam18, 1, 5, (V[]){v_t_242, v_new_243, v_x_2429, v_x_2437, v_k_2428})));
}
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam1(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_new_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_lam2, 1, 6, (V[]){v_t_242, v_st_241, v_e_240, v_new_243, v_hd_2427, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str0, 1, "=");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str1, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str2, 12, "prelude.Pair");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str3, 7, "Split `");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str4, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str6, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str7, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str9, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str10, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str12, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str13, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str14, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str15, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str17, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str18, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str19, 1, "(");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str20, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str21, 3, " = ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str22, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str23, 2, ", ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str24, 2, "{ ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str25, 2, " }");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str26, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str27, 12, "` into cases");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str28, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str29, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str30, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str31, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str32, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str33, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str34, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str35, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str36, 4, "edit");
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_entry, 9, 0};

V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862(V v_e_240, V v_st_241, V v_f_242, V v_uri_243, V v_program_244, V v_c_245, V v_off_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2465 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam0, 1, 2, (V[]){heff_dup(v_c_245), v_off_246}), heff_dup(heff_rfield(v_c_245, 4))));
  HeffT2 v_t_2466 = ({ V a_0 = v_t_2465; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2465); r_; });
  {
    V v_field_2468 = v_t_2466.f[1];
    int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
    if ((v_tag_2467 == ((int64_t)0ULL))) {
      V v_s_2469 = v_field_2468;
      V v_c_2470 = heff_dup(v_c_245);
      V v_s_2471 = heff_dup(v_s_2469);
      V v_t_2472 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_2470, 4)));
      V v_t_2473 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2472));
      HeffT2 v_t_2474 = ({ V a_0 = heff_dup(v_s_2471); V b_1 = heff_get_n(v_t_2473, 0, 2); HeffT2 r_ = (g_list_2efind_24s1338461068x888657721_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2490;
      {
        V v_field_2476 = v_t_2474.f[1];
        int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
        if ((v_tag_2475 == ((int64_t)0ULL))) {
          V v_l_2477 = v_field_2476;
          V v_t_2478 = heff_get_n(v_l_2477, 2, 3);
          switch (heff_tag_of(v_t_2478)) {
          case TAG_Nil: {
            heff_drop_rec(v_c_2470, 14);
            heff_drop_rec(v_s_2471, 5);
            v_t_2490 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_x_2479 = heff_field(v_t_2478, 0);
            heff_take_n(v_t_2478, 1ULL, 2);
            HeffT2 v_t_2481 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2470, heff_get_n(v_x_2479, 0, 2)));
            {
              V v_field_2483 = v_t_2481.f[1];
              int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
              if ((v_tag_2482 == ((int64_t)0ULL))) {
                V v_i_2484 = v_field_2483;
                V v_name_2485 = heff_take_field(v_i_2484, 1);
                V v_key_2486 = heff_take_field(v_i_2484, 2);
                V v_ty_2487 = heff_get_n(v_i_2484, 4, 5);
                if (heff_strEq_c(v_name_2485, heff_get_n(v_s_2471, 0, 5))) {
                  switch (heff_tag_of(v_key_2486)) {
                  case TAG_Nothing: {
                    V v_t_2488 = heff_tr(heff_call(v_ty_2487, 1, (V[]){NTAG(TAG_MkUnit)}));
                    v_t_2490 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2488});
                    break;
                  }
                  case TAG_Just: {
                    heff_take_n(v_key_2486, 0ULL, 1);
                    heff_drop(v_ty_2487);
                    v_t_2490 = NTAG(TAG_Nothing);
                    break;
                  }
                  default: heff_nomatch(v_key_2486);
                  }
                } else {
                  heff_drop(v_key_2486);
                  heff_drop(v_ty_2487);
                  v_t_2490 = NTAG(TAG_Nothing);
                }
              } else {
                heff_drop_rec(v_s_2471, 5);
                heff_drop(v_field_2483);
                v_t_2490 = NTAG(TAG_Nothing);
              }
            }
            break;
          }
          default: heff_nomatch(v_t_2478);
          }
        } else {
          heff_drop_rec(v_c_2470, 14);
          heff_drop_rec(v_s_2471, 5);
          heff_drop(v_field_2476);
          v_t_2490 = NTAG(TAG_Nothing);
        }
      }
      V v_c_2494;
      switch (heff_tag_of(v_t_2490)) {
      case TAG_Nothing: {
        v_c_2494 = (g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223(v_e_240, v_st_241, v_f_242, heff_dup(v_program_244), heff_dup(v_c_245), heff_dup(v_s_2469)));
        break;
      }
      case TAG_Just: {
        V v_t_2491 = heff_field(v_t_2490, 0);
        heff_take_n(v_t_2490, 1ULL, 1);
        heff_drop(v_e_240);
        heff_drop(v_st_241);
        heff_drop(v_f_242);
        v_c_2494 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam3, 2, 1, (V[]){v_t_2491});
        break;
      }
      default: heff_nomatch(v_t_2490);
      }
      return heff_tail(v_c_2494, 2, (V[]){v_z_247, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam4, 1, 5, (V[]){v_program_244, v_c_245, v_s_2469, v_uri_243, v_z_248})});
    } else {
      heff_drop(v_e_240);
      heff_drop(v_st_241);
      heff_drop(v_f_242);
      heff_drop(v_uri_243);
      heff_drop(v_program_244);
      heff_drop_rec(v_c_245, 14);
      heff_drop(v_z_247);
      heff_drop(v_field_2468);
      return heff_tail(v_z_248, 1, (V[]){NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam2(V self, V *args) {
  V v_p_2427 = args[0];
  V v_off_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_2411; V a_1 = v_p_2427; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_p_2427); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam1(V self, V *args) {
  V v_e_2420 = args[0];
  V v_off_2411 = heff_env(self)[0];
  V v_src_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_e_2420)) {
  case TAG_At: {
    V v_x31_2421 = heff_field(v_e_2420, 0);
    V v_sp_2422 = heff_field(v_e_2420, 1);
    V v_ru_24e_2420_24At = heff_take_reuse_n(v_e_2420, 3ULL, 2);
    switch (heff_tag_of(v_x31_2421)) {
    case TAG_MkEquation: {
      V v_ps_2425 = heff_field(v_x31_2421, 2);
      heff_take_n(v_x31_2421, 4ULL, 4);
      V v_t_2428 = (g_list_2emap_24tok2(v_ru_24e_2420_24At, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam2, 1, 1, (V[]){v_off_2411}), heff_dup(v_ps_2425)));
      HeffT2 v_t_2429 = ({ V a_0 = v_t_2428; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2428); r_; });
      {
        V v_field_2431 = v_t_2429.f[1];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          V v_v_2432 = v_field_2431;
          V v_src_2433 = v_src_2410;
          V v_v_2434 = v_v_2432;
          V v_name_2435 = heff_take_field(v_v_2434, 0);
          V v_span_2436 = heff_get_n(v_v_2434, 1, 2);
          V v_sp_2437 = v_sp_2422;
          V v_start_2438 = heff_take_field(v_sp_2437, 0);
          V v_end_2439 = heff_get_n(v_sp_2437, 1, 2);
          V v_ps_2440 = v_ps_2425;
          V v_from_2441 = ({ V a_0 = heff_dup(v_start_2438); V a_1 = v_ps_2440; V r_ = (g_list_2efoldl_24s661788424x2062432904(a_0, a_1)); heff_drop(v_ps_2440); r_; });
          V v_j_2442 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str0), v_src_2433, v_from_2441, 5);
          if (heff_intLt_c_lent(v_j_2442, MK_INT(0LL), 2)) {
            heff_drop(v_src_2433);
            heff_drop(v_name_2435);
            heff_drop(v_span_2436);
            heff_drop(v_start_2438);
            heff_drop(v_end_2439);
            heff_drop(v_j_2442);
            return NTAG(TAG_Nothing);
          } else {
            V v_t_2443 = (g_heff_2elsp_2esplit_2elineStart(v_src_2433, heff_dup(v_start_2438)));
            V v_d_2444 = heff_strLength_lent(v_src_2433, 0);
            V v_j_2445 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str1), v_src_2433, v_end_2439, 5);
            V v_t_2446;
            if (heff_intLt_c_lent(v_j_2445, MK_INT(0LL), 2)) {
              heff_drop(v_j_2445);
              v_t_2446 = v_d_2444;
            } else {
              heff_drop(v_d_2444);
              v_t_2446 = v_j_2445;
            }
            V v_t_2447 = ({ V a_0 = v_src_2433; V a_1 = heff_intSub(heff_dup(v_start_2438), v_t_2443); V a_2 = v_t_2446; V r_ = (g_heff_2elsp_2esplit_2eextentEnd(a_0, a_1, a_2)); heff_drop(v_src_2433); r_; });
            V v_t_2448 = heff_rec_n(5, shape_name__span__start__equals__end, (V[]){v_name_2435, v_span_2436, v_start_2438, heff_intAdd(v_j_2442, MK_INT(1LL)), v_t_2447});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2448});
          }
        } else {
          heff_drop(v_src_2410);
          heff_drop(v_sp_2422);
          heff_drop(v_ps_2425);
          heff_drop(v_field_2431);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_x31_2421);
    }
  }
  default: return heff_nomatch(v_e_2420);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_off_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_src_2410 = heff_get_n(v_c_245, 3, 14);
  V v_off_2411 = v_off_246;
  V v_x3_2412 = v_d_249;
  switch (heff_tag_of(v_x3_2412)) {
  case TAG_At: {
    V v_x31_2413 = heff_field(v_x3_2412, 0);
    V v_ru_24x3_2412_24At = heff_take_reuse_n(v_x3_2412, 1ULL, 2);
    switch (heff_tag_of(v_x31_2413)) {
    case TAG_DeclEquations: {
      V v_eqs_2419 = heff_field(v_x31_2413, 4);
      heff_take_n(v_x31_2413, 16ULL, 5);
      V v_t_2449 = (g_list_2emap_24tok2(v_ru_24x3_2412_24At, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam1, 1, 2, (V[]){v_off_2411, v_src_2410}), v_eqs_2419));
      return ({ V a_0 = v_t_2449; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2449); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x31_2413, 0ULL, 5);
      heff_drop(v_src_2410);
      heff_drop(v_off_2411);
      heff_drop_cell(v_ru_24x3_2412_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x31_2413, 0ULL, 4);
      heff_drop(v_src_2410);
      heff_drop(v_off_2411);
      heff_drop_cell(v_ru_24x3_2412_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x31_2413, 0ULL, 3);
      heff_drop(v_src_2410);
      heff_drop(v_off_2411);
      heff_drop_cell(v_ru_24x3_2412_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x31_2413, 0ULL, 2);
      heff_drop(v_src_2410);
      heff_drop(v_off_2411);
      heff_drop_cell(v_ru_24x3_2412_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x31_2413, 0ULL, 1);
      heff_drop(v_src_2410);
      heff_drop(v_off_2411);
      heff_drop_cell(v_ru_24x3_2412_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_2413);
    }
  }
  default: return heff_nomatch(v_x3_2412);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam3(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_t_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2492);
  V f_ = v_k_2493;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2491});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam5(V self, V *args) {
  V v_c2_24120 = args[0];
  V v_k_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24121 = ({ V a_0 = v_k_24118; V a_1 = heff_rfield(v_c2_24120, 7); HeffT2 r_ = (g_list_2efind_24s1953031388x2120050076_24cpr(a_0, a_1)); heff_drop(v_k_24118); r_; });
  {
    V v_field_24123 = v_t_24121.f[1];
    int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
    if ((v_tag_24122 == ((int64_t)0ULL))) {
      V v_o_24124 = v_field_24123;
      V v_t_24125 = (g_heff_2elsp_2esplit_2edeclsOf(v_c2_24120));
      return ({ V a_0 = v_o_24124; V a_1 = v_t_24125; V r_ = (g_list_2efind_24s633938771x532201311(a_0, a_1)); heff_drop(v_t_24125); r_; });
    } else {
      heff_drop_rec(v_c2_24120, 14);
      heff_drop(v_field_24123);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam7(V self, V *args) {
  V v_o_24245 = args[0];
  V v_c_24244 = heff_env(self)[0];
  V v_g_24243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24246 = (g_heff_2elsp_2esplit_2eisOperator(heff_rfield(v_o_24245, 0)));
  if ((heff_dup(v_t_24246) == NTAG(TAG_True))) {
    heff_drop(v_t_24246);
    V v_x_24247 = heff_get_n(v_o_24245, 0, 2);
    HeffT2 v_t_24248 = ({ V a_0 = v_x_24247; V b_1 = heff_get_n(v_c_24244, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_24250 = v_t_24248.f[1];
      int64_t v_tag_24249 = ((int64_t)v_t_24248.f[0]);
      if ((v_tag_24249 == ((int64_t)0ULL))) {
        V v_o_24251 = v_field_24250;
        HeffT3 v_t_24252 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_24243, v_x_24247));
        {
          V v_field_24254 = v_t_24252.f[1];
          V v_field_24255 = v_t_24252.f[2];
          int64_t v_tag_24253 = ((int64_t)v_t_24252.f[0]);
          if ((v_tag_24253 == ((int64_t)0ULL))) {
            heff_drop_rec(v_o_24251, 2);
            heff_drop(v_field_24255);
            V v_x_24256 = v_field_24254;
            heff_drop(v_x_24256);
            return NTAG(TAG_False);
          } else {
            if ((v_tag_24253 == ((int64_t)1ULL))) {
              heff_drop_rec(v_o_24251, 2);
              heff_drop(v_field_24254);
              heff_drop(v_field_24255);
              return NTAG(TAG_False);
            } else {
              if ((v_tag_24253 == ((int64_t)2ULL))) {
                V v_k2_24257 = v_field_24254;
                V v_x_24258 = v_field_24255;
                heff_drop(v_x_24258);
                V v_ret_24bool = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_o_24251, 1)), heff_dup(v_k2_24257)));
                heff_drop_rec(v_o_24251, 2);
                heff_drop(v_k2_24257);
                return v_ret_24bool;
              } else {
                heff_drop_rec(v_o_24251, 2);
                heff_drop(v_field_24254);
                heff_drop(v_field_24255);
                return NTAG(TAG_False);
              }
            }
          }
        }
      } else {
        heff_drop(v_g_24243);
        heff_drop(v_x_24247);
        heff_drop(v_field_24250);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop_rec(v_o_24245, 2);
    heff_drop_rec(v_c_24244, 14);
    heff_drop(v_g_24243);
    heff_drop(v_t_24246);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam8(V self, V *args) {
  V v_d_24261 = args[0];
  V v_g_24242 = heff_env(self)[0];
  V v_x_24241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_g_24262 = v_g_24242;
  V v_c_24263 = v_x_24241;
  V v_x3_24264 = v_d_24261;
  switch (heff_tag_of(v_x3_24264)) {
  case TAG_At: {
    V v_x31_24265 = heff_field(v_x3_24264, 0);
    V v_ru_24x3_24264_24At = heff_take_reuse_n(v_x3_24264, 1ULL, 2);
    switch (heff_tag_of(v_x31_24265)) {
    case TAG_DeclEquations: {
      V v_op_24267 = heff_field(v_x31_24265, 0);
      V v_x315_24271 = heff_field(v_x31_24265, 4);
      heff_take_n(v_x31_24265, 17ULL, 5);
      switch (heff_tag_of(v_x315_24271)) {
      case TAG_Nil: {
        heff_drop(v_g_24262);
        heff_drop_rec(v_c_24263, 14);
        heff_drop_cell(v_ru_24x3_24264_24At, 2);
        heff_drop(v_op_24267);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_e_24272 = heff_field(v_x315_24271, 0);
        V v_x3152_24273 = heff_field(v_x315_24271, 1);
        heff_take_n(v_x315_24271, 3ULL, 2);
        switch (heff_tag_of(v_x3152_24273)) {
        case TAG_Nil: {
          V v_t_24274 = (g_heff_2elsp_2esplit_2eisOperator(v_op_24267));
          if ((heff_dup(v_t_24274) == NTAG(TAG_True))) {
            heff_drop(v_t_24274);
            HeffT2 v_t_24275 = ({ V a_0 = v_op_24267; V b_1 = heff_get_n(v_c_24263, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_24277 = v_t_24275.f[1];
              int64_t v_tag_24276 = ((int64_t)v_t_24275.f[0]);
              if ((v_tag_24276 == ((int64_t)0ULL))) {
                V v_o_24278 = v_field_24277;
                HeffT3 v_t_24279 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_24262, heff_dup(v_op_24267)));
                {
                  V v_field_24281 = v_t_24279.f[1];
                  V v_field_24282 = v_t_24279.f[2];
                  int64_t v_tag_24280 = ((int64_t)v_t_24279.f[0]);
                  if ((v_tag_24280 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24x3_24264_24At, 2);
                    heff_drop(v_op_24267);
                    heff_drop(v_e_24272);
                    heff_drop_rec(v_o_24278, 2);
                    heff_drop(v_field_24282);
                    V v_x_24283 = v_field_24281;
                    heff_drop(v_x_24283);
                    return NTAG(TAG_Nothing);
                  } else {
                    if ((v_tag_24280 == ((int64_t)1ULL))) {
                      heff_drop_cell(v_ru_24x3_24264_24At, 2);
                      heff_drop(v_op_24267);
                      heff_drop(v_e_24272);
                      heff_drop_rec(v_o_24278, 2);
                      heff_drop(v_field_24281);
                      heff_drop(v_field_24282);
                      return NTAG(TAG_Nothing);
                    } else {
                      if ((v_tag_24280 == ((int64_t)2ULL))) {
                        V v_k2_24284 = v_field_24281;
                        V v_x_24285 = v_field_24282;
                        heff_drop(v_x_24285);
                        if (heff_strEq_c(heff_get_n(v_o_24278, 1, 2), v_k2_24284)) {
                          V v_t_24292;
                          switch (heff_tag_of(v_e_24272)) {
                          case TAG_At: {
                            V v_x11_24286 = heff_field(v_e_24272, 0);
                            heff_take_n(v_e_24272, 1ULL, 2);
                            switch (heff_tag_of(v_x11_24286)) {
                            case TAG_MkEquation: {
                              V v_ps_24290 = heff_field(v_x11_24286, 2);
                              V v_body_24291 = heff_field(v_x11_24286, 3);
                              heff_take_n(v_x11_24286, 12ULL, 4);
                              v_t_24292 = ({ V a_0 = v_ps_24290; V a_1 = v_body_24291; V r_ = (g_heff_2elsp_2esplit_2ealiasedTag(a_0, a_1)); heff_drop(v_body_24291); r_; });
                              break;
                            }
                            default: heff_nomatch(v_x11_24286);
                            }
                            break;
                          }
                          default: heff_nomatch(v_e_24272);
                          }
                          switch (heff_tag_of(v_t_24292)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24x3_24264_24At, 2);
                            heff_drop(v_op_24267);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_t_24293 = heff_field(v_t_24292, 0);
                            V v_ru_24t_24292_24Just = heff_take_reuse_n(v_t_24292, 1ULL, 1);
                            return heff_tag_at_n(v_ru_24t_24292_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x3_24264_24At, TAG_MkPair, 2, (V[]){v_t_24293, v_op_24267})});
                          }
                          default: return heff_nomatch(v_t_24292);
                          }
                        } else {
                          heff_drop_cell(v_ru_24x3_24264_24At, 2);
                          heff_drop(v_op_24267);
                          heff_drop(v_e_24272);
                          return NTAG(TAG_Nothing);
                        }
                      } else {
                        heff_drop_cell(v_ru_24x3_24264_24At, 2);
                        heff_drop(v_op_24267);
                        heff_drop(v_e_24272);
                        heff_drop_rec(v_o_24278, 2);
                        heff_drop(v_field_24281);
                        heff_drop(v_field_24282);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                }
              } else {
                heff_drop(v_g_24262);
                heff_drop_cell(v_ru_24x3_24264_24At, 2);
                heff_drop(v_op_24267);
                heff_drop(v_e_24272);
                heff_drop(v_field_24277);
                return NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_g_24262);
            heff_drop_rec(v_c_24263, 14);
            heff_drop_cell(v_ru_24x3_24264_24At, 2);
            heff_drop(v_op_24267);
            heff_drop(v_e_24272);
            heff_drop(v_t_24274);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x3152_24273, 0ULL, 2);
          heff_drop(v_g_24262);
          heff_drop_rec(v_c_24263, 14);
          heff_drop_cell(v_ru_24x3_24264_24At, 2);
          heff_drop(v_op_24267);
          heff_drop(v_e_24272);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x3152_24273);
        }
      }
      default: return heff_nomatch(v_x315_24271);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x31_24265, 0ULL, 5);
      heff_drop(v_g_24262);
      heff_drop_rec(v_c_24263, 14);
      heff_drop_cell(v_ru_24x3_24264_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x31_24265, 0ULL, 4);
      heff_drop(v_g_24262);
      heff_drop_rec(v_c_24263, 14);
      heff_drop_cell(v_ru_24x3_24264_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x31_24265, 0ULL, 3);
      heff_drop(v_g_24262);
      heff_drop_rec(v_c_24263, 14);
      heff_drop_cell(v_ru_24x3_24264_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x31_24265, 0ULL, 2);
      heff_drop(v_g_24262);
      heff_drop_rec(v_c_24263, 14);
      heff_drop_cell(v_ru_24x3_24264_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x31_24265, 0ULL, 1);
      heff_drop(v_g_24262);
      heff_drop_rec(v_c_24263, 14);
      heff_drop_cell(v_ru_24x3_24264_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_24265);
    }
  }
  default: return heff_nomatch(v_x3_24264);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam6(V self, V *args) {
  V v_acc_24240 = args[0];
  V v_x_24241 = args[1];
  V v_c_24238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_24242 = heff_get_n(heff_get_n(v_c_24238, 5, 14), 0, 10);
  V v_g_24243 = heff_dup(v_g_24242);
  V v_c_24244 = heff_dup(v_x_24241);
  V v_t_24259 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam7, 1, 2, (V[]){heff_dup(v_c_24244), v_g_24243}); V b_1 = heff_get_n(v_c_24244, 7, 14); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24312;
  if ((heff_dup(v_t_24259) == NTAG(TAG_True))) {
    heff_drop(v_t_24259);
    V v_t_24260 = (g_heff_2elsp_2esplit_2edeclsOf(heff_dup(v_x_24241)));
    V v_t_24311 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam8, 1, 2, (V[]){v_g_24242, v_x_24241}), v_t_24260));
    v_t_24312 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24311));
  } else {
    heff_drop(v_x_24241);
    heff_drop(v_g_24242);
    heff_drop(v_t_24259);
    v_t_24312 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_24312, v_acc_24240));
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam10(V self, V *args) {
  V v_a_24324 = args[0];
  V v_ps_24317 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_ps_24317; V a_1 = v_a_24324; V r_ = (g_heff_2elsp_2esplit_2ehintOf(a_0, a_1)); heff_drop(v_ps_24317); heff_drop(v_a_24324); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam9(V self, V *args) {
  V v_t_24319 = args[0];
  V v_ops_24313 = heff_env(self)[0];
  V v_ps_24317 = heff_env(self)[1];
  V v_taken_24316 = heff_env(self)[2];
  V v_s_24315 = heff_env(self)[3];
  V v_src_24314 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_name_24320 = heff_take_field(v_t_24319, 0);
  V v_args_24321 = heff_get_n(v_t_24319, 1, 2);
  V v_op_24322 = ({ V a_0 = v_name_24320; V a_1 = v_ops_24313; V r_ = (g_list_2elookup_24s1507486579x90027037(a_0, a_1)); heff_drop(v_ops_24313); r_; });
  V v_t_24323 = v_name_24320;
  V v_t_24325 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam10, 1, 1, (V[]){v_ps_24317}), v_args_24321));
  V v_xs_24326 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_24316, v_t_24325));
  switch (heff_tag_of(v_xs_24326)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_24315, 5);
    heff_drop(v_src_24314);
    heff_drop(v_op_24322);
    return v_t_24323;
  }
  case TAG_Cons: {
    V v_x1_24329 = v_op_24322;
    V v_t_24330 = v_t_24323;
    V v_xs_24331 = v_xs_24326;
    V v_p_24352;
    switch (heff_tag_of(v_x1_24329)) {
    case TAG_Nothing: {
      V v_t_24334;
      switch (heff_tag_of(v_xs_24331)) {
      case TAG_Nil: {
        v_t_24334 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_24332 = heff_field(v_xs_24331, 0);
        V v_xs_24333 = heff_field(v_xs_24331, 1);
        heff_take_n(v_xs_24331, 3ULL, 2);
        v_t_24334 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str6); V a_1 = v_x_24332; V a_2 = v_xs_24333; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24333); r_; });
        break;
      }
      default: heff_nomatch(v_xs_24331);
      }
      v_p_24352 = heff_strAppend(heff_strAppend(v_t_24330, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str7)), v_t_24334);
      break;
    }
    case TAG_Just: {
      V v_op_24335 = heff_field(v_x1_24329, 0);
      heff_take_n(v_x1_24329, 1ULL, 1);
      switch (heff_tag_of(v_xs_24331)) {
      case TAG_Nil: {
        heff_drop(v_op_24335);
        V v_t_24338;
        switch (heff_tag_of(v_xs_24331)) {
        case TAG_Nil: {
          v_t_24338 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_24336 = heff_field(v_xs_24331, 0);
          V v_xs_24337 = heff_field(v_xs_24331, 1);
          heff_take_n(v_xs_24331, 3ULL, 2);
          v_t_24338 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str9); V a_1 = v_x_24336; V a_2 = v_xs_24337; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24337); r_; });
          break;
        }
        default: heff_nomatch(v_xs_24331);
        }
        v_p_24352 = heff_strAppend(heff_strAppend(v_t_24330, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str10)), v_t_24338);
        break;
      }
      case TAG_Cons: {
        V v_a_24339 = heff_dup(heff_field(v_xs_24331, 0));
        V v_xs2_24340 = heff_dup(heff_field(v_xs_24331, 1));
        switch (heff_tag_of(v_xs2_24340)) {
        case TAG_Nil: {
          heff_drop(v_op_24335);
          heff_drop(v_a_24339);
          V v_t_24343;
          switch (heff_tag_of(v_xs_24331)) {
          case TAG_Nil: {
            v_t_24343 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str11);
            break;
          }
          case TAG_Cons: {
            V v_x_24341 = heff_field(v_xs_24331, 0);
            V v_xs_24342 = heff_field(v_xs_24331, 1);
            heff_take_n(v_xs_24331, 3ULL, 2);
            v_t_24343 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str12); V a_1 = v_x_24341; V a_2 = v_xs_24342; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24342); r_; });
            break;
          }
          default: heff_nomatch(v_xs_24331);
          }
          v_p_24352 = heff_strAppend(heff_strAppend(v_t_24330, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str13)), v_t_24343);
          break;
        }
        case TAG_Cons: {
          V v_b_24344 = heff_field(v_xs2_24340, 0);
          V v_xs22_24345 = heff_field(v_xs2_24340, 1);
          heff_take_n(v_xs2_24340, 3ULL, 2);
          switch (heff_tag_of(v_xs22_24345)) {
          case TAG_Nil: {
            heff_drop(v_t_24330);
            heff_drop_tag(v_xs_24331, 2);
            V v_t_24346 = heff_strAppend(heff_strAppend(v_a_24339, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str14)), v_op_24335);
            v_p_24352 = heff_strAppend(heff_strAppend(v_t_24346, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str15)), v_b_24344);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_xs22_24345, 0ULL, 2);
            heff_drop(v_op_24335);
            heff_drop(v_a_24339);
            heff_drop(v_b_24344);
            V v_t_24351;
            switch (heff_tag_of(v_xs_24331)) {
            case TAG_Nil: {
              v_t_24351 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str16);
              break;
            }
            case TAG_Cons: {
              V v_x_24349 = heff_field(v_xs_24331, 0);
              V v_xs_24350 = heff_field(v_xs_24331, 1);
              heff_take_n(v_xs_24331, 3ULL, 2);
              v_t_24351 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str17); V a_1 = v_x_24349; V a_2 = v_xs_24350; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24350); r_; });
              break;
            }
            default: heff_nomatch(v_xs_24331);
            }
            v_p_24352 = heff_strAppend(heff_strAppend(v_t_24330, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str18)), v_t_24351);
            break;
          }
          default: heff_nomatch(v_xs22_24345);
          }
          break;
        }
        default: heff_nomatch(v_xs2_24340);
        }
        break;
      }
      default: heff_nomatch(v_xs_24331);
      }
      break;
    }
    default: heff_nomatch(v_x1_24329);
    }
    V v_t_24353 = heff_get_n(heff_dup(heff_rfield(v_s_24315, 1)), 0, 2);
    if ((heff_intLt_c_lent(MK_INT(0LL), v_t_24353, 1) && ({ V v_t_24354 = heff_get_n(heff_dup(heff_rfield(v_s_24315, 1)), 0, 2); int c_ = ({ V v_t_24400 = heff_strByteAt(heff_dup(v_src_24314), heff_intSub(heff_dup(v_t_24354), MK_INT(1LL))); int c_ = ((heff_peek_word(v_t_24400) == ((int64_t)40ULL)) && ({ V v_t_24355 = heff_get_n(heff_dup(heff_rfield(v_s_24315, 1)), 1, 2); int c_ = ({ V v_t_24401 = heff_strByteAt_lent(v_src_24314, v_t_24355, 0); int c_ = (heff_peek_word(v_t_24401) == ((int64_t)41ULL)); heff_drop(v_t_24401); c_; }); heff_drop(v_t_24355); c_; })); heff_drop(v_t_24400); c_; }); heff_drop(v_t_24354); c_; }))) {
      heff_drop_rec(v_s_24315, 5);
      heff_drop(v_src_24314);
      heff_drop(v_t_24353);
      return v_p_24352;
    } else {
      heff_drop_rec(v_s_24315, 5);
      heff_drop(v_src_24314);
      heff_drop(v_t_24353);
      return heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str19), v_p_24352), ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str20));
    }
  }
  default: return heff_nomatch(v_xs_24326);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam4(V self, V *args) {
  V v_x_2495 = args[0];
  V v_program_244 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_s_2469 = heff_env(self)[2];
  V v_uri_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_24399;
  switch (heff_tag_of(v_x_2495)) {
  case TAG_Nothing: {
    heff_drop(v_program_244);
    heff_drop_rec(v_c_245, 14);
    heff_drop(v_s_2469);
    heff_drop(v_uri_243);
    v_x_24399 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_t_2496 = heff_field(v_x_2495, 0);
    V v_ru_24x_2495_24Just = heff_take_reuse_n(v_x_2495, 1ULL, 1);
    V v_program_2497 = v_program_244;
    V v_c_2498 = heff_dup(v_c_245);
    V v_s_2499 = v_s_2469;
    V v_ty_24100 = v_t_2496;
    V v_t_24101 = v_ty_24100;
    V v_t_24104;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24101, 0)))) {
      V v_c_24102 = heff_strByteAt_lent(v_t_24101, MK_INT(0LL), 2);
      if (((((int64_t)65ULL) <= heff_peek_word(v_c_24102)) && (heff_peek_word(v_c_24102) <= ((int64_t)90ULL)))) {
        heff_drop(v_c_24102);
        V v_x1_24103 = (g_heff_2elsp_2esplit_2earrowOutside(v_t_24101, MK_INT(0LL), MK_INT(0LL)));
        v_t_24104 = heff_bool(!(heff_dup(v_x1_24103) == NTAG(TAG_True)));
        heff_drop(v_x1_24103);
      } else {
        heff_drop(v_c_24102);
        v_t_24104 = NTAG(TAG_False);
      }
    } else {
      v_t_24104 = NTAG(TAG_False);
    }
    V v_t_24107;
    if ((heff_dup(v_t_24104) == NTAG(TAG_True))) {
      heff_drop(v_t_24104);
      V v_t_24105 = (g_heff_2elsp_2esplit_2enameEnd(v_t_24101, MK_INT(0LL)));
      v_t_24107 = heff_tag_at_n(v_ru_24x_2495_24Just, TAG_Just, 1, (V[]){heff_strSlice(v_t_24101, MK_INT(0LL), v_t_24105)});
    } else {
      heff_drop(v_t_24104);
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24101, 0)))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_t_24101, MK_INT(0LL), 2)) == ((int64_t)40ULL))) {
          V v_x1_24106 = ({ V a_0 = v_t_24101; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V r_ = (g_heff_2elsp_2esplit_2earrowOutside(a_0, a_1, a_2)); heff_drop(v_t_24101); r_; });
          if (!(heff_dup(v_x1_24106) == NTAG(TAG_True))) {
            heff_drop(v_x1_24106);
            v_t_24107 = heff_tag_at_n(v_ru_24x_2495_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str2)});
          } else {
            heff_drop_cell(v_ru_24x_2495_24Just, 1);
            heff_drop(v_x1_24106);
            v_t_24107 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24x_2495_24Just, 1);
          heff_drop(v_t_24101);
          v_t_24107 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24x_2495_24Just, 1);
        heff_drop(v_t_24101);
        v_t_24107 = NTAG(TAG_Nothing);
      }
    }
    V v_t_24369;
    switch (heff_tag_of(v_t_24107)) {
    case TAG_Nothing: {
      heff_drop(v_program_2497);
      heff_drop_rec(v_c_2498, 14);
      heff_drop_rec(v_s_2499, 5);
      v_t_24369 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_h_24108 = heff_field(v_t_24107, 0);
      V v_ru_24t_24107_24Just = heff_take_reuse_n(v_t_24107, 1ULL, 1);
      V v_program_24109 = heff_dup(v_program_2497);
      V v_c_24110 = heff_dup(v_c_2498);
      V v_x_24111 = v_h_24108;
      V v_t_24112 = heff_get_n(heff_get_n(v_c_24110, 5, 14), 0, 10);
      HeffT3 v_t_24113 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_t_24112, v_x_24111));
      V v_t_24224;
      {
        V v_field_24115 = v_t_24113.f[1];
        V v_field_24116 = v_t_24113.f[2];
        int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
        if ((v_tag_24114 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24t_24107_24Just, 1);
          heff_drop(v_program_24109);
          heff_drop(v_field_24116);
          V v_x_24117 = v_field_24115;
          heff_drop(v_x_24117);
          v_t_24224 = NTAG(TAG_Nothing);
        } else {
          if ((v_tag_24114 == ((int64_t)1ULL))) {
            heff_drop_cell(v_ru_24t_24107_24Just, 1);
            heff_drop(v_program_24109);
            heff_drop(v_field_24115);
            heff_drop(v_field_24116);
            v_t_24224 = NTAG(TAG_Nothing);
          } else {
            if ((v_tag_24114 == ((int64_t)2ULL))) {
              V v_k_24118 = v_field_24115;
              V v_x_24119 = v_field_24116;
              heff_drop(v_x_24119);
              V v_t_24126 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam5, 1, 1, (V[]){v_k_24118}), v_program_24109));
              HeffT2 v_t_24127 = ({ V a_0 = v_t_24126; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_24126); r_; });
              {
                V v_field_24129 = v_t_24127.f[1];
                int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
                if ((v_tag_24128 == ((int64_t)0ULL))) {
                  V v_d_24130 = v_field_24129;
                  switch (heff_tag_of(v_d_24130)) {
                  case TAG_At: {
                    V v_x11_24131 = heff_field(v_d_24130, 0);
                    V v_ru_24d_24130_24At = heff_take_reuse_n(v_d_24130, 1ULL, 2);
                    switch (heff_tag_of(v_x11_24131)) {
                    case TAG_DeclEquations: {
                      heff_take_n(v_x11_24131, 0ULL, 5);
                      heff_drop_cell(v_ru_24t_24107_24Just, 1);
                      heff_drop_cell(v_ru_24d_24130_24At, 2);
                      v_t_24224 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclDefine: {
                      V v_ps_24140 = heff_field(v_x11_24131, 2);
                      V v_body_24142 = heff_field(v_x11_24131, 4);
                      heff_take_n(v_x11_24131, 20ULL, 5);
                      V v_ps_24143 = (g_list_2emap_24s1170504272x1852564147(v_ps_24140));
                      V v_x2_24144 = v_body_24142;
                      switch (heff_tag_of(v_x2_24144)) {
                      case TAG_At: {
                        V v_x21_24145 = heff_field(v_x2_24144, 0);
                        heff_take_n(v_x2_24144, 1ULL, 2);
                        switch (heff_tag_of(v_x21_24145)) {
                        case TAG_EVar: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EImplicitVar: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENotationVar: {
                          heff_take_n(v_x21_24145, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETag: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EInt: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EFloat: {
                          heff_take_nf(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EString: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EBinary: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ERune: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWord: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EApp: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EProject: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENamed: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EPi: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELam: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EAnn: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ESpec: {
                          heff_take_n(v_x21_24145, 0ULL, 4);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ESig: {
                          V v_fs_24174 = heff_field(v_x21_24145, 0);
                          V v_ru_24x21_24145_24ESig = heff_take_reuse_n(v_x21_24145, 1ULL, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          switch (heff_tag_of(v_fs_24174)) {
                          case TAG_Nil: {
                            heff_drop_cell(v_ru_24t_24107_24Just, 1);
                            heff_drop_cell(v_ru_24x21_24145_24ESig, 1);
                            v_t_24224 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Cons: {
                            V v_t_24177 = (g_list_2emap_24s1387309293x1990579214(v_fs_24174));
                            V v_t_24178 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24177));
                            v_t_24224 = heff_tag_at_n(v_ru_24t_24107_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_24145_24ESig, TAG_ByFields, 1, (V[]){v_t_24178})});
                            break;
                          }
                          default: heff_nomatch(v_fs_24174);
                          }
                          break;
                        }
                        case TAG_ESum: {
                          V v_vs_24179 = heff_field(v_x21_24145, 0);
                          heff_take_n(v_x21_24145, 1ULL, 1);
                          switch (heff_tag_of(v_vs_24179)) {
                          case TAG_Nil: {
                            heff_drop_cell(v_ru_24t_24107_24Just, 1);
                            heff_drop_cell(v_ru_24d_24130_24At, 2);
                            heff_drop(v_ps_24143);
                            v_t_24224 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Cons: {
                            V v_t_24182 = (g_list_2emap_24s580776739x648604941(v_vs_24179));
                            V v_t_24183 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24182));
                            v_t_24224 = heff_tag_at_n(v_ru_24t_24107_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24d_24130_24At, TAG_ByTags, 2, (V[]){v_ps_24143, v_t_24183})});
                            break;
                          }
                          default: heff_nomatch(v_vs_24179);
                          }
                          break;
                        }
                        case TAG_EStruct: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EUpdate: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EMatch: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELetIn: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EDo: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELocal: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EInvalid: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EAssign: {
                          heff_take_n(v_x21_24145, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWhile: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EFor: {
                          heff_take_n(v_x21_24145, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EIfThen: {
                          heff_take_n(v_x21_24145, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EBreak: {
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EContinue: {
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EReturn: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENest: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELazy: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETuple: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETry: {
                          heff_take_n(v_x21_24145, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWith: {
                          heff_take_n(v_x21_24145, 0ULL, 4);
                          heff_drop_cell(v_ru_24t_24107_24Just, 1);
                          heff_drop_cell(v_ru_24d_24130_24At, 2);
                          heff_drop(v_ps_24143);
                          v_t_24224 = NTAG(TAG_Nothing);
                          break;
                        }
                        default: heff_nomatch(v_x21_24145);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x2_24144);
                      }
                      break;
                    }
                    case TAG_DeclTheory: {
                      heff_take_n(v_x11_24131, 0ULL, 4);
                      heff_drop_cell(v_ru_24t_24107_24Just, 1);
                      heff_drop_cell(v_ru_24d_24130_24At, 2);
                      v_t_24224 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclPrimitive: {
                      heff_take_n(v_x11_24131, 0ULL, 3);
                      heff_drop_cell(v_ru_24t_24107_24Just, 1);
                      heff_drop_cell(v_ru_24d_24130_24At, 2);
                      v_t_24224 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclTest: {
                      heff_take_n(v_x11_24131, 0ULL, 2);
                      heff_drop_cell(v_ru_24t_24107_24Just, 1);
                      heff_drop_cell(v_ru_24d_24130_24At, 2);
                      v_t_24224 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclWatch: {
                      heff_take_n(v_x11_24131, 0ULL, 1);
                      heff_drop_cell(v_ru_24t_24107_24Just, 1);
                      heff_drop_cell(v_ru_24d_24130_24At, 2);
                      v_t_24224 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_x11_24131);
                    }
                    break;
                  }
                  default: heff_nomatch(v_d_24130);
                  }
                } else {
                  heff_drop_cell(v_ru_24t_24107_24Just, 1);
                  heff_drop(v_field_24129);
                  v_t_24224 = NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop_cell(v_ru_24t_24107_24Just, 1);
              heff_drop(v_program_24109);
              heff_drop(v_field_24115);
              heff_drop(v_field_24116);
              v_t_24224 = NTAG(TAG_Nothing);
            }
          }
        }
      }
      switch (heff_tag_of(v_t_24224)) {
      case TAG_Nothing: {
        heff_drop(v_program_2497);
        heff_drop_rec(v_c_2498, 14);
        heff_drop_rec(v_s_2499, 5);
        v_t_24369 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_m_24225 = heff_field(v_t_24224, 0);
        V v_ru_24t_24224_24Just = heff_take_reuse_n(v_t_24224, 1ULL, 1);
        V v_t_24226 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str3), heff_dup(heff_rfield(v_s_2499, 0)));
        V v_t_24227 = (g_heff_2elsp_2esplit_2elineStart(heff_rfield(v_c_2498, 3), heff_dup(heff_rfield(v_s_2499, 2))));
        V v_t_24228 = heff_strSlice(heff_dup(heff_rfield(v_c_2498, 3)), v_t_24227, heff_dup(heff_rfield(v_s_2499, 2)));
        V v_sep_24229 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str4), v_t_24228);
        V v_program_24230 = v_program_2497;
        V v_c_24231 = heff_dup(v_c_2498);
        V v_s_24232 = heff_dup(v_s_2499);
        V v_taken_24233 = (g_heff_2elsp_2esplit_2ewordsIn(heff_rfield(v_c_2498, 3), heff_dup(heff_rfield(v_s_2499, 2)), heff_dup(heff_rfield(v_s_2499, 4)), NTAG(TAG_Nil)));
        V v_x5_24234 = v_m_24225;
        V v_t_24363;
        switch (heff_tag_of(v_x5_24234)) {
        case TAG_ByTags: {
          V v_ps_24235 = heff_field(v_x5_24234, 0);
          V v_tags_24236 = heff_field(v_x5_24234, 1);
          V v_ru_24x5_24234_24ByTags = heff_take_reuse_n(v_x5_24234, 3ULL, 2);
          V v_program_24237 = v_program_24230;
          V v_c_24238 = heff_dup(v_c_24231);
          V v_t_24239 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24237));
          V v_ops_24313 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam6, 2, 1, (V[]){v_c_24238}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24239; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24239); r_; });
          V v_src_24314 = heff_get_n(v_c_24231, 3, 14);
          V v_s_24315 = v_s_24232;
          V v_taken_24316 = v_taken_24233;
          V v_ps_24317 = v_ps_24235;
          V v_tags_24318 = v_tags_24236;
          v_t_24363 = (g_list_2emap_24tok2(v_ru_24x5_24234_24ByTags, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_lam9, 1, 5, (V[]){v_ops_24313, v_ps_24317, v_taken_24316, v_s_24315, v_src_24314}), v_tags_24318));
          break;
        }
        case TAG_ByFields: {
          V v_fs_24356 = heff_field(v_x5_24234, 0);
          heff_take_n(v_x5_24234, 1ULL, 1);
          heff_drop(v_program_24230);
          heff_drop_rec(v_c_24231, 14);
          heff_drop(v_s_24232);
          V v_xs_24357 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_24233, heff_dup(v_fs_24356)));
          V v_x2_24358 = (g_list_2ezipWith_24s2130584539x811126895(((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str21), v_fs_24356, v_xs_24357));
          V v_t_24361;
          switch (heff_tag_of(v_x2_24358)) {
          case TAG_Nil: {
            v_t_24361 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str22);
            break;
          }
          case TAG_Cons: {
            V v_x_24359 = heff_field(v_x2_24358, 0);
            V v_xs_24360 = heff_field(v_x2_24358, 1);
            heff_take_n(v_x2_24358, 3ULL, 2);
            v_t_24361 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str23); V a_1 = v_x_24359; V a_2 = v_xs_24360; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24360); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24358);
          }
          V v_t_24362 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str24), v_t_24361), ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str25));
          v_t_24363 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24362, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_x5_24234);
        }
        V v_x2_24364 = (g_list_2emap_24s1628253759x601849359(v_c_2498, heff_dup(v_s_2499), v_t_24363));
        V v_t_24367;
        switch (heff_tag_of(v_x2_24364)) {
        case TAG_Nil: {
          heff_drop(v_sep_24229);
          v_t_24367 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str26);
          break;
        }
        case TAG_Cons: {
          V v_x_24365 = heff_field(v_x2_24364, 0);
          V v_xs_24366 = heff_field(v_x2_24364, 1);
          heff_take_n(v_x2_24364, 3ULL, 2);
          v_t_24367 = ({ V a_0 = v_sep_24229; V a_1 = v_x_24365; V a_2 = v_xs_24366; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24366); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24364);
        }
        V v_t_24368 = heff_rec_n(4, shape_title__start__end__text, (V[]){heff_strAppend(v_t_24226, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str27)), heff_take_field(v_s_2499, 2), heff_get_n(v_s_2499, 4, 5), v_t_24367});
        v_t_24369 = heff_tag_at_n(v_ru_24t_24224_24Just, TAG_Just, 1, (V[]){v_t_24368});
        break;
      }
      default: heff_nomatch(v_t_24224);
      }
      break;
    }
    default: heff_nomatch(v_t_24107);
    }
    switch (heff_tag_of(v_t_24369)) {
    case TAG_Nothing: {
      heff_drop_rec(v_c_245, 14);
      heff_drop(v_uri_243);
      v_x_24399 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_24370 = heff_field(v_t_24369, 0);
      V v_ru_24t_24369_24Just = heff_take_reuse_n(v_t_24369, 1ULL, 1);
      V v_uri_24371 = v_uri_243;
      V v_src_24372 = heff_get_n(v_c_245, 3, 14);
      V v_x_24373 = v_x_24370;
      V v_title_24374 = heff_take_field(v_x_24373, 0);
      V v_start_24375 = heff_take_field(v_x_24373, 1);
      V v_end_24376 = heff_take_field(v_x_24373, 2);
      V v_text_24377 = heff_get_n(v_x_24373, 3, 4);
      V v_t_24378 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str28), heff_tag_at_n(v_ru_24t_24369_24Just, TAG_JString, 1, (V[]){v_title_24374})});
      V v_t_24379 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str29), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str30)})});
      V v_t_24380 = v_start_24375;
      V v_t_24381 = v_end_24376;
      V v_t_24382 = (g_heff_2elsp_2elsp_2eposition(v_src_24372, heff_dup(v_t_24380)));
      V v_t_24383;
      if (heff_intLe_c_lent(v_t_24380, v_t_24381, 0)) {
        heff_drop(v_t_24380);
        v_t_24383 = v_t_24381;
      } else {
        heff_drop(v_t_24381);
        v_t_24383 = v_t_24380;
      }
      V v_t_24384 = ({ V a_0 = v_src_24372; V a_1 = v_t_24383; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_24372); r_; });
      V v_t_24385 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str31), v_t_24384}), NTAG(TAG_Nil)});
      V v_t_24386 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str32), v_t_24382}), v_t_24385});
      V v_t_24387 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str33), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24386})});
      V v_t_24388 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str34), heff_tag_n(TAG_JString, 1, (V[]){v_text_24377})});
      V v_t_24389 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24388, NTAG(TAG_Nil)});
      V v_t_24390 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24387, v_t_24389})});
      V v_t_24391 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24390, NTAG(TAG_Nil)});
      V v_t_24392 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_24371, heff_tag_n(TAG_JArray, 1, (V[]){v_t_24391})});
      V v_t_24393 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24392, NTAG(TAG_Nil)});
      V v_t_24394 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str35), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24393})});
      V v_t_24395 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24394, NTAG(TAG_Nil)});
      V v_t_24396 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_str36), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24395})});
      V v_t_24397 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24396, NTAG(TAG_Nil)});
      V v_t_24398 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24378, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24379, v_t_24397})});
      v_x_24399 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_24398}), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24369);
    }
    break;
  }
  default: heff_nomatch(v_x_2495);
  }
  V f_ = v_z_248;
  args[0] = v_x_24399;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}