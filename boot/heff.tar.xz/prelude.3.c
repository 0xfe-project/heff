// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_ECon 35052
#define TAG_EGlobal 62762
#define TAG_EProj 35044
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_OfTags 60669
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SDecl 12991
#define TAG_SError 24172
#define TAG_ShapeRecord 31660
#define TAG_ShapeTag 9776
#define TAG_TagVariant 25174
#define TAG_Throw 56084
#define LBL_base 9511832
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_consumers 1203455020
#define LBL_def 308863
#define LBL_defs 9574869
#define LBL_e 319
#define LBL_end 310101
#define LBL_facts 298546081
#define LBL_field 298786068
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_key 315609
#define LBL_kp 10188
#define LBL_lams 9809570
#define LBL_launch 837298910
#define LBL_left 9813198
#define LBL_limit 304334805
#define LBL_made 9839068
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nlam 9879345
#define LBL_note 9882809
#define LBL_nstr 9886666
#define LBL_numbered 1006183371
#define LBL_op 10312
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_plain 308106724
#define LBL_prims 308293287
#define LBL_producers 572620898
#define LBL_protos 967342774
#define LBL_safe 10017876
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_shapes 1043573789
#define LBL_slots 310891087
#define LBL_sp 10436
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_strs 10036521
#define LBL_supply 1056026650
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_tuples 1084651734
#define LBL_unrolled 706233391
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
V g_heff_2ecompile_2efields_2ereadsAt(V, V, V);
V g_heff_2ecompile_2efields_2ereadsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadsAt_clo;
HeffT2 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2elower_2ercOf(V, V);
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ercOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2erunes_2edefOf(V);
V g_heff_2ecompile_2erunes_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2edefOf_clo;
V g_heff_2ecompile_2escalars_2edefWith(V, V, V);
V g_heff_2ecompile_2escalars_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2edefWith_clo;
V g_heff_2ecompile_2escalars_2ewithVars(V);
V g_heff_2ecompile_2escalars_2ewithVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewithVars_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eoneDef_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24dps(V, V, V);
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24dps_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275(V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo;
V g_prelude_2e_2b_2b_24f1876770336x1656095219(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1876770336x1656095219_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1876770336x1656095219_clo;
V g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps(V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps_clo;
V g_prelude_2e_2b_2b_24f292729551x60683815_24dps(V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f292729551x60683815_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f292729551x60683815_24dps_clo;
V g_prelude_2e_2b_2b_24f339900781x1605227681(V, V);
V g_prelude_2e_2b_2b_24f339900781x1605227681_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f339900781x1605227681_clo;
V g_prelude_2e_2b_2b_24f339900781x1605227681_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f339900781x1605227681_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f339900781x1605227681_24dps_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo;
V g_prelude_2e_2b_2b_24f892794188x1384814865(V, V, V);
V g_prelude_2e_2b_2b_24f892794188x1384814865_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f892794188x1384814865_clo;
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HeffT2 g_prelude_2etraverse_24s1023157662x1060337521_24cpr(V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s1111575179x1680558317(V);
V g_prelude_2etraverse_24s1111575179x1680558317_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1111575179x1680558317_clo;
HeffT2 g_prelude_2etraverse_24s1182736556x1844399207_24cpr(V, V);
V g_prelude_2etraverse_24s1211845059x266223635(V);
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1211845059x266223635_clo;
V g_prelude_2etraverse_24s1237512785x1947069493(V);
V g_prelude_2etraverse_24s1237512785x1947069493_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1237512785x1947069493_clo;
V g_prelude_2etraverse_24s1360711314x1560806682(V, V);
V g_prelude_2etraverse_24s1360711314x1560806682_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1360711314x1560806682_clo;
V g_prelude_2etraverse_24s1370495575x1780346529(V, V);
V g_prelude_2etraverse_24s1370495575x1780346529_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1370495575x1780346529_clo;
V g_prelude_2etraverse_24s1462482035x919987020(V);
V g_prelude_2etraverse_24s1462482035x919987020_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1462482035x919987020_clo;
V g_prelude_2etraverse_24s1617808025x638052145(V);
V g_prelude_2etraverse_24s1617808025x638052145_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1617808025x638052145_clo;
V g_prelude_2etraverse_24s1726903169x1952011622(V);
V g_prelude_2etraverse_24s1726903169x1952011622_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1726903169x1952011622_clo;
HeffT2 g_prelude_2etraverse_24s366524614x1308602553_24cpr(V);
V g_prelude_2etraverse_24s390133767x1613463851(V);
V g_prelude_2etraverse_24s390133767x1613463851_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s390133767x1613463851_clo;
V g_prelude_2etraverse_24s428640578x580976168(V, V);
V g_prelude_2etraverse_24s428640578x580976168_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s428640578x580976168_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s545943161x1483966866(V, V);
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s545943161x1483966866_clo;
V g_prelude_2etraverse_24s672366786x467588702(V, V);
V g_prelude_2etraverse_24s672366786x467588702_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s672366786x467588702_clo;
V g_prelude_2etraverse_24s75890152x1871550235(V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s75890152x1871550235_clo;
V g_prelude_2etraverse_24s763866529x146151572(V);
V g_prelude_2etraverse_24s763866529x146151572_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s763866529x146151572_clo;
HeffT2 g_prelude_2etraverse_24s801310267x475583082_24cpr(V, V);
V g_prelude_2etraverse_24s87601361x1873011385(V);
V g_prelude_2etraverse_24s87601361x1873011385_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s87601361x1873011385_clo;
HeffT2 g_prelude_2etraverse_24s890471069x803991723_24cpr(V);
V g_prelude_2etraverse_24s993801089x502291790(V);
V g_prelude_2etraverse_24s993801089x502291790_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s993801089x502291790_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
Clo g_prelude_2e_2b_2b_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_entry, 2, 0};

V g_prelude_2e_2b_2b(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_prelude_2e_2b_2b_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2e_2b_2b_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b(a[0], a[1]);
}
Clo g_prelude_2eskipSpaces_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eskipSpaces_entry, 3, 0};

V g_prelude_2eskipSpaces(V v_s_240, V v_box_24i_241, V v_box_24step_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_step_242 = heff_unbox_word(v_box_24step_242);
top: ;
  if ((((int64_t)0ULL) <= v_i_241)) {
    if ((v_i_241 < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
      V v_c_243 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
      if (((heff_peek_word(v_c_243) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_243) == ((int64_t)9ULL)) || ((heff_peek_word(v_c_243) == ((int64_t)10ULL)) || (heff_peek_word(v_c_243) == ((int64_t)13ULL)))))) {
        heff_drop(v_c_243);
        V t_0 = v_s_240;
        int64_t t_1 = (v_i_241 + v_step_242);
        int64_t t_2 = v_step_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_step_242 = t_2;
        goto top;
      } else {
        heff_drop(v_c_243);
        return heff_box_word(v_i_241);
      }
    } else {
      return heff_box_word(v_i_241);
    }
  } else {
    return heff_box_word(v_i_241);
  }
}
V g_prelude_2eskipSpaces_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2eskipSpaces(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_prelude_2eparseInt_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eparseInt_entry, 1, 0};

V g_prelude_2eparseInt(V v_s_240) {
top: ;
  HeffT2 v_t_241 = (g_prelude_2eparseInt_24cpr(v_s_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_prelude_2eparseInt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2eparseInt(a0); heff_drop(a0); return r;
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1726903169x1952011622_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1726903169x1952011622_lam0, 1, 0};
V g_prelude_2etraverse_24s1726903169x1952011622_lam1(V self, V *args);
V g_prelude_2etraverse_24s1726903169x1952011622_lam2(V self, V *args);
V g_prelude_2etraverse_24s1726903169x1952011622_lam3(V self, V *args);
V g_prelude_2etraverse_24s1726903169x1952011622_lam4(V self, V *args);
Clo g_prelude_2etraverse_24s1726903169x1952011622_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1726903169x1952011622_entry, 1, 0};

V g_prelude_2etraverse_24s1726903169x1952011622(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1726903169x1952011622_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_x2_245 = v_x_243;
    V v_m_2437;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_ECon: {
      V v_c_246 = heff_field(v_x2_245, 0);
      V v_args_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_c_248 = v_c_246;
      V v_text_249 = heff_take_field(v_c_248, 1);
      V v_start_2410 = heff_take_field(v_c_248, 3);
      V v_end_2411 = heff_get_n(v_c_248, 4, 9);
      V v_args_2412 = v_args_247;
      V v_m_2413 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 0)), v_args_2412));
      V v_m_2422 = heff_clo_n(g_prelude_2etraverse_24s1726903169x1952011622_lam1, 1, 4, (V[]){v_m_2413, v_text_249, v_start_2410, v_end_2411});
      v_m_2437 = heff_clo_n(g_prelude_2etraverse_24s1726903169x1952011622_lam2, 1, 1, (V[]){v_m_2422});
      break;
    }
    default: {
      v_m_2437 = heff_clo_n(g_prelude_2etraverse_24s1726903169x1952011622_lam3, 1, 1, (V[]){v_x2_245});
      break;
    }
    }
    return heff_clo_n(g_prelude_2etraverse_24s1726903169x1952011622_lam4, 1, 2, (V[]){v_m_2437, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1726903169x1952011622_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1726903169x1952011622(a[0]);
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam1(V self, V *args) {
  V v_st_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_text_249 = heff_env(self)[1];
  V v_start_2410 = heff_env(self)[2];
  V v_end_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2414}));
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_MkPair: {
    V v_x11_2416 = heff_field(v_x1_2415, 0);
    V v_st_2417 = heff_field(v_x1_2415, 1);
    V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
    switch (heff_tag_of(v_x11_2416)) {
    case TAG_Left: {
      V v_e_2418 = heff_field(v_x11_2416, 0);
      V v_ru_24x11_2416_24Left = heff_take_reuse_n(v_x11_2416, 1ULL, 1);
      heff_drop(v_text_249);
      heff_drop(v_start_2410);
      heff_drop(v_end_2411);
      return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2416_24Left, TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_x11_2416, 0);
      V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 1ULL, 1);
      V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){v_text_249}), heff_rec_n(2, shape_start__end, (V[]){v_start_2410, v_end_2411})});
      V v_x_2421 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2420, v_x_2419));
      return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_Right, 1, (V[]){v_x_2421}), v_st_2417});
    }
    default: return heff_nomatch(v_x11_2416);
    }
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam2(V self, V *args) {
  V v_st_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_st_2423}));
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_MkPair: {
    V v_x11_2425 = heff_field(v_x1_2424, 0);
    V v_st_2426 = heff_field(v_x1_2424, 1);
    V v_ru_24x1_2424_24MkPair = heff_take_reuse_n(v_x1_2424, 3ULL, 2);
    switch (heff_tag_of(v_x11_2425)) {
    case TAG_Left: {
      V v_e_2427 = heff_field(v_x11_2425, 0);
      V v_ru_24x11_2425_24Left = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2425_24Left, TAG_Left, 1, (V[]){v_e_2427}), v_st_2426});
    }
    case TAG_Right: {
      V v_x_2428 = heff_field(v_x11_2425, 0);
      V v_ru_24x11_2425_24Right = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
      V v_x_2429 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2428));
      return heff_tag_at_n(v_ru_24x1_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2425_24Right, TAG_Right, 1, (V[]){v_x_2429}), v_st_2426});
    }
    default: return heff_nomatch(v_x11_2425);
    }
  }
  default: return heff_nomatch(v_x1_2424);
  }
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam3(V self, V *args) {
  V v_st_2430 = args[0];
  V v_x2_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2431 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_245, v_st_2430));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Left = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Left, TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      V v_x_2436 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2435));
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){v_x_2436}), v_st_2433});
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_prelude_2etraverse_24s1726903169x1952011622_lam4(V self, V *args) {
  V v_st_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_st_2438}));
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_MkPair: {
    V v_x11_2440 = heff_field(v_x1_2439, 0);
    V v_st_2441 = heff_field(v_x1_2439, 1);
    V v_ru_24x1_2439_24MkPair = heff_take_reuse_n(v_x1_2439, 3ULL, 2);
    switch (heff_tag_of(v_x11_2440)) {
    case TAG_Left: {
      V v_e_2442 = heff_field(v_x11_2440, 0);
      V v_ru_24x11_2440_24Left = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2440_24Left, TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
    }
    case TAG_Right: {
      V v_x_2443 = heff_field(v_x11_2440, 0);
      V v_ru_24x11_2440_24Right = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
      V v_m_2444 = (g_prelude_2etraverse_24s1726903169x1952011622(v_xs_244));
      V v_x1_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_st_2441}));
      switch (heff_tag_of(v_x1_2445)) {
      case TAG_MkPair: {
        V v_x11_2446 = heff_field(v_x1_2445, 0);
        V v_st_2447 = heff_field(v_x1_2445, 1);
        V v_ru_24x1_2445_24MkPair = heff_take_reuse_n(v_x1_2445, 3ULL, 2);
        switch (heff_tag_of(v_x11_2446)) {
        case TAG_Left: {
          V v_e_2448 = heff_field(v_x11_2446, 0);
          V v_ru_24x11_2446_24Left = heff_take_reuse_n(v_x11_2446, 1ULL, 1);
          heff_drop(v_x_2443);
          heff_drop_cell(v_ru_24x11_2440_24Right, 1);
          heff_drop_cell(v_ru_24x1_2445_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2446_24Left, TAG_Left, 1, (V[]){v_e_2448}), v_st_2447});
        }
        case TAG_Right: {
          V v_x_2449 = heff_field(v_x11_2446, 0);
          heff_take_n(v_x11_2446, 1ULL, 1);
          V v_t_2450 = heff_tag_at_n(v_ru_24x11_2440_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2445_24MkPair, TAG_Cons, 2, (V[]){v_x_2443, v_x_2449})});
          return heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_MkPair, 2, (V[]){v_t_2450, v_st_2447});
        }
        default: return heff_nomatch(v_x11_2446);
        }
      }
      default: return heff_nomatch(v_x1_2445);
      }
    }
    default: return heff_nomatch(v_x11_2440);
    }
  }
  default: return heff_nomatch(v_x1_2439);
  }
}
V g_prelude_2etraverse_24s672366786x467588702_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s672366786x467588702_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s672366786x467588702_lam0, 1, 0};
V g_prelude_2etraverse_24s672366786x467588702_lam1(V self, V *args);
V g_prelude_2etraverse_24s672366786x467588702_lam2(V self, V *args);
V g_prelude_2etraverse_24s672366786x467588702_lam3(V self, V *args);
V g_prelude_2etraverse_24s672366786x467588702_lam4(V self, V *args);
V g_prelude_2etraverse_24s672366786x467588702_lam5(V self, V *args);
Clo g_prelude_2etraverse_24s672366786x467588702_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s672366786x467588702_entry, 2, 0};

V g_prelude_2etraverse_24s672366786x467588702(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s672366786x467588702_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_s_245 = heff_dup(v_lit_240);
    V v_a_246 = v_x_243;
    V v_m_2433;
    switch (heff_tag_of(v_a_246)) {
    case TAG_EProj: {
      V v_a1_247 = heff_dup(heff_field(v_a_246, 0));
      switch (heff_tag_of(v_a1_247)) {
      case TAG_EGlobal: {
        V v_g_2411 = heff_field(v_a1_247, 0);
        heff_take_n(v_a1_247, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_EProj: {
          V v_l_2413 = heff_field(v_a_246, 1);
          V v_sh_2414 = heff_field(v_a_246, 2);
          V v_t_2415 = heff_field(v_a_246, 3);
          heff_take_n(v_a_246, 14ULL, 4);
          HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_s_245, 2, 10); V a_1 = v_g_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              V v_x_2419 = v_field_2418;
              heff_drop(v_x_2419);
              v_m_2433 = heff_clo_n(g_prelude_2etraverse_24s672366786x467588702_lam1, 1, 4, (V[]){v_g_2411, v_l_2413, v_sh_2414, v_t_2415});
            } else {
              heff_drop(v_field_2418);
              v_m_2433 = heff_clo_n(g_prelude_2etraverse_24s672366786x467588702_lam2, 1, 4, (V[]){v_g_2411, v_l_2413, v_sh_2414, v_t_2415});
            }
          }
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: {
        heff_drop_rec(v_s_245, 10);
        heff_drop(v_a1_247);
        v_m_2433 = heff_clo_n(g_prelude_2etraverse_24s672366786x467588702_lam3, 1, 1, (V[]){v_a_246});
        break;
      }
      }
      break;
    }
    default: {
      heff_drop_rec(v_s_245, 10);
      v_m_2433 = heff_clo_n(g_prelude_2etraverse_24s672366786x467588702_lam4, 1, 1, (V[]){v_a_246});
      break;
    }
    }
    return heff_clo_n(g_prelude_2etraverse_24s672366786x467588702_lam5, 1, 3, (V[]){v_m_2433, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s672366786x467588702_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s672366786x467588702(a[0], a[1]);
}
V g_prelude_2etraverse_24s672366786x467588702_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s672366786x467588702_lam1(V self, V *args) {
  V v_s_2420 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_l_2413 = heff_env(self)[1];
  V v_sh_2414 = heff_env(self)[2];
  V v_t_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2411}), v_l_2413, v_sh_2414, v_t_2415});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_s_2420});
}
V g_prelude_2etraverse_24s672366786x467588702_lam2(V self, V *args) {
  V v_s_2422 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_l_2413 = heff_env(self)[1];
  V v_sh_2414 = heff_env(self)[2];
  V v_t_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2423 = (g_heff_2ecompile_2esimplify_2eknownField_24cpr(v_g_2411, v_l_2413, v_s_2422));
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_x_2426 = v_field_2424;
    V v_s_2427 = v_field_2425;
    V v_x_2430;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_Nothing: {
      v_x_2430 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2411}), v_l_2413, v_sh_2414, v_t_2415});
      break;
    }
    case TAG_Just: {
      V v_v_2428 = heff_field(v_x_2426, 0);
      V v_ru_24x_2426_24Just = heff_take_reuse_n(v_x_2426, 1ULL, 1);
      V v_t_2429 = heff_tr(g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_v_2428)));
      if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
        heff_drop(v_g_2411);
        heff_drop(v_l_2413);
        heff_drop(v_sh_2414);
        heff_drop(v_t_2415);
        heff_drop_cell(v_ru_24x_2426_24Just, 1);
        heff_drop(v_t_2429);
        v_x_2430 = v_v_2428;
      } else {
        heff_drop(v_v_2428);
        heff_drop(v_t_2429);
        v_x_2430 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_at_n(v_ru_24x_2426_24Just, TAG_EGlobal, 1, (V[]){v_g_2411}), v_l_2413, v_sh_2414, v_t_2415});
      }
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2430, v_s_2427});
  }
}
V g_prelude_2etraverse_24s672366786x467588702_lam3(V self, V *args) {
  V v_s_2431 = args[0];
  V v_a_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_246, v_s_2431});
}
V g_prelude_2etraverse_24s672366786x467588702_lam4(V self, V *args) {
  V v_s_2432 = args[0];
  V v_a_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_246, v_s_2432});
}
V g_prelude_2etraverse_24s672366786x467588702_lam5(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_m_2438 = (g_prelude_2etraverse_24s672366786x467588702(v_lit_240, v_xs_244));
    V v_x2_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_s_2437}));
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_MkPair: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_s_2441 = heff_field(v_x2_2439, 1);
      V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_Cons, 2, (V[]){v_x_2436, v_x_2440}), v_s_2441});
    }
    default: return heff_nomatch(v_x2_2439);
    }
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_prelude_2etraverse_24s1237512785x1947069493_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1237512785x1947069493_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1237512785x1947069493_lam0, 1, 0};
V g_prelude_2etraverse_24s1237512785x1947069493_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1237512785x1947069493_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1237512785x1947069493_entry, 1, 0};

V g_prelude_2etraverse_24s1237512785x1947069493(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1237512785x1947069493_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s1237512785x1947069493_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1237512785x1947069493_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1237512785x1947069493(a[0]);
}
V g_prelude_2etraverse_24s1237512785x1947069493_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_prelude_2etraverse_24s1237512785x1947069493_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s1237512785x1947069493(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_s_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}

HeffT2 g_prelude_2etraverse_24s1182736556x1844399207_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_244 = v_x_242;
    V v_p_245 = v_p_241;
    V v_x2_2471;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Fresh: {
      V v_d_246 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_x2_2471 = (g_heff_2ecompile_2esimplify_2eoneDef(v_d_246, v_p_245));
      break;
    }
    case TAG_Kept: {
      V v_k_247 = heff_field(v_x1_244, 0);
      V v_redo_248 = heff_field(v_x1_244, 1);
      V v_ru_24x1_244_24Kept = heff_take_reuse_n(v_x1_244, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_247, 2)), 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_k_2410 = v_k_247;
      V v_x2_2411 = v_t_249;
      V v_p_2412 = heff_dup(v_p_245);
      V v_x2_2459;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop_rec(v_k_2410, 7);
        v_x2_2459 = heff_tag_at_n(v_ru_24x1_244_24Kept, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_2412});
        break;
      }
      case TAG_Just: {
        V v_b0_2413 = heff_field(v_x2_2411, 0);
        V v_ru_24x2_2411_24Just = heff_take_reuse_n(v_x2_2411, 1ULL, 1);
        HeffT2 v_t_2414 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(heff_dup(heff_rfield(v_k_2410, 4)), v_p_2412));
        {
          V v_field_2415 = v_t_2414.f[0];
          V v_field_2416 = v_t_2414.f[1];
          V v_x_2417 = v_field_2415;
          V v_s_2418 = v_field_2416;
          if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
            heff_drop(v_x_2417);
            V v_k_2419 = v_k_2410;
            V v_key_2420 = heff_take_field(v_k_2419, 0);
            V v_safe_2421 = heff_take_field(v_k_2419, 3);
            V v_name_2422 = heff_get_n(v_k_2419, 1, 7);
            V v_b0_2423 = v_b0_2413;
            V v_s_2424 = v_s_2418;
            HeffT2 v_t_2425 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b0_2423, v_s_2424));
            V v_x2_2456;
            {
              V v_field_2426 = v_t_2425.f[0];
              V v_field_2427 = v_t_2425.f[1];
              V v_x_2428 = v_field_2426;
              V v_s_2429 = v_field_2427;
              HeffT2 v_t_2430 = (g_heff_2ecompile_2esimplify_2erecordDef_24cpr(heff_dup(v_key_2420), heff_dup(v_x_2428), v_s_2429));
              {
                V v_field_2431 = v_t_2430.f[0];
                V v_field_2432 = v_t_2430.f[1];
                V v_x_2433 = v_field_2431;
                heff_drop(v_x_2433);
                V v_s_2434 = v_field_2432;
                V v_x1_2435 = v_safe_2421;
                V v_k_2436 = heff_dup(v_key_2420);
                V v_p_2437 = v_s_2434;
                V v_x2_2440;
                if ((heff_dup(v_x1_2435) == NTAG(TAG_True))) {
                  heff_drop(v_x1_2435);
                  V v_t_2438 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_p_2437, 3), v_k_2436, NTAG(TAG_MkUnit)));
                  V v_t_2439 = ({ V rv_3 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_p_2437, 1015ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048383u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                  v_x2_2440 = heff_tag_at_n(v_ru_24x1_244_24Kept, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2439});
                } else {
                  heff_drop(v_x1_2435);
                  heff_drop(v_k_2436);
                  v_x2_2440 = heff_tag_at_n(v_ru_24x1_244_24Kept, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_p_2437});
                }
                switch (heff_tag_of(v_x2_2440)) {
                case TAG_MkPair: {
                  V v_s_2442 = heff_field(v_x2_2440, 1);
                  V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 2ULL, 2);
                  V v_t_2443 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_2428)));
                  V v_t_2444 = (g_heff_2ecompile_2eir_2enubI(v_t_2443));
                  HeffT2 v_t_2445 = (g_heff_2ecompile_2esimplify_2emakeEach_24cpr(v_t_2444, v_s_2442));
                  {
                    V v_field_2446 = v_t_2445.f[0];
                    V v_field_2447 = v_t_2445.f[1];
                    V v_x_2448 = v_field_2446;
                    V v_s_2449 = v_field_2447;
                    V v_m_2450 = (g_heff_2ecompile_2esimplify_2einOrder(heff_dup(v_x_2428), v_x_2448));
                    V v_x2_2451 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2449}));
                    switch (heff_tag_of(v_x2_2451)) {
                    case TAG_MkPair: {
                      V v_x_2452 = heff_field(v_x2_2451, 0);
                      V v_s_2453 = heff_field(v_x2_2451, 1);
                      V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
                      V v_t_2454 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_key_2420, v_name_2422, v_x_2428}), NTAG(TAG_Nil)});
                      V v_x_2455 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2451_24MkPair, v_x_2452, v_t_2454));
                      v_x2_2456 = heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, (V[]){v_x_2455, v_s_2453});
                      break;
                    }
                    default: heff_nomatch(v_x2_2451);
                    }
                  }
                  break;
                }
                default: heff_nomatch(v_x2_2440);
                }
              }
            }
            switch (heff_tag_of(v_x2_2456)) {
            case TAG_MkPair: {
              V v_x_2457 = heff_field(v_x2_2456, 0);
              V v_s_2458 = heff_field(v_x2_2456, 1);
              V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
              v_x2_2459 = heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24Just, TAG_Just, 1, (V[]){v_x_2457}), v_s_2458});
              break;
            }
            default: heff_nomatch(v_x2_2456);
            }
          } else {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_rec(v_k_2410, 7);
            heff_drop(v_b0_2413);
            heff_drop_cell(v_ru_24x2_2411_24Just, 1);
            heff_drop(v_x_2417);
            v_x2_2459 = heff_tag_at_n(v_ru_24x1_244_24Kept, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2418});
          }
        }
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      switch (heff_tag_of(v_x2_2459)) {
      case TAG_MkPair: {
        V v_x_2460 = heff_field(v_x2_2459, 0);
        V v_s_2461 = heff_field(v_x2_2459, 1);
        V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
        switch (heff_tag_of(v_x_2460)) {
        case TAG_Nothing: {
          heff_drop(v_s_2461);
          V v_x1_2462 = heff_tr(heff_call(v_redo_248, 1, (V[]){heff_dup(heff_rfield(v_p_245, 0))}));
          V v_p_2463 = v_p_245;
          switch (heff_tag_of(v_x1_2462)) {
          case TAG_MkPair: {
            V v_x11_2464 = heff_field(v_x1_2462, 0);
            V v_n_2465 = heff_field(v_x1_2462, 1);
            V v_ru_24x1_2462_24MkPair = heff_take_reuse_n(v_x1_2462, 3ULL, 2);
            switch (heff_tag_of(v_x11_2464)) {
            case TAG_Nothing: {
              heff_drop(v_n_2465);
              V v_t_2466 = heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
              v_x2_2471 = heff_tag_at_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, (V[]){v_t_2466, v_p_2463});
              break;
            }
            case TAG_Just: {
              V v_d_2467 = heff_field(v_x11_2464, 0);
              heff_take_n(v_x11_2464, 1ULL, 1);
              heff_drop_cell(v_ru_24x2_2459_24MkPair, 2);
              heff_drop_cell(v_ru_24x1_2462_24MkPair, 2);
              V v_t_2468 = ({ V rv_0 = v_n_2465; V rr_ = heff_rec_reuse_nf(v_p_2463, 1022ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048572u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              v_x2_2471 = (g_heff_2ecompile_2esimplify_2eoneDef(v_d_2467, v_t_2468));
              break;
            }
            default: heff_nomatch(v_x11_2464);
            }
            break;
          }
          default: heff_nomatch(v_x1_2462);
          }
          break;
        }
        case TAG_Just: {
          V v_ds_2469 = heff_field(v_x_2460, 0);
          heff_take_n(v_x_2460, 1ULL, 1);
          heff_drop_rec(v_p_245, 10);
          heff_drop(v_redo_248);
          V v_t_2470 = heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){v_ds_2469, NTAG(TAG_Nil)});
          v_x2_2471 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2470, v_s_2461});
          break;
        }
        default: heff_nomatch(v_x_2460);
        }
        break;
      }
      default: heff_nomatch(v_x2_2459);
      }
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_s_2473 = heff_field(v_x2_2471, 1);
      V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
      HeffT2 v_t_2474 = (g_prelude_2etraverse_24s1182736556x1844399207_24cpr(v_xs_243, v_s_2473));
      {
        V v_field_2475 = v_t_2474.f[0];
        V v_field_2476 = v_t_2474.f[1];
        V v_x_2477 = v_field_2475;
        V v_s_2478 = v_field_2476;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_Cons, 2, (V[]){v_x_2472, v_x_2477}), v_s_2478}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2471)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1023157662x1060337521_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_247}});
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2410;
    if (((heff_dup(heff_rfield(v_lit_240, 1)) == NTAG(TAG_True)) && heff_intEq_c_lent(v_x_248, v_lit_241, 0))) {
      heff_drop(v_x_248);
      v_t_2410 = heff_dup(v_lit_242);
    } else {
      heff_drop(v_x_248);
      v_t_2410 = heff_dup(v_lit_243);
    }
    V v_x_2411 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_lit_244)), heff_intShow(heff_dup(v_p_247)));
    V v_n_2412 = heff_intAdd(v_p_247, heff_dup(v_lit_245));
    HeffT2 v_t_2413 = (g_prelude_2etraverse_24s1023157662x1060337521_24cpr(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_249, v_n_2412));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      V v_n_2417 = v_field_2415;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2411, v_x_2416}), v_n_2417}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
  }
}
V g_prelude_2etraverse_24s75890152x1871550235_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s75890152x1871550235_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s75890152x1871550235_lam0, 1, 0};
V g_prelude_2etraverse_24s75890152x1871550235_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s75890152x1871550235_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s75890152x1871550235_entry, 4, 0};

V g_prelude_2etraverse_24s75890152x1871550235(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((V)&g_prelude_2etraverse_24s75890152x1871550235_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ecompile_2eir_2ebaseGo(v_x_245, heff_dup(v_lit_240)));
    return heff_clo_n(g_prelude_2etraverse_24s75890152x1871550235_lam1, 1, 5, (V[]){v_a_247, v_lit_241, v_lit_242, v_lit_240, v_xs_246});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2etraverse_24s75890152x1871550235_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s75890152x1871550235(a[0], a[1], a[2], a[3]);
}
V g_prelude_2etraverse_24s75890152x1871550235_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_244});
}
V g_prelude_2etraverse_24s75890152x1871550235_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_xs_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_249 = heff_strAppend(heff_strAppend(v_a_247, heff_dup(v_lit_241)), heff_intShow(heff_dup(v_n_248)));
  V v_n_2410 = heff_intAdd(v_n_248, heff_dup(v_lit_242));
  V v_m_2411 = (g_prelude_2etraverse_24s75890152x1871550235(v_lit_240, v_lit_241, v_lit_242, v_xs_246));
  V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2410}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2413}), v_n_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_prelude_2etraverse_24s1462482035x919987020_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1462482035x919987020_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1462482035x919987020_lam0, 1, 0};
V g_prelude_2etraverse_24s1462482035x919987020_lam1(V self, V *args);
V g_prelude_2etraverse_24s1462482035x919987020_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1462482035x919987020_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1462482035x919987020_entry, 1, 0};

V g_prelude_2etraverse_24s1462482035x919987020(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1462482035x919987020_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_a_246));
      v_m_2415 = heff_clo_n(g_prelude_2etraverse_24s1462482035x919987020_lam1, 1, 3, (V[]){v_a_247, v_a_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1462482035x919987020_lam2, 1, 2, (V[]){v_m_2415, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1462482035x919987020_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1462482035x919987020(a[0]);
}
V g_prelude_2etraverse_24s1462482035x919987020_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1462482035x919987020_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_245 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  V v_a_2412;
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    heff_take_n(v_a_249, 3ULL, 2);
    v_a_2412 = (g_heff_2ecompile_2efields_2ereadsAt(v_a_245, v_a_2410, v_a_2411));
    break;
  }
  default: heff_nomatch(v_a_249);
  }
  switch (heff_tag_of(v_a_2412)) {
  case TAG_MkPair: {
    V v_a_2413 = heff_field(v_a_2412, 0);
    V v_a_2414 = heff_field(v_a_2412, 1);
    V v_ru_24a_2412_24MkPair = heff_take_reuse_n(v_a_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24a_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2413}), v_a_2414});
  }
  default: return heff_nomatch(v_a_2412);
  }
}
V g_prelude_2etraverse_24s1462482035x919987020_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_m_2420 = (g_prelude_2etraverse_24s1462482035x919987020(v_xs_243));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2419}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_Cons, 2, (V[]){v_x_2418, v_x_2422}), v_n_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_prelude_2etraverse_24s545943161x1483966866_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s545943161x1483966866_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s545943161x1483966866_lam0, 1, 0};
V g_prelude_2etraverse_24s545943161x1483966866_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s545943161x1483966866_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s545943161x1483966866_entry, 2, 0};

V g_prelude_2etraverse_24s545943161x1483966866(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s545943161x1483966866_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s545943161x1483966866_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s545943161x1483966866(a[0], a[1]);
}
V g_prelude_2etraverse_24s545943161x1483966866_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s545943161x1483966866_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s545943161x1483966866(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s1360711314x1560806682_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1360711314x1560806682_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1360711314x1560806682_lam0, 1, 0};
V g_prelude_2etraverse_24s1360711314x1560806682_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1360711314x1560806682_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1360711314x1560806682_entry, 2, 0};

V g_prelude_2etraverse_24s1360711314x1560806682(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1360711314x1560806682_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1360711314x1560806682_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1360711314x1560806682_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1360711314x1560806682(a[0], a[1]);
}
V g_prelude_2etraverse_24s1360711314x1560806682_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s1360711314x1560806682_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s1360711314x1560806682(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s801310267x475583082_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_p_241, 0), v_x_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_e_247 = v_field_245;
      V v_n_248 = v_field_246;
      V v_t_249 = ({ V rv_0 = v_n_248; V rr_ = heff_rec_reuse_nf(v_p_241, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      HeffT2 v_t_2410 = (g_prelude_2etraverse_24s801310267x475583082_24cpr(v_xs_243, v_t_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_s_2414 = v_field_2412;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_e_247, v_x_2413}), v_s_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1111575179x1680558317_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1111575179x1680558317_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1111575179x1680558317_lam0, 1, 0};
V g_prelude_2etraverse_24s1111575179x1680558317_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1111575179x1680558317_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1111575179x1680558317_entry, 1, 0};

V g_prelude_2etraverse_24s1111575179x1680558317(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1111575179x1680558317_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(heff_dup(heff_rfield(v_x_242, 2))));
    return heff_clo_n(g_prelude_2etraverse_24s1111575179x1680558317_lam1, 1, 3, (V[]){v_m_244, v_xs_243, v_x_242});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1111575179x1680558317_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1111575179x1680558317(a[0]);
}
V g_prelude_2etraverse_24s1111575179x1680558317_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1111575179x1680558317_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  V v_x2_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    v_x2_249 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_246_24MkPair, v_x_247, v_n_248));
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = (g_prelude_2etraverse_24s1111575179x1680558317(v_xs_243));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2416 = ({ V rv_2 = v_x_2410; V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){v_t_2416, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_prelude_2etraverse_24s1617808025x638052145_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1617808025x638052145_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1617808025x638052145_lam0, 1, 0};
V g_prelude_2etraverse_24s1617808025x638052145_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1617808025x638052145_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1617808025x638052145_entry, 1, 0};

V g_prelude_2etraverse_24s1617808025x638052145(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1617808025x638052145_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2erunes_2edefOf(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s1617808025x638052145_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1617808025x638052145_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1617808025x638052145(a[0]);
}
V g_prelude_2etraverse_24s1617808025x638052145_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1617808025x638052145_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s1617808025x638052145(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s763866529x146151572_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s763866529x146151572_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s763866529x146151572_lam0, 1, 0};
V g_prelude_2etraverse_24s763866529x146151572_lam1(V self, V *args);
V g_prelude_2etraverse_24s763866529x146151572_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s763866529x146151572_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s763866529x146151572_entry, 1, 0};

V g_prelude_2etraverse_24s763866529x146151572(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s763866529x146151572_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_m_249;
    switch (heff_tag_of(v_t_244)) {
    case TAG_ShapeRecord: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_m_249 = heff_clo_n(g_prelude_2etraverse_24s763866529x146151572_lam1, 1, 1, (V[]){v_x_242});
      break;
    }
    case TAG_ShapeTag: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_m_249 = (g_heff_2ecompile_2escalars_2ewithVars(v_x_242));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_clo_n(g_prelude_2etraverse_24s763866529x146151572_lam2, 1, 2, (V[]){v_m_249, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s763866529x146151572_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s763866529x146151572(a[0]);
}
V g_prelude_2etraverse_24s763866529x146151572_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s763866529x146151572_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_a_246});
}
V g_prelude_2etraverse_24s763866529x146151572_lam2(V self, V *args) {
  V v_n_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_n_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_m_2414 = (g_prelude_2etraverse_24s763866529x146151572(v_xs_243));
    V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2413}));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_n_2417 = heff_field(v_x2_2415, 1);
      V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_Cons, 2, (V[]){v_x_2412, v_x_2416}), v_n_2417});
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_prelude_2etraverse_24s993801089x502291790_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s993801089x502291790_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s993801089x502291790_lam0, 1, 0};
V g_prelude_2etraverse_24s993801089x502291790_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s993801089x502291790_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s993801089x502291790_entry, 1, 0};

V g_prelude_2etraverse_24s993801089x502291790(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s993801089x502291790_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_def_244 = heff_take_field(v_x_242, 0);
    V v_slots_245 = heff_get_n(v_x_242, 1, 2);
    V v_m_246 = ({ V b_0 = NTAG(TAG_OfTags); V a_1 = v_def_244; V a_2 = v_slots_245; V r_ = (g_heff_2ecompile_2escalars_2edefWith(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    return heff_clo_n(g_prelude_2etraverse_24s993801089x502291790_lam1, 1, 2, (V[]){v_m_246, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s993801089x502291790_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s993801089x502291790(a[0]);
}
V g_prelude_2etraverse_24s993801089x502291790_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s993801089x502291790_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_prelude_2etraverse_24s993801089x502291790(v_xs_243));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){v_x_249, v_x_2413}), v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_prelude_2etraverse_24s428640578x580976168_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s428640578x580976168_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s428640578x580976168_lam0, 1, 0};
V g_prelude_2etraverse_24s428640578x580976168_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s428640578x580976168_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s428640578x580976168_entry, 2, 0};

V g_prelude_2etraverse_24s428640578x580976168(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s428640578x580976168_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ecompile_2eemitc_2estmtF(heff_dup(v_lit_240), v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s428640578x580976168_lam1, 1, 3, (V[]){v_m_245, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s428640578x580976168_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s428640578x580976168(a[0], a[1]);
}
V g_prelude_2etraverse_24s428640578x580976168_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s428640578x580976168_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s428640578x580976168(v_lit_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1370495575x1780346529_str0, 0, "");
HEFF_LIT(g_prelude_2etraverse_24s1370495575x1780346529_str1, 2, "g_");
V g_prelude_2etraverse_24s1370495575x1780346529_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1370495575x1780346529_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1370495575x1780346529_lam0, 1, 0};
V g_prelude_2etraverse_24s1370495575x1780346529_lam1(V self, V *args);
V g_prelude_2etraverse_24s1370495575x1780346529_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1370495575x1780346529_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1370495575x1780346529_entry, 2, 0};

V g_prelude_2etraverse_24s1370495575x1780346529(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s1370495575x1780346529_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_ce_245 = heff_dup(v_lit_240);
    V v_d_246 = v_x_243;
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_246, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_prelude_2etraverse_24s1370495575x1780346529_str0)));
    V v_o_248 = heff_strAppend(((V)&g_prelude_2etraverse_24s1370495575x1780346529_str1), v_t_247);
    V v_m_2426 = heff_clo_n(g_prelude_2etraverse_24s1370495575x1780346529_lam1, 1, 3, (V[]){v_ce_245, v_d_246, v_o_248});
    return heff_clo_n(g_prelude_2etraverse_24s1370495575x1780346529_lam2, 1, 3, (V[]){v_m_2426, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1370495575x1780346529_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1370495575x1780346529(a[0], a[1]);
}
V g_prelude_2etraverse_24s1370495575x1780346529_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s1370495575x1780346529_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_ce_245 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_o_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_ce_245, 2)), 8, 11);
  HeffT2 v_t_2411 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), heff_take_field(v_d_246, 2)));
  V v_t_2424;
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_b0_2414 = v_field_2412;
    V v_n_2415 = v_field_2413;
    V v_t_2416 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
    V v_t_2417 = ({ V rv_2 = v_b0_2414; V rr_ = heff_rec_reuse_nf(v_d_246, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    HeffT2 v_t_2418 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2416, v_t_2417, v_n_2415));
    V v_t_2423;
    {
      V v_field_2419 = v_t_2418.f[0];
      V v_field_2420 = v_t_2418.f[1];
      V v_x_2421 = v_field_2419;
      V v_y_2422 = v_field_2420;
      heff_drop(v_y_2422);
      v_t_2423 = v_x_2421;
    }
    v_t_2424 = (g_heff_2ecompile_2elower_2ercOf(heff_get_n(v_ce_245, 2, 3), v_t_2423));
  }
  V v_t_2425 = ({ V rv_0 = v_o_248; V rv_1 = MK_INT(0LL); V rv_4 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_249, 236ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 64752u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; rr_; });
  return ({ V a_0 = v_t_2410; V a_1 = v_t_2424; V a_2 = v_t_2425; V r_ = (g_heff_2ecompile_2eemitc_2edefC(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
}
V g_prelude_2etraverse_24s1370495575x1780346529_lam2(V self, V *args) {
  V v_s_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_s_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_s_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_m_2431 = (g_prelude_2etraverse_24s1370495575x1780346529(v_lit_240, v_xs_244));
    V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_s_2434 = heff_field(v_x2_2432, 1);
      V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_Cons, 2, (V[]){v_x_2429, v_x_2433}), v_s_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}

HeffT2 g_prelude_2etraverse_24s890471069x803991723_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_xs_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_err_246 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_246}});
      } else {
        V v_x_247 = v_field_245;
        HeffT2 v_t_248 = (g_prelude_2etraverse_24s890471069x803991723_24cpr(v_xs_242));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_247);
            V v_err_2411 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2411}});
          } else {
            V v_x_2412 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_x_2412})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s366524614x1308602553_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_xs_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_err_246 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_246}});
      } else {
        V v_x_247 = v_field_245;
        HeffT2 v_t_248 = (g_prelude_2etraverse_24s366524614x1308602553_24cpr(v_xs_242));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_247);
            V v_err_2411 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2411}});
          } else {
            V v_x_2412 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_x_2412})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s87601361x1873011385_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s87601361x1873011385_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s87601361x1873011385_lam0, 2, 0};
V g_prelude_2etraverse_24s87601361x1873011385_lam3(V self, V *args);
V g_prelude_2etraverse_24s87601361x1873011385_lam2(V self, V *args);
V g_prelude_2etraverse_24s87601361x1873011385_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s87601361x1873011385_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s87601361x1873011385_entry, 1, 0};

V g_prelude_2etraverse_24s87601361x1873011385(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s87601361x1873011385_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s87601361x1873011385_lam1, 2, 2, (V[]){v_a_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s87601361x1873011385_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s87601361x1873011385(a[0]);
}
V g_prelude_2etraverse_24s87601361x1873011385_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s87601361x1873011385_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_249, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s87601361x1873011385_lam2(V self, V *args) {
  V v_a_249 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2410 = (g_prelude_2etraverse_24s87601361x1873011385(v_xs_244));
  V f_ = v_a_2410;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s87601361x1873011385_lam3, 1, 2, (V[]){v_a_247, v_a_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s87601361x1873011385_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_a_245}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_248, heff_dup(v_a_246), heff_clo_n(g_prelude_2etraverse_24s87601361x1873011385_lam2, 1, 3, (V[]){v_xs_244, v_a_246, v_a_247})));
}
HEFF_LIT(g_prelude_2etraverse_24s390133767x1613463851_str0, 45, "unexpected notation for variant in a sum type");
V g_prelude_2etraverse_24s390133767x1613463851_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s390133767x1613463851_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s390133767x1613463851_lam0, 2, 0};
V g_prelude_2etraverse_24s390133767x1613463851_lam2(V self, V *args);
V g_prelude_2etraverse_24s390133767x1613463851_lam1(V self, V *args);
V g_prelude_2etraverse_24s390133767x1613463851_lam3(V self, V *args);
V g_prelude_2etraverse_24s390133767x1613463851_lam6(V self, V *args);
V g_prelude_2etraverse_24s390133767x1613463851_lam5(V self, V *args);
V g_prelude_2etraverse_24s390133767x1613463851_lam4(V self, V *args);
Clo g_prelude_2etraverse_24s390133767x1613463851_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s390133767x1613463851_entry, 1, 0};

V g_prelude_2etraverse_24s390133767x1613463851(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s390133767x1613463851_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_x2_245 = v_x_243;
    V v_a_2425;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_x22_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_TagVariant: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_args_2410 = heff_field(v_x21_246, 2);
        heff_take_n(v_x21_246, 5ULL, 3);
        heff_drop(v_x22_247);
        V v_c_2411 = (g_prelude_2etraverse_24s1211845059x266223635(v_args_2410));
        v_a_2425 = heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam1, 2, 2, (V[]){v_c_2411, v_x_248});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x21_246, 0ULL, 1);
        v_a_2425 = heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam3, 2, 1, (V[]){v_x22_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    return heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam4, 2, 2, (V[]){v_a_2425, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s390133767x1613463851_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s390133767x1613463851(a[0]);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, heff_arrayFromList(v_x_2414)});
  V f_ = v_k_2413;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam2, 1, 2, (V[]){v_x_248, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_x22_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2419 = heff_take_field(v_hd_2417, 1);
  V v_malg_2420 = heff_get_n(v_hd_2417, 2, 3);
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s390133767x1613463851_str0), v_x22_247, NTAG(TAG_Nothing)});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(v_malg_2420, 1, (V[]){v_t_2423}));
  V f_ = v_bind_2419;
  args[0] = v_t_2424;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam6(V self, V *args) {
  V v_a_2430 = args[0];
  V v_a_2427 = heff_env(self)[0];
  V v_a_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2427;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2428, v_a_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s390133767x1613463851_lam5(V self, V *args) {
  V v_a_2428 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_2426 = heff_env(self)[1];
  V v_a_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2429 = (g_prelude_2etraverse_24s390133767x1613463851(v_xs_244));
  V f_ = v_a_2429;
  heff_room[0] = v_a_2426;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam6, 1, 2, (V[]){v_a_2427, v_a_2428});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s390133767x1613463851_lam4(V self, V *args) {
  V v_a_2426 = args[0];
  V v_a_2427 = args[1];
  V v_a_2425 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2425;
  args[0] = heff_dup(v_a_2426);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s390133767x1613463851_lam5, 1, 3, (V[]){v_xs_244, v_a_2426, v_a_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_lit_241), v_x_244});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1206589350x791019229_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1206589350x791019229_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f339900781x1605227681_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f339900781x1605227681_entry, 2, 0};

V g_prelude_2e_2b_2b_24f339900781x1605227681(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_SDecl, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f339900781x1605227681_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f339900781x1605227681_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f339900781x1605227681(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_EVar, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1681798656x925918587_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_244, v_lit_241, 0)) {
      V v_x_246 = heff_tag_n(TAG_EVar, 1, (V[]){v_x_244});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f1681798656x925918587_24f1783446775x1621329054_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(V v_ys_240, V v_i_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_x_244);
      V v_t_246 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_242_24Cons, v_xs_245, v_ys_240));
      return heff_setField(v_d_243, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_ys_240 = t_0;
      v_i_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f677743828x1026746250_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f677743828x1026746250_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f292729551x60683815_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f292729551x60683815_24dps_entry, 6, 0};

V g_prelude_2e_2b_2b_24f292729551x60683815_24dps(V v_ys_240, V v_box_24lit_241, V v_lit_242, V v_box_24lit_243, V v_x2_244, V v_d_245) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return heff_setField(v_d_245, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    if (((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_246, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_246, v_lit_242, 0)) == v_lit_243) : 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_249 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ys_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_xs_247;
      V t_5 = v_cell_248;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    } else {
      heff_drop(v_x_246);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      V t_0 = v_ys_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_xs_247;
      V t_5 = v_d_245;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_prelude_2e_2b_2b_24f292729551x60683815_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f292729551x60683815_24dps(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_str0, 1, ":");
Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_x_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_str0)), v_x_243);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_x_247 = v_y_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1085359736x1262841716_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f892794188x1384814865_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f892794188x1384814865_entry, 3, 0};

V g_prelude_2e_2b_2b_24f892794188x1384814865(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_241))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f892794188x1384814865_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f892794188x1384814865(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1537904782x516751275_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1537904782x516751275_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1537904782x516751275(V v_ys_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_p2_243 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_prelude_2e_2b_2b_24f1537904782x516751275_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_241_24At, 2);
        heff_drop(v_x_244);
        return v_ys_240;
      } else {
        V v_x_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        V v_t_246 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_245, v_t_246});
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2411, v_ys_240));
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2416, v_ys_240));
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatBinary: {
      V v_segs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2420));
      V v_t_2422 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2421); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2422, v_ys_240));
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatRecord: {
      V v_fs_2424 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2425); r_; });
      return (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2426, v_ys_240));
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return v_ys_240;
    }
    case TAG_PatAs: {
      V v_x_2428 = heff_field(v_p1_242, 0);
      V v_sp_2429 = heff_field(v_p1_242, 1);
      V v_q_2430 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_x_2431 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2428, v_sp_2429, NTAG(TAG_False)});
      V v_cell_2432 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2431, heff_hole()});
      V v_u_2433 = (g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(v_ys_240, v_q_2430, heff_dup(v_cell_2432)));
      heff_drop(v_u_2433);
      return v_cell_2432;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1537904782x516751275(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f1876770336x1656095219_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1876770336x1656095219_entry, 5, 0};

V g_prelude_2e_2b_2b_24f1876770336x1656095219(V v_ys_240, V v_owner_241, V v_launch_242, V v_i_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_owner_241);
    heff_drop(v_launch_242);
    heff_drop(v_i_243);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_244, 0);
    V v_rest_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_name_247 = heff_field(v_x41_245, 0);
      V v_limit_248 = heff_field(v_x41_245, 1);
      V v_ru_24x41_245_24MkPair = heff_take_reuse_n(v_x41_245, 3ULL, 2);
      V v_t_249 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_243), NTAG(TAG_Nil)});
      V v_x_2410 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(v_owner_241), heff_dup(v_launch_242), v_t_249, v_name_247, NTAG(TAG_Nil), v_limit_248});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x41_245_24MkPair, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2412 = (g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps(v_ys_240, v_owner_241, v_launch_242, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL))), v_rest_246, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_prelude_2e_2b_2b_24f1876770336x1656095219_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1876770336x1656095219(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_prelude_2e_2b_2b_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24tok2_entry, 3, 0};

V g_prelude_2e_2b_2b_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24tok2(a[0], a[1], a[2]);
}