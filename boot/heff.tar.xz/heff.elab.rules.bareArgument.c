// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
V g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241(V, V);
V g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
Clo g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241_entry, 2, 0};

V g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241(V v_mc_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_SpId: {
    return NTAG(TAG_False);
  }
  case TAG_SpApp: {
    V v_sp_242 = heff_field(v_x1_241, 0);
    V v_a_243 = heff_field(v_x1_241, 1);
    V v_v_244 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, heff_dup(v_a_243)));
    switch (heff_tag_of(v_v_244)) {
    case TAG_VNeu: {
      V v_v1_245 = heff_field(v_v_244, 0);
      heff_take_n(v_v_244, 1ULL, 5);
      switch (heff_tag_of(v_v1_245)) {
      case TAG_HLocal: {
        heff_take_n(v_v1_245, 0ULL, 1);
        V t_0 = v_mc_240;
        V t_1 = v_sp_242;
        v_mc_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_HGlobal: {
        heff_take_n(v_v1_245, 0ULL, 1);
        V t_0 = v_mc_240;
        V t_1 = v_sp_242;
        v_mc_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_HMeta: {
        heff_take_n(v_v1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_HError: {
        V t_0 = v_mc_240;
        V t_1 = v_sp_242;
        v_mc_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_v1_245);
      }
    }
    case TAG_VCode: {
      heff_take_n(v_v_244, 0ULL, 1);
      V t_0 = v_mc_240;
      V t_1 = v_sp_242;
      v_mc_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_VLam: {
      heff_take_n(v_v_244, 0ULL, 2);
      V t_0 = v_mc_240;
      V t_1 = v_sp_242;
      v_mc_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_v_244, 0ULL, 1);
      V t_0 = v_mc_240;
      V t_1 = v_sp_242;
      v_mc_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    case TAG_VOpaque: {
      V t_0 = v_mc_240;
      V t_1 = v_sp_242;
      v_mc_240 = t_0;
      v_x1_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_v_244);
    }
  }
  case TAG_SpProj: {
    V v_sp_2417 = heff_field(v_x1_241, 0);
    V t_0 = v_mc_240;
    V t_1 = v_sp_2417;
    v_mc_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_2419 = heff_field(v_x1_241, 0);
    V t_0 = v_mc_240;
    V t_1 = v_sp_2419;
    v_mc_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2ebareArgument_2ebareIn_241(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}