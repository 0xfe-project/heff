// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CSharedPointer 39972
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_byName 571997869
#define LBL_entries 787768015
#define LBL_order 307364712
#define LBL_tySyntax 1405311289
#define LBL_values 1123329101
V g_heff_2ecompile_2eglue_2eappendF(V, V);
V g_heff_2ecompile_2eglue_2eappendF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eappendF_clo;
V g_heff_2ecompile_2eglue_2eappendF_24dps(V, V, V);
V g_heff_2ecompile_2eglue_2eappendF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eappendF_24dps_clo;
HeffT2 g_heff_2ecompile_2eglue_2eargBad_24cpr(V, V, V, V);
V g_heff_2ecompile_2eglue_2eargsBad(V, V, V, V);
V g_heff_2ecompile_2eglue_2eargsBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eargsBad_clo;
V g_heff_2ecompile_2eglue_2ecResultOf(V);
V g_heff_2ecompile_2eglue_2ecResultOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ecResultOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1899415673x1401347262_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2efieldOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eglue_2efirstBad_24cpr(V);
V g_heff_2ecompile_2eglue_2efits(V, V);
V g_heff_2ecompile_2eglue_2efits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2efits_clo;
V g_heff_2ecompile_2eglue_2eisGlobalTy(V, V);
V g_heff_2ecompile_2eglue_2eisGlobalTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eisGlobalTy_clo;
HeffT2 g_heff_2ecompile_2eglue_2elistOf_24cpr(V);
V g_heff_2ecompile_2eglue_2eofType(V, V, V);
V g_heff_2ecompile_2eglue_2eofType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eofType_clo;
HeffT2 g_heff_2ecompile_2eglue_2ereadDescribed_24cpr(V);
V g_heff_2ecompile_2eglue_2etyOf(V);
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2etyOf_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2ecompile_2eglue_2eappendF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eappendF_entry, 2, 0};

V g_heff_2ecompile_2eglue_2eappendF(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eglue_2eappendF_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2eappendF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2eappendF(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eglue_2elistOf_24cpr_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2eglue_2elistOf_24cpr_str1, 4, "Cons");

HeffT2 g_heff_2ecompile_2eglue_2elistOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VTag: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2elistOf_24cpr_str0), 2)) {
      heff_drop(v_x11_243);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
      }
      case TAG_Cons: {
        heff_take_n(v_x12_244, 0ULL, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
      }
    } else {
      if (heff_strEq_c(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2elistOf_24cpr_str1))) {
        switch (heff_tag_of(v_x12_244)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_x12_244, 0);
          V v_x122_2410 = heff_field(v_x12_244, 1);
          heff_take_n(v_x12_244, 3ULL, 2);
          switch (heff_tag_of(v_x122_2410)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_249);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_rest_2411 = heff_field(v_x122_2410, 0);
            V v_x1222_2412 = heff_field(v_x122_2410, 1);
            heff_take_n(v_x122_2410, 3ULL, 2);
            switch (heff_tag_of(v_x1222_2412)) {
            case TAG_Nil: {
              HeffT2 v_t_2413 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_rest_2411));
              {
                V v_field_2415 = v_t_2413.f[1];
                int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  V v_xs_2417 = v_field_2415;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_249, v_xs_2417})}});
                } else {
                  heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                  heff_drop(v_x_249);
                  heff_drop(v_field_2415);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_x1222_2412, 0ULL, 2);
              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
              heff_drop(v_x_249);
              heff_drop(v_rest_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x1222_2412)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x122_2410)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
        }
      } else {
        heff_drop(v_x12_244);
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eglue_2efieldOf_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_fs_243, 1), v_x_241));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_i_248 = v_field_246;
        V v_xs_249 = heff_get_n(v_fs_243, 2, 3);
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_248, 1)) {
          if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength_lent(v_xs_249, 0))) {
            V v_f_2412 = heff_arrayIndex(v_xs_249, v_i_248);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
          } else {
            heff_drop(v_i_248);
            heff_drop(v_xs_249);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_i_248);
          heff_drop(v_xs_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop_rec(v_fs_243, 3);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_VTag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ecResultOf_str0, 5, "Gives");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecResultOf_str1, 12, "GivesOrErrno");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecResultOf_str2, 11, "DoneOrErrno");
Clo g_heff_2ecompile_2eglue_2ecResultOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ecResultOf_entry, 1, 0};

V g_heff_2ecompile_2eglue_2ecResultOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VCons: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VTag: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecResultOf_str0), 2)) {
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nil: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_t_246 = heff_field(v_x12_244, 0);
        V v_x122_247 = heff_field(v_x12_244, 1);
        switch (heff_tag_of(v_x122_247)) {
        case TAG_Nil: {
          HeffT2 v_t_248 = (g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(heff_dup(v_t_246)));
          {
            V v_field_2410 = v_t_248.f[1];
            int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
            if ((v_tag_249 == ((int64_t)0ULL))) {
              V v_c_2412 = v_field_2410;
              return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Gives, 1, (V[]){v_c_2412})});
            } else {
              heff_drop(v_field_2410);
              return NTAG(TAG_Nothing);
            }
          }
        }
        case TAG_Cons: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_247);
        }
      }
      default: return heff_nomatch(v_x12_244);
      }
    } else {
      if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecResultOf_str1), 2)) {
        switch (heff_tag_of(v_x12_244)) {
        case TAG_Nil: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_t_2416 = heff_field(v_x12_244, 0);
          V v_x122_2417 = heff_field(v_x12_244, 1);
          switch (heff_tag_of(v_x122_2417)) {
          case TAG_Nil: {
            HeffT2 v_t_2418 = (g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(heff_dup(v_t_2416)));
            {
              V v_field_2420 = v_t_2418.f[1];
              int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
              if ((v_tag_2419 == ((int64_t)0ULL))) {
                V v_c_2422 = v_field_2420;
                return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_GivesOrErrno, 1, (V[]){v_c_2422})});
              } else {
                heff_drop(v_field_2420);
                return NTAG(TAG_Nothing);
              }
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_x122_2417);
          }
        }
        default: return heff_nomatch(v_x12_244);
        }
      } else {
        if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecResultOf_str2), 2)) {
          switch (heff_tag_of(v_x12_244)) {
          case TAG_Nil: {
            return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_DoneOrErrno)});
          }
          case TAG_Cons: {
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_x12_244);
          }
        } else {
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
  case TAG_VInt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VFloat: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VFloat32: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VStr: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VRune: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VArr: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VBytes: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VBits: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VErased: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2ecResultOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eglue_2ecResultOf(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_v_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(v_v_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        HeffT2 v_t_248 = (g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(v_rest_242));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_xs_2412 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_xs_2412})}});
          } else {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_247);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_v_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VFun: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VCons: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VTag: {
      heff_take_n(v_v_241, 0ULL, 2);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VInt: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_v_241, 0);
      heff_take_n(v_v_241, 1ULL, 1);
      HeffT2 v_t_2411 = (g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(v_rest_242));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_xs_2415 = v_field_2413;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_s_2410, v_xs_2415})}});
        } else {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_s_2410);
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_VRune: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241, 0ULL, 2);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VErased: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_v_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadDescribed_24cpr_str0, 8, "Describe");

HeffT2 g_heff_2ecompile_2eglue_2ereadDescribed_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VTag: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ereadDescribed_24cpr_str0))) {
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_incs_246 = heff_field(v_x12_244, 0);
        V v_x122_247 = heff_field(v_x12_244, 1);
        heff_take_n(v_x12_244, 3ULL, 2);
        switch (heff_tag_of(v_x122_247)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          heff_drop(v_incs_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_ops_248 = heff_field(v_x122_247, 0);
          V v_x1222_249 = heff_field(v_x122_247, 1);
          heff_take_n(v_x122_247, 3ULL, 2);
          switch (heff_tag_of(v_x1222_249)) {
          case TAG_Nil: {
            HeffT2 v_t_2410 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_incs_246));
            {
              V v_field_2412 = v_t_2410.f[1];
              int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
              if ((v_tag_2411 == ((int64_t)0ULL))) {
                V v_x_2414 = v_field_2412;
                HeffT2 v_t_2415 = (g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(v_x_2414));
                {
                  V v_field_2417 = v_t_2415.f[1];
                  int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
                  if ((v_tag_2416 == ((int64_t)0ULL))) {
                    V v_is_2419 = v_field_2417;
                    HeffT2 v_t_2420 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_ops_248));
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x_2424 = v_field_2422;
                        HeffT2 v_t_2425 = (g_heff_2ecompile_2eglue_2eeachOf_24s1899415673x1401347262_24cpr(v_x_2424));
                        {
                          V v_field_2427 = v_t_2425.f[1];
                          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
                          if ((v_tag_2426 == ((int64_t)0ULL))) {
                            V v_os_2429 = v_field_2427;
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_MkPair, 2, (V[]){v_is_2419, v_os_2429})}});
                          } else {
                            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                            heff_drop(v_is_2419);
                            heff_drop(v_field_2427);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                        heff_drop(v_is_2419);
                        heff_drop(v_field_2422);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                    heff_drop(v_ops_248);
                    heff_drop(v_field_2417);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              } else {
                heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                heff_drop(v_ops_248);
                heff_drop(v_field_2412);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_x1222_249, 0ULL, 2);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_incs_246);
            heff_drop(v_ops_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1222_249)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x122_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
      }
    } else {
      heff_drop(v_x12_244);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str3, 1, ".");
V g_heff_2ecompile_2eglue_2eofType_lam0(V self, V *args);
V g_heff_2ecompile_2eglue_2eofType_lam1(V self, V *args);
Clo g_heff_2ecompile_2eglue_2eofType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eofType_entry, 3, 0};

V g_heff_2ecompile_2eglue_2eofType(V v_g_240, V v_m_241, V v_t_242) {
top: ;
  V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eglue_2eofType_lam0, 2, 1, (V[]){heff_dup(v_g_240)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_g_240, 0, 8); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2424 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eglue_2eofType_lam1, 1, 2, (V[]){heff_dup(v_m_241), heff_dup(v_t_242)}), v_t_2410));
  return (g_list_2emap_24s1937570095x2110149801(v_t_2424));
}
V g_heff_2ecompile_2eglue_2eofType_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eglue_2eofType(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eglue_2eofType_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_k_244 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_e_249 = v_field_247;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_244, v_e_249}), v_acc_243});
    } else {
      heff_drop(v_k_244);
      heff_drop(v_field_247);
      return v_acc_243;
    }
  }
}
V g_heff_2ecompile_2eglue_2eofType_lam1(V self, V *args) {
  V v_p_2411 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_k_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_dup(heff_field(v_p_2411, 0));
    v_k_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  V v_t_2415 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2eofType_str0); V a_1 = v_k_2414; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2eofType_str1), v_k_2414, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_k_2414); r_; });
  V v_x2_2416 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2415));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eofType_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2eofType_str3); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  if (heff_strEq_c(v_t_2419, v_m_241)) {
    V v_t_2423;
    switch (heff_tag_of(v_p_2411)) {
    case TAG_MkPair: {
      V v_y_2422 = heff_field(v_p_2411, 1);
      heff_take_n(v_p_2411, 2ULL, 2);
      v_t_2423 = v_y_2422;
      break;
    }
    default: heff_nomatch(v_p_2411);
    }
    return ({ V a_0 = v_t_242; V a_1 = heff_get_n(v_t_2423, 1, 4); V r_ = (g_heff_2ecompile_2eglue_2eisGlobalTy(a_0, a_1)); heff_drop(v_t_242); r_; });
  } else {
    heff_drop(v_p_2411);
    heff_drop(v_t_242);
    return NTAG(TAG_False);
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str0, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str1, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str2, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str3, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str4, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str5, 12, "builtin.Unit");
Clo g_heff_2ecompile_2eglue_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2efits_entry, 2, 0};

V g_heff_2ecompile_2eglue_2efits(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CInteger: {
    heff_take_n(v_x1_240, 0ULL, 1);
    V v_it_243 = (g_heff_2ecompile_2eglue_2etyOf(v_x2_241));
    switch (heff_tag_of(v_it_243)) {
    case TAG_SU: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_245 = heff_field(v_it_243, 0);
      heff_take_n(v_it_243, 1ULL, 1);
      switch (heff_tag_of(v_it1_245)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_247 = heff_field(v_it1_245, 0);
        heff_take_n(v_it1_245, 1ULL, 1);
        if (heff_strEq_c(v_g_247, ((V)&g_heff_2ecompile_2eglue_2efits_str0))) {
          return NTAG(TAG_False);
        } else {
          return NTAG(TAG_True);
        }
      }
      case TAG_SCode: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_245);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_243, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_243, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_True);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_243);
    }
  }
  case TAG_CDouble: {
    V v_it_2454 = (g_heff_2ecompile_2eglue_2etyOf(v_x2_241));
    switch (heff_tag_of(v_it_2454)) {
    case TAG_SU: {
      heff_take_n(v_it_2454, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_2456 = heff_field(v_it_2454, 0);
      heff_take_n(v_it_2454, 1ULL, 1);
      switch (heff_tag_of(v_it1_2456)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_2458 = heff_field(v_it1_2456, 0);
        heff_take_n(v_it1_2456, 1ULL, 1);
        if (heff_strEq_c(v_g_2458, ((V)&g_heff_2ecompile_2eglue_2efits_str1))) {
          return NTAG(TAG_False);
        } else {
          return NTAG(TAG_True);
        }
      }
      case TAG_SCode: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_2456, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_2456, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_2456, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_2456, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_2456);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_2454, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_2454, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_2454, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_2454, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_True);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_2454, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_2454, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_2454);
    }
  }
  case TAG_CBool: {
    V v_it_24105 = (g_heff_2ecompile_2eglue_2etyOf(v_x2_241));
    switch (heff_tag_of(v_it_24105)) {
    case TAG_SU: {
      heff_take_n(v_it_24105, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24107 = heff_field(v_it_24105, 0);
      heff_take_n(v_it_24105, 1ULL, 1);
      switch (heff_tag_of(v_it1_24107)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24109 = heff_field(v_it1_24107, 0);
        heff_take_n(v_it1_24107, 1ULL, 1);
        return heff_strEq(v_g_24109, ((V)&g_heff_2ecompile_2eglue_2efits_str2));
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24107, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24107, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24107, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24107, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24107);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24105, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24105, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24105, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24105, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24105, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24105, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24105);
    }
  }
  case TAG_CString: {
    top_TAG_CString: ;
    V v_it_24155 = (g_heff_2ecompile_2eglue_2etyOf(v_x2_241));
    switch (heff_tag_of(v_it_24155)) {
    case TAG_SU: {
      heff_take_n(v_it_24155, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24157 = heff_field(v_it_24155, 0);
      heff_take_n(v_it_24155, 1ULL, 1);
      switch (heff_tag_of(v_it1_24157)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24159 = heff_field(v_it1_24157, 0);
        heff_take_n(v_it1_24157, 1ULL, 1);
        if (heff_strEq_c(v_g_24159, ((V)&g_heff_2ecompile_2eglue_2efits_str3))) {
          return NTAG(TAG_False);
        } else {
          return NTAG(TAG_True);
        }
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24157, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24157, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24157, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24157, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24157);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24155, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24155, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24155, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24155, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_True);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24155, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24155, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24155);
    }
  }
  case TAG_CText: {
    V t_0 = NTAG(TAG_CString);
    V t_1 = v_x2_241;
    v_x1_240 = t_0;
    v_x2_241 = t_1;
    goto top_TAG_CString;
  }
  case TAG_COwnedString: {
    V t_0 = NTAG(TAG_CString);
    V t_1 = v_x2_241;
    v_x1_240 = t_0;
    v_x2_241 = t_1;
    goto top_TAG_CString;
  }
  case TAG_CPointer: {
    heff_take_n(v_x1_240, 0ULL, 2);
    V v_it_24208 = (g_heff_2ecompile_2eglue_2etyOf(v_x2_241));
    switch (heff_tag_of(v_it_24208)) {
    case TAG_SU: {
      heff_take_n(v_it_24208, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24210 = heff_field(v_it_24208, 0);
      heff_take_n(v_it_24208, 1ULL, 1);
      switch (heff_tag_of(v_it1_24210)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24212 = heff_field(v_it1_24210, 0);
        heff_take_n(v_it1_24210, 1ULL, 1);
        if (heff_strEq_c(v_g_24212, ((V)&g_heff_2ecompile_2eglue_2efits_str4))) {
          return NTAG(TAG_False);
        } else {
          return NTAG(TAG_True);
        }
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24210, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24210, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24210, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24210, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24210);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24208, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24208, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24208, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24208, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24208, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24208, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24208);
    }
  }
  case TAG_CSharedPointer: {
    V v_t_24259 = heff_field(v_x1_240, 0);
    V v_r_24260 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V t_0 = heff_tag_n(TAG_CPointer, 2, (V[]){v_t_24259, v_r_24260});
    V t_1 = v_x2_241;
    v_x1_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CVoid: {
    V v_it_24262 = (g_heff_2ecompile_2eglue_2etyOf(v_x2_241));
    switch (heff_tag_of(v_it_24262)) {
    case TAG_SU: {
      heff_take_n(v_it_24262, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24264 = heff_field(v_it_24262, 0);
      heff_take_n(v_it_24262, 1ULL, 1);
      switch (heff_tag_of(v_it1_24264)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24266 = heff_field(v_it1_24264, 0);
        heff_take_n(v_it1_24264, 1ULL, 1);
        return heff_strEq(v_g_24266, ((V)&g_heff_2ecompile_2eglue_2efits_str5));
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24264, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24264, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24264, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24264, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24264);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24262, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24262, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24262, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24262, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24262, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24262, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24262);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2efits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2efits(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eglue_2efirstBad_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_m_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop(v_rest_242);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_m_243}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str3, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str4, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str5, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str6, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str7, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str8, 18, " is described as `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str9, 18, "`, a result's type");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str10, 13, "`'s argument ");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str11, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str12, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str13, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str14, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str15, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str16, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str17, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str18, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str19, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str20, 26, " cannot be given to C as `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str21, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str22, 10, "`'s field ");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str23, 1, "`");

HeffT2 g_heff_2ecompile_2eglue_2eargBad_24cpr(V v_tag_240, V v_i_241, V v_c_242, V v_t_243) {
top: ;
  V v_t_2410;
  switch (heff_tag_of(v_c_242)) {
  case TAG_CInteger: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_CDouble: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_CBool: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_CString: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_CText: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_COwnedString: {
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  case TAG_CPointer: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_CSharedPointer: {
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  case TAG_CVoid: {
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
    V v_t_2418;
    switch (heff_tag_of(v_c_242)) {
    case TAG_CInteger: {
      V v_t_2412 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 1);
      v_t_2418 = v_t_2412;
      break;
    }
    case TAG_CDouble: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str0);
      break;
    }
    case TAG_CBool: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str1);
      break;
    }
    case TAG_CString: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str2);
      break;
    }
    case TAG_CText: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str4);
      break;
    }
    case TAG_CPointer: {
      V v_t_2413 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 2);
      v_t_2418 = heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str5));
      break;
    }
    case TAG_CSharedPointer: {
      V v_t_2415 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 3);
      v_t_2418 = heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str6));
      break;
    }
    case TAG_CVoid: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str7);
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str8), heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str9)));
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str10), heff_strAppend(v_t_2411, v_t_2419));
    V v_f_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str11), heff_strAppend(v_tag_240, v_t_2420));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
  } else {
    heff_drop(v_t_2410);
    V v_t_2422 = (g_heff_2ecompile_2eglue_2efits(heff_dup(v_c_242), v_t_243));
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_tag_240);
      heff_drop(v_i_241);
      heff_drop(v_c_242);
      heff_drop(v_t_2422);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2422);
      V v_t_2423 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
      V v_t_2430;
      switch (heff_tag_of(v_c_242)) {
      case TAG_CInteger: {
        V v_t_2424 = heff_field(v_c_242, 0);
        heff_take_n(v_c_242, 1ULL, 1);
        v_t_2430 = v_t_2424;
        break;
      }
      case TAG_CDouble: {
        v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str12);
        break;
      }
      case TAG_CBool: {
        v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str13);
        break;
      }
      case TAG_CString: {
        v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str14);
        break;
      }
      case TAG_CText: {
        v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str15);
        break;
      }
      case TAG_COwnedString: {
        v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str16);
        break;
      }
      case TAG_CPointer: {
        V v_t_2425 = heff_field(v_c_242, 0);
        heff_take_n(v_c_242, 1ULL, 2);
        v_t_2430 = heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str17));
        break;
      }
      case TAG_CSharedPointer: {
        V v_t_2427 = heff_field(v_c_242, 0);
        heff_take_n(v_c_242, 1ULL, 3);
        v_t_2430 = heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str18));
        break;
      }
      case TAG_CVoid: {
        v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str19);
        break;
      }
      default: heff_nomatch(v_c_242);
      }
      V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str20), heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str21)));
      V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str22), heff_strAppend(v_t_2423, v_t_2431));
      V v_f_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str23), heff_strAppend(v_tag_240, v_t_2432));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
    }
  }
}
Clo g_heff_2ecompile_2eglue_2eargsBad_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eargsBad_entry, 4, 0};

V g_heff_2ecompile_2eglue_2eargsBad(V v_tag_240, V v_i_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_tag_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_cs_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_tag_240);
      heff_drop(v_i_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_t_246 = heff_field(v_x4_243, 0);
      V v_ts_247 = heff_field(v_x4_243, 1);
      HeffT2 v_t_248 = (g_heff_2ecompile_2eglue_2eargBad_24cpr(heff_dup(v_tag_240), heff_dup(v_i_241), heff_dup(v_c_244), heff_dup(v_t_246)));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop(v_tag_240);
          heff_drop(v_i_241);
          V v_m_2412 = v_field_2410;
          return heff_tag_n(TAG_Just, 1, (V[]){v_m_2412});
        } else {
          heff_drop(v_field_2410);
          V t_0 = v_tag_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_cs_245;
          V t_3 = v_ts_247;
          v_tag_240 = t_0;
          v_i_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eglue_2eargsBad_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eglue_2eargsBad(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}