// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_Case 4415
#define TAG_DData 48360
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EFor 37939
#define TAG_EUSet 22856
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_MkDAlts 45152
#define TAG_MkSep 6724
#define TAG_Op 9330
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PParen 60953
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Sum 30935
#define TAG_Throw 56084
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_blockArg 80527375
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_head 9693863
#define LBL_i 323
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_patAtom 1586746071
#define LBL_pattern 1588251091
#define LBL_raw 322210
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2eanonymousSumF(V, V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_clo;
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo;
V g_heff_2esyntax_2ecst_2eappF(V, V, V);
V g_heff_2esyntax_2ecst_2eappF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1665400558x5238564(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1665400558x5238564_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1665400558x5238564_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628(V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628_clo;
V g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004_clo;
V g_heff_2esyntax_2ecst_2eappF_24s703112455x1201014747(V, V);
V g_heff_2esyntax_2ecst_2eappF_24s703112455x1201014747_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s703112455x1201014747_clo;
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo;
V g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804(V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatTok(V, V, V);
V g_heff_2esyntax_2ecst_2eatTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatTok_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_clo;
V g_heff_2esyntax_2ecst_2ecaseExprF(V, V, V);
V g_heff_2esyntax_2ecst_2ecaseExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecaseExprF_clo;
V g_heff_2esyntax_2ecst_2echeckAltNames(V, V);
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo;
V g_heff_2esyntax_2ecst_2econdF(V, V, V);
V g_heff_2esyntax_2ecst_2econdF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econdF_clo;
V g_heff_2esyntax_2ecst_2econtinuesBlock(V, V);
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edataAlternative(V, V);
V g_heff_2esyntax_2ecst_2edataAlternative_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataAlternative_clo;
V g_heff_2esyntax_2ecst_2edataDecl(V, V, V);
V g_heff_2esyntax_2ecst_2edataDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataDecl_clo;
V g_heff_2esyntax_2ecst_2edataParam(V, V);
V g_heff_2esyntax_2ecst_2edataParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataParam_clo;
V g_heff_2esyntax_2ecst_2edefaultedF(V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_clo;
V g_heff_2esyntax_2ecst_2eendBefore(V, V);
V g_heff_2esyntax_2ecst_2eendBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eendBefore_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2efixityRest(V, V, V);
V g_heff_2esyntax_2ecst_2efixityRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efixityRest_clo;
V g_heff_2esyntax_2ecst_2eforF(V, V, V);
V g_heff_2esyntax_2ecst_2eforF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eforF_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eifExprF(V, V, V);
V g_heff_2esyntax_2ecst_2eifExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifExprF_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emanyParams(V, V, V);
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyParams_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_clo;
V g_heff_2esyntax_2ecst_2epatAtomF(V, V, V);
V g_heff_2esyntax_2ecst_2epatAtomF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatAtomF_clo;
V g_heff_2esyntax_2ecst_2epatSegmentF(V, V, V);
V g_heff_2esyntax_2ecst_2epatSegmentF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatSegmentF_clo;
V g_heff_2esyntax_2ecst_2erecordPatF(V, V, V);
V g_heff_2esyntax_2ecst_2erecordPatF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2erecordPatF_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etheoryField(V, V);
V g_heff_2esyntax_2ecst_2etheoryField_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryField_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str5, 0, "");
Clo g_heff_2esyntax_2ecst_2etokAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etokAt_entry, 2, 0};

V g_heff_2esyntax_2ecst_2etokAt(V v_s_240, V v_j_241) {
top: ;
  V v_xs_242 = heff_dup(heff_rfield(v_s_240, 0));
  if (heff_intLe_c_lent(MK_INT(0LL), v_j_241, 1)) {
    if (heff_intLt_c(heff_dup(v_j_241), heff_arrayLength_lent(v_xs_242, 0))) {
      V v_t_245 = heff_arrayIndex_lent(v_xs_242, v_j_241, 1);
      return (g_heff_2esyntax_2ecst_2eatTok(v_s_240, v_j_241, v_t_245));
    } else {
      heff_drop(v_xs_242);
      V v_e_246 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2etokAt_str0), ((V)&g_heff_2esyntax_2ecst_2etokAt_str1), ((V)&g_heff_2esyntax_2ecst_2etokAt_str2), heff_dup(v_e_246), v_e_246, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
  } else {
    heff_drop(v_xs_242);
    V v_e_247 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
    return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2etokAt_str3), ((V)&g_heff_2esyntax_2ecst_2etokAt_str4), ((V)&g_heff_2esyntax_2ecst_2etokAt_str5), heff_dup(v_e_247), v_e_247, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  }
}
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etokAt(a[0], a[1]);
}
Clo g_heff_2esyntax_2ecst_2ecur_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ecur_entry, 1, 0};

V g_heff_2esyntax_2ecst_2ecur(V v_s_240) {
top: ;
  return (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_get_n(v_s_240, 1, 5)));
}
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ecur(a[0]);
}
V g_heff_2esyntax_2ecst_2enextN_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2enextN_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2enextN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enextN_entry, 3, 0};

V g_heff_2esyntax_2ecst_2enextN(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  } else {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_p_241), heff_clo_n(g_heff_2esyntax_2ecst_2enextN_lam0, 1, 3, (V[]){v_n_240, v_p_241, v_p_242})));
  }
}
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2enextN(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2enextN_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2enextN_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2enextN_clo), 1, (V[]){heff_intSub(v_n_240, MK_INT(1LL))}));
  V f_ = v_c_245;
  heff_room[0] = v_p_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enextN_lam1, 1, 2, (V[]){v_p_242, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eappF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_dup(heff_rfield(v_g_240, 4)), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eappF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eappF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_x_244, v_t_2416));
  V v_x_2418 = heff_tag_n(TAG_App, 2, (V[]){v_x_243, v_t_2417});
  V f_ = v_k_242;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eappF_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_hd_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = heff_take_field(v_g_240, 16);
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eappF_str0))) {
      if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eappF_str1))) {
        if ((heff_dup(v_x_248) == NTAG(TAG_True))) {
          heff_drop(v_x_248);
          heff_drop_rec(v_g_240, 17);
          heff_drop_rec(v_hd_241, 3);
          V v_t_2414;
          switch (heff_tag_of(v_x_244)) {
          case TAG_Nil: {
            v_t_2414 = v_x_243;
            break;
          }
          case TAG_Cons: {
            v_t_2414 = heff_tag_n(TAG_App, 2, (V[]){v_x_243, v_x_244});
            break;
          }
          default: heff_nomatch(v_x_244);
          }
          V f_ = v_k_242;
          args[0] = v_t_2414;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_x_248);
          V f_ = heff_get_n(v_g_240, 11, 17);
          heff_room[0] = v_hd_241;
          heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_lam4, 1, 3, (V[]){v_x_244, v_x_243, v_k_242});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop(v_x_248);
        heff_drop_rec(v_g_240, 17);
        heff_drop_rec(v_hd_241, 3);
        V v_t_2421;
        switch (heff_tag_of(v_x_244)) {
        case TAG_Nil: {
          v_t_2421 = v_x_243;
          break;
        }
        case TAG_Cons: {
          v_t_2421 = heff_tag_n(TAG_App, 2, (V[]){v_x_243, v_x_244});
          break;
        }
        default: heff_nomatch(v_x_244);
        }
        V f_ = v_k_242;
        args[0] = v_t_2421;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      heff_drop(v_x_248);
      heff_drop_rec(v_g_240, 17);
      heff_drop_rec(v_x_247, 9);
      heff_drop_rec(v_hd_241, 3);
      V v_t_2424;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Nil: {
        v_t_2424 = v_x_243;
        break;
      }
      case TAG_Cons: {
        v_t_2424 = heff_tag_n(TAG_App, 2, (V[]){v_x_243, v_x_244});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V f_ = v_k_242;
      args[0] = v_t_2424;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_248);
    heff_drop_rec(v_g_240, 17);
    heff_drop_rec(v_x_247, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop(v_t_249);
    V v_t_2427;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Nil: {
      v_t_2427 = v_x_243;
      break;
    }
    case TAG_Cons: {
      v_t_2427 = heff_tag_n(TAG_App, 2, (V[]){v_x_243, v_x_244});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V f_ = v_k_242;
    args[0] = v_t_2427;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eappF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_lam3, 1, 6, (V[]){v_g_240, v_x_247, v_x_244, v_x_243, v_k_242, v_hd_241})));
}
V g_heff_2esyntax_2ecst_2eappF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_244, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(v_g_240, 4)), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edefaultedF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_dup(heff_rfield(v_g_240, 0)), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2edefaultedF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_243, v_x_2410, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam4, 1, 3, (V[]){v_k_242, v_x_243, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_243, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam6, 1, 3, (V[]){v_k_242, v_x_243, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_str1))) {
      heff_drop_rec(v_x_246, 9);
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 17);
        V f_ = v_k_242;
        args[0] = v_x_243;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_247);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam3, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})));
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_str2))) {
        if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
          heff_drop(v_x_247);
          heff_drop_rec(v_hd_241, 3);
          heff_drop_rec(v_g_240, 17);
          V f_ = v_k_242;
          args[0] = v_x_243;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_x_247);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam5, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})));
        }
      } else {
        heff_drop(v_x_247);
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 17);
        V f_ = v_k_242;
        args[0] = v_x_243;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 17);
    V f_ = v_k_242;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam2, 1, 5, (V[]){v_x_246, v_k_242, v_x_243, v_hd_241, v_g_240})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam1, 1, 4, (V[]){v_hd_241, v_k_242, v_x_243, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_str0, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_str1, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_str2, 1, "}");
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eanonymousSumF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eanonymousSumF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eanonymousSumF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eanonymousSumF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_ECon, 2, (V[]){v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_get_n(v_g_240, 4, 17), NTAG(TAG_Nil), v_hd_245, heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam4, 1, 2, (V[]){v_k_246, v_x_247})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam2(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam3, 1, 3, (V[]){v_g_240, v_hd_245, v_k_246})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam8(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkSep: {
    V v_items_2416 = heff_field(v_x_2414, 0);
    V v_seps_2417 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_t_2418 = heff_tag_n(TAG_Sum, 5, (V[]){v_x_243, v_x_244, v_items_2416, v_seps_2417, v_x_2415});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_2411;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam7(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_str2), v_hd_2410, heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam8, 1, 4, (V[]){v_x_2414, v_x_243, v_x_244, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam6(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_249 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_str1); V a_1 = v_p_249; V a_2 = v_t_2413; V a_3 = NTAG(TAG_Nil); V a_4 = heff_dup(v_hd_2410); V a_5 = heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam7, 1, 4, (V[]){v_hd_2410, v_x_243, v_x_244, v_k_2411}); V r_ = (g_heff_2esyntax_2ecst_2esepGo(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam5(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(v_p_249);
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam6, 1, 5, (V[]){v_p_249, v_hd_2410, v_x_243, v_x_244, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_249 = heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam2, 2, 1, (V[]){v_g_240});
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam5, 2, 3, (V[]){v_p_249, v_x_243, v_x_244}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam1, 1, 4, (V[]){v_g_240, v_x_243, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ecaseExprF_str0, 2, "of");
HEFF_LIT(g_heff_2esyntax_2ecst_2ecaseExprF_str1, 2, "->");
V g_heff_2esyntax_2ecst_2ecaseExprF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ecaseExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ecaseExprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ecaseExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ecaseExprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam6(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_EAlt, 3, (V[]){v_x_248, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam5(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam6, 1, 3, (V[]){v_k_247, v_x_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ecaseExprF_str1), heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam5, 1, 4, (V[]){v_g_240, v_hd_246, v_k_247, v_x_248})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam3(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_g_240, 5));
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam4, 1, 3, (V[]){v_hd_246, v_g_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam7(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Case, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam3, 2, 1, (V[]){v_g_240}), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam7, 1, 4, (V[]){v_k_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2ecaseExprF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eifExprF_str0, 4, "then");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifExprF_str1, 4, "else");
V g_heff_2esyntax_2ecst_2eifExprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eifExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eifExprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eifExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eifExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eifExprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eifExprF_lam5(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_If, 6, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eifExprF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam5, 1, 6, (V[]){v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifExprF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eifExprF_str1), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam4, 1, 7, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2eifExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam3, 1, 6, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eifExprF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eifExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2econdF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eforF_str0, 2, "in");
HEFF_LIT(g_heff_2esyntax_2ecst_2eforF_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eforF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eforF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eforF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eforF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eforF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eforF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eforF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eforF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eforF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eforF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eforF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eforF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eforF_lam5(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EFor, 6, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eforF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_240, 14, 17), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2eforF_lam5, 1, 6, (V[]){v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_x_247})));
}
V g_heff_2esyntax_2ecst_2eforF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eforF_str1), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eforF_lam4, 1, 7, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2eforF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_g_240, 13));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eforF_lam3, 1, 6, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eforF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eforF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eforF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eforF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 5));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eforF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str0, 18, "expected a pattern");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str2, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str3, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str4, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str5, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str6, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str7, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str8, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str9, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str10, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str11, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str12, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str13, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str14, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str15, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str16, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str17, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str18, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str19, 47, "a pattern negates only a number, its sign: `-1`");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str20, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str21, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str24, 24, "expected a pattern, not ");
V g_heff_2esyntax_2ecst_2epatAtomF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2epatAtomF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatAtomF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2epatAtomF_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2epatAtomF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatAtomF_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2epatAtomF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatAtomF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatAtomF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatAtomF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2epatAtomF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatAtomF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_t_2412 = heff_intAdd(heff_dup(heff_rfield(v_s_2411, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2411, v_t_2412));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PAs, 3, (V[]){v_x_2425, v_x_2426, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 7, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam8, 1, 3, (V[]){v_k_242, v_x_2425, v_x_2426});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam7, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2425})));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PAtom, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam13(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2445 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2445;
  args[0] = heff_tag_n(TAG_PParen, 3, (V[]){v_x_2443, v_x_2446, v_x_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam12(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2444 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2epatAtomF_str17), v_hd_2444, heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam13, 1, 3, (V[]){v_k_2445, v_x_2443, v_x_2446})));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam11(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_get_n(v_g_240, 5, 17);
  args[0] = heff_dup(v_hd_2444);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam12, 1, 3, (V[]){v_hd_2444, v_k_2445, v_x_2443});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam11, 2, 2, (V[]){v_g_240, v_x_2443}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2416) == NTAG(TAG_True))) {
    heff_drop(v_x_2416);
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_x_2415, 9);
    heff_drop_rec(v_g_240, 17);
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str0), v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2416);
    V v_t_2424 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str1)) && (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str2)) && (heff_intEq_c(heff_dup(heff_rfield(v_x_245, 4)), heff_dup(heff_rfield(v_x_2410, 3))) && heff_intEq_c(heff_dup(heff_rfield(v_x_2410, 4)), heff_dup(heff_rfield(v_x_2415, 3)))))));
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_x_2415, 9);
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_t_2424);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam6, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
    } else {
      heff_drop(v_t_2424);
      V v_t_2428 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_245, 0))}));
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str3), NTAG(TAG_Nil)});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str5), v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str7), v_t_2430})});
      V v_t_2432 = ({ V a_0 = v_t_2428; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str8), v_t_2431}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_245, 9);
        heff_drop_rec(v_g_240, 17);
        heff_drop(v_t_2432);
        return (g_heff_2esyntax_2ecst_2enext(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam9, 1, 1, (V[]){v_k_242})));
      } else {
        heff_drop(v_t_2432);
        V v_t_2435 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str9)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str10))));
        if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
          heff_drop_rec(v_x_245, 9);
          heff_drop(v_t_2435);
          return (g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(heff_get_n(v_g_240, 5, 17), v_hd_241, v_k_242));
        } else {
          heff_drop(v_t_2435);
          V v_t_2437 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str11)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str12))));
          if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
            heff_drop_rec(v_x_245, 9);
            heff_drop(v_t_2437);
            V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2epatSegmentF_clo), 1, (V[]){v_g_240}));
            return (g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(v_t_2438, v_hd_241, v_k_242));
          } else {
            heff_drop(v_t_2437);
            V v_t_2440 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str13)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str14))));
            if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
              heff_drop_rec(v_x_245, 9);
              heff_drop(v_t_2440);
              return (g_heff_2esyntax_2ecst_2erecordPatF(v_g_240, v_hd_241, v_k_242));
            } else {
              heff_drop(v_t_2440);
              V v_t_2442 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str15)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str16))));
              if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
                heff_drop_rec(v_x_245, 9);
                heff_drop(v_t_2442);
                return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam10, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
              } else {
                heff_drop_rec(v_g_240, 17);
                heff_drop(v_t_2442);
                if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str18))) {
                  V v_t_2449 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
                  V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str19), v_t_2449, NTAG(TAG_Nothing)});
                  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2450})});
                  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2451}));
                  V f_ = heff_get_n(v_hd_241, 1, 3);
                  heff_room[0] = v_t_2452;
                  heff_room[1] = v_k_242;
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  V v_t_2455;
                  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str20))) {
                    v_t_2455 = ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str21);
                  } else {
                    V v_t_2454 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str22));
                    v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2epatAtomF_str23), v_t_2454);
                  }
                  V v_t_2456 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
                  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2epatAtomF_str24), v_t_2455), v_t_2456, NTAG(TAG_Nothing)});
                  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
                  V v_t_2459 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2458}));
                  V f_ = heff_get_n(v_hd_241, 1, 3);
                  heff_room[0] = v_t_2459;
                  heff_room[1] = v_k_242;
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam5, 1, 6, (V[]){v_x_245, v_hd_241, v_k_242, v_x_2410, v_x_2415, v_g_240})));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_lam3_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam4, 1, 5, (V[]){v_hd_241, v_x_245, v_k_242, v_x_2410, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam2, 1, 4, (V[]){v_hd_241, v_x_245, v_k_242, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321(V v_lit_240, V v_sep_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam0, 1, 6, (V[]){heff_dup(v_sep_241), v_hd_244, v_lit_240, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam4(V self, V *args) {
  V v_a_2413 = args[0];
  V v_a_2411 = heff_env(self)[0];
  V v_a_2412 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_sep_241 = heff_env(self)[4];
  V v_x_2410 = heff_env(self)[5];
  V v_seps_243 = heff_env(self)[6];
  V v_hd_244 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFSet, 3, (V[]){v_a_2411, v_a_2412, v_a_2413}), v_items_242});
  return ({ V a_0 = v_lit_240; V a_1 = v_sep_241; V a_2 = v_t_2414; V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}); V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_sep_241); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_sep_241 = heff_env(self)[4];
  V v_x_2410 = heff_env(self)[5];
  V v_seps_243 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam4, 1, 9, (V[]){v_a_2411, v_a_2412, v_items_242, v_lit_240, v_sep_241, v_x_2410, v_seps_243, v_hd_244, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam2(V self, V *args) {
  V v_a_2411 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_sep_241 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_seps_243 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eexpectSym(heff_dup(v_lit_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam3, 1, 8, (V[]){v_hd_244, v_a_2411, v_items_242, v_lit_240, v_sep_241, v_x_2410, v_seps_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_sep_241 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam2, 1, 7, (V[]){v_lit_240, v_hd_244, v_items_242, v_sep_241, v_x_2410, v_seps_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_241))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s104385016x1401312321_lam1, 1, 6, (V[]){v_hd_244, v_lit_240, v_items_242, v_sep_241, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_lit_240);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243));
    V v_x_2417 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2415, v_t_2416});
    V f_ = v_k_245;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str2, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str3, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str4, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str5, 4, "case");
V g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_entry, 2, 0};

V g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str0))) {
    heff_drop_rec(v_x_244, 9);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, v_k_241));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str1))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_244, 1, 9)}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str2), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str4), v_t_248})});
      V v_t_2410 = ({ V a_0 = v_t_247; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_str5), v_t_249}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, v_k_241));
      } else {
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628(MK_INT(1LL), heff_dup(v_hd_240), v_k_241, v_hd_240));
      }
    } else {
      heff_drop_rec(v_x_244, 9);
      return (g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628(MK_INT(1LL), heff_dup(v_hd_240), v_k_241, v_hd_240));
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str2, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str4, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str6, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str8, 1, "~");
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(V v_minPrec_240, V v_lhs_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam0, 1, 4, (V[]){v_hd_242, v_minPrec_240, v_k_243, v_lhs_241})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam3(V self, V *args) {
  V v_st_2425 = args[0];
  V v_k_2426 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_x_246, 1, 9); V b_1 = ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str7); V a_2 = MK_INT(1LL); V b_3 = ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str8); V a_4 = MK_INT(2LL); V a_5 = MK_INT(-1LL); V a_6 = heff_dup(v_st_2425); V a_7 = v_k_2426; V a_8 = v_st_2425; V r_ = (g_heff_2esyntax_2ecst_2eappF_24s1665400558x5238564(b_0, b_1, a_2, b_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_3); r_; });
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_minPrec_240 = heff_env(self)[0];
  V v_lhs_241 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_minPrec_240, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_241, v_x_2419, v_x_2428}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_minPrec_240 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_s_2420 = heff_dup(heff_rfield(v_x_246, 1));
  int64_t v_t_2423;
  if (heff_strEq_c_lent(v_s_2420, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str5), 2)) {
    heff_drop(v_s_2420);
    v_t_2423 = ((int64_t)1ULL);
  } else {
    if (heff_strEq_c(v_s_2420, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str6))) {
      v_t_2423 = ((int64_t)2ULL);
    } else {
      v_t_2423 = ((int64_t)-1ULL);
    }
  }
  V v_c_2427;
  if ((v_t_2423 == ((int64_t)1ULL))) {
    heff_drop_rec(v_x_246, 9);
    v_c_2427 = ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s274869865x957113804_clo);
  } else {
    v_c_2427 = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam3, 2, 1, (V[]){v_x_246});
  }
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam4, 1, 5, (V[]){v_minPrec_240, v_lhs_241, v_x_2419, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str0))) {
    V v_s_249 = heff_dup(heff_rfield(v_x_246, 1));
    int64_t v_t_2412;
    if (heff_strEq_c_lent(v_s_249, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str1), 2)) {
      heff_drop(v_s_249);
      v_t_2412 = ((int64_t)1ULL);
    } else {
      if (heff_strEq_c(v_s_249, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str2))) {
        v_t_2412 = ((int64_t)2ULL);
      } else {
        v_t_2412 = ((int64_t)-1ULL);
      }
    }
    if ((((int64_t)1ULL) <= v_t_2412)) {
      V v_s_2414 = heff_dup(heff_rfield(v_x_246, 1));
      V v_t_2417;
      if (heff_strEq_c_lent(v_s_2414, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str3), 2)) {
        heff_drop(v_s_2414);
        v_t_2417 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2414, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_str4))) {
          v_t_2417 = MK_INT(2LL);
        } else {
          v_t_2417 = MK_INT(-1LL);
        }
      }
      if (heff_intLe_c_lent(v_minPrec_240, v_t_2417, 2)) {
        if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
          heff_drop(v_x_247);
          heff_drop_rec(v_x_246, 9);
          heff_drop(v_minPrec_240);
          heff_drop_rec(v_hd_242, 3);
          V f_ = v_k_243;
          args[0] = v_lhs_241;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_x_247);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam2, 1, 5, (V[]){v_x_246, v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})));
        }
      } else {
        heff_drop(v_x_247);
        heff_drop_rec(v_x_246, 9);
        heff_drop(v_minPrec_240);
        heff_drop_rec(v_hd_242, 3);
        V f_ = v_k_243;
        args[0] = v_lhs_241;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      heff_drop(v_x_247);
      heff_drop_rec(v_x_246, 9);
      heff_drop(v_minPrec_240);
      heff_drop_rec(v_hd_242, 3);
      V f_ = v_k_243;
      args[0] = v_lhs_241;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_minPrec_240);
    heff_drop_rec(v_hd_242, 3);
    V f_ = v_k_243;
    args[0] = v_lhs_241;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_lam1, 1, 5, (V[]){v_x_246, v_minPrec_240, v_k_243, v_lhs_241, v_hd_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str0, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str1, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str2, 1, "}");
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam6(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSep: {
    V v_items_2411 = heff_field(v_x_249, 0);
    V v_seps_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    v_t_2413 = heff_tag_n(TAG_Sum, 5, (V[]){v_x_242, v_x_243, v_items_2411, v_seps_2412, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_245;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam5(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str2), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam6, 1, 4, (V[]){v_x_249, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_x_246, v_x_247}), NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str1); V a_1 = v_t_248; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_244); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam5, 1, 4, (V[]){v_hd_244, v_x_242, v_x_243, v_k_245}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam4, 1, 5, (V[]){v_x_246, v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam2(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam3, 1, 4, (V[]){v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam2, 2, 2, (V[]){v_x_242, v_x_243}), v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str0), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam1, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str2, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str3, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str4, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str5, 4, "case");
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry, 2, 0};

V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str0))) {
    heff_drop_rec(v_x_244, 9);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, v_k_241));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str1))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_244, 1, 9)}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str2), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str4), v_t_248})});
      V v_t_2410 = ({ V a_0 = v_t_247; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str5), v_t_249}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, v_k_241));
      } else {
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(MK_INT(1LL), heff_dup(v_hd_240), v_k_241, v_hd_240));
      }
    } else {
      heff_drop_rec(v_x_244, 9);
      return (g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(MK_INT(1LL), heff_dup(v_hd_240), v_k_241, v_hd_240));
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_242, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam4, 1, 3, (V[]){v_k_241, v_x_242, v_x_249})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_242, v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam6, 1, 3, (V[]){v_k_241, v_x_242, v_x_2412})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_str1))) {
      heff_drop_rec(v_x_245, 9);
      if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
        heff_drop(v_x_246);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_242;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_246);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_str2))) {
        if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
          heff_drop(v_x_246);
          heff_drop_rec(v_hd_240, 3);
          V f_ = v_k_241;
          args[0] = v_x_242;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_x_246);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam5, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
        }
      } else {
        heff_drop(v_x_246);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_242;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  } else {
    heff_drop(v_x_246);
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam2, 1, 4, (V[]){v_x_245, v_k_241, v_x_242, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_str2, 51, "an update sets a field by its name: `{ r | x = v }`");
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EUSet, 3, (V[]){v_x_247, v_x_248, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam4, 1, 3, (V[]){v_k_241, v_x_247, v_x_248})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_247})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_Atom, 1, (V[]){v_x_246}), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_str0))) {
    heff_drop_rec(v_x_244, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
  } else {
    V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_str2), v_t_2410, NTAG(TAG_Nothing)});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2412}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2413;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str0, 17, "no parameter here");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str2, 10, " :: Type)`");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str3, 55, "a type's parameter is lower case, or given its type: `(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str6, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str7, 17, "no parameter here");
V g_heff_2esyntax_2ecst_2edataParam_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edataParam_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edataParam_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edataParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataParam_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edataParam(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2edataParam_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2edataParam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edataParam(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edataParam_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataParam_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2edataParam_str0), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_248}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_249;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_245);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str1))) {
      V v_t_2411 = heff_strAppend(heff_take_field(v_x_244, 1), ((V)&g_heff_2esyntax_2ecst_2edataParam_str2));
      V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2edataParam_str3), v_t_2411), v_t_2412, NTAG(TAG_Nothing)});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2414}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2415;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str4))) {
        heff_drop_rec(v_x_244, 9);
        return (g_heff_2esyntax_2ecst_2enext(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edataParam_lam2, 1, 1, (V[]){v_k_241})));
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str5))) {
          heff_drop_rec(v_x_244, 9);
          return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(v_hd_240, v_k_241));
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str6))) {
            heff_drop_rec(v_x_244, 9);
            return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(v_hd_240, v_k_241));
          } else {
            V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
            V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2edataParam_str7), v_t_2420, NTAG(TAG_Nothing)});
            V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
            V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2422}));
            V f_ = heff_get_n(v_hd_240, 1, 3);
            heff_room[0] = v_t_2423;
            heff_room[1] = v_k_241;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edataParam_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataParam_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyParams_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyParams_str1, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyParams_str2, 1, "(");
V g_heff_2esyntax_2ecst_2emanyParams_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyParams_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyParams_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyParams_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyParams_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emanyParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emanyParams_entry, 3, 0};

V g_heff_2esyntax_2ecst_2emanyParams(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam0, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emanyParams(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2emanyParams_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2emanyParams_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2emanyParams_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2emanyParams_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_243) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_x_243);
    heff_drop_rec(v_hd_241, 3);
    V v_x_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_243);
    V v_t_248 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_246)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_246, 9);
      heff_drop(v_t_248);
      return (g_heff_2esyntax_2ecst_2edataParam(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam2, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
    } else {
      heff_drop(v_t_248);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyParams_str0))) {
        heff_drop_rec(v_x_246, 9);
        return (g_heff_2esyntax_2ecst_2edataParam(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam3, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyParams_str1))) {
          if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2emanyParams_str2))) {
            return (g_heff_2esyntax_2ecst_2edataParam(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam4, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
          } else {
            heff_drop_rec(v_hd_241, 3);
            V v_x_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
            V f_ = v_k_242;
            args[0] = v_x_2415;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        } else {
          heff_drop_rec(v_x_246, 9);
          heff_drop_rec(v_hd_241, 3);
          V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
          V f_ = v_k_242;
          args[0] = v_x_2416;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2emanyParams_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam1, 1, 4, (V[]){v_x_243, v_acc_240, v_k_242, v_hd_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str1, 18, "the name of a type");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str4, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str5, 1, "|");
V g_heff_2esyntax_2ecst_2edataDecl_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam4, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam7, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam8(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam8, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam11(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam11, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam15(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam15, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edataDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edataDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_2446 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_2446, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2edataDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edataDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_x_2414})});
  V f_ = v_k_2412;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eappF_24s703112455x1201014747(v_hd_2411, heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam6, 1, 2, (V[]){v_x_2413, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam4(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2411), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam5, 1, 2, (V[]){v_hd_2411, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam7(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam8(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam14(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_MkSep: {
    V v_items_2432 = heff_field(v_x_2431, 0);
    V v_seps_2433 = heff_field(v_x_2431, 1);
    heff_take_n(v_x_2431, 3ULL, 2);
    v_t_2434 = heff_tag_n(TAG_MkDAlts, 3, (V[]){v_x_2428, v_items_2432, v_seps_2433});
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam13(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_str5); V a_1 = v_t_2430; V a_2 = NTAG(TAG_Nil); V a_3 = v_hd_2426; V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam14, 1, 2, (V[]){v_x_2428, v_k_2427}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2edataDecl_lam12(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2edataAlternative(heff_dup(v_hd_2426), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam13, 1, 3, (V[]){v_hd_2426, v_x_2428, v_k_2427})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam11(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2426), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam12, 1, 2, (V[]){v_hd_2426, v_k_2427})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam15(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam17(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_x_2438 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2445);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DData, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_2421, v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam16(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Nothing: {
    v_t_2443 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_2439 = heff_dup(heff_field(v_x_2438, 0));
    switch (heff_tag_of(v_x11_2439)) {
    case TAG_MkDAlts: {
      V v_alts_2441 = heff_field(v_x11_2439, 1);
      heff_take_n(v_x11_2439, 2ULL, 3);
      v_t_2443 = v_alts_2441;
      break;
    }
    default: heff_nomatch(v_x11_2439);
    }
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V v_c_2444 = ({ V a_0 = heff_rfield(v_x_244, 1); V a_1 = v_t_2443; V r_ = (g_heff_2esyntax_2ecst_2echeckAltNames(a_0, a_1)); heff_drop(v_t_2443); r_; });
  V f_ = v_c_2444;
  heff_room[0] = v_hd_240;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam17, 1, 6, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_2421, v_x_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam10(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437;
  if (heff_strEq_c(heff_get_n(v_x_2424, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edataDecl_str4))) {
    v_t_2437 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam11_clo);
  } else {
    v_t_2437 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam15_clo);
  }
  V f_ = v_t_2437;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam16, 1, 6, (V[]){v_x_244, v_hd_240, v_k_241, v_x_243, v_x_245, v_x_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2422}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam10, 1, 6, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243, v_x_245, v_x_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 1)), ((V)&g_heff_2esyntax_2ecst_2edataDecl_str2))) {
    if (heff_strEq_c(heff_get_n(v_x_248, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edataDecl_str3))) {
      v_t_2420 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam4_clo);
    } else {
      v_t_2420 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam7_clo);
    }
  } else {
    heff_drop_rec(v_x_248, 9);
    v_t_2420 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam8_clo);
  }
  V f_ = v_t_2420;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam9, 1, 5, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam3, 1, 5, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam2, 1, 4, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_str0); V a_1 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_str1); V a_2 = heff_dup(v_hd_240); V a_3 = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243}); V r_ = (g_heff_2esyntax_2ecst_2eexpectKind(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_244, 1)); V rr_ = heff_rec_reuse_nf(v_s_244, 15ULL, 5, shape_toks__i__top__stack__start, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2414, heff_dup(v_col_240)));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    return (g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(v_col_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241}), v_hd_242, v_k_243));
  } else {
    heff_drop(v_col_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_t_2415);
    V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam4, 1, 5, (V[]){v_col_240, v_x_2411, v_acc_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  return (g_heff_2esyntax_2ecst_2etheoryField(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efixityRest_str0, 3, "eof");
V g_heff_2esyntax_2ecst_2efixityRest_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efixityRest_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2efixityRest_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efixityRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efixityRest_entry, 3, 0};

V g_heff_2esyntax_2ecst_2efixityRest(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2efixityRest_lam0, 1, 3, (V[]){v_acc_240, v_k_242, v_hd_241})});
}
V g_heff_2esyntax_2ecst_2efixityRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efixityRest(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2efixityRest_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efixityRest(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efixityRest_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efixityRest(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efixityRest_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2efixityRest_str0))) {
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_241, 3);
    V v_x_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_248 = heff_take_field(v_x_245, 6);
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      if (heff_intEq_c(heff_get_n(v_x_245, 5, 9), MK_INT(0LL))) {
        heff_drop_rec(v_hd_241, 3);
        V v_x_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
        V f_ = v_k_242;
        args[0] = v_x_2410;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efixityRest_lam1, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
      }
    } else {
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_t_248);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efixityRest_lam2, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
    }
  }
}