// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_FtOther 63706
#define TAG_Kept 49931
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_MkRes 5766
#define TAG_MkResVals 58586
#define TAG_NoShape 40346
#define TAG_OfRecords 55355
#define TAG_OfTags 60669
#define TAG_Perform 19235
#define TAG_Right 62770
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_b 316
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_byFun 295539138
#define LBL_byKey 295543458
#define LBL_byMember 2056687451
#define LBL_callers 780494982
#define LBL_callersOf 583887482
#define LBL_calls 295783919
#define LBL_cells 295903083
#define LBL_changed 970801394
#define LBL_consts 592362651
#define LBL_consumers 1203455020
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_defs 9574869
#define LBL_dirty 296951788
#define LBL_done 9584713
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_fix 310927
#define LBL_flat 9641024
#define LBL_found 298980252
#define LBL_fresh 299054408
#define LBL_gathered 1327153563
#define LBL_globals 352931696
#define LBL_group 299987609
#define LBL_grown 299987669
#define LBL_index 301704428
#define LBL_ints 9732907
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_left 9813198
#define LBL_lent 9813446
#define LBL_made 9839068
#define LBL_marking 1071112247
#define LBL_marks 305024864
#define LBL_members 1180739419
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_outer 307469461
#define LBL_owner 307523277
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_pieces 958716528
#define LBL_producers 572620898
#define LBL_refs 9991943
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_supply 1056026650
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tables 1065764240
#define LBL_tag 324116
#define LBL_tokens 1078955205
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_tuples 1084651734
#define LBL_type_5f 312202367
#define LBL_units 312791945
#define LBL_ver 326173
#define LBL_words 314676931
#define LBL_workers 1757018875
#define LBL_xs 10594
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words, LBL_tokens};
static uint32_t shape_byFun__cells[] = {LBL_byFun, LBL_cells};
static uint32_t shape_byKey__callers__callersOf__ints[] = {LBL_byKey, LBL_callers, LBL_callersOf, LBL_ints};
static uint32_t shape_byMember__supply[] = {LBL_byMember, LBL_supply};
static uint32_t shape_defs__facts__errors[] = {LBL_defs, LBL_facts, LBL_errors};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_defs__supply__tokens[] = {LBL_defs, LBL_supply, LBL_tokens};
static uint32_t shape_defs__supply__tuples[] = {LBL_defs, LBL_supply, LBL_tuples};
static uint32_t shape_defs__words[] = {LBL_defs, LBL_words};
static uint32_t shape_done__name__refs__sgSafe__sgTotal[] = {LBL_done, LBL_name, LBL_refs, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_owner__key__name__item__refs[] = {LBL_owner, LBL_key, LBL_name, LBL_item, LBL_refs};
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_params__gathered__changed[] = {LBL_params, LBL_gathered, LBL_changed};
static uint32_t shape_params__grown__marks[] = {LBL_params, LBL_grown, LBL_marks};
static uint32_t shape_pieces__errors__supply[] = {LBL_pieces, LBL_errors, LBL_supply};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_xs__b[] = {LBL_xs, LBL_b};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2ecallarity_2erounds(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2erounds_clo;
V g_heff_2ecompile_2ecallarity_2esatGo(V, V);
V g_heff_2ecompile_2ecallarity_2esatGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esatGo_clo;
V g_heff_2ecompile_2ecpr_2edefWith(V, V, V);
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edefWith_clo;
V g_heff_2ecompile_2ecpr_2edropCalling(V);
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edropCalling_clo;
V g_heff_2ecompile_2ecpr_2ekeptGo(V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo;
V g_heff_2ecompile_2ecpr_2esitesW(V, V, V);
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esitesW_clo;
V g_heff_2ecompile_2ecycles_2estartWalk_get(void);
V g_heff_2ecompile_2ecycles_2estrong(V, V, V);
V g_heff_2ecompile_2ecycles_2estrong_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2estrong_clo;
V g_heff_2ecompile_2eerase_2edefinition(V, V, V, V);
V g_heff_2ecompile_2eerase_2edefinition_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2edefinition_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2efacts_2efactsOf(V);
V g_heff_2ecompile_2efacts_2efactsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2efactsOf_clo;
V g_heff_2ecompile_2efuse_2esites(V, V);
V g_heff_2ecompile_2efuse_2esites_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esites_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
V g_heff_2ecompile_2elift_2eordered(V, V);
V g_heff_2ecompile_2elift_2eordered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eordered_clo;
V g_heff_2ecompile_2elower_2ecFacts(V, V);
V g_heff_2ecompile_2elower_2ecFacts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecFacts_clo;
V g_heff_2ecompile_2elower_2eentryBody(V, V);
V g_heff_2ecompile_2elower_2eentryBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryBody_clo;
V g_heff_2ecompile_2elower_2eentryKept(V, V);
V g_heff_2ecompile_2elower_2eentryKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryKept_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2eerasedPieces(V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_clo;
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2(V, V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_24tok2_clo;
V g_heff_2ecompile_2elower_2efindDef(V, V);
V g_heff_2ecompile_2elower_2efindDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efindDef_clo;
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337(V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_clo;
V g_heff_2ecompile_2elower_2egroupGo(V);
V g_heff_2ecompile_2elower_2egroupGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupGo_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_clo;
V g_heff_2ecompile_2elower_2ereachedPieces(V);
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ereachedPieces_clo;
V g_heff_2ecompile_2elower_2eredoErased(V, V, V, V);
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eredoErased_clo;
V g_heff_2ecompile_2elower_2erevOnto(V, V);
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_clo;
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V, V, V);
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo;
HeffT3 g_heff_2ecompile_2elower_2eshared_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2eunitOut(V, V, V);
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitOut_clo;
HeffT2 g_heff_2ecompile_2elower_2eunitOut_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2eunitVers(V, V);
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitVers_clo;
V g_heff_2ecompile_2eonce_2einlined(V, V, V);
V g_heff_2ecompile_2eonce_2einlined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2einlined_clo;
V g_heff_2ecompile_2eonce_2eusesW(V, V, V);
V g_heff_2ecompile_2eonce_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2eusesW_clo;
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void);
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
V g_heff_2ecompile_2eranges_2emattering(V, V, V);
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emattering_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2enarrowing(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowing_clo;
V g_heff_2ecompile_2eranges_2eroundOf(V, V, V, V);
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eroundOf_clo;
HeffT2 g_heff_2ecompile_2eranges_2erounds_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2escanW(V, V, V);
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanW_clo;
V g_heff_2ecompile_2eranges_2ewalkGo(V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkGo_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2etokens_2ebuildsW(V, V);
V g_heff_2ecompile_2etokens_2ebuildsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ebuildsW_clo;
HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(V, V);
V g_heff_2ecompile_2etokens_2esitesW(V, V);
V g_heff_2ecompile_2etokens_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2esitesW_clo;
V g_heff_2ecompile_2eworker_2eworkers(V, V);
V g_heff_2ecompile_2eworker_2eworkers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eworkers_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s44244667x1445755514(V, V);
V g_list_2eall_24s44244667x1445755514_entry(V self, V *a);
extern Clo g_list_2eall_24s44244667x1445755514_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s277053946x716662586(V, V);
V g_list_2eany_24s277053946x716662586_entry(V self, V *a);
extern Clo g_list_2eany_24s277053946x716662586_clo;
HeffT2 g_list_2efind_24s775449825x1158002128_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1007625675x912768453(V, V, V);
V g_list_2efoldl_24s1007625675x912768453_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1007625675x912768453_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1068175575x1869083571(V, V);
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1068175575x1869083571_clo;
V g_list_2efoldl_24s1078918265x314186258(V, V);
V g_list_2efoldl_24s1078918265x314186258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1078918265x314186258_clo;
V g_list_2efoldl_24s1165300915x1297435540(V, V);
V g_list_2efoldl_24s1165300915x1297435540_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1165300915x1297435540_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1499934538x170225690(V, V);
V g_list_2efoldl_24s1499934538x170225690_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1499934538x170225690_clo;
V g_list_2efoldl_24s1530765264x1072548396(V, V);
V g_list_2efoldl_24s1530765264x1072548396_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530765264x1072548396_clo;
V g_list_2efoldl_24s1579438642x567671990(V, V, V, V, V);
V g_list_2efoldl_24s1579438642x567671990_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1579438642x567671990_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1738438673x24732785(V, V);
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1738438673x24732785_clo;
V g_list_2efoldl_24s1766906699x9526323(V, V);
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1766906699x9526323_clo;
V g_list_2efoldl_24s1769360958x1839054239(V, V);
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1769360958x1839054239_clo;
V g_list_2efoldl_24s1810610888x1691479932(V, V);
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810610888x1691479932_clo;
V g_list_2efoldl_24s1977498258x1405492921(V, V, V, V);
V g_list_2efoldl_24s1977498258x1405492921_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1977498258x1405492921_clo;
V g_list_2efoldl_24s2004150897x784001505(V, V);
V g_list_2efoldl_24s2004150897x784001505_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2004150897x784001505_clo;
V g_list_2efoldl_24s2023159590x14712440(V, V);
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2023159590x14712440_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s2098410461x866205771(V, V, V);
V g_list_2efoldl_24s2098410461x866205771_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2098410461x866205771_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s243940296x1179168444(V, V);
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243940296x1179168444_clo;
V g_list_2efoldl_24s26403090x581733227(V, V, V, V);
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a);
extern Clo g_list_2efoldl_24s26403090x581733227_clo;
V g_list_2efoldl_24s271650647x1598714891(V, V);
V g_list_2efoldl_24s271650647x1598714891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s271650647x1598714891_clo;
V g_list_2efoldl_24s291344770x1790586136(V, V);
V g_list_2efoldl_24s291344770x1790586136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s291344770x1790586136_clo;
V g_list_2efoldl_24s322049767x2109647543(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s322049767x2109647543_entry(V self, V *a);
extern Clo g_list_2efoldl_24s322049767x2109647543_clo;
V g_list_2efoldl_24s327126808x177501924(V, V);
V g_list_2efoldl_24s327126808x177501924_entry(V self, V *a);
extern Clo g_list_2efoldl_24s327126808x177501924_clo;
V g_list_2efoldl_24s330602584x1277356584(V, V, V);
V g_list_2efoldl_24s330602584x1277356584_entry(V self, V *a);
extern Clo g_list_2efoldl_24s330602584x1277356584_clo;
V g_list_2efoldl_24s42602063x979600769(V, V);
V g_list_2efoldl_24s42602063x979600769_entry(V self, V *a);
extern Clo g_list_2efoldl_24s42602063x979600769_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s532743697x1094589833(V, V);
V g_list_2efoldl_24s532743697x1094589833_entry(V self, V *a);
extern Clo g_list_2efoldl_24s532743697x1094589833_clo;
V g_list_2efoldl_24s53729099x990735293(V, V);
V g_list_2efoldl_24s53729099x990735293_entry(V self, V *a);
extern Clo g_list_2efoldl_24s53729099x990735293_clo;
V g_list_2efoldl_24s591996130x301722846(V, V);
V g_list_2efoldl_24s591996130x301722846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591996130x301722846_clo;
V g_list_2efoldl_24s630841978x1026694071(V, V);
V g_list_2efoldl_24s630841978x1026694071_entry(V self, V *a);
extern Clo g_list_2efoldl_24s630841978x1026694071_clo;
V g_list_2efoldl_24s637780307x9274583(V, V);
V g_list_2efoldl_24s637780307x9274583_entry(V self, V *a);
extern Clo g_list_2efoldl_24s637780307x9274583_clo;
V g_list_2efoldl_24s88009013x1334911863(V, V);
V g_list_2efoldl_24s88009013x1334911863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s88009013x1334911863_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1223034477x943356724(V);
V g_list_2ekeepIf_24s1223034477x943356724_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_clo;
V g_list_2ekeepIf_24s1606737509x658906972(V);
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_clo;
V g_list_2ekeepIf_24s1911725233x106069160(V, V, V, V);
V g_list_2ekeepIf_24s1911725233x106069160_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1911725233x106069160_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1460603830x671758883(V, V);
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_clo;
V g_list_2emap_24s1460603830x671758883_24tok1(V, V, V);
V g_list_2emap_24s1460603830x671758883_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24tok1_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1915587473x866090925(V, V);
V g_list_2emap_24s1915587473x866090925_entry(V self, V *a);
extern Clo g_list_2emap_24s1915587473x866090925_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1985010810x1780722131(V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_clo;
V g_list_2emap_24s273193875x235978955(V, V, V, V);
V g_list_2emap_24s273193875x235978955_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_list_2emap_24s510639937x1058700299(V);
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1111575179x1680558317(V);
V g_prelude_2etraverse_24s1111575179x1680558317_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1111575179x1680558317_clo;
V g_prelude_2etraverse_24s1442653311x1678194035(V);
V g_prelude_2etraverse_24s1442653311x1678194035_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1442653311x1678194035_clo;
V g_prelude_2etraverse_24s1617808025x638052145(V);
V g_prelude_2etraverse_24s1617808025x638052145_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1617808025x638052145_clo;
V g_prelude_2etraverse_24s1882351740x242225671(V);
V g_prelude_2etraverse_24s1882351740x242225671_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1882351740x242225671_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
V g_prelude_2etraverse_24s248425057x1995322387(V);
V g_prelude_2etraverse_24s248425057x1995322387_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s248425057x1995322387_clo;
V g_prelude_2etraverse_24s322261189x1827875354(V);
V g_prelude_2etraverse_24s322261189x1827875354_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s322261189x1827875354_clo;
V g_prelude_2etraverse_24s379292819x1163591097(V);
V g_prelude_2etraverse_24s379292819x1163591097_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s379292819x1163591097_clo;
V g_prelude_2etraverse_24s545943161x1483966866(V, V);
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s545943161x1483966866_clo;
V g_prelude_2etraverse_24s812820150x374715993(V);
V g_prelude_2etraverse_24s812820150x374715993_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s812820150x374715993_clo;
V g_prelude_2etraverse_24s993801089x502291790(V);
V g_prelude_2etraverse_24s993801089x502291790_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s993801089x502291790_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2emapValues_24s383523993x1452310955(V);
V g_std_2eordmap_2emapValues_24s383523993x1452310955_entry(V self, V *a);
extern Clo g_std_2eordmap_2emapValues_24s383523993x1452310955_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_24cpr_str0, 6, "Enter$");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_24cpr_str3, 6, "Enter$");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_24cpr_str4, 4, "$cpr");
V g_heff_2ecompile_2elower_2eshared_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam5(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam6(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam4(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam7(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam8(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam9(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam10(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_24cpr_lam11(V self, V *args);

HeffT3 g_heff_2ecompile_2elower_2eshared_24cpr(V v_roots_240, V v_supply_241, V v_kept_242) {
top: ;
  V v_roots_243 = v_roots_240;
  V v_t_244 = heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){heff_dup(g_std_2eordmap_2eempty_get())}), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_c_245 = heff_tr(g_heff_2ecompile_2ecallarity_2erounds(MK_INT(3LL), v_t_244, v_kept_242, v_supply_241));
  V v_ar_246 = (g_list_2efoldl_24s445268946x679229867(heff_dup(g_std_2eordmap_2eempty_get()), heff_rfield(v_c_245, 0)));
  V v_c_247 = v_c_245;
  V v_supply_248 = heff_take_field(v_c_247, 1);
  V v_defs_249 = heff_get_n(v_c_247, 0, 2);
  V v_supply_2410 = v_supply_248;
  V v_defs_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam0, 1, 1, (V[]){v_ar_246}), v_defs_249));
  V v_t_2414 = (g_prelude_2etraverse_24s1882351740x242225671(v_defs_2413));
  V v_t_2415 = heff_tr(heff_call(v_t_2414, 1, (V[]){v_supply_2410}));
  V v_t_2420;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_MkPair: {
    V v_dss_2416 = heff_field(v_t_2415, 0);
    V v_n_2417 = heff_field(v_t_2415, 1);
    heff_take_n(v_t_2415, 3ULL, 2);
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_2416));
    V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2418); r_; });
    v_t_2420 = heff_rec_n(2, shape_defs__supply, (V[]){v_t_2419, v_n_2417});
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_supply_2421 = heff_take_field(v_t_2420, 1);
  V v_defs_2422 = heff_get_n(v_t_2420, 0, 2);
  V v_n_2423 = v_supply_2421;
  V v_defs_2424 = v_defs_2422;
  V v_funs_2425 = (g_list_2efoldl_24s291344770x1790586136(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2424));
  V v_t_2426 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2424));
  V v_x1_2427 = (g_list_2efoldl_24s1007625675x912768453(MK_INT(1LL), heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get())}), heff_dup(v_defs_2424)));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_field(v_x1_2427, 1);
    heff_take_n(v_x1_2427, 2ULL, 2);
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_x1_2427);
  }
  V v_funs_2431 = v_funs_2425;
  V v_defs_2432 = heff_dup(v_defs_2424);
  V v_calls_2491 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam1, 2, 1, (V[]){v_funs_2431}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_2432; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_2432); r_; });
  V v_defs_2492 = heff_dup(v_defs_2424);
  V v_w_24103 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam3, 2, 1, (V[]){v_calls_2491}); V a_1 = heff_dup(g_heff_2ecompile_2ecycles_2estartWalk_get()); V a_2 = v_defs_2492; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_2492); r_; });
  V v_t_24104 = (g_list_2ekeepIf_24s1911725233x106069160(MK_INT(1LL), MK_INT(0LL), MK_INT(2LL), heff_get_n(v_w_24103, 5, 6)));
  V v_cs_24105 = ({ V a_0 = v_t_2426; V a_1 = v_t_2430; V a_2 = heff_rec_n(2, shape_byMember__supply, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_n_2423)}); V a_3 = v_t_24104; V r_ = (g_list_2efoldl_24s1977498258x1405492921(a_0, a_1, a_2, a_3)); heff_drop(v_t_24104); r_; });
  V v_t_24106 = (g_std_2eordmap_2esize(heff_rfield(v_cs_24105, 0)));
  V v_x1_24162;
  if (heff_intEq_c(v_t_24106, MK_INT(0LL))) {
    heff_drop_rec(v_cs_24105, 2);
    v_x1_24162 = heff_tag_n(TAG_MkPair, 2, (V[]){v_defs_2424, v_n_2423});
  } else {
    heff_drop(v_n_2423);
    V v_defs_24107 = v_defs_2424;
    V v_cs_24108 = v_cs_24105;
    V v_byMember_24109 = heff_take_field(v_cs_24108, 0);
    V v_supply_24110 = heff_get_n(v_cs_24108, 1, 2);
    V v_xs_24160 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam4, 2, 1, (V[]){v_byMember_24109}); V a_1 = NTAG(TAG_Nil); V a_2 = v_defs_24107; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_24107); r_; });
    V v_t_24161 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24160));
    v_x1_24162 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24161, v_supply_24110});
  }
  V v_t_24165;
  switch (heff_tag_of(v_x1_24162)) {
  case TAG_MkPair: {
    V v_defs_24163 = heff_field(v_x1_24162, 0);
    V v_n_24164 = heff_field(v_x1_24162, 1);
    heff_take_n(v_x1_24162, 3ULL, 2);
    v_t_24165 = heff_rec_n(2, shape_defs__supply, (V[]){v_defs_24163, v_n_24164});
    break;
  }
  default: heff_nomatch(v_x1_24162);
  }
  V v_supply_24166 = heff_take_field(v_t_24165, 1);
  V v_defs_24167 = heff_get_n(v_t_24165, 0, 2);
  V v_supply_24168 = v_supply_24166;
  V v_t_24169 = (g_prelude_2etraverse_24s1442653311x1678194035(v_defs_24167));
  V v_x2_24170 = heff_tr(heff_call(v_t_24169, 1, (V[]){v_supply_24168}));
  V v_t_24179;
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_MkPair: {
    V v_fs_24171 = heff_field(v_x2_24170, 0);
    V v_n_24172 = heff_field(v_x2_24170, 1);
    heff_take_n(v_x2_24170, 3ULL, 2);
    V v_t_24173 = (g_prelude_2etraverse_24s379292819x1163591097(v_fs_24171));
    V v_x3_24174 = heff_tr(heff_call(v_t_24173, 1, (V[]){v_n_24172}));
    switch (heff_tag_of(v_x3_24174)) {
    case TAG_MkPair: {
      V v_dss_24175 = heff_field(v_x3_24174, 0);
      V v_n_24176 = heff_field(v_x3_24174, 1);
      heff_take_n(v_x3_24174, 3ULL, 2);
      V v_t_24177 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_24175));
      V v_ds_24178 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24177; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24177); r_; });
      v_t_24179 = heff_rec_n(2, shape_defs__supply, (V[]){v_ds_24178, v_n_24176});
      break;
    }
    default: heff_nomatch(v_x3_24174);
    }
    break;
  }
  default: heff_nomatch(v_x2_24170);
  }
  V v_supply_24180 = heff_take_field(v_t_24179, 1);
  V v_defs_24181 = heff_get_n(v_t_24179, 0, 2);
  V v_supply_24182 = v_supply_24180;
  V v_t_24183 = (g_prelude_2etraverse_24s322261189x1827875354(v_defs_24181));
  V v_x2_24184 = heff_tr(heff_call(v_t_24183, 1, (V[]){v_supply_24182}));
  V v_x1_24198;
  switch (heff_tag_of(v_x2_24184)) {
  case TAG_MkPair: {
    V v_fs_24185 = heff_field(v_x2_24184, 0);
    V v_n_24186 = heff_field(v_x2_24184, 1);
    V v_ru_24x2_24184_24MkPair = heff_take_reuse_n(v_x2_24184, 3ULL, 2);
    V v_kind_24187 = NTAG(TAG_OfTags);
    V v_fs_24188 = heff_dup(v_fs_24185);
    V v_t_24189 = (g_prelude_2etraverse_24s993801089x502291790(v_fs_24185));
    V v_x3_24190 = heff_tr(heff_call(v_t_24189, 1, (V[]){v_n_24186}));
    switch (heff_tag_of(v_x3_24190)) {
    case TAG_MkPair: {
      V v_dss_24191 = heff_field(v_x3_24190, 0);
      V v_n_24192 = heff_field(v_x3_24190, 1);
      heff_take_n(v_x3_24190, 3ULL, 2);
      V v_t_24193 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_24191));
      V v_ds_24194 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24193; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24193); r_; });
      V v_t_24197;
      switch (heff_tag_of(v_kind_24187)) {
      case TAG_OfRecords: {
        heff_drop(v_fs_24188);
        v_t_24197 = v_ds_24194;
        break;
      }
      case TAG_OfTags: {
        V v_m_24195 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_fs_24188; V r_ = (g_list_2efoldl_24s53729099x990735293(a_0, a_1)); heff_drop(v_fs_24188); r_; });
        V v_t_24196 = (g_std_2eordmap_2esize(v_m_24195));
        if (heff_intEq_c(v_t_24196, MK_INT(0LL))) {
          heff_drop(v_m_24195);
          v_t_24197 = v_ds_24194;
        } else {
          v_t_24197 = (g_list_2emap_24s1915587473x866090925(v_m_24195, v_ds_24194));
        }
        break;
      }
      default: heff_nomatch(v_kind_24187);
      }
      v_x1_24198 = heff_tag_at_n(v_ru_24x2_24184_24MkPair, TAG_MkPair, 2, (V[]){v_t_24197, v_n_24192});
      break;
    }
    default: heff_nomatch(v_x3_24190);
    }
    break;
  }
  default: heff_nomatch(v_x2_24184);
  }
  V v_t_24201;
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_defs_24199 = heff_field(v_x1_24198, 0);
    V v_n_24200 = heff_field(v_x1_24198, 1);
    heff_take_n(v_x1_24198, 3ULL, 2);
    v_t_24201 = heff_rec_n(2, shape_defs__supply, (V[]){v_defs_24199, v_n_24200});
    break;
  }
  default: heff_nomatch(v_x1_24198);
  }
  V v_supply_24202 = heff_take_field(v_t_24201, 1);
  V v_defs_24203 = heff_get_n(v_t_24201, 0, 2);
  V v_roots_24204 = v_roots_243;
  V v_supply_24205 = v_supply_24202;
  V v_defs_24206 = v_defs_24203;
  V v_supply_24207 = v_supply_24205;
  V v_defs_24208 = heff_dup(v_defs_24206);
  V v_defs_24209 = heff_dup(v_defs_24206);
  V v_m_24210 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_defs_24206; V r_ = (g_list_2efoldl_24s327126808x177501924(a_0, a_1)); heff_drop(v_defs_24206); r_; });
  V v_t_24211 = (g_heff_2ecompile_2ecpr_2edropCalling(v_m_24210));
  V v_m_24212 = (g_heff_2ecompile_2ecpr_2ekeptGo(v_m_24210, v_t_24211));
  V v_t_24213 = (g_std_2eordmap_2etoListOnto(v_m_24212, NTAG(TAG_Nil)));
  V v_parent_24214 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24213; V r_ = (g_list_2efoldl_24s271650647x1598714891(a_0, a_1)); heff_drop(v_t_24213); r_; });
  V v_t_24215 = (g_std_2eordmap_2etoListOnto(v_m_24212, NTAG(TAG_Nil)));
  V v_parent_24216 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24215; V r_ = (g_list_2efoldl_24s271650647x1598714891(a_0, a_1)); heff_drop(v_t_24215); r_; });
  V v_m_24217 = heff_dup(v_m_24212);
  V v_t_24218 = ({ V a_0 = v_m_24217; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_24217); r_; });
  V v_shapes_24235 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam7, 2, 1, (V[]){v_parent_24216}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_24218; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24218); r_; });
  V v_t_24236 = ({ V a_0 = v_shapes_24235; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_shapes_24235); r_; });
  V v_ls_24237 = (g_list_2efoldl_24s1165300915x1297435540(heff_dup(g_std_2eordmap_2eempty_get()), v_t_24236));
  V v_m_24238 = v_m_24212;
  V v_t_24239 = ({ V a_0 = v_m_24238; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_24238); r_; });
  V v_k_24254 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam8, 2, 2, (V[]){v_parent_24214, v_ls_24237}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_24239; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24239); r_; });
  V v_t_24255 = (g_list_2emap_24s45270243x110012769(v_defs_24209));
  V v_t_24256 = (g_heff_2ecompile_2ecpr_2esitesW(heff_dup(v_k_24254), NTAG(TAG_Nil), v_t_24255));
  V v_groups_24257 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24256; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_t_24256); r_; });
  V v_t_24258 = ({ V a_0 = v_k_24254; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_k_24254); r_; });
  V v_ps_24267 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam9, 1, 1, (V[]){v_groups_24257}), v_t_24258));
  V v_k_24268 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24267; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_24267); r_; });
  V v_t_24269 = (g_std_2eordmap_2esize(v_k_24268));
  V v_c_24281;
  if (heff_intEq_c(v_t_24269, MK_INT(0LL))) {
    heff_drop(v_k_24268);
    v_c_24281 = heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_defs_24208, v_supply_24207, heff_dup(g_std_2eordmap_2eempty_get())});
  } else {
    V v_t_24272 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam10, 1, 1, (V[]){heff_dup(v_k_24268)}), v_defs_24208));
    V v_t_24273 = heff_tr(heff_call(v_t_24272, 1, (V[]){v_supply_24207}));
    switch (heff_tag_of(v_t_24273)) {
    case TAG_MkPair: {
      V v_dss_24274 = heff_field(v_t_24273, 0);
      V v_n_24275 = heff_field(v_t_24273, 1);
      heff_take_n(v_t_24273, 3ULL, 2);
      V v_t_24276 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_24274));
      V v_t_24277 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24276; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24276); r_; });
      V v_t_24278 = ({ V a_0 = v_k_24268; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_k_24268); r_; });
      V v_ps_24279 = (g_list_2emap_24s273193875x235978955(((V)&g_heff_2ecompile_2elower_2eshared_24cpr_str4), MK_INT(1LL), MK_INT(0LL), v_t_24278));
      V v_t_24280 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24279; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_24279); r_; });
      v_c_24281 = heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_t_24277, v_n_24275, v_t_24280});
      break;
    }
    default: heff_nomatch(v_t_24273);
    }
  }
  V v_defs_24282 = heff_take_field(v_c_24281, 0);
  V v_supply_24283 = heff_take_field(v_c_24281, 1);
  V v_tuples_24284 = heff_get_n(v_c_24281, 2, 3);
  V v_defs_24285 = v_defs_24282;
  V v_t_24286 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24285));
  V v_reached_24287 = ({ V a_0 = v_t_24286; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_roots_24204; V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_24286); r_; });
  V v_f_24293 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam11, 1, 1, (V[]){v_reached_24287}), v_defs_24285));
  V v_f_24294 = v_supply_24283;
  V v_f_24295 = v_tuples_24284;
  return ((HeffT3){{v_f_24293, v_f_24294, v_f_24295}});
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam0(V self, V *args) {
  V v_d_2411 = args[0];
  V v_ar_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2ecompile_2ecallarity_2esatGo(v_ar_246, heff_take_field(v_d_2411, 2)));
  return ({ V rv_2 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_d_2411, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam2(V self, V *args) {
  V v_g_2485 = args[0];
  V v_funs_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2486 = ({ V a_0 = v_funs_2431; V a_1 = v_g_2485; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_funs_2431); heff_drop(v_g_2485); r_; });
  {
    V v_field_2488 = v_t_2486.f[1];
    int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2487 == ((int64_t)0ULL)) && ({ V v_x_2489 = heff_dup(v_field_2488); int c_ = 1; heff_drop(v_x_2489); c_; })));
    heff_drop(v_field_2488);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam1(V self, V *args) {
  V v_m_2433 = args[0];
  V v_d_2434 = args[1];
  V v_funs_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2435 = heff_take_field(v_d_2434, 0);
  V v_body_2436 = heff_get_n(v_d_2434, 2, 3);
  HeffT2 v_t_2437 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_funs_2431, v_key_2435));
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_x_2440 = v_field_2439;
      heff_drop(v_x_2440);
      V v_e_2441 = v_body_2436;
      V v_t_2481;
      switch (heff_tag_of(v_e_2441)) {
      case TAG_EVar: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EGlobal: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_ELam: {
        V v_b_2445 = heff_field(v_e_2441, 1);
        heff_take_n(v_e_2441, 2ULL, 2);
        v_t_2481 = v_b_2445;
        break;
      }
      case TAG_EApp: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_ELet: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_ERecord: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EProj: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_ETag: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EMatch: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EPrim: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_ECall: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EInt: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EFloat: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EStr: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EBytes: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EFixed: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EFloat32: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EAbandon: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EBool: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_ESet: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EValues: {
        v_t_2481 = v_e_2441;
        break;
      }
      case TAG_EFix: {
        v_t_2481 = v_e_2441;
        break;
      }
      default: heff_nomatch(v_e_2441);
      }
      V v_xs_2482 = (g_heff_2ecompile_2eir_2ewaysOnto(v_t_2481, NTAG(TAG_Nil)));
      V v_t_2483 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2482));
      V v_t_2484 = (g_list_2efoldl_24s630841978x1026694071(NTAG(TAG_Nil), v_t_2483));
      V v_t_2490 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam2, 1, 1, (V[]){v_funs_2431}), v_t_2484));
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2433, v_key_2435, v_t_2490));
    } else {
      heff_drop(v_funs_2431);
      heff_drop(v_key_2435);
      heff_drop(v_body_2436);
      heff_drop(v_field_2439);
      return v_m_2433;
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam3(V self, V *args) {
  V v_w_2493 = args[0];
  V v_d_2494 = args[1];
  V v_calls_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2495 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_calls_2491, heff_rfield(v_d_2494, 0)));
  {
    V v_field_2497 = v_t_2495.f[1];
    int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
    if ((v_tag_2496 == ((int64_t)0ULL))) {
      V v_x_2498 = v_field_2497;
      heff_drop(v_x_2498);
      HeffT2 v_t_2499 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_w_2493, 1), heff_rfield(v_d_2494, 0)));
      {
        V v_field_24101 = v_t_2499.f[1];
        int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
        if ((v_tag_24100 == ((int64_t)0ULL))) {
          heff_drop_rec(v_d_2494, 3);
          heff_drop(v_calls_2491);
          V v_x_24102 = v_field_24101;
          heff_drop(v_x_24102);
          return v_w_2493;
        } else {
          heff_drop(v_field_24101);
          return ({ V a_0 = v_calls_2491; V a_1 = v_w_2493; V a_2 = heff_get_n(v_d_2494, 0, 3); V r_ = (g_heff_2ecompile_2ecycles_2estrong(a_0, a_1, a_2)); heff_drop(v_calls_2491); r_; });
        }
      }
    } else {
      heff_drop_rec(v_d_2494, 3);
      heff_drop(v_calls_2491);
      heff_drop(v_field_2497);
      return v_w_2493;
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam5(V self, V *args) {
  V v_acc_24137 = args[0];
  V v_x_24138 = args[1];
  V v_g_24133 = heff_env(self)[0];
  V v_args_24134 = heff_env(self)[1];
  V v_at_24132 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_key_24139 = heff_take_field(v_x_24138, 0);
  V v_params_24140 = heff_get_n(v_x_24138, 2, 4);
  V v_t_24142;
  if (heff_strEq_c_lent(v_key_24139, v_g_24133, 2)) {
    heff_drop(v_key_24139);
    heff_drop(v_params_24140);
    v_t_24142 = v_args_24134;
  } else {
    heff_drop(v_args_24134);
    switch (heff_tag_of(v_at_24132)) {
    case TAG_Nothing: {
      heff_drop(v_key_24139);
      v_t_24142 = (g_list_2emap_24s1460603830x671758883(((V)&g_heff_2ecompile_2elower_2eshared_24cpr_str1), v_params_24140));
      break;
    }
    case TAG_Just: {
      V v_x_24141 = heff_field(v_at_24132, 0);
      V v_ru_24at_24132_24Just = heff_take_reuse_n(v_at_24132, 1ULL, 1);
      if (!heff_strEq_c_lent(v_x_24141, v_key_24139, 0)) {
        heff_drop(v_key_24139);
        heff_drop(v_x_24141);
        v_t_24142 = (g_list_2emap_24s1809017761x1063871171_24tok1(v_ru_24at_24132_24Just, v_params_24140));
      } else {
        heff_drop(v_key_24139);
        heff_drop(v_x_24141);
        v_t_24142 = (g_list_2emap_24s1460603830x671758883_24tok1(v_ru_24at_24132_24Just, ((V)&g_heff_2ecompile_2elower_2eshared_24cpr_str2), v_params_24140));
      }
      break;
    }
    default: heff_nomatch(v_at_24132);
    }
  }
  return (g_prelude_2e_2b_2b(v_t_24142, v_acc_24137));
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam6(V self, V *args) {
  V v_m_24152 = args[0];
  V v_c_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_24153 = heff_take_field(v_m_24152, 0);
  V v_body_24154 = heff_get_n(v_m_24152, 3, 4);
  V v_t_24155 = (g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(v_c_24147, heff_dup(v_key_24153), v_body_24154));
  return heff_tag_n(TAG_MkArm, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eshared_24cpr_str3), v_key_24153), NTAG(TAG_Nil), v_t_24155});
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam4(V self, V *args) {
  V v_acc_24111 = args[0];
  V v_d_24112 = args[1];
  V v_byMember_24109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24113 = ({ V a_0 = v_byMember_24109; V a_1 = heff_rfield(v_d_24112, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byMember_24109); r_; });
  {
    V v_field_24115 = v_t_24113.f[1];
    int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
    if ((v_tag_24114 == ((int64_t)0ULL))) {
      V v_c_24116 = v_field_24115;
      V v_t_24117 = heff_dup(heff_rfield(v_c_24116, 2));
      switch (heff_tag_of(v_t_24117)) {
      case TAG_Nil: {
        heff_drop_rec(v_c_24116, 3);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_d_24112, v_acc_24111});
      }
      case TAG_Cons: {
        V v_x_24118 = heff_field(v_t_24117, 0);
        V v_ru_24t_24117_24Cons = heff_take_reuse_n(v_t_24117, 1ULL, 2);
        V v_c_24120 = v_c_24116;
        V v_acc_24121 = v_acc_24111;
        V v_d_24122 = v_d_24112;
        V v_first_24123 = v_x_24118;
        HeffT2 v_t_24124 = (g_list_2efind_24s775449825x1158002128_24cpr(heff_dup(v_d_24122), heff_rfield(v_c_24120, 2)));
        V v_t_24146;
        {
          V v_field_24126 = v_t_24124.f[1];
          int64_t v_tag_24125 = ((int64_t)v_t_24124.f[0]);
          V v_m_24128;
          if ((v_tag_24125 == ((int64_t)0ULL))) {
            V v_x_24127 = v_field_24126;
            v_m_24128 = v_x_24127;
          } else {
            heff_drop(v_field_24126);
            v_m_24128 = heff_dup(v_first_24123);
          }
          V v_outer_24129 = heff_take_field(v_m_24128, 1);
          V v_key_24130 = heff_get_n(v_m_24128, 0, 4);
          V v_c_24131 = heff_dup(v_c_24120);
          V v_at_24132 = NTAG(TAG_Nothing);
          V v_g_24133 = v_key_24130;
          V v_args_24134 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_outer_24129)));
          V v_t_24135 = heff_tag_n(TAG_ETag, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eshared_24cpr_str0), heff_dup(v_g_24133)), NTAG(TAG_Nil), NTAG(TAG_Nil)});
          V v_t_24136 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_24131, 2, 3)));
          V v_t_24143 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam5, 2, 3, (V[]){v_g_24133, v_args_24134, v_at_24132}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24136; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24136); r_; });
          V v_t_24144 = heff_tag_n(TAG_ECall, 2, (V[]){heff_dup(heff_rfield(v_c_24120, 0)), heff_tag_at_n(v_ru_24t_24117_24Cons, TAG_Cons, 2, (V[]){v_t_24135, v_t_24143})});
          V v_body_24145 = heff_tag_n(TAG_ELam, 2, (V[]){v_outer_24129, v_t_24144});
          v_t_24146 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_24122, 0)), heff_dup(heff_rfield(v_d_24122, 1)), v_body_24145});
        }
        V v_t_24159;
        if (heff_strEq_c(heff_get_n(v_first_24123, 0, 4), heff_get_n(v_d_24122, 0, 3))) {
          V v_c_24147 = v_c_24120;
          V v_t_24148 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_24147, 2))));
          V v_t_24149 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24148; V r_ = (g_list_2efoldl_24s2023159590x14712440(a_0, a_1)); heff_drop(v_t_24148); r_; });
          V v_t_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_24147, 1)), v_t_24149});
          V v_t_24151 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_c_24147, 1))});
          V v_t_24156 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2eshared_24cpr_lam6, 1, 1, (V[]){heff_dup(v_c_24147)}), heff_dup(heff_rfield(v_c_24147, 2))));
          V v_body_24157 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_24150, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_24151, v_t_24156})});
          V v_t_24158 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_c_24147, 0)), heff_get_n(v_c_24147, 0, 3), v_body_24157});
          v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24158, v_acc_24121});
        } else {
          heff_drop_rec(v_c_24120, 3);
          v_t_24159 = v_acc_24121;
        }
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24146, v_t_24159});
      }
      default: return heff_nomatch(v_t_24117);
      }
    } else {
      heff_drop(v_field_24115);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_d_24112, v_acc_24111});
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam7(V self, V *args) {
  V v_acc_24219 = args[0];
  V v_p_24220 = args[1];
  V v_parent_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_24223;
  switch (heff_tag_of(v_p_24220)) {
  case TAG_MkPair: {
    V v_x_24221 = heff_dup(heff_field(v_p_24220, 0));
    v_x_24223 = v_x_24221;
    break;
  }
  default: heff_nomatch(v_p_24220);
  }
  V v_t_24224 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_24216, v_x_24223));
  V v_root_24225 = ({ V a_0 = v_parent_24216; V a_1 = v_x_24223; V a_2 = v_t_24224; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_24216); r_; });
  HeffT2 v_t_24226 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_acc_24219, v_root_24225));
  V v_t_24230;
  {
    V v_field_24228 = v_t_24226.f[1];
    int64_t v_tag_24227 = ((int64_t)v_t_24226.f[0]);
    if ((v_tag_24227 == ((int64_t)0ULL))) {
      V v_x_24229 = v_field_24228;
      v_t_24230 = v_x_24229;
    } else {
      heff_drop(v_field_24228);
      v_t_24230 = NTAG(TAG_NoShape);
    }
  }
  V v_t_24233;
  switch (heff_tag_of(v_p_24220)) {
  case TAG_MkPair: {
    V v_y_24232 = heff_field(v_p_24220, 1);
    heff_take_n(v_p_24220, 2ULL, 2);
    v_t_24233 = v_y_24232;
    break;
  }
  default: heff_nomatch(v_p_24220);
  }
  V v_t_24234 = (g_list_2efoldl_24s1766906699x9526323(v_t_24230, v_t_24233));
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_acc_24219, v_root_24225, v_t_24234));
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam8(V self, V *args) {
  V v_acc_24240 = args[0];
  V v_p_24241 = args[1];
  V v_parent_24214 = heff_env(self)[0];
  V v_ls_24237 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24244;
  switch (heff_tag_of(v_p_24241)) {
  case TAG_MkPair: {
    V v_x_24242 = heff_dup(heff_field(v_p_24241, 0));
    v_x_24244 = v_x_24242;
    break;
  }
  default: heff_nomatch(v_p_24241);
  }
  V v_t_24245 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_24214, v_x_24244));
  V v_t_24246 = ({ V a_0 = v_parent_24214; V a_1 = v_x_24244; V a_2 = v_t_24245; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_24214); r_; });
  HeffT2 v_t_24247 = ({ V a_0 = v_ls_24237; V a_1 = v_t_24246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_ls_24237); heff_drop(v_t_24246); r_; });
  {
    V v_field_24249 = v_t_24247.f[1];
    int64_t v_tag_24248 = ((int64_t)v_t_24247.f[0]);
    if ((v_tag_24248 == ((int64_t)0ULL))) {
      V v_lay_24250 = v_field_24249;
      V v_t_24253;
      switch (heff_tag_of(v_p_24241)) {
      case TAG_MkPair: {
        V v_x_24251 = heff_field(v_p_24241, 0);
        heff_take_n(v_p_24241, 1ULL, 2);
        v_t_24253 = v_x_24251;
        break;
      }
      default: heff_nomatch(v_p_24241);
      }
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_acc_24240, v_t_24253, v_lay_24250));
    } else {
      heff_drop(v_p_24241);
      heff_drop(v_field_24249);
      return v_acc_24240;
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam9(V self, V *args) {
  V v_p_24259 = args[0];
  V v_groups_24257 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24262;
  switch (heff_tag_of(v_p_24259)) {
  case TAG_MkPair: {
    V v_y_24261 = heff_field(v_p_24259, 1);
    heff_take_n(v_p_24259, 2ULL, 2);
    v_t_24262 = v_y_24261;
    break;
  }
  default: heff_nomatch(v_p_24259);
  }
  HeffT2 v_t_24263 = ({ V a_0 = v_groups_24257; V b_1 = heff_get_n(v_t_24262, 6, 7); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_groups_24257); heff_drop(b_1); r_; });
  {
    V v_field_24265 = v_t_24263.f[1];
    int64_t v_tag_24264 = ((int64_t)v_t_24263.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24264 == ((int64_t)0ULL)) && ({ V v_x_24266 = heff_dup(v_field_24265); int c_ = 1; heff_drop(v_x_24266); c_; })));
    heff_drop(v_field_24265);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam10(V self, V *args) {
  V v_d_24270 = args[0];
  V v_k_24268 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24271 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_k_24268, heff_rfield(v_d_24270, 0)));
  return ({ V a_0 = v_k_24268; V a_1 = v_d_24270; V a_2 = v_t_24271; V r_ = (g_heff_2ecompile_2ecpr_2edefWith(a_0, a_1, a_2)); heff_drop(v_k_24268); heff_drop(v_t_24271); r_; });
}
V g_heff_2ecompile_2elower_2eshared_24cpr_lam11(V self, V *args) {
  V v_d_24288 = args[0];
  V v_reached_24287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24289 = ({ V a_0 = v_reached_24287; V b_1 = heff_get_n(v_d_24288, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_24287); heff_drop(b_1); r_; });
  {
    V v_field_24291 = v_t_24289.f[1];
    int64_t v_tag_24290 = ((int64_t)v_t_24289.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24290 == ((int64_t)0ULL)) && ({ V v_x_24292 = heff_dup(v_field_24291); int c_ = 1; heff_drop(v_x_24292); c_; })));
    heff_drop(v_field_24291);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2efusedOf_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_lam4(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_lam6(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_lam5(V self, V *args);
Clo g_heff_2ecompile_2elower_2efusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efusedOf_entry, 2, 0};

V g_heff_2ecompile_2elower_2efusedOf(V v_roots_240, V v_si_241) {
top: ;
  V v_defs_242 = heff_take_field(v_si_241, 0);
  V v_supply_243 = heff_get_n(v_si_241, 1, 4);
  V v_defs_244 = v_defs_242;
  V v_t_245 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_244));
  V v_reached_246 = ({ V a_0 = v_t_245; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  V v_defs_2412 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam0, 1, 1, (V[]){v_reached_246}), v_defs_244));
  V v_roots_2413 = v_roots_240;
  V v_defs_2414 = heff_dup(v_defs_2412);
  V v_small_2467 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam1, 2, 1, (V[]){v_roots_2413}), heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2414));
  V v_t_2471 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam2, 2, 1, (V[]){heff_dup(v_small_2467)}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_2414; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_2414); r_; });
  V v_t_2472 = ({ V a_0 = v_small_2467; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_small_2467); r_; });
  V v_cs_2473 = ({ V a_0 = v_t_2471; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_2472; V r_ = (g_list_2efoldl_24s2098410461x866205771(a_0, a_1, a_2)); heff_drop(v_t_2472); r_; });
  V v_defs_2474 = v_defs_2412;
  V v_cs_2475 = heff_dup(v_cs_2473);
  V v_t_2476 = ({ V a_0 = v_cs_2473; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_cs_2473); r_; });
  V v_x3_2477 = (g_list_2efoldl_24s637780307x9274583(heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_supply_243}), v_t_2476));
  V v_x1_2489;
  switch (heff_tag_of(v_x3_2477)) {
  case TAG_MkPair: {
    V v_fresh_2478 = heff_field(v_x3_2477, 0);
    V v_n_2479 = heff_field(v_x3_2477, 1);
    V v_ru_24x3_2477_24MkPair = heff_take_reuse_n(v_x3_2477, 3ULL, 2);
    V v_t_2485 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam3, 1, 1, (V[]){v_cs_2475}), v_defs_2474));
    V v_t_2488 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam4, 1, 1, (V[]){v_fresh_2478}), v_t_2485));
    v_x1_2489 = heff_tag_at_n(v_ru_24x3_2477_24MkPair, TAG_MkPair, 2, (V[]){v_t_2488, v_n_2479});
    break;
  }
  default: heff_nomatch(v_x3_2477);
  }
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_MkPair: {
    V v_defs_2490 = heff_field(v_x1_2489, 0);
    V v_n_2491 = heff_field(v_x1_2489, 1);
    V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
    V v_supply_2492 = v_n_2491;
    V v_defs_2493 = v_defs_2490;
    V v_sg_2494 = (g_list_2efoldl_24s890299851x180637966(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())}), v_defs_2493));
    V v_t_24102 = (g_prelude_2etraverse_24s545943161x1483966866(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam5, 1, 1, (V[]){v_sg_2494}), heff_dup(v_defs_2493)));
    V v_t_24103 = (g_list_2efoldl_24s1530765264x1072548396(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2493));
    V v_t_24104 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_defs_2493; V r_ = (g_list_2efoldl_24s42602063x979600769(a_0, a_1)); heff_drop(v_defs_2493); r_; });
    V v_t_24105 = heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_supply_2492, v_t_24103, v_t_24104, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), MK_INT(2000LL)});
    V v_x2_24106 = heff_tr(heff_call(v_t_24102, 1, (V[]){v_t_24105}));
    switch (heff_tag_of(v_x2_24106)) {
    case TAG_MkPair: {
      V v_ds_24107 = heff_field(v_x2_24106, 0);
      V v_s_24108 = heff_field(v_x2_24106, 1);
      heff_take_n(v_x2_24106, 3ULL, 2);
      V v_fresh_24109 = heff_take_field(v_s_24108, 4);
      V v_supply_24110 = heff_get_n(v_s_24108, 0, 6);
      V v_t_24111 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fresh_24109));
      V v_t_24112 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_2489_24MkPair, v_ds_24107, v_t_24111));
      return heff_rec_n(2, shape_defs__supply, (V[]){v_t_24112, v_supply_24110});
    }
    default: return heff_nomatch(v_x2_24106);
    }
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2efusedOf(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2efusedOf_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_reached_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_reached_246; V b_1 = heff_get_n(v_d_247, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_246); heff_drop(b_1); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_249 == ((int64_t)0ULL)) && ({ V v_x_2411 = heff_dup(v_field_2410); int c_ = 1; heff_drop(v_x_2411); c_; })));
    heff_drop(v_field_2410);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2efusedOf_lam1(V self, V *args) {
  V v_m_2415 = args[0];
  V v_d_2416 = args[1];
  V v_roots_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2417 = heff_take_field(v_d_2416, 0);
  V v_body_2418 = heff_get_n(v_d_2416, 2, 3);
  V v_roots_2419 = v_roots_2413;
  V v_g_2420 = heff_dup(v_key_2417);
  V v_e_2421 = v_body_2418;
  V v_x3_2465;
  switch (heff_tag_of(v_e_2421)) {
  case TAG_EVar: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    V v_xs_2424 = heff_field(v_e_2421, 0);
    V v_b_2425 = heff_field(v_e_2421, 1);
    V v_ru_24e_2421_24ELam = heff_take_reuse_n(v_e_2421, 3ULL, 2);
    V v_t_2426 = heff_tag_at_n(v_ru_24e_2421_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_2425), NTAG(TAG_Nil)});
    V v_x_2427 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(75LL), MK_INT(0LL), v_t_2426));
    if (!heff_intLt_c_lent(MK_INT(75LL), v_x_2427, 1)) {
      heff_drop(v_x_2427);
      V v_t_2428 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_g_2420}));
      V v_x1_2429 = ({ V a_0 = v_t_2428; V a_1 = v_roots_2419; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_roots_2419); r_; });
      if (!(heff_dup(v_x1_2429) == NTAG(TAG_True))) {
        heff_drop(v_x1_2429);
        v_x3_2465 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_xs__b, (V[]){v_xs_2424, v_b_2425})});
      } else {
        heff_drop(v_xs_2424);
        heff_drop(v_b_2425);
        heff_drop(v_x1_2429);
        v_x3_2465 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_roots_2419);
      heff_drop(v_g_2420);
      heff_drop(v_xs_2424);
      heff_drop(v_b_2425);
      heff_drop(v_x_2427);
      v_x3_2465 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_e_2421, 0ULL, 3);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_e_2421, 0ULL, 4);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_e_2421, 0ULL, 3);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_e_2421, 0ULL, 3);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_roots_2419);
    heff_drop(v_g_2420);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_2421);
  }
  switch (heff_tag_of(v_x3_2465)) {
  case TAG_Nothing: {
    heff_drop(v_key_2417);
    return v_m_2415;
  }
  case TAG_Just: {
    V v_c_2466 = heff_field(v_x3_2465, 0);
    heff_take_n(v_x3_2465, 1ULL, 1);
    return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2415, v_key_2417, v_c_2466));
  }
  default: return heff_nomatch(v_x3_2465);
  }
}
V g_heff_2ecompile_2elower_2efusedOf_lam2(V self, V *args) {
  V v_m_2468 = args[0];
  V v_d_2469 = args[1];
  V v_small_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_d_2469, 2, 3), NTAG(TAG_Nil)});
  return ({ V a_0 = v_small_2467; V a_1 = v_m_2468; V a_2 = v_t_2470; V r_ = (g_heff_2ecompile_2eonce_2eusesW(a_0, a_1, a_2)); heff_drop(v_small_2467); r_; });
}
V g_heff_2ecompile_2elower_2efusedOf_lam3(V self, V *args) {
  V v_d_2480 = args[0];
  V v_cs_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2481 = ({ V a_0 = v_cs_2475; V b_1 = heff_get_n(v_d_2480, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_cs_2475); heff_drop(b_1); r_; });
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2482 == ((int64_t)0ULL)) ? ({ V v_x_2484 = heff_dup(v_field_2483); int c_ = 0; heff_drop(v_x_2484); c_; }) : 1));
    heff_drop(v_field_2483);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2efusedOf_lam4(V self, V *args) {
  V v_d_2486 = args[0];
  V v_fresh_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_body_2487 = ({ V a_0 = v_fresh_2478; V a_1 = NTAG(TAG_Nil); V a_2 = heff_take_field(v_d_2486, 2); V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_fresh_2478); r_; });
  return ({ V rv_2 = v_body_2487; V rr_ = heff_rec_reuse_nf(v_d_2486, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2elower_2efusedOf_lam6(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_d_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    V v_t_24101 = ({ V rv_2 = v_x_2499; V rr_ = heff_rec_reuse_nf(v_d_2495, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){v_t_24101, v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2elower_2efusedOf_lam5(V self, V *args) {
  V v_d_2495 = args[0];
  V v_sg_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2496 = (g_heff_2ecompile_2efuse_2esites(v_sg_2494, heff_dup(heff_rfield(v_d_2495, 2))));
  return heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam6, 1, 2, (V[]){v_m_2496, v_d_2495});
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryKey_str0, 9, "run$entry");

static V g_heff_2ecompile_2elower_2eentryKey_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2eentryKey_st;
static V g_heff_2ecompile_2elower_2eentryKey_init(void) {
  return ((V)&g_heff_2ecompile_2elower_2eentryKey_str0);
}
V g_heff_2ecompile_2elower_2eentryKey_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2eentryKey_st)) return g_heff_2ecompile_2elower_2eentryKey_val;
  return heff_global(&g_heff_2ecompile_2elower_2eentryKey_val, &g_heff_2ecompile_2elower_2eentryKey_st, g_heff_2ecompile_2elower_2eentryKey_init);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str0, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str1, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str2, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str3, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str4, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str5, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str6, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str7, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str8, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str9, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str10, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str11, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str12, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str13, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str14, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str15, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str16, 4, "malg");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str17, 4, "bind");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str18, 3, "ret");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str19, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str20, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str21, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str22, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str23, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str24, 6, "MkUnit");
Clo g_heff_2ecompile_2elower_2eentryBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryBody_entry, 2, 0};

V g_heff_2ecompile_2elower_2eentryBody(V v_key_240, V v_n_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str0), heff_intShow(heff_dup(v_n_241)));
  V v_t_243 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str1), v_t_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_246 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str2), v_t_245)});
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str3), heff_intShow(heff_dup(v_n_241)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244}), heff_tag_n(TAG_EApp, 2, (V[]){v_t_246, v_t_248})});
  V v_t_2410 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2411 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2412 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str4), v_t_2412), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str5), v_t_2411), v_t_2413});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str6), v_t_2410), v_t_2414});
  V v_t_2416 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2417 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str7), v_t_2416)});
  V v_t_2418 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str8), v_t_2418), NTAG(TAG_Nil)});
  V v_t_2420 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2421 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str9), v_t_2420)});
  V v_t_2422 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2423 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str10), v_t_2422)});
  V v_t_2424 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2425 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str11), v_t_2424)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2419, v_t_2427}), NTAG(TAG_Nil)});
  V v_t_2429 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2417, v_t_2428})});
  V v_t_2430 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2431 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str12), v_t_2431), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str13), v_t_2430), v_t_2432});
  V v_t_2434 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2435 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str14), v_t_2434)});
  V v_t_2436 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2437 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str15), v_t_2436)});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
  V v_t_2439 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_Perform), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str16), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2433, v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str17), v_t_2429}), v_t_2441});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str18), v_t_249}), v_t_2442});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2444});
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2445});
  V v_t_2447 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2448 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str19), v_t_2448), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str20), v_t_2447), v_t_2449});
  V v_t_2451 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2452 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str21), v_t_2451)});
  V v_t_2453 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2454 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str22), v_t_2453)});
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2450, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2452, v_t_2455})});
  V v_t_2457 = heff_intShow(heff_intAdd(v_n_241, MK_INT(10LL)));
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str23), v_t_2457), NTAG(TAG_Nil)});
  V v_t_2459 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str24), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2458, v_t_2459}), NTAG(TAG_Nil)});
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2443, v_t_2446}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, v_t_2460})});
  return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_240}), v_t_2461});
}
V g_heff_2ecompile_2elower_2eentryBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eentryBody(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2ecFacts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecFacts_entry, 2, 0};

V g_heff_2ecompile_2elower_2ecFacts(V v_defs_240, V v_facts_241) {
top: ;
  V v_m_242 = (g_list_2efoldl_24s1738438673x24732785(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_240)));
  V v_t_243 = ({ V a_0 = v_m_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_242); r_; });
  V v_ps_244 = (g_list_2ekeepIf_24s1223034477x943356724(v_t_243));
  V v_su_245 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_244; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_244); r_; });
  V v_fl_246 = (g_list_2efoldl_24s2004150897x784001505(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_240)));
  V v_m_247 = (g_list_2efoldl_24s243940296x1179168444(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_240)));
  V v_t_248 = ({ V a_0 = v_m_247; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_247); r_; });
  V v_ps_249 = (g_list_2ekeepIf_24s1223034477x943356724(v_t_248));
  V v_su_2410 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_249; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_249); r_; });
  V v_facts_2411 = ({ V rv_5 = v_fl_246; V rv_6 = v_su_2410; V rv_7 = v_su_245; V rr_ = heff_rec_reuse_nf(v_facts_241, 1823ULL, 11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, 4129791u, 0u); heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_ws_2412 = (g_heff_2ecompile_2eworker_2eworkers(heff_dup(v_facts_2411), v_defs_240));
  return ({ V rv_4 = v_ws_2412; V rr_ = heff_rec_reuse_nf(v_facts_2411, 2031ULL, 11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, 4193535u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2ecompile_2elower_2ecFacts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecFacts(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_str1, 4, "$tok");
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam5(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam6(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam4(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam7(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam8(V self, V *args);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam9(V self, V *args);
Clo g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_entry, 3, 0};

V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337(V v_roots_240, V v_errors_241, V v_f_242) {
top: ;
  V v_supply_243 = heff_take_field(v_f_242, 1);
  V v_defs_244 = heff_get_n(v_f_242, 0, 2);
  V v_supply_245 = v_supply_243;
  V v_defs_246 = v_defs_244;
  V v_t_247 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_246));
  V v_reached_248 = ({ V a_0 = v_t_247; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_kept_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam0, 1, 1, (V[]){v_reached_248}), v_defs_246));
  V v_roots_2415 = v_roots_240;
  V v_errors_2416 = v_errors_241;
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_supply_245});
  V v_t_2418 = (g_list_2efoldl_24s1078918265x314186258(v_t_2417, v_kept_2414));
  V v_x3_2424;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_MkPair: {
    V v_acc_2419 = heff_field(v_t_2418, 0);
    V v_n2_2420 = heff_field(v_t_2418, 1);
    V v_ru_24t_2418_24MkPair = heff_take_reuse_n(v_t_2418, 3ULL, 2);
    V v_xs_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_2419));
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
    V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2422); r_; });
    v_x3_2424 = heff_tag_at_n(v_ru_24t_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_n2_2420});
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  switch (heff_tag_of(v_x3_2424)) {
  case TAG_MkPair: {
    V v_defs_2425 = heff_field(v_x3_2424, 0);
    V v_n_2426 = heff_field(v_x3_2424, 1);
    V v_ru_24x3_2424_24MkPair = heff_take_reuse_n(v_x3_2424, 3ULL, 2);
    HeffT3 v_t_2427 = (g_heff_2ecompile_2elower_2eshared_24cpr(v_roots_2415, v_n_2426, v_defs_2425));
    {
      V v_field_2428 = v_t_2427.f[0];
      V v_field_2429 = v_t_2427.f[1];
      V v_field_2430 = v_t_2427.f[2];
      V v_errors_2431 = v_errors_2416;
      V v_tuples_2432 = v_field_2430;
      V v_n_2433 = v_field_2429;
      V v_t_2434 = (g_prelude_2etraverse_24s1111575179x1680558317(v_field_2428));
      V v_x1_2435 = heff_tr(heff_call(v_t_2434, 1, (V[]){v_n_2433}));
      V v_x3_2439;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_MkPair: {
        V v_defs_2436 = heff_field(v_x1_2435, 0);
        V v_n_2437 = heff_field(v_x1_2435, 1);
        heff_take_n(v_x1_2435, 3ULL, 2);
        V v_t_2438 = (g_prelude_2etraverse_24s812820150x374715993(v_defs_2436));
        v_x3_2439 = heff_tr(heff_call(v_t_2438, 1, (V[]){v_n_2437}));
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      switch (heff_tag_of(v_x3_2439)) {
      case TAG_MkPair: {
        V v_defs_2440 = heff_field(v_x3_2439, 0);
        V v_n_2441 = heff_field(v_x3_2439, 1);
        V v_ru_24x3_2439_24MkPair = heff_take_reuse_n(v_x3_2439, 3ULL, 2);
        V v_tuples_2442 = heff_dup(v_tuples_2432);
        V v_s_2443 = v_n_2441;
        V v_defs_2444 = v_defs_2440;
        V v_tuples_2445 = v_tuples_2442;
        V v_byKey_2446 = (g_list_2efoldl_24s88009013x1334911863(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2444));
        V v_t_2447 = (g_list_2emap_24s45270243x110012769(heff_dup(v_defs_2444)));
        V v_sites_2448 = (g_heff_2ecompile_2etokens_2esitesW(NTAG(TAG_Nil), v_t_2447));
        V v_m_24125 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam1, 2, 2, (V[]){v_byKey_2446, v_tuples_2445}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_sites_2448; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_sites_2448); r_; });
        V v_t_24126 = ({ V a_0 = v_m_24125; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_24125); r_; });
        V v_cs_24127 = (g_list_2emap_24s366344330x1145113647(v_t_24126));
        HeffT2 v_t_24128 = (g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(heff_dup(v_cs_24127), v_s_2443));
        V v_t_24136;
        {
          V v_field_24129 = v_t_24128.f[0];
          V v_field_24130 = v_t_24128.f[1];
          V v_copied_24131 = v_field_24129;
          V v_s_24132 = v_field_24130;
          V v_t_24133 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_2424_24MkPair, v_defs_2444, v_copied_24131));
          V v_t_24134 = (g_list_2efoldl_24s532743697x1094589833(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_cs_24127)));
          V v_t_24135 = ({ V a_0 = ((V)&g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_str1); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_cs_24127; V r_ = (g_list_2efoldl_24s330602584x1277356584(a_0, a_1, a_2)); heff_drop(v_cs_24127); r_; });
          v_t_24136 = heff_rec_n(3, shape_defs__supply__tokens, (V[]){v_t_24133, v_s_24132, heff_rec_n(2, shape_byFun__cells, (V[]){v_t_24134, v_t_24135})});
        }
        V v_tokens_24137 = heff_take_field(v_t_24136, 2);
        V v_supply_24138 = heff_take_field(v_t_24136, 1);
        V v_defs_24139 = heff_get_n(v_t_24136, 0, 3);
        V v_errors_24140 = v_errors_2431;
        V v_tuples_24141 = v_tuples_2432;
        V v_tk_24142 = v_tokens_24137;
        V v_supply_24143 = v_supply_24138;
        V v_t_24144 = (g_prelude_2etraverse_24s248425057x1995322387(v_defs_24139));
        V v_x1_24145 = heff_tr(heff_call(v_t_24144, 1, (V[]){v_supply_24143}));
        V v_x1_24149;
        switch (heff_tag_of(v_x1_24145)) {
        case TAG_MkPair: {
          V v_defs_24146 = heff_field(v_x1_24145, 0);
          V v_n_24147 = heff_field(v_x1_24145, 1);
          heff_take_n(v_x1_24145, 3ULL, 2);
          V v_t_24148 = (g_prelude_2etraverse_24s1617808025x638052145(v_defs_24146));
          v_x1_24149 = heff_tr(heff_call(v_t_24148, 1, (V[]){v_n_24147}));
          break;
        }
        default: heff_nomatch(v_x1_24145);
        }
        V v_defs_24152;
        switch (heff_tag_of(v_x1_24149)) {
        case TAG_MkPair: {
          V v_x_24150 = heff_field(v_x1_24149, 0);
          heff_take_n(v_x1_24149, 1ULL, 2);
          v_defs_24152 = v_x_24150;
          break;
        }
        default: heff_nomatch(v_x1_24149);
        }
        V v_consts_24153 = (g_list_2efoldl_24s1068175575x1869083571(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24152));
        V v_defs_24154 = heff_dup(v_defs_24152);
        V v_ar_24155 = (g_list_2efoldl_24s1810610888x1691479932(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24152));
        V v_scans_24162 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam2, 2, 1, (V[]){v_ar_24155}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_24152; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_24152); r_; });
        V v_t_24163 = (g_std_2eordmap_2etoListOnto(v_scans_24162, NTAG(TAG_Nil)));
        V v_esc_24164 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24163; V r_ = (g_list_2efoldl_24s591996130x301722846(a_0, a_1)); heff_drop(v_t_24163); r_; });
        V v_fns_24165 = (g_list_2efoldl_24s26403090x581733227(v_esc_24164, heff_dup(v_scans_24162), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_24154)));
        V v_consts_24166 = v_consts_24153;
        V v_defs_24167 = v_defs_24154;
        V v_scans_24168 = v_scans_24162;
        V v_fns_24169 = heff_dup(v_fns_24165);
        V v_t_24170 = (g_std_2eordmap_2etoListOnto(v_fns_24165, NTAG(TAG_Nil)));
        V v_t_24171 = (g_list_2ekeepIf_24s1606737509x658906972(v_t_24170));
        V v_t_24172 = (g_std_2eordmap_2emapValues_24s383523993x1452310955(v_fns_24165));
        V v_ms_24173 = ({ V a_0 = v_t_24171; V a_1 = MK_INT(64LL); V a_2 = v_t_24172; V r_ = (g_heff_2ecompile_2eranges_2emattering(a_0, a_1, a_2)); heff_drop(v_t_24171); r_; });
        V v_t_24174 = ({ V a_0 = v_ms_24173; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_ms_24173); r_; });
        V v_params_24186 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam3, 2, 1, (V[]){v_fns_24169}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_24174; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24174); r_; });
        V v_consts_24187 = v_consts_24166;
        V v_defs_24188 = heff_dup(v_defs_24167);
        V v_params_24189 = heff_dup(v_params_24186);
        V v_sc_24230 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam4, 2, 2, (V[]){v_params_24186, v_scans_24168}); V a_1 = heff_rec_n(4, shape_byKey__callers__callersOf__ints, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())}); V a_2 = v_defs_24167; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_24167); r_; });
        V v_consts_24231 = heff_dup(v_consts_24187);
        V v_sc_24232 = heff_dup(v_sc_24230);
        V v_defs_24233 = heff_dup(v_defs_24188);
        V v_t_24234 = heff_rec_n(3, shape_fix__dirty__gathered, (V[]){heff_rec_n(3, shape_params__grown__marks, (V[]){heff_dup(v_params_24189), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())}), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
        V v_t_24235 = (g_list_2emap_24s1835183789x486277886(v_defs_24188));
        V v_t_24241 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam7, 1, 1, (V[]){v_params_24189}), v_t_24235));
        V v_t_24242 = ({ V a_0 = heff_dup(v_consts_24187); V a_1 = heff_dup(v_sc_24230); V a_2 = v_t_24234; V a_3 = v_t_24241; V r_ = (g_heff_2ecompile_2eranges_2eroundOf(a_0, a_1, a_2, a_3)); heff_drop(v_t_24241); r_; });
        HeffT2 v_t_24243 = (g_heff_2ecompile_2eranges_2erounds_24cpr(v_consts_24187, v_sc_24230, MK_INT(64LL), v_t_24242));
        V v_r_24289;
        {
          V v_field_24245 = v_t_24243.f[1];
          int64_t v_tag_24244 = ((int64_t)v_t_24243.f[0]);
          if ((v_tag_24244 == ((int64_t)0ULL))) {
            V v_s_24246 = v_field_24245;
            V v_fix_24247 = heff_take_field(v_s_24246, 0);
            V v_gathered_24248 = heff_get_n(v_s_24246, 2, 3);
            V v_consts_24249 = heff_dup(v_consts_24231);
            V v_sc_24250 = heff_dup(v_sc_24232);
            V v_defs_24251 = v_defs_24233;
            V v_t_24252 = heff_rec_n(3, shape_params__gathered__changed, (V[]){heff_dup(heff_rfield(v_fix_24247, 0)), heff_dup(v_gathered_24248), NTAG(TAG_Nil)});
            V v_t_24253 = ({ V b_0 = heff_get_n(v_fix_24247, 0, 3); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_24254 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x3_2439_24MkPair, v_t_24253));
            V v_t_24255 = ({ V a_0 = heff_dup(v_sc_24232); V a_1 = v_t_24252; V a_2 = v_gathered_24248; V a_3 = v_t_24254; V r_ = (g_heff_2ecompile_2eranges_2enarrowWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_24254); r_; });
            V v_params_24256 = (g_heff_2ecompile_2eranges_2enarrowing(v_consts_24231, v_sc_24232, MK_INT(3LL), v_t_24255));
            V v_t_24286 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam8, 1, 3, (V[]){v_sc_24250, heff_dup(v_params_24256), v_consts_24249}), v_defs_24251));
            V v_t_24287 = ({ V a_0 = v_params_24256; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_params_24256); r_; });
            V v_t_24288 = ({ V a_0 = MK_INT(-4611686018427387904LL); V a_1 = MK_INT(4611686018427387903LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = MK_INT(0LL); V a_5 = MK_INT(1LL); V a_6 = MK_INT(-4611686018427387904LL); V a_7 = MK_INT(4611686018427387903LL); V a_8 = MK_INT(0LL); V a_9 = MK_INT(1LL); V a_10 = MK_INT(0LL); V a_11 = MK_INT(1LL); V a_12 = heff_dup(g_std_2eordmap_2eempty_get()); V a_13 = v_t_24287; V r_ = (g_list_2efoldl_24s322049767x2109647543(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_t_24287); r_; });
            v_r_24289 = heff_rec_n(2, shape_defs__words, (V[]){v_t_24286, v_t_24288});
          } else {
            heff_drop_cell(v_ru_24x3_2439_24MkPair, 2);
            heff_drop(v_consts_24231);
            heff_drop(v_sc_24232);
            heff_drop(v_field_24245);
            v_r_24289 = heff_rec_n(2, shape_defs__words, (V[]){v_defs_24233, heff_dup(g_std_2eordmap_2eempty_get())});
          }
        }
        V v_defs_24290 = heff_take_field(v_r_24289, 0);
        V v_words_24291 = heff_get_n(v_r_24289, 1, 2);
        V v_ws_24292 = v_words_24291;
        V v_tk_24293 = heff_dup(v_tk_24142);
        V v_defs_24294 = heff_dup(v_defs_24290);
        V v_t_24295 = (g_list_2efoldl_24s1769360958x1839054239(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24294));
        V v_m_24296 = ({ V a_0 = v_defs_24294; V a_1 = MK_INT(-1LL); V a_2 = v_t_24295; V r_ = (g_heff_2ecompile_2eborrow_2eborFix(a_0, a_1, a_2)); heff_drop(v_defs_24294); r_; });
        V v_t_24297 = ({ V a_0 = v_m_24296; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_24296); r_; });
        V v_ps_24313 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam9, 1, 1, (V[]){v_tk_24293}), v_t_24297));
        V v_lent_24314 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24313; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_24313); r_; });
        V v_f_24315 = (g_heff_2ecompile_2efacts_2efactsOf(v_defs_24290));
        V v_arity_24316 = heff_take_field(v_f_24315, 0);
        V v_bounce_24317 = heff_take_field(v_f_24315, 1);
        V v_lazy_24318 = heff_take_field(v_f_24315, 2);
        V v_workers_24319 = heff_take_field(v_f_24315, 4);
        V v_flat_24320 = heff_take_field(v_f_24315, 5);
        V v_sure_24321 = heff_take_field(v_f_24315, 6);
        V v_sureRecs_24322 = heff_get_n(v_f_24315, 7, 11);
        V v_t_24323 = v_arity_24316;
        V v_t_24324 = v_bounce_24317;
        V v_t_24325 = v_lazy_24318;
        V v_t_24326 = v_workers_24319;
        V v_t_24327 = v_flat_24320;
        V v_t_24328 = v_sure_24321;
        V v_t_24329 = v_sureRecs_24322;
        V v_t_24330 = (g_heff_2ecompile_2elower_2ecFacts(heff_dup(v_defs_24290), heff_rec_n(11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, (V[]){v_t_24323, v_t_24324, v_t_24325, v_lent_24314, v_t_24326, v_t_24327, v_t_24328, v_t_24329, v_tuples_24141, v_ws_24292, v_tk_24142})));
        return heff_rec_n(3, shape_defs__facts__errors, (V[]){v_defs_24290, v_t_24330, v_errors_24140});
      }
      default: return heff_nomatch(v_x3_2439);
      }
    }
  }
  default: return heff_nomatch(v_x3_2424);
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_reached_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V a_0 = v_reached_248; V b_1 = heff_get_n(v_d_249, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_248); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) && ({ V v_x_2413 = heff_dup(v_field_2412); int c_ = 1; heff_drop(v_x_2413); c_; })));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam1(V self, V *args) {
  V v_m_2449 = args[0];
  V v_s_2450 = args[1];
  V v_byKey_2446 = heff_env(self)[0];
  V v_tuples_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453;
  switch (heff_tag_of(v_s_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_dup(heff_field(v_s_2450, 0));
    v_t_2453 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_s_2450);
  }
  HeffT2 v_t_2454 = ({ V a_0 = v_byKey_2446; V a_1 = v_t_2453; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byKey_2446); heff_drop(v_t_2453); r_; });
  {
    V v_field_2456 = v_t_2454.f[1];
    int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
    if ((v_tag_2455 == ((int64_t)0ULL))) {
      V v_d_2457 = v_field_2456;
      V v_tuples_2458 = v_tuples_2445;
      V v_n_2461;
      switch (heff_tag_of(v_s_2450)) {
      case TAG_MkPair: {
        V v_y_2460 = heff_dup(heff_field(v_s_2450, 1));
        v_n_2461 = v_y_2460;
        break;
      }
      default: heff_nomatch(v_s_2450);
      }
      V v_d_2462 = heff_dup(v_d_2457);
      V v_t_2463 = heff_dup(heff_rfield(v_d_2462, 2));
      V v_t_24114;
      switch (heff_tag_of(v_t_2463)) {
      case TAG_EVar: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        V v_b_2467 = heff_field(v_t_2463, 1);
        V v_ru_24t_2463_24ELam = heff_take_reuse_n(v_t_2463, 2ULL, 2);
        HeffT2 v_t_2468 = ({ V a_0 = v_tuples_2458; V a_1 = heff_rfield(v_d_2462, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_tuples_2458); r_; });
        {
          V v_field_2470 = v_t_2468.f[1];
          int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
          if ((v_tag_2469 == ((int64_t)0ULL))) {
            heff_drop(v_n_2461);
            heff_drop_rec(v_d_2462, 3);
            heff_drop(v_b_2467);
            heff_drop_cell(v_ru_24t_2463_24ELam, 2);
            V v_x_2471 = v_field_2470;
            heff_drop(v_x_2471);
            v_t_24114 = NTAG(TAG_False);
          } else {
            heff_drop(v_field_2470);
            V v_t_2472 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2467)));
            V v_t_2473 = (g_heff_2ecompile_2eir_2enubI(v_t_2472));
            V v_x1_2474 = ({ V a_0 = v_d_2462; V a_1 = v_t_2473; V r_ = (g_list_2eany_24s277053946x716662586(a_0, a_1)); heff_drop(v_t_2473); r_; });
            if (!(heff_dup(v_x1_2474) == NTAG(TAG_True))) {
              heff_drop(v_x1_2474);
              V v_t_2475 = heff_tag_at_n(v_ru_24t_2463_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_2467), NTAG(TAG_Nil)});
              V v_t_2476 = (g_heff_2ecompile_2etokens_2ebuildsW(v_n_2461, v_t_2475));
              if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
                heff_drop(v_t_2476);
                V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2467, NTAG(TAG_Nil)});
                V v_x_2478 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(150LL), MK_INT(0LL), v_t_2477));
                v_t_24114 = heff_bool(!heff_intLt_c_lent(MK_INT(150LL), v_x_2478, 1));
                heff_drop(v_x_2478);
              } else {
                heff_drop(v_b_2467);
                heff_drop(v_t_2476);
                v_t_24114 = NTAG(TAG_False);
              }
            } else {
              heff_drop(v_n_2461);
              heff_drop(v_b_2467);
              heff_drop_cell(v_ru_24t_2463_24ELam, 2);
              heff_drop(v_x1_2474);
              v_t_24114 = NTAG(TAG_False);
            }
          }
        }
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_t_2463, 0ULL, 2);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_t_2463, 0ULL, 3);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_t_2463, 0ULL, 2);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_t_2463, 0ULL, 4);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_t_2463, 0ULL, 3);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_t_2463, 0ULL, 2);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_t_2463, 0ULL, 2);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_t_2463, 0ULL, 2);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_t_2463, 0ULL, 2);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_t_2463, 0ULL, 3);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_t_2463, 0ULL, 1);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_t_2463, 0ULL, 2);
        heff_drop(v_tuples_2458);
        heff_drop(v_n_2461);
        heff_drop_rec(v_d_2462, 3);
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2463);
      }
      if ((heff_dup(v_t_24114) == NTAG(TAG_True))) {
        heff_drop(v_t_24114);
        V v_t_24117;
        switch (heff_tag_of(v_s_2450)) {
        case TAG_MkPair: {
          V v_x_24115 = heff_dup(heff_field(v_s_2450, 0));
          v_t_24117 = v_x_24115;
          break;
        }
        default: heff_nomatch(v_s_2450);
        }
        V v_t_24120;
        switch (heff_tag_of(v_s_2450)) {
        case TAG_MkPair: {
          V v_y_24119 = heff_dup(heff_field(v_s_2450, 1));
          v_t_24120 = v_y_24119;
          break;
        }
        default: heff_nomatch(v_s_2450);
        }
        V v_t_24121 = heff_strAppend(heff_strAppend(v_t_24117, ((V)&g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_str0)), heff_intShow(v_t_24120));
        V v_t_24124;
        switch (heff_tag_of(v_s_2450)) {
        case TAG_MkPair: {
          V v_y_24123 = heff_field(v_s_2450, 1);
          heff_take_n(v_s_2450, 2ULL, 2);
          v_t_24124 = v_y_24123;
          break;
        }
        default: heff_nomatch(v_s_2450);
        }
        return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2449, v_t_24121, heff_tag_n(TAG_MkPair, 2, (V[]){v_d_2457, v_t_24124})));
      } else {
        heff_drop(v_s_2450);
        heff_drop(v_d_2457);
        heff_drop(v_t_24114);
        return v_m_2449;
      }
    } else {
      heff_drop(v_s_2450);
      heff_drop(v_tuples_2445);
      heff_drop(v_field_2456);
      return v_m_2449;
    }
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam2(V self, V *args) {
  V v_m_24156 = args[0];
  V v_d_24157 = args[1];
  V v_ar_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_24158 = heff_take_field(v_d_24157, 0);
  V v_body_24159 = heff_get_n(v_d_24157, 2, 3);
  V v_t_24160 = heff_tag_n(TAG_Cons, 2, (V[]){v_body_24159, NTAG(TAG_Nil)});
  V v_t_24161 = (g_heff_2ecompile_2eranges_2escanW(v_ar_24155, heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get()), v_t_24160));
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_24156, v_key_24158, v_t_24161));
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam3(V self, V *args) {
  V v_acc_24175 = args[0];
  V v_x3_24176 = args[1];
  V v_fns_24169 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24176)) {
  case TAG_MkPair: {
    V v_k_24177 = heff_field(v_x3_24176, 0);
    V v_x32_24178 = heff_field(v_x3_24176, 1);
    heff_take_n(v_x3_24176, 3ULL, 2);
    switch (heff_tag_of(v_x32_24178)) {
    case TAG_Nil: {
      heff_drop(v_fns_24169);
      heff_drop(v_k_24177);
      return v_acc_24175;
    }
    case TAG_Cons: {
      heff_take_n(v_x32_24178, 0ULL, 2);
      HeffT2 v_t_24181 = ({ V a_0 = v_fns_24169; V a_1 = v_k_24177; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_fns_24169); r_; });
      {
        V v_field_24183 = v_t_24181.f[1];
        int64_t v_tag_24182 = ((int64_t)v_t_24181.f[0]);
        if ((v_tag_24182 == ((int64_t)0ULL))) {
          V v_fn_24184 = v_field_24183;
          V v_t_24185 = (g_list_2emap_24s1792553290x233563724(heff_get_n(v_fn_24184, 0, 3)));
          return (g_std_2eordmap_2einsert_24s615484302x989744458(v_acc_24175, v_k_24177, v_t_24185));
        } else {
          heff_drop(v_k_24177);
          heff_drop(v_field_24183);
          return v_acc_24175;
        }
      }
    }
    default: return heff_nomatch(v_x32_24178);
    }
  }
  default: return heff_nomatch(v_x3_24176);
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam5(V self, V *args) {
  V v_m_24205 = args[0];
  V v_g_24206 = args[1];
  V v_params_24192 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24207 = ({ V a_0 = v_params_24192; V a_1 = v_g_24206; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_params_24192); r_; });
  {
    V v_field_24209 = v_t_24207.f[1];
    int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
    if ((v_tag_24208 == ((int64_t)0ULL))) {
      V v_x_24210 = v_field_24209;
      heff_drop(v_x_24210);
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_24205, v_g_24206, NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_g_24206);
      heff_drop(v_field_24209);
      return v_m_24205;
    }
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam6(V self, V *args) {
  V v_m_24220 = args[0];
  V v_g_24221 = args[1];
  V v_d_24203 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24222 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_24220, v_g_24221));
  V v_t_24226;
  {
    V v_field_24224 = v_t_24222.f[1];
    int64_t v_tag_24223 = ((int64_t)v_t_24222.f[0]);
    if ((v_tag_24223 == ((int64_t)0ULL))) {
      V v_x_24225 = v_field_24224;
      v_t_24226 = v_x_24225;
    } else {
      heff_drop(v_field_24224);
      v_t_24226 = NTAG(TAG_Nil);
    }
  }
  V v_t_24227 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_d_24203, 0, 3), v_t_24226});
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_24220, v_g_24221, v_t_24227));
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam4(V self, V *args) {
  V v_sc_24190 = args[0];
  V v_d_24191 = args[1];
  V v_params_24186 = heff_env(self)[0];
  V v_scans_24168 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_params_24192 = v_params_24186;
  V v_sc_24193 = v_sc_24190;
  V v_d_24194 = heff_dup(v_d_24191);
  HeffT2 v_t_24195 = ({ V a_0 = v_scans_24168; V b_1 = heff_get_n(v_d_24191, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_scans_24168); heff_drop(b_1); r_; });
  V v_s_24199;
  {
    V v_field_24197 = v_t_24195.f[1];
    int64_t v_tag_24196 = ((int64_t)v_t_24195.f[0]);
    if ((v_tag_24196 == ((int64_t)0ULL))) {
      V v_x_24198 = v_field_24197;
      v_s_24199 = v_x_24198;
    } else {
      heff_drop(v_field_24197);
      v_s_24199 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get());
    }
  }
  V v_ints_24200 = heff_take_field(v_s_24199, 3);
  V v_calls_24201 = heff_get_n(v_s_24199, 2, 5);
  V v_sc_24202 = v_sc_24193;
  V v_d_24203 = v_d_24194;
  V v_ints_24204 = v_ints_24200;
  V v_m_24211 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam5, 2, 1, (V[]){v_params_24192}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_calls_24201; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_calls_24201); r_; });
  V v_t_24212 = ({ V a_0 = v_m_24211; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_24211); r_; });
  V v_gs_24213 = (g_list_2emap_24s1937570095x2110149801(v_t_24212));
  switch (heff_tag_of(v_gs_24213)) {
  case TAG_Nil: {
    V v_t_24214 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_sc_24202, 0), heff_dup(heff_rfield(v_d_24203, 0)), heff_dup(v_d_24203)));
    V v_t_24215;
    if ((heff_dup(v_ints_24204) == NTAG(TAG_True))) {
      heff_drop(v_ints_24204);
      v_t_24215 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_sc_24202, 3)), heff_get_n(v_d_24203, 0, 3), NTAG(TAG_MkUnit)));
    } else {
      heff_drop_rec(v_d_24203, 3);
      heff_drop(v_ints_24204);
      v_t_24215 = heff_dup(heff_rfield(v_sc_24202, 3));
    }
    return ({ V rv_0 = v_t_24214; V rv_3 = v_t_24215; V rr_ = heff_rec_reuse_nf(v_sc_24202, 6ULL, 4, shape_byKey__callers__callersOf__ints, 60u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  case TAG_Cons: {
    V v_t_24218 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_sc_24202, 0), heff_dup(heff_rfield(v_d_24203, 0)), heff_dup(v_d_24203)));
    V v_t_24219 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_sc_24202, 1), heff_dup(heff_rfield(v_d_24203, 0)), heff_dup(v_gs_24213)));
    V v_t_24228 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam6, 2, 1, (V[]){heff_dup(v_d_24203)}); V a_1 = heff_take_field(v_sc_24202, 2); V a_2 = v_gs_24213; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop_tag(v_gs_24213, 2); r_; });
    V v_t_24229;
    if ((heff_dup(v_ints_24204) == NTAG(TAG_True))) {
      heff_drop(v_ints_24204);
      v_t_24229 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_get_n(v_sc_24202, 3, 4), heff_get_n(v_d_24203, 0, 3), NTAG(TAG_MkUnit)));
    } else {
      heff_drop_rec(v_d_24203, 3);
      heff_drop(v_ints_24204);
      v_t_24229 = heff_get_n(v_sc_24202, 3, 4);
    }
    return heff_rec_n(4, shape_byKey__callers__callersOf__ints, (V[]){v_t_24218, v_t_24219, v_t_24228, v_t_24229});
  }
  default: return heff_nomatch(v_gs_24213);
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam7(V self, V *args) {
  V v_k_24236 = args[0];
  V v_params_24189 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24237 = ({ V a_0 = v_params_24189; V a_1 = v_k_24236; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_params_24189); heff_drop(v_k_24236); r_; });
  {
    V v_field_24239 = v_t_24237.f[1];
    int64_t v_tag_24238 = ((int64_t)v_t_24237.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24238 == ((int64_t)0ULL)) ? ({ V v_x_24240 = heff_dup(v_field_24239); int c_ = 0; heff_drop(v_x_24240); c_; }) : 1));
    heff_drop(v_field_24239);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam8(V self, V *args) {
  V v_d_24257 = args[0];
  V v_sc_24250 = heff_env(self)[0];
  V v_params_24256 = heff_env(self)[1];
  V v_consts_24249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_24258 = ({ V b_0 = heff_get_n(v_sc_24250, 3, 4); V a_1 = heff_rfield(v_d_24257, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_24260 = v_t_24258.f[1];
    int64_t v_tag_24259 = ((int64_t)v_t_24258.f[0]);
    if ((v_tag_24259 == ((int64_t)0ULL))) {
      V v_x_24261 = v_field_24260;
      heff_drop(v_x_24261);
      V v_c_24262 = heff_rec_n(3, shape_params__consts__marking, (V[]){v_params_24256, v_consts_24249, NTAG(TAG_False)});
      V v_d_24263 = heff_dup(v_d_24257);
      V v_body_24264 = heff_take_field(v_d_24263, 2);
      V v_key_24265 = heff_get_n(v_d_24263, 0, 3);
      V v_body_24285;
      switch (heff_tag_of(v_body_24264)) {
      case TAG_ELam: {
        V v_xs_24266 = heff_field(v_body_24264, 0);
        V v_b_24267 = heff_field(v_body_24264, 1);
        V v_ru_24body_24264_24ELam = heff_take_reuse_n(v_body_24264, 3ULL, 2);
        HeffT2 v_t_24268 = ({ V a_0 = heff_rfield(v_c_24262, 0); V a_1 = v_key_24265; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_key_24265); r_; });
        V v_t_24273;
        {
          V v_field_24270 = v_t_24268.f[1];
          int64_t v_tag_24269 = ((int64_t)v_t_24268.f[0]);
          if ((v_tag_24269 == ((int64_t)0ULL))) {
            V v_rs_24271 = v_field_24270;
            V v_t_24272 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_24266), v_rs_24271));
            v_t_24273 = ({ V a_0 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()); V a_1 = v_t_24272; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_24272); r_; });
          } else {
            heff_drop(v_field_24270);
            v_t_24273 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get());
          }
        }
        V v_x1_24274 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_24262, v_t_24273, v_b_24267));
        V v_t_24279;
        switch (heff_tag_of(v_x1_24274)) {
        case TAG_MkRes: {
          V v_e_24276 = heff_field(v_x1_24274, 1);
          heff_take_n(v_x1_24274, 2ULL, 2);
          v_t_24279 = v_e_24276;
          break;
        }
        case TAG_MkResVals: {
          V v_e_24278 = heff_field(v_x1_24274, 1);
          heff_take_n(v_x1_24274, 2ULL, 2);
          v_t_24279 = v_e_24278;
          break;
        }
        default: heff_nomatch(v_x1_24274);
        }
        v_body_24285 = heff_tag_at_n(v_ru_24body_24264_24ELam, TAG_ELam, 2, (V[]){v_xs_24266, v_t_24279});
        break;
      }
      default: {
        heff_drop(v_key_24265);
        V v_x1_24280 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_24262, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), v_body_24264));
        switch (heff_tag_of(v_x1_24280)) {
        case TAG_MkRes: {
          V v_e_24282 = heff_field(v_x1_24280, 1);
          heff_take_n(v_x1_24280, 2ULL, 2);
          v_body_24285 = v_e_24282;
          break;
        }
        case TAG_MkResVals: {
          V v_e_24284 = heff_field(v_x1_24280, 1);
          heff_take_n(v_x1_24280, 2ULL, 2);
          v_body_24285 = v_e_24284;
          break;
        }
        default: heff_nomatch(v_x1_24280);
        }
        break;
      }
      }
      return ({ V rv_2 = v_body_24285; V rr_ = heff_rec_reuse_nf(v_d_24257, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      heff_drop(v_params_24256);
      heff_drop(v_consts_24249);
      heff_drop(v_field_24260);
      return v_d_24257;
    }
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_lam9(V self, V *args) {
  V v_p_24298 = args[0];
  V v_tk_24293 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24301;
  switch (heff_tag_of(v_p_24298)) {
  case TAG_MkPair: {
    V v_x_24299 = heff_dup(heff_field(v_p_24298, 0));
    v_t_24301 = v_x_24299;
    break;
  }
  default: heff_nomatch(v_p_24298);
  }
  HeffT2 v_t_24302 = ({ V b_0 = heff_get_n(v_tk_24293, 1, 2); V a_1 = v_t_24301; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24301); r_; });
  {
    V v_field_24304 = v_t_24302.f[1];
    int64_t v_tag_24303 = ((int64_t)v_t_24302.f[0]);
    if ((v_tag_24303 == ((int64_t)0ULL))) {
      V v_x_24305 = v_field_24304;
      heff_drop(v_x_24305);
      V v_t_24308;
      switch (heff_tag_of(v_p_24298)) {
      case TAG_MkPair: {
        V v_x_24306 = heff_dup(heff_field(v_p_24298, 0));
        v_t_24308 = v_x_24306;
        break;
      }
      default: heff_nomatch(v_p_24298);
      }
      V v_t_24311;
      switch (heff_tag_of(v_p_24298)) {
      case TAG_MkPair: {
        V v_y_24310 = heff_field(v_p_24298, 1);
        heff_take_n(v_p_24298, 2ULL, 2);
        v_t_24311 = v_y_24310;
        break;
      }
      default: heff_nomatch(v_p_24298);
      }
      V v_t_24312 = (g_list_2ekeepIf_24s512765522x2052101617(MK_INT(0LL), v_t_24311));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24308, v_t_24312});
    } else {
      heff_drop(v_field_24304);
      return v_p_24298;
    }
  }
}
Clo g_heff_2ecompile_2elower_2efindDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efindDef_entry, 2, 0};

V g_heff_2ecompile_2elower_2efindDef(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_ds_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_d_242, 0)), heff_dup(v_k_240))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_d_242)});
    } else {
      V t_0 = v_k_240;
      V t_1 = v_ds_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2elower_2efindDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2elower_2efindDef(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2elower_2eredoErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eredoErased_entry, 4, 0};

V g_heff_2ecompile_2elower_2eredoErased(V v_k_240, V v_uk_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    heff_drop(v_k_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_242});
  }
  case TAG_Right: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    heff_drop(v_n_242);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_body_246 = heff_field(v_x41_245, 0);
      V v_n2_247 = heff_field(v_x41_245, 1);
      HeffT2 v_t_248 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), heff_dup(v_body_246)}), heff_dup(v_body_246)));
      V v_t_2413;
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_b_2411 = v_field_249;
        V v_acc_2412 = v_field_2410;
        v_t_2413 = (g_heff_2ecompile_2elift_2eordered(heff_get_n(v_acc_2412, 0, 2), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), v_k_240, v_b_2411})));
      }
      V v_t_2414 = ({ V a_0 = v_uk_241; V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2elower_2efindDef(a_0, a_1)); heff_drop(v_t_2413); r_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, heff_dup(v_n2_247)});
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2elower_2eredoErased(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2elower_2eentryKept_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eentryKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryKept_entry, 2, 0};

V g_heff_2ecompile_2elower_2eentryKept(V v_key_240, V v_u_241) {
top: ;
  V v_def_242 = heff_take_field(v_u_241, 0);
  V v_refs_243 = heff_get_n(v_u_241, 1, 2);
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(heff_rfield(v_def_242, 0)), heff_dup(heff_rfield(v_def_242, 1)), heff_tag_n(TAG_Kept, 2, (V[]){v_def_242, heff_clo_n(g_heff_2ecompile_2elower_2eentryKept_lam0, 1, 1, (V[]){v_key_240})}), v_refs_243});
}
V g_heff_2ecompile_2elower_2eentryKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eentryKept(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2eentryKept_lam0(V self, V *args) {
  V v_m_244 = args[0];
  V v_key_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_body_245 = (g_heff_2ecompile_2elower_2eentryBody(v_key_240, heff_dup(v_m_244)));
  V v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_245})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_m_244, MK_INT(11LL))});
}

HeffT2 g_heff_2ecompile_2elower_2eunitOut_24cpr(V v_sg_240, V v_dm_241, V v_p_242) {
top: ;
  V v_key_243 = heff_take_field(v_p_242, 1);
  V v_name_244 = heff_take_field(v_p_242, 2);
  V v_refs_245 = heff_get_n(v_p_242, 4, 5);
  V v_safe_246 = heff_take_field(v_sg_240, 0);
  V v_total_247 = heff_get_n(v_sg_240, 1, 2);
  HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_dm_241, v_key_243));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_d_2411 = v_field_2410;
      HeffT2 v_t_2412 = ({ V a_0 = v_safe_246; V a_1 = v_key_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_safe_246); r_; });
      V v_t_2416;
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        v_t_2416 = heff_bool(((v_tag_2413 == ((int64_t)0ULL)) && ({ V v_x_2415 = heff_dup(v_field_2414); int c_ = 1; heff_drop(v_x_2415); c_; })));
        heff_drop(v_field_2414);
      }
      HeffT2 v_t_2417 = ({ V a_0 = v_total_247; V a_1 = v_key_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_total_247); heff_drop(v_key_243); r_; });
      V v_t_2421;
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_x_2420 = v_field_2419;
          v_t_2421 = v_x_2420;
        } else {
          heff_drop(v_field_2419);
          v_t_2421 = MK_INT(-1LL);
        }
      }
      V v_f_2422 = heff_rec_n(5, shape_done__name__refs__sgSafe__sgTotal, (V[]){v_d_2411, v_name_244, v_refs_245, v_t_2416, v_t_2421});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
    } else {
      heff_drop(v_key_243);
      heff_drop(v_name_244);
      heff_drop(v_refs_245);
      heff_drop(v_safe_246);
      heff_drop(v_total_247);
      heff_drop(v_field_2410);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ecompile_2elower_2egroupGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2egroupGo_entry, 1, 0};

V g_heff_2ecompile_2elower_2egroupGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_ps_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_p_243 = v_p_241;
    V v_gs_244 = (g_heff_2ecompile_2elower_2egroupGo(v_ps_242));
    switch (heff_tag_of(v_gs_244)) {
    case TAG_Nil: {
      V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_gs_244});
    }
    case TAG_Cons: {
      V v_gs1_246 = heff_dup(heff_field(v_gs_244, 0));
      switch (heff_tag_of(v_gs1_246)) {
      case TAG_Nil: {
        V v_t_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_gs_244});
      }
      case TAG_Cons: {
        V v_q_249 = heff_field(v_gs1_246, 0);
        V v_qs_2410 = heff_field(v_gs1_246, 1);
        V v_ru_24gs1_246_24Cons = heff_take_reuse_n(v_gs1_246, 3ULL, 2);
        switch (heff_tag_of(v_gs_244)) {
        case TAG_Cons: {
          V v_rest_2412 = heff_field(v_gs_244, 1);
          V v_ru_24gs_244_24Cons = heff_take_reuse_n(v_gs_244, 2ULL, 2);
          if (heff_strEq_c(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_q_249, 0)))) {
            V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, heff_tag_at_n(v_ru_24gs1_246_24Cons, TAG_Cons, 2, (V[]){v_q_249, v_qs_2410})});
            return heff_tag_at_n(v_ru_24gs_244_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_rest_2412});
          } else {
            V v_t_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, NTAG(TAG_Nil)});
            V v_t_2415 = heff_tag_at_n(v_ru_24gs1_246_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24gs_244_24Cons, TAG_Cons, 2, (V[]){v_q_249, v_qs_2410}), v_rest_2412});
            return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2415});
          }
        }
        default: return heff_nomatch(v_gs_244);
        }
      }
      default: return heff_nomatch(v_gs1_246);
      }
    }
    default: return heff_nomatch(v_gs_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2egroupGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2egroupGo(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str5, 0, "");
V g_heff_2ecompile_2elower_2egroupOut_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam4(V self, V *args);
Clo g_heff_2ecompile_2elower_2egroupOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2egroupOut_entry, 4, 0};

V g_heff_2ecompile_2elower_2egroupOut(V v_vers_240, V v_sg_241, V v_dm_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sg_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ps_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_240, heff_rfield(v_p_244, 0)));
    V v_t_2410;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_248);
        v_t_2410 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str0);
      }
    }
    if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ecompile_2elower_2egroupOut_str1))) {
      heff_drop(v_sg_241);
      heff_drop_rec(v_p_244, 5);
      heff_drop(v_ps_245);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    } else {
      HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_dm_242, heff_rfield(v_p_244, 1)));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2413;
          heff_drop(v_x_2414);
          V v_p_2421 = heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam0, 1, 2, (V[]){heff_dup(v_sg_241), heff_dup(v_dm_242)});
          V v_t_2422 = heff_tr(heff_call(heff_dup(v_p_2421), 1, (V[]){heff_dup(v_p_244)}));
          if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
            heff_drop(v_t_2422);
            V v_x1_2423 = (g_list_2eall(v_p_2421, v_ps_245));
            if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
              heff_drop(v_sg_241);
              heff_drop_rec(v_p_244, 5);
              heff_drop(v_ps_245);
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              heff_drop(v_x1_2423);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_x1_2423);
              HeffT2 v_t_2424 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_240, heff_rfield(v_p_244, 0)));
              V v_t_2428;
              {
                V v_field_2426 = v_t_2424.f[1];
                int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
                if ((v_tag_2425 == ((int64_t)0ULL))) {
                  V v_x_2427 = v_field_2426;
                  v_t_2428 = v_x_2427;
                } else {
                  heff_drop(v_field_2426);
                  v_t_2428 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str3);
                }
              }
              V v_t_2429 = (g_heff_2ecompile_2elower_2eunitOut(heff_dup(v_sg_241), v_dm_242, heff_dup(v_p_244)));
              V v_t_2430 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_p_244, 1)), v_t_2429});
              V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam1, 1, 2, (V[]){v_sg_241, heff_dup(v_dm_242)}), v_ps_245));
              V v_t_2434 = heff_rec_n(3, shape_owner__ver__units, (V[]){heff_get_n(v_p_244, 0, 5), v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_t_2433})});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2434});
            }
          } else {
            heff_drop(v_sg_241);
            heff_drop_rec(v_p_244, 5);
            heff_drop(v_ps_245);
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            heff_drop_clo(v_p_2421, 2);
            heff_drop(v_t_2422);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_field_2413);
          V v_x1_2440 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam2, 1, 1, (V[]){heff_dup(v_dm_242)}), v_ps_245));
          if (!(heff_dup(v_x1_2440) == NTAG(TAG_True))) {
            heff_drop(v_sg_241);
            heff_drop_rec(v_p_244, 5);
            heff_drop(v_ps_245);
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            heff_drop(v_x1_2440);
            return NTAG(TAG_Nothing);
          } else {
            heff_drop(v_x1_2440);
            V v_p_2447 = heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam3, 1, 2, (V[]){heff_dup(v_sg_241), heff_dup(v_dm_242)});
            V v_t_2448 = heff_tr(heff_call(heff_dup(v_p_2447), 1, (V[]){heff_dup(v_p_244)}));
            if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
              heff_drop(v_t_2448);
              V v_x1_2449 = (g_list_2eall(v_p_2447, v_ps_245));
              if (!(heff_dup(v_x1_2449) == NTAG(TAG_True))) {
                heff_drop(v_sg_241);
                heff_drop_rec(v_p_244, 5);
                heff_drop(v_ps_245);
                heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                heff_drop(v_x1_2449);
                return NTAG(TAG_Nothing);
              } else {
                heff_drop(v_x1_2449);
                HeffT2 v_t_2450 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_240, heff_rfield(v_p_244, 0)));
                V v_t_2454;
                {
                  V v_field_2452 = v_t_2450.f[1];
                  int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                  if ((v_tag_2451 == ((int64_t)0ULL))) {
                    V v_x_2453 = v_field_2452;
                    v_t_2454 = v_x_2453;
                  } else {
                    heff_drop(v_field_2452);
                    v_t_2454 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str5);
                  }
                }
                V v_t_2455 = (g_heff_2ecompile_2elower_2eunitOut(heff_dup(v_sg_241), v_dm_242, heff_dup(v_p_244)));
                V v_t_2456 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_p_244, 1)), v_t_2455});
                V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam4, 1, 2, (V[]){v_sg_241, heff_dup(v_dm_242)}), v_ps_245));
                V v_t_2460 = heff_rec_n(3, shape_owner__ver__units, (V[]){heff_get_n(v_p_244, 0, 5), v_t_2454, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, v_t_2459})});
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2460});
              }
            } else {
              heff_drop(v_sg_241);
              heff_drop_rec(v_p_244, 5);
              heff_drop(v_ps_245);
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              heff_drop_clo(v_p_2447, 2);
              heff_drop(v_t_2448);
              return NTAG(TAG_Nothing);
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2elower_2egroupOut(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2elower_2egroupOut_lam0(V self, V *args) {
  V v_q_2415 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = v_q_2415; HeffT2 r_ = (g_heff_2ecompile_2elower_2eunitOut_24cpr(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_u_2419 = v_field_2418;
      V v_t_2420 = heff_get_n(heff_get_n(v_u_2419, 0, 5), 3, 4);
      return ({ V b_0 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str2); V a_1 = v_t_2420; V r_ = (g_list_2eall_24s44244667x1445755514(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2420); r_; });
    } else {
      heff_drop(v_field_2418);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam1(V self, V *args) {
  V v_q_2431 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = heff_dup(v_q_2431); V r_ = (g_heff_2ecompile_2elower_2eunitOut(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_q_2431, 1, 5), v_t_2432});
}
V g_heff_2ecompile_2elower_2egroupOut_lam2(V self, V *args) {
  V v_q_2435 = args[0];
  V v_dm_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2436 = ({ V a_0 = v_dm_242; V b_1 = heff_get_n(v_q_2435, 1, 5); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_dm_242); heff_drop(b_1); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2437 == ((int64_t)0ULL)) && ({ V v_x_2439 = heff_dup(v_field_2438); int c_ = 1; heff_drop(v_x_2439); c_; })));
    heff_drop(v_field_2438);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam3(V self, V *args) {
  V v_q_2441 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2442 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = v_q_2441; HeffT2 r_ = (g_heff_2ecompile_2elower_2eunitOut_24cpr(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_u_2445 = v_field_2444;
      V v_t_2446 = heff_get_n(heff_get_n(v_u_2445, 0, 5), 3, 4);
      return ({ V b_0 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str4); V a_1 = v_t_2446; V r_ = (g_list_2eall_24s44244667x1445755514(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2446); r_; });
    } else {
      heff_drop(v_field_2444);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam4(V self, V *args) {
  V v_q_2457 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2458 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = heff_dup(v_q_2457); V r_ = (g_heff_2ecompile_2elower_2eunitOut(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_q_2457, 1, 5), v_t_2458});
}
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str2, 6, "entry/");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str5, 0, "");
V g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_lam0(V self, V *args);

HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V v_g_240, V v_key_241, V v_vers_242, V v_ks_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_242, v_key_241));
  V v_t_248;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_v_247 = v_field_246;
      if (heff_strEq_c_lent(v_v_247, ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str0), 2)) {
        heff_drop(v_v_247);
        v_t_248 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str1);
      } else {
        v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str2), v_v_247);
      }
    } else {
      heff_drop(v_field_246);
      v_t_248 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str3);
    }
  }
  V v_vers_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(v_vers_242), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_248));
  V v_ks_2410 = heff_dup(v_ks_243);
  V v_key_2411 = v_key_241;
  V v_t_2412 = heff_rec_n(3, shape_pieces__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2419 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
  V v_acc_2420 = ({ V a_0 = v_g_240; V a_1 = v_vers_242; V a_2 = v_ks_243; V a_3 = v_t_2412; V a_4 = v_t_2419; V r_ = (g_list_2efoldl_24s1579438642x567671990(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_vers_242); heff_drop(v_t_2419); r_; });
  V v_errors_2421 = heff_take_field(v_acc_2420, 1);
  V v_supply_2422 = heff_take_field(v_acc_2420, 2);
  V v_pieces_2423 = heff_get_n(v_acc_2420, 0, 3);
  V v_errors_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_errors_2421));
  V v_vers_2425 = heff_dup(v_vers_249);
  V v_ks_2426 = heff_dup(v_ks_2410);
  V v_key_2427 = v_key_2411;
  V v_n_2428 = heff_dup(v_supply_2422);
  HeffT2 v_t_2429 = ({ V b_0 = heff_get_n(v_ks_2426, 0, 2); V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2448;
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_it1_2432 = v_field_2431;
      switch (heff_tag_of(v_it1_2432)) {
      case TAG_MkPair: {
        V v_v_2433 = heff_field(v_it1_2432, 0);
        V v_us_2434 = heff_field(v_it1_2432, 1);
        V v_ru_24it1_2432_24MkPair = heff_take_reuse_n(v_it1_2432, 3ULL, 2);
        V v_t_2468;
        if (heff_strEq_c_lent(v_v_2433, ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str4), 2)) {
          heff_drop(v_vers_2425);
          heff_drop(v_v_2433);
          v_t_2468 = NTAG(TAG_False);
        } else {
          HeffT2 v_t_2435 = ({ V a_0 = v_vers_2425; V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_vers_2425); heff_drop(b_1); r_; });
          V v_t_2471;
          {
            V v_field_2437 = v_t_2435.f[1];
            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
            if ((v_tag_2436 == ((int64_t)0ULL))) {
              V v_x_2438 = v_field_2437;
              v_t_2471 = v_x_2438;
            } else {
              heff_drop(v_field_2437);
              v_t_2471 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str5);
            }
          }
          v_t_2468 = heff_strEq(v_v_2433, v_t_2471);
        }
        switch (heff_tag_of(v_t_2468)) {
        case TAG_True: {
          heff_drop(v_n_2428);
          heff_drop_cell(v_ru_24it1_2432_24MkPair, 2);
          V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2eentryKept_clo), 1, (V[]){v_key_2427}));
          v_t_2448 = (g_list_2emap(v_t_2439, v_us_2434));
          break;
        }
        case TAG_False: {
          heff_drop(v_us_2434);
          V v_body_2440 = (g_heff_2ecompile_2elower_2eentryBody(v_key_2427, v_n_2428));
          V v_t_2441 = heff_tag_n(TAG_Fresh, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(v_body_2440)})});
          V v_t_2442 = (g_heff_2ecompile_2eir_2eglobalsGo(v_body_2440));
          V v_t_2443 = (g_heff_2ecompile_2eir_2enubI(v_t_2442));
          v_t_2448 = heff_tag_at_n(v_ru_24it1_2432_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2441, v_t_2443}), NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2468);
        }
        break;
      }
      default: heff_nomatch(v_it1_2432);
      }
    } else {
      heff_drop(v_vers_2425);
      heff_drop(v_field_2431);
      V v_body_2444 = (g_heff_2ecompile_2elower_2eentryBody(v_key_2427, v_n_2428));
      V v_t_2445 = heff_tag_n(TAG_Fresh, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(v_body_2444)})});
      V v_t_2446 = (g_heff_2ecompile_2eir_2eglobalsGo(v_body_2444));
      V v_t_2447 = (g_heff_2ecompile_2eir_2enubI(v_t_2446));
      v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2445, v_t_2447}), NTAG(TAG_Nil)});
    }
  }
  V v_xs_2449 = (g_heff_2ecompile_2elower_2erevOnto(v_t_2448, v_pieces_2423));
  V v_t_2450 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2449));
  V v_ps_2451 = (g_heff_2ecompile_2elower_2ereachedPieces(v_t_2450));
  V v_errors_2452 = v_errors_2424;
  V v_vers_2453 = v_vers_249;
  V v_ks_2454 = v_ks_2410;
  V v_n_2455 = heff_intAdd(v_supply_2422, MK_INT(11LL));
  V v_ps_2456 = heff_dup(v_ps_2451);
  V v_items_2457 = (g_list_2emap_24s510639937x1058700299(v_ps_2451));
  V v_sg_2458 = ({ V a_0 = heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())}); V a_1 = v_items_2457; V r_ = (g_list_2efoldl_24s2070597502x591087275(a_0, a_1)); heff_drop(v_items_2457); r_; });
  V v_t_2459 = (g_heff_2ecompile_2elower_2eunitVers(v_vers_2453, v_ps_2456));
  V v_t_2460 = (g_list_2emap_24s510639937x1058700299(heff_dup(v_ps_2456)));
  V v_si_2461 = (g_heff_2ecompile_2esimplify_2esimplifyItems(v_n_2455, heff_dup(v_sg_2458), v_t_2459, heff_get_n(v_ks_2454, 1, 2), v_t_2460));
  V v_t_2462 = (g_list_2efoldl_24s1499934538x170225690(heff_dup(g_std_2eordmap_2eempty_get()), heff_rfield(v_si_2461, 2)));
  V v_t_2463 = (g_heff_2ecompile_2elower_2egroupGo(v_ps_2456));
  V v_t_2464 = ({ V a_0 = v_vers_2453; V a_1 = v_sg_2458; V a_2 = v_t_2462; V a_3 = v_t_2463; V r_ = (g_list_2emap_24s1985010810x1780722131(a_0, a_1, a_2, a_3)); heff_drop(v_vers_2453); heff_drop(v_t_2462); r_; });
  V v_f_2465 = (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2464));
  V v_f_2466 = heff_dup(heff_rfield(v_si_2461, 3));
  return ((HeffT4){{v_si_2461, v_errors_2452, v_f_2465, v_f_2466}});
}
V g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_lam0(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_k_2414 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_e_2418 = v_field_2417;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2414, v_e_2418}), v_acc_2413});
    } else {
      heff_drop(v_k_2414);
      heff_drop(v_field_2417);
      return v_acc_2413;
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str1, 0, "");
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_entry, 4, 0};

V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(V v_g_240, V v_vers_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_k_244 = heff_field(v_x5_243, 0);
    V v_e_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_245, 3))));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_k_244);
      heff_drop_rec(v_e_245, 4);
      heff_drop_cell(v_ru_24x5_243_24MkPair, 2);
      heff_drop(v_t_246);
      return v_acc_242;
    } else {
      heff_drop(v_t_246);
      HeffT2 v_t_247 = ({ V b_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_k_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_it1_2410 = v_field_249;
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_MkPair: {
            V v_v_2411 = heff_field(v_it1_2410, 0);
            V v_us_2412 = heff_field(v_it1_2410, 1);
            heff_take_n(v_it1_2410, 3ULL, 2);
            V v_t_2426;
            if (heff_strEq_c_lent(v_v_2411, ((V)&g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str0), 2)) {
              heff_drop(v_v_2411);
              v_t_2426 = NTAG(TAG_False);
            } else {
              HeffT2 v_t_2413 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_241, v_k_244));
              V v_t_2429;
              {
                V v_field_2415 = v_t_2413.f[1];
                int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  V v_x_2416 = v_field_2415;
                  v_t_2429 = v_x_2416;
                } else {
                  heff_drop(v_field_2415);
                  v_t_2429 = ((V)&g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str1);
                }
              }
              v_t_2426 = heff_strEq(v_v_2411, v_t_2429);
            }
            switch (heff_tag_of(v_t_2426)) {
            case TAG_True: {
              heff_drop_cell(v_ru_24x5_243_24MkPair, 2);
              V v_t_2422 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_242, 0), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam0, 1, 3, (V[]){v_k_244, v_g_240, v_e_245}), v_us_2412));
              return ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_acc_242, 6ULL, 3, shape_pieces__errors__supply, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            }
            case TAG_False: {
              heff_drop(v_us_2412);
              V v_t_2423 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_244), v_e_245, heff_dup(heff_rfield(v_acc_242, 2))));
              HEFF_LAST return g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_243_24MkPair, v_k_244, v_acc_242, v_t_2423);
            }
            default: return heff_nomatch(v_t_2426);
            }
          }
          default: return heff_nomatch(v_it1_2410);
          }
        } else {
          heff_drop(v_field_249);
          V v_t_2424 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_244), v_e_245, heff_dup(heff_rfield(v_acc_242, 2))));
          HEFF_LAST return g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_243_24MkPair, v_k_244, v_acc_242, v_t_2424);
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam1(V self, V *args) {
  V v_n_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_e_245 = heff_env(self)[2];
  V v_def_2418 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_244), v_e_245, heff_dup(v_n_2420)));
  return ({ V a_0 = v_k_244; V b_1 = heff_get_n(v_def_2418, 0, 7); V a_2 = v_n_2420; V a_3 = v_t_2421; V r_ = (g_heff_2ecompile_2elower_2eredoErased(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_t_2421); r_; });
}
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_e_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_def_2418 = heff_take_field(v_u_2417, 0);
  V v_refs_2419 = heff_get_n(v_u_2417, 1, 2);
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(v_k_244), heff_dup(heff_rfield(v_def_2418, 0)), heff_dup(heff_rfield(v_def_2418, 1)), heff_tag_n(TAG_Kept, 2, (V[]){heff_dup(v_def_2418), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam1, 1, 4, (V[]){v_g_240, v_k_244, v_e_245, v_def_2418})}), v_refs_2419});
}
HEFF_LIT(g_heff_2ecompile_2elower_2eerasedPieces_24tok2_str0, 2, ": ");
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eerasedPieces_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry, 4, 0};

V g_heff_2ecompile_2elower_2eerasedPieces_24tok2(V v_tok_240, V v_k_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Left: {
    V v_err_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    V v_t_245 = heff_strAppend(heff_strAppend(v_k_241, ((V)&g_heff_2ecompile_2elower_2eerasedPieces_24tok2_str0)), v_err_244);
    V v_t_246 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_245, heff_dup(heff_rfield(v_acc_242, 1))});
    return ({ V rv_1 = v_t_246; V rr_ = heff_rec_reuse_nf(v_acc_242, 5ULL, 3, shape_pieces__errors__supply, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Right: {
    V v_x31_247 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_body_248 = heff_field(v_x31_247, 0);
      V v_n_249 = heff_field(v_x31_247, 1);
      heff_take_n(v_x31_247, 3ULL, 2);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_241), heff_dup(v_k_241), heff_dup(v_body_248)}), v_body_248));
      V v_t_2415;
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_b_2413 = v_field_2411;
        V v_acc_2414 = v_field_2412;
        v_t_2415 = (g_heff_2ecompile_2elift_2eordered(heff_get_n(v_acc_2414, 0, 2), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_241), heff_dup(v_k_241), v_b_2413})));
      }
      V v_t_2419 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_242, 0), heff_clo_n(g_heff_2ecompile_2elower_2eerasedPieces_24tok2_lam0, 1, 1, (V[]){v_k_241}), v_t_2415));
      return ({ V rv_0 = v_t_2419; V rv_2 = v_n_249; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 3, shape_pieces__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eerasedPieces_24tok2(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_lam0(V self, V *args) {
  V v_d_2416 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_2416, 2))));
  V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){v_k_241, heff_dup(heff_rfield(v_d_2416, 0)), heff_dup(heff_rfield(v_d_2416, 1)), heff_tag_n(TAG_Fresh, 1, (V[]){v_d_2416}), v_t_2418});
}