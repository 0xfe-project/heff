// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define TAG_Leaf 13717
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_MkRes 5766
#define TAG_MkResVals 58586
#define TAG_NoCustody 24110
#define TAG_PerformAt 64592
#define TAG_Plus 9189
#define TAG_Reading 19214
#define TAG_Right 62770
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_byFun 295539138
#define LBL_byKey 295543458
#define LBL_callers 780494982
#define LBL_callersOf 583887482
#define LBL_calls 295783919
#define LBL_cells 295903083
#define LBL_changed 970801394
#define LBL_consts 592362651
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_defs 9574869
#define LBL_dirty 296951788
#define LBL_done 9584713
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_fix 310927
#define LBL_flat 9641024
#define LBL_gathered 1327153563
#define LBL_group 299987609
#define LBL_groups 709681407
#define LBL_grown 299987669
#define LBL_ints 9732907
#define LBL_item 9738202
#define LBL_k 325
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lazy 9809979
#define LBL_lent 9813446
#define LBL_lowered 588863906
#define LBL_marking 1071112247
#define LBL_marks 305024864
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_pieces 958716528
#define LBL_refs 9991943
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_simplified 1686448252
#define LBL_supply 1056026650
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tokens 1078955205
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_tuples 1084651734
#define LBL_type_5f 312202367
#define LBL_units 312791945
#define LBL_ver 326173
#define LBL_words 314676931
#define LBL_workers 1757018875
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words, LBL_tokens};
static uint32_t shape_byFun__cells[] = {LBL_byFun, LBL_cells};
static uint32_t shape_byKey__callers__callersOf__ints[] = {LBL_byKey, LBL_callers, LBL_callersOf, LBL_ints};
static uint32_t shape_defs__facts__errors[] = {LBL_defs, LBL_facts, LBL_errors};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_defs__supply__tokens[] = {LBL_defs, LBL_supply, LBL_tokens};
static uint32_t shape_defs__words[] = {LBL_defs, LBL_words};
static uint32_t shape_done__name__refs__sgSafe__sgTotal[] = {LBL_done, LBL_name, LBL_refs, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_group__arity[] = {LBL_group, LBL_arity};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__out__k[] = {LBL_keys, LBL_out, LBL_k};
static uint32_t shape_lowered__groups__copies[] = {LBL_lowered, LBL_groups, LBL_copies};
static uint32_t shape_owner__key__name__item__refs[] = {LBL_owner, LBL_key, LBL_name, LBL_item, LBL_refs};
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_params__gathered__changed[] = {LBL_params, LBL_gathered, LBL_changed};
static uint32_t shape_params__grown__marks[] = {LBL_params, LBL_grown, LBL_marks};
static uint32_t shape_pieces__errors__supply[] = {LBL_pieces, LBL_errors, LBL_supply};
static uint32_t shape_simplified__errors__groups__copies[] = {LBL_simplified, LBL_errors, LBL_groups, LBL_copies};
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2edirect_2edirectDefs(V, V, V);
V g_heff_2ecompile_2edirect_2edirectDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectDefs_clo;
V g_heff_2ecompile_2edirect_2edirectDefs_24tok2(V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectDefs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectDefs_24tok2_clo;
V g_heff_2ecompile_2eerase_2edefinition(V, V, V, V);
V g_heff_2ecompile_2eerase_2edefinition_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2edefinition_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
HeffT11 g_heff_2ecompile_2efacts_2efactsOf_24cpr(V);
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
V g_heff_2ecompile_2elift_2eordered(V, V);
V g_heff_2ecompile_2elift_2eordered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eordered_clo;
V g_heff_2ecompile_2elower_2ecFacts(V, V);
V g_heff_2ecompile_2elower_2ecFacts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecFacts_clo;
V g_heff_2ecompile_2elower_2ecKept(V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2ecKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecKept_clo;
V g_heff_2ecompile_2elower_2ecKept_24rec0_get(void);
V g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937(V, V, V);
V g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_clo;
HeffT3 g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2edispatchDefs(V, V, V);
V g_heff_2ecompile_2elower_2edispatchDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2edispatchDefs_clo;
V g_heff_2ecompile_2elower_2eentryCps(V, V, V);
V g_heff_2ecompile_2elower_2eentryCps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryCps_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2eentryPieces(V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2eentryPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryPieces_clo;
V g_heff_2ecompile_2elower_2eentryReading(V, V, V);
V g_heff_2ecompile_2elower_2eentryReading_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryReading_clo;
V g_heff_2ecompile_2elower_2eerasedPieces(V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_clo;
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2(V, V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_24tok2_clo;
V g_heff_2ecompile_2elower_2efindDef(V, V);
V g_heff_2ecompile_2elower_2efindDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efindDef_clo;
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
HeffT2 g_heff_2ecompile_2elower_2efusedOf_24cpr(V, V);
V g_heff_2ecompile_2elower_2egroupGo(V);
V g_heff_2ecompile_2elower_2egroupGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupGo_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2ecompile_2elower_2eleafCount(V);
V g_heff_2ecompile_2elower_2eleafCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eleafCount_clo;
V g_heff_2ecompile_2elower_2elowerProgramKept(V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo;
HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_clo;
V g_heff_2ecompile_2elower_2eplusCount(V);
V g_heff_2ecompile_2elower_2eplusCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eplusCount_clo;
V g_heff_2ecompile_2elower_2ereachedPieces(V);
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ereachedPieces_clo;
V g_heff_2ecompile_2elower_2eredoErased(V, V, V, V);
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eredoErased_clo;
V g_heff_2ecompile_2elower_2erevOnto(V, V);
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_clo;
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V, V, V);
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo;
V g_heff_2ecompile_2elower_2eshapeSaid(V);
V g_heff_2ecompile_2elower_2eshapeSaid_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eshapeSaid_clo;
V g_heff_2ecompile_2elower_2eshared(V, V, V, V);
V g_heff_2ecompile_2elower_2eshared_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eshared_clo;
V g_heff_2ecompile_2elower_2eshared_24rec0_get(void);
V g_heff_2ecompile_2elower_2eshared_24rec2_get(void);
HeffT3 g_heff_2ecompile_2elower_2esharedLowered_24cpr(V, V);
V g_heff_2ecompile_2elower_2eunitOut(V, V, V);
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitOut_clo;
HeffT2 g_heff_2ecompile_2elower_2eunitOut_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2eunitVers(V, V);
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitVers_clo;
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void);
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
V g_heff_2ecompile_2eranges_2emattering(V, V, V);
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emattering_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2enarrowing(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowing_clo;
V g_heff_2ecompile_2eranges_2eroundOf(V, V, V, V);
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eroundOf_clo;
HeffT2 g_heff_2ecompile_2eranges_2erounds_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2escanW(V, V, V);
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanW_clo;
V g_heff_2ecompile_2eranges_2ewalkGo(V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkGo_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram_24rec0_get(void);
V g_heff_2ecompile_2etokens_2ebuildsW(V, V);
V g_heff_2ecompile_2etokens_2ebuildsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ebuildsW_clo;
HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(V, V);
V g_heff_2ecompile_2etokens_2esitesW(V, V);
V g_heff_2ecompile_2etokens_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2esitesW_clo;
V g_heff_2ecompile_2eworker_2eworkers(V, V);
V g_heff_2ecompile_2eworker_2eworkers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eworkers_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s44244667x1445755514(V, V);
V g_list_2eall_24s44244667x1445755514_entry(V self, V *a);
extern Clo g_list_2eall_24s44244667x1445755514_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s277053946x716662586(V, V);
V g_list_2eany_24s277053946x716662586_entry(V self, V *a);
extern Clo g_list_2eany_24s277053946x716662586_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1068175575x1869083571(V, V);
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1068175575x1869083571_clo;
V g_list_2efoldl_24s1078918265x314186258(V, V);
V g_list_2efoldl_24s1078918265x314186258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1078918265x314186258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1499934538x170225690(V, V);
V g_list_2efoldl_24s1499934538x170225690_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1499934538x170225690_clo;
V g_list_2efoldl_24s1579438642x567671990(V, V, V, V, V);
V g_list_2efoldl_24s1579438642x567671990_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1579438642x567671990_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1738438673x24732785(V, V);
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1738438673x24732785_clo;
V g_list_2efoldl_24s1769360958x1839054239(V, V);
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1769360958x1839054239_clo;
V g_list_2efoldl_24s1810610888x1691479932(V, V);
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810610888x1691479932_clo;
V g_list_2efoldl_24s1898127600x1966620111(V, V);
V g_list_2efoldl_24s1898127600x1966620111_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1898127600x1966620111_clo;
V g_list_2efoldl_24s2004150897x784001505(V, V);
V g_list_2efoldl_24s2004150897x784001505_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2004150897x784001505_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s243940296x1179168444(V, V);
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243940296x1179168444_clo;
V g_list_2efoldl_24s26403090x581733227(V, V, V, V);
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a);
extern Clo g_list_2efoldl_24s26403090x581733227_clo;
V g_list_2efoldl_24s322049767x2109647543(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s322049767x2109647543_entry(V self, V *a);
extern Clo g_list_2efoldl_24s322049767x2109647543_clo;
V g_list_2efoldl_24s330602584x1277356584(V, V, V);
V g_list_2efoldl_24s330602584x1277356584_entry(V self, V *a);
extern Clo g_list_2efoldl_24s330602584x1277356584_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s532743697x1094589833(V, V);
V g_list_2efoldl_24s532743697x1094589833_entry(V self, V *a);
extern Clo g_list_2efoldl_24s532743697x1094589833_clo;
V g_list_2efoldl_24s644510009x1719377493(V, V);
V g_list_2efoldl_24s644510009x1719377493_entry(V self, V *a);
extern Clo g_list_2efoldl_24s644510009x1719377493_clo;
V g_list_2efoldl_24s88009013x1334911863(V, V);
V g_list_2efoldl_24s88009013x1334911863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s88009013x1334911863_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1223034477x943356724(V);
V g_list_2ekeepIf_24s1223034477x943356724_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_clo;
V g_list_2ekeepIf_24s1606737509x658906972(V);
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s136093287x730789464(V, V, V, V);
V g_list_2emap_24s136093287x730789464_entry(V self, V *a);
extern Clo g_list_2emap_24s136093287x730789464_clo;
V g_list_2emap_24s136093287x730789464_24tok2(V, V, V, V, V);
V g_list_2emap_24s136093287x730789464_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s136093287x730789464_24tok2_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1985010810x1780722131(V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_list_2emap_24s509077117x607152875(V);
V g_list_2emap_24s509077117x607152875_entry(V self, V *a);
extern Clo g_list_2emap_24s509077117x607152875_clo;
V g_list_2emap_24s509077117x607152875_24tok1(V, V);
V g_list_2emap_24s509077117x607152875_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s509077117x607152875_24tok1_clo;
V g_list_2emap_24s510639937x1058700299(V);
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1111575179x1680558317_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1573855737x392625097_24cpr(V, V);
V g_prelude_2etraverse_24s1617808025x638052145(V, V);
V g_prelude_2etraverse_24s1617808025x638052145_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1617808025x638052145_clo;
V g_prelude_2etraverse_24s812820150x374715993(V, V);
V g_prelude_2etraverse_24s812820150x374715993_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s812820150x374715993_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2emapValues_24s383523993x1452310955(V);
V g_std_2eordmap_2emapValues_24s383523993x1452310955_entry(V self, V *a);
extern Clo g_std_2eordmap_2emapValues_24s383523993x1452310955_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;

static V g_heff_2ecompile_2elower_2eshared_24rec0_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2eshared_24rec0_st;
static V g_heff_2ecompile_2elower_2eshared_24rec0_init(void) {
  return heff_rec_n(2, shape_group__arity, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2elower_2eshared_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2eshared_24rec0_st)) return g_heff_2ecompile_2elower_2eshared_24rec0_val;
  return heff_global(&g_heff_2ecompile_2elower_2eshared_24rec0_val, &g_heff_2ecompile_2elower_2eshared_24rec0_st, g_heff_2ecompile_2elower_2eshared_24rec0_init);
}

static V g_heff_2ecompile_2elower_2eshared_24rec2_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2eshared_24rec2_st;
static V g_heff_2ecompile_2elower_2eshared_24rec2_init(void) {
  return heff_rec_n(3, shape_keys__out__k, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), MK_INT(0LL)});
}
V g_heff_2ecompile_2elower_2eshared_24rec2_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2eshared_24rec2_st)) return g_heff_2ecompile_2elower_2eshared_24rec2_val;
  return heff_global(&g_heff_2ecompile_2elower_2eshared_24rec2_val, &g_heff_2ecompile_2elower_2eshared_24rec2_st, g_heff_2ecompile_2elower_2eshared_24rec2_init);
}

HeffT3 g_heff_2ecompile_2elower_2esharedLowered_24cpr(V v_errors_240, V v_t_241) {
top: ;
  V v_tuples_242 = heff_take_field(v_t_241, 2);
  V v_defs_243 = heff_get_n(v_t_241, 0, 3);
  V v_ts_244 = v_tuples_242;
  HeffT11 v_t_245 = (g_heff_2ecompile_2efacts_2efactsOf_24cpr(v_defs_243));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    V v_field_249 = v_t_245.f[3];
    V v_field_2410 = v_t_245.f[4];
    V v_field_2411 = v_t_245.f[5];
    V v_field_2412 = v_t_245.f[6];
    V v_field_2413 = v_t_245.f[7];
    V v_field_2415 = v_t_245.f[9];
    V v_field_2416 = v_t_245.f[10];
    heff_drop(v_t_245.f[8]);
    V v_f_2417 = v_defs_243;
    return ((HeffT3){{v_f_2417, heff_rec_n(11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, (V[]){v_field_246, v_field_247, v_field_248, v_field_249, v_field_2410, v_field_2411, v_field_2412, v_field_2413, v_ts_244, v_field_2415, v_field_2416}), v_errors_240}});
  }
}
Clo g_heff_2ecompile_2elower_2efusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efusedOf_entry, 2, 0};

V g_heff_2ecompile_2elower_2efusedOf(V v_roots_240, V v_si_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2elower_2efusedOf_24cpr(v_roots_240, v_si_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_rec_n(2, shape_defs__supply, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2efusedOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryKey_str0, 9, "run$entry");

static V g_heff_2ecompile_2elower_2eentryKey_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2eentryKey_st;
static V g_heff_2ecompile_2elower_2eentryKey_init(void) {
  return ((V)&g_heff_2ecompile_2elower_2eentryKey_str0);
}
V g_heff_2ecompile_2elower_2eentryKey_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2eentryKey_st)) return g_heff_2ecompile_2elower_2eentryKey_val;
  return heff_global(&g_heff_2ecompile_2elower_2eentryKey_val, &g_heff_2ecompile_2elower_2eentryKey_st, g_heff_2ecompile_2elower_2eentryKey_init);
}
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str0, 3, "w#p");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str1, 3, "w#k");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str2, 3, "w#l");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str3, 3, "w#r");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str4, 12, "run$perform$");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str5, 12, "run$perform$");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str6, 12, "run$perform$");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str7, 12, "run$perform$");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str8, 3, "InR");
HEFF_LIT(g_heff_2ecompile_2elower_2edispatchDefs_str9, 3, "InL");
Clo g_heff_2ecompile_2elower_2edispatchDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2edispatchDefs_entry, 3, 0};

V g_heff_2ecompile_2elower_2edispatchDefs(V v_x1_240, V v_node_241, V v_leaf_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_node_241);
    heff_drop(v_leaf_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Plus: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Plus = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_na_246 = heff_intAdd_lent(v_node_241, MK_INT(1LL), 2);
    V v_t_247 = (g_heff_2ecompile_2elower_2eplusCount(v_a_244));
    V v_nb_248 = heff_intAdd(heff_intAdd_lent(v_node_241, MK_INT(1LL), 2), v_t_247);
    V v_t_249 = (g_heff_2ecompile_2elower_2eleafCount(v_a_244));
    V v_lb_2410 = heff_intAdd_lent(v_leaf_242, v_t_249, 2);
    V v_p_2411 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str0), heff_intShow(heff_dup(v_node_241)));
    V v_k_2412 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str1), heff_intShow(heff_dup(v_node_241)));
    V v_x_2413 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str2), heff_intShow(heff_dup(v_node_241)));
    V v_y_2414 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str3), heff_intShow(heff_dup(v_node_241)));
    V v_t_2423;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Leaf: {
      V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24Plus, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_k_2412)}), NTAG(TAG_Nil)});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2413)}), v_t_2416});
      v_t_2423 = heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){heff_dup(v_leaf_242)}), v_t_2417});
      break;
    }
    case TAG_Plus: {
      V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str4), heff_intShow(heff_dup(v_na_246)));
      V v_t_2421 = heff_tag_at_n(v_ru_24x1_240_24Plus, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_k_2412)}), NTAG(TAG_Nil)});
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2413)}), v_t_2421});
      v_t_2423 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_t_2420}), v_t_2422});
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_t_2432;
    switch (heff_tag_of(v_b_245)) {
    case TAG_Leaf: {
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_k_2412)}), NTAG(TAG_Nil)});
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_y_2414)}), v_t_2425});
      v_t_2432 = heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){heff_dup(v_lb_2410)}), v_t_2426});
      break;
    }
    case TAG_Plus: {
      V v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str5), heff_intShow(heff_dup(v_nb_248)));
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_k_2412)}), NTAG(TAG_Nil)});
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_y_2414)}), v_t_2430});
      v_t_2432 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_t_2429}), v_t_2431});
      break;
    }
    default: heff_nomatch(v_b_245);
    }
    V v_t_2433 = (g_heff_2ecompile_2elower_2edispatchDefs(v_a_244, v_na_246, v_leaf_242));
    V v_t_2434 = (g_heff_2ecompile_2elower_2edispatchDefs(v_b_245, v_nb_248, v_lb_2410));
    V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2434));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str6), heff_intShow(heff_dup(v_node_241)));
    V v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2edispatchDefs_str7), heff_intShow(v_node_241));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_2412, NTAG(TAG_Nil)});
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, NTAG(TAG_Nil)});
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_2414, NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2elower_2edispatchDefs_str8), v_t_2440, v_t_2432}), NTAG(TAG_Nil)});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2elower_2edispatchDefs_str9), v_t_2439, v_t_2423}), v_t_2441});
    V v_t_2443 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_p_2411)}), v_t_2442});
    V v_t_2444 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_p_2411, v_t_2438}), v_t_2443});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_t_2436, v_t_2437, v_t_2444}), v_t_2435});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2edispatchDefs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2edispatchDefs(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2elower_2ecFacts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecFacts_entry, 2, 0};

V g_heff_2ecompile_2elower_2ecFacts(V v_defs_240, V v_facts_241) {
top: ;
  V v_m_242 = (g_list_2efoldl_24s1738438673x24732785(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_240)));
  V v_t_243 = ({ V a_0 = v_m_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_242); r_; });
  V v_ps_244 = (g_list_2ekeepIf_24s1223034477x943356724(v_t_243));
  V v_su_245 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_244; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_244); r_; });
  V v_fl_246 = (g_list_2efoldl_24s2004150897x784001505(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_240)));
  V v_m_247 = (g_list_2efoldl_24s243940296x1179168444(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_240)));
  V v_t_248 = ({ V a_0 = v_m_247; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_247); r_; });
  V v_ps_249 = (g_list_2ekeepIf_24s1223034477x943356724(v_t_248));
  V v_su_2410 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_249; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_249); r_; });
  V v_facts_2411 = ({ V rv_5 = v_fl_246; V rv_6 = v_su_2410; V rv_7 = v_su_245; V rr_ = heff_rec_reuse_nf(v_facts_241, 1823ULL, 11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, 4129791u, 0u); heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_ws_2412 = (g_heff_2ecompile_2eworker_2eworkers(heff_dup(v_facts_2411), v_defs_240));
  return ({ V rv_4 = v_ws_2412; V rr_ = heff_rec_reuse_nf(v_facts_2411, 2031ULL, 11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, 4193535u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2ecompile_2elower_2ecFacts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecFacts(a[0], a[1]);
}

static V g_heff_2ecompile_2elower_2ecKept_24rec0_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2ecKept_24rec0_st;
static V g_heff_2ecompile_2elower_2ecKept_24rec0_init(void) {
  return heff_rec_n(4, shape_byKey__callers__callersOf__ints, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2elower_2ecKept_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2ecKept_24rec0_st)) return g_heff_2ecompile_2elower_2ecKept_24rec0_val;
  return heff_global(&g_heff_2ecompile_2elower_2ecKept_24rec0_val, &g_heff_2ecompile_2elower_2ecKept_24rec0_st, g_heff_2ecompile_2elower_2ecKept_24rec0_init);
}
HEFF_LIT(g_heff_2ecompile_2elower_2ecKept_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2elower_2ecKept_str1, 4, "$tok");
V g_heff_2ecompile_2elower_2ecKept_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam4(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam5(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam6(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam7(V self, V *args);
V g_heff_2ecompile_2elower_2ecKept_lam8(V self, V *args);
Clo g_heff_2ecompile_2elower_2ecKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecKept_entry, 6, 0};

V g_heff_2ecompile_2elower_2ecKept(V v_fuel_240, V v_direct_241, V v_roots_242, V v_supply_243, V v_kept_244, V v_errors_245) {
top: ;
  V v_fuel_246 = v_fuel_240;
  V v_roots_247 = v_roots_242;
  V v_errors_248 = v_errors_245;
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_supply_243});
  V v_t_2410 = (g_list_2efoldl_24s1078918265x314186258(v_t_249, v_kept_244));
  V v_p_2416;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_MkPair: {
    V v_acc_2411 = heff_field(v_t_2410, 0);
    V v_n2_2412 = heff_field(v_t_2410, 1);
    V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
    V v_xs_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_2411));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
    V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2414); r_; });
    v_p_2416 = heff_tag_re_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2415, v_n2_2412});
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_x4_2421;
  switch (heff_tag_of(v_direct_241)) {
  case TAG_Nil: {
    v_x4_2421 = v_p_2416;
    break;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_p_2416)) {
    case TAG_MkPair: {
      V v_defs_2419 = heff_field(v_p_2416, 0);
      V v_n_2420 = heff_field(v_p_2416, 1);
      V v_ru_24p_2416_24MkPair = heff_take_reuse_n(v_p_2416, 3ULL, 2);
      v_x4_2421 = (g_heff_2ecompile_2edirect_2edirectDefs_24tok2(v_ru_24p_2416_24MkPair, v_direct_241, v_defs_2419, v_n_2420));
      break;
    }
    default: heff_nomatch(v_p_2416);
    }
    break;
  }
  default: heff_nomatch(v_direct_241);
  }
  switch (heff_tag_of(v_x4_2421)) {
  case TAG_MkPair: {
    V v_defs_2422 = heff_field(v_x4_2421, 0);
    V v_n_2423 = heff_field(v_x4_2421, 1);
    V v_ru_24x4_2421_24MkPair = heff_take_reuse_n(v_x4_2421, 3ULL, 2);
    V v_t_2424 = (g_heff_2ecompile_2elower_2eshared(v_fuel_246, v_roots_247, v_n_2423, v_defs_2422));
    V v_tuples_2425 = heff_take_field(v_t_2424, 2);
    V v_supply_2426 = heff_take_field(v_t_2424, 1);
    V v_defs_2427 = heff_get_n(v_t_2424, 0, 3);
    V v_errors_2428 = v_errors_248;
    V v_tuples_2429 = v_tuples_2425;
    V v_n_2430 = v_supply_2426;
    HeffT2 v_t_2431 = (g_prelude_2etraverse_24s1111575179x1680558317_24cpr(v_defs_2427, v_n_2430));
    {
      V v_field_2432 = v_t_2431.f[0];
      V v_field_2433 = v_t_2431.f[1];
      V v_defs_2434 = v_field_2432;
      V v_n_2435 = v_field_2433;
      V v_x3_2436 = (g_prelude_2etraverse_24s812820150x374715993(v_defs_2434, v_n_2435));
      switch (heff_tag_of(v_x3_2436)) {
      case TAG_MkPair: {
        V v_defs_2437 = heff_field(v_x3_2436, 0);
        V v_n_2438 = heff_field(v_x3_2436, 1);
        V v_ru_24x3_2436_24MkPair = heff_take_reuse_n(v_x3_2436, 3ULL, 2);
        V v_tuples_2439 = heff_dup(v_tuples_2429);
        V v_s_2440 = v_n_2438;
        V v_defs_2441 = v_defs_2437;
        V v_tuples_2442 = v_tuples_2439;
        V v_byKey_2443 = (g_list_2efoldl_24s88009013x1334911863(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2441));
        V v_t_2444 = (g_list_2emap_24s45270243x110012769(heff_dup(v_defs_2441)));
        V v_sites_2445 = (g_heff_2ecompile_2etokens_2esitesW(NTAG(TAG_Nil), v_t_2444));
        V v_m_24122 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam0, 2, 2, (V[]){v_byKey_2443, v_tuples_2442}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_sites_2445; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_sites_2445); r_; });
        V v_t_24123 = ({ V a_0 = v_m_24122; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_24122); r_; });
        V v_cs_24124 = (g_list_2emap_24s366344330x1145113647(v_t_24123));
        HeffT2 v_t_24125 = (g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(heff_dup(v_cs_24124), v_s_2440));
        {
          V v_field_24126 = v_t_24125.f[0];
          V v_field_24127 = v_t_24125.f[1];
          V v_copied_24128 = v_field_24126;
          V v_s_24129 = v_field_24127;
          V v_t_24130 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_2421_24MkPair, v_defs_2441, v_copied_24128));
          V v_t_24131 = (g_list_2efoldl_24s532743697x1094589833(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_cs_24124)));
          V v_t_24132 = ({ V a_0 = ((V)&g_heff_2ecompile_2elower_2ecKept_str1); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_cs_24124; V r_ = (g_list_2efoldl_24s330602584x1277356584(a_0, a_1, a_2)); heff_drop(v_cs_24124); r_; });
          V v_t_24133 = heff_rec_n(3, shape_defs__supply__tokens, (V[]){v_t_24130, v_s_24129, heff_rec_n(2, shape_byFun__cells, (V[]){v_t_24131, v_t_24132})});
          V v_tokens_24134 = heff_take_field(v_t_24133, 2);
          V v_supply_24135 = heff_take_field(v_t_24133, 1);
          V v_defs_24136 = heff_get_n(v_t_24133, 0, 3);
          V v_errors_24137 = v_errors_2428;
          V v_tuples_24138 = v_tuples_2429;
          V v_tk_24139 = v_tokens_24134;
          V v_supply_24140 = v_supply_24135;
          HeffT2 v_t_24141 = (g_prelude_2etraverse_24s1573855737x392625097_24cpr(v_defs_24136, v_supply_24140));
          {
            V v_field_24142 = v_t_24141.f[0];
            V v_field_24143 = v_t_24141.f[1];
            V v_defs_24144 = v_field_24142;
            V v_n_24145 = v_field_24143;
            V v_x1_24146 = (g_prelude_2etraverse_24s1617808025x638052145(v_defs_24144, v_n_24145));
            V v_defs_24149;
            switch (heff_tag_of(v_x1_24146)) {
            case TAG_MkPair: {
              V v_x_24147 = heff_field(v_x1_24146, 0);
              heff_take_n(v_x1_24146, 1ULL, 2);
              v_defs_24149 = v_x_24147;
              break;
            }
            default: heff_nomatch(v_x1_24146);
            }
            V v_consts_24150 = (g_list_2efoldl_24s1068175575x1869083571(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24149));
            V v_defs_24151 = heff_dup(v_defs_24149);
            V v_ar_24152 = (g_list_2efoldl_24s1810610888x1691479932(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24149));
            V v_scans_24159 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam1, 2, 1, (V[]){v_ar_24152}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_24149; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_24149); r_; });
            V v_t_24160 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_scans_24159, NTAG(TAG_Nil)));
            V v_esc_24161 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24160; V r_ = (g_list_2efoldl_24s1898127600x1966620111(a_0, a_1)); heff_drop(v_t_24160); r_; });
            V v_fns_24162 = (g_list_2efoldl_24s26403090x581733227(v_esc_24161, heff_dup(v_scans_24159), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_24151)));
            V v_consts_24163 = v_consts_24150;
            V v_defs_24164 = v_defs_24151;
            V v_scans_24165 = v_scans_24159;
            V v_fns_24166 = heff_dup(v_fns_24162);
            V v_t_24167 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_fns_24162, NTAG(TAG_Nil)));
            V v_t_24168 = (g_list_2ekeepIf_24s1606737509x658906972(v_t_24167));
            V v_t_24169 = (g_std_2eordmap_2emapValues_24s383523993x1452310955(v_fns_24162));
            V v_ms_24170 = ({ V a_0 = v_t_24168; V a_1 = MK_INT(64LL); V a_2 = v_t_24169; V r_ = (g_heff_2ecompile_2eranges_2emattering(a_0, a_1, a_2)); heff_drop(v_t_24168); r_; });
            V v_t_24171 = ({ V a_0 = v_ms_24170; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_ms_24170); r_; });
            V v_params_24183 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam2, 2, 1, (V[]){v_fns_24166}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_24171; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24171); r_; });
            V v_consts_24184 = v_consts_24163;
            V v_defs_24185 = heff_dup(v_defs_24164);
            V v_params_24186 = heff_dup(v_params_24183);
            V v_sc_24227 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam3, 2, 2, (V[]){v_params_24183, v_scans_24165}); V a_1 = heff_dup(g_heff_2ecompile_2elower_2ecKept_24rec0_get()); V a_2 = v_defs_24164; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_24164); r_; });
            V v_consts_24228 = heff_dup(v_consts_24184);
            V v_sc_24229 = heff_dup(v_sc_24227);
            V v_defs_24230 = heff_dup(v_defs_24185);
            V v_t_24231 = (g_list_2emap_24s1835183789x486277886(v_defs_24185));
            V v_t_24237 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam6, 1, 1, (V[]){heff_dup(v_params_24186)}), v_t_24231));
            V v_t_24238 = heff_rec_n(3, shape_fix__dirty__gathered, (V[]){heff_rec_n(3, shape_params__grown__marks, (V[]){v_params_24186, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())}), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
            V v_t_24239 = ({ V a_0 = heff_dup(v_consts_24184); V a_1 = heff_dup(v_sc_24227); V a_2 = v_t_24238; V a_3 = v_t_24237; V r_ = (g_heff_2ecompile_2eranges_2eroundOf(a_0, a_1, a_2, a_3)); heff_drop(v_t_24237); r_; });
            HeffT2 v_t_24240 = (g_heff_2ecompile_2eranges_2erounds_24cpr(v_consts_24184, v_sc_24227, MK_INT(64LL), v_t_24239));
            {
              V v_field_24242 = v_t_24240.f[1];
              int64_t v_tag_24241 = ((int64_t)v_t_24240.f[0]);
              V v_r_24287;
              if ((v_tag_24241 == ((int64_t)0ULL))) {
                V v_s_24243 = v_field_24242;
                V v_fix_24244 = heff_take_field(v_s_24243, 0);
                V v_gathered_24245 = heff_get_n(v_s_24243, 2, 3);
                V v_consts_24246 = heff_dup(v_consts_24228);
                V v_sc_24247 = heff_dup(v_sc_24229);
                V v_defs_24248 = v_defs_24230;
                V v_t_24249 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_fix_24244, 0), NTAG(TAG_Nil)));
                V v_t_24250 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x3_2436_24MkPair, v_t_24249));
                V v_t_24251 = heff_rec_n(3, shape_params__gathered__changed, (V[]){heff_get_n(v_fix_24244, 0, 3), heff_dup(v_gathered_24245), NTAG(TAG_Nil)});
                V v_t_24252 = ({ V a_0 = heff_dup(v_sc_24229); V a_1 = v_t_24251; V a_2 = v_gathered_24245; V a_3 = v_t_24250; V r_ = (g_heff_2ecompile_2eranges_2enarrowWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_24250); r_; });
                V v_params_24253 = (g_heff_2ecompile_2eranges_2enarrowing(v_consts_24228, v_sc_24229, MK_INT(3LL), v_t_24252));
                V v_t_24284 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam7, 1, 3, (V[]){v_sc_24247, heff_dup(v_params_24253), v_consts_24246}), v_defs_24248));
                V v_t_24285 = ({ V a_0 = v_params_24253; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_params_24253); r_; });
                V v_t_24286 = ({ V a_0 = MK_INT(-4611686018427387904LL); V a_1 = MK_INT(4611686018427387903LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = MK_INT(0LL); V a_5 = MK_INT(1LL); V a_6 = MK_INT(-4611686018427387904LL); V a_7 = MK_INT(4611686018427387903LL); V a_8 = MK_INT(0LL); V a_9 = MK_INT(1LL); V a_10 = MK_INT(0LL); V a_11 = MK_INT(1LL); V a_12 = heff_dup(g_std_2eordmap_2eempty_get()); V a_13 = v_t_24285; V r_ = (g_list_2efoldl_24s322049767x2109647543(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12, a_13)); heff_drop(v_t_24285); r_; });
                v_r_24287 = heff_rec_n(2, shape_defs__words, (V[]){v_t_24284, v_t_24286});
              } else {
                heff_drop_cell(v_ru_24x3_2436_24MkPair, 2);
                heff_drop(v_consts_24228);
                heff_drop(v_sc_24229);
                heff_drop(v_field_24242);
                v_r_24287 = heff_rec_n(2, shape_defs__words, (V[]){v_defs_24230, heff_dup(g_std_2eordmap_2eempty_get())});
              }
              V v_words_24288 = heff_take_field(v_r_24287, 1);
              V v_defs_24289 = heff_get_n(v_r_24287, 0, 2);
              V v_ws_24290 = v_words_24288;
              V v_tk_24291 = heff_dup(v_tk_24139);
              V v_defs_24292 = heff_dup(v_defs_24289);
              V v_t_24293 = (g_list_2efoldl_24s1769360958x1839054239(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24292));
              V v_m_24294 = ({ V a_0 = v_defs_24292; V a_1 = MK_INT(-1LL); V a_2 = v_t_24293; V r_ = (g_heff_2ecompile_2eborrow_2eborFix(a_0, a_1, a_2)); heff_drop(v_defs_24292); r_; });
              V v_t_24295 = ({ V a_0 = v_m_24294; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_24294); r_; });
              V v_ps_24311 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam8, 1, 1, (V[]){v_tk_24291}), v_t_24295));
              V v_lent_24312 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24311; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_24311); r_; });
              HeffT11 v_t_24313 = (g_heff_2ecompile_2efacts_2efactsOf_24cpr(v_defs_24289));
              {
                V v_field_24314 = v_t_24313.f[0];
                V v_field_24315 = v_t_24313.f[1];
                V v_field_24316 = v_t_24313.f[2];
                V v_field_24318 = v_t_24313.f[4];
                V v_field_24319 = v_t_24313.f[5];
                V v_field_24320 = v_t_24313.f[6];
                V v_field_24321 = v_t_24313.f[7];
                heff_drop(v_t_24313.f[3]);
                heff_drop(v_t_24313.f[8]);
                heff_drop(v_t_24313.f[9]);
                heff_drop(v_t_24313.f[10]);
                V v_t_24325 = v_field_24314;
                V v_t_24326 = v_field_24315;
                V v_t_24327 = v_field_24316;
                V v_t_24328 = v_field_24318;
                V v_t_24329 = v_field_24319;
                V v_t_24330 = v_field_24320;
                V v_t_24331 = v_field_24321;
                V v_t_24332 = (g_heff_2ecompile_2elower_2ecFacts(heff_dup(v_defs_24289), heff_rec_n(11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, (V[]){v_t_24325, v_t_24326, v_t_24327, v_lent_24312, v_t_24328, v_t_24329, v_t_24330, v_t_24331, v_tuples_24138, v_ws_24290, v_tk_24139})));
                return heff_rec_n(3, shape_defs__facts__errors, (V[]){v_defs_24289, v_t_24332, v_errors_24137});
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_x3_2436);
      }
    }
  }
  default: return heff_nomatch(v_x4_2421);
  }
}
V g_heff_2ecompile_2elower_2ecKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecKept(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2elower_2ecKept_lam0(V self, V *args) {
  V v_m_2446 = args[0];
  V v_s_2447 = args[1];
  V v_byKey_2443 = heff_env(self)[0];
  V v_tuples_2442 = heff_env(self)[1];
  V v_t_2450;
  switch (heff_tag_of(v_s_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_dup(heff_field(v_s_2447, 0));
    v_t_2450 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_s_2447);
  }
  heff_clo_take(self, 2);
  HeffT2 v_t_2451 = ({ V a_0 = v_byKey_2443; V a_1 = v_t_2450; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byKey_2443); heff_drop(v_t_2450); r_; });
  {
    V v_field_2453 = v_t_2451.f[1];
    int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
    if ((v_tag_2452 == ((int64_t)0ULL))) {
      V v_d_2454 = v_field_2453;
      V v_tuples_2455 = v_tuples_2442;
      V v_n_2458;
      switch (heff_tag_of(v_s_2447)) {
      case TAG_MkPair: {
        V v_y_2457 = heff_dup(heff_field(v_s_2447, 1));
        v_n_2458 = v_y_2457;
        break;
      }
      default: heff_nomatch(v_s_2447);
      }
      V v_d_2459 = heff_dup(v_d_2454);
      V v_t_2460 = heff_dup(heff_rfield(v_d_2459, 2));
      V v_t_24111;
      switch (heff_tag_of(v_t_2460)) {
      case TAG_EVar: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        V v_b_2464 = heff_field(v_t_2460, 1);
        V v_ru_24t_2460_24ELam = heff_take_reuse_n(v_t_2460, 2ULL, 2);
        HeffT2 v_t_2465 = ({ V a_0 = v_tuples_2455; V a_1 = heff_rfield(v_d_2459, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_tuples_2455); r_; });
        {
          V v_field_2467 = v_t_2465.f[1];
          int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
          if ((v_tag_2466 == ((int64_t)0ULL))) {
            heff_drop(v_n_2458);
            heff_drop_rec(v_d_2459, 3);
            heff_drop(v_b_2464);
            heff_drop_cell(v_ru_24t_2460_24ELam, 2);
            V v_x_2468 = v_field_2467;
            heff_drop(v_x_2468);
            v_t_24111 = NTAG(TAG_False);
          } else {
            heff_drop(v_field_2467);
            V v_t_2469 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2464)));
            V v_t_2470 = (g_heff_2ecompile_2eir_2enubI(v_t_2469));
            V v_x1_2471 = ({ V a_0 = v_d_2459; V a_1 = v_t_2470; V r_ = (g_list_2eany_24s277053946x716662586(a_0, a_1)); heff_drop(v_t_2470); r_; });
            if (!(heff_dup(v_x1_2471) == NTAG(TAG_True))) {
              heff_drop(v_x1_2471);
              V v_t_2472 = heff_tag_at_n(v_ru_24t_2460_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_2464), NTAG(TAG_Nil)});
              V v_t_2473 = (g_heff_2ecompile_2etokens_2ebuildsW(v_n_2458, v_t_2472));
              if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
                heff_drop(v_t_2473);
                V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2464, NTAG(TAG_Nil)});
                V v_x_2475 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(150LL), MK_INT(0LL), v_t_2474));
                v_t_24111 = heff_bool(!heff_intLt_c_lent(MK_INT(150LL), v_x_2475, 1));
                heff_drop(v_x_2475);
              } else {
                heff_drop(v_b_2464);
                heff_drop(v_t_2473);
                v_t_24111 = NTAG(TAG_False);
              }
            } else {
              heff_drop(v_n_2458);
              heff_drop(v_b_2464);
              heff_drop_cell(v_ru_24t_2460_24ELam, 2);
              heff_drop(v_x1_2471);
              v_t_24111 = NTAG(TAG_False);
            }
          }
        }
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_t_2460, 0ULL, 2);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_t_2460, 0ULL, 3);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_t_2460, 0ULL, 2);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_t_2460, 0ULL, 4);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_t_2460, 0ULL, 3);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_t_2460, 0ULL, 2);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_t_2460, 0ULL, 2);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_t_2460, 0ULL, 2);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_t_2460, 0ULL, 2);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_t_2460, 0ULL, 3);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_t_2460, 0ULL, 1);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_t_2460, 0ULL, 2);
        heff_drop(v_tuples_2455);
        heff_drop(v_n_2458);
        heff_drop_rec(v_d_2459, 3);
        v_t_24111 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2460);
      }
      if ((heff_dup(v_t_24111) == NTAG(TAG_True))) {
        heff_drop(v_t_24111);
        V v_t_24114;
        switch (heff_tag_of(v_s_2447)) {
        case TAG_MkPair: {
          V v_x_24112 = heff_dup(heff_field(v_s_2447, 0));
          v_t_24114 = v_x_24112;
          break;
        }
        default: heff_nomatch(v_s_2447);
        }
        V v_t_24117;
        switch (heff_tag_of(v_s_2447)) {
        case TAG_MkPair: {
          V v_y_24116 = heff_dup(heff_field(v_s_2447, 1));
          v_t_24117 = v_y_24116;
          break;
        }
        default: heff_nomatch(v_s_2447);
        }
        V v_t_24120;
        switch (heff_tag_of(v_s_2447)) {
        case TAG_MkPair: {
          V v_y_24119 = heff_field(v_s_2447, 1);
          heff_take_n(v_s_2447, 2ULL, 2);
          v_t_24120 = v_y_24119;
          break;
        }
        default: heff_nomatch(v_s_2447);
        }
        V v_t_24121 = heff_strAppend(heff_strAppend(v_t_24114, ((V)&g_heff_2ecompile_2elower_2ecKept_str0)), heff_intShow(v_t_24117));
        return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2446, v_t_24121, heff_tag_n(TAG_MkPair, 2, (V[]){v_d_2454, v_t_24120})));
      } else {
        heff_drop(v_s_2447);
        heff_drop(v_d_2454);
        heff_drop(v_t_24111);
        return v_m_2446;
      }
    } else {
      heff_drop(v_s_2447);
      heff_drop(v_tuples_2442);
      heff_drop(v_field_2453);
      return v_m_2446;
    }
  }
}
V g_heff_2ecompile_2elower_2ecKept_lam1(V self, V *args) {
  V v_m_24153 = args[0];
  V v_d_24154 = args[1];
  V v_ar_24152 = heff_env(self)[0];
  V v_body_24155 = heff_take_field(v_d_24154, 2);
  V v_key_24156 = heff_get_n(v_d_24154, 0, 3);
  V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){v_body_24155, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  V v_t_24158 = (g_heff_2ecompile_2eranges_2escanW(v_ar_24152, heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get()), v_t_24157));
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_24153, v_key_24156, v_t_24158));
}
V g_heff_2ecompile_2elower_2ecKept_lam2(V self, V *args) {
  V v_acc_24172 = args[0];
  V v_x3_24173 = args[1];
  V v_fns_24166 = heff_env(self)[0];
  switch (heff_tag_of(v_x3_24173)) {
  case TAG_MkPair: {
    V v_k_24174 = heff_field(v_x3_24173, 0);
    V v_x32_24175 = heff_field(v_x3_24173, 1);
    heff_take_n(v_x3_24173, 3ULL, 2);
    switch (heff_tag_of(v_x32_24175)) {
    case TAG_Nil: {
      heff_drop(self);
      heff_drop(v_k_24174);
      return v_acc_24172;
    }
    case TAG_Cons: {
      heff_take_n(v_x32_24175, 0ULL, 2);
      heff_clo_take(self, 1);
      HeffT2 v_t_24178 = ({ V a_0 = v_fns_24166; V a_1 = v_k_24174; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_fns_24166); r_; });
      {
        V v_field_24180 = v_t_24178.f[1];
        int64_t v_tag_24179 = ((int64_t)v_t_24178.f[0]);
        if ((v_tag_24179 == ((int64_t)0ULL))) {
          V v_fn_24181 = v_field_24180;
          V v_t_24182 = (g_list_2emap_24s1792553290x233563724(heff_get_n(v_fn_24181, 0, 3)));
          return (g_std_2eordmap_2einsert_24s615484302x989744458(v_acc_24172, v_k_24174, v_t_24182));
        } else {
          heff_drop(v_k_24174);
          heff_drop(v_field_24180);
          return v_acc_24172;
        }
      }
    }
    default: return heff_nomatch(v_x32_24175);
    }
  }
  default: return heff_nomatch(v_x3_24173);
  }
}
V g_heff_2ecompile_2elower_2ecKept_lam4(V self, V *args) {
  V v_m_24202 = args[0];
  V v_g_24203 = args[1];
  V v_params_24189 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24204 = ({ V a_0 = v_params_24189; V a_1 = v_g_24203; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_params_24189); r_; });
  {
    V v_field_24206 = v_t_24204.f[1];
    int64_t v_tag_24205 = ((int64_t)v_t_24204.f[0]);
    if ((v_tag_24205 == ((int64_t)0ULL))) {
      V v_x_24207 = v_field_24206;
      heff_drop(v_x_24207);
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_24202, v_g_24203, NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_g_24203);
      heff_drop(v_field_24206);
      return v_m_24202;
    }
  }
}
V g_heff_2ecompile_2elower_2ecKept_lam5(V self, V *args) {
  V v_m_24217 = args[0];
  V v_g_24218 = args[1];
  V v_d_24200 = heff_env(self)[0];
  HeffT2 v_t_24219 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_24217, v_g_24218));
  {
    V v_field_24221 = v_t_24219.f[1];
    int64_t v_tag_24220 = ((int64_t)v_t_24219.f[0]);
    V v_t_24223;
    if ((v_tag_24220 == ((int64_t)0ULL))) {
      V v_x_24222 = v_field_24221;
      v_t_24223 = v_x_24222;
    } else {
      heff_drop(v_field_24221);
      v_t_24223 = NTAG(TAG_Nil);
    }
    heff_clo_take(self, 1);
    V v_t_24224 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_d_24200, 0, 3), v_t_24223});
    return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_24217, v_g_24218, v_t_24224));
  }
}
V g_heff_2ecompile_2elower_2ecKept_lam3(V self, V *args) {
  V v_sc_24187 = args[0];
  V v_d_24188 = args[1];
  V v_params_24183 = heff_env(self)[0];
  V v_scans_24165 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_params_24189 = v_params_24183;
  V v_sc_24190 = v_sc_24187;
  V v_d_24191 = heff_dup(v_d_24188);
  HeffT2 v_t_24192 = ({ V a_0 = v_scans_24165; V b_1 = heff_get_n(v_d_24188, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_scans_24165); heff_drop(b_1); r_; });
  {
    V v_field_24194 = v_t_24192.f[1];
    int64_t v_tag_24193 = ((int64_t)v_t_24192.f[0]);
    V v_s_24196;
    if ((v_tag_24193 == ((int64_t)0ULL))) {
      V v_x_24195 = v_field_24194;
      v_s_24196 = v_x_24195;
    } else {
      heff_drop(v_field_24194);
      v_s_24196 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get());
    }
    V v_ints_24197 = heff_take_field(v_s_24196, 3);
    V v_calls_24198 = heff_get_n(v_s_24196, 2, 5);
    V v_sc_24199 = v_sc_24190;
    V v_d_24200 = v_d_24191;
    V v_ints_24201 = v_ints_24197;
    V v_m_24208 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam4, 2, 1, (V[]){v_params_24189}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_calls_24198; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_calls_24198); r_; });
    V v_t_24209 = ({ V a_0 = v_m_24208; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_24208); r_; });
    V v_gs_24210 = (g_list_2emap_24s1937570095x2110149801(v_t_24209));
    switch (heff_tag_of(v_gs_24210)) {
    case TAG_Nil: {
      V v_t_24211 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_sc_24199, 0), heff_dup(heff_rfield(v_d_24200, 0)), heff_dup(v_d_24200)));
      V v_t_24212;
      if ((heff_dup(v_ints_24201) == NTAG(TAG_True))) {
        heff_drop(v_ints_24201);
        v_t_24212 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_sc_24199, 3)), heff_get_n(v_d_24200, 0, 3), NTAG(TAG_MkUnit)));
      } else {
        heff_drop_rec(v_d_24200, 3);
        heff_drop(v_ints_24201);
        v_t_24212 = heff_dup(heff_rfield(v_sc_24199, 3));
      }
      return ({ V rv_0 = v_t_24211; V rv_3 = v_t_24212; V rr_ = heff_rec_reuse_nf(v_sc_24199, 6ULL, 4, shape_byKey__callers__callersOf__ints, 60u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
    }
    case TAG_Cons: {
      V v_t_24215 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_sc_24199, 0), heff_dup(heff_rfield(v_d_24200, 0)), heff_dup(v_d_24200)));
      V v_t_24216 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_sc_24199, 1), heff_dup(heff_rfield(v_d_24200, 0)), heff_dup(v_gs_24210)));
      V v_t_24225 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecKept_lam5, 2, 1, (V[]){heff_dup(v_d_24200)}); V a_1 = heff_take_field(v_sc_24199, 2); V a_2 = v_gs_24210; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop_tag(v_gs_24210, 2); r_; });
      V v_t_24226;
      if ((heff_dup(v_ints_24201) == NTAG(TAG_True))) {
        heff_drop(v_ints_24201);
        v_t_24226 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_sc_24199, 3)), heff_get_n(v_d_24200, 0, 3), NTAG(TAG_MkUnit)));
      } else {
        heff_drop_rec(v_d_24200, 3);
        heff_drop(v_ints_24201);
        v_t_24226 = heff_dup(heff_rfield(v_sc_24199, 3));
      }
      return ({ V rv_0 = v_t_24215; V rv_1 = v_t_24216; V rv_2 = v_t_24225; V rv_3 = v_t_24226; V rr_ = heff_rec_reuse_nf(v_sc_24199, 0ULL, 4, shape_byKey__callers__callersOf__ints, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    }
    default: return heff_nomatch(v_gs_24210);
    }
  }
}
V g_heff_2ecompile_2elower_2ecKept_lam6(V self, V *args) {
  V v_k_24232 = args[0];
  V v_params_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24233 = ({ V a_0 = v_params_24186; V a_1 = v_k_24232; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_params_24186); heff_drop(v_k_24232); r_; });
  {
    V v_field_24235 = v_t_24233.f[1];
    int64_t v_tag_24234 = ((int64_t)v_t_24233.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24234 == ((int64_t)0ULL)) ? ({ V v_x_24236 = heff_dup(v_field_24235); int c_ = 0; heff_drop(v_x_24236); c_; }) : 1));
    heff_drop(v_field_24235);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2ecKept_lam7(V self, V *args) {
  V v_d_24254 = args[0];
  V v_sc_24247 = heff_env(self)[0];
  V v_params_24253 = heff_env(self)[1];
  V v_consts_24246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_24255 = ({ V b_0 = heff_get_n(v_sc_24247, 3, 4); V a_1 = heff_rfield(v_d_24254, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_24257 = v_t_24255.f[1];
    int64_t v_tag_24256 = ((int64_t)v_t_24255.f[0]);
    if ((v_tag_24256 == ((int64_t)0ULL))) {
      V v_x_24258 = v_field_24257;
      heff_drop(v_x_24258);
      V v_c_24259 = heff_rec_n(3, shape_params__consts__marking, (V[]){v_params_24253, v_consts_24246, NTAG(TAG_False)});
      V v_d_24260 = heff_dup(v_d_24254);
      V v_body_24261 = heff_take_field(v_d_24260, 2);
      V v_key_24262 = heff_get_n(v_d_24260, 0, 3);
      V v_t_24263 = heff_dup(v_body_24261);
      V v_body_24283;
      switch (heff_tag_of(v_t_24263)) {
      case TAG_ELam: {
        V v_xs_24264 = heff_field(v_t_24263, 0);
        V v_b_24265 = heff_field(v_t_24263, 1);
        V v_ru_24t_24263_24ELam = heff_take_reuse_n(v_t_24263, 3ULL, 2);
        heff_drop(v_body_24261);
        HeffT2 v_t_24266 = ({ V a_0 = heff_rfield(v_c_24259, 0); V a_1 = v_key_24262; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_key_24262); r_; });
        {
          V v_field_24268 = v_t_24266.f[1];
          int64_t v_tag_24267 = ((int64_t)v_t_24266.f[0]);
          V v_t_24271;
          if ((v_tag_24267 == ((int64_t)0ULL))) {
            V v_rs_24269 = v_field_24268;
            V v_t_24270 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_24264), v_rs_24269));
            v_t_24271 = ({ V a_0 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()); V a_1 = v_t_24270; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_24270); r_; });
          } else {
            heff_drop(v_field_24268);
            v_t_24271 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get());
          }
          V v_x1_24272 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_24259, v_t_24271, v_b_24265));
          V v_t_24277;
          switch (heff_tag_of(v_x1_24272)) {
          case TAG_MkRes: {
            V v_e_24274 = heff_field(v_x1_24272, 1);
            heff_take_n(v_x1_24272, 2ULL, 2);
            v_t_24277 = v_e_24274;
            break;
          }
          case TAG_MkResVals: {
            V v_e_24276 = heff_field(v_x1_24272, 1);
            heff_take_n(v_x1_24272, 2ULL, 2);
            v_t_24277 = v_e_24276;
            break;
          }
          default: heff_nomatch(v_x1_24272);
          }
          v_body_24283 = heff_tag_re_n(v_ru_24t_24263_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_24264, v_t_24277});
        }
        break;
      }
      default: {
        heff_drop(v_key_24262);
        heff_drop(v_t_24263);
        V v_x1_24278 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_24259, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), v_body_24261));
        switch (heff_tag_of(v_x1_24278)) {
        case TAG_MkRes: {
          V v_e_24280 = heff_field(v_x1_24278, 1);
          heff_take_n(v_x1_24278, 2ULL, 2);
          v_body_24283 = v_e_24280;
          break;
        }
        case TAG_MkResVals: {
          V v_e_24282 = heff_field(v_x1_24278, 1);
          heff_take_n(v_x1_24278, 2ULL, 2);
          v_body_24283 = v_e_24282;
          break;
        }
        default: heff_nomatch(v_x1_24278);
        }
        break;
      }
      }
      return ({ V rv_2 = v_body_24283; V rr_ = heff_rec_reuse_nf(v_d_24254, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      heff_drop(v_params_24253);
      heff_drop(v_consts_24246);
      heff_drop(v_field_24257);
      return v_d_24254;
    }
  }
}
V g_heff_2ecompile_2elower_2ecKept_lam8(V self, V *args) {
  V v_p_24296 = args[0];
  V v_tk_24291 = heff_env(self)[0];
  V v_t_24299;
  switch (heff_tag_of(v_p_24296)) {
  case TAG_MkPair: {
    V v_x_24297 = heff_dup(heff_field(v_p_24296, 0));
    v_t_24299 = v_x_24297;
    break;
  }
  default: heff_nomatch(v_p_24296);
  }
  heff_clo_take(self, 1);
  HeffT2 v_t_24300 = ({ V b_0 = heff_get_n(v_tk_24291, 1, 2); V a_1 = v_t_24299; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24299); r_; });
  {
    V v_field_24302 = v_t_24300.f[1];
    int64_t v_tag_24301 = ((int64_t)v_t_24300.f[0]);
    if ((v_tag_24301 == ((int64_t)0ULL))) {
      V v_x_24303 = v_field_24302;
      heff_drop(v_x_24303);
      V v_t_24306;
      switch (heff_tag_of(v_p_24296)) {
      case TAG_MkPair: {
        V v_x_24304 = heff_dup(heff_field(v_p_24296, 0));
        v_t_24306 = v_x_24304;
        break;
      }
      default: heff_nomatch(v_p_24296);
      }
      V v_t_24309;
      switch (heff_tag_of(v_p_24296)) {
      case TAG_MkPair: {
        V v_y_24308 = heff_field(v_p_24296, 1);
        heff_take_n(v_p_24296, 2ULL, 2);
        v_t_24309 = v_y_24308;
        break;
      }
      default: heff_nomatch(v_p_24296);
      }
      V v_t_24310 = (g_list_2ekeepIf_24s512765522x2052101617(MK_INT(0LL), v_t_24309));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24306, v_t_24310});
    } else {
      heff_drop(v_field_24302);
      return v_p_24296;
    }
  }
}
Clo g_heff_2ecompile_2elower_2efindDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efindDef_entry, 2, 0};

V g_heff_2ecompile_2elower_2efindDef(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_ds_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_d_242, 0)), heff_dup(v_k_240))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_d_242)});
    } else {
      V t_0 = v_k_240;
      V t_1 = v_ds_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2elower_2efindDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2elower_2efindDef(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2elower_2eredoErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eredoErased_entry, 4, 0};

V g_heff_2ecompile_2elower_2eredoErased(V v_k_240, V v_uk_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    heff_drop(v_k_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_242});
  }
  case TAG_Right: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    heff_drop(v_n_242);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_body_246 = heff_field(v_x41_245, 0);
      V v_n2_247 = heff_field(v_x41_245, 1);
      HeffT2 v_t_248 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), heff_dup(v_body_246)}), heff_dup(v_body_246)));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_b_2411 = v_field_249;
        V v_acc_2412 = v_field_2410;
        V v_defs_2413 = (g_heff_2ecompile_2elift_2eordered(heff_get_n(v_acc_2412, 0, 2), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), v_k_240, v_b_2411})));
        V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2413));
        V v_t_2415 = (g_list_2efoldl_24s644510009x1719377493(NTAG(TAG_Nil), v_t_2414));
        V v_t_2416 = ({ V a_0 = v_uk_241; V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2elower_2efindDef(a_0, a_1)); heff_drop(v_t_2415); r_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, heff_dup(v_n2_247)});
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2elower_2eredoErased(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryPieces_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryPieces_str1, 0, "");
Clo g_heff_2ecompile_2elower_2eentryPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryPieces_entry, 6, 0};

V g_heff_2ecompile_2elower_2eentryPieces(V v_due_240, V v_w_241, V v_vers_242, V v_ks_243, V v_key_244, V v_n_245) {
top: ;
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_ks_243, 0, 2); V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_it1_249 = v_field_248;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_MkPair: {
        V v_v_2410 = heff_field(v_it1_249, 0);
        V v_us_2411 = heff_field(v_it1_249, 1);
        V v_ru_24it1_249_24MkPair = heff_take_reuse_n(v_it1_249, 3ULL, 2);
        V v_t_2425;
        if (heff_strEq_c_lent(v_v_2410, ((V)&g_heff_2ecompile_2elower_2eentryPieces_str0), 2)) {
          heff_drop(v_v_2410);
          v_t_2425 = NTAG(TAG_False);
        } else {
          HeffT2 v_t_2412 = ({ V a_0 = v_vers_242; V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          V v_t_2428;
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_x_2415 = v_field_2414;
              v_t_2428 = v_x_2415;
            } else {
              heff_drop(v_field_2414);
              v_t_2428 = ((V)&g_heff_2ecompile_2elower_2eentryPieces_str1);
            }
          }
          v_t_2425 = heff_strEq(v_v_2410, v_t_2428);
        }
        switch (heff_tag_of(v_t_2425)) {
        case TAG_True: {
          heff_drop(v_n_245);
          return (g_list_2emap_24s136093287x730789464_24tok2(v_ru_24it1_249_24MkPair, v_due_240, v_w_241, v_key_244, v_us_2411));
        }
        case TAG_False: {
          heff_drop(v_us_2411);
          V v_body_2416;
          switch (heff_tag_of(v_due_240)) {
          case TAG_NoCustody: {
            v_body_2416 = (g_heff_2ecompile_2elower_2eentryCps(v_w_241, v_key_244, v_n_245));
            break;
          }
          case TAG_Reading: {
            v_body_2416 = (g_heff_2ecompile_2elower_2eentryReading(v_w_241, v_key_244, v_n_245));
            break;
          }
          default: heff_nomatch(v_due_240);
          }
          V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_body_2416)));
          V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
          V v_t_2419 = heff_tag_n(TAG_Fresh, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_2416})});
          return heff_tag_at_n(v_ru_24it1_249_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2419, v_t_2418}), NTAG(TAG_Nil)});
        }
        default: return heff_nomatch(v_t_2425);
        }
      }
      default: return heff_nomatch(v_it1_249);
      }
    } else {
      heff_drop(v_field_248);
      V v_body_2420;
      switch (heff_tag_of(v_due_240)) {
      case TAG_NoCustody: {
        v_body_2420 = (g_heff_2ecompile_2elower_2eentryCps(v_w_241, v_key_244, v_n_245));
        break;
      }
      case TAG_Reading: {
        v_body_2420 = (g_heff_2ecompile_2elower_2eentryReading(v_w_241, v_key_244, v_n_245));
        break;
      }
      default: heff_nomatch(v_due_240);
      }
      V v_t_2421 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_body_2420)));
      V v_t_2422 = (g_heff_2ecompile_2eir_2enubI(v_t_2421));
      V v_t_2423 = heff_tag_n(TAG_Fresh, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_2420})});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2423, v_t_2422}), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2elower_2eentryPieces_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2elower_2eentryPieces(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2elower_2eunitOut_24cpr(V v_sg_240, V v_dm_241, V v_p_242) {
top: ;
  V v_key_243 = heff_take_field(v_p_242, 1);
  V v_name_244 = heff_take_field(v_p_242, 2);
  V v_refs_245 = heff_get_n(v_p_242, 4, 5);
  V v_safe_246 = heff_take_field(v_sg_240, 0);
  V v_total_247 = heff_get_n(v_sg_240, 1, 2);
  HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_dm_241, v_key_243));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_d_2411 = v_field_2410;
      HeffT2 v_t_2412 = ({ V a_0 = v_safe_246; V a_1 = v_key_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_safe_246); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        V v_t_2416 = heff_bool(((v_tag_2413 == ((int64_t)0ULL)) && ({ V v_x_2415 = heff_dup(v_field_2414); int c_ = 1; heff_drop(v_x_2415); c_; })));
        heff_drop(v_field_2414);
        HeffT2 v_t_2417 = ({ V a_0 = v_total_247; V a_1 = v_key_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_total_247); heff_drop(v_key_243); r_; });
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          V v_t_2421;
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_x_2420 = v_field_2419;
            v_t_2421 = v_x_2420;
          } else {
            heff_drop(v_field_2419);
            v_t_2421 = MK_INT(-1LL);
          }
          V v_f_2422 = heff_rec_n(5, shape_done__name__refs__sgSafe__sgTotal, (V[]){v_d_2411, v_name_244, v_refs_245, v_t_2416, v_t_2421});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
        }
      }
    } else {
      heff_drop(v_key_243);
      heff_drop(v_name_244);
      heff_drop(v_refs_245);
      heff_drop(v_safe_246);
      heff_drop(v_total_247);
      heff_drop(v_field_2410);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ecompile_2elower_2egroupGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2egroupGo_entry, 1, 0};

V g_heff_2ecompile_2elower_2egroupGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_ps_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_p_243 = v_p_241;
    V v_gs_244 = (g_heff_2ecompile_2elower_2egroupGo(v_ps_242));
    switch (heff_tag_of(v_gs_244)) {
    case TAG_Nil: {
      V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_gs_244});
    }
    case TAG_Cons: {
      V v_gs1_246 = heff_dup(heff_field(v_gs_244, 0));
      switch (heff_tag_of(v_gs1_246)) {
      case TAG_Nil: {
        V v_t_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_gs_244});
      }
      case TAG_Cons: {
        V v_q_249 = heff_field(v_gs1_246, 0);
        V v_qs_2410 = heff_field(v_gs1_246, 1);
        V v_ru_24gs1_246_24Cons = heff_take_reuse_n(v_gs1_246, 3ULL, 2);
        switch (heff_tag_of(v_gs_244)) {
        case TAG_Cons: {
          V v_rest_2412 = heff_field(v_gs_244, 1);
          V v_ru_24gs_244_24Cons = heff_take_reuse_n(v_gs_244, 2ULL, 2);
          if (heff_strEq_c(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_q_249, 0)))) {
            V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, heff_tag_re_n(v_ru_24gs1_246_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_q_249, v_qs_2410})});
            return heff_tag_re_n(v_ru_24gs_244_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_t_2413, v_rest_2412});
          } else {
            V v_t_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_243, NTAG(TAG_Nil)});
            V v_t_2415 = heff_tag_at_n(v_ru_24gs1_246_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24gs_244_24Cons, TAG_Cons, 2, (V[]){v_q_249, v_qs_2410}), v_rest_2412});
            return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2415});
          }
        }
        default: return heff_nomatch(v_gs_244);
        }
      }
      default: return heff_nomatch(v_gs1_246);
      }
    }
    default: return heff_nomatch(v_gs_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2egroupGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2egroupGo(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str5, 0, "");
V g_heff_2ecompile_2elower_2egroupOut_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam4(V self, V *args);
Clo g_heff_2ecompile_2elower_2egroupOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2egroupOut_entry, 4, 0};

V g_heff_2ecompile_2elower_2egroupOut(V v_vers_240, V v_sg_241, V v_dm_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sg_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ps_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_240, heff_rfield(v_p_244, 0)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2410;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_248);
        v_t_2410 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str0);
      }
      if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ecompile_2elower_2egroupOut_str1))) {
        heff_drop(v_sg_241);
        heff_drop_rec(v_p_244, 5);
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        return NTAG(TAG_Nothing);
      } else {
        HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_dm_242, heff_rfield(v_p_244, 1)));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2414 = v_field_2413;
            heff_drop(v_x_2414);
            V v_p_2421 = heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam0, 1, 2, (V[]){heff_dup(v_sg_241), heff_dup(v_dm_242)});
            V v_t_2422 = heff_tr(heff_call(heff_dup(v_p_2421), 1, (V[]){heff_dup(v_p_244)}));
            if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
              heff_drop(v_t_2422);
              V v_x1_2423 = (g_list_2eall(v_p_2421, v_ps_245));
              if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
                heff_drop(v_sg_241);
                heff_drop_rec(v_p_244, 5);
                heff_drop(v_ps_245);
                heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                heff_drop(v_x1_2423);
                return NTAG(TAG_Nothing);
              } else {
                heff_drop(v_x1_2423);
                HeffT2 v_t_2424 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_240, heff_rfield(v_p_244, 0)));
                {
                  V v_field_2426 = v_t_2424.f[1];
                  int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
                  V v_t_2428;
                  if ((v_tag_2425 == ((int64_t)0ULL))) {
                    V v_x_2427 = v_field_2426;
                    v_t_2428 = v_x_2427;
                  } else {
                    heff_drop(v_field_2426);
                    v_t_2428 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str3);
                  }
                  V v_t_2429 = (g_heff_2ecompile_2elower_2eunitOut(heff_dup(v_sg_241), v_dm_242, heff_dup(v_p_244)));
                  V v_t_2432 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam1, 1, 2, (V[]){v_sg_241, heff_dup(v_dm_242)}), v_ps_245));
                  V v_t_2433 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_p_244, 1)), v_t_2429});
                  V v_t_2434 = heff_rec_n(3, shape_owner__ver__units, (V[]){heff_get_n(v_p_244, 0, 5), v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2432})});
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2434});
                }
              }
            } else {
              heff_drop(v_sg_241);
              heff_drop_rec(v_p_244, 5);
              heff_drop(v_ps_245);
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              heff_drop_clo(v_p_2421, 2);
              heff_drop(v_t_2422);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_field_2413);
            V v_x1_2440 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam2, 1, 1, (V[]){heff_dup(v_dm_242)}), v_ps_245));
            if (!(heff_dup(v_x1_2440) == NTAG(TAG_True))) {
              heff_drop(v_sg_241);
              heff_drop_rec(v_p_244, 5);
              heff_drop(v_ps_245);
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              heff_drop(v_x1_2440);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_x1_2440);
              V v_p_2447 = heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam3, 1, 2, (V[]){heff_dup(v_sg_241), heff_dup(v_dm_242)});
              V v_t_2448 = heff_tr(heff_call(heff_dup(v_p_2447), 1, (V[]){heff_dup(v_p_244)}));
              if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
                heff_drop(v_t_2448);
                V v_x1_2449 = (g_list_2eall(v_p_2447, v_ps_245));
                if (!(heff_dup(v_x1_2449) == NTAG(TAG_True))) {
                  heff_drop(v_sg_241);
                  heff_drop_rec(v_p_244, 5);
                  heff_drop(v_ps_245);
                  heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                  heff_drop(v_x1_2449);
                  return NTAG(TAG_Nothing);
                } else {
                  heff_drop(v_x1_2449);
                  HeffT2 v_t_2450 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_240, heff_rfield(v_p_244, 0)));
                  {
                    V v_field_2452 = v_t_2450.f[1];
                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                    V v_t_2454;
                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                      V v_x_2453 = v_field_2452;
                      v_t_2454 = v_x_2453;
                    } else {
                      heff_drop(v_field_2452);
                      v_t_2454 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str5);
                    }
                    V v_t_2455 = (g_heff_2ecompile_2elower_2eunitOut(heff_dup(v_sg_241), v_dm_242, heff_dup(v_p_244)));
                    V v_t_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam4, 1, 2, (V[]){v_sg_241, heff_dup(v_dm_242)}), v_ps_245));
                    V v_t_2459 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_p_244, 1)), v_t_2455});
                    V v_t_2460 = heff_rec_n(3, shape_owner__ver__units, (V[]){heff_get_n(v_p_244, 0, 5), v_t_2454, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_t_2458})});
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2460});
                  }
                }
              } else {
                heff_drop(v_sg_241);
                heff_drop_rec(v_p_244, 5);
                heff_drop(v_ps_245);
                heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                heff_drop_clo(v_p_2447, 2);
                heff_drop(v_t_2448);
                return NTAG(TAG_Nothing);
              }
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2elower_2egroupOut(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2elower_2egroupOut_lam0(V self, V *args) {
  V v_q_2415 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = v_q_2415; HeffT2 r_ = (g_heff_2ecompile_2elower_2eunitOut_24cpr(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_u_2419 = v_field_2418;
      V v_t_2420 = heff_get_n(heff_get_n(v_u_2419, 0, 5), 3, 4);
      return ({ V b_0 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str2); V a_1 = v_t_2420; V r_ = (g_list_2eall_24s44244667x1445755514(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2420); r_; });
    } else {
      heff_drop(v_field_2418);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam1(V self, V *args) {
  V v_q_2430 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = heff_dup(v_q_2430); V r_ = (g_heff_2ecompile_2elower_2eunitOut(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_q_2430, 1, 5), v_t_2431});
}
V g_heff_2ecompile_2elower_2egroupOut_lam2(V self, V *args) {
  V v_q_2435 = args[0];
  V v_dm_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2436 = ({ V a_0 = v_dm_242; V b_1 = heff_get_n(v_q_2435, 1, 5); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_dm_242); heff_drop(b_1); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2437 == ((int64_t)0ULL)) && ({ V v_x_2439 = heff_dup(v_field_2438); int c_ = 1; heff_drop(v_x_2439); c_; })));
    heff_drop(v_field_2438);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam3(V self, V *args) {
  V v_q_2441 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2442 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = v_q_2441; HeffT2 r_ = (g_heff_2ecompile_2elower_2eunitOut_24cpr(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_u_2445 = v_field_2444;
      V v_t_2446 = heff_get_n(heff_get_n(v_u_2445, 0, 5), 3, 4);
      return ({ V b_0 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str4); V a_1 = v_t_2446; V r_ = (g_list_2eall_24s44244667x1445755514(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2446); r_; });
    } else {
      heff_drop(v_field_2444);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam4(V self, V *args) {
  V v_q_2456 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = heff_dup(v_q_2456); V r_ = (g_heff_2ecompile_2elower_2eunitOut(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_q_2456, 1, 5), v_t_2457});
}
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str2, 6, "entry/");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str3, 10, "entry-due/");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str5, 1, "/");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str6, 0, "");
V g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_lam0(V self, V *args);

HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V v_due_240, V v_w_241, V v_g_242, V v_key_243, V v_vers_244, V v_ks_245) {
top: ;
  V v_due_246 = heff_dup(v_due_240);
  V v_w_247 = heff_dup(v_w_241);
  HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_244, v_key_243));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_t_2416;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_v_2411 = v_field_2410;
      if (heff_strEq_c_lent(v_v_2411, ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str0), 2)) {
        heff_drop(v_due_240);
        heff_drop(v_w_241);
        heff_drop(v_v_2411);
        v_t_2416 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str1);
      } else {
        V v_t_2412;
        switch (heff_tag_of(v_due_240)) {
        case TAG_NoCustody: {
          v_t_2412 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str2);
          break;
        }
        case TAG_Reading: {
          v_t_2412 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str3);
          break;
        }
        default: heff_nomatch(v_due_240);
        }
        V v_t_2415;
        switch (heff_tag_of(v_w_241)) {
        case TAG_Nothing: {
          v_t_2415 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str4);
          break;
        }
        case TAG_Just: {
          V v_w_2413 = heff_field(v_w_241, 0);
          heff_take_n(v_w_241, 1ULL, 1);
          V v_t_2414 = ({ V a_0 = v_w_2413; V r_ = (g_heff_2ecompile_2elower_2eshapeSaid(a_0)); heff_drop(v_w_2413); r_; });
          v_t_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str5));
          break;
        }
        default: heff_nomatch(v_w_241);
        }
        v_t_2416 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2415), v_v_2411);
      }
    } else {
      heff_drop(v_due_240);
      heff_drop(v_w_241);
      heff_drop(v_field_2410);
      v_t_2416 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_str6);
    }
    V v_vers_2417 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(v_vers_244), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2416));
    V v_ks_2418 = heff_dup(v_ks_245);
    V v_key_2419 = v_key_243;
    V v_t_2426 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_lam0, 2, 1, (V[]){heff_dup(v_g_242)}), NTAG(TAG_Nil), heff_rfield(v_g_242, 0)));
    V v_t_2427 = heff_rec_n(3, shape_pieces__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
    V v_acc_2428 = ({ V a_0 = v_g_242; V a_1 = v_vers_244; V a_2 = v_ks_245; V a_3 = v_t_2427; V a_4 = v_t_2426; V r_ = (g_list_2efoldl_24s1579438642x567671990(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_vers_244); heff_drop(v_t_2426); r_; });
    V v_errors_2429 = heff_take_field(v_acc_2428, 1);
    V v_supply_2430 = heff_take_field(v_acc_2428, 2);
    V v_pieces_2431 = heff_get_n(v_acc_2428, 0, 3);
    V v_errors_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_errors_2429));
    V v_t_2435;
    switch (heff_tag_of(v_w_247)) {
    case TAG_Nothing: {
      v_t_2435 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_w_2433 = heff_dup(heff_field(v_w_247, 0));
      V v_t_2434 = (g_heff_2ecompile_2elower_2edispatchDefs(v_w_2433, MK_INT(0LL), MK_INT(0LL)));
      v_t_2435 = (g_list_2emap_24s509077117x607152875(v_t_2434));
      break;
    }
    default: heff_nomatch(v_w_247);
    }
    V v_t_2436 = (g_heff_2ecompile_2elower_2eentryPieces(v_due_246, v_w_247, v_vers_2417, heff_dup(v_ks_2418), v_key_2419, heff_dup(v_supply_2430)));
    V v_xs_2437 = (g_heff_2ecompile_2elower_2erevOnto(v_t_2436, v_pieces_2431));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2437));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2438));
    V v_ps_2440 = (g_heff_2ecompile_2elower_2ereachedPieces(v_t_2439));
    V v_errors_2441 = v_errors_2432;
    V v_vers_2442 = v_vers_2417;
    V v_ks_2443 = v_ks_2418;
    V v_n_2444 = heff_intAdd(v_supply_2430, MK_INT(16LL));
    V v_ps_2445 = heff_dup(v_ps_2440);
    V v_items_2446 = (g_list_2emap_24s510639937x1058700299(v_ps_2440));
    V v_sg_2447 = ({ V a_0 = heff_dup(g_heff_2ecompile_2esimplify_2esimplifyProgram_24rec0_get()); V a_1 = v_items_2446; V r_ = (g_list_2efoldl_24s2070597502x591087275(a_0, a_1)); heff_drop(v_items_2446); r_; });
    V v_t_2448 = (g_heff_2ecompile_2elower_2eunitVers(v_vers_2442, v_ps_2445));
    V v_t_2449 = (g_list_2emap_24s510639937x1058700299(heff_dup(v_ps_2445)));
    V v_si_2450 = (g_heff_2ecompile_2esimplify_2esimplifyItems(v_n_2444, heff_dup(v_sg_2447), v_t_2448, heff_get_n(v_ks_2443, 1, 2), v_t_2449));
    V v_t_2451 = (g_list_2efoldl_24s1499934538x170225690(heff_dup(g_std_2eordmap_2eempty_get()), heff_rfield(v_si_2450, 2)));
    V v_t_2452 = (g_heff_2ecompile_2elower_2egroupGo(v_ps_2445));
    V v_t_2453 = ({ V a_0 = v_vers_2442; V a_1 = v_sg_2447; V a_2 = v_t_2451; V a_3 = v_t_2452; V r_ = (g_list_2emap_24s1985010810x1780722131(a_0, a_1, a_2, a_3)); heff_drop(v_vers_2442); heff_drop(v_t_2451); r_; });
    V v_t_2454 = (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2453));
    V v_f_2455 = heff_dup(heff_rfield(v_si_2450, 3));
    return ((HeffT4){{v_si_2450, v_errors_2441, v_t_2454, v_f_2455}});
  }
}
V g_heff_2ecompile_2elower_2elowerProgramKept_24cpr_lam0(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2422 = ({ V b_0 = heff_get_n(v_g_242, 1, 8); V a_1 = v_k_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_e_2425 = v_field_2424;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2421, v_e_2425}), v_acc_2420});
    } else {
      heff_drop(v_k_2421);
      heff_drop(v_field_2424);
      return v_acc_2420;
    }
  }
}
Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerProgramKept_entry, 6, 0};

V g_heff_2ecompile_2elower_2elowerProgramKept(V v_due_240, V v_w_241, V v_g_242, V v_key_243, V v_vers_244, V v_ks_245) {
top: ;
  HeffT4 v_t_246 = (g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(v_due_240, v_w_241, v_g_242, v_key_243, v_vers_244, v_ks_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_field_249 = v_t_246.f[2];
    V v_field_2410 = v_t_246.f[3];
    return heff_rec_n(4, shape_simplified__errors__groups__copies, (V[]){v_field_247, v_field_248, v_field_249, v_field_2410});
  }
}
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerProgramKept(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_entry, 3, 0};

V g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937(V v_lit_240, V v_fuel_241, V v_sk_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr(v_lit_240, v_fuel_241, v_sk_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    return heff_rec_n(3, shape_lowered__groups__copies, (V[]){v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str1, 0, "");
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_entry, 4, 0};

V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(V v_g_240, V v_vers_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_k_244 = heff_field(v_x5_243, 0);
    V v_e_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_245, 3))));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_k_244);
      heff_drop_rec(v_e_245, 4);
      heff_drop_cell(v_ru_24x5_243_24MkPair, 2);
      heff_drop(v_t_246);
      return v_acc_242;
    } else {
      heff_drop(v_t_246);
      HeffT2 v_t_247 = ({ V b_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_k_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_it1_2410 = v_field_249;
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_MkPair: {
            V v_v_2411 = heff_field(v_it1_2410, 0);
            V v_us_2412 = heff_field(v_it1_2410, 1);
            heff_take_n(v_it1_2410, 3ULL, 2);
            V v_t_2426;
            if (heff_strEq_c_lent(v_v_2411, ((V)&g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str0), 2)) {
              heff_drop(v_v_2411);
              v_t_2426 = NTAG(TAG_False);
            } else {
              HeffT2 v_t_2413 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_241, v_k_244));
              V v_t_2429;
              {
                V v_field_2415 = v_t_2413.f[1];
                int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  V v_x_2416 = v_field_2415;
                  v_t_2429 = v_x_2416;
                } else {
                  heff_drop(v_field_2415);
                  v_t_2429 = ((V)&g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_str1);
                }
              }
              v_t_2426 = heff_strEq(v_v_2411, v_t_2429);
            }
            switch (heff_tag_of(v_t_2426)) {
            case TAG_True: {
              heff_drop_cell(v_ru_24x5_243_24MkPair, 2);
              V v_t_2422 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_242, 0), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam0, 1, 3, (V[]){v_k_244, v_g_240, v_e_245}), v_us_2412));
              return ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_acc_242, 6ULL, 3, shape_pieces__errors__supply, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            }
            case TAG_False: {
              heff_drop(v_us_2412);
              V v_t_2423 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_244), v_e_245, heff_dup(heff_rfield(v_acc_242, 2))));
              HEFF_LAST return g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_243_24MkPair, v_k_244, v_acc_242, v_t_2423);
            }
            default: return heff_nomatch(v_t_2426);
            }
          }
          default: return heff_nomatch(v_it1_2410);
          }
        } else {
          heff_drop(v_field_249);
          V v_t_2424 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_244), v_e_245, heff_dup(heff_rfield(v_acc_242, 2))));
          HEFF_LAST return g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_243_24MkPair, v_k_244, v_acc_242, v_t_2424);
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam1(V self, V *args) {
  V v_n_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_e_245 = heff_env(self)[2];
  V v_def_2418 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_244), v_e_245, heff_dup(v_n_2420)));
  return ({ V a_0 = v_k_244; V b_1 = heff_get_n(v_def_2418, 0, 7); V a_2 = v_n_2420; V a_3 = v_t_2421; V r_ = (g_heff_2ecompile_2elower_2eredoErased(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_t_2421); r_; });
}
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_e_245 = heff_env(self)[2];
  V v_def_2418 = heff_take_field(v_u_2417, 0);
  V v_refs_2419 = heff_get_n(v_u_2417, 1, 2);
  heff_clo_take(self, 3);
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(v_k_244), heff_dup(heff_rfield(v_def_2418, 0)), heff_dup(heff_rfield(v_def_2418, 1)), heff_tag_n(TAG_Kept, 2, (V[]){heff_dup(v_def_2418), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_lam1, 1, 4, (V[]){v_g_240, v_k_244, v_e_245, v_def_2418})}), v_refs_2419});
}
HEFF_LIT(g_heff_2ecompile_2elower_2eerasedPieces_24tok2_str0, 2, ": ");
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eerasedPieces_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry, 4, 0};

V g_heff_2ecompile_2elower_2eerasedPieces_24tok2(V v_tok_240, V v_k_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Left: {
    V v_err_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    V v_t_245 = heff_strAppend(heff_strAppend(v_k_241, ((V)&g_heff_2ecompile_2elower_2eerasedPieces_24tok2_str0)), v_err_244);
    V v_t_246 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_245, heff_dup(heff_rfield(v_acc_242, 1))});
    return ({ V rv_1 = v_t_246; V rr_ = heff_rec_reuse_nf(v_acc_242, 5ULL, 3, shape_pieces__errors__supply, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Right: {
    V v_x31_247 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_body_248 = heff_field(v_x31_247, 0);
      V v_n_249 = heff_field(v_x31_247, 1);
      heff_take_n(v_x31_247, 3ULL, 2);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_241), heff_dup(v_k_241), heff_dup(v_body_248)}), v_body_248));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_b_2413 = v_field_2411;
        V v_acc_2414 = v_field_2412;
        V v_defs_2415 = (g_heff_2ecompile_2elift_2eordered(heff_get_n(v_acc_2414, 0, 2), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_241), heff_dup(v_k_241), v_b_2413})));
        V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2415));
        V v_t_2417 = (g_list_2efoldl_24s644510009x1719377493(NTAG(TAG_Nil), v_t_2416));
        V v_t_2421 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_242, 0), heff_clo_n(g_heff_2ecompile_2elower_2eerasedPieces_24tok2_lam0, 1, 1, (V[]){v_k_241}), v_t_2417));
        return ({ V rv_0 = v_t_2421; V rv_2 = v_n_249; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 3, shape_pieces__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eerasedPieces_24tok2(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_lam0(V self, V *args) {
  V v_d_2418 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_t_2419 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_2418, 2))));
  V v_t_2420 = (g_heff_2ecompile_2eir_2enubI(v_t_2419));
  heff_clo_take(self, 1);
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){v_k_241, heff_dup(heff_rfield(v_d_2418, 0)), heff_dup(heff_rfield(v_d_2418, 1)), heff_tag_n(TAG_Fresh, 1, (V[]){v_d_2418}), v_t_2420});
}