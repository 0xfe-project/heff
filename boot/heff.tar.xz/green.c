// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Finish 61316
#define TAG_Main 39920
#define TAG_MkGroup 19195
#define TAG_NewChan 9424
#define TAG_Other 45236
#define TAG_RAct 26891
#define TAG_RDone 16778
#define TAG_RNew 39449
#define TAG_RRecv 30762
#define TAG_RSend 60876
#define TAG_RSpawn 40406
#define TAG_RYield 3356
#define TAG_Recv 61489
#define TAG_SAct 56682
#define TAG_SEnd 60851
#define TAG_SFinal 20030
#define TAG_SNew 3714
#define TAG_SNext 49456
#define TAG_SRecv 36919
#define TAG_SSend 1507
#define TAG_SSpawn 34695
#define TAG_SYield 63171
#define TAG_Send 26077
#define TAG_Spawn 10053
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Yield 38529
#define LBL_back 9511342
#define LBL_chans 295981947
#define LBL_fmap 9641981
#define LBL_front 299063875
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_next 9873338
#define LBL_pending 1696753626
#define LBL_ready 309745085
#define LBL_turns 312085424
#define LBL_waiting 1348170899
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_front__back[] = {LBL_front, LBL_back};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_ready__chans__waiting__next__pending__turns[] = {LBL_ready, LBL_chans, LBL_waiting, LBL_next, LBL_pending, LBL_turns};
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void);
V g_co_2eop_24s1997951166x681497643(V, V, V);
V g_co_2eop_24s1997951166x681497643_entry(V self, V *a);
extern Clo g_co_2eop_24s1997951166x681497643_clo;
V g_co_2eop_24s293084245x615760588(V, V, V);
V g_co_2eop_24s293084245x615760588_entry(V self, V *a);
extern Clo g_co_2eop_24s293084245x615760588_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_green_2ealone_24s896371827x11544689(V);
V g_green_2ealone_24s896371827x11544689_entry(V self, V *a);
extern Clo g_green_2ealone_24s896371827x11544689_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s1072496561x430638721(V, V, V);
V g_green_2ego_24s1072496561x430638721_entry(V self, V *a);
extern Clo g_green_2ego_24s1072496561x430638721_clo;
V g_green_2egreen_get(void);
V g_green_2egreenAlg_24s854873557x32656427(V);
V g_green_2egreenAlg_24s854873557x32656427_entry(V self, V *a);
extern Clo g_green_2egreenAlg_24s854873557x32656427_clo;
HeffT2 g_green_2etakeQ_24cpr(V);
V g_green_2ethenRes_24s2092633126x465472411(V, V);
V g_green_2ethenRes_24s2092633126x465472411_entry(V self, V *a);
extern Clo g_green_2ethenRes_24s2092633126x465472411_clo;
V g_green_2eview_24s1017855520x282345245(V);
V g_green_2eview_24s1017855520x282345245_entry(V self, V *a);
extern Clo g_green_2eview_24s1017855520x282345245_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2062876492x2082655823(V, V);
V g_list_2efoldl_24s2062876492x2082655823_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
V g_green_2egreen_lam1(V self, V *args);
V g_green_2egreen_lam2(V self, V *args);
V g_green_2egreen_lam0(V self, V *args); static Clo g_green_2egreen_lam0_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreen_lam0, 3, 0};
V g_green_2egreen_lam3(V self, V *args); static Clo g_green_2egreen_lam3_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreen_lam3, 4, 0};

static V g_green_2egreen_val;
static HEFF_ONCE g_green_2egreen_st;
static V g_green_2egreen_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_green_2egreen_lam0_clo), ((V)&g_green_2egreen_lam3_clo)});
}
V g_green_2egreen_get(void) {
  if (HEFF_DONE(g_green_2egreen_st)) return g_green_2egreen_val;
  return heff_global(&g_green_2egreen_val, &g_green_2egreen_st, g_green_2egreen_init);
}
V g_green_2egreen_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tr(heff_call(v_k_248, 1, (V[]){v_n_249}));
  V f_ = v_g_241;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2egreen_lam2(V self, V *args) {
  V v_v_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_call(v_k_2416, 1, (V[]){v_v_2417}));
  V f_ = v_g_241;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2egreen_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Spawn: {
    V v_c_243 = heff_field(v_p_242, 0);
    V v_x_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Spawn = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_244}));
    return heff_tag_at_n(v_ru_24p_242_24Spawn, TAG_Spawn, 2, (V[]){v_c_243, v_t_245});
  }
  case TAG_Yield: {
    V v_x_246 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Yield = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_246}));
    return heff_tag_at_n(v_ru_24p_242_24Yield, TAG_Yield, 1, (V[]){v_t_247});
  }
  case TAG_NewChan: {
    V v_k_248 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24NewChan = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24NewChan, TAG_NewChan, 1, (V[]){heff_clo_n(g_green_2egreen_lam1, 1, 2, (V[]){v_k_248, v_g_241})});
  }
  case TAG_Send: {
    V v_ch_2411 = heff_field(v_p_242, 0);
    V v_v_2412 = heff_field(v_p_242, 1);
    V v_x_2413 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Send = heff_take_reuse_n(v_p_242, 7ULL, 3);
    V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
    return heff_tag_at_n(v_ru_24p_242_24Send, TAG_Send, 3, (V[]){v_ch_2411, v_v_2412, v_t_2414});
  }
  case TAG_Recv: {
    V v_ch_2415 = heff_field(v_p_242, 0);
    V v_k_2416 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Recv = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Recv, TAG_Recv, 2, (V[]){v_ch_2415, heff_clo_n(g_green_2egreen_lam2, 1, 2, (V[]){v_k_2416, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_green_2egreen_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  heff_drop(v_m_2419);
  heff_drop(v_n_2420);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_Spawn: {
    V v_c_2423 = heff_field(v_p_2422, 0);
    V v_x_2424 = heff_field(v_p_2422, 1);
    V v_ru_24p_2422_24Spawn = heff_take_reuse_n(v_p_2422, 3ULL, 2);
    V v_t_2425 = heff_tr(heff_call(v_nt_2421, 1, (V[]){v_c_2423}));
    return heff_tag_at_n(v_ru_24p_2422_24Spawn, TAG_Spawn, 2, (V[]){v_t_2425, v_x_2424});
  }
  case TAG_Yield: {
    V v_x_2426 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24Yield = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24Yield, TAG_Yield, 1, (V[]){v_x_2426});
  }
  case TAG_NewChan: {
    V v_k_2427 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24NewChan = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24NewChan, TAG_NewChan, 1, (V[]){v_k_2427});
  }
  case TAG_Send: {
    V v_ch_2428 = heff_field(v_p_2422, 0);
    V v_v_2429 = heff_field(v_p_2422, 1);
    V v_x_2430 = heff_field(v_p_2422, 2);
    V v_ru_24p_2422_24Send = heff_take_reuse_n(v_p_2422, 7ULL, 3);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24Send, TAG_Send, 3, (V[]){v_ch_2428, v_v_2429, v_x_2430});
  }
  case TAG_Recv: {
    V v_ch_2431 = heff_field(v_p_2422, 0);
    V v_k_2432 = heff_field(v_p_2422, 1);
    V v_ru_24p_2422_24Recv = heff_take_reuse_n(v_p_2422, 3ULL, 2);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24Recv, TAG_Recv, 2, (V[]){v_ch_2431, v_k_2432});
  }
  default: return heff_nomatch(v_p_2422);
  }
}

static V g_green_2eemptyQ_val;
static HEFF_ONCE g_green_2eemptyQ_st;
static V g_green_2eemptyQ_init(void) {
  return heff_rec_n(2, shape_front__back, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_green_2eemptyQ_get(void) {
  if (HEFF_DONE(g_green_2eemptyQ_st)) return g_green_2eemptyQ_val;
  return heff_global(&g_green_2eemptyQ_val, &g_green_2eemptyQ_st, g_green_2eemptyQ_init);
}

HeffT2 g_green_2etakeQ_24cpr(V v_x1_240) {
top: ;
  V v_front_241 = heff_take_field(v_x1_240, 0);
  V v_back_242 = heff_get_n(v_x1_240, 1, 2);
  V v_front_27_243 = v_front_241;
  V v_b_244 = v_back_242;
  switch (heff_tag_of(v_front_27_243)) {
  case TAG_Nil: {
    V v_x1_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_b_244));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x1_245, 0);
      V v_rest_247 = heff_field(v_x1_245, 1);
      V v_ru_24x1_245_24Cons = heff_take_reuse_n(v_x1_245, 3ULL, 2);
      V v_t_248 = heff_rec_n(2, shape_front__back, (V[]){v_rest_247, NTAG(TAG_Nil)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_245_24Cons, TAG_MkPair, 2, (V[]){v_x_246, v_t_248})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
    }
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_front_27_243, 0);
    V v_rest_2410 = heff_field(v_front_27_243, 1);
    V v_ru_24front_27_243_24Cons = heff_take_reuse_n(v_front_27_243, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24front_27_243_24Cons, TAG_MkPair, 2, (V[]){v_x_249, heff_rec_n(2, shape_front__back, (V[]){v_rest_2410, v_b_244})});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_front_27_243)}});
  }
}
V g_green_2eview_24s1017855520x282345245_lam0(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam1(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam2(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam3(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam4(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam6(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam5(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam7(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam8(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam9(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam10(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam11(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam13(V self, V *args);
V g_green_2eview_24s1017855520x282345245_lam12(V self, V *args);
Clo g_green_2eview_24s1017855520x282345245_clo = {{0x80000000u, K_CLO, 0}, g_green_2eview_24s1017855520x282345245_entry, 1, 0};

V g_green_2eview_24s1017855520x282345245(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Main: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Main = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_RDone: {
      V v_x_242 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SFinal, 1, (V[]){v_x_242});
    }
    case TAG_RYield: {
      V v_k_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SYield, 1, (V[]){heff_clo_n(g_green_2eview_24s1017855520x282345245_lam0, 1, 1, (V[]){v_k_243})});
    }
    case TAG_RSpawn: {
      V v_c_246 = heff_field(v_x11_241, 0);
      V v_k_247 = heff_field(v_x11_241, 1);
      V v_ru_24x11_241_24RSpawn = heff_take_reuse_n(v_x11_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_241_24RSpawn, TAG_SSpawn, 2, (V[]){v_c_246, heff_clo_n(g_green_2eview_24s1017855520x282345245_lam1, 1, 1, (V[]){v_k_247})});
    }
    case TAG_RNew: {
      V v_k_2410 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SNew, 1, (V[]){heff_clo_n(g_green_2eview_24s1017855520x282345245_lam2, 1, 1, (V[]){v_k_2410})});
    }
    case TAG_RSend: {
      V v_ch_2413 = heff_field(v_x11_241, 0);
      V v_v_2414 = heff_field(v_x11_241, 1);
      V v_k_2415 = heff_field(v_x11_241, 2);
      V v_ru_24x11_241_24RSend = heff_take_reuse_n(v_x11_241, 7ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_241_24RSend, TAG_SSend, 3, (V[]){v_ch_2413, v_v_2414, heff_clo_n(g_green_2eview_24s1017855520x282345245_lam3, 1, 1, (V[]){v_k_2415})});
    }
    case TAG_RRecv: {
      V v_ch_2418 = heff_field(v_x11_241, 0);
      V v_k_2419 = heff_field(v_x11_241, 1);
      V v_ru_24x11_241_24RRecv = heff_take_reuse_n(v_x11_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_241_24RRecv, TAG_SRecv, 2, (V[]){v_ch_2418, heff_clo_n(g_green_2eview_24s1017855520x282345245_lam4, 1, 1, (V[]){v_k_2419})});
    }
    case TAG_RAct: {
      V v_m_2422 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SAct, 1, (V[]){heff_clo_n(g_green_2eview_24s1017855520x282345245_lam5, 2, 1, (V[]){v_m_2422})});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  case TAG_Other: {
    V v_x11_2426 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Other = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2426)) {
    case TAG_RDone: {
      heff_take_n(v_x11_2426, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return NTAG(TAG_SEnd);
    }
    case TAG_RYield: {
      V v_k_2428 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Other, TAG_SYield, 1, (V[]){heff_clo_n(g_green_2eview_24s1017855520x282345245_lam7, 1, 1, (V[]){v_k_2428})});
    }
    case TAG_RSpawn: {
      V v_c_2431 = heff_field(v_x11_2426, 0);
      V v_k_2432 = heff_field(v_x11_2426, 1);
      V v_ru_24x11_2426_24RSpawn = heff_take_reuse_n(v_x11_2426, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2426_24RSpawn, TAG_SSpawn, 2, (V[]){v_c_2431, heff_clo_n(g_green_2eview_24s1017855520x282345245_lam8, 1, 1, (V[]){v_k_2432})});
    }
    case TAG_RNew: {
      V v_k_2435 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Other, TAG_SNew, 1, (V[]){heff_clo_n(g_green_2eview_24s1017855520x282345245_lam9, 1, 1, (V[]){v_k_2435})});
    }
    case TAG_RSend: {
      V v_ch_2438 = heff_field(v_x11_2426, 0);
      V v_v_2439 = heff_field(v_x11_2426, 1);
      V v_k_2440 = heff_field(v_x11_2426, 2);
      V v_ru_24x11_2426_24RSend = heff_take_reuse_n(v_x11_2426, 7ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2426_24RSend, TAG_SSend, 3, (V[]){v_ch_2438, v_v_2439, heff_clo_n(g_green_2eview_24s1017855520x282345245_lam10, 1, 1, (V[]){v_k_2440})});
    }
    case TAG_RRecv: {
      V v_ch_2443 = heff_field(v_x11_2426, 0);
      V v_k_2444 = heff_field(v_x11_2426, 1);
      V v_ru_24x11_2426_24RRecv = heff_take_reuse_n(v_x11_2426, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2426_24RRecv, TAG_SRecv, 2, (V[]){v_ch_2443, heff_clo_n(g_green_2eview_24s1017855520x282345245_lam11, 1, 1, (V[]){v_k_2444})});
    }
    case TAG_RAct: {
      V v_m_2447 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Other, TAG_SAct, 1, (V[]){heff_clo_n(g_green_2eview_24s1017855520x282345245_lam12, 2, 1, (V[]){v_m_2447})});
    }
    default: return heff_nomatch(v_x11_2426);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_green_2eview_24s1017855520x282345245_entry(V self, V *a) {
  (void)self;
  return g_green_2eview_24s1017855520x282345245(a[0]);
}
V g_green_2eview_24s1017855520x282345245_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_u_244}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_245});
}
V g_green_2eview_24s1017855520x282345245_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_u_248}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_249});
}
V g_green_2eview_24s1017855520x282345245_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_n_2411}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2412});
}
V g_green_2eview_24s1017855520x282345245_lam3(V self, V *args) {
  V v_u_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_u_2416}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2417});
}
V g_green_2eview_24s1017855520x282345245_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_v_2420}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2421});
}
V g_green_2eview_24s1017855520x282345245_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Main, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2eview_24s1017855520x282345245_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_green_2eview_24s1017855520x282345245_lam6, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2eview_24s1017855520x282345245_lam7(V self, V *args) {
  V v_u_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tr(heff_call(v_k_2428, 1, (V[]){v_u_2429}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2430});
}
V g_green_2eview_24s1017855520x282345245_lam8(V self, V *args) {
  V v_u_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_tr(heff_call(v_k_2432, 1, (V[]){v_u_2433}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2434});
}
V g_green_2eview_24s1017855520x282345245_lam9(V self, V *args) {
  V v_n_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tr(heff_call(v_k_2435, 1, (V[]){v_n_2436}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2437});
}
V g_green_2eview_24s1017855520x282345245_lam10(V self, V *args) {
  V v_u_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tr(heff_call(v_k_2440, 1, (V[]){v_u_2441}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2442});
}
V g_green_2eview_24s1017855520x282345245_lam11(V self, V *args) {
  V v_v_2445 = args[0];
  V v_k_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(v_k_2444, 1, (V[]){v_v_2445}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2446});
}
V g_green_2eview_24s1017855520x282345245_lam13(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_Other, 1, (V[]){v_x_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2eview_24s1017855520x282345245_lam12(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_m_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_green_2eview_24s1017855520x282345245_lam13, 1, 1, (V[]){v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1072496561x430638721_lam1(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam0(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam2(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam3(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam5(V self, V *args); static Clo g_green_2ego_24s1072496561x430638721_lam5_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1072496561x430638721_lam5, 1, 0};
V g_green_2ego_24s1072496561x430638721_lam4(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam7(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam6(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam9(V self, V *args); static Clo g_green_2ego_24s1072496561x430638721_lam9_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1072496561x430638721_lam9, 1, 0};
V g_green_2ego_24s1072496561x430638721_lam8(V self, V *args); static Clo g_green_2ego_24s1072496561x430638721_lam8_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1072496561x430638721_lam8, 1, 0};
V g_green_2ego_24s1072496561x430638721_lam11(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam10(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam13(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam12(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam15(V self, V *args); static Clo g_green_2ego_24s1072496561x430638721_lam15_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1072496561x430638721_lam15, 1, 0};
V g_green_2ego_24s1072496561x430638721_lam14(V self, V *args); static Clo g_green_2ego_24s1072496561x430638721_lam14_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1072496561x430638721_lam14, 1, 0};
V g_green_2ego_24s1072496561x430638721_lam18(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam17(V self, V *args);
V g_green_2ego_24s1072496561x430638721_lam16(V self, V *args);
Clo g_green_2ego_24s1072496561x430638721_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1072496561x430638721_entry, 3, 0};

V g_green_2ego_24s1072496561x430638721(V v_g_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SFinal: {
    V v_x_243 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_s_241, 6);
    return heff_clo_n(g_green_2ego_24s1072496561x430638721_lam0, 2, 2, (V[]){v_g_240, v_x_243});
  }
  case TAG_SEnd: {
    V t_0 = v_g_240;
    V t_1 = v_s_241;
    V t_2 = NTAG(TAG_SNext);
    v_g_240 = t_0;
    v_s_241 = t_1;
    v_x4_242 = t_2;
    goto top_TAG_SNext;
  }
  case TAG_SYield: {
    V v_k_249 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_q_2410 = heff_take_field(v_s_241, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_249, heff_take_field(v_q_2410, 1)});
    V v_t_2412 = ({ V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_q_2410, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_241, 62ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_g_240;
    V t_1 = v_t_2413;
    V t_2 = NTAG(TAG_SNext);
    v_g_240 = t_0;
    v_s_241 = t_1;
    v_x4_242 = t_2;
    goto top_TAG_SNext;
  }
  case TAG_SSpawn: {
    V v_c_2414 = heff_field(v_x4_242, 0);
    V v_k_2415 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SSpawn = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_q_2416 = heff_take_field(v_s_241, 0);
    V v_t_2418 = heff_tag_at_n(v_ru_24x4_242_24SSpawn, TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s1072496561x430638721_lam2, 1, 1, (V[]){v_c_2414}), heff_dup(heff_rfield(v_q_2416, 1))});
    V v_t_2419 = ({ V rv_1 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_q_2416, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2420 = ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_s_241, 62ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2421 = heff_tr(heff_call(v_k_2415, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2422 = (g_green_2eview_24s1017855520x282345245(v_t_2421));
    V t_0 = v_g_240;
    V t_1 = v_t_2420;
    V t_2 = v_t_2422;
    v_g_240 = t_0;
    v_s_241 = t_1;
    v_x4_242 = t_2;
    goto top;
  }
  case TAG_SNew: {
    V v_k_2423 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_t_2424 = heff_intAdd(heff_dup(heff_rfield(v_s_241, 3)), MK_INT(1LL));
    V v_t_2425 = heff_rec_n(6, shape_ready__chans__waiting__next__pending__turns, (V[]){heff_take_field(v_s_241, 0), heff_take_field(v_s_241, 1), heff_take_field(v_s_241, 2), v_t_2424, heff_take_field(v_s_241, 4), heff_take_field(v_s_241, 5)});
    V v_t_2426 = heff_tr(heff_call(v_k_2423, 1, (V[]){heff_get_n(v_s_241, 3, 6)}));
    V v_t_2427 = (g_green_2eview_24s1017855520x282345245(v_t_2426));
    V t_0 = v_g_240;
    V t_1 = v_t_2425;
    V t_2 = v_t_2427;
    v_g_240 = t_0;
    v_s_241 = t_1;
    v_x4_242 = t_2;
    goto top;
  }
  case TAG_SSend: {
    V v_ch_2428 = heff_field(v_x4_242, 0);
    V v_v_2429 = heff_field(v_x4_242, 1);
    V v_k_2430 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2431 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_241, 2), heff_dup(v_ch_2428)));
    V v_t_2435;
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_x_2434 = v_field_2433;
        v_t_2435 = v_x_2434;
      } else {
        heff_drop(v_field_2433);
        v_t_2435 = heff_dup(g_green_2eemptyQ_get());
      }
    }
    HeffT2 v_t_2436 = (g_green_2etakeQ_24cpr(v_t_2435));
    {
      V v_field_2438 = v_t_2436.f[1];
      int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
      if ((v_tag_2437 == ((int64_t)0ULL))) {
        V v_it1_2439 = v_field_2438;
        switch (heff_tag_of(v_it1_2439)) {
        case TAG_MkPair: {
          V v_w_2440 = heff_field(v_it1_2439, 0);
          V v_ws_2441 = heff_field(v_it1_2439, 1);
          V v_ru_24it1_2439_24MkPair = heff_take_reuse_n(v_it1_2439, 3ULL, 2);
          V v_q_2442 = heff_take_field(v_s_241, 0);
          V v_t_2444 = heff_tag_at_n(v_ru_24it1_2439_24MkPair, TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s1072496561x430638721_lam3, 1, 2, (V[]){v_w_2440, v_v_2429}), heff_dup(heff_rfield(v_q_2442, 1))});
          V v_t_2445 = ({ V rv_1 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_q_2442, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2446 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_241, 2), v_ch_2428, v_ws_2441));
          V v_t_2447 = ({ V rv_0 = v_t_2445; V rv_2 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_s_241, 58ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4044u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2448 = heff_tr(heff_call(v_k_2430, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2449 = (g_green_2eview_24s1017855520x282345245(v_t_2448));
          V t_0 = v_g_240;
          V t_1 = v_t_2447;
          V t_2 = v_t_2449;
          v_g_240 = t_0;
          v_s_241 = t_1;
          v_x4_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_it1_2439);
        }
      } else {
        heff_drop(v_field_2438);
        HeffT2 v_t_2450 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_241, 1), heff_dup(v_ch_2428)));
        V v_t_2456;
        {
          V v_field_2452 = v_t_2450.f[1];
          int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
          V v_q_2454;
          if ((v_tag_2451 == ((int64_t)0ULL))) {
            V v_x_2453 = v_field_2452;
            v_q_2454 = v_x_2453;
          } else {
            heff_drop(v_field_2452);
            v_q_2454 = heff_dup(g_green_2eemptyQ_get());
          }
          V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2429, heff_take_field(v_q_2454, 1)});
          v_t_2456 = ({ V rv_1 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_q_2454, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        V v_t_2457 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_241, 1), v_ch_2428, v_t_2456));
        V v_t_2458 = ({ V rv_1 = v_t_2457; V rr_ = heff_rec_reuse_nf(v_s_241, 61ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2459 = heff_tr(heff_call(v_k_2430, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_2460 = (g_green_2eview_24s1017855520x282345245(v_t_2459));
        V t_0 = v_g_240;
        V t_1 = v_t_2458;
        V t_2 = v_t_2460;
        v_g_240 = t_0;
        v_s_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      }
    }
  }
  case TAG_SRecv: {
    V v_ch_2461 = heff_field(v_x4_242, 0);
    V v_k_2462 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SRecv = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_2463 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_241, 1), heff_dup(v_ch_2461)));
    V v_t_2467;
    {
      V v_field_2465 = v_t_2463.f[1];
      int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
      if ((v_tag_2464 == ((int64_t)0ULL))) {
        V v_x_2466 = v_field_2465;
        v_t_2467 = v_x_2466;
      } else {
        heff_drop(v_field_2465);
        v_t_2467 = heff_dup(g_green_2eemptyQ_get());
      }
    }
    HeffT2 v_t_2468 = (g_green_2etakeQ_24cpr(v_t_2467));
    {
      V v_field_2470 = v_t_2468.f[1];
      int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
      if ((v_tag_2469 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x4_242_24SRecv, 2);
        V v_it1_2471 = v_field_2470;
        switch (heff_tag_of(v_it1_2471)) {
        case TAG_MkPair: {
          V v_v_2472 = heff_field(v_it1_2471, 0);
          V v_vs_2473 = heff_field(v_it1_2471, 1);
          heff_take_n(v_it1_2471, 3ULL, 2);
          V v_t_2474 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_241, 1), v_ch_2461, v_vs_2473));
          V v_t_2475 = ({ V rv_1 = v_t_2474; V rr_ = heff_rec_reuse_nf(v_s_241, 61ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2476 = heff_tr(heff_call(v_k_2462, 1, (V[]){v_v_2472}));
          V v_t_2477 = (g_green_2eview_24s1017855520x282345245(v_t_2476));
          V t_0 = v_g_240;
          V t_1 = v_t_2475;
          V t_2 = v_t_2477;
          v_g_240 = t_0;
          v_s_241 = t_1;
          v_x4_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_it1_2471);
        }
      } else {
        heff_drop(v_field_2470);
        HeffT2 v_t_2478 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_241, 2), heff_dup(v_ch_2461)));
        V v_t_2484;
        {
          V v_field_2480 = v_t_2478.f[1];
          int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
          V v_q_2482;
          if ((v_tag_2479 == ((int64_t)0ULL))) {
            V v_x_2481 = v_field_2480;
            v_q_2482 = v_x_2481;
          } else {
            heff_drop(v_field_2480);
            v_q_2482 = heff_dup(g_green_2eemptyQ_get());
          }
          V v_t_2483 = heff_tag_at_n(v_ru_24x4_242_24SRecv, TAG_Cons, 2, (V[]){v_k_2462, heff_dup(heff_rfield(v_q_2482, 1))});
          v_t_2484 = ({ V rv_1 = v_t_2483; V rr_ = heff_rec_reuse_nf(v_q_2482, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        V v_t_2485 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_241, 2), v_ch_2461, v_t_2484));
        V v_t_2486 = ({ V rv_2 = v_t_2485; V rr_ = heff_rec_reuse_nf(v_s_241, 59ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V t_0 = v_g_240;
        V t_1 = v_t_2486;
        V t_2 = NTAG(TAG_SNext);
        v_g_240 = t_0;
        v_s_241 = t_1;
        v_x4_242 = t_2;
        goto top_TAG_SNext;
      }
    }
  }
  case TAG_SAct: {
    V v_m_2487 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SAct = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_c_2494;
    switch (heff_tag_of(v_g_240)) {
    case TAG_MkGroup: {
      V v_i_2488 = heff_dup(heff_field(v_g_240, 0));
      V v_t_2491 = heff_tag_at_n(v_ru_24x4_242_24SAct, TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_i_2488, heff_clo_n(g_green_2ego_24s1072496561x430638721_lam4, 1, 1, (V[]){v_m_2487})})});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})});
      v_c_2494 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2493}));
      break;
    }
    default: heff_nomatch(v_g_240);
    }
    return heff_clo_n(g_green_2ego_24s1072496561x430638721_lam6, 2, 3, (V[]){v_c_2494, v_s_241, v_g_240});
  }
  case TAG_SNext: {
    top_TAG_SNext: ;
    if ((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_241, 4))) && heff_intLe_c(MK_INT(64LL), heff_dup(heff_rfield(v_s_241, 5))))) {
      V v_c_24110;
      switch (heff_tag_of(v_g_240)) {
      case TAG_MkGroup: {
        V v_i_24104 = heff_dup(heff_field(v_g_240, 0));
        V v_t_24107 = heff_tag_n(TAG_Finish, 3, (V[]){v_i_24104, NTAG(TAG_False), ((V)&g_green_2ego_24s1072496561x430638721_lam8_clo)});
        V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
        V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
        v_c_24110 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
        break;
      }
      default: heff_nomatch(v_g_240);
      }
      return heff_clo_n(g_green_2ego_24s1072496561x430638721_lam10, 2, 3, (V[]){v_c_24110, v_s_241, v_g_240});
    } else {
      HeffT2 v_t_24119 = (g_green_2etakeQ_24cpr(heff_dup(heff_rfield(v_s_241, 0))));
      {
        V v_field_24121 = v_t_24119.f[1];
        int64_t v_tag_24120 = ((int64_t)v_t_24119.f[0]);
        if ((v_tag_24120 == ((int64_t)0ULL))) {
          V v_it1_24122 = v_field_24121;
          switch (heff_tag_of(v_it1_24122)) {
          case TAG_MkPair: {
            V v_t_24123 = heff_field(v_it1_24122, 0);
            V v_q_24124 = heff_field(v_it1_24122, 1);
            heff_take_n(v_it1_24122, 3ULL, 2);
            V v_t_24125 = heff_intAdd(heff_take_field(v_s_241, 5), MK_INT(1LL));
            V v_t_24126 = ({ V rv_0 = v_q_24124; V rv_5 = v_t_24125; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 6, shape_ready__chans__waiting__next__pending__turns, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 5) = rv_5; rr_; });
            V v_t_24127 = heff_tr(heff_call(v_t_24123, 1, (V[]){NTAG(TAG_MkUnit)}));
            V v_t_24128 = (g_green_2eview_24s1017855520x282345245(v_t_24127));
            V t_0 = v_g_240;
            V t_1 = v_t_24126;
            V t_2 = v_t_24128;
            v_g_240 = t_0;
            v_s_241 = t_1;
            v_x4_242 = t_2;
            goto top;
          }
          default: return heff_nomatch(v_it1_24122);
          }
        } else {
          heff_drop(v_field_24121);
          if (heff_intEq_c(heff_dup(heff_rfield(v_s_241, 4)), MK_INT(0LL))) {
            heff_drop_rec(v_s_241, 6);
            return heff_clo_n(g_green_2ego_24s1072496561x430638721_lam12, 2, 1, (V[]){v_g_240});
          } else {
            V v_c_24140;
            switch (heff_tag_of(v_g_240)) {
            case TAG_MkGroup: {
              V v_i_24134 = heff_dup(heff_field(v_g_240, 0));
              V v_t_24137 = heff_tag_n(TAG_Finish, 3, (V[]){v_i_24134, NTAG(TAG_True), ((V)&g_green_2ego_24s1072496561x430638721_lam14_clo)});
              V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24137})});
              V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24138})});
              v_c_24140 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})}));
              break;
            }
            default: heff_nomatch(v_g_240);
            }
            return heff_clo_n(g_green_2ego_24s1072496561x430638721_lam16, 2, 3, (V[]){v_c_24140, v_g_240, v_s_241});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_green_2ego_24s1072496561x430638721_entry(V self, V *a) {
  (void)self;
  return g_green_2ego_24s1072496561x430638721(a[0], a[1], a[2]);
}
V g_green_2ego_24s1072496561x430638721_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_248);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1072496561x430638721_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247;
  switch (heff_tag_of(v_g_240)) {
  case TAG_MkGroup: {
    V v_i_246 = heff_field(v_g_240, 0);
    heff_take_n(v_g_240, 1ULL, 1);
    v_t_247 = heff_tr(heff_call(((V)&g_co_2eop_24s1997951166x681497643_clo), 1, (V[]){v_i_246}));
    break;
  }
  default: heff_nomatch(v_g_240);
  }
  V f_ = v_t_247;
  args[0] = v_hd_244;
  args[1] = heff_clo_n(g_green_2ego_24s1072496561x430638721_lam1, 1, 2, (V[]){v_k_245, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1072496561x430638721_lam2(V self, V *args) {
  V v_u_2417 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Other, 1, (V[]){v_c_2414});
}
V g_green_2ego_24s1072496561x430638721_lam3(V self, V *args) {
  V v_u_2443 = args[0];
  V v_w_2440 = heff_env(self)[0];
  V v_v_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2443);
  V f_ = v_w_2440;
  args[0] = v_v_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1072496561x430638721_lam5(V self, V *args) {
  V v_r_2490 = args[0];
  return v_r_2490;
}
V g_green_2ego_24s1072496561x430638721_lam4(V self, V *args) {
  V v_use_2489 = args[0];
  V v_m_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_use_2489;
  heff_room[0] = v_m_2487;
  heff_room[1] = ((V)&g_green_2ego_24s1072496561x430638721_lam5_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_green_2ego_24s1072496561x430638721_lam7(V self, V *args) {
  V v_x_2497 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_2495 = heff_env(self)[2];
  V v_k_2496 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2497)) {
  case TAG_Nothing: {
    V v_t_2498 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
    V v_t_2499 = ({ V rv_4 = v_t_2498; V rr_ = heff_rec_reuse_nf(v_s_241, 47ULL, 6, shape_ready__chans__waiting__next__pending__turns, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_24100 = (g_green_2ego_24s1072496561x430638721(v_g_240, v_t_2499, NTAG(TAG_SNext)));
    V f_ = v_t_24100;
    heff_room[0] = v_hd_2495;
    heff_room[1] = v_k_2496;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_24101 = heff_field(v_x_2497, 0);
    heff_take_n(v_x_2497, 1ULL, 1);
    V v_t_24102 = (g_green_2eview_24s1017855520x282345245(v_t_24101));
    V v_t_24103 = (g_green_2ego_24s1072496561x430638721(v_g_240, v_s_241, v_t_24102));
    V f_ = v_t_24103;
    heff_room[0] = v_hd_2495;
    heff_room[1] = v_k_2496;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2497);
  }
}
V g_green_2ego_24s1072496561x430638721_lam6(V self, V *args) {
  V v_hd_2495 = args[0];
  V v_k_2496 = args[1];
  V v_c_2494 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2494;
  args[0] = heff_dup(v_hd_2495);
  args[1] = heff_clo_n(g_green_2ego_24s1072496561x430638721_lam7, 1, 4, (V[]){v_s_241, v_g_240, v_hd_2495, v_k_2496});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1072496561x430638721_lam9(V self, V *args) {
  V v_l_24106 = args[0];
  return v_l_24106;
}
V g_green_2ego_24s1072496561x430638721_lam8(V self, V *args) {
  V v_use_24105 = args[0];
  V f_ = v_use_24105;
  args[0] = ((V)&g_green_2ego_24s1072496561x430638721_lam9_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1072496561x430638721_lam11(V self, V *args) {
  V v_x_24113 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_24111 = heff_env(self)[2];
  V v_k_24112 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24114 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_241, 0), heff_dup(v_x_24113)));
  V v_t_24115 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24113; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24113); r_; });
  V v_t_24116 = heff_intSub(heff_take_field(v_s_241, 4), v_t_24115);
  V v_t_24117 = ({ V rv_0 = v_t_24114; V rv_4 = v_t_24116; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_241, 14ULL, 6, shape_ready__chans__waiting__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_t_24118 = (g_green_2ego_24s1072496561x430638721(v_g_240, v_t_24117, NTAG(TAG_SNext)));
  V f_ = v_t_24118;
  heff_room[0] = v_hd_24111;
  heff_room[1] = v_k_24112;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_green_2ego_24s1072496561x430638721_lam10(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_c_24110 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24110;
  args[0] = heff_dup(v_hd_24111);
  args[1] = heff_clo_n(g_green_2ego_24s1072496561x430638721_lam11, 1, 4, (V[]){v_s_241, v_g_240, v_hd_24111, v_k_24112});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1072496561x430638721_lam13(V self, V *args) {
  V v_x_24133 = args[0];
  V v_k_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24133);
  V f_ = v_k_24130;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1072496561x430638721_lam12(V self, V *args) {
  V v_hd_24129 = args[0];
  V v_k_24130 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24132;
  switch (heff_tag_of(v_g_240)) {
  case TAG_MkGroup: {
    V v_i_24131 = heff_field(v_g_240, 0);
    heff_take_n(v_g_240, 1ULL, 1);
    v_t_24132 = heff_tr(heff_call(((V)&g_co_2eop_24s1997951166x681497643_clo), 1, (V[]){v_i_24131}));
    break;
  }
  default: heff_nomatch(v_g_240);
  }
  V f_ = v_t_24132;
  args[0] = v_hd_24129;
  args[1] = heff_clo_n(g_green_2ego_24s1072496561x430638721_lam13, 1, 1, (V[]){v_k_24130});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1072496561x430638721_lam15(V self, V *args) {
  V v_l_24136 = args[0];
  return v_l_24136;
}
V g_green_2ego_24s1072496561x430638721_lam14(V self, V *args) {
  V v_use_24135 = args[0];
  V f_ = v_use_24135;
  args[0] = ((V)&g_green_2ego_24s1072496561x430638721_lam15_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1072496561x430638721_lam18(V self, V *args) {
  V v_x_24147 = args[0];
  V v_k_24142 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24147);
  V f_ = v_k_24142;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1072496561x430638721_lam17(V self, V *args) {
  V v_x_24143 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_24141 = heff_env(self)[1];
  V v_k_24142 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24144 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_24143));
  if (heff_intEq_c(v_t_24144, MK_INT(0LL))) {
    heff_drop(v_x_24143);
    heff_drop_rec(v_s_241, 6);
    V v_t_24146;
    switch (heff_tag_of(v_g_240)) {
    case TAG_MkGroup: {
      V v_i_24145 = heff_field(v_g_240, 0);
      heff_take_n(v_g_240, 1ULL, 1);
      v_t_24146 = heff_tr(heff_call(((V)&g_co_2eop_24s1997951166x681497643_clo), 1, (V[]){v_i_24145}));
      break;
    }
    default: heff_nomatch(v_g_240);
    }
    V f_ = v_t_24146;
    heff_room[0] = v_hd_24141;
    heff_room[1] = heff_clo_n(g_green_2ego_24s1072496561x430638721_lam18, 1, 1, (V[]){v_k_24142});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_24148 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_241, 0), heff_dup(v_x_24143)));
    V v_t_24149 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24143; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24143); r_; });
    V v_t_24150 = heff_intSub(heff_take_field(v_s_241, 4), v_t_24149);
    V v_t_24151 = ({ V rv_0 = v_t_24148; V rv_4 = v_t_24150; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_241, 14ULL, 6, shape_ready__chans__waiting__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    V v_t_24152 = (g_green_2ego_24s1072496561x430638721(v_g_240, v_t_24151, NTAG(TAG_SNext)));
    V f_ = v_t_24152;
    heff_room[0] = v_hd_24141;
    heff_room[1] = v_k_24142;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_green_2ego_24s1072496561x430638721_lam16(V self, V *args) {
  V v_hd_24141 = args[0];
  V v_k_24142 = args[1];
  V v_c_24140 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_s_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24140;
  args[0] = heff_dup(v_hd_24141);
  args[1] = heff_clo_n(g_green_2ego_24s1072496561x430638721_lam17, 1, 4, (V[]){v_g_240, v_hd_24141, v_k_24142, v_s_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ethenRes_24s2092633126x465472411_lam0(V self, V *args);
V g_green_2ethenRes_24s2092633126x465472411_lam1(V self, V *args);
V g_green_2ethenRes_24s2092633126x465472411_lam2(V self, V *args);
V g_green_2ethenRes_24s2092633126x465472411_lam3(V self, V *args);
V g_green_2ethenRes_24s2092633126x465472411_lam4(V self, V *args);
V g_green_2ethenRes_24s2092633126x465472411_lam6(V self, V *args);
V g_green_2ethenRes_24s2092633126x465472411_lam5(V self, V *args);
Clo g_green_2ethenRes_24s2092633126x465472411_clo = {{0x80000000u, K_CLO, 0}, g_green_2ethenRes_24s2092633126x465472411_entry, 2, 0};

V g_green_2ethenRes_24s2092633126x465472411(V v_x1_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RDone: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tail(v_f_241, 1, (V[]){v_x_242});
  }
  case TAG_RYield: {
    V v_k_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RYield = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RYield, TAG_RYield, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s2092633126x465472411_lam0, 1, 2, (V[]){v_k_243, v_f_241})});
  }
  case TAG_RSpawn: {
    V v_c_246 = heff_field(v_x1_240, 0);
    V v_k_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RSpawn = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RSpawn, TAG_RSpawn, 2, (V[]){v_c_246, heff_clo_n(g_green_2ethenRes_24s2092633126x465472411_lam1, 1, 2, (V[]){v_k_247, v_f_241})});
  }
  case TAG_RNew: {
    V v_k_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RNew = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RNew, TAG_RNew, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s2092633126x465472411_lam2, 1, 2, (V[]){v_k_2410, v_f_241})});
  }
  case TAG_RSend: {
    V v_ch_2413 = heff_field(v_x1_240, 0);
    V v_v_2414 = heff_field(v_x1_240, 1);
    V v_k_2415 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24RSend = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    return heff_tag_at_n(v_ru_24x1_240_24RSend, TAG_RSend, 3, (V[]){v_ch_2413, v_v_2414, heff_clo_n(g_green_2ethenRes_24s2092633126x465472411_lam3, 1, 2, (V[]){v_k_2415, v_f_241})});
  }
  case TAG_RRecv: {
    V v_ch_2418 = heff_field(v_x1_240, 0);
    V v_k_2419 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RRecv = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RRecv, TAG_RRecv, 2, (V[]){v_ch_2418, heff_clo_n(g_green_2ethenRes_24s2092633126x465472411_lam4, 1, 2, (V[]){v_k_2419, v_f_241})});
  }
  case TAG_RAct: {
    V v_m_2422 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RAct = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RAct, TAG_RAct, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s2092633126x465472411_lam5, 2, 2, (V[]){v_m_2422, v_f_241})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_green_2ethenRes_24s2092633126x465472411_entry(V self, V *a) {
  (void)self;
  return g_green_2ethenRes_24s2092633126x465472411(a[0], a[1]);
}
V g_green_2ethenRes_24s2092633126x465472411_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_u_244}));
  return (g_green_2ethenRes_24s2092633126x465472411(v_t_245, v_f_241));
}
V g_green_2ethenRes_24s2092633126x465472411_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_u_248}));
  return (g_green_2ethenRes_24s2092633126x465472411(v_t_249, v_f_241));
}
V g_green_2ethenRes_24s2092633126x465472411_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_n_2411}));
  return (g_green_2ethenRes_24s2092633126x465472411(v_t_2412, v_f_241));
}
V g_green_2ethenRes_24s2092633126x465472411_lam3(V self, V *args) {
  V v_u_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_u_2416}));
  return (g_green_2ethenRes_24s2092633126x465472411(v_t_2417, v_f_241));
}
V g_green_2ethenRes_24s2092633126x465472411_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_v_2420}));
  return (g_green_2ethenRes_24s2092633126x465472411(v_t_2421, v_f_241));
}
V g_green_2ethenRes_24s2092633126x465472411_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2426 = heff_tr(g_green_2ethenRes_24s2092633126x465472411(v_x_2425, v_f_241));
  V f_ = v_k_2424;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ethenRes_24s2092633126x465472411_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_m_2422 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_m_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_green_2ethenRes_24s2092633126x465472411_lam6, 1, 2, (V[]){v_f_241, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ealone_24s896371827x11544689_lam0(V self, V *args);
V g_green_2ealone_24s896371827x11544689_lam2(V self, V *args);
V g_green_2ealone_24s896371827x11544689_lam1(V self, V *args);
Clo g_green_2ealone_24s896371827x11544689_clo = {{0x80000000u, K_CLO, 0}, g_green_2ealone_24s896371827x11544689_entry, 1, 0};

V g_green_2ealone_24s896371827x11544689(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RDone: {
    V v_x_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_clo_n(g_green_2ealone_24s896371827x11544689_lam0, 2, 1, (V[]){v_x_241});
  }
  case TAG_RYield: {
    V v_k_244 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(v_k_244, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_t_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RSpawn: {
    V v_k_247 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V v_t_248 = heff_tr(heff_call(v_k_247, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_t_248;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RNew: {
    V v_k_249 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2410 = heff_tr(heff_call(v_k_249, 1, (V[]){MK_INT(0LL)}));
    V t_0 = v_t_2410;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RSend: {
    V v_k_2413 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V v_t_2414 = heff_tr(heff_call(v_k_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_t_2414;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RRecv: {
    V v_k_2416 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V v_t_2417 = heff_tr(heff_call(v_k_2416, 1, (V[]){MK_INT(0LL)}));
    V t_0 = v_t_2417;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RAct: {
    V v_m_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_clo_n(g_green_2ealone_24s896371827x11544689_lam1, 2, 1, (V[]){v_m_2418});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_green_2ealone_24s896371827x11544689_entry(V self, V *a) {
  (void)self;
  return g_green_2ealone_24s896371827x11544689(a[0]);
}
V g_green_2ealone_24s896371827x11544689_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_x_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ealone_24s896371827x11544689_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2419 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = (g_green_2ealone_24s896371827x11544689(v_x_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_2419;
  heff_room[1] = v_k_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_green_2ealone_24s896371827x11544689_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_m_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_green_2ealone_24s896371827x11544689_lam2, 1, 2, (V[]){v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2egreenAlg_24s854873557x32656427_lam0(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam1(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam2(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam3(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam4(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam5(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam7(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam6(V self, V *args); static Clo g_green_2egreenAlg_24s854873557x32656427_lam6_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreenAlg_24s854873557x32656427_lam6, 2, 0};
V g_green_2egreenAlg_24s854873557x32656427_lam9(V self, V *args);
V g_green_2egreenAlg_24s854873557x32656427_lam8(V self, V *args); static Clo g_green_2egreenAlg_24s854873557x32656427_lam8_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreenAlg_24s854873557x32656427_lam8, 4, 0};
Clo g_green_2egreenAlg_24s854873557x32656427_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreenAlg_24s854873557x32656427_entry, 1, 0};

V g_green_2egreenAlg_24s854873557x32656427(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_InL: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24InL = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_Spawn: {
      V v_c_242 = heff_field(v_x21_241, 0);
      V v_x_243 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24Spawn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_241_24Spawn, TAG_RSpawn, 2, (V[]){v_c_242, heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam0, 1, 1, (V[]){v_x_243})});
    }
    case TAG_Yield: {
      V v_x_245 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_240_24InL, TAG_RYield, 1, (V[]){heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam1, 1, 1, (V[]){v_x_245})});
    }
    case TAG_NewChan: {
      V v_k_247 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_240_24InL, TAG_RNew, 1, (V[]){heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam2, 1, 1, (V[]){v_k_247})});
    }
    case TAG_Send: {
      V v_ch_2410 = heff_field(v_x21_241, 0);
      V v_v_2411 = heff_field(v_x21_241, 1);
      V v_x_2412 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24Send = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_241_24Send, TAG_RSend, 3, (V[]){v_ch_2410, v_v_2411, heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam3, 1, 1, (V[]){v_x_2412})});
    }
    case TAG_Recv: {
      V v_ch_2414 = heff_field(v_x21_241, 0);
      V v_k_2415 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24Recv = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_241_24Recv, TAG_RRecv, 2, (V[]){v_ch_2414, heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam4, 1, 1, (V[]){v_k_2415})});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  case TAG_InR: {
    V v_q_2418 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24InR = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2439;
    switch (heff_tag_of(v_q_2418)) {
    case TAG_InL: {
      V v_x_2419 = heff_field(v_q_2418, 0);
      V v_ru_24q_2418_24InL = heff_take_reuse_n(v_q_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24InR, 1);
      V v_t_2426;
      switch (heff_tag_of(v_x_2419)) {
      case TAG_Throw: {
        V v_s_2420 = heff_field(v_x_2419, 0);
        V v_ru_24x_2419_24Throw = heff_take_reuse_n(v_x_2419, 1ULL, 1);
        v_t_2426 = heff_tag_at_n(v_ru_24x_2419_24Throw, TAG_Throw, 1, (V[]){v_s_2420});
        break;
      }
      case TAG_Catch: {
        V v_c_2421 = heff_field(v_x_2419, 0);
        V v_h_2422 = heff_field(v_x_2419, 1);
        V v_ru_24x_2419_24Catch = heff_take_reuse_n(v_x_2419, 3ULL, 2);
        V v_t_2423 = (g_green_2ealone_24s896371827x11544689(v_c_2421));
        v_t_2426 = heff_tag_at_n(v_ru_24x_2419_24Catch, TAG_Catch, 2, (V[]){v_t_2423, heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam5, 1, 1, (V[]){v_h_2422})});
        break;
      }
      default: heff_nomatch(v_x_2419);
      }
      v_t_2439 = heff_tag_at_n(v_ru_24q_2418_24InL, TAG_InL, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_InR: {
      V v_y_2427 = heff_field(v_q_2418, 0);
      heff_take_n(v_q_2418, 1ULL, 1);
      V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_green_2egreenAlg_24s854873557x32656427_lam6_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_green_2egreenAlg_24s854873557x32656427_lam8_clo)}), ((V)&g_green_2ealone_24s896371827x11544689_clo), v_y_2427}));
      v_t_2439 = heff_tag_at_n(v_ru_24x2_240_24InR, TAG_InR, 1, (V[]){v_t_2438});
      break;
    }
    default: heff_nomatch(v_q_2418);
    }
    V v_t_2440 = heff_tr(heff_call(((V)&g_co_2eop_24s293084245x615760588_clo), 1, (V[]){v_t_2439}));
    return heff_tag_n(TAG_RAct, 1, (V[]){v_t_2440});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_green_2egreenAlg_24s854873557x32656427_entry(V self, V *a) {
  (void)self;
  return g_green_2egreenAlg_24s854873557x32656427(a[0]);
}
V g_green_2egreenAlg_24s854873557x32656427_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_243});
}
V g_green_2egreenAlg_24s854873557x32656427_lam1(V self, V *args) {
  V v_u_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_246);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_245});
}
V g_green_2egreenAlg_24s854873557x32656427_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_n_248}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_249});
}
V g_green_2egreenAlg_24s854873557x32656427_lam3(V self, V *args) {
  V v_u_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2412});
}
V g_green_2egreenAlg_24s854873557x32656427_lam4(V self, V *args) {
  V v_v_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_v_2416}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_2417});
}
V g_green_2egreenAlg_24s854873557x32656427_lam5(V self, V *args) {
  V v_s_2424 = args[0];
  V v_h_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_2425 = heff_tr(heff_call(v_h_2422, 1, (V[]){v_s_2424}));
  return (g_green_2ealone_24s896371827x11544689(v_r_2425));
}
V g_green_2egreenAlg_24s854873557x32656427_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_g_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tr(heff_call(v_g_2428, 1, (V[]){v_x_2430}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_2431});
}
V g_green_2egreenAlg_24s854873557x32656427_lam6(V self, V *args) {
  V v_g_2428 = args[0];
  V v_r_2429 = args[1];
  return (g_green_2ethenRes_24s2092633126x465472411(v_r_2429, heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam7, 1, 1, (V[]){v_g_2428})));
}
V g_green_2egreenAlg_24s854873557x32656427_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_g_2432 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2437 = heff_tr(heff_call(v_g_2432, 1, (V[]){v_x_2436}));
  V f_ = v_k_2435;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2egreenAlg_24s854873557x32656427_lam8(V self, V *args) {
  V v_g_2432 = args[0];
  V v_c_2433 = args[1];
  V v_hd_2434 = args[2];
  V v_k_2435 = args[3];
  V f_ = v_c_2433;
  args[0] = v_hd_2434;
  args[1] = heff_clo_n(g_green_2egreenAlg_24s854873557x32656427_lam9, 1, 2, (V[]){v_g_2432, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}