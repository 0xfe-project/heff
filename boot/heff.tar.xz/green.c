// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Alone 55333
#define TAG_Close 2276
#define TAG_Finish 61316
#define TAG_Joining 21922
#define TAG_Main 39920
#define TAG_MkGroup 19195
#define TAG_NewKey 33294
#define TAG_Other 45236
#define TAG_Park 64043
#define TAG_RAct 26891
#define TAG_RDone 16778
#define TAG_RKey 36568
#define TAG_RPark 33316
#define TAG_RSpawn 40406
#define TAG_RWake 45052
#define TAG_RYield 3356
#define TAG_SAct 56682
#define TAG_SEnd 60851
#define TAG_SFinal 20030
#define TAG_SKey 833
#define TAG_SNext 49456
#define TAG_SPark 39473
#define TAG_SSpawn 34695
#define TAG_SWake 51209
#define TAG_SYield 63171
#define TAG_Spawn 10053
#define TAG_Wake 10253
#define TAG_Yield 38529
#define LBL_back 9511342
#define LBL_front 299063875
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_next 9873338
#define LBL_parked 951723316
#define LBL_pending 1696753626
#define LBL_ready 309745085
#define LBL_turns 312085424
#define LBL_woken 314670230
static uint32_t shape_front__back[] = {LBL_front, LBL_back};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_ready__woken__parked__next__pending__turns[] = {LBL_ready, LBL_woken, LBL_parked, LBL_next, LBL_pending, LBL_turns};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_green_2ealone(V, V);
V g_green_2ealone_entry(V self, V *a);
extern Clo g_green_2ealone_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s1139265617x957540378(V, V, V, V, V, V);
V g_green_2ego_24s1139265617x957540378_entry(V self, V *a);
extern Clo g_green_2ego_24s1139265617x957540378_clo;
V g_green_2egreen_get(void);
HeffT3 g_green_2etakeQ_24cpr(V);
V g_green_2ethenRes(V, V, V);
V g_green_2ethenRes_entry(V self, V *a);
extern Clo g_green_2ethenRes_clo;
V g_green_2eview(V, V);
V g_green_2eview_entry(V self, V *a);
extern Clo g_green_2eview_clo;
V g_list_2eall_24s852887114x1468859299(V);
V g_list_2eall_24s852887114x1468859299_entry(V self, V *a);
extern Clo g_list_2eall_24s852887114x1468859299_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2062876492x2082655823(V, V);
V g_list_2efoldl_24s2062876492x2082655823_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2ereactor_2estart_24s1697505031x474729009(V, V, V, V, V);
V g_std_2ereactor_2estart_24s1697505031x474729009_entry(V self, V *a);
extern Clo g_std_2ereactor_2estart_24s1697505031x474729009_clo;
V g_green_2egreen_lam1(V self, V *args);
V g_green_2egreen_lam2(V self, V *args);
V g_green_2egreen_lam0(V self, V *args); static Clo g_green_2egreen_lam0_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreen_lam0, 3, 0};
V g_green_2egreen_lam3(V self, V *args); static Clo g_green_2egreen_lam3_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreen_lam3, 4, 0};

static V g_green_2egreen_val;
static HEFF_ONCE g_green_2egreen_st;
static V g_green_2egreen_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_green_2egreen_lam0_clo), ((V)&g_green_2egreen_lam3_clo)});
}
V g_green_2egreen_get(void) {
  if (HEFF_DONE(g_green_2egreen_st)) return g_green_2egreen_val;
  return heff_global(&g_green_2egreen_val, &g_green_2egreen_st, g_green_2egreen_init);
}
V g_green_2egreen_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tr(heff_call(v_k_248, 1, (V[]){v_n_249}));
  V f_ = v_g_241;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2egreen_lam2(V self, V *args) {
  V v_v_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_call(v_k_2416, 1, (V[]){v_v_2417}));
  V f_ = v_g_241;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2egreen_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Spawn: {
    V v_c_243 = heff_field(v_p_242, 0);
    V v_x_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Spawn = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_244}));
    return heff_tag_at_n(v_ru_24p_242_24Spawn, TAG_Spawn, 2, (V[]){v_c_243, v_t_245});
  }
  case TAG_Yield: {
    V v_x_246 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Yield = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_246}));
    return heff_tag_at_n(v_ru_24p_242_24Yield, TAG_Yield, 1, (V[]){v_t_247});
  }
  case TAG_NewKey: {
    V v_k_248 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24NewKey = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24NewKey, TAG_NewKey, 1, (V[]){heff_clo_n(g_green_2egreen_lam1, 1, 2, (V[]){v_k_248, v_g_241})});
  }
  case TAG_Wake: {
    V v_ch_2411 = heff_field(v_p_242, 0);
    V v_v_2412 = heff_field(v_p_242, 1);
    V v_x_2413 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Wake = heff_take_reuse_n(v_p_242, 7ULL, 3);
    V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
    return heff_tag_at_n(v_ru_24p_242_24Wake, TAG_Wake, 3, (V[]){v_ch_2411, v_v_2412, v_t_2414});
  }
  case TAG_Park: {
    V v_ch_2415 = heff_field(v_p_242, 0);
    V v_k_2416 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Park = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Park, TAG_Park, 2, (V[]){v_ch_2415, heff_clo_n(g_green_2egreen_lam2, 1, 2, (V[]){v_k_2416, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_green_2egreen_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  heff_drop(v_m_2419);
  heff_drop(v_n_2420);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_Spawn: {
    V v_c_2423 = heff_field(v_p_2422, 0);
    V v_x_2424 = heff_field(v_p_2422, 1);
    V v_ru_24p_2422_24Spawn = heff_take_reuse_n(v_p_2422, 3ULL, 2);
    V v_t_2425 = heff_tr(heff_call(v_nt_2421, 1, (V[]){v_c_2423}));
    return heff_tag_at_n(v_ru_24p_2422_24Spawn, TAG_Spawn, 2, (V[]){v_t_2425, v_x_2424});
  }
  case TAG_Yield: {
    V v_x_2426 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24Yield = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24Yield, TAG_Yield, 1, (V[]){v_x_2426});
  }
  case TAG_NewKey: {
    V v_k_2427 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24NewKey = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24NewKey, TAG_NewKey, 1, (V[]){v_k_2427});
  }
  case TAG_Wake: {
    V v_ch_2428 = heff_field(v_p_2422, 0);
    V v_v_2429 = heff_field(v_p_2422, 1);
    V v_x_2430 = heff_field(v_p_2422, 2);
    V v_ru_24p_2422_24Wake = heff_take_reuse_n(v_p_2422, 7ULL, 3);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24Wake, TAG_Wake, 3, (V[]){v_ch_2428, v_v_2429, v_x_2430});
  }
  case TAG_Park: {
    V v_ch_2431 = heff_field(v_p_2422, 0);
    V v_k_2432 = heff_field(v_p_2422, 1);
    V v_ru_24p_2422_24Park = heff_take_reuse_n(v_p_2422, 3ULL, 2);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24Park, TAG_Park, 2, (V[]){v_ch_2431, v_k_2432});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_green_2ethenRes_lam0(V self, V *args);
V g_green_2ethenRes_lam1(V self, V *args);
V g_green_2ethenRes_lam2(V self, V *args);
V g_green_2ethenRes_lam3(V self, V *args);
V g_green_2ethenRes_lam4(V self, V *args);
V g_green_2ethenRes_lam6(V self, V *args);
V g_green_2ethenRes_lam5(V self, V *args);
Clo g_green_2ethenRes_clo = {{0x80000000u, K_CLO, 0}, g_green_2ethenRes_entry, 3, 0};

V g_green_2ethenRes(V v_e_240, V v_x1_241, V v_f_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_RDone: {
    V v_x_243 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    return heff_tail(v_f_242, 1, (V[]){v_x_243});
  }
  case TAG_RYield: {
    V v_k_244 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24RYield = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241_24RYield, TAG_RYield, 1, (V[]){heff_clo_n(g_green_2ethenRes_lam0, 1, 3, (V[]){v_k_244, heff_dup(v_e_240), v_f_242})});
  }
  case TAG_RSpawn: {
    V v_c_247 = heff_field(v_x1_241, 0);
    V v_k_248 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24RSpawn = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_241_24RSpawn, TAG_RSpawn, 2, (V[]){v_c_247, heff_clo_n(g_green_2ethenRes_lam1, 1, 3, (V[]){v_k_248, heff_dup(v_e_240), v_f_242})});
  }
  case TAG_RKey: {
    V v_k_2411 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24RKey = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241_24RKey, TAG_RKey, 1, (V[]){heff_clo_n(g_green_2ethenRes_lam2, 1, 3, (V[]){v_k_2411, heff_dup(v_e_240), v_f_242})});
  }
  case TAG_RWake: {
    V v_ch_2414 = heff_field(v_x1_241, 0);
    V v_v_2415 = heff_field(v_x1_241, 1);
    V v_k_2416 = heff_field(v_x1_241, 2);
    V v_ru_24x1_241_24RWake = heff_take_reuse_n(v_x1_241, 7ULL, 3);
    return heff_tag_at_n(v_ru_24x1_241_24RWake, TAG_RWake, 3, (V[]){v_ch_2414, v_v_2415, heff_clo_n(g_green_2ethenRes_lam3, 1, 3, (V[]){v_k_2416, heff_dup(v_e_240), v_f_242})});
  }
  case TAG_RPark: {
    V v_ch_2419 = heff_field(v_x1_241, 0);
    V v_k_2420 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24RPark = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_241_24RPark, TAG_RPark, 2, (V[]){v_ch_2419, heff_clo_n(g_green_2ethenRes_lam4, 1, 3, (V[]){v_k_2420, heff_dup(v_e_240), v_f_242})});
  }
  case TAG_RAct: {
    V v_m_2423 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24RAct = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241_24RAct, TAG_RAct, 1, (V[]){heff_clo_n(g_green_2ethenRes_lam5, 2, 3, (V[]){v_m_2423, heff_dup(v_e_240), v_f_242})});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_green_2ethenRes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_green_2ethenRes(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_green_2ethenRes_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_u_245}));
  return ({ V a_0 = v_e_240; V a_1 = v_t_246; V a_2 = v_f_242; V r_ = (g_green_2ethenRes(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
}
V g_green_2ethenRes_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tr(heff_call(v_k_248, 1, (V[]){v_u_249}));
  return ({ V a_0 = v_e_240; V a_1 = v_t_2410; V a_2 = v_f_242; V r_ = (g_green_2ethenRes(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
}
V g_green_2ethenRes_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_n_2412}));
  return ({ V a_0 = v_e_240; V a_1 = v_t_2413; V a_2 = v_f_242; V r_ = (g_green_2ethenRes(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
}
V g_green_2ethenRes_lam3(V self, V *args) {
  V v_u_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tr(heff_call(v_k_2416, 1, (V[]){v_u_2417}));
  return ({ V a_0 = v_e_240; V a_1 = v_t_2418; V a_2 = v_f_242; V r_ = (g_green_2ethenRes(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
}
V g_green_2ethenRes_lam4(V self, V *args) {
  V v_v_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_tr(heff_call(v_k_2420, 1, (V[]){v_v_2421}));
  return ({ V a_0 = v_e_240; V a_1 = v_t_2422; V a_2 = v_f_242; V r_ = (g_green_2ethenRes(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
}
V g_green_2ethenRes_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2427 = ({ V a_0 = v_e_240; V a_1 = v_x_2426; V a_2 = v_f_242; V r_ = heff_tr(g_green_2ethenRes(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
  V f_ = v_k_2425;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ethenRes_lam5(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_m_2423 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_m_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_green_2ethenRes_lam6, 1, 3, (V[]){v_e_240, v_f_242, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ealone_lam0(V self, V *args);
V g_green_2ealone_lam2(V self, V *args);
V g_green_2ealone_lam1(V self, V *args);
Clo g_green_2ealone_clo = {{0x80000000u, K_CLO, 0}, g_green_2ealone_entry, 2, 0};

V g_green_2ealone(V v_e_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_RDone: {
    V v_x_242 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    heff_drop(v_e_240);
    return heff_clo_n(g_green_2ealone_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_RYield: {
    V v_k_245 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(v_k_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_e_240;
    V t_1 = v_t_246;
    v_e_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_RSpawn: {
    V v_k_248 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 2ULL, 2);
    V v_t_249 = heff_tr(heff_call(v_k_248, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_e_240;
    V t_1 = v_t_249;
    v_e_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_RKey: {
    V v_k_2410 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_t_2411 = heff_tr(heff_call(v_k_2410, 1, (V[]){MK_INT(0LL)}));
    V t_0 = v_e_240;
    V t_1 = v_t_2411;
    v_e_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_RWake: {
    V v_k_2414 = heff_field(v_x1_241, 2);
    heff_take_n(v_x1_241, 4ULL, 3);
    V v_t_2415 = heff_tr(heff_call(v_k_2414, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_e_240;
    V t_1 = v_t_2415;
    v_e_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_RPark: {
    V v_k_2417 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 2ULL, 2);
    V v_t_2418 = heff_tr(heff_call(v_k_2417, 1, (V[]){MK_INT(0LL)}));
    V t_0 = v_e_240;
    V t_1 = v_t_2418;
    v_e_240 = t_0;
    v_x1_241 = t_1;
    goto top;
  }
  case TAG_RAct: {
    V v_m_2419 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_f_2420 = heff_tr(heff_call(((V)&g_green_2ealone_clo), 1, (V[]){v_e_240}));
    return heff_clo_n(g_green_2ealone_lam1, 2, 2, (V[]){v_m_2419, v_f_2420});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_green_2ealone_entry(V self, V *a) {
  (void)self;
  return g_green_2ealone(a[0], a[1]);
}
V g_green_2ealone_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ealone_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_f_2420 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_2420;
  heff_room[0] = v_x_2423;
  heff_room[1] = v_hd_2421;
  heff_room[2] = v_k_2422;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_green_2ealone_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_m_2419 = heff_env(self)[0];
  V v_f_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_m_2419;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_green_2ealone_lam2, 1, 3, (V[]){v_f_2420, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2eview_lam0(V self, V *args);
V g_green_2eview_lam1(V self, V *args);
V g_green_2eview_lam2(V self, V *args);
V g_green_2eview_lam3(V self, V *args);
V g_green_2eview_lam4(V self, V *args);
V g_green_2eview_lam6(V self, V *args);
V g_green_2eview_lam5(V self, V *args);
V g_green_2eview_lam7(V self, V *args);
V g_green_2eview_lam8(V self, V *args);
V g_green_2eview_lam9(V self, V *args);
V g_green_2eview_lam10(V self, V *args);
V g_green_2eview_lam11(V self, V *args);
V g_green_2eview_lam13(V self, V *args);
V g_green_2eview_lam12(V self, V *args);
Clo g_green_2eview_clo = {{0x80000000u, K_CLO, 0}, g_green_2eview_entry, 2, 0};

V g_green_2eview(V v_e_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Main: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Main = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_RDone: {
      V v_x_243 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241_24Main, TAG_SFinal, 1, (V[]){v_x_243});
    }
    case TAG_RYield: {
      V v_k_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241_24Main, TAG_SYield, 1, (V[]){heff_clo_n(g_green_2eview_lam0, 1, 1, (V[]){v_k_244})});
    }
    case TAG_RSpawn: {
      V v_c_247 = heff_field(v_x11_242, 0);
      V v_k_248 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24RSpawn = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_242_24RSpawn, TAG_SSpawn, 2, (V[]){v_c_247, heff_clo_n(g_green_2eview_lam1, 1, 1, (V[]){v_k_248})});
    }
    case TAG_RKey: {
      V v_k_2411 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241_24Main, TAG_SKey, 1, (V[]){heff_clo_n(g_green_2eview_lam2, 1, 1, (V[]){v_k_2411})});
    }
    case TAG_RWake: {
      V v_ch_2414 = heff_field(v_x11_242, 0);
      V v_v_2415 = heff_field(v_x11_242, 1);
      V v_k_2416 = heff_field(v_x11_242, 2);
      V v_ru_24x11_242_24RWake = heff_take_reuse_n(v_x11_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_242_24RWake, TAG_SWake, 3, (V[]){v_ch_2414, v_v_2415, heff_clo_n(g_green_2eview_lam3, 1, 1, (V[]){v_k_2416})});
    }
    case TAG_RPark: {
      V v_ch_2419 = heff_field(v_x11_242, 0);
      V v_k_2420 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24RPark = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_242_24RPark, TAG_SPark, 2, (V[]){v_ch_2419, heff_clo_n(g_green_2eview_lam4, 1, 1, (V[]){v_k_2420})});
    }
    case TAG_RAct: {
      V v_m_2423 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241_24Main, TAG_SAct, 1, (V[]){heff_clo_n(g_green_2eview_lam5, 2, 1, (V[]){v_m_2423})});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_Other: {
    V v_x11_2427 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Other = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2427)) {
    case TAG_RDone: {
      heff_take_n(v_x11_2427, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24Other, 1);
      return NTAG(TAG_SEnd);
    }
    case TAG_RYield: {
      V v_k_2429 = heff_field(v_x11_2427, 0);
      heff_take_n(v_x11_2427, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241_24Other, TAG_SYield, 1, (V[]){heff_clo_n(g_green_2eview_lam7, 1, 1, (V[]){v_k_2429})});
    }
    case TAG_RSpawn: {
      V v_c_2432 = heff_field(v_x11_2427, 0);
      V v_k_2433 = heff_field(v_x11_2427, 1);
      V v_ru_24x11_2427_24RSpawn = heff_take_reuse_n(v_x11_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2427_24RSpawn, TAG_SSpawn, 2, (V[]){v_c_2432, heff_clo_n(g_green_2eview_lam8, 1, 1, (V[]){v_k_2433})});
    }
    case TAG_RKey: {
      V v_k_2436 = heff_field(v_x11_2427, 0);
      heff_take_n(v_x11_2427, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241_24Other, TAG_SKey, 1, (V[]){heff_clo_n(g_green_2eview_lam9, 1, 1, (V[]){v_k_2436})});
    }
    case TAG_RWake: {
      V v_ch_2439 = heff_field(v_x11_2427, 0);
      V v_v_2440 = heff_field(v_x11_2427, 1);
      V v_k_2441 = heff_field(v_x11_2427, 2);
      V v_ru_24x11_2427_24RWake = heff_take_reuse_n(v_x11_2427, 7ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2427_24RWake, TAG_SWake, 3, (V[]){v_ch_2439, v_v_2440, heff_clo_n(g_green_2eview_lam10, 1, 1, (V[]){v_k_2441})});
    }
    case TAG_RPark: {
      V v_ch_2444 = heff_field(v_x11_2427, 0);
      V v_k_2445 = heff_field(v_x11_2427, 1);
      V v_ru_24x11_2427_24RPark = heff_take_reuse_n(v_x11_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2427_24RPark, TAG_SPark, 2, (V[]){v_ch_2444, heff_clo_n(g_green_2eview_lam11, 1, 1, (V[]){v_k_2445})});
    }
    case TAG_RAct: {
      V v_m_2448 = heff_field(v_x11_2427, 0);
      heff_take_n(v_x11_2427, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241_24Other, TAG_SAct, 1, (V[]){heff_clo_n(g_green_2eview_lam12, 2, 1, (V[]){v_m_2448})});
    }
    default: return heff_nomatch(v_x11_2427);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_green_2eview_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_green_2eview(a0, a[1]); heff_drop(a0); return r;
}
V g_green_2eview_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_u_245}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_246});
}
V g_green_2eview_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tr(heff_call(v_k_248, 1, (V[]){v_u_249}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2410});
}
V g_green_2eview_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_n_2412}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2413});
}
V g_green_2eview_lam3(V self, V *args) {
  V v_u_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tr(heff_call(v_k_2416, 1, (V[]){v_u_2417}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2418});
}
V g_green_2eview_lam4(V self, V *args) {
  V v_v_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tr(heff_call(v_k_2420, 1, (V[]){v_v_2421}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2422});
}
V g_green_2eview_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Main, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2eview_lam5(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_green_2eview_lam6, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2eview_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tr(heff_call(v_k_2429, 1, (V[]){v_u_2430}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2431});
}
V g_green_2eview_lam8(V self, V *args) {
  V v_u_2434 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tr(heff_call(v_k_2433, 1, (V[]){v_u_2434}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2435});
}
V g_green_2eview_lam9(V self, V *args) {
  V v_n_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tr(heff_call(v_k_2436, 1, (V[]){v_n_2437}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2438});
}
V g_green_2eview_lam10(V self, V *args) {
  V v_u_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tr(heff_call(v_k_2441, 1, (V[]){v_u_2442}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2443});
}
V g_green_2eview_lam11(V self, V *args) {
  V v_v_2446 = args[0];
  V v_k_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_tr(heff_call(v_k_2445, 1, (V[]){v_v_2446}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2447});
}
V g_green_2eview_lam13(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2450;
  args[0] = heff_tag_n(TAG_Other, 1, (V[]){v_x_2451});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2eview_lam12(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_m_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2448;
  args[0] = v_hd_2449;
  args[1] = heff_clo_n(g_green_2eview_lam13, 1, 1, (V[]){v_k_2450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

static V g_green_2eemptyQ_val;
static HEFF_ONCE g_green_2eemptyQ_st;
static V g_green_2eemptyQ_init(void) {
  return heff_rec_n(2, shape_front__back, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_green_2eemptyQ_get(void) {
  if (HEFF_DONE(g_green_2eemptyQ_st)) return g_green_2eemptyQ_val;
  return heff_global(&g_green_2eemptyQ_val, &g_green_2eemptyQ_st, g_green_2eemptyQ_init);
}

HeffT3 g_green_2etakeQ_24cpr(V v_x1_240) {
top: ;
  V v_front_241 = heff_take_field(v_x1_240, 0);
  V v_back_242 = heff_get_n(v_x1_240, 1, 2);
  V v_front_27_243 = v_front_241;
  V v_b_244 = v_back_242;
  switch (heff_tag_of(v_front_27_243)) {
  case TAG_Nil: {
    V v_x1_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_b_244));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nil: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x1_245, 0);
      V v_rest_247 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 3ULL, 2);
      V v_t_248 = heff_rec_n(2, shape_front__back, (V[]){v_rest_247, NTAG(TAG_Nil)});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_246, v_t_248}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x1_245)}});
    }
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_front_27_243, 0);
    V v_rest_2410 = heff_field(v_front_27_243, 1);
    heff_take_n(v_front_27_243, 3ULL, 2);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_249, heff_rec_n(2, shape_front__back, (V[]){v_rest_2410, v_b_244})}});
  }
  default: return ((HeffT3){{heff_nomatch(v_front_27_243)}});
  }
}
V g_green_2ego_24s1139265617x957540378_lam1(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam0(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam2(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam3(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam5(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam4(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam7(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam7_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam7, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam6(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam6_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam6, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam9(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam8(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam11(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam10(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam13(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam13_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam13, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam12(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam12_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam12, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam16(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam15(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam14(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam17(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam18(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam20(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam19(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam22(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam22_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam22, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam21(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam21_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam21, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam24(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam23(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam26(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam25(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam28(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam28_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam28, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam27(V self, V *args); static Clo g_green_2ego_24s1139265617x957540378_lam27_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_lam27, 1, 0};
V g_green_2ego_24s1139265617x957540378_lam31(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam30(V self, V *args);
V g_green_2ego_24s1139265617x957540378_lam29(V self, V *args);
Clo g_green_2ego_24s1139265617x957540378_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s1139265617x957540378_entry, 6, 0};

V g_green_2ego_24s1139265617x957540378(V v_lit_240, V v_e_241, V v_g_242, V v_j_243, V v_s_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_j_243)) {
  case TAG_Alone: {
    top_TAG_Alone: ;
    switch (heff_tag_of(v_x5_245)) {
    case TAG_SFinal: {
      V v_x_246 = heff_field(v_x5_245, 0);
      heff_take_n(v_x5_245, 1ULL, 1);
      heff_drop_rec(v_s_244, 6);
      return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam0, 2, 3, (V[]){v_g_242, v_lit_240, v_x_246});
    }
    case TAG_SEnd: {
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_s_244;
      V t_5 = NTAG(TAG_SNext);
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SYield: {
      V v_k_2415 = heff_field(v_x5_245, 0);
      heff_take_n(v_x5_245, 1ULL, 1);
      V v_q_2416 = heff_take_field(v_s_244, 0);
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_2415, heff_take_field(v_q_2416, 1)});
      V v_t_2418 = ({ V rv_1 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_q_2416, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2419 = ({ V rv_0 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_s_244, 62ULL, 6, shape_ready__woken__parked__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_t_2419;
      V t_5 = NTAG(TAG_SNext);
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SSpawn: {
      V v_c_2420 = heff_field(v_x5_245, 0);
      V v_k_2421 = heff_field(v_x5_245, 1);
      V v_ru_24x5_245_24SSpawn = heff_take_reuse_n(v_x5_245, 3ULL, 2);
      V v_q_2422 = heff_take_field(v_s_244, 0);
      V v_t_2424 = heff_tag_at_n(v_ru_24x5_245_24SSpawn, TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s1139265617x957540378_lam2, 1, 1, (V[]){v_c_2420}), heff_dup(heff_rfield(v_q_2422, 1))});
      V v_t_2425 = ({ V rv_1 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_q_2422, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2426 = ({ V rv_0 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_s_244, 62ULL, 6, shape_ready__woken__parked__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2427 = heff_tr(heff_call(v_k_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2428 = (g_green_2eview(v_e_241, v_t_2427));
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_t_2426;
      V t_5 = v_t_2428;
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SKey: {
      V v_k_2429 = heff_field(v_x5_245, 0);
      heff_take_n(v_x5_245, 1ULL, 1);
      V v_t_2430 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 3)), MK_INT(1LL));
      V v_t_2431 = heff_rec_n(6, shape_ready__woken__parked__next__pending__turns, (V[]){heff_take_field(v_s_244, 0), heff_take_field(v_s_244, 1), heff_take_field(v_s_244, 2), v_t_2430, heff_take_field(v_s_244, 4), heff_take_field(v_s_244, 5)});
      V v_t_2432 = heff_tr(heff_call(v_k_2429, 1, (V[]){heff_get_n(v_s_244, 3, 6)}));
      V v_t_2433 = (g_green_2eview(v_e_241, v_t_2432));
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_t_2431;
      V t_5 = v_t_2433;
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SWake: {
      V v_ch_2434 = heff_field(v_x5_245, 0);
      V v_v_2435 = heff_field(v_x5_245, 1);
      V v_k_2436 = heff_field(v_x5_245, 2);
      heff_take_n(v_x5_245, 7ULL, 3);
      HeffT2 v_t_2437 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 2), heff_dup(v_ch_2434)));
      V v_t_2441;
      {
        V v_field_2439 = v_t_2437.f[1];
        int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
        if ((v_tag_2438 == ((int64_t)0ULL))) {
          V v_x_2440 = v_field_2439;
          v_t_2441 = v_x_2440;
        } else {
          heff_drop(v_field_2439);
          v_t_2441 = heff_dup(g_green_2eemptyQ_get());
        }
      }
      HeffT3 v_t_2442 = (g_green_2etakeQ_24cpr(v_t_2441));
      {
        V v_field_2444 = v_t_2442.f[1];
        V v_field_2445 = v_t_2442.f[2];
        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
        if ((v_tag_2443 == ((int64_t)0ULL))) {
          V v_w_2446 = v_field_2444;
          V v_ws_2447 = v_field_2445;
          V v_q_2448 = heff_take_field(v_s_244, 0);
          V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s1139265617x957540378_lam3, 1, 2, (V[]){v_w_2446, v_v_2435}), heff_take_field(v_q_2448, 1)});
          V v_t_2451 = ({ V rv_1 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_q_2448, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2452 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 2), v_ch_2434, v_ws_2447));
          V v_t_2453 = ({ V rv_0 = v_t_2451; V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_s_244, 58ULL, 6, shape_ready__woken__parked__next__pending__turns, 4044u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2454 = heff_tr(heff_call(v_k_2436, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2455 = (g_green_2eview(v_e_241, v_t_2454));
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_2453;
          V t_5 = v_t_2455;
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        } else {
          heff_drop(v_field_2444);
          heff_drop(v_field_2445);
          HeffT2 v_t_2456 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 1), heff_dup(v_ch_2434)));
          V v_t_2462;
          {
            V v_field_2458 = v_t_2456.f[1];
            int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
            V v_q_2460;
            if ((v_tag_2457 == ((int64_t)0ULL))) {
              V v_x_2459 = v_field_2458;
              v_q_2460 = v_x_2459;
            } else {
              heff_drop(v_field_2458);
              v_q_2460 = heff_dup(g_green_2eemptyQ_get());
            }
            V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2435, heff_take_field(v_q_2460, 1)});
            v_t_2462 = ({ V rv_1 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_q_2460, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          V v_t_2463 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 1), v_ch_2434, v_t_2462));
          V v_t_2464 = ({ V rv_1 = v_t_2463; V rr_ = heff_rec_reuse_nf(v_s_244, 61ULL, 6, shape_ready__woken__parked__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2465 = heff_tr(heff_call(v_k_2436, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2466 = (g_green_2eview(v_e_241, v_t_2465));
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_2464;
          V t_5 = v_t_2466;
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        }
      }
    }
    case TAG_SPark: {
      V v_ch_2467 = heff_field(v_x5_245, 0);
      V v_k_2468 = heff_field(v_x5_245, 1);
      V v_ru_24x5_245_24SPark = heff_take_reuse_n(v_x5_245, 3ULL, 2);
      HeffT2 v_t_2469 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 1), heff_dup(v_ch_2467)));
      V v_t_2473;
      {
        V v_field_2471 = v_t_2469.f[1];
        int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
        if ((v_tag_2470 == ((int64_t)0ULL))) {
          V v_x_2472 = v_field_2471;
          v_t_2473 = v_x_2472;
        } else {
          heff_drop(v_field_2471);
          v_t_2473 = heff_dup(g_green_2eemptyQ_get());
        }
      }
      HeffT3 v_t_2474 = (g_green_2etakeQ_24cpr(v_t_2473));
      {
        V v_field_2476 = v_t_2474.f[1];
        V v_field_2477 = v_t_2474.f[2];
        int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
        if ((v_tag_2475 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x5_245_24SPark, 2);
          V v_v_2478 = v_field_2476;
          V v_vs_2479 = v_field_2477;
          V v_t_2480 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 1), v_ch_2467, v_vs_2479));
          V v_t_2481 = ({ V rv_1 = v_t_2480; V rr_ = heff_rec_reuse_nf(v_s_244, 61ULL, 6, shape_ready__woken__parked__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2482 = heff_tr(heff_call(v_k_2468, 1, (V[]){v_v_2478}));
          V v_t_2483 = (g_green_2eview(v_e_241, v_t_2482));
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_2481;
          V t_5 = v_t_2483;
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        } else {
          heff_drop(v_field_2476);
          heff_drop(v_field_2477);
          HeffT2 v_t_2484 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 2), heff_dup(v_ch_2467)));
          V v_t_2490;
          {
            V v_field_2486 = v_t_2484.f[1];
            int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
            V v_q_2488;
            if ((v_tag_2485 == ((int64_t)0ULL))) {
              V v_x_2487 = v_field_2486;
              v_q_2488 = v_x_2487;
            } else {
              heff_drop(v_field_2486);
              v_q_2488 = heff_dup(g_green_2eemptyQ_get());
            }
            V v_t_2489 = heff_tag_at_n(v_ru_24x5_245_24SPark, TAG_Cons, 2, (V[]){v_k_2468, heff_dup(heff_rfield(v_q_2488, 1))});
            v_t_2490 = ({ V rv_1 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_q_2488, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          V v_t_2491 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 2), v_ch_2467, v_t_2490));
          V v_t_2492 = ({ V rv_2 = v_t_2491; V rr_ = heff_rec_reuse_nf(v_s_244, 59ULL, 6, shape_ready__woken__parked__next__pending__turns, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_2492;
          V t_5 = NTAG(TAG_SNext);
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        }
      }
    }
    case TAG_SAct: {
      V v_m_2493 = heff_field(v_x5_245, 0);
      heff_take_n(v_x5_245, 1ULL, 1);
      return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam4, 2, 6, (V[]){v_lit_240, v_g_242, v_m_2493, v_s_244, heff_dup(v_e_241), v_j_243});
    }
    case TAG_SNext: {
      if ((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_244, 4))) && heff_intLe_c(MK_INT(64LL), heff_dup(heff_rfield(v_s_244, 5))))) {
        V v_c_24109;
        switch (heff_tag_of(v_g_242)) {
        case TAG_MkGroup: {
          V v_i_24103 = heff_dup(heff_field(v_g_242, 0));
          V v_t_24106 = heff_tag_n(TAG_Finish, 3, (V[]){v_i_24103, NTAG(TAG_False), ((V)&g_green_2ego_24s1139265617x957540378_lam6_clo)});
          V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})});
          V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
          v_c_24109 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})}));
          break;
        }
        default: heff_nomatch(v_g_242);
        }
        return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam8, 2, 5, (V[]){v_c_24109, v_s_244, v_lit_240, heff_dup(v_e_241), v_g_242});
      } else {
        HeffT3 v_t_24118 = (g_green_2etakeQ_24cpr(heff_dup(heff_rfield(v_s_244, 0))));
        {
          V v_field_24120 = v_t_24118.f[1];
          V v_field_24121 = v_t_24118.f[2];
          int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
          if ((v_tag_24119 == ((int64_t)0ULL))) {
            V v_t_24122 = v_field_24120;
            V v_q_24123 = v_field_24121;
            V v_t_24124 = heff_intAdd(heff_take_field(v_s_244, 5), MK_INT(1LL));
            V v_t_24125 = ({ V rv_0 = v_q_24123; V rv_5 = v_t_24124; V rr_ = heff_rec_reuse_nf(v_s_244, 30ULL, 6, shape_ready__woken__parked__next__pending__turns, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 5) = rv_5; rr_; });
            V v_t_24126 = heff_tr(heff_call(v_t_24122, 1, (V[]){NTAG(TAG_MkUnit)}));
            V v_t_24127 = (g_green_2eview(v_e_241, v_t_24126));
            V t_0 = v_lit_240;
            V t_1 = v_e_241;
            V t_2 = v_g_242;
            V t_3 = NTAG(TAG_Alone);
            V t_4 = v_t_24125;
            V t_5 = v_t_24127;
            v_lit_240 = t_0;
            v_e_241 = t_1;
            v_g_242 = t_2;
            v_j_243 = t_3;
            v_s_244 = t_4;
            v_x5_245 = t_5;
            goto top_TAG_Alone;
          } else {
            heff_drop(v_field_24120);
            heff_drop(v_field_24121);
            if (heff_intEq_c(heff_dup(heff_rfield(v_s_244, 4)), MK_INT(0LL))) {
              heff_drop_rec(v_s_244, 6);
              return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam10, 2, 2, (V[]){v_g_242, v_lit_240});
            } else {
              V v_c_24142;
              switch (heff_tag_of(v_g_242)) {
              case TAG_MkGroup: {
                V v_i_24136 = heff_dup(heff_field(v_g_242, 0));
                V v_t_24139 = heff_tag_n(TAG_Finish, 3, (V[]){v_i_24136, NTAG(TAG_True), ((V)&g_green_2ego_24s1139265617x957540378_lam12_clo)});
                V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
                V v_t_24141 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24140})});
                v_c_24142 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24141})}));
                break;
              }
              default: heff_nomatch(v_g_242);
              }
              return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam14, 2, 5, (V[]){v_c_24142, v_g_242, v_lit_240, v_s_244, heff_dup(v_e_241)});
            }
          }
        }
      }
    }
    default: return heff_nomatch(v_x5_245);
    }
  }
  case TAG_Joining: {
    switch (heff_tag_of(v_x5_245)) {
    case TAG_SFinal: {
      V v_x_24159 = heff_field(v_x5_245, 0);
      V v_ru_24x5_245_24SFinal = heff_take_reuse_n(v_x5_245, 1ULL, 1);
      heff_drop_tag(v_j_243, 1);
      V v_t_24160 = heff_tag_at_n(v_ru_24x5_245_24SFinal, TAG_Joining, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_24159})});
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_t_24160;
      V t_4 = v_s_244;
      V t_5 = NTAG(TAG_SNext);
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SEnd: {
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_s_244;
      V t_5 = NTAG(TAG_SNext);
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SYield: {
      V v_k_24161 = heff_field(v_x5_245, 0);
      heff_take_n(v_x5_245, 1ULL, 1);
      V v_q_24162 = heff_take_field(v_s_244, 0);
      V v_t_24163 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_24161, heff_take_field(v_q_24162, 1)});
      V v_t_24164 = ({ V rv_1 = v_t_24163; V rr_ = heff_rec_reuse_nf(v_q_24162, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_24165 = ({ V rv_0 = v_t_24164; V rr_ = heff_rec_reuse_nf(v_s_244, 62ULL, 6, shape_ready__woken__parked__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_t_24165;
      V t_5 = NTAG(TAG_SNext);
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SSpawn: {
      V v_c_24166 = heff_field(v_x5_245, 0);
      V v_k_24167 = heff_field(v_x5_245, 1);
      V v_ru_24x5_245_24SSpawn = heff_take_reuse_n(v_x5_245, 3ULL, 2);
      V v_q_24168 = heff_take_field(v_s_244, 0);
      V v_t_24170 = heff_tag_at_n(v_ru_24x5_245_24SSpawn, TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s1139265617x957540378_lam17, 1, 1, (V[]){v_c_24166}), heff_dup(heff_rfield(v_q_24168, 1))});
      V v_t_24171 = ({ V rv_1 = v_t_24170; V rr_ = heff_rec_reuse_nf(v_q_24168, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_24172 = ({ V rv_0 = v_t_24171; V rr_ = heff_rec_reuse_nf(v_s_244, 62ULL, 6, shape_ready__woken__parked__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24173 = heff_tr(heff_call(v_k_24167, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_24174 = (g_green_2eview(v_e_241, v_t_24173));
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_t_24172;
      V t_5 = v_t_24174;
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SKey: {
      V v_k_24175 = heff_field(v_x5_245, 0);
      heff_take_n(v_x5_245, 1ULL, 1);
      V v_t_24176 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 3)), MK_INT(1LL));
      V v_t_24177 = heff_rec_n(6, shape_ready__woken__parked__next__pending__turns, (V[]){heff_take_field(v_s_244, 0), heff_take_field(v_s_244, 1), heff_take_field(v_s_244, 2), v_t_24176, heff_take_field(v_s_244, 4), heff_take_field(v_s_244, 5)});
      V v_t_24178 = heff_tr(heff_call(v_k_24175, 1, (V[]){heff_get_n(v_s_244, 3, 6)}));
      V v_t_24179 = (g_green_2eview(v_e_241, v_t_24178));
      V t_0 = v_lit_240;
      V t_1 = v_e_241;
      V t_2 = v_g_242;
      V t_3 = v_j_243;
      V t_4 = v_t_24177;
      V t_5 = v_t_24179;
      v_lit_240 = t_0;
      v_e_241 = t_1;
      v_g_242 = t_2;
      v_j_243 = t_3;
      v_s_244 = t_4;
      v_x5_245 = t_5;
      goto top;
    }
    case TAG_SWake: {
      V v_ch_24180 = heff_field(v_x5_245, 0);
      V v_v_24181 = heff_field(v_x5_245, 1);
      V v_k_24182 = heff_field(v_x5_245, 2);
      heff_take_n(v_x5_245, 7ULL, 3);
      HeffT2 v_t_24183 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 2), heff_dup(v_ch_24180)));
      V v_t_24187;
      {
        V v_field_24185 = v_t_24183.f[1];
        int64_t v_tag_24184 = ((int64_t)v_t_24183.f[0]);
        if ((v_tag_24184 == ((int64_t)0ULL))) {
          V v_x_24186 = v_field_24185;
          v_t_24187 = v_x_24186;
        } else {
          heff_drop(v_field_24185);
          v_t_24187 = heff_dup(g_green_2eemptyQ_get());
        }
      }
      HeffT3 v_t_24188 = (g_green_2etakeQ_24cpr(v_t_24187));
      {
        V v_field_24190 = v_t_24188.f[1];
        V v_field_24191 = v_t_24188.f[2];
        int64_t v_tag_24189 = ((int64_t)v_t_24188.f[0]);
        if ((v_tag_24189 == ((int64_t)0ULL))) {
          V v_w_24192 = v_field_24190;
          V v_ws_24193 = v_field_24191;
          V v_q_24194 = heff_take_field(v_s_244, 0);
          V v_t_24196 = heff_tag_n(TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s1139265617x957540378_lam18, 1, 2, (V[]){v_w_24192, v_v_24181}), heff_take_field(v_q_24194, 1)});
          V v_t_24197 = ({ V rv_1 = v_t_24196; V rr_ = heff_rec_reuse_nf(v_q_24194, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24198 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 2), v_ch_24180, v_ws_24193));
          V v_t_24199 = ({ V rv_0 = v_t_24197; V rv_2 = v_t_24198; V rr_ = heff_rec_reuse_nf(v_s_244, 58ULL, 6, shape_ready__woken__parked__next__pending__turns, 4044u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_24200 = heff_tr(heff_call(v_k_24182, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_24201 = (g_green_2eview(v_e_241, v_t_24200));
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_24199;
          V t_5 = v_t_24201;
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        } else {
          heff_drop(v_field_24190);
          heff_drop(v_field_24191);
          HeffT2 v_t_24202 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 1), heff_dup(v_ch_24180)));
          V v_t_24208;
          {
            V v_field_24204 = v_t_24202.f[1];
            int64_t v_tag_24203 = ((int64_t)v_t_24202.f[0]);
            V v_q_24206;
            if ((v_tag_24203 == ((int64_t)0ULL))) {
              V v_x_24205 = v_field_24204;
              v_q_24206 = v_x_24205;
            } else {
              heff_drop(v_field_24204);
              v_q_24206 = heff_dup(g_green_2eemptyQ_get());
            }
            V v_t_24207 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_24181, heff_take_field(v_q_24206, 1)});
            v_t_24208 = ({ V rv_1 = v_t_24207; V rr_ = heff_rec_reuse_nf(v_q_24206, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          V v_t_24209 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 1), v_ch_24180, v_t_24208));
          V v_t_24210 = ({ V rv_1 = v_t_24209; V rr_ = heff_rec_reuse_nf(v_s_244, 61ULL, 6, shape_ready__woken__parked__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24211 = heff_tr(heff_call(v_k_24182, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_24212 = (g_green_2eview(v_e_241, v_t_24211));
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_24210;
          V t_5 = v_t_24212;
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        }
      }
    }
    case TAG_SPark: {
      V v_ch_24213 = heff_field(v_x5_245, 0);
      V v_k_24214 = heff_field(v_x5_245, 1);
      V v_ru_24x5_245_24SPark = heff_take_reuse_n(v_x5_245, 3ULL, 2);
      HeffT2 v_t_24215 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 1), heff_dup(v_ch_24213)));
      V v_t_24219;
      {
        V v_field_24217 = v_t_24215.f[1];
        int64_t v_tag_24216 = ((int64_t)v_t_24215.f[0]);
        if ((v_tag_24216 == ((int64_t)0ULL))) {
          V v_x_24218 = v_field_24217;
          v_t_24219 = v_x_24218;
        } else {
          heff_drop(v_field_24217);
          v_t_24219 = heff_dup(g_green_2eemptyQ_get());
        }
      }
      HeffT3 v_t_24220 = (g_green_2etakeQ_24cpr(v_t_24219));
      {
        V v_field_24222 = v_t_24220.f[1];
        V v_field_24223 = v_t_24220.f[2];
        int64_t v_tag_24221 = ((int64_t)v_t_24220.f[0]);
        if ((v_tag_24221 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x5_245_24SPark, 2);
          V v_v_24224 = v_field_24222;
          V v_vs_24225 = v_field_24223;
          V v_t_24226 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 1), v_ch_24213, v_vs_24225));
          V v_t_24227 = ({ V rv_1 = v_t_24226; V rr_ = heff_rec_reuse_nf(v_s_244, 61ULL, 6, shape_ready__woken__parked__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24228 = heff_tr(heff_call(v_k_24214, 1, (V[]){v_v_24224}));
          V v_t_24229 = (g_green_2eview(v_e_241, v_t_24228));
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_24227;
          V t_5 = v_t_24229;
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        } else {
          heff_drop(v_field_24222);
          heff_drop(v_field_24223);
          HeffT2 v_t_24230 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_s_244, 2), heff_dup(v_ch_24213)));
          V v_t_24236;
          {
            V v_field_24232 = v_t_24230.f[1];
            int64_t v_tag_24231 = ((int64_t)v_t_24230.f[0]);
            V v_q_24234;
            if ((v_tag_24231 == ((int64_t)0ULL))) {
              V v_x_24233 = v_field_24232;
              v_q_24234 = v_x_24233;
            } else {
              heff_drop(v_field_24232);
              v_q_24234 = heff_dup(g_green_2eemptyQ_get());
            }
            V v_t_24235 = heff_tag_at_n(v_ru_24x5_245_24SPark, TAG_Cons, 2, (V[]){v_k_24214, heff_dup(heff_rfield(v_q_24234, 1))});
            v_t_24236 = ({ V rv_1 = v_t_24235; V rr_ = heff_rec_reuse_nf(v_q_24234, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          V v_t_24237 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_s_244, 2), v_ch_24213, v_t_24236));
          V v_t_24238 = ({ V rv_2 = v_t_24237; V rr_ = heff_rec_reuse_nf(v_s_244, 59ULL, 6, shape_ready__woken__parked__next__pending__turns, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V t_0 = v_lit_240;
          V t_1 = v_e_241;
          V t_2 = v_g_242;
          V t_3 = v_j_243;
          V t_4 = v_t_24238;
          V t_5 = NTAG(TAG_SNext);
          v_lit_240 = t_0;
          v_e_241 = t_1;
          v_g_242 = t_2;
          v_j_243 = t_3;
          v_s_244 = t_4;
          v_x5_245 = t_5;
          goto top;
        }
      }
    }
    case TAG_SAct: {
      V v_m_24239 = heff_field(v_x5_245, 0);
      heff_take_n(v_x5_245, 1ULL, 1);
      return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam19, 2, 6, (V[]){v_lit_240, v_g_242, v_m_24239, v_s_244, heff_dup(v_e_241), v_j_243});
    }
    case TAG_SNext: {
      if ((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_244, 4))) && heff_intLe_c(MK_INT(64LL), heff_dup(heff_rfield(v_s_244, 5))))) {
        V v_c_24255;
        switch (heff_tag_of(v_g_242)) {
        case TAG_MkGroup: {
          V v_i_24249 = heff_dup(heff_field(v_g_242, 0));
          V v_t_24252 = heff_tag_n(TAG_Finish, 3, (V[]){v_i_24249, NTAG(TAG_False), ((V)&g_green_2ego_24s1139265617x957540378_lam21_clo)});
          V v_t_24253 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24252})});
          V v_t_24254 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24253})});
          v_c_24255 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24254})}));
          break;
        }
        default: heff_nomatch(v_g_242);
        }
        return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam23, 2, 6, (V[]){v_c_24255, v_s_244, v_lit_240, heff_dup(v_e_241), v_g_242, v_j_243});
      } else {
        HeffT3 v_t_24264 = (g_green_2etakeQ_24cpr(heff_dup(heff_rfield(v_s_244, 0))));
        {
          V v_field_24266 = v_t_24264.f[1];
          V v_field_24267 = v_t_24264.f[2];
          int64_t v_tag_24265 = ((int64_t)v_t_24264.f[0]);
          if ((v_tag_24265 == ((int64_t)0ULL))) {
            V v_t_24268 = v_field_24266;
            V v_q_24269 = v_field_24267;
            V v_t_24270 = heff_intAdd(heff_take_field(v_s_244, 5), MK_INT(1LL));
            V v_t_24271 = ({ V rv_0 = v_q_24269; V rv_5 = v_t_24270; V rr_ = heff_rec_reuse_nf(v_s_244, 30ULL, 6, shape_ready__woken__parked__next__pending__turns, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 5) = rv_5; rr_; });
            V v_t_24272 = heff_tr(heff_call(v_t_24268, 1, (V[]){NTAG(TAG_MkUnit)}));
            V v_t_24273 = (g_green_2eview(v_e_241, v_t_24272));
            V t_0 = v_lit_240;
            V t_1 = v_e_241;
            V t_2 = v_g_242;
            V t_3 = v_j_243;
            V t_4 = v_t_24271;
            V t_5 = v_t_24273;
            v_lit_240 = t_0;
            v_e_241 = t_1;
            v_g_242 = t_2;
            v_j_243 = t_3;
            v_s_244 = t_4;
            v_x5_245 = t_5;
            goto top;
          } else {
            heff_drop(v_field_24266);
            heff_drop(v_field_24267);
            if (heff_intEq_c(heff_dup(heff_rfield(v_s_244, 4)), MK_INT(0LL))) {
              V v_r_24278;
              switch (heff_tag_of(v_j_243)) {
              case TAG_Alone: {
                heff_drop_rec(v_s_244, 6);
                v_r_24278 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Joining: {
                V v_r_24274 = heff_field(v_j_243, 0);
                heff_take_n(v_j_243, 1ULL, 1);
                V v_t_24275 = ({ V b_0 = heff_get_n(v_s_244, 2, 6); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_24276 = (g_list_2emap_24s366344330x1145113647(v_t_24275));
                V v_t_24277 = ({ V a_0 = v_t_24276; V r_ = (g_list_2eall_24s852887114x1468859299(a_0)); heff_drop(v_t_24276); r_; });
                if ((heff_dup(v_t_24277) == NTAG(TAG_True))) {
                  heff_drop(v_t_24277);
                  v_r_24278 = v_r_24274;
                } else {
                  heff_drop(v_r_24274);
                  heff_drop(v_t_24277);
                  v_r_24278 = NTAG(TAG_Nothing);
                }
                break;
              }
              default: heff_nomatch(v_j_243);
              }
              return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam25, 2, 3, (V[]){v_g_242, v_lit_240, v_r_24278});
            } else {
              V v_c_24293;
              switch (heff_tag_of(v_g_242)) {
              case TAG_MkGroup: {
                V v_i_24287 = heff_dup(heff_field(v_g_242, 0));
                V v_t_24290 = heff_tag_n(TAG_Finish, 3, (V[]){v_i_24287, NTAG(TAG_True), ((V)&g_green_2ego_24s1139265617x957540378_lam27_clo)});
                V v_t_24291 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24290})});
                V v_t_24292 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24291})});
                v_c_24293 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24292})}));
                break;
              }
              default: heff_nomatch(v_g_242);
              }
              return heff_clo_n(g_green_2ego_24s1139265617x957540378_lam29, 2, 6, (V[]){v_c_24293, v_j_243, v_s_244, v_g_242, v_lit_240, heff_dup(v_e_241)});
            }
          }
        }
      }
    }
    default: return heff_nomatch(v_x5_245);
    }
  }
  default: return heff_nomatch(v_j_243);
  }
}
V g_green_2ego_24s1139265617x957540378_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_green_2ego_24s1139265617x957540378(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_green_2ego_24s1139265617x957540378_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_g_242 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_g_242)) {
  case TAG_MkGroup: {
    V v_i_249 = heff_field(v_g_242, 0);
    V v_ru_24g_242_24MkGroup = heff_take_reuse_n(v_g_242, 1ULL, 1);
    V v_t_2410 = heff_tag_n(TAG_Close, 2, (V[]){v_i_249, NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_at_n(v_ru_24g_242_24MkGroup, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    v_t_2413 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_lit_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})}));
    break;
  }
  default: heff_nomatch(v_g_242);
  }
  V f_ = v_t_2413;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam1, 1, 2, (V[]){v_k_248, v_x_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1139265617x957540378_lam2(V self, V *args) {
  V v_u_2423 = args[0];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return heff_tag_n(TAG_Other, 1, (V[]){v_c_2420});
}
V g_green_2ego_24s1139265617x957540378_lam3(V self, V *args) {
  V v_u_2449 = args[0];
  V v_w_2446 = heff_env(self)[0];
  V v_v_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2449);
  V f_ = v_w_2446;
  args[0] = v_v_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam5(V self, V *args) {
  V v_x_2496 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_g_242 = heff_env(self)[3];
  V v_j_243 = heff_env(self)[4];
  V v_hd_2494 = heff_env(self)[5];
  V v_k_2495 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2496)) {
  case TAG_Nothing: {
    V v_t_2497 = heff_intAdd(heff_take_field(v_s_244, 4), MK_INT(1LL));
    V v_t_2498 = ({ V rv_4 = v_t_2497; V rr_ = heff_rec_reuse_nf(v_s_244, 47ULL, 6, shape_ready__woken__parked__next__pending__turns, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_2499 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = v_j_243; V a_4 = v_t_2498; V a_5 = NTAG(TAG_SNext); V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
    V f_ = v_t_2499;
    heff_room[0] = v_hd_2494;
    heff_room[1] = v_k_2495;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_24100 = heff_field(v_x_2496, 0);
    heff_take_n(v_x_2496, 1ULL, 1);
    V v_t_24101 = (g_green_2eview(v_e_241, v_t_24100));
    V v_t_24102 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = v_j_243; V a_4 = v_s_244; V a_5 = v_t_24101; V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
    V f_ = v_t_24102;
    heff_room[0] = v_hd_2494;
    heff_room[1] = v_k_2495;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2496);
  }
}
V g_green_2ego_24s1139265617x957540378_lam4(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k_2495 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_g_242 = heff_env(self)[1];
  V v_m_2493 = heff_env(self)[2];
  V v_s_244 = heff_env(self)[3];
  V v_e_241 = heff_env(self)[4];
  V v_j_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_std_2ereactor_2estart_24s1697505031x474729009(heff_dup(v_lit_240), heff_dup(v_g_242), v_m_2493, heff_dup(v_hd_2494), heff_clo_n(g_green_2ego_24s1139265617x957540378_lam5, 1, 7, (V[]){v_s_244, v_lit_240, v_e_241, v_g_242, v_j_243, v_hd_2494, v_k_2495})));
}
V g_green_2ego_24s1139265617x957540378_lam7(V self, V *args) {
  V v_l_24105 = args[0];
  return v_l_24105;
}
V g_green_2ego_24s1139265617x957540378_lam6(V self, V *args) {
  V v_use_24104 = args[0];
  V f_ = v_use_24104;
  args[0] = ((V)&g_green_2ego_24s1139265617x957540378_lam7_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam9(V self, V *args) {
  V v_x_24112 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_g_242 = heff_env(self)[3];
  V v_hd_24110 = heff_env(self)[4];
  V v_k_24111 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24113 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_244, 0), heff_dup(v_x_24112)));
  V v_t_24114 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24112; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24112); r_; });
  V v_t_24115 = heff_intSub(heff_take_field(v_s_244, 4), v_t_24114);
  V v_t_24116 = ({ V rv_0 = v_t_24113; V rv_4 = v_t_24115; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_244, 14ULL, 6, shape_ready__woken__parked__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_t_24117 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = NTAG(TAG_Alone); V a_4 = v_t_24116; V a_5 = NTAG(TAG_SNext); V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
  V f_ = v_t_24117;
  heff_room[0] = v_hd_24110;
  heff_room[1] = v_k_24111;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_green_2ego_24s1139265617x957540378_lam8(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k_24111 = args[1];
  V v_c_24109 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_g_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24109;
  args[0] = heff_dup(v_hd_24110);
  args[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam9, 1, 6, (V[]){v_s_244, v_lit_240, v_e_241, v_g_242, v_hd_24110, v_k_24111});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1139265617x957540378_lam11(V self, V *args) {
  V v_x_24135 = args[0];
  V v_k_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24135);
  V f_ = v_k_24129;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam10(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  V v_g_242 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24134;
  switch (heff_tag_of(v_g_242)) {
  case TAG_MkGroup: {
    V v_i_24130 = heff_field(v_g_242, 0);
    V v_ru_24g_242_24MkGroup = heff_take_reuse_n(v_g_242, 1ULL, 1);
    V v_t_24131 = heff_tag_n(TAG_Close, 2, (V[]){v_i_24130, NTAG(TAG_MkUnit)});
    V v_t_24132 = heff_tag_at_n(v_ru_24g_242_24MkGroup, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24131})});
    V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24132})});
    v_t_24134 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_lit_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24133})}));
    break;
  }
  default: heff_nomatch(v_g_242);
  }
  V f_ = v_t_24134;
  args[0] = v_hd_24128;
  args[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam11, 1, 1, (V[]){v_k_24129});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1139265617x957540378_lam13(V self, V *args) {
  V v_l_24138 = args[0];
  return v_l_24138;
}
V g_green_2ego_24s1139265617x957540378_lam12(V self, V *args) {
  V v_use_24137 = args[0];
  V f_ = v_use_24137;
  args[0] = ((V)&g_green_2ego_24s1139265617x957540378_lam13_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam16(V self, V *args) {
  V v_x_24152 = args[0];
  V v_k_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24152);
  V f_ = v_k_24144;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam15(V self, V *args) {
  V v_x_24145 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_hd_24143 = heff_env(self)[2];
  V v_k_24144 = heff_env(self)[3];
  V v_s_244 = heff_env(self)[4];
  V v_e_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24146 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_24145));
  if (heff_intEq_c(v_t_24146, MK_INT(0LL))) {
    heff_drop(v_x_24145);
    heff_drop_rec(v_s_244, 6);
    heff_drop(v_e_241);
    V v_t_24151;
    switch (heff_tag_of(v_g_242)) {
    case TAG_MkGroup: {
      V v_i_24147 = heff_field(v_g_242, 0);
      V v_ru_24g_242_24MkGroup = heff_take_reuse_n(v_g_242, 1ULL, 1);
      V v_t_24148 = heff_tag_n(TAG_Close, 2, (V[]){v_i_24147, NTAG(TAG_MkUnit)});
      V v_t_24149 = heff_tag_at_n(v_ru_24g_242_24MkGroup, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24148})});
      V v_t_24150 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24149})});
      v_t_24151 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_lit_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24150})}));
      break;
    }
    default: heff_nomatch(v_g_242);
    }
    V f_ = v_t_24151;
    heff_room[0] = v_hd_24143;
    heff_room[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam16, 1, 1, (V[]){v_k_24144});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_24153 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_244, 0), heff_dup(v_x_24145)));
    V v_t_24154 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24145; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24145); r_; });
    V v_t_24155 = heff_intSub(heff_take_field(v_s_244, 4), v_t_24154);
    V v_t_24156 = ({ V rv_0 = v_t_24153; V rv_4 = v_t_24155; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_244, 14ULL, 6, shape_ready__woken__parked__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    V v_t_24157 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = NTAG(TAG_Alone); V a_4 = v_t_24156; V a_5 = NTAG(TAG_SNext); V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
    V f_ = v_t_24157;
    heff_room[0] = v_hd_24143;
    heff_room[1] = v_k_24144;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_green_2ego_24s1139265617x957540378_lam14(V self, V *args) {
  V v_hd_24143 = args[0];
  V v_k_24144 = args[1];
  V v_c_24142 = heff_env(self)[0];
  V v_g_242 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_s_244 = heff_env(self)[3];
  V v_e_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24142;
  args[0] = heff_dup(v_hd_24143);
  args[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam15, 1, 6, (V[]){v_g_242, v_lit_240, v_hd_24143, v_k_24144, v_s_244, v_e_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1139265617x957540378_lam17(V self, V *args) {
  V v_u_24169 = args[0];
  V v_c_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24169);
  return heff_tag_n(TAG_Other, 1, (V[]){v_c_24166});
}
V g_green_2ego_24s1139265617x957540378_lam18(V self, V *args) {
  V v_u_24195 = args[0];
  V v_w_24192 = heff_env(self)[0];
  V v_v_24181 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_24195);
  V f_ = v_w_24192;
  args[0] = v_v_24181;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam20(V self, V *args) {
  V v_x_24242 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_g_242 = heff_env(self)[3];
  V v_j_243 = heff_env(self)[4];
  V v_hd_24240 = heff_env(self)[5];
  V v_k_24241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_24242)) {
  case TAG_Nothing: {
    V v_t_24243 = heff_intAdd(heff_take_field(v_s_244, 4), MK_INT(1LL));
    V v_t_24244 = ({ V rv_4 = v_t_24243; V rr_ = heff_rec_reuse_nf(v_s_244, 47ULL, 6, shape_ready__woken__parked__next__pending__turns, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_24245 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = v_j_243; V a_4 = v_t_24244; V a_5 = NTAG(TAG_SNext); V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
    V f_ = v_t_24245;
    heff_room[0] = v_hd_24240;
    heff_room[1] = v_k_24241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_24246 = heff_field(v_x_24242, 0);
    heff_take_n(v_x_24242, 1ULL, 1);
    V v_t_24247 = (g_green_2eview(v_e_241, v_t_24246));
    V v_t_24248 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = v_j_243; V a_4 = v_s_244; V a_5 = v_t_24247; V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
    V f_ = v_t_24248;
    heff_room[0] = v_hd_24240;
    heff_room[1] = v_k_24241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24242);
  }
}
V g_green_2ego_24s1139265617x957540378_lam19(V self, V *args) {
  V v_hd_24240 = args[0];
  V v_k_24241 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_g_242 = heff_env(self)[1];
  V v_m_24239 = heff_env(self)[2];
  V v_s_244 = heff_env(self)[3];
  V v_e_241 = heff_env(self)[4];
  V v_j_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_std_2ereactor_2estart_24s1697505031x474729009(heff_dup(v_lit_240), heff_dup(v_g_242), v_m_24239, heff_dup(v_hd_24240), heff_clo_n(g_green_2ego_24s1139265617x957540378_lam20, 1, 7, (V[]){v_s_244, v_lit_240, v_e_241, v_g_242, v_j_243, v_hd_24240, v_k_24241})));
}
V g_green_2ego_24s1139265617x957540378_lam22(V self, V *args) {
  V v_l_24251 = args[0];
  return v_l_24251;
}
V g_green_2ego_24s1139265617x957540378_lam21(V self, V *args) {
  V v_use_24250 = args[0];
  V f_ = v_use_24250;
  args[0] = ((V)&g_green_2ego_24s1139265617x957540378_lam22_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam24(V self, V *args) {
  V v_x_24258 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_g_242 = heff_env(self)[3];
  V v_j_243 = heff_env(self)[4];
  V v_hd_24256 = heff_env(self)[5];
  V v_k_24257 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24259 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_244, 0), heff_dup(v_x_24258)));
  V v_t_24260 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24258; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24258); r_; });
  V v_t_24261 = heff_intSub(heff_take_field(v_s_244, 4), v_t_24260);
  V v_t_24262 = ({ V rv_0 = v_t_24259; V rv_4 = v_t_24261; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_244, 14ULL, 6, shape_ready__woken__parked__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_t_24263 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = v_j_243; V a_4 = v_t_24262; V a_5 = NTAG(TAG_SNext); V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
  V f_ = v_t_24263;
  heff_room[0] = v_hd_24256;
  heff_room[1] = v_k_24257;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_green_2ego_24s1139265617x957540378_lam23(V self, V *args) {
  V v_hd_24256 = args[0];
  V v_k_24257 = args[1];
  V v_c_24255 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_g_242 = heff_env(self)[4];
  V v_j_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_24255;
  args[0] = heff_dup(v_hd_24256);
  args[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam24, 1, 7, (V[]){v_s_244, v_lit_240, v_e_241, v_g_242, v_j_243, v_hd_24256, v_k_24257});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1139265617x957540378_lam26(V self, V *args) {
  V v_x_24286 = args[0];
  V v_k_24280 = heff_env(self)[0];
  V v_r_24278 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24286);
  V f_ = v_k_24280;
  args[0] = v_r_24278;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam25(V self, V *args) {
  V v_hd_24279 = args[0];
  V v_k_24280 = args[1];
  V v_g_242 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_r_24278 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24285;
  switch (heff_tag_of(v_g_242)) {
  case TAG_MkGroup: {
    V v_i_24281 = heff_field(v_g_242, 0);
    V v_ru_24g_242_24MkGroup = heff_take_reuse_n(v_g_242, 1ULL, 1);
    V v_t_24282 = heff_tag_n(TAG_Close, 2, (V[]){v_i_24281, NTAG(TAG_MkUnit)});
    V v_t_24283 = heff_tag_at_n(v_ru_24g_242_24MkGroup, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24282})});
    V v_t_24284 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24283})});
    v_t_24285 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_lit_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24284})}));
    break;
  }
  default: heff_nomatch(v_g_242);
  }
  V f_ = v_t_24285;
  args[0] = v_hd_24279;
  args[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam26, 1, 2, (V[]){v_k_24280, v_r_24278});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s1139265617x957540378_lam28(V self, V *args) {
  V v_l_24289 = args[0];
  return v_l_24289;
}
V g_green_2ego_24s1139265617x957540378_lam27(V self, V *args) {
  V v_use_24288 = args[0];
  V f_ = v_use_24288;
  args[0] = ((V)&g_green_2ego_24s1139265617x957540378_lam28_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam31(V self, V *args) {
  V v_x_24308 = args[0];
  V v_k_24295 = heff_env(self)[0];
  V v_r_24302 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24308);
  V f_ = v_k_24295;
  args[0] = v_r_24302;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s1139265617x957540378_lam30(V self, V *args) {
  V v_x_24296 = args[0];
  V v_j_243 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_g_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_hd_24294 = heff_env(self)[4];
  V v_k_24295 = heff_env(self)[5];
  V v_e_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24297 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_24296));
  if (heff_intEq_c(v_t_24297, MK_INT(0LL))) {
    heff_drop(v_x_24296);
    heff_drop(v_e_241);
    V v_r_24302;
    switch (heff_tag_of(v_j_243)) {
    case TAG_Alone: {
      heff_drop_rec(v_s_244, 6);
      v_r_24302 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Joining: {
      V v_r_24298 = heff_field(v_j_243, 0);
      heff_take_n(v_j_243, 1ULL, 1);
      V v_t_24299 = ({ V b_0 = heff_get_n(v_s_244, 2, 6); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_24300 = (g_list_2emap_24s366344330x1145113647(v_t_24299));
      V v_t_24301 = ({ V a_0 = v_t_24300; V r_ = (g_list_2eall_24s852887114x1468859299(a_0)); heff_drop(v_t_24300); r_; });
      if ((heff_dup(v_t_24301) == NTAG(TAG_True))) {
        heff_drop(v_t_24301);
        v_r_24302 = v_r_24298;
      } else {
        heff_drop(v_r_24298);
        heff_drop(v_t_24301);
        v_r_24302 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_j_243);
    }
    V v_t_24307;
    switch (heff_tag_of(v_g_242)) {
    case TAG_MkGroup: {
      V v_i_24303 = heff_field(v_g_242, 0);
      V v_ru_24g_242_24MkGroup = heff_take_reuse_n(v_g_242, 1ULL, 1);
      V v_t_24304 = heff_tag_n(TAG_Close, 2, (V[]){v_i_24303, NTAG(TAG_MkUnit)});
      V v_t_24305 = heff_tag_at_n(v_ru_24g_242_24MkGroup, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24304})});
      V v_t_24306 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24305})});
      v_t_24307 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_lit_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24306})}));
      break;
    }
    default: heff_nomatch(v_g_242);
    }
    V f_ = v_t_24307;
    heff_room[0] = v_hd_24294;
    heff_room[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam31, 1, 2, (V[]){v_k_24295, v_r_24302});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_24309 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_244, 0), heff_dup(v_x_24296)));
    V v_t_24310 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24296; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24296); r_; });
    V v_t_24311 = heff_intSub(heff_take_field(v_s_244, 4), v_t_24310);
    V v_t_24312 = ({ V rv_0 = v_t_24309; V rv_4 = v_t_24311; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_244, 14ULL, 6, shape_ready__woken__parked__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    V v_t_24313 = ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_g_242; V a_3 = v_j_243; V a_4 = v_t_24312; V a_5 = NTAG(TAG_SNext); V r_ = (g_green_2ego_24s1139265617x957540378(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_241); r_; });
    V f_ = v_t_24313;
    heff_room[0] = v_hd_24294;
    heff_room[1] = v_k_24295;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_green_2ego_24s1139265617x957540378_lam29(V self, V *args) {
  V v_hd_24294 = args[0];
  V v_k_24295 = args[1];
  V v_c_24293 = heff_env(self)[0];
  V v_j_243 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  V v_g_242 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_e_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_24293;
  args[0] = heff_dup(v_hd_24294);
  args[1] = heff_clo_n(g_green_2ego_24s1139265617x957540378_lam30, 1, 7, (V[]){v_j_243, v_s_244, v_g_242, v_lit_240, v_hd_24294, v_k_24295, v_e_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}