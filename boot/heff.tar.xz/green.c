// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Main 39920
#define TAG_NewChan 9424
#define TAG_Other 45236
#define TAG_RAct 26891
#define TAG_RDone 16778
#define TAG_RNew 39449
#define TAG_RRecv 30762
#define TAG_RSend 60876
#define TAG_RSpawn 40406
#define TAG_RYield 3356
#define TAG_Recv 61489
#define TAG_SAct 56682
#define TAG_SEnd 60851
#define TAG_SFinal 20030
#define TAG_SNew 3714
#define TAG_SNext 49456
#define TAG_SRecv 36919
#define TAG_SSend 1507
#define TAG_SSpawn 34695
#define TAG_SYield 63171
#define TAG_Send 26077
#define TAG_Spawn 10053
#define TAG_Yield 38529
#define LBL_back 9511342
#define LBL_chans 295981947
#define LBL_close 296114706
#define LBL_finished 71477802
#define LBL_fmap 9641981
#define LBL_front 299063875
#define LBL_hmap 9701563
#define LBL_next 9873338
#define LBL_pending 1696753626
#define LBL_ready 309745085
#define LBL_start 311115900
#define LBL_turns 312085424
#define LBL_waiting 1348170899
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_front__back[] = {LBL_front, LBL_back};
static uint32_t shape_ready__chans__waiting__next__pending__turns[] = {LBL_ready, LBL_chans, LBL_waiting, LBL_next, LBL_pending, LBL_turns};
V g_co_2eop_24s792193458x1346260978(V, V, V);
V g_co_2eop_24s792193458x1346260978_entry(V self, V *a);
extern Clo g_co_2eop_24s792193458x1346260978_clo;
V g_co_2eplus_24s1854017309x1005292301_get(void);
V g_green_2ealone_24s1898071788x975368556(V);
V g_green_2ealone_24s1898071788x975368556_entry(V self, V *a);
extern Clo g_green_2ealone_24s1898071788x975368556_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s482904806x1315522706(V, V, V, V);
V g_green_2ego_24s482904806x1315522706_entry(V self, V *a);
extern Clo g_green_2ego_24s482904806x1315522706_clo;
V g_green_2egreenAlg_24s1477571606x442912311(V);
V g_green_2egreenAlg_24s1477571606x442912311_entry(V self, V *a);
extern Clo g_green_2egreenAlg_24s1477571606x442912311_clo;
HeffT2 g_green_2etakeQ_24cpr(V);
V g_green_2ethenRes_24s1747913378x1698907254(V, V);
V g_green_2ethenRes_24s1747913378x1698907254_entry(V self, V *a);
extern Clo g_green_2ethenRes_24s1747913378x1698907254_clo;
V g_green_2ethenRes_24s352754375x1842358360(V);
V g_green_2ethenRes_24s352754375x1842358360_entry(V self, V *a);
extern Clo g_green_2ethenRes_24s352754375x1842358360_clo;
V g_green_2eview_24s658128430x1389625833(V);
V g_green_2eview_24s658128430x1389625833_entry(V self, V *a);
extern Clo g_green_2eview_24s658128430x1389625833_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2062876492x2082655823(V, V);
V g_list_2efoldl_24s2062876492x2082655823_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);

static V g_green_2eemptyQ_val;
static HEFF_ONCE g_green_2eemptyQ_st;
static V g_green_2eemptyQ_init(void) {
  return heff_rec_n(2, shape_front__back, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_green_2eemptyQ_get(void) {
  if (HEFF_DONE(g_green_2eemptyQ_st)) return g_green_2eemptyQ_val;
  return heff_global(&g_green_2eemptyQ_val, &g_green_2eemptyQ_st, g_green_2eemptyQ_init);
}

HeffT2 g_green_2etakeQ_24cpr(V v_x1_240) {
top: ;
  V v_b_241 = heff_take_field(v_x1_240, 1);
  V v_t_242 = heff_get_n(v_x1_240, 0, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_b_241));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x1_243, 0);
      V v_rest_245 = heff_field(v_x1_243, 1);
      V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
      V v_t_246 = heff_rec_n(2, shape_front__back, (V[]){v_rest_245, NTAG(TAG_Nil)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_MkPair, 2, (V[]){v_x_244, v_t_246})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_243)}});
    }
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_t_242, 0);
    V v_rest_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24Cons = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_249 = heff_tag_at_n(v_ru_24t_242_24Cons, TAG_MkPair, 2, (V[]){v_x_247, heff_rec_n(2, shape_front__back, (V[]){v_rest_248, v_b_241})});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_242)}});
  }
}
V g_green_2eview_24s658128430x1389625833_lam0(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam1(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam2(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam3(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam4(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam6(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam5(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam7(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam8(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam9(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam10(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam11(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam13(V self, V *args);
V g_green_2eview_24s658128430x1389625833_lam12(V self, V *args);
Clo g_green_2eview_24s658128430x1389625833_clo = {{0x80000000u, K_CLO, 0}, g_green_2eview_24s658128430x1389625833_entry, 1, 0};

V g_green_2eview_24s658128430x1389625833(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Main: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Main = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_RDone: {
      V v_x_242 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SFinal, 1, (V[]){v_x_242});
    }
    case TAG_RYield: {
      V v_k_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SYield, 1, (V[]){heff_clo_n(g_green_2eview_24s658128430x1389625833_lam0, 1, 1, (V[]){v_k_243})});
    }
    case TAG_RSpawn: {
      V v_c_246 = heff_field(v_x11_241, 0);
      V v_k_247 = heff_field(v_x11_241, 1);
      V v_ru_24x11_241_24RSpawn = heff_take_reuse_n(v_x11_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_241_24RSpawn, TAG_SSpawn, 2, (V[]){v_c_246, heff_clo_n(g_green_2eview_24s658128430x1389625833_lam1, 1, 1, (V[]){v_k_247})});
    }
    case TAG_RNew: {
      V v_k_2410 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SNew, 1, (V[]){heff_clo_n(g_green_2eview_24s658128430x1389625833_lam2, 1, 1, (V[]){v_k_2410})});
    }
    case TAG_RSend: {
      V v_ch_2413 = heff_field(v_x11_241, 0);
      V v_v_2414 = heff_field(v_x11_241, 1);
      V v_k_2415 = heff_field(v_x11_241, 2);
      V v_ru_24x11_241_24RSend = heff_take_reuse_n(v_x11_241, 7ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_241_24RSend, TAG_SSend, 3, (V[]){v_ch_2413, v_v_2414, heff_clo_n(g_green_2eview_24s658128430x1389625833_lam3, 1, 1, (V[]){v_k_2415})});
    }
    case TAG_RRecv: {
      V v_ch_2418 = heff_field(v_x11_241, 0);
      V v_k_2419 = heff_field(v_x11_241, 1);
      V v_ru_24x11_241_24RRecv = heff_take_reuse_n(v_x11_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Main, 1);
      return heff_tag_at_n(v_ru_24x11_241_24RRecv, TAG_SRecv, 2, (V[]){v_ch_2418, heff_clo_n(g_green_2eview_24s658128430x1389625833_lam4, 1, 1, (V[]){v_k_2419})});
    }
    case TAG_RAct: {
      V v_m_2422 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Main, TAG_SAct, 1, (V[]){heff_clo_n(g_green_2eview_24s658128430x1389625833_lam5, 2, 1, (V[]){v_m_2422})});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  case TAG_Other: {
    V v_x11_2426 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Other = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2426)) {
    case TAG_RDone: {
      heff_take_n(v_x11_2426, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return NTAG(TAG_SEnd);
    }
    case TAG_RYield: {
      V v_k_2428 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Other, TAG_SYield, 1, (V[]){heff_clo_n(g_green_2eview_24s658128430x1389625833_lam7, 1, 1, (V[]){v_k_2428})});
    }
    case TAG_RSpawn: {
      V v_c_2431 = heff_field(v_x11_2426, 0);
      V v_k_2432 = heff_field(v_x11_2426, 1);
      V v_ru_24x11_2426_24RSpawn = heff_take_reuse_n(v_x11_2426, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2426_24RSpawn, TAG_SSpawn, 2, (V[]){v_c_2431, heff_clo_n(g_green_2eview_24s658128430x1389625833_lam8, 1, 1, (V[]){v_k_2432})});
    }
    case TAG_RNew: {
      V v_k_2435 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Other, TAG_SNew, 1, (V[]){heff_clo_n(g_green_2eview_24s658128430x1389625833_lam9, 1, 1, (V[]){v_k_2435})});
    }
    case TAG_RSend: {
      V v_ch_2438 = heff_field(v_x11_2426, 0);
      V v_v_2439 = heff_field(v_x11_2426, 1);
      V v_k_2440 = heff_field(v_x11_2426, 2);
      V v_ru_24x11_2426_24RSend = heff_take_reuse_n(v_x11_2426, 7ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2426_24RSend, TAG_SSend, 3, (V[]){v_ch_2438, v_v_2439, heff_clo_n(g_green_2eview_24s658128430x1389625833_lam10, 1, 1, (V[]){v_k_2440})});
    }
    case TAG_RRecv: {
      V v_ch_2443 = heff_field(v_x11_2426, 0);
      V v_k_2444 = heff_field(v_x11_2426, 1);
      V v_ru_24x11_2426_24RRecv = heff_take_reuse_n(v_x11_2426, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Other, 1);
      return heff_tag_at_n(v_ru_24x11_2426_24RRecv, TAG_SRecv, 2, (V[]){v_ch_2443, heff_clo_n(g_green_2eview_24s658128430x1389625833_lam11, 1, 1, (V[]){v_k_2444})});
    }
    case TAG_RAct: {
      V v_m_2447 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Other, TAG_SAct, 1, (V[]){heff_clo_n(g_green_2eview_24s658128430x1389625833_lam12, 2, 1, (V[]){v_m_2447})});
    }
    default: return heff_nomatch(v_x11_2426);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_green_2eview_24s658128430x1389625833_entry(V self, V *a) {
  (void)self;
  return g_green_2eview_24s658128430x1389625833(a[0]);
}
V g_green_2eview_24s658128430x1389625833_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_u_244}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_245});
}
V g_green_2eview_24s658128430x1389625833_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_u_248}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_249});
}
V g_green_2eview_24s658128430x1389625833_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_n_2411}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2412});
}
V g_green_2eview_24s658128430x1389625833_lam3(V self, V *args) {
  V v_u_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_u_2416}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2417});
}
V g_green_2eview_24s658128430x1389625833_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_v_2420}));
  return heff_tag_n(TAG_Main, 1, (V[]){v_t_2421});
}
V g_green_2eview_24s658128430x1389625833_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Main, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2eview_24s658128430x1389625833_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_green_2eview_24s658128430x1389625833_lam6, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2eview_24s658128430x1389625833_lam7(V self, V *args) {
  V v_u_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tr(heff_call(v_k_2428, 1, (V[]){v_u_2429}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2430});
}
V g_green_2eview_24s658128430x1389625833_lam8(V self, V *args) {
  V v_u_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_tr(heff_call(v_k_2432, 1, (V[]){v_u_2433}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2434});
}
V g_green_2eview_24s658128430x1389625833_lam9(V self, V *args) {
  V v_n_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tr(heff_call(v_k_2435, 1, (V[]){v_n_2436}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2437});
}
V g_green_2eview_24s658128430x1389625833_lam10(V self, V *args) {
  V v_u_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tr(heff_call(v_k_2440, 1, (V[]){v_u_2441}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2442});
}
V g_green_2eview_24s658128430x1389625833_lam11(V self, V *args) {
  V v_v_2445 = args[0];
  V v_k_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(v_k_2444, 1, (V[]){v_v_2445}));
  return heff_tag_n(TAG_Other, 1, (V[]){v_t_2446});
}
V g_green_2eview_24s658128430x1389625833_lam13(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_Other, 1, (V[]){v_x_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2eview_24s658128430x1389625833_lam12(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_m_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_green_2eview_24s658128430x1389625833_lam13, 1, 1, (V[]){v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s482904806x1315522706_lam1(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam0(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam2(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam3(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam5(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam4(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam7(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam6(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam9(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam8(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam12(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam11(V self, V *args);
V g_green_2ego_24s482904806x1315522706_lam10(V self, V *args);
Clo g_green_2ego_24s482904806x1315522706_clo = {{0x80000000u, K_CLO, 0}, g_green_2ego_24s482904806x1315522706_entry, 4, 0};

V g_green_2ego_24s482904806x1315522706(V v_o_240, V v_g_241, V v_s_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SFinal: {
    V v_x_244 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    heff_drop_rec(v_s_242, 6);
    V v_c_245 = heff_tr(heff_call(heff_get_n(v_o_240, 3, 4), 1, (V[]){v_g_241}));
    return heff_clo_n(g_green_2ego_24s482904806x1315522706_lam0, 2, 2, (V[]){v_c_245, v_x_244});
  }
  case TAG_SEnd: {
    V t_0 = v_o_240;
    V t_1 = v_g_241;
    V t_2 = v_s_242;
    V t_3 = NTAG(TAG_SNext);
    v_o_240 = t_0;
    v_g_241 = t_1;
    v_s_242 = t_2;
    v_x4_243 = t_3;
    goto top_TAG_SNext;
  }
  case TAG_SYield: {
    V v_k_249 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_q_2410 = heff_take_field(v_s_242, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_249, heff_take_field(v_q_2410, 1)});
    V v_t_2412 = ({ V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_q_2410, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_242, 62ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_o_240;
    V t_1 = v_g_241;
    V t_2 = v_t_2413;
    V t_3 = NTAG(TAG_SNext);
    v_o_240 = t_0;
    v_g_241 = t_1;
    v_s_242 = t_2;
    v_x4_243 = t_3;
    goto top_TAG_SNext;
  }
  case TAG_SSpawn: {
    V v_c_2414 = heff_field(v_x4_243, 0);
    V v_k_2415 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24SSpawn = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_q_2416 = heff_take_field(v_s_242, 0);
    V v_t_2418 = heff_tag_at_n(v_ru_24x4_243_24SSpawn, TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s482904806x1315522706_lam2, 1, 1, (V[]){v_c_2414}), heff_dup(heff_rfield(v_q_2416, 1))});
    V v_t_2419 = ({ V rv_1 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_q_2416, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2420 = ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_s_242, 62ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2421 = heff_tr(heff_call(v_k_2415, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2422 = (g_green_2eview_24s658128430x1389625833(v_t_2421));
    V t_0 = v_o_240;
    V t_1 = v_g_241;
    V t_2 = v_t_2420;
    V t_3 = v_t_2422;
    v_o_240 = t_0;
    v_g_241 = t_1;
    v_s_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  case TAG_SNew: {
    V v_k_2423 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_2424 = heff_intAdd(heff_dup(heff_rfield(v_s_242, 3)), MK_INT(1LL));
    V v_t_2425 = heff_rec_n(6, shape_ready__chans__waiting__next__pending__turns, (V[]){heff_take_field(v_s_242, 0), heff_take_field(v_s_242, 1), heff_take_field(v_s_242, 2), v_t_2424, heff_take_field(v_s_242, 4), heff_take_field(v_s_242, 5)});
    V v_t_2426 = heff_tr(heff_call(v_k_2423, 1, (V[]){heff_get_n(v_s_242, 3, 6)}));
    V v_t_2427 = (g_green_2eview_24s658128430x1389625833(v_t_2426));
    V t_0 = v_o_240;
    V t_1 = v_g_241;
    V t_2 = v_t_2425;
    V t_3 = v_t_2427;
    v_o_240 = t_0;
    v_g_241 = t_1;
    v_s_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  case TAG_SSend: {
    V v_ch_2428 = heff_field(v_x4_243, 0);
    V v_v_2429 = heff_field(v_x4_243, 1);
    V v_k_2430 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    HeffT2 v_t_2431 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_s_242, 2), heff_dup(v_ch_2428)));
    V v_t_2436;
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_x_2435 = v_field_2433;
        v_t_2436 = v_x_2435;
      } else {
        heff_drop(v_field_2433);
        v_t_2436 = heff_dup(g_green_2eemptyQ_get());
      }
    }
    HeffT2 v_t_2437 = (g_green_2etakeQ_24cpr(v_t_2436));
    {
      V v_field_2439 = v_t_2437.f[1];
      int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
      if ((v_tag_2438 == ((int64_t)0ULL))) {
        V v_it1_2441 = v_field_2439;
        switch (heff_tag_of(v_it1_2441)) {
        case TAG_MkPair: {
          V v_w_2442 = heff_field(v_it1_2441, 0);
          V v_ws_2443 = heff_field(v_it1_2441, 1);
          V v_ru_24it1_2441_24MkPair = heff_take_reuse_n(v_it1_2441, 3ULL, 2);
          V v_q_2444 = heff_take_field(v_s_242, 0);
          V v_t_2446 = heff_tag_at_n(v_ru_24it1_2441_24MkPair, TAG_Cons, 2, (V[]){heff_clo_n(g_green_2ego_24s482904806x1315522706_lam3, 1, 2, (V[]){v_w_2442, v_v_2429}), heff_dup(heff_rfield(v_q_2444, 1))});
          V v_t_2447 = ({ V rv_1 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_q_2444, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2448 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_s_242, 2), v_ch_2428, v_ws_2443));
          V v_t_2449 = ({ V rv_0 = v_t_2447; V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_s_242, 58ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4044u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2450 = heff_tr(heff_call(v_k_2430, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2451 = (g_green_2eview_24s658128430x1389625833(v_t_2450));
          V t_0 = v_o_240;
          V t_1 = v_g_241;
          V t_2 = v_t_2449;
          V t_3 = v_t_2451;
          v_o_240 = t_0;
          v_g_241 = t_1;
          v_s_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_it1_2441);
        }
      } else {
        heff_drop(v_field_2439);
        HeffT2 v_t_2452 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_s_242, 1), heff_dup(v_ch_2428)));
        V v_t_2459;
        {
          V v_field_2454 = v_t_2452.f[1];
          int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
          V v_q_2457;
          if ((v_tag_2453 == ((int64_t)0ULL))) {
            V v_x_2456 = v_field_2454;
            v_q_2457 = v_x_2456;
          } else {
            heff_drop(v_field_2454);
            v_q_2457 = heff_dup(g_green_2eemptyQ_get());
          }
          V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2429, heff_take_field(v_q_2457, 1)});
          v_t_2459 = ({ V rv_1 = v_t_2458; V rr_ = heff_rec_reuse_nf(v_q_2457, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        V v_t_2460 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_s_242, 1), v_ch_2428, v_t_2459));
        V v_t_2461 = ({ V rv_1 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_s_242, 61ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2462 = heff_tr(heff_call(v_k_2430, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_2463 = (g_green_2eview_24s658128430x1389625833(v_t_2462));
        V t_0 = v_o_240;
        V t_1 = v_g_241;
        V t_2 = v_t_2461;
        V t_3 = v_t_2463;
        v_o_240 = t_0;
        v_g_241 = t_1;
        v_s_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
  }
  case TAG_SRecv: {
    V v_ch_2464 = heff_field(v_x4_243, 0);
    V v_k_2465 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24SRecv = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    HeffT2 v_t_2466 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_s_242, 1), heff_dup(v_ch_2464)));
    V v_t_2471;
    {
      V v_field_2468 = v_t_2466.f[1];
      int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
      if ((v_tag_2467 == ((int64_t)0ULL))) {
        V v_x_2470 = v_field_2468;
        v_t_2471 = v_x_2470;
      } else {
        heff_drop(v_field_2468);
        v_t_2471 = heff_dup(g_green_2eemptyQ_get());
      }
    }
    HeffT2 v_t_2472 = (g_green_2etakeQ_24cpr(v_t_2471));
    {
      V v_field_2474 = v_t_2472.f[1];
      int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
      if ((v_tag_2473 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x4_243_24SRecv, 2);
        V v_it1_2476 = v_field_2474;
        switch (heff_tag_of(v_it1_2476)) {
        case TAG_MkPair: {
          V v_v_2477 = heff_field(v_it1_2476, 0);
          V v_vs_2478 = heff_field(v_it1_2476, 1);
          heff_take_n(v_it1_2476, 3ULL, 2);
          V v_t_2479 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_s_242, 1), v_ch_2464, v_vs_2478));
          V v_t_2480 = ({ V rv_1 = v_t_2479; V rr_ = heff_rec_reuse_nf(v_s_242, 61ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4083u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2481 = heff_tr(heff_call(v_k_2465, 1, (V[]){v_v_2477}));
          V v_t_2482 = (g_green_2eview_24s658128430x1389625833(v_t_2481));
          V t_0 = v_o_240;
          V t_1 = v_g_241;
          V t_2 = v_t_2480;
          V t_3 = v_t_2482;
          v_o_240 = t_0;
          v_g_241 = t_1;
          v_s_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_it1_2476);
        }
      } else {
        heff_drop(v_field_2474);
        HeffT2 v_t_2483 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_s_242, 2), heff_dup(v_ch_2464)));
        V v_t_2490;
        {
          V v_field_2485 = v_t_2483.f[1];
          int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
          V v_q_2488;
          if ((v_tag_2484 == ((int64_t)0ULL))) {
            V v_x_2487 = v_field_2485;
            v_q_2488 = v_x_2487;
          } else {
            heff_drop(v_field_2485);
            v_q_2488 = heff_dup(g_green_2eemptyQ_get());
          }
          V v_t_2489 = heff_tag_at_n(v_ru_24x4_243_24SRecv, TAG_Cons, 2, (V[]){v_k_2465, heff_dup(heff_rfield(v_q_2488, 1))});
          v_t_2490 = ({ V rv_1 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_q_2488, 1ULL, 2, shape_front__back, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        V v_t_2491 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_s_242, 2), v_ch_2464, v_t_2490));
        V v_t_2492 = ({ V rv_2 = v_t_2491; V rr_ = heff_rec_reuse_nf(v_s_242, 59ULL, 6, shape_ready__chans__waiting__next__pending__turns, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V t_0 = v_o_240;
        V t_1 = v_g_241;
        V t_2 = v_t_2492;
        V t_3 = NTAG(TAG_SNext);
        v_o_240 = t_0;
        v_g_241 = t_1;
        v_s_242 = t_2;
        v_x4_243 = t_3;
        goto top_TAG_SNext;
      }
    }
  }
  case TAG_SAct: {
    V v_m_2493 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_c_2494 = heff_tr(heff_call(heff_dup(heff_rfield(v_o_240, 1)), 2, (V[]){heff_dup(v_g_241), v_m_2493}));
    return heff_clo_n(g_green_2ego_24s482904806x1315522706_lam4, 2, 4, (V[]){v_c_2494, v_s_242, v_o_240, v_g_241});
  }
  case TAG_SNext: {
    top_TAG_SNext: ;
    V v_t_24105 = heff_bool((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 4))) && heff_intLe_c(MK_INT(64LL), heff_dup(heff_rfield(v_s_242, 5)))));
    if ((heff_dup(v_t_24105) == NTAG(TAG_True))) {
      heff_drop(v_t_24105);
      V v_c_24106 = heff_tr(heff_call(heff_dup(heff_rfield(v_o_240, 2)), 2, (V[]){heff_dup(v_g_241), NTAG(TAG_False)}));
      return heff_clo_n(g_green_2ego_24s482904806x1315522706_lam6, 2, 4, (V[]){v_c_24106, v_s_242, v_o_240, v_g_241});
    } else {
      heff_drop(v_t_24105);
      HeffT2 v_t_24115 = (g_green_2etakeQ_24cpr(heff_dup(heff_rfield(v_s_242, 0))));
      {
        V v_field_24117 = v_t_24115.f[1];
        int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
        if ((v_tag_24116 == ((int64_t)0ULL))) {
          V v_it1_24119 = v_field_24117;
          switch (heff_tag_of(v_it1_24119)) {
          case TAG_MkPair: {
            V v_t_24120 = heff_field(v_it1_24119, 0);
            V v_q_24121 = heff_field(v_it1_24119, 1);
            heff_take_n(v_it1_24119, 3ULL, 2);
            V v_t_24122 = heff_intAdd(heff_take_field(v_s_242, 5), MK_INT(1LL));
            V v_t_24123 = ({ V rv_0 = v_q_24121; V rv_5 = v_t_24122; V rr_ = heff_rec_reuse_nf(v_s_242, 30ULL, 6, shape_ready__chans__waiting__next__pending__turns, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 5) = rv_5; rr_; });
            V v_t_24124 = heff_tr(heff_call(v_t_24120, 1, (V[]){NTAG(TAG_MkUnit)}));
            V v_t_24125 = (g_green_2eview_24s658128430x1389625833(v_t_24124));
            V t_0 = v_o_240;
            V t_1 = v_g_241;
            V t_2 = v_t_24123;
            V t_3 = v_t_24125;
            v_o_240 = t_0;
            v_g_241 = t_1;
            v_s_242 = t_2;
            v_x4_243 = t_3;
            goto top;
          }
          default: return heff_nomatch(v_it1_24119);
          }
        } else {
          heff_drop(v_field_24117);
          if (heff_intEq_c(heff_dup(heff_rfield(v_s_242, 4)), MK_INT(0LL))) {
            heff_drop_rec(v_s_242, 6);
            V v_c_24127 = heff_tr(heff_call(heff_get_n(v_o_240, 3, 4), 1, (V[]){v_g_241}));
            return heff_clo_n(g_green_2ego_24s482904806x1315522706_lam8, 2, 1, (V[]){v_c_24127});
          } else {
            V v_c_24131 = heff_tr(heff_call(heff_dup(heff_rfield(v_o_240, 2)), 2, (V[]){heff_dup(v_g_241), NTAG(TAG_True)}));
            return heff_clo_n(g_green_2ego_24s482904806x1315522706_lam10, 2, 4, (V[]){v_c_24131, v_o_240, v_g_241, v_s_242});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_green_2ego_24s482904806x1315522706_entry(V self, V *a) {
  (void)self;
  return g_green_2ego_24s482904806x1315522706(a[0], a[1], a[2], a[3]);
}
V g_green_2ego_24s482904806x1315522706_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_248);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s482904806x1315522706_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_green_2ego_24s482904806x1315522706_lam1, 1, 2, (V[]){v_k_247, v_x_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s482904806x1315522706_lam2(V self, V *args) {
  V v_u_2417 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Other, 1, (V[]){v_c_2414});
}
V g_green_2ego_24s482904806x1315522706_lam3(V self, V *args) {
  V v_u_2445 = args[0];
  V v_w_2442 = heff_env(self)[0];
  V v_v_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2445);
  V f_ = v_w_2442;
  args[0] = v_v_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s482904806x1315522706_lam5(V self, V *args) {
  V v_x_2497 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_hd_2495 = heff_env(self)[3];
  V v_k_2496 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2497)) {
  case TAG_Nothing: {
    V v_t_2498 = heff_intAdd(heff_take_field(v_s_242, 4), MK_INT(1LL));
    V v_t_2499 = ({ V rv_4 = v_t_2498; V rr_ = heff_rec_reuse_nf(v_s_242, 47ULL, 6, shape_ready__chans__waiting__next__pending__turns, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_24100 = (g_green_2ego_24s482904806x1315522706(v_o_240, v_g_241, v_t_2499, NTAG(TAG_SNext)));
    V f_ = v_t_24100;
    heff_room[0] = v_hd_2495;
    heff_room[1] = v_k_2496;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_24101 = heff_field(v_x_2497, 0);
    heff_take_n(v_x_2497, 1ULL, 1);
    V v_t_24102 = (g_green_2eview_24s658128430x1389625833(v_t_24101));
    V v_t_24103 = (g_green_2ego_24s482904806x1315522706(v_o_240, v_g_241, v_s_242, v_t_24102));
    V f_ = v_t_24103;
    heff_room[0] = v_hd_2495;
    heff_room[1] = v_k_2496;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2497);
  }
}
V g_green_2ego_24s482904806x1315522706_lam4(V self, V *args) {
  V v_hd_2495 = args[0];
  V v_k_2496 = args[1];
  V v_c_2494 = heff_env(self)[0];
  V v_s_242 = heff_env(self)[1];
  V v_o_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2494;
  args[0] = heff_dup(v_hd_2495);
  args[1] = heff_clo_n(g_green_2ego_24s482904806x1315522706_lam5, 1, 5, (V[]){v_s_242, v_o_240, v_g_241, v_hd_2495, v_k_2496});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s482904806x1315522706_lam7(V self, V *args) {
  V v_x_24109 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_hd_24107 = heff_env(self)[3];
  V v_k_24108 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24110 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_242, 0), heff_dup(v_x_24109)));
  V v_t_24111 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24109; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24109); r_; });
  V v_t_24112 = heff_intSub(heff_take_field(v_s_242, 4), v_t_24111);
  V v_t_24113 = ({ V rv_0 = v_t_24110; V rv_4 = v_t_24112; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_242, 14ULL, 6, shape_ready__chans__waiting__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_t_24114 = (g_green_2ego_24s482904806x1315522706(v_o_240, v_g_241, v_t_24113, NTAG(TAG_SNext)));
  V f_ = v_t_24114;
  heff_room[0] = v_hd_24107;
  heff_room[1] = v_k_24108;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_green_2ego_24s482904806x1315522706_lam6(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k_24108 = args[1];
  V v_c_24106 = heff_env(self)[0];
  V v_s_242 = heff_env(self)[1];
  V v_o_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24106;
  args[0] = heff_dup(v_hd_24107);
  args[1] = heff_clo_n(g_green_2ego_24s482904806x1315522706_lam7, 1, 5, (V[]){v_s_242, v_o_240, v_g_241, v_hd_24107, v_k_24108});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s482904806x1315522706_lam9(V self, V *args) {
  V v_x_24130 = args[0];
  V v_k_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24130);
  V f_ = v_k_24129;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s482904806x1315522706_lam8(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  V v_c_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24127;
  args[0] = v_hd_24128;
  args[1] = heff_clo_n(g_green_2ego_24s482904806x1315522706_lam9, 1, 1, (V[]){v_k_24129});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ego_24s482904806x1315522706_lam12(V self, V *args) {
  V v_x_24138 = args[0];
  V v_k_24133 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24138);
  V f_ = v_k_24133;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ego_24s482904806x1315522706_lam11(V self, V *args) {
  V v_x_24134 = args[0];
  V v_o_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_hd_24132 = heff_env(self)[2];
  V v_k_24133 = heff_env(self)[3];
  V v_s_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24135 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_24134));
  if (heff_intEq_c(v_t_24135, MK_INT(0LL))) {
    heff_drop(v_x_24134);
    heff_drop_rec(v_s_242, 6);
    V v_c_24137 = heff_tr(heff_call(heff_get_n(v_o_240, 3, 4), 1, (V[]){v_g_241}));
    V f_ = v_c_24137;
    heff_room[0] = v_hd_24132;
    heff_room[1] = heff_clo_n(g_green_2ego_24s482904806x1315522706_lam12, 1, 1, (V[]){v_k_24133});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_24139 = (g_list_2efoldl_24s2062876492x2082655823(heff_take_field(v_s_242, 0), heff_dup(v_x_24134)));
    V v_t_24140 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_24134; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_24134); r_; });
    V v_t_24141 = heff_intSub(heff_take_field(v_s_242, 4), v_t_24140);
    V v_t_24142 = ({ V rv_0 = v_t_24139; V rv_4 = v_t_24141; V rv_5 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_s_242, 14ULL, 6, shape_ready__chans__waiting__next__pending__turns, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    V v_t_24143 = (g_green_2ego_24s482904806x1315522706(v_o_240, v_g_241, v_t_24142, NTAG(TAG_SNext)));
    V f_ = v_t_24143;
    heff_room[0] = v_hd_24132;
    heff_room[1] = v_k_24133;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_green_2ego_24s482904806x1315522706_lam10(V self, V *args) {
  V v_hd_24132 = args[0];
  V v_k_24133 = args[1];
  V v_c_24131 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24131;
  args[0] = heff_dup(v_hd_24132);
  args[1] = heff_clo_n(g_green_2ego_24s482904806x1315522706_lam11, 1, 5, (V[]){v_o_240, v_g_241, v_hd_24132, v_k_24133, v_s_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ethenRes_24s1747913378x1698907254_lam0(V self, V *args);
V g_green_2ethenRes_24s1747913378x1698907254_lam1(V self, V *args);
V g_green_2ethenRes_24s1747913378x1698907254_lam2(V self, V *args);
V g_green_2ethenRes_24s1747913378x1698907254_lam3(V self, V *args);
V g_green_2ethenRes_24s1747913378x1698907254_lam4(V self, V *args);
V g_green_2ethenRes_24s1747913378x1698907254_lam6(V self, V *args);
V g_green_2ethenRes_24s1747913378x1698907254_lam5(V self, V *args);
Clo g_green_2ethenRes_24s1747913378x1698907254_clo = {{0x80000000u, K_CLO, 0}, g_green_2ethenRes_24s1747913378x1698907254_entry, 2, 0};

V g_green_2ethenRes_24s1747913378x1698907254(V v_x1_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RDone: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tail(v_f_241, 1, (V[]){v_x_242});
  }
  case TAG_RYield: {
    V v_k_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RYield = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RYield, TAG_RYield, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s1747913378x1698907254_lam0, 1, 2, (V[]){v_k_243, v_f_241})});
  }
  case TAG_RSpawn: {
    V v_c_246 = heff_field(v_x1_240, 0);
    V v_k_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RSpawn = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RSpawn, TAG_RSpawn, 2, (V[]){v_c_246, heff_clo_n(g_green_2ethenRes_24s1747913378x1698907254_lam1, 1, 2, (V[]){v_k_247, v_f_241})});
  }
  case TAG_RNew: {
    V v_k_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RNew = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RNew, TAG_RNew, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s1747913378x1698907254_lam2, 1, 2, (V[]){v_k_2410, v_f_241})});
  }
  case TAG_RSend: {
    V v_ch_2413 = heff_field(v_x1_240, 0);
    V v_v_2414 = heff_field(v_x1_240, 1);
    V v_k_2415 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24RSend = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    return heff_tag_at_n(v_ru_24x1_240_24RSend, TAG_RSend, 3, (V[]){v_ch_2413, v_v_2414, heff_clo_n(g_green_2ethenRes_24s1747913378x1698907254_lam3, 1, 2, (V[]){v_k_2415, v_f_241})});
  }
  case TAG_RRecv: {
    V v_ch_2418 = heff_field(v_x1_240, 0);
    V v_k_2419 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RRecv = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RRecv, TAG_RRecv, 2, (V[]){v_ch_2418, heff_clo_n(g_green_2ethenRes_24s1747913378x1698907254_lam4, 1, 2, (V[]){v_k_2419, v_f_241})});
  }
  case TAG_RAct: {
    V v_m_2422 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RAct = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RAct, TAG_RAct, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s1747913378x1698907254_lam5, 2, 2, (V[]){v_m_2422, v_f_241})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_green_2ethenRes_24s1747913378x1698907254_entry(V self, V *a) {
  (void)self;
  return g_green_2ethenRes_24s1747913378x1698907254(a[0], a[1]);
}
V g_green_2ethenRes_24s1747913378x1698907254_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_u_244}));
  return (g_green_2ethenRes_24s1747913378x1698907254(v_t_245, v_f_241));
}
V g_green_2ethenRes_24s1747913378x1698907254_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_u_248}));
  return (g_green_2ethenRes_24s1747913378x1698907254(v_t_249, v_f_241));
}
V g_green_2ethenRes_24s1747913378x1698907254_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_n_2411}));
  return (g_green_2ethenRes_24s1747913378x1698907254(v_t_2412, v_f_241));
}
V g_green_2ethenRes_24s1747913378x1698907254_lam3(V self, V *args) {
  V v_u_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_u_2416}));
  return (g_green_2ethenRes_24s1747913378x1698907254(v_t_2417, v_f_241));
}
V g_green_2ethenRes_24s1747913378x1698907254_lam4(V self, V *args) {
  V v_v_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_v_2420}));
  return (g_green_2ethenRes_24s1747913378x1698907254(v_t_2421, v_f_241));
}
V g_green_2ethenRes_24s1747913378x1698907254_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2426 = heff_tr(g_green_2ethenRes_24s1747913378x1698907254(v_x_2425, v_f_241));
  V f_ = v_k_2424;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ethenRes_24s1747913378x1698907254_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_m_2422 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_m_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_green_2ethenRes_24s1747913378x1698907254_lam6, 1, 2, (V[]){v_f_241, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ealone_24s1898071788x975368556_lam0(V self, V *args);
V g_green_2ealone_24s1898071788x975368556_lam2(V self, V *args);
V g_green_2ealone_24s1898071788x975368556_lam1(V self, V *args);
Clo g_green_2ealone_24s1898071788x975368556_clo = {{0x80000000u, K_CLO, 0}, g_green_2ealone_24s1898071788x975368556_entry, 1, 0};

V g_green_2ealone_24s1898071788x975368556(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RDone: {
    V v_x_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_clo_n(g_green_2ealone_24s1898071788x975368556_lam0, 2, 1, (V[]){v_x_241});
  }
  case TAG_RYield: {
    V v_k_244 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(v_k_244, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_t_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RSpawn: {
    V v_k_247 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V v_t_248 = heff_tr(heff_call(v_k_247, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_t_248;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RNew: {
    V v_k_249 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2410 = heff_tr(heff_call(v_k_249, 1, (V[]){MK_INT(0LL)}));
    V t_0 = v_t_2410;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RSend: {
    V v_k_2413 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V v_t_2414 = heff_tr(heff_call(v_k_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_t_2414;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RRecv: {
    V v_k_2416 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V v_t_2417 = heff_tr(heff_call(v_k_2416, 1, (V[]){MK_INT(0LL)}));
    V t_0 = v_t_2417;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_RAct: {
    V v_m_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_clo_n(g_green_2ealone_24s1898071788x975368556_lam1, 2, 1, (V[]){v_m_2418});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_green_2ealone_24s1898071788x975368556_entry(V self, V *a) {
  (void)self;
  return g_green_2ealone_24s1898071788x975368556(a[0]);
}
V g_green_2ealone_24s1898071788x975368556_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_x_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ealone_24s1898071788x975368556_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2419 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = (g_green_2ealone_24s1898071788x975368556(v_x_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_2419;
  heff_room[1] = v_k_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_green_2ealone_24s1898071788x975368556_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_m_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_green_2ealone_24s1898071788x975368556_lam2, 1, 2, (V[]){v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2egreenAlg_24s1477571606x442912311_lam0(V self, V *args);
V g_green_2egreenAlg_24s1477571606x442912311_lam1(V self, V *args);
V g_green_2egreenAlg_24s1477571606x442912311_lam2(V self, V *args);
V g_green_2egreenAlg_24s1477571606x442912311_lam3(V self, V *args);
V g_green_2egreenAlg_24s1477571606x442912311_lam4(V self, V *args);
V g_green_2egreenAlg_24s1477571606x442912311_lam6(V self, V *args);
V g_green_2egreenAlg_24s1477571606x442912311_lam5(V self, V *args); static Clo g_green_2egreenAlg_24s1477571606x442912311_lam5_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreenAlg_24s1477571606x442912311_lam5, 2, 0};
V g_green_2egreenAlg_24s1477571606x442912311_lam8(V self, V *args);
V g_green_2egreenAlg_24s1477571606x442912311_lam7(V self, V *args); static Clo g_green_2egreenAlg_24s1477571606x442912311_lam7_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreenAlg_24s1477571606x442912311_lam7, 4, 0};
Clo g_green_2egreenAlg_24s1477571606x442912311_clo = {{0x80000000u, K_CLO, 0}, g_green_2egreenAlg_24s1477571606x442912311_entry, 1, 0};

V g_green_2egreenAlg_24s1477571606x442912311(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_InL: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24InL = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_Spawn: {
      V v_c_242 = heff_field(v_x21_241, 0);
      V v_x_243 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24Spawn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_241_24Spawn, TAG_RSpawn, 2, (V[]){v_c_242, heff_clo_n(g_green_2egreenAlg_24s1477571606x442912311_lam0, 1, 1, (V[]){v_x_243})});
    }
    case TAG_Yield: {
      V v_x_245 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_240_24InL, TAG_RYield, 1, (V[]){heff_clo_n(g_green_2egreenAlg_24s1477571606x442912311_lam1, 1, 1, (V[]){v_x_245})});
    }
    case TAG_NewChan: {
      V v_k_247 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_240_24InL, TAG_RNew, 1, (V[]){heff_clo_n(g_green_2egreenAlg_24s1477571606x442912311_lam2, 1, 1, (V[]){v_k_247})});
    }
    case TAG_Send: {
      V v_ch_2410 = heff_field(v_x21_241, 0);
      V v_v_2411 = heff_field(v_x21_241, 1);
      V v_x_2412 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24Send = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_241_24Send, TAG_RSend, 3, (V[]){v_ch_2410, v_v_2411, heff_clo_n(g_green_2egreenAlg_24s1477571606x442912311_lam3, 1, 1, (V[]){v_x_2412})});
    }
    case TAG_Recv: {
      V v_ch_2414 = heff_field(v_x21_241, 0);
      V v_k_2415 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24Recv = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24InL, 1);
      return heff_tag_at_n(v_ru_24x21_241_24Recv, TAG_RRecv, 2, (V[]){v_ch_2414, heff_clo_n(g_green_2egreenAlg_24s1477571606x442912311_lam4, 1, 1, (V[]){v_k_2415})});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  case TAG_InR: {
    V v_q_2418 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24InR = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_green_2egreenAlg_24s1477571606x442912311_lam5_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_green_2egreenAlg_24s1477571606x442912311_lam7_clo)}), ((V)&g_green_2ealone_24s1898071788x975368556_clo), v_q_2418}));
    V v_t_2430 = heff_tr(heff_call(((V)&g_co_2eop_24s792193458x1346260978_clo), 1, (V[]){v_t_2429}));
    return heff_tag_at_n(v_ru_24x2_240_24InR, TAG_RAct, 1, (V[]){v_t_2430});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_green_2egreenAlg_24s1477571606x442912311_entry(V self, V *a) {
  (void)self;
  return g_green_2egreenAlg_24s1477571606x442912311(a[0]);
}
V g_green_2egreenAlg_24s1477571606x442912311_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_243});
}
V g_green_2egreenAlg_24s1477571606x442912311_lam1(V self, V *args) {
  V v_u_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_246);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_245});
}
V g_green_2egreenAlg_24s1477571606x442912311_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_n_248}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_249});
}
V g_green_2egreenAlg_24s1477571606x442912311_lam3(V self, V *args) {
  V v_u_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return heff_tag_n(TAG_RDone, 1, (V[]){v_x_2412});
}
V g_green_2egreenAlg_24s1477571606x442912311_lam4(V self, V *args) {
  V v_v_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_v_2416}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_2417});
}
V g_green_2egreenAlg_24s1477571606x442912311_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2421}));
  return heff_tag_n(TAG_RDone, 1, (V[]){v_t_2422});
}
V g_green_2egreenAlg_24s1477571606x442912311_lam5(V self, V *args) {
  V v_g_2419 = args[0];
  V v_r_2420 = args[1];
  return (g_green_2ethenRes_24s1747913378x1698907254(v_r_2420, heff_clo_n(g_green_2egreenAlg_24s1477571606x442912311_lam6, 1, 1, (V[]){v_g_2419})));
}
V g_green_2egreenAlg_24s1477571606x442912311_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2423 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2428 = heff_tr(heff_call(v_g_2423, 1, (V[]){v_x_2427}));
  V f_ = v_k_2426;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2egreenAlg_24s1477571606x442912311_lam7(V self, V *args) {
  V v_g_2423 = args[0];
  V v_c_2424 = args[1];
  V v_hd_2425 = args[2];
  V v_k_2426 = args[3];
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_green_2egreenAlg_24s1477571606x442912311_lam8, 1, 2, (V[]){v_g_2423, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_green_2ethenRes_24s352754375x1842358360_lam0(V self, V *args);
V g_green_2ethenRes_24s352754375x1842358360_lam1(V self, V *args);
V g_green_2ethenRes_24s352754375x1842358360_lam2(V self, V *args);
V g_green_2ethenRes_24s352754375x1842358360_lam3(V self, V *args);
V g_green_2ethenRes_24s352754375x1842358360_lam4(V self, V *args);
V g_green_2ethenRes_24s352754375x1842358360_lam6(V self, V *args);
V g_green_2ethenRes_24s352754375x1842358360_lam5(V self, V *args);
Clo g_green_2ethenRes_24s352754375x1842358360_clo = {{0x80000000u, K_CLO, 0}, g_green_2ethenRes_24s352754375x1842358360_entry, 1, 0};

V g_green_2ethenRes_24s352754375x1842358360(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RDone: {
    V v_ru_24x1_240_24RDone = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RDone, TAG_RDone, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_RYield: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RYield = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RYield, TAG_RYield, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s352754375x1842358360_lam0, 1, 1, (V[]){v_k_242})});
  }
  case TAG_RSpawn: {
    V v_c_245 = heff_field(v_x1_240, 0);
    V v_k_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RSpawn = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RSpawn, TAG_RSpawn, 2, (V[]){v_c_245, heff_clo_n(g_green_2ethenRes_24s352754375x1842358360_lam1, 1, 1, (V[]){v_k_246})});
  }
  case TAG_RNew: {
    V v_k_249 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RNew = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RNew, TAG_RNew, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s352754375x1842358360_lam2, 1, 1, (V[]){v_k_249})});
  }
  case TAG_RSend: {
    V v_ch_2412 = heff_field(v_x1_240, 0);
    V v_v_2413 = heff_field(v_x1_240, 1);
    V v_k_2414 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24RSend = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    return heff_tag_at_n(v_ru_24x1_240_24RSend, TAG_RSend, 3, (V[]){v_ch_2412, v_v_2413, heff_clo_n(g_green_2ethenRes_24s352754375x1842358360_lam3, 1, 1, (V[]){v_k_2414})});
  }
  case TAG_RRecv: {
    V v_ch_2417 = heff_field(v_x1_240, 0);
    V v_k_2418 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RRecv = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24RRecv, TAG_RRecv, 2, (V[]){v_ch_2417, heff_clo_n(g_green_2ethenRes_24s352754375x1842358360_lam4, 1, 1, (V[]){v_k_2418})});
  }
  case TAG_RAct: {
    V v_m_2421 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RAct = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24RAct, TAG_RAct, 1, (V[]){heff_clo_n(g_green_2ethenRes_24s352754375x1842358360_lam5, 2, 1, (V[]){v_m_2421})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_green_2ethenRes_24s352754375x1842358360_entry(V self, V *a) {
  (void)self;
  return g_green_2ethenRes_24s352754375x1842358360(a[0]);
}
V g_green_2ethenRes_24s352754375x1842358360_lam0(V self, V *args) {
  V v_u_243 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(v_k_242, 1, (V[]){v_u_243}));
  return (g_green_2ethenRes_24s352754375x1842358360(v_t_244));
}
V g_green_2ethenRes_24s352754375x1842358360_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_u_247}));
  return (g_green_2ethenRes_24s352754375x1842358360(v_t_248));
}
V g_green_2ethenRes_24s352754375x1842358360_lam2(V self, V *args) {
  V v_n_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tr(heff_call(v_k_249, 1, (V[]){v_n_2410}));
  return (g_green_2ethenRes_24s352754375x1842358360(v_t_2411));
}
V g_green_2ethenRes_24s352754375x1842358360_lam3(V self, V *args) {
  V v_u_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_u_2415}));
  return (g_green_2ethenRes_24s352754375x1842358360(v_t_2416));
}
V g_green_2ethenRes_24s352754375x1842358360_lam4(V self, V *args) {
  V v_v_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tr(heff_call(v_k_2418, 1, (V[]){v_v_2419}));
  return (g_green_2ethenRes_24s352754375x1842358360(v_t_2420));
}
V g_green_2ethenRes_24s352754375x1842358360_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2425 = (g_green_2ethenRes_24s352754375x1842358360(v_x_2424));
  V f_ = v_k_2423;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_green_2ethenRes_24s352754375x1842358360_lam5(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_m_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_green_2ethenRes_24s352754375x1842358360_lam6, 1, 1, (V[]){v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}