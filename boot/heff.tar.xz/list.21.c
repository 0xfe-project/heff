// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_AtLeast0 52203
#define TAG_AtVar 7142
#define TAG_AtWord 2344
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_Below 46697
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CInf 46723
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_KnownRec 32578
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SWarning 44190
#define TAG_SetField 47531
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_long 9823043
#define LBL_mods 9852536
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_olds 9909235
#define LBL_parent 951717845
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_total 311908190
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
V g_heff_2ebuild_2ebackcache_2eentriesAt(V, V, V);
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo;
V g_heff_2ebuild_2ebackcache_2ejsText(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsText_clo;
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_24tok1_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_list_2eall_24s457861111x1513113784(V, V);
V g_list_2eall_24s457861111x1513113784_entry(V self, V *a);
extern Clo g_list_2eall_24s457861111x1513113784_clo;
V g_list_2eany_24s1137631697x622554211(V, V);
V g_list_2eany_24s1137631697x622554211_entry(V self, V *a);
extern Clo g_list_2eany_24s1137631697x622554211_clo;
V g_list_2eany_24s1145295705x1744236002(V, V);
V g_list_2eany_24s1145295705x1744236002_entry(V self, V *a);
extern Clo g_list_2eany_24s1145295705x1744236002_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2eany_24s2046291842x47540086(V, V, V, V);
V g_list_2eany_24s2046291842x47540086_entry(V self, V *a);
extern Clo g_list_2eany_24s2046291842x47540086_clo;
V g_list_2eany_24s313956312x193471538(V, V, V, V);
V g_list_2eany_24s313956312x193471538_entry(V self, V *a);
extern Clo g_list_2eany_24s313956312x193471538_clo;
HeffT2 g_list_2efind_24s1498631415x1735266116_24cpr(V, V);
V g_list_2efind_24s1498631415x1735266116_24tok1(V, V, V);
V g_list_2efind_24s1498631415x1735266116_24tok1_entry(V self, V *a);
extern Clo g_list_2efind_24s1498631415x1735266116_24tok1_clo;
HeffT2 g_list_2efind_24s1867824208x1412174996_24cpr(V, V);
V g_list_2efoldl_24f1084934118x784646860(V, V, V, V, V);
V g_list_2efoldl_24f1084934118x784646860_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1084934118x784646860_clo;
V g_list_2efoldl_24f700195413x1431112932(V, V, V);
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a);
extern Clo g_list_2efoldl_24f700195413x1431112932_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1494296198x1800016121(V, V, V);
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1494296198x1800016121_clo;
V g_list_2efoldl_24s1920613344x620515025(V, V);
V g_list_2efoldl_24s1920613344x620515025_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1920613344x620515025_clo;
V g_list_2efoldl_24s425699049x1164890302(V, V, V);
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s425699049x1164890302_clo;
V g_list_2efoldl_24s623440618x1627495623(V, V);
V g_list_2efoldl_24s623440618x1627495623_entry(V self, V *a);
extern Clo g_list_2efoldl_24s623440618x1627495623_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2ekeepIf_24s1063601026x1972672043_24dps(V, V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_24dps_clo;
V g_list_2ekeepIf_24s1111636858x612918583(V, V, V);
V g_list_2ekeepIf_24s1111636858x612918583_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1111636858x612918583_clo;
V g_list_2ekeepIf_24s1111636858x612918583_24dps(V, V, V, V);
V g_list_2ekeepIf_24s1111636858x612918583_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1111636858x612918583_24dps_clo;
V g_list_2ekeepIf_24s1161549307x1906011635_24dps(V, V);
V g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_24dps_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap_24f1559388374x681683417_24dps(V, V, V, V, V);
V g_list_2emap_24f1559388374x681683417_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1559388374x681683417_24dps_clo;
V g_list_2emap_24s1041642916x1626051668(V);
V g_list_2emap_24s1041642916x1626051668_entry(V self, V *a);
extern Clo g_list_2emap_24s1041642916x1626051668_clo;
V g_list_2emap_24s1041642916x1626051668_24dps(V, V);
V g_list_2emap_24s1041642916x1626051668_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1041642916x1626051668_24dps_clo;
V g_list_2emap_24s1112048172x371485672(V);
V g_list_2emap_24s1112048172x371485672_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_clo;
V g_list_2emap_24s1112048172x371485672_24dps(V, V);
V g_list_2emap_24s1112048172x371485672_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_24dps_clo;
V g_list_2emap_24s1354671438x1264137843_24dps(V, V);
V g_list_2emap_24s1354671438x1264137843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_24dps_clo;
V g_list_2emap_24s1367173129x1257089258(V);
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_clo;
V g_list_2emap_24s1367173129x1257089258_24dps(V, V);
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_24dps_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s2000102784x314586828_24dps(V, V);
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_24dps_clo;
V g_list_2emap_24s2016093283x1174801437_24dps(V, V, V);
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_24dps_clo;
V g_list_2emap_24s2021078391x832341393(V, V, V);
V g_list_2emap_24s2021078391x832341393_entry(V self, V *a);
extern Clo g_list_2emap_24s2021078391x832341393_clo;
V g_list_2emap_24s2021078391x832341393_24dps(V, V, V, V);
V g_list_2emap_24s2021078391x832341393_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2021078391x832341393_24dps_clo;
V g_list_2emap_24s2029035892x1571084362_24dps(V, V);
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24dps_clo;
V g_list_2emap_24s2029035892x1571084362_24tok2(V, V);
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo;
V g_list_2emap_24s231073986x752637537_24dps(V, V, V);
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_24dps_clo;
V g_list_2emap_24s24324293x740715900(V, V);
V g_list_2emap_24s24324293x740715900_entry(V self, V *a);
extern Clo g_list_2emap_24s24324293x740715900_clo;
V g_list_2emap_24s24324293x740715900_24dps(V, V, V);
V g_list_2emap_24s24324293x740715900_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s24324293x740715900_24dps_clo;
V g_list_2emap_24s348263401x2104816219(V);
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_clo;
V g_list_2emap_24s348263401x2104816219_24dps(V, V);
V g_list_2emap_24s348263401x2104816219_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s900318151x1569363206_24dps(V, V, V, V);
V g_list_2emap_24s900318151x1569363206_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_24dps_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s961097229x1129443801_24dps(V, V);
V g_list_2emap_24s961097229x1129443801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_24dps_clo;
V g_list_2ezipWith_24s1604775524x1614188687(V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_clo;
V g_list_2ezipWith_24s1604775524x1614188687_24dps(V, V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_24dps_clo;
V g_list_2ezipWith_24s1737719962x691725464_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s1737719962x691725464_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1737719962x691725464_24dps_clo;
V g_list_2ezipWith_24s2130584539x811126895_24dps(V, V, V, V);
V g_list_2ezipWith_24s2130584539x811126895_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2130584539x811126895_24dps_clo;
V g_regex_2esizeOf(V);
V g_regex_2esizeOf_entry(V self, V *a);
extern Clo g_regex_2esizeOf_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2emap_24s2029035892x1571084362_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029035892x1571084362_24dps_entry, 2, 0};

V g_list_2emap_24s2029035892x1571084362_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029035892x1571084362_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1604775524x1614188687_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1604775524x1614188687_entry, 3, 0};

V g_list_2ezipWith_24s1604775524x1614188687(V v_lit_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_dup(heff_field(v_x_243, 0));
        v_a_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_a_2412;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_2411 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 2ULL, 2);
        v_a_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2416;
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Unreached: {
        heff_drop(v_y_245);
        v_t_2416 = v_a_249;
        break;
      }
      case TAG_Within: {
        V v_t_2415 = ({ V a_0 = v_a_2412; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2eranges_2erangeEq(a_0, a_1)); heff_drop_tag(v_a_2412, 2); heff_drop(v_y_245); r_; });
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          v_t_2416 = v_a_249;
        } else {
          heff_drop(v_t_2415);
          v_t_2416 = heff_intAdd(v_a_249, heff_dup(v_lit_240));
        }
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = (g_list_2ezipWith_24s1604775524x1614188687_24dps(v_lit_240, v_xs_244, v_ys_246, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1604775524x1614188687(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2016093283x1174801437_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016093283x1174801437_24dps_entry, 3, 0};

V g_list_2emap_24s2016093283x1174801437_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016093283x1174801437_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s961097229x1129443801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s961097229x1129443801_entry, 1, 0};

V g_list_2emap_24s961097229x1129443801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2438;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_SetField: {
        V v_x_246 = heff_field(v_x21_244, 0);
        V v_xsp_247 = heff_field(v_x21_244, 1);
        V v_e_248 = heff_field(v_x21_244, 2);
        V v_ru_24x21_244_24SetField = heff_take_reuse_n(v_x21_244, 7ULL, 3);
        HeffT3 v_t_249 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_248));
        V v_t_2422;
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_c_2413 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
            v_t_2422 = v_c_2413;
          } else {
            if ((v_tag_2410 == ((int64_t)1ULL))) {
              heff_drop(v_field_2412);
              V v_i_2414 = v_field_2411;
              V v_t_2417;
              switch (heff_tag_of(v_i_2414)) {
              case TAG_At: {
                V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
                v_t_2417 = v_s_2416;
                break;
              }
              default: heff_nomatch(v_i_2414);
              }
              v_t_2422 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2414}), v_t_2417});
            } else {
              V v_t_2418 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
              V v_t_2421;
              switch (heff_tag_of(v_t_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_t_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_t_2418);
              }
              v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2418}), v_t_2421});
            }
          }
        }
        v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_244_24SetField, TAG_SetField, 3, (V[]){v_x_246, v_xsp_247, v_t_2422}), v_sp_245});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2423 = heff_field(v_x21_244, 0);
        V v_ru_24x21_244_24BadFieldSet = heff_take_reuse_n(v_x21_244, 1ULL, 1);
        HeffT3 v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2423));
        V v_t_2437;
        {
          V v_field_2426 = v_t_2424.f[1];
          V v_field_2427 = v_t_2424.f[2];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            V v_c_2428 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2426, v_field_2427});
            v_t_2437 = v_c_2428;
          } else {
            if ((v_tag_2425 == ((int64_t)1ULL))) {
              heff_drop(v_field_2427);
              V v_i_2429 = v_field_2426;
              V v_t_2432;
              switch (heff_tag_of(v_i_2429)) {
              case TAG_At: {
                V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
                v_t_2432 = v_s_2431;
                break;
              }
              default: heff_nomatch(v_i_2429);
              }
              v_t_2437 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2429}), v_t_2432});
            } else {
              V v_t_2433 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2426, v_field_2427});
              V v_t_2436;
              switch (heff_tag_of(v_t_2433)) {
              case TAG_At: {
                V v_s_2435 = heff_dup(heff_field(v_t_2433, 1));
                v_t_2436 = v_s_2435;
                break;
              }
              default: heff_nomatch(v_t_2433);
              }
              v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2433}), v_t_2436});
            }
          }
        }
        v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2437}), v_sp_245});
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2439 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2438, heff_hole()});
    V v_u_2440 = (g_list_2emap_24s961097229x1129443801_24dps(v_xs_242, heff_dup(v_cell_2439)));
    heff_drop(v_u_2440);
    return v_cell_2439;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s961097229x1129443801(a[0]);
}
Clo g_list_2emap_24s348263401x2104816219_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s348263401x2104816219_entry, 1, 0};

V g_list_2emap_24s348263401x2104816219(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esyntax_2esurface_2edeclNameOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s348263401x2104816219_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s348263401x2104816219(a[0]);
}
Clo g_list_2emap_24s1112048172x371485672_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1112048172x371485672_entry, 1, 0};

V g_list_2emap_24s1112048172x371485672(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2442;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 4);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2443 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2442, heff_hole()});
    V v_u_2444 = (g_list_2emap_24s1112048172x371485672_24dps(v_xs_242, heff_dup(v_cell_2443)));
    heff_drop(v_u_2444);
    return v_cell_2443;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1112048172x371485672_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1112048172x371485672(a[0]);
}
Clo g_list_2eany_24s1877524499x1789047582_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1877524499x1789047582_entry, 2, 0};

V g_list_2eany_24s1877524499x1789047582(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2429;
    switch (heff_tag_of(v_x_242)) {
    case TAG_PartVal: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SVar: {
        V v_a_245 = heff_field(v_a_244, 0);
        v_t_2429 = heff_bool(heff_strEq_c_lent(v_lit_240, v_a_245, 0));
        break;
      }
      case TAG_SGlobal: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_PartOp: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2429);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1877524499x1789047582(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s976906006x1321876394_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s976906006x1321876394_entry, 4, 0};

V g_list_2efoldl_24s976906006x1321876394(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_2458;
    switch (heff_tag_of(v_x_244)) {
    case TAG_PartVal: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24PartVal = heff_take_reuse_n(v_x_244, 1ULL, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_SVar: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_246, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SProj: {
        V v_a_2424 = heff_field(v_a_246, 0);
        V v_a_2426 = heff_field(v_a_246, 2);
        heff_take_n(v_a_246, 5ULL, 4);
        switch (heff_tag_of(v_a_2424)) {
        case TAG_SVar: {
          V v_a_2428 = heff_field(v_a_2424, 0);
          heff_take_n(v_a_2424, 1ULL, 1);
          switch (heff_tag_of(v_a_2426)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24x3_243_24Cons, 2);
            heff_drop_cell(v_ru_24x_244_24PartVal, 1);
            heff_drop(v_a_2428);
            v_t_2458 = v_z_242;
            break;
          }
          case TAG_Cons: {
            V v_t_2431 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_2426; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_a_2426, 2); r_; });
            V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2428, heff_tag_at_n(v_ru_24x_244_24PartVal, TAG_KnownRec, 1, (V[]){v_t_2431})});
            v_t_2458 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2432, v_z_242});
            break;
          }
          default: heff_nomatch(v_a_2426);
          }
          break;
        }
        case TAG_SGlobal: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SInt: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFloat: {
          heff_take_na(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SStr: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SBytes: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFixed: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFloat32: {
          heff_take_na(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SPrimFn: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SLam: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_STag: {
          heff_take_n(v_a_2424, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SRec: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SProj: {
          heff_take_n(v_a_2424, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SPrim: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        default: heff_nomatch(v_a_2424);
        }
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_243_24Cons, 2);
      v_t_2458 = v_z_242;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2458;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s976906006x1321876394(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s231073986x752637537_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s231073986x752637537_24dps_entry, 3, 0};

V g_list_2emap_24s231073986x752637537_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s231073986x752637537_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1367173129x1257089258_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367173129x1257089258_entry, 1, 0};

V g_list_2emap_24s1367173129x1257089258(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1367173129x1257089258_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367173129x1257089258(a[0]);
}
Clo g_list_2emap_24s1354671438x1264137843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354671438x1264137843_24dps_entry, 2, 0};

V g_list_2emap_24s1354671438x1264137843_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354671438x1264137843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354671438x1264137843_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1477604419x1568736711_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1477604419x1568736711_entry, 2, 0};

V g_list_2eany_24s1477604419x1568736711(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1477604419x1568736711(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1145295705x1744236002_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1145295705x1744236002_entry, 2, 0};

V g_list_2eany_24s1145295705x1744236002(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x_242)) {
    case TAG_AtLeast0: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_lit_240)) {
      case TAG_AtVar: {
        V v_a_245 = heff_field(v_lit_240, 0);
        switch (heff_tag_of(v_a_244)) {
        case TAG_AtVar: {
          V v_a_246 = heff_field(v_a_244, 0);
          if (heff_strEq_c_lent(v_a_245, v_a_246, 0)) {
            return NTAG(TAG_True);
          } else {
            V t_0 = v_lit_240;
            V t_1 = v_xs_243;
            v_lit_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        case TAG_AtWord: {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_a_244);
        }
      }
      case TAG_AtWord: {
        V v_a_248 = heff_field(v_lit_240, 0);
        switch (heff_tag_of(v_a_244)) {
        case TAG_AtVar: {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_AtWord: {
          V v_a_2410 = heff_field(v_a_244, 0);
          if (heff_intEq_c_lent(v_a_248, v_a_2410, 0)) {
            return NTAG(TAG_True);
          } else {
            V t_0 = v_lit_240;
            V t_1 = v_xs_243;
            v_lit_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_244);
        }
      }
      default: return heff_nomatch(v_lit_240);
      }
    }
    case TAG_Below: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1145295705x1744236002_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1145295705x1744236002(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1920613344x620515025_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1920613344x620515025_entry, 2, 0};

V g_list_2efoldl_24s1920613344x620515025(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_s_245 = v_x_242;
    V v_t_2435;
    switch (heff_tag_of(v_s_245)) {
    case TAG_CDrop: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLet: {
      V v_x_247 = heff_field(v_s_245, 0);
      heff_take_n(v_s_245, 1ULL, 2);
      v_t_2435 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_acc_244});
      break;
    }
    case TAG_CDecl: {
      V v_x_249 = heff_field(v_s_245, 0);
      heff_take_n(v_s_245, 1ULL, 1);
      v_t_2435 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_249, v_acc_244});
      break;
    }
    case TAG_CSet: {
      V v_x_2410 = heff_field(v_s_245, 0);
      heff_take_n(v_s_245, 1ULL, 2);
      v_t_2435 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_2410, v_acc_244});
      break;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CIf: {
      V v_a_2413 = heff_field(v_s_245, 1);
      V v_b_2414 = heff_field(v_s_245, 2);
      heff_take_n(v_s_245, 6ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2415 = (g_list_2efoldl_24s1920613344x620515025(v_acc_244, v_a_2413));
      v_t_2435 = (g_list_2efoldl_24s1920613344x620515025(v_t_2415, v_b_2414));
      break;
    }
    case TAG_CSwitch: {
      V v_arms_2417 = heff_field(v_s_245, 1);
      heff_take_n(v_s_245, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = ({ V a_0 = v_acc_244; V a_1 = v_arms_2417; V r_ = (g_list_2efoldl_24s623440618x1627495623(a_0, a_1)); heff_drop(v_arms_2417); r_; });
      break;
    }
    case TAG_CReturn: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CInPlace: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CRoomed: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CTail: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLoop: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLoopTo: {
      heff_take_n(v_s_245, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLabel: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CJump: {
      heff_take_n(v_s_245, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    default: heff_nomatch(v_s_245);
    }
    V t_0 = v_t_2435;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1920613344x620515025_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1920613344x620515025(a[0], a[1]);
}
Clo g_list_2ezipWith_24s2130584539x811126895_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s2130584539x811126895_24dps_entry, 4, 0};

V g_list_2ezipWith_24s2130584539x811126895_24dps(V v_lit_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_248 = heff_strAppend(heff_strAppend(v_x_244, heff_dup(v_lit_240)), v_y_246);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s2130584539x811126895_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s2130584539x811126895_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s24324293x740715900_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s24324293x740715900_entry, 2, 0};

V g_list_2emap_24s24324293x740715900(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_lit_240)), v_t_2410);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s24324293x740715900_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s24324293x740715900_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s24324293x740715900(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1737719962x691725464_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1737719962x691725464_24dps_entry, 10, 0};

V g_list_2ezipWith_24s1737719962x691725464_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_247, 0);
    V v_xs_2411 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_2410);
      heff_drop(v_xs_2411);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x3_248, 0);
      V v_ys_2413 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2410); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2414));
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, heff_dup(v_lit_245)), heff_intShow(v_y_2412));
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, heff_dup(v_lit_246)), heff_hole()});
      V v_u_2418 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_2411;
      V t_8 = v_ys_2413;
      V t_9 = v_cell_2417;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      v_x3_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2ezipWith_24s1737719962x691725464_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1737719962x691725464_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2eany_24s313956312x193471538_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s313956312x193471538_entry, 4, 0};

V g_list_2eany_24s313956312x193471538(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_242, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s313956312x193471538_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s313956312x193471538(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2efoldl_24s425699049x1164890302_str0, 2, "$s");
HEFF_LIT(g_list_2efoldl_24s425699049x1164890302_str1, 2, "$s");
Clo g_list_2efoldl_24s425699049x1164890302_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s425699049x1164890302_entry, 3, 0};

V g_list_2efoldl_24s425699049x1164890302(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_fs_245 = heff_dup(v_lit_240);
    V v_mods_246 = heff_take_field(v_fs_245, 0);
    V v_olds_247 = heff_get_n(v_fs_245, 1, 2);
    V v_m_248 = v_z_241;
    V v_x3_249 = heff_dup(v_x_243);
    V v_t_2422;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_MkPair: {
      V v_k_2410 = heff_field(v_x3_249, 0);
      V v_e_2411 = heff_field(v_x3_249, 1);
      heff_take_n(v_x3_249, 3ULL, 2);
      V v_j_2412 = heff_strFind_lent(((V)&g_list_2efoldl_24s425699049x1164890302_str0), v_k_2410, MK_INT(0LL), 5);
      V v_t_2413;
      if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
        heff_drop(v_j_2412);
        v_t_2413 = heff_dup(v_k_2410);
      } else {
        v_t_2413 = heff_strSlice_lent(v_k_2410, MK_INT(0LL), v_j_2412, 6);
      }
      V v_t_2414 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_246, v_t_2413));
      V v_t_2415 = (g_heff_2ebuild_2ebackcache_2ejsText(heff_dup(v_k_2410), v_e_2411));
      V v_j_2416 = heff_strFind_lent(((V)&g_list_2efoldl_24s425699049x1164890302_str1), v_k_2410, MK_INT(0LL), 5);
      V v_t_2417;
      if (heff_intLt_c_lent(v_j_2416, MK_INT(0LL), 2)) {
        heff_drop(v_j_2416);
        v_t_2417 = heff_dup(v_k_2410);
      } else {
        v_t_2417 = heff_strSlice_lent(v_k_2410, MK_INT(0LL), v_j_2416, 6);
      }
      V v_t_2418 = ({ V a_0 = v_mods_246; V a_1 = v_t_2417; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_246); r_; });
      V v_es_2419 = ({ V a_0 = v_olds_247; V a_1 = v_m_248; V a_2 = v_t_2418; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(a_0, a_1, a_2)); heff_drop(v_olds_247); heff_drop(v_t_2418); r_; });
      V v_t_2420 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_es_2419, 3), v_k_2410, v_t_2415));
      V v_t_2421 = ({ V rv_3 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_es_2419, 7ULL, 4, shape_groups__copies__emits__jss, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      v_t_2422 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_248, v_t_2414, v_t_2421));
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2422;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s425699049x1164890302(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1494296198x1800016121_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1494296198x1800016121_entry, 3, 0};

V g_list_2efoldl_24s1494296198x1800016121(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eaddGroup(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1494296198x1800016121(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eall_24s457861111x1513113784_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s457861111x1513113784_entry, 2, 0};

V g_list_2eall_24s457861111x1513113784(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ty_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_size_245 = heff_dup(heff_rfield(v_x_242, 2));
    HeffT2 v_t_246 = ({ V a_0 = v_ty_244; V a_1 = v_size_245; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(a_0, a_1)); heff_drop(v_ty_244); heff_drop(v_size_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_248;
        if (heff_intEq_c_lent(v_a_249, v_lit_240, 1)) {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_lit_240);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_field_248);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s457861111x1513113784_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s457861111x1513113784(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1161549307x1906011635_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1161549307x1906011635_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_SError: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1161549307x1906011635_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s900318151x1569363206_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s900318151x1569363206_24dps_entry, 4, 0};

V g_list_2emap_24s900318151x1569363206_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_246 = heff_take_field(v_x_244, 0);
    V v_tags_247 = heff_get_n(v_x_244, 1, 3);
    V v_t_248;
    if ((heff_dup(v_tags_247) == NTAG(TAG_True))) {
      heff_drop(v_tags_247);
      v_t_248 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_tags_247);
      v_t_248 = heff_dup(v_lit_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_name_246, v_t_248), heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s900318151x1569363206_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s900318151x1569363206_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s680990791x1764841948_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s680990791x1764841948_entry, 7, 0};

V g_list_2efoldl_24s680990791x1764841948(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_z_245, V v_x3_246) {
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    return v_z_245;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_246, 0);
    V v_xs_248 = heff_field(v_x3_246, 1);
    V v_ru_24x3_246_24Cons = heff_take_reuse_n(v_x3_246, 3ULL, 2);
    V v_t_2411;
    if (heff_strEq_c_lent(v_x_247, v_lit_240, 0)) {
      heff_drop(v_x_247);
      switch (heff_tag_of(v_z_245)) {
      case TAG_Nil: {
        if ((heff_dup(v_lit_241) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          v_t_2411 = NTAG(TAG_Nil);
        } else {
          v_t_2411 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_242), NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_z_245, 0));
        V v_a_2410 = heff_dup(heff_field(v_z_245, 1));
        if (heff_strEq_c_lent(v_a_249, v_lit_243, 1)) {
          heff_drop(v_a_2410);
          v_t_2411 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_244), v_z_245});
        } else {
          heff_drop_tag(v_z_245, 2);
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          v_t_2411 = v_a_2410;
        }
        break;
      }
      default: heff_nomatch(v_z_245);
      }
    } else {
      v_t_2411 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_245});
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_t_2411;
    V t_6 = v_xs_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_z_245 = t_5;
    v_x3_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s680990791x1764841948(a0, a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24s2000102784x314586828_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_entry, 1, 0};

V g_list_2emap_24s2000102784x314586828(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s2000102784x314586828_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828(a[0]);
}
Clo g_list_2emap_24s2021078391x832341393_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2021078391x832341393_entry, 3, 0};

V g_list_2emap_24s2021078391x832341393(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_t_245 = heff_intAdd(heff_take_field(v_x_243, 3), heff_dup(v_lit_241));
      v_t_246 = ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_x_243, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_246 = v_x_243;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s2021078391x832341393_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s2021078391x832341393_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2021078391x832341393(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1063601026x1972672043_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1063601026x1972672043_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1063601026x1972672043_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_x_243, 0)) - heff_unbox_word(heff_strLength_lent(v_lit_240, 0)));
    V v_t_246 = heff_strSlice(heff_dup(v_x_243), heff_box_word(v_t_245), heff_strLength_lent(v_x_243, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1063601026x1972672043_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1063601026x1972672043_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1041642916x1626051668_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1041642916x1626051668_entry, 1, 0};

V g_list_2emap_24s1041642916x1626051668(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_regex_2esizeOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1041642916x1626051668_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1041642916x1626051668_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1041642916x1626051668(a[0]);
}
Clo g_list_2eany_24s2046291842x47540086_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2046291842x47540086_entry, 4, 0};

V g_list_2eany_24s2046291842x47540086(V v_box_24lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strLength(heff_dup(heff_rfield(v_x_244, 1)));
    if (((v_lit_240 < heff_peek_word(v_t_246)) || (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241)) || heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_242))))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      int64_t t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s2046291842x47540086_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s2046291842x47540086(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24s1111636858x612918583_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1111636858x612918583_entry, 3, 0};

V g_list_2ekeepIf_24s1111636858x612918583(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_245, v_lit_241, 1)) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s1111636858x612918583_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s1111636858x612918583_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s1111636858x612918583(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s1867824208x1412174996_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24f1559388374x681683417_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1559388374x681683417_24dps_entry, 5, 0};

V g_list_2emap_24f1559388374x681683417_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = ({ V a_0 = heff_dup(v_x_245); V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s1137631697x622554211(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_a_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 2), heff_take_field(v_x_245, 3)});
      V v_t_249 = heff_strAppend(heff_dup(v_lit_241), heff_get_n(v_x_245, 1, 7));
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(v_t_249, heff_dup(v_lit_242)), v_a_248, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1559388374x681683417_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1559388374x681683417_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f700195413x1431112932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f700195413x1431112932_entry, 3, 0};

V g_list_2efoldl_24f700195413x1431112932(V v_lit_240, V v_z_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_xs_244 = heff_field(v_x1_242, 1);
    heff_take_n(v_x1_242, 3ULL, 2);
    V v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_243); r_; });
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_t_245;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x1_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f700195413x1431112932(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2efoldl_24f1084934118x784646860_str0, 0, "");
HEFF_LIT(g_list_2efoldl_24f1084934118x784646860_str1, 0, "");
HEFF_LIT(g_list_2efoldl_24f1084934118x784646860_str2, 1, " ");
Clo g_list_2efoldl_24f1084934118x784646860_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1084934118x784646860_entry, 5, 0};

V g_list_2efoldl_24f1084934118x784646860(V v_lit_240, V v_z_241, V v_w_242, V v_line_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_w_242);
    if (heff_strEq_c(v_line_243, ((V)&g_list_2efoldl_24f1084934118x784646860_str0))) {
      heff_drop(v_lit_240);
      return v_z_241;
    } else {
      return ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_intAdd(v_z_241, v_lit_240); V b_2 = NTAG(TAG_Nil); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    }
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    if (heff_strEq_c_lent(v_line_243, ((V)&g_list_2efoldl_24f1084934118x784646860_str1), 2)) {
      heff_drop(v_line_243);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_w_242;
      V t_3 = heff_dup(v_x_245);
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_w_242 = t_2;
      v_line_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    } else {
      V v_xs_247 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_line_243))));
      V v_t_248 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_247; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_247); r_; });
      V v_xs_249 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_x_245))));
      V v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_249); r_; });
      V v_t_2411 = heff_intAdd(heff_intAdd(v_t_248, MK_INT(1LL)), v_t_2410);
      if (heff_intLe_c_lent(v_t_2411, v_w_242, 1)) {
        V v_t_2412 = heff_strAppend(heff_strAppend(v_line_243, ((V)&g_list_2efoldl_24f1084934118x784646860_str2)), heff_dup(v_x_245));
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_w_242;
        V t_3 = v_t_2412;
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_w_242 = t_2;
        v_line_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      } else {
        heff_drop(v_line_243);
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_w_242;
        V t_3 = heff_dup(v_x_245);
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_w_242 = t_2;
        v_line_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2efoldl_24f1084934118x784646860_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24f1084934118x784646860(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2efind_24s1498631415x1735266116_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1498631415x1735266116_24tok1_entry, 3, 0};

V g_list_2efind_24s1498631415x1735266116_24tok1(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  HeffT2 v_t_243 = (g_list_2efind_24s1498631415x1735266116_24cpr(v_lit_241, v_x2_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_list_2efind_24s1498631415x1735266116_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2efind_24s1498631415x1735266116_24tok1(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029035892x1571084362_24tok2_entry, 2, 0};

V g_list_2emap_24s2029035892x1571084362_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
    V v_u_245 = (g_list_2emap_24s2029035892x1571084362_24dps(v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029035892x1571084362_24tok2(a[0], a[1]);
}