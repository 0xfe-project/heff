// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_e 319
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo;
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate(V, V, V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_clo;
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(V, V, V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_clo;
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240(V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etryScope(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_clo;
V g_heff_2esyntax_2epresyntax_2etryT(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryT_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SetField: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_xsp_246 = heff_field(v_x31_243, 1);
      V v_e_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_248 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_247}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x1_248, 0);
        V v_y_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_x_245, v_xsp_246, v_y_2410}), v_sp_244});
        return ((HeffT2){{v_x_249, v_t_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
      }
    }
    case TAG_BadFieldSet: {
      V v_e_2412 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_x1_2413 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2412}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        V v_y_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_y_2415}), v_sp_244});
        return ((HeffT2){{v_x_2414, v_t_2416}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_t_244 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      v_t_244 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_x_242)));
    }
    HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_t_244, v_xs_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      V v_y_249 = v_field_247;
      return ((HeffT2){{v_x_248, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_y_249})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_StmtBind: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLet: {
        heff_take_n(v_x111_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtExpr: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLetMut: {
        V v_x_2411 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 3);
        V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
        V v_u_2415 = (g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(v_rest_242, heff_dup(v_cell_2414)));
        heff_drop(v_u_2415);
        return v_cell_2414;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclaredMuts(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryT_str0, 89, "nothing after this `try` runs: neither its statements nor its `catch` arm reach their end");
Clo g_heff_2esyntax_2epresyntax_2etryT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryT_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2etryT(V v_t_240, V v_cx_241, V v_sp_242, V v_tr_243, V v_rest_244, V v_end_245) {
top: ;
  V v_scope_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2etryScope_clo), 4, (V[]){heff_dup(v_t_240), heff_dup(v_cx_241), heff_dup(v_sp_242), heff_dup(v_tr_243)}));
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETry, 1, (V[]){v_tr_243}), heff_dup(v_sp_242)});
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_249));
  V v_falls_2427;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_falls_2427 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    switch (heff_tag_of(v_x_2411)) {
    case TAG_At: {
      V v_it11_2413 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 2);
      switch (heff_tag_of(v_it11_2413)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2413, 0ULL, 2);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2420 = heff_field(v_it11_2413, 0);
        heff_take_n(v_it11_2413, 1ULL, 1);
        v_falls_2427 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2420));
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it11_2413);
      }
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  switch (heff_tag_of(v_rest_244)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_cx_241);
    heff_drop(v_sp_242);
    heff_drop(v_falls_2427);
    return heff_tail(v_scope_246, 1, (V[]){v_end_245});
  }
  case TAG_Cons: {
    V v_s_2428 = heff_field(v_rest_244, 0);
    V v_rest_2429 = heff_field(v_rest_244, 1);
    V v_ru_24rest_244_24Cons = heff_take_reuse_n(v_rest_244, 3ULL, 2);
    if ((heff_dup(v_falls_2427) == NTAG(TAG_True))) {
      heff_drop(v_falls_2427);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_246, heff_tag_at_n(v_ru_24rest_244_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_rest_2429}), v_end_245);
    } else {
      heff_drop(v_t_240);
      heff_drop(v_cx_241);
      heff_drop(v_sp_242);
      heff_drop(v_end_245);
      heff_drop(v_scope_246);
      heff_drop(v_falls_2427);
      heff_drop(v_rest_2429);
      heff_drop_cell(v_ru_24rest_244_24Cons, 2);
      V v_t_2432;
      switch (heff_tag_of(v_s_2428)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_s_2428, 1);
        heff_take_n(v_s_2428, 2ULL, 2);
        v_t_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_s_2428);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryT_str0)}), v_t_2432});
    }
  }
  default: return heff_nomatch(v_rest_244);
  }
}
V g_heff_2esyntax_2epresyntax_2etryT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etryT(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eelseFalls_str0, 136, "the `else` of `let p = e else ...` must leave the block: end it with `return`, `break`, `continue` or `abandon`; for a value, use `case`");

static V g_heff_2esyntax_2epresyntax_2eelseFalls_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eelseFalls_st;
static V g_heff_2esyntax_2epresyntax_2eelseFalls_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2eelseFalls_str0);
}
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eelseFalls_st)) return g_heff_2esyntax_2epresyntax_2eelseFalls_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eelseFalls_val, &g_heff_2esyntax_2epresyntax_2eelseFalls_st, g_heff_2esyntax_2epresyntax_2eelseFalls_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eargOf_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eargOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_dup(heff_field(v_x2_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EVar, 1);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), v_t_2418});
    }
    case TAG_EImplicitVar: {
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EImplicitVar, 1);
        v_t_2430 = v_c_2425;
        break;
      }
      case TAG_IsType: {
        V v_t_2426 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2433;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2430}), v_t_2433});
    }
    case TAG_ETag: {
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETag, 1);
        v_t_2445 = v_c_2440;
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CType, 1, (V[]){v_t_2441}), v_t_2444});
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2448;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2445}), v_t_2448});
    }
    case TAG_EInt: {
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2460;
      switch (heff_tag_of(v_x1_2450)) {
      case TAG_IsInferable: {
        V v_i_2451 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2455 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInt, 1);
        v_t_2460 = v_c_2455;
        break;
      }
      case TAG_IsType: {
        V v_t_2456 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
        break;
      }
      default: heff_nomatch(v_x1_2450);
      }
      V v_t_2463;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2460}), v_t_2463});
    }
    case TAG_EFloat: {
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2475;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_IsInferable: {
        V v_i_2466 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2469;
        switch (heff_tag_of(v_i_2466)) {
        case TAG_At: {
          V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
          v_t_2469 = v_s_2468;
          break;
        }
        default: heff_nomatch(v_i_2466);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2470 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EFloat, 1);
        v_t_2475 = v_c_2470;
        break;
      }
      case TAG_IsType: {
        V v_t_2471 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2478;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EString: {
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2490;
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_IsInferable: {
        V v_i_2481 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2484;
        switch (heff_tag_of(v_i_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_i_2481);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CInf, 1, (V[]){v_i_2481}), v_t_2484});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2485 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EString, 1);
        v_t_2490 = v_c_2485;
        break;
      }
      case TAG_IsType: {
        V v_t_2486 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_t_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CType, 1, (V[]){v_t_2486}), v_t_2489});
        break;
      }
      default: heff_nomatch(v_x1_2480);
      }
      V v_t_2493;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2490}), v_t_2493});
    }
    case TAG_EBinary: {
      V v_ru_24x21_242_24EBinary = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24105;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_IsInferable: {
        V v_i_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_i_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_i_2496);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CInf, 1, (V[]){v_i_2496}), v_t_2499});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24100 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EBinary, 1);
        v_t_24105 = v_c_24100;
        break;
      }
      case TAG_IsType: {
        V v_t_24101 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_t_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CType, 1, (V[]){v_t_24101}), v_t_24104});
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_t_24108;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24105}), v_t_24108});
    }
    case TAG_ERune: {
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24120;
      switch (heff_tag_of(v_x1_24110)) {
      case TAG_IsInferable: {
        V v_i_24111 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24114;
        switch (heff_tag_of(v_i_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_i_24111);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24115 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ERune, 1);
        v_t_24120 = v_c_24115;
        break;
      }
      case TAG_IsType: {
        V v_t_24116 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_t_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_t_24116);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
        break;
      }
      default: heff_nomatch(v_x1_24110);
      }
      V v_t_24123;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24120}), v_t_24123});
    }
    case TAG_EWord: {
      V v_ru_24x21_242_24EWord = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24125 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24135;
      switch (heff_tag_of(v_x1_24125)) {
      case TAG_IsInferable: {
        V v_i_24126 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24129;
        switch (heff_tag_of(v_i_24126)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_i_24126, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_i_24126);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CInf, 1, (V[]){v_i_24126}), v_t_24129});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24130 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EWord, 1);
        v_t_24135 = v_c_24130;
        break;
      }
      case TAG_IsType: {
        V v_t_24131 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24134;
        switch (heff_tag_of(v_t_24131)) {
        case TAG_At: {
          V v_s_24133 = heff_dup(heff_field(v_t_24131, 1));
          v_t_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_t_24131);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CType, 1, (V[]){v_t_24131}), v_t_24134});
        break;
      }
      default: heff_nomatch(v_x1_24125);
      }
      V v_t_24138;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24137 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24138 = v_s_24137;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24135}), v_t_24138});
    }
    case TAG_EApp: {
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24151;
      switch (heff_tag_of(v_x1_24141)) {
      case TAG_IsInferable: {
        V v_i_24142 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24145;
        switch (heff_tag_of(v_i_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_dup(heff_field(v_i_24142, 1));
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_i_24142);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24142}), v_t_24145});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24146 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EApp, 2);
        v_t_24151 = v_c_24146;
        break;
      }
      case TAG_IsType: {
        V v_t_24147 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24150;
        switch (heff_tag_of(v_t_24147)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
          v_t_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_t_24147);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
        break;
      }
      default: heff_nomatch(v_x1_24141);
      }
      V v_t_24154;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_EProject: {
      V v_x_24155 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_tag(v_x2_241, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_24155}), v_sp_243});
    }
    case TAG_ENamed: {
      V v_x_24156 = heff_field(v_x21_242, 0);
      V v_x212_24157 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      switch (heff_tag_of(v_x212_24157)) {
      case TAG_At: {
        V v_x2121_24158 = heff_dup(heff_field(v_x212_24157, 0));
        switch (heff_tag_of(v_x2121_24158)) {
        case TAG_EVar: {
          V v_x21211_24160 = heff_field(v_x2121_24158, 0);
          heff_take_n(v_x2121_24158, 1ULL, 1);
          if (heff_strEq_c(v_x21211_24160, ((V)&g_heff_2esyntax_2epresyntax_2eargOf_str0))) {
            heff_drop_rec(v_r_240, 2);
            heff_drop_tag(v_x212_24157, 2);
            return heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgEvidence, 1, (V[]){v_x_24156}), v_sp_243});
          } else {
            V v_x1_24162 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
            V v_t_24172;
            switch (heff_tag_of(v_x1_24162)) {
            case TAG_IsInferable: {
              V v_i_24163 = heff_field(v_x1_24162, 0);
              heff_take_n(v_x1_24162, 1ULL, 1);
              V v_t_24166;
              switch (heff_tag_of(v_i_24163)) {
              case TAG_At: {
                V v_s_24165 = heff_dup(heff_field(v_i_24163, 1));
                v_t_24166 = v_s_24165;
                break;
              }
              default: heff_nomatch(v_i_24163);
              }
              v_t_24172 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24163}), v_t_24166});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24167 = heff_field(v_x1_24162, 0);
              heff_take_n(v_x1_24162, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24172 = v_c_24167;
              break;
            }
            case TAG_IsType: {
              V v_t_24168 = heff_field(v_x1_24162, 0);
              heff_take_n(v_x1_24162, 1ULL, 1);
              V v_t_24171;
              switch (heff_tag_of(v_t_24168)) {
              case TAG_At: {
                V v_s_24170 = heff_dup(heff_field(v_t_24168, 1));
                v_t_24171 = v_s_24170;
                break;
              }
              default: heff_nomatch(v_t_24168);
              }
              v_t_24172 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24168}), v_t_24171});
              break;
            }
            default: heff_nomatch(v_x1_24162);
            }
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24172}), v_sp_243});
          }
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24174 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24184;
          switch (heff_tag_of(v_x1_24174)) {
          case TAG_IsInferable: {
            V v_i_24175 = heff_field(v_x1_24174, 0);
            heff_take_n(v_x1_24174, 1ULL, 1);
            V v_t_24178;
            switch (heff_tag_of(v_i_24175)) {
            case TAG_At: {
              V v_s_24177 = heff_dup(heff_field(v_i_24175, 1));
              v_t_24178 = v_s_24177;
              break;
            }
            default: heff_nomatch(v_i_24175);
            }
            v_t_24184 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24175}), v_t_24178});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24179 = heff_field(v_x1_24174, 0);
            heff_take_n(v_x1_24174, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24184 = v_c_24179;
            break;
          }
          case TAG_IsType: {
            V v_t_24180 = heff_field(v_x1_24174, 0);
            heff_take_n(v_x1_24174, 1ULL, 1);
            V v_t_24183;
            switch (heff_tag_of(v_t_24180)) {
            case TAG_At: {
              V v_s_24182 = heff_dup(heff_field(v_t_24180, 1));
              v_t_24183 = v_s_24182;
              break;
            }
            default: heff_nomatch(v_t_24180);
            }
            v_t_24184 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24180}), v_t_24183});
            break;
          }
          default: heff_nomatch(v_x1_24174);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24184}), v_sp_243});
        }
        case TAG_ETag: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24186 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24196;
          switch (heff_tag_of(v_x1_24186)) {
          case TAG_IsInferable: {
            V v_i_24187 = heff_field(v_x1_24186, 0);
            heff_take_n(v_x1_24186, 1ULL, 1);
            V v_t_24190;
            switch (heff_tag_of(v_i_24187)) {
            case TAG_At: {
              V v_s_24189 = heff_dup(heff_field(v_i_24187, 1));
              v_t_24190 = v_s_24189;
              break;
            }
            default: heff_nomatch(v_i_24187);
            }
            v_t_24196 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24187}), v_t_24190});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24191 = heff_field(v_x1_24186, 0);
            heff_take_n(v_x1_24186, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24196 = v_c_24191;
            break;
          }
          case TAG_IsType: {
            V v_t_24192 = heff_field(v_x1_24186, 0);
            heff_take_n(v_x1_24186, 1ULL, 1);
            V v_t_24195;
            switch (heff_tag_of(v_t_24192)) {
            case TAG_At: {
              V v_s_24194 = heff_dup(heff_field(v_t_24192, 1));
              v_t_24195 = v_s_24194;
              break;
            }
            default: heff_nomatch(v_t_24192);
            }
            v_t_24196 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24192}), v_t_24195});
            break;
          }
          default: heff_nomatch(v_x1_24186);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24196}), v_sp_243});
        }
        case TAG_EInt: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24198 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24208;
          switch (heff_tag_of(v_x1_24198)) {
          case TAG_IsInferable: {
            V v_i_24199 = heff_field(v_x1_24198, 0);
            heff_take_n(v_x1_24198, 1ULL, 1);
            V v_t_24202;
            switch (heff_tag_of(v_i_24199)) {
            case TAG_At: {
              V v_s_24201 = heff_dup(heff_field(v_i_24199, 1));
              v_t_24202 = v_s_24201;
              break;
            }
            default: heff_nomatch(v_i_24199);
            }
            v_t_24208 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24199}), v_t_24202});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24203 = heff_field(v_x1_24198, 0);
            heff_take_n(v_x1_24198, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24208 = v_c_24203;
            break;
          }
          case TAG_IsType: {
            V v_t_24204 = heff_field(v_x1_24198, 0);
            heff_take_n(v_x1_24198, 1ULL, 1);
            V v_t_24207;
            switch (heff_tag_of(v_t_24204)) {
            case TAG_At: {
              V v_s_24206 = heff_dup(heff_field(v_t_24204, 1));
              v_t_24207 = v_s_24206;
              break;
            }
            default: heff_nomatch(v_t_24204);
            }
            v_t_24208 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24204}), v_t_24207});
            break;
          }
          default: heff_nomatch(v_x1_24198);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24208}), v_sp_243});
        }
        case TAG_EFloat: {
          heff_take_na(v_x2121_24158, 0ULL, 1);
          V v_x1_24210 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24220;
          switch (heff_tag_of(v_x1_24210)) {
          case TAG_IsInferable: {
            V v_i_24211 = heff_field(v_x1_24210, 0);
            heff_take_n(v_x1_24210, 1ULL, 1);
            V v_t_24214;
            switch (heff_tag_of(v_i_24211)) {
            case TAG_At: {
              V v_s_24213 = heff_dup(heff_field(v_i_24211, 1));
              v_t_24214 = v_s_24213;
              break;
            }
            default: heff_nomatch(v_i_24211);
            }
            v_t_24220 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24211}), v_t_24214});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24215 = heff_field(v_x1_24210, 0);
            heff_take_n(v_x1_24210, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24220 = v_c_24215;
            break;
          }
          case TAG_IsType: {
            V v_t_24216 = heff_field(v_x1_24210, 0);
            heff_take_n(v_x1_24210, 1ULL, 1);
            V v_t_24219;
            switch (heff_tag_of(v_t_24216)) {
            case TAG_At: {
              V v_s_24218 = heff_dup(heff_field(v_t_24216, 1));
              v_t_24219 = v_s_24218;
              break;
            }
            default: heff_nomatch(v_t_24216);
            }
            v_t_24220 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24216}), v_t_24219});
            break;
          }
          default: heff_nomatch(v_x1_24210);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24220}), v_sp_243});
        }
        case TAG_EString: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24222 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24232;
          switch (heff_tag_of(v_x1_24222)) {
          case TAG_IsInferable: {
            V v_i_24223 = heff_field(v_x1_24222, 0);
            heff_take_n(v_x1_24222, 1ULL, 1);
            V v_t_24226;
            switch (heff_tag_of(v_i_24223)) {
            case TAG_At: {
              V v_s_24225 = heff_dup(heff_field(v_i_24223, 1));
              v_t_24226 = v_s_24225;
              break;
            }
            default: heff_nomatch(v_i_24223);
            }
            v_t_24232 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24223}), v_t_24226});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24227 = heff_field(v_x1_24222, 0);
            heff_take_n(v_x1_24222, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24232 = v_c_24227;
            break;
          }
          case TAG_IsType: {
            V v_t_24228 = heff_field(v_x1_24222, 0);
            heff_take_n(v_x1_24222, 1ULL, 1);
            V v_t_24231;
            switch (heff_tag_of(v_t_24228)) {
            case TAG_At: {
              V v_s_24230 = heff_dup(heff_field(v_t_24228, 1));
              v_t_24231 = v_s_24230;
              break;
            }
            default: heff_nomatch(v_t_24228);
            }
            v_t_24232 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24228}), v_t_24231});
            break;
          }
          default: heff_nomatch(v_x1_24222);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24232}), v_sp_243});
        }
        case TAG_EBinary: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24234 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24244;
          switch (heff_tag_of(v_x1_24234)) {
          case TAG_IsInferable: {
            V v_i_24235 = heff_field(v_x1_24234, 0);
            heff_take_n(v_x1_24234, 1ULL, 1);
            V v_t_24238;
            switch (heff_tag_of(v_i_24235)) {
            case TAG_At: {
              V v_s_24237 = heff_dup(heff_field(v_i_24235, 1));
              v_t_24238 = v_s_24237;
              break;
            }
            default: heff_nomatch(v_i_24235);
            }
            v_t_24244 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24235}), v_t_24238});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24239 = heff_field(v_x1_24234, 0);
            heff_take_n(v_x1_24234, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24244 = v_c_24239;
            break;
          }
          case TAG_IsType: {
            V v_t_24240 = heff_field(v_x1_24234, 0);
            heff_take_n(v_x1_24234, 1ULL, 1);
            V v_t_24243;
            switch (heff_tag_of(v_t_24240)) {
            case TAG_At: {
              V v_s_24242 = heff_dup(heff_field(v_t_24240, 1));
              v_t_24243 = v_s_24242;
              break;
            }
            default: heff_nomatch(v_t_24240);
            }
            v_t_24244 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24240}), v_t_24243});
            break;
          }
          default: heff_nomatch(v_x1_24234);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24244}), v_sp_243});
        }
        case TAG_ERune: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24256;
          switch (heff_tag_of(v_x1_24246)) {
          case TAG_IsInferable: {
            V v_i_24247 = heff_field(v_x1_24246, 0);
            heff_take_n(v_x1_24246, 1ULL, 1);
            V v_t_24250;
            switch (heff_tag_of(v_i_24247)) {
            case TAG_At: {
              V v_s_24249 = heff_dup(heff_field(v_i_24247, 1));
              v_t_24250 = v_s_24249;
              break;
            }
            default: heff_nomatch(v_i_24247);
            }
            v_t_24256 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24247}), v_t_24250});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24251 = heff_field(v_x1_24246, 0);
            heff_take_n(v_x1_24246, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24256 = v_c_24251;
            break;
          }
          case TAG_IsType: {
            V v_t_24252 = heff_field(v_x1_24246, 0);
            heff_take_n(v_x1_24246, 1ULL, 1);
            V v_t_24255;
            switch (heff_tag_of(v_t_24252)) {
            case TAG_At: {
              V v_s_24254 = heff_dup(heff_field(v_t_24252, 1));
              v_t_24255 = v_s_24254;
              break;
            }
            default: heff_nomatch(v_t_24252);
            }
            v_t_24256 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24252}), v_t_24255});
            break;
          }
          default: heff_nomatch(v_x1_24246);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24256}), v_sp_243});
        }
        case TAG_EWord: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24258 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24268;
          switch (heff_tag_of(v_x1_24258)) {
          case TAG_IsInferable: {
            V v_i_24259 = heff_field(v_x1_24258, 0);
            heff_take_n(v_x1_24258, 1ULL, 1);
            V v_t_24262;
            switch (heff_tag_of(v_i_24259)) {
            case TAG_At: {
              V v_s_24261 = heff_dup(heff_field(v_i_24259, 1));
              v_t_24262 = v_s_24261;
              break;
            }
            default: heff_nomatch(v_i_24259);
            }
            v_t_24268 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24259}), v_t_24262});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24263 = heff_field(v_x1_24258, 0);
            heff_take_n(v_x1_24258, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24268 = v_c_24263;
            break;
          }
          case TAG_IsType: {
            V v_t_24264 = heff_field(v_x1_24258, 0);
            heff_take_n(v_x1_24258, 1ULL, 1);
            V v_t_24267;
            switch (heff_tag_of(v_t_24264)) {
            case TAG_At: {
              V v_s_24266 = heff_dup(heff_field(v_t_24264, 1));
              v_t_24267 = v_s_24266;
              break;
            }
            default: heff_nomatch(v_t_24264);
            }
            v_t_24268 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24264}), v_t_24267});
            break;
          }
          default: heff_nomatch(v_x1_24258);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24268}), v_sp_243});
        }
        case TAG_EApp: {
          V v_ru_24x2121_24158_24EApp = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24271 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24281;
          switch (heff_tag_of(v_x1_24271)) {
          case TAG_IsInferable: {
            V v_i_24272 = heff_field(v_x1_24271, 0);
            heff_take_n(v_x1_24271, 1ULL, 1);
            V v_t_24275;
            switch (heff_tag_of(v_i_24272)) {
            case TAG_At: {
              V v_s_24274 = heff_dup(heff_field(v_i_24272, 1));
              v_t_24275 = v_s_24274;
              break;
            }
            default: heff_nomatch(v_i_24272);
            }
            v_t_24281 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24272}), v_t_24275});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24276 = heff_field(v_x1_24271, 0);
            heff_take_n(v_x1_24271, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24281 = v_c_24276;
            break;
          }
          case TAG_IsType: {
            V v_t_24277 = heff_field(v_x1_24271, 0);
            heff_take_n(v_x1_24271, 1ULL, 1);
            V v_t_24280;
            switch (heff_tag_of(v_t_24277)) {
            case TAG_At: {
              V v_s_24279 = heff_dup(heff_field(v_t_24277, 1));
              v_t_24280 = v_s_24279;
              break;
            }
            default: heff_nomatch(v_t_24277);
            }
            v_t_24281 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24277}), v_t_24280});
            break;
          }
          default: heff_nomatch(v_x1_24271);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24281}), v_sp_243});
        }
        case TAG_EProject: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24283 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24293;
          switch (heff_tag_of(v_x1_24283)) {
          case TAG_IsInferable: {
            V v_i_24284 = heff_field(v_x1_24283, 0);
            heff_take_n(v_x1_24283, 1ULL, 1);
            V v_t_24287;
            switch (heff_tag_of(v_i_24284)) {
            case TAG_At: {
              V v_s_24286 = heff_dup(heff_field(v_i_24284, 1));
              v_t_24287 = v_s_24286;
              break;
            }
            default: heff_nomatch(v_i_24284);
            }
            v_t_24293 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24284}), v_t_24287});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24288 = heff_field(v_x1_24283, 0);
            heff_take_n(v_x1_24283, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24293 = v_c_24288;
            break;
          }
          case TAG_IsType: {
            V v_t_24289 = heff_field(v_x1_24283, 0);
            heff_take_n(v_x1_24283, 1ULL, 1);
            V v_t_24292;
            switch (heff_tag_of(v_t_24289)) {
            case TAG_At: {
              V v_s_24291 = heff_dup(heff_field(v_t_24289, 1));
              v_t_24292 = v_s_24291;
              break;
            }
            default: heff_nomatch(v_t_24289);
            }
            v_t_24293 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24289}), v_t_24292});
            break;
          }
          default: heff_nomatch(v_x1_24283);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24293}), v_sp_243});
        }
        case TAG_ENamed: {
          V v_ru_24x2121_24158_24ENamed = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24296 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24306;
          switch (heff_tag_of(v_x1_24296)) {
          case TAG_IsInferable: {
            V v_i_24297 = heff_field(v_x1_24296, 0);
            heff_take_n(v_x1_24296, 1ULL, 1);
            V v_t_24300;
            switch (heff_tag_of(v_i_24297)) {
            case TAG_At: {
              V v_s_24299 = heff_dup(heff_field(v_i_24297, 1));
              v_t_24300 = v_s_24299;
              break;
            }
            default: heff_nomatch(v_i_24297);
            }
            v_t_24306 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24297}), v_t_24300});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24301 = heff_field(v_x1_24296, 0);
            heff_take_n(v_x1_24296, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24306 = v_c_24301;
            break;
          }
          case TAG_IsType: {
            V v_t_24302 = heff_field(v_x1_24296, 0);
            heff_take_n(v_x1_24296, 1ULL, 1);
            V v_t_24305;
            switch (heff_tag_of(v_t_24302)) {
            case TAG_At: {
              V v_s_24304 = heff_dup(heff_field(v_t_24302, 1));
              v_t_24305 = v_s_24304;
              break;
            }
            default: heff_nomatch(v_t_24302);
            }
            v_t_24306 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24302}), v_t_24305});
            break;
          }
          default: heff_nomatch(v_x1_24296);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24306}), v_sp_243});
        }
        case TAG_EPi: {
          V v_ru_24x2121_24158_24EPi = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24309 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24319;
          switch (heff_tag_of(v_x1_24309)) {
          case TAG_IsInferable: {
            V v_i_24310 = heff_field(v_x1_24309, 0);
            heff_take_n(v_x1_24309, 1ULL, 1);
            V v_t_24313;
            switch (heff_tag_of(v_i_24310)) {
            case TAG_At: {
              V v_s_24312 = heff_dup(heff_field(v_i_24310, 1));
              v_t_24313 = v_s_24312;
              break;
            }
            default: heff_nomatch(v_i_24310);
            }
            v_t_24319 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24310}), v_t_24313});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24314 = heff_field(v_x1_24309, 0);
            heff_take_n(v_x1_24309, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24319 = v_c_24314;
            break;
          }
          case TAG_IsType: {
            V v_t_24315 = heff_field(v_x1_24309, 0);
            heff_take_n(v_x1_24309, 1ULL, 1);
            V v_t_24318;
            switch (heff_tag_of(v_t_24315)) {
            case TAG_At: {
              V v_s_24317 = heff_dup(heff_field(v_t_24315, 1));
              v_t_24318 = v_s_24317;
              break;
            }
            default: heff_nomatch(v_t_24315);
            }
            v_t_24319 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24315}), v_t_24318});
            break;
          }
          default: heff_nomatch(v_x1_24309);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24319}), v_sp_243});
        }
        case TAG_ELam: {
          V v_ru_24x2121_24158_24ELam = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24322 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24332;
          switch (heff_tag_of(v_x1_24322)) {
          case TAG_IsInferable: {
            V v_i_24323 = heff_field(v_x1_24322, 0);
            heff_take_n(v_x1_24322, 1ULL, 1);
            V v_t_24326;
            switch (heff_tag_of(v_i_24323)) {
            case TAG_At: {
              V v_s_24325 = heff_dup(heff_field(v_i_24323, 1));
              v_t_24326 = v_s_24325;
              break;
            }
            default: heff_nomatch(v_i_24323);
            }
            v_t_24332 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24323}), v_t_24326});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24327 = heff_field(v_x1_24322, 0);
            heff_take_n(v_x1_24322, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24332 = v_c_24327;
            break;
          }
          case TAG_IsType: {
            V v_t_24328 = heff_field(v_x1_24322, 0);
            heff_take_n(v_x1_24322, 1ULL, 1);
            V v_t_24331;
            switch (heff_tag_of(v_t_24328)) {
            case TAG_At: {
              V v_s_24330 = heff_dup(heff_field(v_t_24328, 1));
              v_t_24331 = v_s_24330;
              break;
            }
            default: heff_nomatch(v_t_24328);
            }
            v_t_24332 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24328}), v_t_24331});
            break;
          }
          default: heff_nomatch(v_x1_24322);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24332}), v_sp_243});
        }
        case TAG_EAnn: {
          V v_ru_24x2121_24158_24EAnn = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24335 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24345;
          switch (heff_tag_of(v_x1_24335)) {
          case TAG_IsInferable: {
            V v_i_24336 = heff_field(v_x1_24335, 0);
            heff_take_n(v_x1_24335, 1ULL, 1);
            V v_t_24339;
            switch (heff_tag_of(v_i_24336)) {
            case TAG_At: {
              V v_s_24338 = heff_dup(heff_field(v_i_24336, 1));
              v_t_24339 = v_s_24338;
              break;
            }
            default: heff_nomatch(v_i_24336);
            }
            v_t_24345 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24336}), v_t_24339});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24340 = heff_field(v_x1_24335, 0);
            heff_take_n(v_x1_24335, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24345 = v_c_24340;
            break;
          }
          case TAG_IsType: {
            V v_t_24341 = heff_field(v_x1_24335, 0);
            heff_take_n(v_x1_24335, 1ULL, 1);
            V v_t_24344;
            switch (heff_tag_of(v_t_24341)) {
            case TAG_At: {
              V v_s_24343 = heff_dup(heff_field(v_t_24341, 1));
              v_t_24344 = v_s_24343;
              break;
            }
            default: heff_nomatch(v_t_24341);
            }
            v_t_24345 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24341}), v_t_24344});
            break;
          }
          default: heff_nomatch(v_x1_24335);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24345}), v_sp_243});
        }
        case TAG_ESpec: {
          heff_take_n(v_x2121_24158, 0ULL, 4);
          V v_x1_24350 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24360;
          switch (heff_tag_of(v_x1_24350)) {
          case TAG_IsInferable: {
            V v_i_24351 = heff_field(v_x1_24350, 0);
            heff_take_n(v_x1_24350, 1ULL, 1);
            V v_t_24354;
            switch (heff_tag_of(v_i_24351)) {
            case TAG_At: {
              V v_s_24353 = heff_dup(heff_field(v_i_24351, 1));
              v_t_24354 = v_s_24353;
              break;
            }
            default: heff_nomatch(v_i_24351);
            }
            v_t_24360 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24351}), v_t_24354});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24355 = heff_field(v_x1_24350, 0);
            heff_take_n(v_x1_24350, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24360 = v_c_24355;
            break;
          }
          case TAG_IsType: {
            V v_t_24356 = heff_field(v_x1_24350, 0);
            heff_take_n(v_x1_24350, 1ULL, 1);
            V v_t_24359;
            switch (heff_tag_of(v_t_24356)) {
            case TAG_At: {
              V v_s_24358 = heff_dup(heff_field(v_t_24356, 1));
              v_t_24359 = v_s_24358;
              break;
            }
            default: heff_nomatch(v_t_24356);
            }
            v_t_24360 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24356}), v_t_24359});
            break;
          }
          default: heff_nomatch(v_x1_24350);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24360}), v_sp_243});
        }
        case TAG_ESig: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24362 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24372;
          switch (heff_tag_of(v_x1_24362)) {
          case TAG_IsInferable: {
            V v_i_24363 = heff_field(v_x1_24362, 0);
            heff_take_n(v_x1_24362, 1ULL, 1);
            V v_t_24366;
            switch (heff_tag_of(v_i_24363)) {
            case TAG_At: {
              V v_s_24365 = heff_dup(heff_field(v_i_24363, 1));
              v_t_24366 = v_s_24365;
              break;
            }
            default: heff_nomatch(v_i_24363);
            }
            v_t_24372 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24363}), v_t_24366});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24367 = heff_field(v_x1_24362, 0);
            heff_take_n(v_x1_24362, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24372 = v_c_24367;
            break;
          }
          case TAG_IsType: {
            V v_t_24368 = heff_field(v_x1_24362, 0);
            heff_take_n(v_x1_24362, 1ULL, 1);
            V v_t_24371;
            switch (heff_tag_of(v_t_24368)) {
            case TAG_At: {
              V v_s_24370 = heff_dup(heff_field(v_t_24368, 1));
              v_t_24371 = v_s_24370;
              break;
            }
            default: heff_nomatch(v_t_24368);
            }
            v_t_24372 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24368}), v_t_24371});
            break;
          }
          default: heff_nomatch(v_x1_24362);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24372}), v_sp_243});
        }
        case TAG_ESum: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24374 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24384;
          switch (heff_tag_of(v_x1_24374)) {
          case TAG_IsInferable: {
            V v_i_24375 = heff_field(v_x1_24374, 0);
            heff_take_n(v_x1_24374, 1ULL, 1);
            V v_t_24378;
            switch (heff_tag_of(v_i_24375)) {
            case TAG_At: {
              V v_s_24377 = heff_dup(heff_field(v_i_24375, 1));
              v_t_24378 = v_s_24377;
              break;
            }
            default: heff_nomatch(v_i_24375);
            }
            v_t_24384 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24375}), v_t_24378});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24379 = heff_field(v_x1_24374, 0);
            heff_take_n(v_x1_24374, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24384 = v_c_24379;
            break;
          }
          case TAG_IsType: {
            V v_t_24380 = heff_field(v_x1_24374, 0);
            heff_take_n(v_x1_24374, 1ULL, 1);
            V v_t_24383;
            switch (heff_tag_of(v_t_24380)) {
            case TAG_At: {
              V v_s_24382 = heff_dup(heff_field(v_t_24380, 1));
              v_t_24383 = v_s_24382;
              break;
            }
            default: heff_nomatch(v_t_24380);
            }
            v_t_24384 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24380}), v_t_24383});
            break;
          }
          default: heff_nomatch(v_x1_24374);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24384}), v_sp_243});
        }
        case TAG_EStruct: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24386 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24396;
          switch (heff_tag_of(v_x1_24386)) {
          case TAG_IsInferable: {
            V v_i_24387 = heff_field(v_x1_24386, 0);
            heff_take_n(v_x1_24386, 1ULL, 1);
            V v_t_24390;
            switch (heff_tag_of(v_i_24387)) {
            case TAG_At: {
              V v_s_24389 = heff_dup(heff_field(v_i_24387, 1));
              v_t_24390 = v_s_24389;
              break;
            }
            default: heff_nomatch(v_i_24387);
            }
            v_t_24396 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24387}), v_t_24390});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24391 = heff_field(v_x1_24386, 0);
            heff_take_n(v_x1_24386, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24396 = v_c_24391;
            break;
          }
          case TAG_IsType: {
            V v_t_24392 = heff_field(v_x1_24386, 0);
            heff_take_n(v_x1_24386, 1ULL, 1);
            V v_t_24395;
            switch (heff_tag_of(v_t_24392)) {
            case TAG_At: {
              V v_s_24394 = heff_dup(heff_field(v_t_24392, 1));
              v_t_24395 = v_s_24394;
              break;
            }
            default: heff_nomatch(v_t_24392);
            }
            v_t_24396 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24392}), v_t_24395});
            break;
          }
          default: heff_nomatch(v_x1_24386);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24396}), v_sp_243});
        }
        case TAG_EUpdate: {
          V v_ru_24x2121_24158_24EUpdate = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24399 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24409;
          switch (heff_tag_of(v_x1_24399)) {
          case TAG_IsInferable: {
            V v_i_24400 = heff_field(v_x1_24399, 0);
            heff_take_n(v_x1_24399, 1ULL, 1);
            V v_t_24403;
            switch (heff_tag_of(v_i_24400)) {
            case TAG_At: {
              V v_s_24402 = heff_dup(heff_field(v_i_24400, 1));
              v_t_24403 = v_s_24402;
              break;
            }
            default: heff_nomatch(v_i_24400);
            }
            v_t_24409 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24400}), v_t_24403});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24404 = heff_field(v_x1_24399, 0);
            heff_take_n(v_x1_24399, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24409 = v_c_24404;
            break;
          }
          case TAG_IsType: {
            V v_t_24405 = heff_field(v_x1_24399, 0);
            heff_take_n(v_x1_24399, 1ULL, 1);
            V v_t_24408;
            switch (heff_tag_of(v_t_24405)) {
            case TAG_At: {
              V v_s_24407 = heff_dup(heff_field(v_t_24405, 1));
              v_t_24408 = v_s_24407;
              break;
            }
            default: heff_nomatch(v_t_24405);
            }
            v_t_24409 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24405}), v_t_24408});
            break;
          }
          default: heff_nomatch(v_x1_24399);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24409}), v_sp_243});
        }
        case TAG_EMatch: {
          V v_ru_24x2121_24158_24EMatch = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24422;
          switch (heff_tag_of(v_x1_24412)) {
          case TAG_IsInferable: {
            V v_i_24413 = heff_field(v_x1_24412, 0);
            heff_take_n(v_x1_24412, 1ULL, 1);
            V v_t_24416;
            switch (heff_tag_of(v_i_24413)) {
            case TAG_At: {
              V v_s_24415 = heff_dup(heff_field(v_i_24413, 1));
              v_t_24416 = v_s_24415;
              break;
            }
            default: heff_nomatch(v_i_24413);
            }
            v_t_24422 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24413}), v_t_24416});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24417 = heff_field(v_x1_24412, 0);
            heff_take_n(v_x1_24412, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24422 = v_c_24417;
            break;
          }
          case TAG_IsType: {
            V v_t_24418 = heff_field(v_x1_24412, 0);
            heff_take_n(v_x1_24412, 1ULL, 1);
            V v_t_24421;
            switch (heff_tag_of(v_t_24418)) {
            case TAG_At: {
              V v_s_24420 = heff_dup(heff_field(v_t_24418, 1));
              v_t_24421 = v_s_24420;
              break;
            }
            default: heff_nomatch(v_t_24418);
            }
            v_t_24422 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24418}), v_t_24421});
            break;
          }
          default: heff_nomatch(v_x1_24412);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24422}), v_sp_243});
        }
        case TAG_ELetIn: {
          V v_ru_24x2121_24158_24ELetIn = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24435;
          switch (heff_tag_of(v_x1_24425)) {
          case TAG_IsInferable: {
            V v_i_24426 = heff_field(v_x1_24425, 0);
            heff_take_n(v_x1_24425, 1ULL, 1);
            V v_t_24429;
            switch (heff_tag_of(v_i_24426)) {
            case TAG_At: {
              V v_s_24428 = heff_dup(heff_field(v_i_24426, 1));
              v_t_24429 = v_s_24428;
              break;
            }
            default: heff_nomatch(v_i_24426);
            }
            v_t_24435 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24426}), v_t_24429});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24430 = heff_field(v_x1_24425, 0);
            heff_take_n(v_x1_24425, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24435 = v_c_24430;
            break;
          }
          case TAG_IsType: {
            V v_t_24431 = heff_field(v_x1_24425, 0);
            heff_take_n(v_x1_24425, 1ULL, 1);
            V v_t_24434;
            switch (heff_tag_of(v_t_24431)) {
            case TAG_At: {
              V v_s_24433 = heff_dup(heff_field(v_t_24431, 1));
              v_t_24434 = v_s_24433;
              break;
            }
            default: heff_nomatch(v_t_24431);
            }
            v_t_24435 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24431}), v_t_24434});
            break;
          }
          default: heff_nomatch(v_x1_24425);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24435}), v_sp_243});
        }
        case TAG_EDo: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24447;
          switch (heff_tag_of(v_x1_24437)) {
          case TAG_IsInferable: {
            V v_i_24438 = heff_field(v_x1_24437, 0);
            heff_take_n(v_x1_24437, 1ULL, 1);
            V v_t_24441;
            switch (heff_tag_of(v_i_24438)) {
            case TAG_At: {
              V v_s_24440 = heff_dup(heff_field(v_i_24438, 1));
              v_t_24441 = v_s_24440;
              break;
            }
            default: heff_nomatch(v_i_24438);
            }
            v_t_24447 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24438}), v_t_24441});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24442 = heff_field(v_x1_24437, 0);
            heff_take_n(v_x1_24437, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24447 = v_c_24442;
            break;
          }
          case TAG_IsType: {
            V v_t_24443 = heff_field(v_x1_24437, 0);
            heff_take_n(v_x1_24437, 1ULL, 1);
            V v_t_24446;
            switch (heff_tag_of(v_t_24443)) {
            case TAG_At: {
              V v_s_24445 = heff_dup(heff_field(v_t_24443, 1));
              v_t_24446 = v_s_24445;
              break;
            }
            default: heff_nomatch(v_t_24443);
            }
            v_t_24447 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24443}), v_t_24446});
            break;
          }
          default: heff_nomatch(v_x1_24437);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24447}), v_sp_243});
        }
        case TAG_ELocal: {
          V v_ru_24x2121_24158_24ELocal = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24460;
          switch (heff_tag_of(v_x1_24450)) {
          case TAG_IsInferable: {
            V v_i_24451 = heff_field(v_x1_24450, 0);
            heff_take_n(v_x1_24450, 1ULL, 1);
            V v_t_24454;
            switch (heff_tag_of(v_i_24451)) {
            case TAG_At: {
              V v_s_24453 = heff_dup(heff_field(v_i_24451, 1));
              v_t_24454 = v_s_24453;
              break;
            }
            default: heff_nomatch(v_i_24451);
            }
            v_t_24460 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24451}), v_t_24454});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24455 = heff_field(v_x1_24450, 0);
            heff_take_n(v_x1_24450, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24460 = v_c_24455;
            break;
          }
          case TAG_IsType: {
            V v_t_24456 = heff_field(v_x1_24450, 0);
            heff_take_n(v_x1_24450, 1ULL, 1);
            V v_t_24459;
            switch (heff_tag_of(v_t_24456)) {
            case TAG_At: {
              V v_s_24458 = heff_dup(heff_field(v_t_24456, 1));
              v_t_24459 = v_s_24458;
              break;
            }
            default: heff_nomatch(v_t_24456);
            }
            v_t_24460 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24456}), v_t_24459});
            break;
          }
          default: heff_nomatch(v_x1_24450);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24460}), v_sp_243});
        }
        case TAG_EInvalid: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24472;
          switch (heff_tag_of(v_x1_24462)) {
          case TAG_IsInferable: {
            V v_i_24463 = heff_field(v_x1_24462, 0);
            heff_take_n(v_x1_24462, 1ULL, 1);
            V v_t_24466;
            switch (heff_tag_of(v_i_24463)) {
            case TAG_At: {
              V v_s_24465 = heff_dup(heff_field(v_i_24463, 1));
              v_t_24466 = v_s_24465;
              break;
            }
            default: heff_nomatch(v_i_24463);
            }
            v_t_24472 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24463}), v_t_24466});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24467 = heff_field(v_x1_24462, 0);
            heff_take_n(v_x1_24462, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24472 = v_c_24467;
            break;
          }
          case TAG_IsType: {
            V v_t_24468 = heff_field(v_x1_24462, 0);
            heff_take_n(v_x1_24462, 1ULL, 1);
            V v_t_24471;
            switch (heff_tag_of(v_t_24468)) {
            case TAG_At: {
              V v_s_24470 = heff_dup(heff_field(v_t_24468, 1));
              v_t_24471 = v_s_24470;
              break;
            }
            default: heff_nomatch(v_t_24468);
            }
            v_t_24472 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24468}), v_t_24471});
            break;
          }
          default: heff_nomatch(v_x1_24462);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24472}), v_sp_243});
        }
        case TAG_EAssign: {
          heff_take_n(v_x2121_24158, 0ULL, 3);
          V v_x1_24476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24486;
          switch (heff_tag_of(v_x1_24476)) {
          case TAG_IsInferable: {
            V v_i_24477 = heff_field(v_x1_24476, 0);
            heff_take_n(v_x1_24476, 1ULL, 1);
            V v_t_24480;
            switch (heff_tag_of(v_i_24477)) {
            case TAG_At: {
              V v_s_24479 = heff_dup(heff_field(v_i_24477, 1));
              v_t_24480 = v_s_24479;
              break;
            }
            default: heff_nomatch(v_i_24477);
            }
            v_t_24486 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24477}), v_t_24480});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24481 = heff_field(v_x1_24476, 0);
            heff_take_n(v_x1_24476, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24486 = v_c_24481;
            break;
          }
          case TAG_IsType: {
            V v_t_24482 = heff_field(v_x1_24476, 0);
            heff_take_n(v_x1_24476, 1ULL, 1);
            V v_t_24485;
            switch (heff_tag_of(v_t_24482)) {
            case TAG_At: {
              V v_s_24484 = heff_dup(heff_field(v_t_24482, 1));
              v_t_24485 = v_s_24484;
              break;
            }
            default: heff_nomatch(v_t_24482);
            }
            v_t_24486 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24482}), v_t_24485});
            break;
          }
          default: heff_nomatch(v_x1_24476);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24486}), v_sp_243});
        }
        case TAG_EWhile: {
          V v_ru_24x2121_24158_24EWhile = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24499;
          switch (heff_tag_of(v_x1_24489)) {
          case TAG_IsInferable: {
            V v_i_24490 = heff_field(v_x1_24489, 0);
            heff_take_n(v_x1_24489, 1ULL, 1);
            V v_t_24493;
            switch (heff_tag_of(v_i_24490)) {
            case TAG_At: {
              V v_s_24492 = heff_dup(heff_field(v_i_24490, 1));
              v_t_24493 = v_s_24492;
              break;
            }
            default: heff_nomatch(v_i_24490);
            }
            v_t_24499 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24490}), v_t_24493});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24494 = heff_field(v_x1_24489, 0);
            heff_take_n(v_x1_24489, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24499 = v_c_24494;
            break;
          }
          case TAG_IsType: {
            V v_t_24495 = heff_field(v_x1_24489, 0);
            heff_take_n(v_x1_24489, 1ULL, 1);
            V v_t_24498;
            switch (heff_tag_of(v_t_24495)) {
            case TAG_At: {
              V v_s_24497 = heff_dup(heff_field(v_t_24495, 1));
              v_t_24498 = v_s_24497;
              break;
            }
            default: heff_nomatch(v_t_24495);
            }
            v_t_24499 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24495}), v_t_24498});
            break;
          }
          default: heff_nomatch(v_x1_24489);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24499}), v_sp_243});
        }
        case TAG_EFor: {
          heff_take_n(v_x2121_24158, 0ULL, 3);
          V v_x1_24503 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24513;
          switch (heff_tag_of(v_x1_24503)) {
          case TAG_IsInferable: {
            V v_i_24504 = heff_field(v_x1_24503, 0);
            heff_take_n(v_x1_24503, 1ULL, 1);
            V v_t_24507;
            switch (heff_tag_of(v_i_24504)) {
            case TAG_At: {
              V v_s_24506 = heff_dup(heff_field(v_i_24504, 1));
              v_t_24507 = v_s_24506;
              break;
            }
            default: heff_nomatch(v_i_24504);
            }
            v_t_24513 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24504}), v_t_24507});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24508 = heff_field(v_x1_24503, 0);
            heff_take_n(v_x1_24503, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24513 = v_c_24508;
            break;
          }
          case TAG_IsType: {
            V v_t_24509 = heff_field(v_x1_24503, 0);
            heff_take_n(v_x1_24503, 1ULL, 1);
            V v_t_24512;
            switch (heff_tag_of(v_t_24509)) {
            case TAG_At: {
              V v_s_24511 = heff_dup(heff_field(v_t_24509, 1));
              v_t_24512 = v_s_24511;
              break;
            }
            default: heff_nomatch(v_t_24509);
            }
            v_t_24513 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24509}), v_t_24512});
            break;
          }
          default: heff_nomatch(v_x1_24503);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24513}), v_sp_243});
        }
        case TAG_EIfThen: {
          V v_ru_24x2121_24158_24EIfThen = heff_take_reuse_n(v_x2121_24158, 0ULL, 2);
          V v_x1_24516 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24526;
          switch (heff_tag_of(v_x1_24516)) {
          case TAG_IsInferable: {
            V v_i_24517 = heff_field(v_x1_24516, 0);
            heff_take_n(v_x1_24516, 1ULL, 1);
            V v_t_24520;
            switch (heff_tag_of(v_i_24517)) {
            case TAG_At: {
              V v_s_24519 = heff_dup(heff_field(v_i_24517, 1));
              v_t_24520 = v_s_24519;
              break;
            }
            default: heff_nomatch(v_i_24517);
            }
            v_t_24526 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24517}), v_t_24520});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24521 = heff_field(v_x1_24516, 0);
            heff_take_n(v_x1_24516, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24526 = v_c_24521;
            break;
          }
          case TAG_IsType: {
            V v_t_24522 = heff_field(v_x1_24516, 0);
            heff_take_n(v_x1_24516, 1ULL, 1);
            V v_t_24525;
            switch (heff_tag_of(v_t_24522)) {
            case TAG_At: {
              V v_s_24524 = heff_dup(heff_field(v_t_24522, 1));
              v_t_24525 = v_s_24524;
              break;
            }
            default: heff_nomatch(v_t_24522);
            }
            v_t_24526 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24522}), v_t_24525});
            break;
          }
          default: heff_nomatch(v_x1_24516);
          }
          return heff_tag_at_n(v_ru_24x2121_24158_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24526}), v_sp_243});
        }
        case TAG_EBreak: {
          V v_x1_24527 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24537;
          switch (heff_tag_of(v_x1_24527)) {
          case TAG_IsInferable: {
            V v_i_24528 = heff_field(v_x1_24527, 0);
            heff_take_n(v_x1_24527, 1ULL, 1);
            V v_t_24531;
            switch (heff_tag_of(v_i_24528)) {
            case TAG_At: {
              V v_s_24530 = heff_dup(heff_field(v_i_24528, 1));
              v_t_24531 = v_s_24530;
              break;
            }
            default: heff_nomatch(v_i_24528);
            }
            v_t_24537 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24528}), v_t_24531});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24532 = heff_field(v_x1_24527, 0);
            heff_take_n(v_x1_24527, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24537 = v_c_24532;
            break;
          }
          case TAG_IsType: {
            V v_t_24533 = heff_field(v_x1_24527, 0);
            heff_take_n(v_x1_24527, 1ULL, 1);
            V v_t_24536;
            switch (heff_tag_of(v_t_24533)) {
            case TAG_At: {
              V v_s_24535 = heff_dup(heff_field(v_t_24533, 1));
              v_t_24536 = v_s_24535;
              break;
            }
            default: heff_nomatch(v_t_24533);
            }
            v_t_24537 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24533}), v_t_24536});
            break;
          }
          default: heff_nomatch(v_x1_24527);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24537}), v_sp_243});
        }
        case TAG_EContinue: {
          V v_x1_24538 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24548;
          switch (heff_tag_of(v_x1_24538)) {
          case TAG_IsInferable: {
            V v_i_24539 = heff_field(v_x1_24538, 0);
            heff_take_n(v_x1_24538, 1ULL, 1);
            V v_t_24542;
            switch (heff_tag_of(v_i_24539)) {
            case TAG_At: {
              V v_s_24541 = heff_dup(heff_field(v_i_24539, 1));
              v_t_24542 = v_s_24541;
              break;
            }
            default: heff_nomatch(v_i_24539);
            }
            v_t_24548 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24539}), v_t_24542});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24543 = heff_field(v_x1_24538, 0);
            heff_take_n(v_x1_24538, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24548 = v_c_24543;
            break;
          }
          case TAG_IsType: {
            V v_t_24544 = heff_field(v_x1_24538, 0);
            heff_take_n(v_x1_24538, 1ULL, 1);
            V v_t_24547;
            switch (heff_tag_of(v_t_24544)) {
            case TAG_At: {
              V v_s_24546 = heff_dup(heff_field(v_t_24544, 1));
              v_t_24547 = v_s_24546;
              break;
            }
            default: heff_nomatch(v_t_24544);
            }
            v_t_24548 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24544}), v_t_24547});
            break;
          }
          default: heff_nomatch(v_x1_24538);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24548}), v_sp_243});
        }
        case TAG_EReturn: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24550 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24560;
          switch (heff_tag_of(v_x1_24550)) {
          case TAG_IsInferable: {
            V v_i_24551 = heff_field(v_x1_24550, 0);
            heff_take_n(v_x1_24550, 1ULL, 1);
            V v_t_24554;
            switch (heff_tag_of(v_i_24551)) {
            case TAG_At: {
              V v_s_24553 = heff_dup(heff_field(v_i_24551, 1));
              v_t_24554 = v_s_24553;
              break;
            }
            default: heff_nomatch(v_i_24551);
            }
            v_t_24560 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24551}), v_t_24554});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24555 = heff_field(v_x1_24550, 0);
            heff_take_n(v_x1_24550, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24560 = v_c_24555;
            break;
          }
          case TAG_IsType: {
            V v_t_24556 = heff_field(v_x1_24550, 0);
            heff_take_n(v_x1_24550, 1ULL, 1);
            V v_t_24559;
            switch (heff_tag_of(v_t_24556)) {
            case TAG_At: {
              V v_s_24558 = heff_dup(heff_field(v_t_24556, 1));
              v_t_24559 = v_s_24558;
              break;
            }
            default: heff_nomatch(v_t_24556);
            }
            v_t_24560 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24556}), v_t_24559});
            break;
          }
          default: heff_nomatch(v_x1_24550);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24560}), v_sp_243});
        }
        case TAG_ENest: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24562 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24572;
          switch (heff_tag_of(v_x1_24562)) {
          case TAG_IsInferable: {
            V v_i_24563 = heff_field(v_x1_24562, 0);
            heff_take_n(v_x1_24562, 1ULL, 1);
            V v_t_24566;
            switch (heff_tag_of(v_i_24563)) {
            case TAG_At: {
              V v_s_24565 = heff_dup(heff_field(v_i_24563, 1));
              v_t_24566 = v_s_24565;
              break;
            }
            default: heff_nomatch(v_i_24563);
            }
            v_t_24572 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24563}), v_t_24566});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24567 = heff_field(v_x1_24562, 0);
            heff_take_n(v_x1_24562, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24572 = v_c_24567;
            break;
          }
          case TAG_IsType: {
            V v_t_24568 = heff_field(v_x1_24562, 0);
            heff_take_n(v_x1_24562, 1ULL, 1);
            V v_t_24571;
            switch (heff_tag_of(v_t_24568)) {
            case TAG_At: {
              V v_s_24570 = heff_dup(heff_field(v_t_24568, 1));
              v_t_24571 = v_s_24570;
              break;
            }
            default: heff_nomatch(v_t_24568);
            }
            v_t_24572 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24568}), v_t_24571});
            break;
          }
          default: heff_nomatch(v_x1_24562);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24572}), v_sp_243});
        }
        case TAG_ELazy: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24574 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24584;
          switch (heff_tag_of(v_x1_24574)) {
          case TAG_IsInferable: {
            V v_i_24575 = heff_field(v_x1_24574, 0);
            heff_take_n(v_x1_24574, 1ULL, 1);
            V v_t_24578;
            switch (heff_tag_of(v_i_24575)) {
            case TAG_At: {
              V v_s_24577 = heff_dup(heff_field(v_i_24575, 1));
              v_t_24578 = v_s_24577;
              break;
            }
            default: heff_nomatch(v_i_24575);
            }
            v_t_24584 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24575}), v_t_24578});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24579 = heff_field(v_x1_24574, 0);
            heff_take_n(v_x1_24574, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24584 = v_c_24579;
            break;
          }
          case TAG_IsType: {
            V v_t_24580 = heff_field(v_x1_24574, 0);
            heff_take_n(v_x1_24574, 1ULL, 1);
            V v_t_24583;
            switch (heff_tag_of(v_t_24580)) {
            case TAG_At: {
              V v_s_24582 = heff_dup(heff_field(v_t_24580, 1));
              v_t_24583 = v_s_24582;
              break;
            }
            default: heff_nomatch(v_t_24580);
            }
            v_t_24584 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24580}), v_t_24583});
            break;
          }
          default: heff_nomatch(v_x1_24574);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24584}), v_sp_243});
        }
        case TAG_ETuple: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24586 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24596;
          switch (heff_tag_of(v_x1_24586)) {
          case TAG_IsInferable: {
            V v_i_24587 = heff_field(v_x1_24586, 0);
            heff_take_n(v_x1_24586, 1ULL, 1);
            V v_t_24590;
            switch (heff_tag_of(v_i_24587)) {
            case TAG_At: {
              V v_s_24589 = heff_dup(heff_field(v_i_24587, 1));
              v_t_24590 = v_s_24589;
              break;
            }
            default: heff_nomatch(v_i_24587);
            }
            v_t_24596 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24587}), v_t_24590});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24591 = heff_field(v_x1_24586, 0);
            heff_take_n(v_x1_24586, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24596 = v_c_24591;
            break;
          }
          case TAG_IsType: {
            V v_t_24592 = heff_field(v_x1_24586, 0);
            heff_take_n(v_x1_24586, 1ULL, 1);
            V v_t_24595;
            switch (heff_tag_of(v_t_24592)) {
            case TAG_At: {
              V v_s_24594 = heff_dup(heff_field(v_t_24592, 1));
              v_t_24595 = v_s_24594;
              break;
            }
            default: heff_nomatch(v_t_24592);
            }
            v_t_24596 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24592}), v_t_24595});
            break;
          }
          default: heff_nomatch(v_x1_24586);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24596}), v_sp_243});
        }
        case TAG_ETry: {
          heff_take_n(v_x2121_24158, 0ULL, 1);
          V v_x1_24598 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24608;
          switch (heff_tag_of(v_x1_24598)) {
          case TAG_IsInferable: {
            V v_i_24599 = heff_field(v_x1_24598, 0);
            heff_take_n(v_x1_24598, 1ULL, 1);
            V v_t_24602;
            switch (heff_tag_of(v_i_24599)) {
            case TAG_At: {
              V v_s_24601 = heff_dup(heff_field(v_i_24599, 1));
              v_t_24602 = v_s_24601;
              break;
            }
            default: heff_nomatch(v_i_24599);
            }
            v_t_24608 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24599}), v_t_24602});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24603 = heff_field(v_x1_24598, 0);
            heff_take_n(v_x1_24598, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24608 = v_c_24603;
            break;
          }
          case TAG_IsType: {
            V v_t_24604 = heff_field(v_x1_24598, 0);
            heff_take_n(v_x1_24598, 1ULL, 1);
            V v_t_24607;
            switch (heff_tag_of(v_t_24604)) {
            case TAG_At: {
              V v_s_24606 = heff_dup(heff_field(v_t_24604, 1));
              v_t_24607 = v_s_24606;
              break;
            }
            default: heff_nomatch(v_t_24604);
            }
            v_t_24608 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24604}), v_t_24607});
            break;
          }
          default: heff_nomatch(v_x1_24598);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24608}), v_sp_243});
        }
        case TAG_EWith: {
          heff_take_n(v_x2121_24158, 0ULL, 4);
          V v_x1_24613 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24157}));
          V v_t_24623;
          switch (heff_tag_of(v_x1_24613)) {
          case TAG_IsInferable: {
            V v_i_24614 = heff_field(v_x1_24613, 0);
            heff_take_n(v_x1_24613, 1ULL, 1);
            V v_t_24617;
            switch (heff_tag_of(v_i_24614)) {
            case TAG_At: {
              V v_s_24616 = heff_dup(heff_field(v_i_24614, 1));
              v_t_24617 = v_s_24616;
              break;
            }
            default: heff_nomatch(v_i_24614);
            }
            v_t_24623 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24614}), v_t_24617});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24618 = heff_field(v_x1_24613, 0);
            heff_take_n(v_x1_24613, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
            v_t_24623 = v_c_24618;
            break;
          }
          case TAG_IsType: {
            V v_t_24619 = heff_field(v_x1_24613, 0);
            heff_take_n(v_x1_24613, 1ULL, 1);
            V v_t_24622;
            switch (heff_tag_of(v_t_24619)) {
            case TAG_At: {
              V v_s_24621 = heff_dup(heff_field(v_t_24619, 1));
              v_t_24622 = v_s_24621;
              break;
            }
            default: heff_nomatch(v_t_24619);
            }
            v_t_24623 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24619}), v_t_24622});
            break;
          }
          default: heff_nomatch(v_x1_24613);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24623}), v_sp_243});
        }
        default: return heff_nomatch(v_x2121_24158);
        }
      }
      default: return heff_nomatch(v_x212_24157);
      }
    }
    case TAG_EPi: {
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24626 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24636;
      switch (heff_tag_of(v_x1_24626)) {
      case TAG_IsInferable: {
        V v_i_24627 = heff_field(v_x1_24626, 0);
        heff_take_n(v_x1_24626, 1ULL, 1);
        V v_t_24630;
        switch (heff_tag_of(v_i_24627)) {
        case TAG_At: {
          V v_s_24629 = heff_dup(heff_field(v_i_24627, 1));
          v_t_24630 = v_s_24629;
          break;
        }
        default: heff_nomatch(v_i_24627);
        }
        v_t_24636 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24627}), v_t_24630});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24631 = heff_field(v_x1_24626, 0);
        heff_take_n(v_x1_24626, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EPi, 2);
        v_t_24636 = v_c_24631;
        break;
      }
      case TAG_IsType: {
        V v_t_24632 = heff_field(v_x1_24626, 0);
        heff_take_n(v_x1_24626, 1ULL, 1);
        V v_t_24635;
        switch (heff_tag_of(v_t_24632)) {
        case TAG_At: {
          V v_s_24634 = heff_dup(heff_field(v_t_24632, 1));
          v_t_24635 = v_s_24634;
          break;
        }
        default: heff_nomatch(v_t_24632);
        }
        v_t_24636 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24632}), v_t_24635});
        break;
      }
      default: heff_nomatch(v_x1_24626);
      }
      V v_t_24639;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24638 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24639 = v_s_24638;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24636}), v_t_24639});
    }
    case TAG_ELam: {
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24642 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24652;
      switch (heff_tag_of(v_x1_24642)) {
      case TAG_IsInferable: {
        V v_i_24643 = heff_field(v_x1_24642, 0);
        heff_take_n(v_x1_24642, 1ULL, 1);
        V v_t_24646;
        switch (heff_tag_of(v_i_24643)) {
        case TAG_At: {
          V v_s_24645 = heff_dup(heff_field(v_i_24643, 1));
          v_t_24646 = v_s_24645;
          break;
        }
        default: heff_nomatch(v_i_24643);
        }
        v_t_24652 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24643}), v_t_24646});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24647 = heff_field(v_x1_24642, 0);
        heff_take_n(v_x1_24642, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        v_t_24652 = v_c_24647;
        break;
      }
      case TAG_IsType: {
        V v_t_24648 = heff_field(v_x1_24642, 0);
        heff_take_n(v_x1_24642, 1ULL, 1);
        V v_t_24651;
        switch (heff_tag_of(v_t_24648)) {
        case TAG_At: {
          V v_s_24650 = heff_dup(heff_field(v_t_24648, 1));
          v_t_24651 = v_s_24650;
          break;
        }
        default: heff_nomatch(v_t_24648);
        }
        v_t_24652 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24648}), v_t_24651});
        break;
      }
      default: heff_nomatch(v_x1_24642);
      }
      V v_t_24655;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24654 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24655 = v_s_24654;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24652}), v_t_24655});
    }
    case TAG_EAnn: {
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24658 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24668;
      switch (heff_tag_of(v_x1_24658)) {
      case TAG_IsInferable: {
        V v_i_24659 = heff_field(v_x1_24658, 0);
        heff_take_n(v_x1_24658, 1ULL, 1);
        V v_t_24662;
        switch (heff_tag_of(v_i_24659)) {
        case TAG_At: {
          V v_s_24661 = heff_dup(heff_field(v_i_24659, 1));
          v_t_24662 = v_s_24661;
          break;
        }
        default: heff_nomatch(v_i_24659);
        }
        v_t_24668 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24659}), v_t_24662});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24663 = heff_field(v_x1_24658, 0);
        heff_take_n(v_x1_24658, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24668 = v_c_24663;
        break;
      }
      case TAG_IsType: {
        V v_t_24664 = heff_field(v_x1_24658, 0);
        heff_take_n(v_x1_24658, 1ULL, 1);
        V v_t_24667;
        switch (heff_tag_of(v_t_24664)) {
        case TAG_At: {
          V v_s_24666 = heff_dup(heff_field(v_t_24664, 1));
          v_t_24667 = v_s_24666;
          break;
        }
        default: heff_nomatch(v_t_24664);
        }
        v_t_24668 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24664}), v_t_24667});
        break;
      }
      default: heff_nomatch(v_x1_24658);
      }
      V v_t_24671;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24670 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24671 = v_s_24670;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24668}), v_t_24671});
    }
    case TAG_ESpec: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_24676 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24686;
      switch (heff_tag_of(v_x1_24676)) {
      case TAG_IsInferable: {
        V v_i_24677 = heff_field(v_x1_24676, 0);
        V v_ru_24x1_24676_24IsInferable = heff_take_reuse_n(v_x1_24676, 1ULL, 1);
        V v_t_24680;
        switch (heff_tag_of(v_i_24677)) {
        case TAG_At: {
          V v_s_24679 = heff_dup(heff_field(v_i_24677, 1));
          v_t_24680 = v_s_24679;
          break;
        }
        default: heff_nomatch(v_i_24677);
        }
        v_t_24686 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24676_24IsInferable, TAG_CInf, 1, (V[]){v_i_24677}), v_t_24680});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24681 = heff_field(v_x1_24676, 0);
        heff_take_n(v_x1_24676, 1ULL, 1);
        v_t_24686 = v_c_24681;
        break;
      }
      case TAG_IsType: {
        V v_t_24682 = heff_field(v_x1_24676, 0);
        V v_ru_24x1_24676_24IsType = heff_take_reuse_n(v_x1_24676, 1ULL, 1);
        V v_t_24685;
        switch (heff_tag_of(v_t_24682)) {
        case TAG_At: {
          V v_s_24684 = heff_dup(heff_field(v_t_24682, 1));
          v_t_24685 = v_s_24684;
          break;
        }
        default: heff_nomatch(v_t_24682);
        }
        v_t_24686 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24676_24IsType, TAG_CType, 1, (V[]){v_t_24682}), v_t_24685});
        break;
      }
      default: heff_nomatch(v_x1_24676);
      }
      V v_t_24689;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24688 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24689 = v_s_24688;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24686}), v_t_24689});
    }
    case TAG_ESig: {
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24691 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24701;
      switch (heff_tag_of(v_x1_24691)) {
      case TAG_IsInferable: {
        V v_i_24692 = heff_field(v_x1_24691, 0);
        heff_take_n(v_x1_24691, 1ULL, 1);
        V v_t_24695;
        switch (heff_tag_of(v_i_24692)) {
        case TAG_At: {
          V v_s_24694 = heff_dup(heff_field(v_i_24692, 1));
          v_t_24695 = v_s_24694;
          break;
        }
        default: heff_nomatch(v_i_24692);
        }
        v_t_24701 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CInf, 1, (V[]){v_i_24692}), v_t_24695});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24696 = heff_field(v_x1_24691, 0);
        heff_take_n(v_x1_24691, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESig, 1);
        v_t_24701 = v_c_24696;
        break;
      }
      case TAG_IsType: {
        V v_t_24697 = heff_field(v_x1_24691, 0);
        heff_take_n(v_x1_24691, 1ULL, 1);
        V v_t_24700;
        switch (heff_tag_of(v_t_24697)) {
        case TAG_At: {
          V v_s_24699 = heff_dup(heff_field(v_t_24697, 1));
          v_t_24700 = v_s_24699;
          break;
        }
        default: heff_nomatch(v_t_24697);
        }
        v_t_24701 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CType, 1, (V[]){v_t_24697}), v_t_24700});
        break;
      }
      default: heff_nomatch(v_x1_24691);
      }
      V v_t_24704;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24703 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24704 = v_s_24703;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24701}), v_t_24704});
    }
    case TAG_ESum: {
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24706 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24716;
      switch (heff_tag_of(v_x1_24706)) {
      case TAG_IsInferable: {
        V v_i_24707 = heff_field(v_x1_24706, 0);
        heff_take_n(v_x1_24706, 1ULL, 1);
        V v_t_24710;
        switch (heff_tag_of(v_i_24707)) {
        case TAG_At: {
          V v_s_24709 = heff_dup(heff_field(v_i_24707, 1));
          v_t_24710 = v_s_24709;
          break;
        }
        default: heff_nomatch(v_i_24707);
        }
        v_t_24716 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CInf, 1, (V[]){v_i_24707}), v_t_24710});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24711 = heff_field(v_x1_24706, 0);
        heff_take_n(v_x1_24706, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESum, 1);
        v_t_24716 = v_c_24711;
        break;
      }
      case TAG_IsType: {
        V v_t_24712 = heff_field(v_x1_24706, 0);
        heff_take_n(v_x1_24706, 1ULL, 1);
        V v_t_24715;
        switch (heff_tag_of(v_t_24712)) {
        case TAG_At: {
          V v_s_24714 = heff_dup(heff_field(v_t_24712, 1));
          v_t_24715 = v_s_24714;
          break;
        }
        default: heff_nomatch(v_t_24712);
        }
        v_t_24716 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CType, 1, (V[]){v_t_24712}), v_t_24715});
        break;
      }
      default: heff_nomatch(v_x1_24706);
      }
      V v_t_24719;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24718 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24719 = v_s_24718;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24716}), v_t_24719});
    }
    case TAG_EStruct: {
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24721 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24731;
      switch (heff_tag_of(v_x1_24721)) {
      case TAG_IsInferable: {
        V v_i_24722 = heff_field(v_x1_24721, 0);
        heff_take_n(v_x1_24721, 1ULL, 1);
        V v_t_24725;
        switch (heff_tag_of(v_i_24722)) {
        case TAG_At: {
          V v_s_24724 = heff_dup(heff_field(v_i_24722, 1));
          v_t_24725 = v_s_24724;
          break;
        }
        default: heff_nomatch(v_i_24722);
        }
        v_t_24731 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CInf, 1, (V[]){v_i_24722}), v_t_24725});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24726 = heff_field(v_x1_24721, 0);
        heff_take_n(v_x1_24721, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EStruct, 1);
        v_t_24731 = v_c_24726;
        break;
      }
      case TAG_IsType: {
        V v_t_24727 = heff_field(v_x1_24721, 0);
        heff_take_n(v_x1_24721, 1ULL, 1);
        V v_t_24730;
        switch (heff_tag_of(v_t_24727)) {
        case TAG_At: {
          V v_s_24729 = heff_dup(heff_field(v_t_24727, 1));
          v_t_24730 = v_s_24729;
          break;
        }
        default: heff_nomatch(v_t_24727);
        }
        v_t_24731 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CType, 1, (V[]){v_t_24727}), v_t_24730});
        break;
      }
      default: heff_nomatch(v_x1_24721);
      }
      V v_t_24734;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24733 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24734 = v_s_24733;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24731}), v_t_24734});
    }
    case TAG_EUpdate: {
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24737 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24747;
      switch (heff_tag_of(v_x1_24737)) {
      case TAG_IsInferable: {
        V v_i_24738 = heff_field(v_x1_24737, 0);
        heff_take_n(v_x1_24737, 1ULL, 1);
        V v_t_24741;
        switch (heff_tag_of(v_i_24738)) {
        case TAG_At: {
          V v_s_24740 = heff_dup(heff_field(v_i_24738, 1));
          v_t_24741 = v_s_24740;
          break;
        }
        default: heff_nomatch(v_i_24738);
        }
        v_t_24747 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24738}), v_t_24741});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24742 = heff_field(v_x1_24737, 0);
        heff_take_n(v_x1_24737, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EUpdate, 2);
        v_t_24747 = v_c_24742;
        break;
      }
      case TAG_IsType: {
        V v_t_24743 = heff_field(v_x1_24737, 0);
        heff_take_n(v_x1_24737, 1ULL, 1);
        V v_t_24746;
        switch (heff_tag_of(v_t_24743)) {
        case TAG_At: {
          V v_s_24745 = heff_dup(heff_field(v_t_24743, 1));
          v_t_24746 = v_s_24745;
          break;
        }
        default: heff_nomatch(v_t_24743);
        }
        v_t_24747 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24743}), v_t_24746});
        break;
      }
      default: heff_nomatch(v_x1_24737);
      }
      V v_t_24750;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24749 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24750 = v_s_24749;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24747}), v_t_24750});
    }
    case TAG_EMatch: {
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24753 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24763;
      switch (heff_tag_of(v_x1_24753)) {
      case TAG_IsInferable: {
        V v_i_24754 = heff_field(v_x1_24753, 0);
        heff_take_n(v_x1_24753, 1ULL, 1);
        V v_t_24757;
        switch (heff_tag_of(v_i_24754)) {
        case TAG_At: {
          V v_s_24756 = heff_dup(heff_field(v_i_24754, 1));
          v_t_24757 = v_s_24756;
          break;
        }
        default: heff_nomatch(v_i_24754);
        }
        v_t_24763 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24754}), v_t_24757});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24758 = heff_field(v_x1_24753, 0);
        heff_take_n(v_x1_24753, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EMatch, 2);
        v_t_24763 = v_c_24758;
        break;
      }
      case TAG_IsType: {
        V v_t_24759 = heff_field(v_x1_24753, 0);
        heff_take_n(v_x1_24753, 1ULL, 1);
        V v_t_24762;
        switch (heff_tag_of(v_t_24759)) {
        case TAG_At: {
          V v_s_24761 = heff_dup(heff_field(v_t_24759, 1));
          v_t_24762 = v_s_24761;
          break;
        }
        default: heff_nomatch(v_t_24759);
        }
        v_t_24763 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24759}), v_t_24762});
        break;
      }
      default: heff_nomatch(v_x1_24753);
      }
      V v_t_24766;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24765 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24766 = v_s_24765;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24763}), v_t_24766});
    }
    case TAG_ELetIn: {
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24769 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24779;
      switch (heff_tag_of(v_x1_24769)) {
      case TAG_IsInferable: {
        V v_i_24770 = heff_field(v_x1_24769, 0);
        heff_take_n(v_x1_24769, 1ULL, 1);
        V v_t_24773;
        switch (heff_tag_of(v_i_24770)) {
        case TAG_At: {
          V v_s_24772 = heff_dup(heff_field(v_i_24770, 1));
          v_t_24773 = v_s_24772;
          break;
        }
        default: heff_nomatch(v_i_24770);
        }
        v_t_24779 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24770}), v_t_24773});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24774 = heff_field(v_x1_24769, 0);
        heff_take_n(v_x1_24769, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELetIn, 2);
        v_t_24779 = v_c_24774;
        break;
      }
      case TAG_IsType: {
        V v_t_24775 = heff_field(v_x1_24769, 0);
        heff_take_n(v_x1_24769, 1ULL, 1);
        V v_t_24778;
        switch (heff_tag_of(v_t_24775)) {
        case TAG_At: {
          V v_s_24777 = heff_dup(heff_field(v_t_24775, 1));
          v_t_24778 = v_s_24777;
          break;
        }
        default: heff_nomatch(v_t_24775);
        }
        v_t_24779 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24775}), v_t_24778});
        break;
      }
      default: heff_nomatch(v_x1_24769);
      }
      V v_t_24782;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24781 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24782 = v_s_24781;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24779}), v_t_24782});
    }
    case TAG_EDo: {
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24784 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24794;
      switch (heff_tag_of(v_x1_24784)) {
      case TAG_IsInferable: {
        V v_i_24785 = heff_field(v_x1_24784, 0);
        heff_take_n(v_x1_24784, 1ULL, 1);
        V v_t_24788;
        switch (heff_tag_of(v_i_24785)) {
        case TAG_At: {
          V v_s_24787 = heff_dup(heff_field(v_i_24785, 1));
          v_t_24788 = v_s_24787;
          break;
        }
        default: heff_nomatch(v_i_24785);
        }
        v_t_24794 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CInf, 1, (V[]){v_i_24785}), v_t_24788});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24789 = heff_field(v_x1_24784, 0);
        heff_take_n(v_x1_24784, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EDo, 1);
        v_t_24794 = v_c_24789;
        break;
      }
      case TAG_IsType: {
        V v_t_24790 = heff_field(v_x1_24784, 0);
        heff_take_n(v_x1_24784, 1ULL, 1);
        V v_t_24793;
        switch (heff_tag_of(v_t_24790)) {
        case TAG_At: {
          V v_s_24792 = heff_dup(heff_field(v_t_24790, 1));
          v_t_24793 = v_s_24792;
          break;
        }
        default: heff_nomatch(v_t_24790);
        }
        v_t_24794 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CType, 1, (V[]){v_t_24790}), v_t_24793});
        break;
      }
      default: heff_nomatch(v_x1_24784);
      }
      V v_t_24797;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24796 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24797 = v_s_24796;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24794}), v_t_24797});
    }
    case TAG_ELocal: {
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24800 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24810;
      switch (heff_tag_of(v_x1_24800)) {
      case TAG_IsInferable: {
        V v_i_24801 = heff_field(v_x1_24800, 0);
        heff_take_n(v_x1_24800, 1ULL, 1);
        V v_t_24804;
        switch (heff_tag_of(v_i_24801)) {
        case TAG_At: {
          V v_s_24803 = heff_dup(heff_field(v_i_24801, 1));
          v_t_24804 = v_s_24803;
          break;
        }
        default: heff_nomatch(v_i_24801);
        }
        v_t_24810 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24801}), v_t_24804});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24805 = heff_field(v_x1_24800, 0);
        heff_take_n(v_x1_24800, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELocal, 2);
        v_t_24810 = v_c_24805;
        break;
      }
      case TAG_IsType: {
        V v_t_24806 = heff_field(v_x1_24800, 0);
        heff_take_n(v_x1_24800, 1ULL, 1);
        V v_t_24809;
        switch (heff_tag_of(v_t_24806)) {
        case TAG_At: {
          V v_s_24808 = heff_dup(heff_field(v_t_24806, 1));
          v_t_24809 = v_s_24808;
          break;
        }
        default: heff_nomatch(v_t_24806);
        }
        v_t_24810 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24806}), v_t_24809});
        break;
      }
      default: heff_nomatch(v_x1_24800);
      }
      V v_t_24813;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24812 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24813 = v_s_24812;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24810}), v_t_24813});
    }
    case TAG_EInvalid: {
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24815 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24825;
      switch (heff_tag_of(v_x1_24815)) {
      case TAG_IsInferable: {
        V v_i_24816 = heff_field(v_x1_24815, 0);
        heff_take_n(v_x1_24815, 1ULL, 1);
        V v_t_24819;
        switch (heff_tag_of(v_i_24816)) {
        case TAG_At: {
          V v_s_24818 = heff_dup(heff_field(v_i_24816, 1));
          v_t_24819 = v_s_24818;
          break;
        }
        default: heff_nomatch(v_i_24816);
        }
        v_t_24825 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CInf, 1, (V[]){v_i_24816}), v_t_24819});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24820 = heff_field(v_x1_24815, 0);
        heff_take_n(v_x1_24815, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInvalid, 1);
        v_t_24825 = v_c_24820;
        break;
      }
      case TAG_IsType: {
        V v_t_24821 = heff_field(v_x1_24815, 0);
        heff_take_n(v_x1_24815, 1ULL, 1);
        V v_t_24824;
        switch (heff_tag_of(v_t_24821)) {
        case TAG_At: {
          V v_s_24823 = heff_dup(heff_field(v_t_24821, 1));
          v_t_24824 = v_s_24823;
          break;
        }
        default: heff_nomatch(v_t_24821);
        }
        v_t_24825 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CType, 1, (V[]){v_t_24821}), v_t_24824});
        break;
      }
      default: heff_nomatch(v_x1_24815);
      }
      V v_t_24828;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24827 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24828 = v_s_24827;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24825}), v_t_24828});
    }
    case TAG_EAssign: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_x1_24832 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24842;
      switch (heff_tag_of(v_x1_24832)) {
      case TAG_IsInferable: {
        V v_i_24833 = heff_field(v_x1_24832, 0);
        V v_ru_24x1_24832_24IsInferable = heff_take_reuse_n(v_x1_24832, 1ULL, 1);
        V v_t_24836;
        switch (heff_tag_of(v_i_24833)) {
        case TAG_At: {
          V v_s_24835 = heff_dup(heff_field(v_i_24833, 1));
          v_t_24836 = v_s_24835;
          break;
        }
        default: heff_nomatch(v_i_24833);
        }
        v_t_24842 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24832_24IsInferable, TAG_CInf, 1, (V[]){v_i_24833}), v_t_24836});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24837 = heff_field(v_x1_24832, 0);
        heff_take_n(v_x1_24832, 1ULL, 1);
        v_t_24842 = v_c_24837;
        break;
      }
      case TAG_IsType: {
        V v_t_24838 = heff_field(v_x1_24832, 0);
        V v_ru_24x1_24832_24IsType = heff_take_reuse_n(v_x1_24832, 1ULL, 1);
        V v_t_24841;
        switch (heff_tag_of(v_t_24838)) {
        case TAG_At: {
          V v_s_24840 = heff_dup(heff_field(v_t_24838, 1));
          v_t_24841 = v_s_24840;
          break;
        }
        default: heff_nomatch(v_t_24838);
        }
        v_t_24842 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24832_24IsType, TAG_CType, 1, (V[]){v_t_24838}), v_t_24841});
        break;
      }
      default: heff_nomatch(v_x1_24832);
      }
      V v_t_24845;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24844 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24845 = v_s_24844;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24842}), v_t_24845});
    }
    case TAG_EWhile: {
      V v_ru_24x21_242_24EWhile = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24848 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24858;
      switch (heff_tag_of(v_x1_24848)) {
      case TAG_IsInferable: {
        V v_i_24849 = heff_field(v_x1_24848, 0);
        heff_take_n(v_x1_24848, 1ULL, 1);
        V v_t_24852;
        switch (heff_tag_of(v_i_24849)) {
        case TAG_At: {
          V v_s_24851 = heff_dup(heff_field(v_i_24849, 1));
          v_t_24852 = v_s_24851;
          break;
        }
        default: heff_nomatch(v_i_24849);
        }
        v_t_24858 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24849}), v_t_24852});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24853 = heff_field(v_x1_24848, 0);
        heff_take_n(v_x1_24848, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EWhile, 2);
        v_t_24858 = v_c_24853;
        break;
      }
      case TAG_IsType: {
        V v_t_24854 = heff_field(v_x1_24848, 0);
        heff_take_n(v_x1_24848, 1ULL, 1);
        V v_t_24857;
        switch (heff_tag_of(v_t_24854)) {
        case TAG_At: {
          V v_s_24856 = heff_dup(heff_field(v_t_24854, 1));
          v_t_24857 = v_s_24856;
          break;
        }
        default: heff_nomatch(v_t_24854);
        }
        v_t_24858 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24854}), v_t_24857});
        break;
      }
      default: heff_nomatch(v_x1_24848);
      }
      V v_t_24861;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24860 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24861 = v_s_24860;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24858}), v_t_24861});
    }
    case TAG_EFor: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_x1_24865 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24875;
      switch (heff_tag_of(v_x1_24865)) {
      case TAG_IsInferable: {
        V v_i_24866 = heff_field(v_x1_24865, 0);
        V v_ru_24x1_24865_24IsInferable = heff_take_reuse_n(v_x1_24865, 1ULL, 1);
        V v_t_24869;
        switch (heff_tag_of(v_i_24866)) {
        case TAG_At: {
          V v_s_24868 = heff_dup(heff_field(v_i_24866, 1));
          v_t_24869 = v_s_24868;
          break;
        }
        default: heff_nomatch(v_i_24866);
        }
        v_t_24875 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24865_24IsInferable, TAG_CInf, 1, (V[]){v_i_24866}), v_t_24869});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24870 = heff_field(v_x1_24865, 0);
        heff_take_n(v_x1_24865, 1ULL, 1);
        v_t_24875 = v_c_24870;
        break;
      }
      case TAG_IsType: {
        V v_t_24871 = heff_field(v_x1_24865, 0);
        V v_ru_24x1_24865_24IsType = heff_take_reuse_n(v_x1_24865, 1ULL, 1);
        V v_t_24874;
        switch (heff_tag_of(v_t_24871)) {
        case TAG_At: {
          V v_s_24873 = heff_dup(heff_field(v_t_24871, 1));
          v_t_24874 = v_s_24873;
          break;
        }
        default: heff_nomatch(v_t_24871);
        }
        v_t_24875 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24865_24IsType, TAG_CType, 1, (V[]){v_t_24871}), v_t_24874});
        break;
      }
      default: heff_nomatch(v_x1_24865);
      }
      V v_t_24878;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24877 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24878 = v_s_24877;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24875}), v_t_24878});
    }
    case TAG_EIfThen: {
      V v_ru_24x21_242_24EIfThen = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24881 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24891;
      switch (heff_tag_of(v_x1_24881)) {
      case TAG_IsInferable: {
        V v_i_24882 = heff_field(v_x1_24881, 0);
        heff_take_n(v_x1_24881, 1ULL, 1);
        V v_t_24885;
        switch (heff_tag_of(v_i_24882)) {
        case TAG_At: {
          V v_s_24884 = heff_dup(heff_field(v_i_24882, 1));
          v_t_24885 = v_s_24884;
          break;
        }
        default: heff_nomatch(v_i_24882);
        }
        v_t_24891 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24882}), v_t_24885});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24886 = heff_field(v_x1_24881, 0);
        heff_take_n(v_x1_24881, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EIfThen, 2);
        v_t_24891 = v_c_24886;
        break;
      }
      case TAG_IsType: {
        V v_t_24887 = heff_field(v_x1_24881, 0);
        heff_take_n(v_x1_24881, 1ULL, 1);
        V v_t_24890;
        switch (heff_tag_of(v_t_24887)) {
        case TAG_At: {
          V v_s_24889 = heff_dup(heff_field(v_t_24887, 1));
          v_t_24890 = v_s_24889;
          break;
        }
        default: heff_nomatch(v_t_24887);
        }
        v_t_24891 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24887}), v_t_24890});
        break;
      }
      default: heff_nomatch(v_x1_24881);
      }
      V v_t_24894;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24893 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24894 = v_s_24893;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24891}), v_t_24894});
    }
    case TAG_EBreak: {
      heff_drop(v_sp_243);
      V v_x1_24895 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24905;
      switch (heff_tag_of(v_x1_24895)) {
      case TAG_IsInferable: {
        V v_i_24896 = heff_field(v_x1_24895, 0);
        V v_ru_24x1_24895_24IsInferable = heff_take_reuse_n(v_x1_24895, 1ULL, 1);
        V v_t_24899;
        switch (heff_tag_of(v_i_24896)) {
        case TAG_At: {
          V v_s_24898 = heff_dup(heff_field(v_i_24896, 1));
          v_t_24899 = v_s_24898;
          break;
        }
        default: heff_nomatch(v_i_24896);
        }
        v_t_24905 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24895_24IsInferable, TAG_CInf, 1, (V[]){v_i_24896}), v_t_24899});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24900 = heff_field(v_x1_24895, 0);
        heff_take_n(v_x1_24895, 1ULL, 1);
        v_t_24905 = v_c_24900;
        break;
      }
      case TAG_IsType: {
        V v_t_24901 = heff_field(v_x1_24895, 0);
        V v_ru_24x1_24895_24IsType = heff_take_reuse_n(v_x1_24895, 1ULL, 1);
        V v_t_24904;
        switch (heff_tag_of(v_t_24901)) {
        case TAG_At: {
          V v_s_24903 = heff_dup(heff_field(v_t_24901, 1));
          v_t_24904 = v_s_24903;
          break;
        }
        default: heff_nomatch(v_t_24901);
        }
        v_t_24905 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24895_24IsType, TAG_CType, 1, (V[]){v_t_24901}), v_t_24904});
        break;
      }
      default: heff_nomatch(v_x1_24895);
      }
      V v_t_24908;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24907 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24908 = v_s_24907;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24905}), v_t_24908});
    }
    case TAG_EContinue: {
      heff_drop(v_sp_243);
      V v_x1_24909 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24919;
      switch (heff_tag_of(v_x1_24909)) {
      case TAG_IsInferable: {
        V v_i_24910 = heff_field(v_x1_24909, 0);
        V v_ru_24x1_24909_24IsInferable = heff_take_reuse_n(v_x1_24909, 1ULL, 1);
        V v_t_24913;
        switch (heff_tag_of(v_i_24910)) {
        case TAG_At: {
          V v_s_24912 = heff_dup(heff_field(v_i_24910, 1));
          v_t_24913 = v_s_24912;
          break;
        }
        default: heff_nomatch(v_i_24910);
        }
        v_t_24919 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24909_24IsInferable, TAG_CInf, 1, (V[]){v_i_24910}), v_t_24913});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24914 = heff_field(v_x1_24909, 0);
        heff_take_n(v_x1_24909, 1ULL, 1);
        v_t_24919 = v_c_24914;
        break;
      }
      case TAG_IsType: {
        V v_t_24915 = heff_field(v_x1_24909, 0);
        V v_ru_24x1_24909_24IsType = heff_take_reuse_n(v_x1_24909, 1ULL, 1);
        V v_t_24918;
        switch (heff_tag_of(v_t_24915)) {
        case TAG_At: {
          V v_s_24917 = heff_dup(heff_field(v_t_24915, 1));
          v_t_24918 = v_s_24917;
          break;
        }
        default: heff_nomatch(v_t_24915);
        }
        v_t_24919 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24909_24IsType, TAG_CType, 1, (V[]){v_t_24915}), v_t_24918});
        break;
      }
      default: heff_nomatch(v_x1_24909);
      }
      V v_t_24922;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24921 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24922 = v_s_24921;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24919}), v_t_24922});
    }
    case TAG_EReturn: {
      V v_ru_24x21_242_24EReturn = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24924 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24934;
      switch (heff_tag_of(v_x1_24924)) {
      case TAG_IsInferable: {
        V v_i_24925 = heff_field(v_x1_24924, 0);
        heff_take_n(v_x1_24924, 1ULL, 1);
        V v_t_24928;
        switch (heff_tag_of(v_i_24925)) {
        case TAG_At: {
          V v_s_24927 = heff_dup(heff_field(v_i_24925, 1));
          v_t_24928 = v_s_24927;
          break;
        }
        default: heff_nomatch(v_i_24925);
        }
        v_t_24934 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_CInf, 1, (V[]){v_i_24925}), v_t_24928});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24929 = heff_field(v_x1_24924, 0);
        heff_take_n(v_x1_24924, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EReturn, 1);
        v_t_24934 = v_c_24929;
        break;
      }
      case TAG_IsType: {
        V v_t_24930 = heff_field(v_x1_24924, 0);
        heff_take_n(v_x1_24924, 1ULL, 1);
        V v_t_24933;
        switch (heff_tag_of(v_t_24930)) {
        case TAG_At: {
          V v_s_24932 = heff_dup(heff_field(v_t_24930, 1));
          v_t_24933 = v_s_24932;
          break;
        }
        default: heff_nomatch(v_t_24930);
        }
        v_t_24934 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_CType, 1, (V[]){v_t_24930}), v_t_24933});
        break;
      }
      default: heff_nomatch(v_x1_24924);
      }
      V v_t_24937;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24936 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24937 = v_s_24936;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24934}), v_t_24937});
    }
    case TAG_ENest: {
      V v_ru_24x21_242_24ENest = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24939 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24949;
      switch (heff_tag_of(v_x1_24939)) {
      case TAG_IsInferable: {
        V v_i_24940 = heff_field(v_x1_24939, 0);
        heff_take_n(v_x1_24939, 1ULL, 1);
        V v_t_24943;
        switch (heff_tag_of(v_i_24940)) {
        case TAG_At: {
          V v_s_24942 = heff_dup(heff_field(v_i_24940, 1));
          v_t_24943 = v_s_24942;
          break;
        }
        default: heff_nomatch(v_i_24940);
        }
        v_t_24949 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_CInf, 1, (V[]){v_i_24940}), v_t_24943});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24944 = heff_field(v_x1_24939, 0);
        heff_take_n(v_x1_24939, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ENest, 1);
        v_t_24949 = v_c_24944;
        break;
      }
      case TAG_IsType: {
        V v_t_24945 = heff_field(v_x1_24939, 0);
        heff_take_n(v_x1_24939, 1ULL, 1);
        V v_t_24948;
        switch (heff_tag_of(v_t_24945)) {
        case TAG_At: {
          V v_s_24947 = heff_dup(heff_field(v_t_24945, 1));
          v_t_24948 = v_s_24947;
          break;
        }
        default: heff_nomatch(v_t_24945);
        }
        v_t_24949 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_CType, 1, (V[]){v_t_24945}), v_t_24948});
        break;
      }
      default: heff_nomatch(v_x1_24939);
      }
      V v_t_24952;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24951 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24952 = v_s_24951;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24949}), v_t_24952});
    }
    case TAG_ELazy: {
      V v_ru_24x21_242_24ELazy = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24954 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24964;
      switch (heff_tag_of(v_x1_24954)) {
      case TAG_IsInferable: {
        V v_i_24955 = heff_field(v_x1_24954, 0);
        heff_take_n(v_x1_24954, 1ULL, 1);
        V v_t_24958;
        switch (heff_tag_of(v_i_24955)) {
        case TAG_At: {
          V v_s_24957 = heff_dup(heff_field(v_i_24955, 1));
          v_t_24958 = v_s_24957;
          break;
        }
        default: heff_nomatch(v_i_24955);
        }
        v_t_24964 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CInf, 1, (V[]){v_i_24955}), v_t_24958});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24959 = heff_field(v_x1_24954, 0);
        heff_take_n(v_x1_24954, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELazy, 1);
        v_t_24964 = v_c_24959;
        break;
      }
      case TAG_IsType: {
        V v_t_24960 = heff_field(v_x1_24954, 0);
        heff_take_n(v_x1_24954, 1ULL, 1);
        V v_t_24963;
        switch (heff_tag_of(v_t_24960)) {
        case TAG_At: {
          V v_s_24962 = heff_dup(heff_field(v_t_24960, 1));
          v_t_24963 = v_s_24962;
          break;
        }
        default: heff_nomatch(v_t_24960);
        }
        v_t_24964 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CType, 1, (V[]){v_t_24960}), v_t_24963});
        break;
      }
      default: heff_nomatch(v_x1_24954);
      }
      V v_t_24967;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24966 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24967 = v_s_24966;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24964}), v_t_24967});
    }
    case TAG_ETuple: {
      V v_ru_24x21_242_24ETuple = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24969 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24979;
      switch (heff_tag_of(v_x1_24969)) {
      case TAG_IsInferable: {
        V v_i_24970 = heff_field(v_x1_24969, 0);
        heff_take_n(v_x1_24969, 1ULL, 1);
        V v_t_24973;
        switch (heff_tag_of(v_i_24970)) {
        case TAG_At: {
          V v_s_24972 = heff_dup(heff_field(v_i_24970, 1));
          v_t_24973 = v_s_24972;
          break;
        }
        default: heff_nomatch(v_i_24970);
        }
        v_t_24979 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_CInf, 1, (V[]){v_i_24970}), v_t_24973});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24974 = heff_field(v_x1_24969, 0);
        heff_take_n(v_x1_24969, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETuple, 1);
        v_t_24979 = v_c_24974;
        break;
      }
      case TAG_IsType: {
        V v_t_24975 = heff_field(v_x1_24969, 0);
        heff_take_n(v_x1_24969, 1ULL, 1);
        V v_t_24978;
        switch (heff_tag_of(v_t_24975)) {
        case TAG_At: {
          V v_s_24977 = heff_dup(heff_field(v_t_24975, 1));
          v_t_24978 = v_s_24977;
          break;
        }
        default: heff_nomatch(v_t_24975);
        }
        v_t_24979 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_CType, 1, (V[]){v_t_24975}), v_t_24978});
        break;
      }
      default: heff_nomatch(v_x1_24969);
      }
      V v_t_24982;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24981 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24982 = v_s_24981;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24979}), v_t_24982});
    }
    case TAG_ETry: {
      V v_ru_24x21_242_24ETry = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24984 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24994;
      switch (heff_tag_of(v_x1_24984)) {
      case TAG_IsInferable: {
        V v_i_24985 = heff_field(v_x1_24984, 0);
        heff_take_n(v_x1_24984, 1ULL, 1);
        V v_t_24988;
        switch (heff_tag_of(v_i_24985)) {
        case TAG_At: {
          V v_s_24987 = heff_dup(heff_field(v_i_24985, 1));
          v_t_24988 = v_s_24987;
          break;
        }
        default: heff_nomatch(v_i_24985);
        }
        v_t_24994 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_CInf, 1, (V[]){v_i_24985}), v_t_24988});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24989 = heff_field(v_x1_24984, 0);
        heff_take_n(v_x1_24984, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETry, 1);
        v_t_24994 = v_c_24989;
        break;
      }
      case TAG_IsType: {
        V v_t_24990 = heff_field(v_x1_24984, 0);
        heff_take_n(v_x1_24984, 1ULL, 1);
        V v_t_24993;
        switch (heff_tag_of(v_t_24990)) {
        case TAG_At: {
          V v_s_24992 = heff_dup(heff_field(v_t_24990, 1));
          v_t_24993 = v_s_24992;
          break;
        }
        default: heff_nomatch(v_t_24990);
        }
        v_t_24994 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_CType, 1, (V[]){v_t_24990}), v_t_24993});
        break;
      }
      default: heff_nomatch(v_x1_24984);
      }
      V v_t_24997;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24996 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24997 = v_s_24996;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24994}), v_t_24997});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_241002 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_241012;
      switch (heff_tag_of(v_x1_241002)) {
      case TAG_IsInferable: {
        V v_i_241003 = heff_field(v_x1_241002, 0);
        V v_ru_24x1_241002_24IsInferable = heff_take_reuse_n(v_x1_241002, 1ULL, 1);
        V v_t_241006;
        switch (heff_tag_of(v_i_241003)) {
        case TAG_At: {
          V v_s_241005 = heff_dup(heff_field(v_i_241003, 1));
          v_t_241006 = v_s_241005;
          break;
        }
        default: heff_nomatch(v_i_241003);
        }
        v_t_241012 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_241002_24IsInferable, TAG_CInf, 1, (V[]){v_i_241003}), v_t_241006});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_241007 = heff_field(v_x1_241002, 0);
        heff_take_n(v_x1_241002, 1ULL, 1);
        v_t_241012 = v_c_241007;
        break;
      }
      case TAG_IsType: {
        V v_t_241008 = heff_field(v_x1_241002, 0);
        V v_ru_24x1_241002_24IsType = heff_take_reuse_n(v_x1_241002, 1ULL, 1);
        V v_t_241011;
        switch (heff_tag_of(v_t_241008)) {
        case TAG_At: {
          V v_s_241010 = heff_dup(heff_field(v_t_241008, 1));
          v_t_241011 = v_s_241010;
          break;
        }
        default: heff_nomatch(v_t_241008);
        }
        v_t_241012 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_241002_24IsType, TAG_CType, 1, (V[]){v_t_241008}), v_t_241011});
        break;
      }
      default: heff_nomatch(v_x1_241002);
      }
      V v_t_241015;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_241014 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_241015 = v_s_241014;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_241012}), v_t_241015});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesTerm_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesTerm(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_242}), v_sp_241});
  }
  case TAG_SizeNumber: {
    V v_n_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){heff_intDiv(v_n_243, MK_INT(8LL))});
    V v_t_245 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(8LL), 2)) {
      heff_drop(v_sp_241);
      heff_drop(v_x13_248);
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_xsp_247});
    } else {
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intDiv(v_x13_248, MK_INT(8LL))});
      V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)})});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415})));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesTerm_str0)}), heff_dup(v_sp_241)});
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_241)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_241});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesTerm(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclEquations = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2419;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_IsInferable: {
        V v_i_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_i_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_i_2410);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2410}), v_t_2413});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2414 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_c_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_c_2414);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
        break;
      }
      case TAG_IsType: {
        V v_t_2418 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2419 = v_t_2418;
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2420 = (g_list_2emap_24s1036840854x702708481(v_r_240, v_eqs_248));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_2419, v_t_2420}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_x21_242, 0);
      V v_xsp_2422 = heff_field(v_x21_242, 1);
      V v_ps_2423 = heff_field(v_x21_242, 2);
      V v_u_2424 = heff_field(v_x21_242, 3);
      V v_body_2425 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclDefine = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_t_2426 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2423));
      V v_x1_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2424}));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_IsInferable: {
        V v_i_2428 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_i_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_i_2428);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2432 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_c_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_c_2432);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
        break;
      }
      case TAG_IsType: {
        V v_t_2436 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2437 = v_t_2436;
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
      V v_x1_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2425}));
      V v_t_2448;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_IsInferable: {
        V v_i_2439 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsInferable = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_i_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_i_2439);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsInferable, TAG_CInf, 1, (V[]){v_i_2439}), v_t_2442});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2443 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2448 = v_c_2443;
        break;
      }
      case TAG_IsType: {
        V v_t_2444 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsType = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2447;
        switch (heff_tag_of(v_t_2444)) {
        case TAG_At: {
          V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
          v_t_2447 = v_s_2446;
          break;
        }
        default: heff_nomatch(v_t_2444);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsType, TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2421, v_xsp_2422, v_t_2426, v_t_2437, v_t_2448}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2449 = heff_field(v_x21_242, 0);
      V v_xsp_2450 = heff_field(v_x21_242, 1);
      V v_ps_2451 = heff_field(v_x21_242, 2);
      V v_body_2452 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclTheory = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_2453 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2451));
      V v_x1_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2452}));
      V v_t_2464;
      switch (heff_tag_of(v_x1_2454)) {
      case TAG_IsInferable: {
        V v_i_2455 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_i_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_i_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_i_2455);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2455}), v_t_2458});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2459 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2464 = v_c_2459;
        break;
      }
      case TAG_IsType: {
        V v_t_2460 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2463;
        switch (heff_tag_of(v_t_2460)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_t_2460);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
        break;
      }
      default: heff_nomatch(v_x1_2454);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2449, v_xsp_2450, v_t_2453, v_t_2464}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2465 = heff_field(v_x21_242, 0);
      V v_xsp_2466 = heff_field(v_x21_242, 1);
      V v_t_2467 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24DeclPrimitive = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2467}));
      V v_t_2478;
      switch (heff_tag_of(v_x1_2468)) {
      case TAG_IsInferable: {
        V v_i_2469 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2472;
        switch (heff_tag_of(v_i_2469)) {
        case TAG_At: {
          V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_i_2469);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2473 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2476;
        switch (heff_tag_of(v_c_2473)) {
        case TAG_At: {
          V v_s_2475 = heff_dup(heff_field(v_c_2473, 1));
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_c_2473);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2473}), v_t_2476});
        break;
      }
      case TAG_IsType: {
        V v_t_2477 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2478 = v_t_2477;
        break;
      }
      default: heff_nomatch(v_x1_2468);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2465, v_xsp_2466, v_t_2478}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2479 = heff_field(v_x21_242, 0);
      V v_xsp_2480 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_rec(v_r_240, 2);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2479, v_xsp_2480}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2481 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2481}));
      V v_t_2483 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2482));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_2483}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2427;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            v_t_2427 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2419 = v_field_2415;
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = v_field_2415;
              V v_t_2426;
              switch (heff_tag_of(v_t_2423)) {
              case TAG_At: {
                V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
                v_t_2426 = v_s_2425;
                break;
              }
              default: heff_nomatch(v_t_2423);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
            }
          }
        }
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2428});
        V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2429});
        V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2430));
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0)}), heff_dup(v_sp_242)});
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2431}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2436 = v_t_2434.f[1];
            int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
            if ((v_tag_2435 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2438 = v_field_2436;
              return v_c_2438;
            } else {
              if ((v_tag_2435 == ((int64_t)1ULL))) {
                V v_i_2440 = v_field_2436;
                V v_t_2443;
                switch (heff_tag_of(v_i_2440)) {
                case TAG_At: {
                  V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
                  v_t_2443 = v_s_2442;
                  break;
                }
                default: heff_nomatch(v_i_2440);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
              } else {
                V v_t_2444 = v_field_2436;
                V v_t_2447;
                switch (heff_tag_of(v_t_2444)) {
                case TAG_At: {
                  V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
                  v_t_2447 = v_s_2446;
                  break;
                }
                default: heff_nomatch(v_t_2444);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2449 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2464;
          {
            V v_field_2452 = v_t_2450.f[1];
            int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
            if ((v_tag_2451 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2454 = v_field_2452;
              v_t_2464 = v_c_2454;
            } else {
              if ((v_tag_2451 == ((int64_t)1ULL))) {
                V v_i_2456 = v_field_2452;
                V v_t_2459;
                switch (heff_tag_of(v_i_2456)) {
                case TAG_At: {
                  V v_s_2458 = heff_dup(heff_field(v_i_2456, 1));
                  v_t_2459 = v_s_2458;
                  break;
                }
                default: heff_nomatch(v_i_2456);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2456}), v_t_2459});
              } else {
                V v_t_2460 = v_field_2452;
                V v_t_2463;
                switch (heff_tag_of(v_t_2460)) {
                case TAG_At: {
                  V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
                  v_t_2463 = v_s_2462;
                  break;
                }
                default: heff_nomatch(v_t_2460);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
              }
            }
          }
          V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
          V v_args_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2465});
          V v_t_2467 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2466));
          V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1)}), heff_dup(v_sp_242)});
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2468, v_t_2467}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2469}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2473 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2474 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2488;
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            if ((v_tag_2475 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2478 = v_field_2476;
              v_t_2488 = v_c_2478;
            } else {
              if ((v_tag_2475 == ((int64_t)1ULL))) {
                V v_i_2480 = v_field_2476;
                V v_t_2483;
                switch (heff_tag_of(v_i_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_i_2480);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
              } else {
                V v_t_2484 = v_field_2476;
                V v_t_2487;
                switch (heff_tag_of(v_t_2484)) {
                case TAG_At: {
                  V v_s_2486 = heff_dup(heff_field(v_t_2484, 1));
                  v_t_2487 = v_s_2486;
                  break;
                }
                default: heff_nomatch(v_t_2484);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2484}), v_t_2487});
              }
            }
          }
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, NTAG(TAG_Nil)});
          V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2489});
          V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2490));
          V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2)}), heff_dup(v_sp_242)});
          V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT2 v_t_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24108;
        {
          V v_field_2496 = v_t_2494.f[1];
          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
          if ((v_tag_2495 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2498 = v_field_2496;
            v_t_24108 = v_c_2498;
          } else {
            if ((v_tag_2495 == ((int64_t)1ULL))) {
              V v_i_24100 = v_field_2496;
              V v_t_24103;
              switch (heff_tag_of(v_i_24100)) {
              case TAG_At: {
                V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
                v_t_24103 = v_s_24102;
                break;
              }
              default: heff_nomatch(v_i_24100);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
            } else {
              V v_t_24104 = v_field_2496;
              V v_t_24107;
              switch (heff_tag_of(v_t_24104)) {
              case TAG_At: {
                V v_s_24106 = heff_dup(heff_field(v_t_24104, 1));
                v_t_24107 = v_s_24106;
                break;
              }
              default: heff_nomatch(v_t_24104);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24104}), v_t_24107});
            }
          }
        }
        V v_args_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, NTAG(TAG_Nil)});
        V v_t_24110 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24109));
        V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3)}), heff_dup(v_sp_242)});
        V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24110}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24112}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24113 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24114;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)0ULL);
        }
        V v_t_24115 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24114 + ((int64_t)0ULL)))});
        V v_t_24116 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24115, heff_dup(v_sp_242)})});
        V v_t_24117 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT2 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24132;
        {
          V v_field_24120 = v_t_24118.f[1];
          int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
          if ((v_tag_24119 == ((int64_t)0ULL))) {
            V v_c_24122 = v_field_24120;
            v_t_24132 = v_c_24122;
          } else {
            if ((v_tag_24119 == ((int64_t)1ULL))) {
              V v_i_24124 = v_field_24120;
              V v_t_24127;
              switch (heff_tag_of(v_i_24124)) {
              case TAG_At: {
                V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
                v_t_24127 = v_s_24126;
                break;
              }
              default: heff_nomatch(v_i_24124);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
            } else {
              V v_t_24128 = v_field_24120;
              V v_t_24131;
              switch (heff_tag_of(v_t_24128)) {
              case TAG_At: {
                V v_s_24130 = heff_dup(heff_field(v_t_24128, 1));
                v_t_24131 = v_s_24130;
                break;
              }
              default: heff_nomatch(v_t_24128);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24128}), v_t_24131});
            }
          }
        }
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
        V v_args_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_t_24133});
        V v_t_24135 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24134));
        V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4)}), heff_dup(v_sp_242)});
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24136, v_t_24135}), heff_dup(v_sp_242)});
        V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24137}), heff_dup(v_sp_242)});
        V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
        V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24116, heff_dup(v_sp_242)}), v_t_24139});
        V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_t_24140});
        V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
        V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5)}), heff_dup(v_sp_242)});
        V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24145 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24145, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24145);
          V v_t_24147 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24148 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24147, NTAG(TAG_Nil)});
          V v_t_24149 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24148));
          V v_t_24150 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6)}), heff_dup(v_sp_242)});
          V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24150, v_t_24149}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24151}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24145, MK_INT(16LL))) {
            int64_t v_t_24153;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)0ULL);
            }
            V v_t_24154 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24153 + ((int64_t)0ULL)))});
            V v_t_24155 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24154, heff_dup(v_sp_242)})});
            V v_t_24156 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24156, NTAG(TAG_Nil)});
            V v_args_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24155, heff_dup(v_sp_242)}), v_t_24157});
            V v_t_24159 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24158));
            V v_t_24160 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7)}), heff_dup(v_sp_242)});
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24160, v_t_24159}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24161}), v_sp_242});
          } else {
            int64_t v_t_24162;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)0ULL);
            }
            V v_t_24163 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24162 + ((int64_t)0ULL)))});
            V v_t_24164 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24163, heff_dup(v_sp_242)})});
            V v_t_24165 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
            V v_args_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24164, heff_dup(v_sp_242)}), v_t_24166});
            V v_t_24168 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24167));
            V v_t_24169 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8)}), heff_dup(v_sp_242)});
            V v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24169, v_t_24168}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24170}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
      v_t_245 = heff_tag_at_n(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at_n(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      heff_take_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2438 = (g_list_2emap_24s79542405x478516404(v_args_2437));
    return heff_tag_at_n(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, v_t_2438});
  }
  case TAG_CStruct: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1729787689x465380098(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){v_t_2440});
  }
  case TAG_CMatch: {
    V v_sc_2441 = heff_field(v_n_240, 0);
    V v_alts_2442 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_sc_2441)) {
    case TAG_At: {
      V v_n_2443 = heff_field(v_sc_2441, 0);
      V v_sp_2444 = heff_field(v_sc_2441, 1);
      V v_ru_24sc_2441_24At = heff_take_reuse_n(v_sc_2441, 3ULL, 2);
      V v_t_2445 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2443));
      v_t_2446 = heff_tag_at_n(v_ru_24sc_2441_24At, TAG_At, 2, (V[]){v_t_2445, v_sp_2444});
      break;
    }
    default: heff_nomatch(v_sc_2441);
    }
    V v_t_2447 = (g_list_2emap_24s244350250x1728178626(v_alts_2442));
    return heff_tag_at_n(v_ru_24n_240_24CMatch, TAG_CMatch, 2, (V[]){v_t_2446, v_t_2447});
  }
  case TAG_CLetIn: {
    V v_rhs_2448 = heff_field(v_n_240, 0);
    V v_alt_2449 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2453;
    switch (heff_tag_of(v_rhs_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_rhs_2448, 0);
      V v_sp_2451 = heff_field(v_rhs_2448, 1);
      V v_ru_24rhs_2448_24At = heff_take_reuse_n(v_rhs_2448, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24rhs_2448_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_rhs_2448);
    }
    V v_t_2463;
    switch (heff_tag_of(v_alt_2449)) {
    case TAG_At: {
      V v_x_2454 = heff_field(v_alt_2449, 0);
      V v_sp_2455 = heff_field(v_alt_2449, 1);
      V v_ru_24alt_2449_24At = heff_take_reuse_n(v_alt_2449, 3ULL, 2);
      V v_t_2462;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_MkAlt: {
        V v_p_2456 = heff_field(v_x_2454, 0);
        V v_b_2457 = heff_field(v_x_2454, 1);
        V v_ru_24x_2454_24MkAlt = heff_take_reuse_n(v_x_2454, 3ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_b_2457)) {
        case TAG_At: {
          V v_n_2458 = heff_field(v_b_2457, 0);
          V v_sp_2459 = heff_field(v_b_2457, 1);
          heff_take_n(v_b_2457, 3ULL, 2);
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2458));
          v_t_2461 = heff_tag_at_n(v_ru_24alt_2449_24At, TAG_At, 2, (V[]){v_t_2460, v_sp_2459});
          break;
        }
        default: heff_nomatch(v_b_2457);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x_2454_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2456, v_t_2461});
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_alt_2449);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2453, v_t_2463});
  }
  case TAG_CLocal: {
    V v_body_2464 = heff_field(v_n_240, 0);
    V v_ds_2465 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_body_2464)) {
    case TAG_At: {
      V v_n_2466 = heff_field(v_body_2464, 0);
      V v_sp_2467 = heff_field(v_body_2464, 1);
      V v_ru_24body_2464_24At = heff_take_reuse_n(v_body_2464, 3ULL, 2);
      V v_t_2468 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2466));
      v_t_2469 = heff_tag_at_n(v_ru_24body_2464_24At, TAG_At, 2, (V[]){v_t_2468, v_sp_2467});
      break;
    }
    default: heff_nomatch(v_body_2464);
    }
    V v_t_2470 = (g_list_2emap_24s386875578x1005587669(v_ds_2465));
    return heff_tag_at_n(v_ru_24n_240_24CLocal, TAG_CLocal, 2, (V[]){v_t_2469, v_t_2470});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eevidenceCandidate_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eevidenceCandidate(V v_sp_240, V v_path_241, V v_w_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240(heff_dup(v_sp_240)));
  V v_t_244 = (g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(v_w_242, heff_dup(v_sp_240), v_path_241));
  V v_t_245 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_243, heff_dup(v_sp_240)}), v_t_244});
  V v_e_246 = heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2411 = v_field_249;
      switch (heff_tag_of(v_c_2411)) {
      case TAG_At: {
        V v_n_2412 = heff_field(v_c_2411, 0);
        V v_sp_2413 = heff_field(v_c_2411, 1);
        V v_ru_24c_2411_24At = heff_take_reuse_n(v_c_2411, 3ULL, 2);
        V v_t_2414 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2412));
        return heff_tag_at_n(v_ru_24c_2411_24At, TAG_At, 2, (V[]){v_t_2414, v_sp_2413});
      }
      default: return heff_nomatch(v_c_2411);
      }
    } else {
      if ((v_tag_248 == ((int64_t)1ULL))) {
        V v_i_2416 = v_field_249;
        V v_t_2417 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(heff_tag_n(TAG_CInf, 1, (V[]){heff_dup(v_i_2416)})));
        V v_t_2420;
        switch (heff_tag_of(v_i_2416)) {
        case TAG_At: {
          V v_s_2419 = heff_field(v_i_2416, 1);
          heff_take_n(v_i_2416, 2ULL, 2);
          v_t_2420 = v_s_2419;
          break;
        }
        default: heff_nomatch(v_i_2416);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2420});
      } else {
        V v_t_2421 = v_field_249;
        V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(heff_tag_n(TAG_CType, 1, (V[]){heff_dup(v_t_2421)})));
        V v_t_2425;
        switch (heff_tag_of(v_t_2421)) {
        case TAG_At: {
          V v_s_2424 = heff_field(v_t_2421, 1);
          heff_take_n(v_t_2421, 2ULL, 2);
          v_t_2425 = v_s_2424;
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2425});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eevidenceCandidate(a[0], a[1], a[2]);
}