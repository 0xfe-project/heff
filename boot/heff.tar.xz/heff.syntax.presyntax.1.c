// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define LBL_args 9498020
#define LBL_e 319
#define LBL_end 310101
#define LBL_head 9693863
#define LBL_part 9928890
#define LBL_run 322821
#define LBL_start 311115900
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2edoStep(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoStep_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2eall_24s1687051711x1677682329(V, V);
V g_list_2eall_24s1687051711x1677682329_entry(V self, V *a);
extern Clo g_list_2eall_24s1687051711x1677682329_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2enatBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2enatBytes(V v_k_240, V v_u_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_244 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_245 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_244)), v_acc_242);
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2enatBytes(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
      return heff_rec_n(2, shape_head__args, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_tsp_245}), v_ps_246});
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_241, 0);
      V v_xsp_249 = heff_field(v_p1_241, 1);
      V v_ps_2410 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_248}), v_xsp_249});
      return heff_rec_n(2, shape_head__args, (V[]){v_t_2411, v_ps_2410});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str0, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str1, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str2, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2edoStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edoStep_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2edoStep(V v_sp_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x21_243, 0);
      V v_xsp_246 = heff_field(v_x21_243, 1);
      V v_e_247 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 7ULL, 3);
      heff_drop_rec(v_x22_244, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str0)}), v_sp_240});
      V v_t_249 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_245, heff_dup(v_xsp_246)}), heff_dup(v_rest_242)});
      V v_t_2412;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2413 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2413}), NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_e_247, v_t_2414})));
    }
    case TAG_StmtLet: {
      V v_p_2415 = heff_field(v_x21_243, 0);
      V v_rhs_2416 = heff_field(v_x21_243, 1);
      V v_ru_24x21_243_24StmtLet = heff_take_reuse_n(v_x21_243, 3ULL, 2);
      heff_drop_rec(v_sp_240, 2);
      V v_t_2419;
      switch (heff_tag_of(v_p_2415)) {
      case TAG_At: {
        V v_s_2418 = heff_dup(heff_field(v_p_2415, 1));
        v_t_2419 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_p_2415);
      }
      V v_t_2422;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_rest_242, 1));
        v_t_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2424 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2415, heff_dup(v_rest_242)}), v_t_2423});
      V v_t_2427;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_x22_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x21_243_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_2416, v_t_2424}), v_t_2428});
    }
    case TAG_StmtExpr: {
      V v_e_2429 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_rec(v_x22_244, 2);
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str1)}), heff_dup(v_sp_240)});
      V v_t_2431 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str2), heff_dup(v_sp_240)}), heff_dup(v_rest_242)});
      V v_t_2434;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2433 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2435 = ({ V rv_1 = heff_get_n(v_t_2434, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2430, heff_tag_n(TAG_Cons, 2, (V[]){v_e_2429, v_t_2436})));
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edoStep(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0, 22, "`Array` takes one type");

HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_242}});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_243}});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_244}});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_245}});
  }
  case TAG_RuneWord: {
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TRune), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_246}});
  }
  case TAG_ArrayWord: {
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241})}});
  }
  case TAG_AbandonWord: {
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_FixedWord: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eargOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_dup(heff_field(v_x2_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EVar, 1);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), v_t_2418});
    }
    case TAG_EImplicitVar: {
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EImplicitVar, 1);
        v_t_2430 = v_c_2425;
        break;
      }
      case TAG_IsType: {
        V v_t_2426 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2433;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2430}), v_t_2433});
    }
    case TAG_ETag: {
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETag, 1);
        v_t_2445 = v_c_2440;
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CType, 1, (V[]){v_t_2441}), v_t_2444});
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2448;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2445}), v_t_2448});
    }
    case TAG_EInt: {
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2460;
      switch (heff_tag_of(v_x1_2450)) {
      case TAG_IsInferable: {
        V v_i_2451 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2455 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInt, 1);
        v_t_2460 = v_c_2455;
        break;
      }
      case TAG_IsType: {
        V v_t_2456 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
        break;
      }
      default: heff_nomatch(v_x1_2450);
      }
      V v_t_2463;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2460}), v_t_2463});
    }
    case TAG_EFloat: {
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2475;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_IsInferable: {
        V v_i_2466 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2469;
        switch (heff_tag_of(v_i_2466)) {
        case TAG_At: {
          V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
          v_t_2469 = v_s_2468;
          break;
        }
        default: heff_nomatch(v_i_2466);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2470 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EFloat, 1);
        v_t_2475 = v_c_2470;
        break;
      }
      case TAG_IsType: {
        V v_t_2471 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2478;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EString: {
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2490;
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_IsInferable: {
        V v_i_2481 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2484;
        switch (heff_tag_of(v_i_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_i_2481);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CInf, 1, (V[]){v_i_2481}), v_t_2484});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2485 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EString, 1);
        v_t_2490 = v_c_2485;
        break;
      }
      case TAG_IsType: {
        V v_t_2486 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_t_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CType, 1, (V[]){v_t_2486}), v_t_2489});
        break;
      }
      default: heff_nomatch(v_x1_2480);
      }
      V v_t_2493;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2490}), v_t_2493});
    }
    case TAG_EBinary: {
      V v_ru_24x21_242_24EBinary = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24105;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_IsInferable: {
        V v_i_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_i_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_i_2496);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CInf, 1, (V[]){v_i_2496}), v_t_2499});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24100 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EBinary, 1);
        v_t_24105 = v_c_24100;
        break;
      }
      case TAG_IsType: {
        V v_t_24101 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_t_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CType, 1, (V[]){v_t_24101}), v_t_24104});
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_t_24108;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24105}), v_t_24108});
    }
    case TAG_ERune: {
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24120;
      switch (heff_tag_of(v_x1_24110)) {
      case TAG_IsInferable: {
        V v_i_24111 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24114;
        switch (heff_tag_of(v_i_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_i_24111);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24115 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ERune, 1);
        v_t_24120 = v_c_24115;
        break;
      }
      case TAG_IsType: {
        V v_t_24116 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_t_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_t_24116);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
        break;
      }
      default: heff_nomatch(v_x1_24110);
      }
      V v_t_24123;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24120}), v_t_24123});
    }
    case TAG_EWord: {
      V v_ru_24x21_242_24EWord = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24125 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24135;
      switch (heff_tag_of(v_x1_24125)) {
      case TAG_IsInferable: {
        V v_i_24126 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24129;
        switch (heff_tag_of(v_i_24126)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_i_24126, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_i_24126);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CInf, 1, (V[]){v_i_24126}), v_t_24129});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24130 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EWord, 1);
        v_t_24135 = v_c_24130;
        break;
      }
      case TAG_IsType: {
        V v_t_24131 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24134;
        switch (heff_tag_of(v_t_24131)) {
        case TAG_At: {
          V v_s_24133 = heff_dup(heff_field(v_t_24131, 1));
          v_t_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_t_24131);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CType, 1, (V[]){v_t_24131}), v_t_24134});
        break;
      }
      default: heff_nomatch(v_x1_24125);
      }
      V v_t_24138;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24137 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24138 = v_s_24137;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24135}), v_t_24138});
    }
    case TAG_EApp: {
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24151;
      switch (heff_tag_of(v_x1_24141)) {
      case TAG_IsInferable: {
        V v_i_24142 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24145;
        switch (heff_tag_of(v_i_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_dup(heff_field(v_i_24142, 1));
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_i_24142);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24142}), v_t_24145});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24146 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EApp, 2);
        v_t_24151 = v_c_24146;
        break;
      }
      case TAG_IsType: {
        V v_t_24147 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24150;
        switch (heff_tag_of(v_t_24147)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
          v_t_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_t_24147);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
        break;
      }
      default: heff_nomatch(v_x1_24141);
      }
      V v_t_24154;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_EProject: {
      V v_x_24155 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_tag(v_x2_241, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_24155}), v_sp_243});
    }
    case TAG_ENamed: {
      V v_x_24156 = heff_field(v_x21_242, 0);
      V v_e_24157 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      V v_x1_24158 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24157}));
      V v_t_24168;
      switch (heff_tag_of(v_x1_24158)) {
      case TAG_IsInferable: {
        V v_i_24159 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        V v_t_24162;
        switch (heff_tag_of(v_i_24159)) {
        case TAG_At: {
          V v_s_24161 = heff_dup(heff_field(v_i_24159, 1));
          v_t_24162 = v_s_24161;
          break;
        }
        default: heff_nomatch(v_i_24159);
        }
        v_t_24168 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24159}), v_t_24162});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24163 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
        v_t_24168 = v_c_24163;
        break;
      }
      case TAG_IsType: {
        V v_t_24164 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        V v_t_24167;
        switch (heff_tag_of(v_t_24164)) {
        case TAG_At: {
          V v_s_24166 = heff_dup(heff_field(v_t_24164, 1));
          v_t_24167 = v_s_24166;
          break;
        }
        default: heff_nomatch(v_t_24164);
        }
        v_t_24168 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24164}), v_t_24167});
        break;
      }
      default: heff_nomatch(v_x1_24158);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24168}), v_sp_243});
    }
    case TAG_EPi: {
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24171 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24181;
      switch (heff_tag_of(v_x1_24171)) {
      case TAG_IsInferable: {
        V v_i_24172 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24175;
        switch (heff_tag_of(v_i_24172)) {
        case TAG_At: {
          V v_s_24174 = heff_dup(heff_field(v_i_24172, 1));
          v_t_24175 = v_s_24174;
          break;
        }
        default: heff_nomatch(v_i_24172);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24172}), v_t_24175});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24176 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EPi, 2);
        v_t_24181 = v_c_24176;
        break;
      }
      case TAG_IsType: {
        V v_t_24177 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24180;
        switch (heff_tag_of(v_t_24177)) {
        case TAG_At: {
          V v_s_24179 = heff_dup(heff_field(v_t_24177, 1));
          v_t_24180 = v_s_24179;
          break;
        }
        default: heff_nomatch(v_t_24177);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24177}), v_t_24180});
        break;
      }
      default: heff_nomatch(v_x1_24171);
      }
      V v_t_24184;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24183 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24184 = v_s_24183;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24181}), v_t_24184});
    }
    case TAG_ELam: {
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24187 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24197;
      switch (heff_tag_of(v_x1_24187)) {
      case TAG_IsInferable: {
        V v_i_24188 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24191;
        switch (heff_tag_of(v_i_24188)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_i_24188, 1));
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_i_24188);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24188}), v_t_24191});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24192 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        v_t_24197 = v_c_24192;
        break;
      }
      case TAG_IsType: {
        V v_t_24193 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24196;
        switch (heff_tag_of(v_t_24193)) {
        case TAG_At: {
          V v_s_24195 = heff_dup(heff_field(v_t_24193, 1));
          v_t_24196 = v_s_24195;
          break;
        }
        default: heff_nomatch(v_t_24193);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24193}), v_t_24196});
        break;
      }
      default: heff_nomatch(v_x1_24187);
      }
      V v_t_24200;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24199 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24200 = v_s_24199;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24197}), v_t_24200});
    }
    case TAG_EAnn: {
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24203 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24213;
      switch (heff_tag_of(v_x1_24203)) {
      case TAG_IsInferable: {
        V v_i_24204 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        V v_t_24207;
        switch (heff_tag_of(v_i_24204)) {
        case TAG_At: {
          V v_s_24206 = heff_dup(heff_field(v_i_24204, 1));
          v_t_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_i_24204);
        }
        v_t_24213 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24204}), v_t_24207});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24208 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24213 = v_c_24208;
        break;
      }
      case TAG_IsType: {
        V v_t_24209 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        V v_t_24212;
        switch (heff_tag_of(v_t_24209)) {
        case TAG_At: {
          V v_s_24211 = heff_dup(heff_field(v_t_24209, 1));
          v_t_24212 = v_s_24211;
          break;
        }
        default: heff_nomatch(v_t_24209);
        }
        v_t_24213 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24209}), v_t_24212});
        break;
      }
      default: heff_nomatch(v_x1_24203);
      }
      V v_t_24216;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24215 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24216 = v_s_24215;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24213}), v_t_24216});
    }
    case TAG_ESpec: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_24221 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24231;
      switch (heff_tag_of(v_x1_24221)) {
      case TAG_IsInferable: {
        V v_i_24222 = heff_field(v_x1_24221, 0);
        V v_ru_24x1_24221_24IsInferable = heff_take_reuse_n(v_x1_24221, 1ULL, 1);
        V v_t_24225;
        switch (heff_tag_of(v_i_24222)) {
        case TAG_At: {
          V v_s_24224 = heff_dup(heff_field(v_i_24222, 1));
          v_t_24225 = v_s_24224;
          break;
        }
        default: heff_nomatch(v_i_24222);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24221_24IsInferable, TAG_CInf, 1, (V[]){v_i_24222}), v_t_24225});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24226 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        v_t_24231 = v_c_24226;
        break;
      }
      case TAG_IsType: {
        V v_t_24227 = heff_field(v_x1_24221, 0);
        V v_ru_24x1_24221_24IsType = heff_take_reuse_n(v_x1_24221, 1ULL, 1);
        V v_t_24230;
        switch (heff_tag_of(v_t_24227)) {
        case TAG_At: {
          V v_s_24229 = heff_dup(heff_field(v_t_24227, 1));
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_t_24227);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24221_24IsType, TAG_CType, 1, (V[]){v_t_24227}), v_t_24230});
        break;
      }
      default: heff_nomatch(v_x1_24221);
      }
      V v_t_24234;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24233 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24234 = v_s_24233;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24231}), v_t_24234});
    }
    case TAG_ESig: {
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24236 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24246;
      switch (heff_tag_of(v_x1_24236)) {
      case TAG_IsInferable: {
        V v_i_24237 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24240;
        switch (heff_tag_of(v_i_24237)) {
        case TAG_At: {
          V v_s_24239 = heff_dup(heff_field(v_i_24237, 1));
          v_t_24240 = v_s_24239;
          break;
        }
        default: heff_nomatch(v_i_24237);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CInf, 1, (V[]){v_i_24237}), v_t_24240});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24241 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESig, 1);
        v_t_24246 = v_c_24241;
        break;
      }
      case TAG_IsType: {
        V v_t_24242 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24245;
        switch (heff_tag_of(v_t_24242)) {
        case TAG_At: {
          V v_s_24244 = heff_dup(heff_field(v_t_24242, 1));
          v_t_24245 = v_s_24244;
          break;
        }
        default: heff_nomatch(v_t_24242);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CType, 1, (V[]){v_t_24242}), v_t_24245});
        break;
      }
      default: heff_nomatch(v_x1_24236);
      }
      V v_t_24249;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24248 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24249 = v_s_24248;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24246}), v_t_24249});
    }
    case TAG_ESum: {
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24261;
      switch (heff_tag_of(v_x1_24251)) {
      case TAG_IsInferable: {
        V v_i_24252 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24255;
        switch (heff_tag_of(v_i_24252)) {
        case TAG_At: {
          V v_s_24254 = heff_dup(heff_field(v_i_24252, 1));
          v_t_24255 = v_s_24254;
          break;
        }
        default: heff_nomatch(v_i_24252);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CInf, 1, (V[]){v_i_24252}), v_t_24255});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24256 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESum, 1);
        v_t_24261 = v_c_24256;
        break;
      }
      case TAG_IsType: {
        V v_t_24257 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24260;
        switch (heff_tag_of(v_t_24257)) {
        case TAG_At: {
          V v_s_24259 = heff_dup(heff_field(v_t_24257, 1));
          v_t_24260 = v_s_24259;
          break;
        }
        default: heff_nomatch(v_t_24257);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CType, 1, (V[]){v_t_24257}), v_t_24260});
        break;
      }
      default: heff_nomatch(v_x1_24251);
      }
      V v_t_24264;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24263 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24264 = v_s_24263;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24261}), v_t_24264});
    }
    case TAG_EStruct: {
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24266 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24276;
      switch (heff_tag_of(v_x1_24266)) {
      case TAG_IsInferable: {
        V v_i_24267 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24270;
        switch (heff_tag_of(v_i_24267)) {
        case TAG_At: {
          V v_s_24269 = heff_dup(heff_field(v_i_24267, 1));
          v_t_24270 = v_s_24269;
          break;
        }
        default: heff_nomatch(v_i_24267);
        }
        v_t_24276 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CInf, 1, (V[]){v_i_24267}), v_t_24270});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24271 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EStruct, 1);
        v_t_24276 = v_c_24271;
        break;
      }
      case TAG_IsType: {
        V v_t_24272 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24275;
        switch (heff_tag_of(v_t_24272)) {
        case TAG_At: {
          V v_s_24274 = heff_dup(heff_field(v_t_24272, 1));
          v_t_24275 = v_s_24274;
          break;
        }
        default: heff_nomatch(v_t_24272);
        }
        v_t_24276 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CType, 1, (V[]){v_t_24272}), v_t_24275});
        break;
      }
      default: heff_nomatch(v_x1_24266);
      }
      V v_t_24279;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24278 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24279 = v_s_24278;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24276}), v_t_24279});
    }
    case TAG_EUpdate: {
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24282 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24292;
      switch (heff_tag_of(v_x1_24282)) {
      case TAG_IsInferable: {
        V v_i_24283 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24286;
        switch (heff_tag_of(v_i_24283)) {
        case TAG_At: {
          V v_s_24285 = heff_dup(heff_field(v_i_24283, 1));
          v_t_24286 = v_s_24285;
          break;
        }
        default: heff_nomatch(v_i_24283);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24283}), v_t_24286});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24287 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EUpdate, 2);
        v_t_24292 = v_c_24287;
        break;
      }
      case TAG_IsType: {
        V v_t_24288 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24291;
        switch (heff_tag_of(v_t_24288)) {
        case TAG_At: {
          V v_s_24290 = heff_dup(heff_field(v_t_24288, 1));
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_t_24288);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24288}), v_t_24291});
        break;
      }
      default: heff_nomatch(v_x1_24282);
      }
      V v_t_24295;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24294 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24295 = v_s_24294;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24292}), v_t_24295});
    }
    case TAG_EMatch: {
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24298 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24308;
      switch (heff_tag_of(v_x1_24298)) {
      case TAG_IsInferable: {
        V v_i_24299 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24302;
        switch (heff_tag_of(v_i_24299)) {
        case TAG_At: {
          V v_s_24301 = heff_dup(heff_field(v_i_24299, 1));
          v_t_24302 = v_s_24301;
          break;
        }
        default: heff_nomatch(v_i_24299);
        }
        v_t_24308 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24299}), v_t_24302});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24303 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EMatch, 2);
        v_t_24308 = v_c_24303;
        break;
      }
      case TAG_IsType: {
        V v_t_24304 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24307;
        switch (heff_tag_of(v_t_24304)) {
        case TAG_At: {
          V v_s_24306 = heff_dup(heff_field(v_t_24304, 1));
          v_t_24307 = v_s_24306;
          break;
        }
        default: heff_nomatch(v_t_24304);
        }
        v_t_24308 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24304}), v_t_24307});
        break;
      }
      default: heff_nomatch(v_x1_24298);
      }
      V v_t_24311;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24310 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24311 = v_s_24310;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24308}), v_t_24311});
    }
    case TAG_ELetIn: {
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24314 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24324;
      switch (heff_tag_of(v_x1_24314)) {
      case TAG_IsInferable: {
        V v_i_24315 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24318;
        switch (heff_tag_of(v_i_24315)) {
        case TAG_At: {
          V v_s_24317 = heff_dup(heff_field(v_i_24315, 1));
          v_t_24318 = v_s_24317;
          break;
        }
        default: heff_nomatch(v_i_24315);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24315}), v_t_24318});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24319 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELetIn, 2);
        v_t_24324 = v_c_24319;
        break;
      }
      case TAG_IsType: {
        V v_t_24320 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24323;
        switch (heff_tag_of(v_t_24320)) {
        case TAG_At: {
          V v_s_24322 = heff_dup(heff_field(v_t_24320, 1));
          v_t_24323 = v_s_24322;
          break;
        }
        default: heff_nomatch(v_t_24320);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24320}), v_t_24323});
        break;
      }
      default: heff_nomatch(v_x1_24314);
      }
      V v_t_24327;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24326 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24327 = v_s_24326;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24324}), v_t_24327});
    }
    case TAG_EDo: {
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24339;
      switch (heff_tag_of(v_x1_24329)) {
      case TAG_IsInferable: {
        V v_i_24330 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24333;
        switch (heff_tag_of(v_i_24330)) {
        case TAG_At: {
          V v_s_24332 = heff_dup(heff_field(v_i_24330, 1));
          v_t_24333 = v_s_24332;
          break;
        }
        default: heff_nomatch(v_i_24330);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CInf, 1, (V[]){v_i_24330}), v_t_24333});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24334 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EDo, 1);
        v_t_24339 = v_c_24334;
        break;
      }
      case TAG_IsType: {
        V v_t_24335 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24338;
        switch (heff_tag_of(v_t_24335)) {
        case TAG_At: {
          V v_s_24337 = heff_dup(heff_field(v_t_24335, 1));
          v_t_24338 = v_s_24337;
          break;
        }
        default: heff_nomatch(v_t_24335);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CType, 1, (V[]){v_t_24335}), v_t_24338});
        break;
      }
      default: heff_nomatch(v_x1_24329);
      }
      V v_t_24342;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24341 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24342 = v_s_24341;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24339}), v_t_24342});
    }
    case TAG_ELocal: {
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24345 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24355;
      switch (heff_tag_of(v_x1_24345)) {
      case TAG_IsInferable: {
        V v_i_24346 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        V v_t_24349;
        switch (heff_tag_of(v_i_24346)) {
        case TAG_At: {
          V v_s_24348 = heff_dup(heff_field(v_i_24346, 1));
          v_t_24349 = v_s_24348;
          break;
        }
        default: heff_nomatch(v_i_24346);
        }
        v_t_24355 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24346}), v_t_24349});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24350 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELocal, 2);
        v_t_24355 = v_c_24350;
        break;
      }
      case TAG_IsType: {
        V v_t_24351 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        V v_t_24354;
        switch (heff_tag_of(v_t_24351)) {
        case TAG_At: {
          V v_s_24353 = heff_dup(heff_field(v_t_24351, 1));
          v_t_24354 = v_s_24353;
          break;
        }
        default: heff_nomatch(v_t_24351);
        }
        v_t_24355 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24351}), v_t_24354});
        break;
      }
      default: heff_nomatch(v_x1_24345);
      }
      V v_t_24358;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24357 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24358 = v_s_24357;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24355}), v_t_24358});
    }
    case TAG_EInvalid: {
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24360 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24370;
      switch (heff_tag_of(v_x1_24360)) {
      case TAG_IsInferable: {
        V v_i_24361 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        V v_t_24364;
        switch (heff_tag_of(v_i_24361)) {
        case TAG_At: {
          V v_s_24363 = heff_dup(heff_field(v_i_24361, 1));
          v_t_24364 = v_s_24363;
          break;
        }
        default: heff_nomatch(v_i_24361);
        }
        v_t_24370 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CInf, 1, (V[]){v_i_24361}), v_t_24364});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24365 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInvalid, 1);
        v_t_24370 = v_c_24365;
        break;
      }
      case TAG_IsType: {
        V v_t_24366 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        V v_t_24369;
        switch (heff_tag_of(v_t_24366)) {
        case TAG_At: {
          V v_s_24368 = heff_dup(heff_field(v_t_24366, 1));
          v_t_24369 = v_s_24368;
          break;
        }
        default: heff_nomatch(v_t_24366);
        }
        v_t_24370 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CType, 1, (V[]){v_t_24366}), v_t_24369});
        break;
      }
      default: heff_nomatch(v_x1_24360);
      }
      V v_t_24373;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24372 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24373 = v_s_24372;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24370}), v_t_24373});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_e_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24SetField = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetField, TAG_SetField, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_BadFieldSet: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldSet = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2418}));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2429}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetPath, TAG_SetPath, 2, (V[]){v_path_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IsInferable: {
    V v_b_245 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b_245}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_246}});
  }
  case TAG_IsCheckable: {
    V v_t_2417;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_248 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2412 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2417 = v_c_2412;
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2417}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
  }
  case TAG_IsType: {
    V v_t_2429;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_2420 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2423;
      switch (heff_tag_of(v_i_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_i_2420);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2424 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2429 = v_c_2424;
      break;
    }
    case TAG_IsType: {
      V v_t_2425 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2429}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_size_243 = heff_field(v_x1_240, 2);
    V v_little_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_EVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EImplicitVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        V v_v_2411 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return (g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(v_size_243, v_little_244, heff_dup(v_v_2411)));
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2412 = heff_field(v_x12_242, 0);
          if (heff_intEq_c(heff_dup(v_x121_2412), MK_INT(8LL))) {
            V v_f_2414 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_v_2411)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EFloat: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EString: {
        V v_s_2416 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_size_243)) {
          case TAG_SizeDefault: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_s_2416)}});
          }
          case TAG_SizeNumber: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SizeName: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_size_243)}});
          }
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EBinary: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERune: {
        V v_c_2423 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2424 = heff_field(v_x12_242, 0);
          if (heff_intEq_c(heff_dup(v_x121_2424), MK_INT(8LL))) {
            V v_f_2426 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_c_2423)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EWord: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProject: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENamed: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPi: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAnn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESpec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESig: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESum: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStruct: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EUpdate: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetIn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EDo: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELocal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInvalid: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esizeTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esizeTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2esizeTerm(V v_x1_240, V v_x2_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x2_241}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_243}), v_sp_242});
  }
  case TAG_SizeNumber: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_x2_241);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){v_m_244}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), v_sp_242});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    heff_drop(v_x2_241);
    if (heff_intEq_c(heff_dup(v_x13_248), MK_INT(1LL))) {
      heff_drop(v_sp_242);
      heff_drop(v_x13_248);
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_xsp_247});
    } else {
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x13_248}), heff_dup(v_sp_242)});
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), heff_dup(v_sp_242)});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415})));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esizeTerm_str0)}), heff_dup(v_sp_242)});
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_242});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esizeTerm(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesTerm_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesTerm(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_242}), v_sp_241});
  }
  case TAG_SizeNumber: {
    V v_n_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){heff_intDiv(v_n_243, MK_INT(8LL))});
    V v_t_245 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    if (heff_intEq_c(heff_dup(v_x13_248), MK_INT(8LL))) {
      heff_drop(v_sp_241);
      heff_drop(v_x13_248);
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_xsp_247});
    } else {
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intDiv(v_x13_248, MK_INT(8LL))});
      V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)})});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415})));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesTerm_str0)}), heff_dup(v_sp_241)});
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_241)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_241});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesTerm(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V v_r_240, V v_v_241, V v_sp_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_241}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_IsInferable: {
    V v_i_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsInferable = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_i_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_i_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_i_244);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
    break;
  }
  case TAG_IsCheckable: {
    V v_c_248 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_t_2413 = v_c_248;
    break;
  }
  case TAG_IsType: {
    V v_t_249 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsType = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_t_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsType, TAG_CType, 1, (V[]){v_t_249}), v_t_2412});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2414));
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0)}), heff_dup(v_sp_242)});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_242)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts(V v_m_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_m_240, 2);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      heff_take_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tr(heff_call(heff_get_n(v_m_240, 1, 2), 2, (V[]){v_s_245, v_sp_246}));
        return heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_Cons, 2, (V[]){v_t_247, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_rest_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2410);
          V v_s_2416 = v_field_2414;
          V v_t_2422;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){v_s_2416, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2417 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2417)) {
            case TAG_MkPair: {
              V v_s0_2418 = heff_field(v_x11_2417, 0);
              V v_sp0_2419 = heff_field(v_x11_2417, 1);
              heff_take_n(v_x11_2417, 3ULL, 2);
              V v_t_2420 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2421 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2418, v_s_2416), v_t_2420});
              v_t_2422 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
              break;
            }
            default: heff_nomatch(v_x11_2417);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = v_t_2422;
          V t_3 = v_acc_243;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})}));
          V v_t_2428;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2428 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2424 = heff_field(v_run_242, 0);
            heff_take_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2424)) {
            case TAG_MkPair: {
              V v_s_2425 = heff_field(v_x21_2424, 0);
              V v_sp_2426 = heff_field(v_x21_2424, 1);
              heff_take_n(v_x21_2424, 3ULL, 2);
              V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 1)), 2, (V[]){v_s_2425, v_sp_2426}));
              v_t_2428 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2427, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2424);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2423, v_t_2428});
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0, 0, "");

HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  V v_t_2412;
  if ((heff_dup(v_asBits_241) == NTAG(TAG_True))) {
    v_t_2412 = NTAG(TAG_True);
  } else {
    V v_t_244 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_2412 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_242)));
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_245, MK_INT(0LL)));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        v_t_2412 = heff_bool(((v_tag_247 == ((int64_t)0ULL)) ? ({ V v_n_2410 = heff_dup(v_field_248); int c_ = !heff_intEq_c(heff_dup(v_n_2410), MK_INT(0LL)); heff_drop(v_n_2410); c_; }) : 1));
        heff_drop(v_field_248);
      }
    }
  }
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  } else {
    heff_drop(v_t_2412);
    V v_x1_2413 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_x1_2413) == NTAG(TAG_True))) {
      heff_drop(v_x1_2413);
      return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    } else {
      heff_drop(v_x1_2413);
      V v_t_2414 = (g_list_2eall_24s1687051711x1677682329(MK_INT(0LL), v_segs_242));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_242, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0)));
        HEFF_LAST return g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(v_r_240, v_segs_242, v_sp_243, v_t_2415);
      } else {
        heff_drop(v_t_2414);
        return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
      }
    }
  }
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclEquations = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2419;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_IsInferable: {
        V v_i_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_i_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_i_2410);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2410}), v_t_2413});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2414 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_c_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_c_2414);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
        break;
      }
      case TAG_IsType: {
        V v_t_2418 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2419 = v_t_2418;
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2420 = (g_list_2emap_24s1036840854x702708481(v_r_240, v_eqs_248));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_2419, v_t_2420}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_x21_242, 0);
      V v_xsp_2422 = heff_field(v_x21_242, 1);
      V v_ps_2423 = heff_field(v_x21_242, 2);
      V v_u_2424 = heff_field(v_x21_242, 3);
      V v_body_2425 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclDefine = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_t_2426 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2423));
      V v_x1_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2424}));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_IsInferable: {
        V v_i_2428 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_i_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_i_2428);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2432 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_c_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_c_2432);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
        break;
      }
      case TAG_IsType: {
        V v_t_2436 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2437 = v_t_2436;
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
      V v_x1_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2425}));
      V v_t_2448;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_IsInferable: {
        V v_i_2439 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsInferable = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_i_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_i_2439);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsInferable, TAG_CInf, 1, (V[]){v_i_2439}), v_t_2442});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2443 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2448 = v_c_2443;
        break;
      }
      case TAG_IsType: {
        V v_t_2444 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsType = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2447;
        switch (heff_tag_of(v_t_2444)) {
        case TAG_At: {
          V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
          v_t_2447 = v_s_2446;
          break;
        }
        default: heff_nomatch(v_t_2444);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsType, TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2421, v_xsp_2422, v_t_2426, v_t_2437, v_t_2448}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2449 = heff_field(v_x21_242, 0);
      V v_xsp_2450 = heff_field(v_x21_242, 1);
      V v_ps_2451 = heff_field(v_x21_242, 2);
      V v_body_2452 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclTheory = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_2453 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2451));
      V v_x1_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2452}));
      V v_t_2464;
      switch (heff_tag_of(v_x1_2454)) {
      case TAG_IsInferable: {
        V v_i_2455 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_i_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_i_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_i_2455);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2455}), v_t_2458});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2459 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2464 = v_c_2459;
        break;
      }
      case TAG_IsType: {
        V v_t_2460 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2463;
        switch (heff_tag_of(v_t_2460)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_t_2460);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
        break;
      }
      default: heff_nomatch(v_x1_2454);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2449, v_xsp_2450, v_t_2453, v_t_2464}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2465 = heff_field(v_x21_242, 0);
      V v_xsp_2466 = heff_field(v_x21_242, 1);
      V v_t_2467 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24DeclPrimitive = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2467}));
      V v_t_2478;
      switch (heff_tag_of(v_x1_2468)) {
      case TAG_IsInferable: {
        V v_i_2469 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2472;
        switch (heff_tag_of(v_i_2469)) {
        case TAG_At: {
          V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_i_2469);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2473 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2476;
        switch (heff_tag_of(v_c_2473)) {
        case TAG_At: {
          V v_s_2475 = heff_dup(heff_field(v_c_2473, 1));
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_c_2473);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2473}), v_t_2476});
        break;
      }
      case TAG_IsType: {
        V v_t_2477 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2478 = v_t_2477;
        break;
      }
      default: heff_nomatch(v_x1_2468);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2465, v_xsp_2466, v_t_2478}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2479 = heff_field(v_x21_242, 0);
      V v_xsp_2480 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_rec(v_r_240, 2);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2479, v_xsp_2480}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2481 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2481}));
      V v_t_2483 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2482));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_2483}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2427;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            v_t_2427 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2419 = v_field_2415;
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = v_field_2415;
              V v_t_2426;
              switch (heff_tag_of(v_t_2423)) {
              case TAG_At: {
                V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
                v_t_2426 = v_s_2425;
                break;
              }
              default: heff_nomatch(v_t_2423);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
            }
          }
        }
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2428});
        V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2429});
        V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2430));
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0)}), heff_dup(v_sp_242)});
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2431}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2436 = v_t_2434.f[1];
            int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
            if ((v_tag_2435 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2438 = v_field_2436;
              return v_c_2438;
            } else {
              if ((v_tag_2435 == ((int64_t)1ULL))) {
                V v_i_2440 = v_field_2436;
                V v_t_2443;
                switch (heff_tag_of(v_i_2440)) {
                case TAG_At: {
                  V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
                  v_t_2443 = v_s_2442;
                  break;
                }
                default: heff_nomatch(v_i_2440);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
              } else {
                V v_t_2444 = v_field_2436;
                V v_t_2447;
                switch (heff_tag_of(v_t_2444)) {
                case TAG_At: {
                  V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
                  v_t_2447 = v_s_2446;
                  break;
                }
                default: heff_nomatch(v_t_2444);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2449 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2464;
          {
            V v_field_2452 = v_t_2450.f[1];
            int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
            if ((v_tag_2451 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2454 = v_field_2452;
              v_t_2464 = v_c_2454;
            } else {
              if ((v_tag_2451 == ((int64_t)1ULL))) {
                V v_i_2456 = v_field_2452;
                V v_t_2459;
                switch (heff_tag_of(v_i_2456)) {
                case TAG_At: {
                  V v_s_2458 = heff_dup(heff_field(v_i_2456, 1));
                  v_t_2459 = v_s_2458;
                  break;
                }
                default: heff_nomatch(v_i_2456);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2456}), v_t_2459});
              } else {
                V v_t_2460 = v_field_2452;
                V v_t_2463;
                switch (heff_tag_of(v_t_2460)) {
                case TAG_At: {
                  V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
                  v_t_2463 = v_s_2462;
                  break;
                }
                default: heff_nomatch(v_t_2460);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
              }
            }
          }
          V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
          V v_args_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2465});
          V v_t_2467 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2466));
          V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1)}), heff_dup(v_sp_242)});
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2468, v_t_2467}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2469}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2473 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2474 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2488;
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            if ((v_tag_2475 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2478 = v_field_2476;
              v_t_2488 = v_c_2478;
            } else {
              if ((v_tag_2475 == ((int64_t)1ULL))) {
                V v_i_2480 = v_field_2476;
                V v_t_2483;
                switch (heff_tag_of(v_i_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_i_2480);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
              } else {
                V v_t_2484 = v_field_2476;
                V v_t_2487;
                switch (heff_tag_of(v_t_2484)) {
                case TAG_At: {
                  V v_s_2486 = heff_dup(heff_field(v_t_2484, 1));
                  v_t_2487 = v_s_2486;
                  break;
                }
                default: heff_nomatch(v_t_2484);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2484}), v_t_2487});
              }
            }
          }
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, NTAG(TAG_Nil)});
          V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2489});
          V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2490));
          V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2)}), heff_dup(v_sp_242)});
          V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT2 v_t_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24108;
        {
          V v_field_2496 = v_t_2494.f[1];
          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
          if ((v_tag_2495 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2498 = v_field_2496;
            v_t_24108 = v_c_2498;
          } else {
            if ((v_tag_2495 == ((int64_t)1ULL))) {
              V v_i_24100 = v_field_2496;
              V v_t_24103;
              switch (heff_tag_of(v_i_24100)) {
              case TAG_At: {
                V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
                v_t_24103 = v_s_24102;
                break;
              }
              default: heff_nomatch(v_i_24100);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
            } else {
              V v_t_24104 = v_field_2496;
              V v_t_24107;
              switch (heff_tag_of(v_t_24104)) {
              case TAG_At: {
                V v_s_24106 = heff_dup(heff_field(v_t_24104, 1));
                v_t_24107 = v_s_24106;
                break;
              }
              default: heff_nomatch(v_t_24104);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24104}), v_t_24107});
            }
          }
        }
        V v_args_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, NTAG(TAG_Nil)});
        V v_t_24110 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24109));
        V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3)}), heff_dup(v_sp_242)});
        V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24110}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24112}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24113 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24114;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)0ULL);
        }
        V v_t_24115 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24114 + ((int64_t)0ULL)))});
        V v_t_24116 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24115, heff_dup(v_sp_242)})});
        V v_t_24117 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT2 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24132;
        {
          V v_field_24120 = v_t_24118.f[1];
          int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
          if ((v_tag_24119 == ((int64_t)0ULL))) {
            V v_c_24122 = v_field_24120;
            v_t_24132 = v_c_24122;
          } else {
            if ((v_tag_24119 == ((int64_t)1ULL))) {
              V v_i_24124 = v_field_24120;
              V v_t_24127;
              switch (heff_tag_of(v_i_24124)) {
              case TAG_At: {
                V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
                v_t_24127 = v_s_24126;
                break;
              }
              default: heff_nomatch(v_i_24124);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
            } else {
              V v_t_24128 = v_field_24120;
              V v_t_24131;
              switch (heff_tag_of(v_t_24128)) {
              case TAG_At: {
                V v_s_24130 = heff_dup(heff_field(v_t_24128, 1));
                v_t_24131 = v_s_24130;
                break;
              }
              default: heff_nomatch(v_t_24128);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24128}), v_t_24131});
            }
          }
        }
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
        V v_args_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_t_24133});
        V v_t_24135 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24134));
        V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4)}), heff_dup(v_sp_242)});
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24136, v_t_24135}), heff_dup(v_sp_242)});
        V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24137}), heff_dup(v_sp_242)});
        V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
        V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24116, heff_dup(v_sp_242)}), v_t_24139});
        V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_t_24140});
        V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
        V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5)}), heff_dup(v_sp_242)});
        V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24145 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c(heff_dup(v_x2121_24145), MK_INT(8LL))) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24145);
          V v_t_24147 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24148 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24147, NTAG(TAG_Nil)});
          V v_t_24149 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24148));
          V v_t_24150 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6)}), heff_dup(v_sp_242)});
          V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24150, v_t_24149}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24151}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24145, MK_INT(16LL))) {
            int64_t v_t_24153;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)0ULL);
            }
            V v_t_24154 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24153 + ((int64_t)0ULL)))});
            V v_t_24155 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24154, heff_dup(v_sp_242)})});
            V v_t_24156 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24156, NTAG(TAG_Nil)});
            V v_args_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24155, heff_dup(v_sp_242)}), v_t_24157});
            V v_t_24159 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24158));
            V v_t_24160 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7)}), heff_dup(v_sp_242)});
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24160, v_t_24159}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24161}), v_sp_242});
          } else {
            int64_t v_t_24162;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)0ULL);
            }
            V v_t_24163 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24162 + ((int64_t)0ULL)))});
            V v_t_24164 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24163, heff_dup(v_sp_242)})});
            V v_t_24165 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
            V v_args_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24164, heff_dup(v_sp_242)}), v_t_24166});
            V v_t_24168 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24167));
            V v_t_24169 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8)}), heff_dup(v_sp_242)});
            V v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24169, v_t_24168}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24170}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(V v_seg_240) {
top: ;
  switch (heff_tag_of(v_seg_240)) {
  case TAG_At: {
    V v_seg1_241 = heff_dup(heff_field(v_seg_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_seg_240, 1));
    switch (heff_tag_of(v_seg1_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_seg1_241, 0);
      V v_seg12_244 = heff_field(v_seg1_241, 1);
      V v_size_245 = heff_field(v_seg1_241, 2);
      V v_little_246 = heff_field(v_seg1_241, 3);
      V v_signed_247 = heff_field(v_seg1_241, 4);
      heff_take_n(v_seg1_241, 31ULL, 5);
      switch (heff_tag_of(v_seg12_244)) {
      case TAG_SegmentInteger: {
        heff_drop_tag(v_seg_240, 2);
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2427;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            v_t_2427 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2419 = v_field_2415;
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = v_field_2415;
              V v_t_2426;
              switch (heff_tag_of(v_t_2423)) {
              case TAG_At: {
                V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
                v_t_2426 = v_s_2425;
                break;
              }
              default: heff_nomatch(v_t_2423);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
            }
          }
        }
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2428});
        V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2429});
        V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2430));
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str0)}), heff_dup(v_sp_242)});
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2431}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_2434 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
        V v_sp_2438;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_2437 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_2439 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2438), v_args_2435));
        V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str1)}), heff_dup(v_sp_2438)});
        V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2440, v_t_2439}), heff_dup(v_sp_2438)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2441}), v_sp_2438});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_240, 2);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2442 = heff_field(v_v_243, 0);
            V v_sp_2443 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2444 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2442)));
            {
              V v_field_2446 = v_t_2444.f[1];
              int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
              if ((v_tag_2445 == ((int64_t)0ULL))) {
                heff_drop(v_e_2442);
                V v_segs_2448 = v_field_2446;
                HeffT2 v_t_2449 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_segs_2448; V a_2 = v_sp_2443; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
                {
                  V v_field_2451 = v_t_2449.f[1];
                  int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
                  if ((v_tag_2450 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_2453 = v_field_2451;
                    return v_a_2453;
                  } else {
                    if ((v_tag_2450 == ((int64_t)1ULL))) {
                      V v_a_2455 = v_field_2451;
                      V v_t_2458;
                      switch (heff_tag_of(v_a_2455)) {
                      case TAG_At: {
                        V v_a_2457 = heff_dup(heff_field(v_a_2455, 1));
                        v_t_2458 = v_a_2457;
                        break;
                      }
                      default: heff_nomatch(v_a_2455);
                      }
                      return heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2455}), v_t_2458});
                    } else {
                      V v_a_2459 = v_field_2451;
                      V v_t_2462;
                      switch (heff_tag_of(v_a_2459)) {
                      case TAG_At: {
                        V v_a_2461 = heff_dup(heff_field(v_a_2459, 1));
                        v_t_2462 = v_a_2461;
                        break;
                      }
                      default: heff_nomatch(v_a_2459);
                      }
                      return heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2459}), v_t_2462});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2446);
                HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2442, v_sp_2443})));
                {
                  V v_field_2465 = v_t_2463.f[1];
                  int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                  if ((v_tag_2464 == ((int64_t)0ULL))) {
                    V v_c_2467 = v_field_2465;
                    return v_c_2467;
                  } else {
                    if ((v_tag_2464 == ((int64_t)1ULL))) {
                      V v_i_2469 = v_field_2465;
                      V v_t_2472;
                      switch (heff_tag_of(v_i_2469)) {
                      case TAG_At: {
                        V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
                        v_t_2472 = v_s_2471;
                        break;
                      }
                      default: heff_nomatch(v_i_2469);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2469}), v_t_2472});
                    } else {
                      V v_t_2473 = v_field_2465;
                      V v_t_2476;
                      switch (heff_tag_of(v_t_2473)) {
                      case TAG_At: {
                        V v_s_2475 = heff_dup(heff_field(v_t_2473, 1));
                        v_t_2476 = v_s_2475;
                        break;
                      }
                      default: heff_nomatch(v_t_2473);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2473}), v_t_2476});
                    }
                  }
                }
              }
            }
          }
          default: return heff_nomatch(v_v_243);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2478 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24114;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2479 = heff_field(v_v_243, 0);
            V v_sp_2480 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2481 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2479)));
            {
              V v_field_2483 = v_t_2481.f[1];
              int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
              if ((v_tag_2482 == ((int64_t)0ULL))) {
                heff_drop(v_e_2479);
                V v_segs_2485 = v_field_2483;
                HeffT2 v_t_2486 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_segs_2485; V a_2 = v_sp_2480; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
                {
                  V v_field_2488 = v_t_2486.f[1];
                  int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                  if ((v_tag_2487 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_2490 = v_field_2488;
                    v_t_24114 = v_a_2490;
                  } else {
                    if ((v_tag_2487 == ((int64_t)1ULL))) {
                      V v_a_2492 = v_field_2488;
                      V v_t_2495;
                      switch (heff_tag_of(v_a_2492)) {
                      case TAG_At: {
                        V v_a_2494 = heff_dup(heff_field(v_a_2492, 1));
                        v_t_2495 = v_a_2494;
                        break;
                      }
                      default: heff_nomatch(v_a_2492);
                      }
                      v_t_24114 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2492}), v_t_2495});
                    } else {
                      V v_a_2496 = v_field_2488;
                      V v_t_2499;
                      switch (heff_tag_of(v_a_2496)) {
                      case TAG_At: {
                        V v_a_2498 = heff_dup(heff_field(v_a_2496, 1));
                        v_t_2499 = v_a_2498;
                        break;
                      }
                      default: heff_nomatch(v_a_2496);
                      }
                      v_t_24114 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2496}), v_t_2499});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2483);
                HeffT2 v_t_24100 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2479, v_sp_2480})));
                {
                  V v_field_24102 = v_t_24100.f[1];
                  int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                  if ((v_tag_24101 == ((int64_t)0ULL))) {
                    V v_c_24104 = v_field_24102;
                    v_t_24114 = v_c_24104;
                  } else {
                    if ((v_tag_24101 == ((int64_t)1ULL))) {
                      V v_i_24106 = v_field_24102;
                      V v_t_24109;
                      switch (heff_tag_of(v_i_24106)) {
                      case TAG_At: {
                        V v_s_24108 = heff_dup(heff_field(v_i_24106, 1));
                        v_t_24109 = v_s_24108;
                        break;
                      }
                      default: heff_nomatch(v_i_24106);
                      }
                      v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24106}), v_t_24109});
                    } else {
                      V v_t_24110 = v_field_24102;
                      V v_t_24113;
                      switch (heff_tag_of(v_t_24110)) {
                      case TAG_At: {
                        V v_s_24112 = heff_dup(heff_field(v_t_24110, 1));
                        v_t_24113 = v_s_24112;
                        break;
                      }
                      default: heff_nomatch(v_t_24110);
                      }
                      v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24110}), v_t_24113});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24115 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24114, NTAG(TAG_Nil)});
          V v_args_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, v_t_24115});
          V v_t_24117 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24116));
          V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str2)}), heff_dup(v_sp_242)});
          V v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24118, v_t_24117}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24119}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_24123 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24159;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_24124 = heff_field(v_v_243, 0);
            V v_sp_24125 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_24126 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_24124)));
            {
              V v_field_24128 = v_t_24126.f[1];
              int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
              if ((v_tag_24127 == ((int64_t)0ULL))) {
                heff_drop(v_e_24124);
                V v_segs_24130 = v_field_24128;
                HeffT2 v_t_24131 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_segs_24130; V a_2 = v_sp_24125; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
                {
                  V v_field_24133 = v_t_24131.f[1];
                  int64_t v_tag_24132 = ((int64_t)v_t_24131.f[0]);
                  if ((v_tag_24132 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_24135 = v_field_24133;
                    v_t_24159 = v_a_24135;
                  } else {
                    if ((v_tag_24132 == ((int64_t)1ULL))) {
                      V v_a_24137 = v_field_24133;
                      V v_t_24140;
                      switch (heff_tag_of(v_a_24137)) {
                      case TAG_At: {
                        V v_a_24139 = heff_dup(heff_field(v_a_24137, 1));
                        v_t_24140 = v_a_24139;
                        break;
                      }
                      default: heff_nomatch(v_a_24137);
                      }
                      v_t_24159 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24137}), v_t_24140});
                    } else {
                      V v_a_24141 = v_field_24133;
                      V v_t_24144;
                      switch (heff_tag_of(v_a_24141)) {
                      case TAG_At: {
                        V v_a_24143 = heff_dup(heff_field(v_a_24141, 1));
                        v_t_24144 = v_a_24143;
                        break;
                      }
                      default: heff_nomatch(v_a_24141);
                      }
                      v_t_24159 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_24141}), v_t_24144});
                    }
                  }
                }
              } else {
                heff_drop(v_field_24128);
                HeffT2 v_t_24145 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_24124, v_sp_24125})));
                {
                  V v_field_24147 = v_t_24145.f[1];
                  int64_t v_tag_24146 = ((int64_t)v_t_24145.f[0]);
                  if ((v_tag_24146 == ((int64_t)0ULL))) {
                    V v_c_24149 = v_field_24147;
                    v_t_24159 = v_c_24149;
                  } else {
                    if ((v_tag_24146 == ((int64_t)1ULL))) {
                      V v_i_24151 = v_field_24147;
                      V v_t_24154;
                      switch (heff_tag_of(v_i_24151)) {
                      case TAG_At: {
                        V v_s_24153 = heff_dup(heff_field(v_i_24151, 1));
                        v_t_24154 = v_s_24153;
                        break;
                      }
                      default: heff_nomatch(v_i_24151);
                      }
                      v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24151}), v_t_24154});
                    } else {
                      V v_t_24155 = v_field_24147;
                      V v_t_24158;
                      switch (heff_tag_of(v_t_24155)) {
                      case TAG_At: {
                        V v_s_24157 = heff_dup(heff_field(v_t_24155, 1));
                        v_t_24158 = v_s_24157;
                        break;
                      }
                      default: heff_nomatch(v_t_24155);
                      }
                      v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24155}), v_t_24158});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24160 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24159, NTAG(TAG_Nil)});
          V v_args_24161 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, v_t_24160});
          V v_t_24162 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24161));
          V v_t_24163 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str3)}), heff_dup(v_sp_242)});
          V v_t_24164 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24163, v_t_24162}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24164}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24165 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
        V v_sp_24169;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24168 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24169 = v_s_24168;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24170 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24169), v_args_24166));
        V v_t_24171 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str4)}), heff_dup(v_sp_24169)});
        V v_t_24172 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24171, v_t_24170}), heff_dup(v_sp_24169)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24172}), v_sp_24169});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_244_24SegmentUtf = heff_take_reuse_n(v_seg12_244, 0ULL, 1);
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24174 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24175 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24174, NTAG(TAG_Nil)});
        V v_sp_24178;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24177 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24178 = v_s_24177;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24179 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24178), v_args_24175));
        V v_t_24180 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_244_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str5)}), heff_dup(v_sp_24178)});
        V v_t_24181 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24180, v_t_24179}), heff_dup(v_sp_24178)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24181}), v_sp_24178});
      }
      default: return heff_nomatch(v_seg12_244);
      }
    }
    default: return heff_nomatch(v_seg1_241);
    }
  }
  default: return heff_nomatch(v_seg_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V v_x2_240, V v_run_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_241)) {
    case TAG_Nothing: {
      return v_acc_242;
    }
    case TAG_Just: {
      V v_x21_243 = heff_field(v_run_241, 0);
      V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
      switch (heff_tag_of(v_x21_243)) {
      case TAG_MkPair: {
        V v_s_244 = heff_field(v_x21_243, 0);
        V v_sp_245 = heff_field(v_x21_243, 1);
        V v_ru_24x21_243_24MkPair = heff_take_reuse_n(v_x21_243, 3ULL, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_244}), heff_dup(v_sp_245)});
        V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), v_sp_245});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      }
      default: return heff_nomatch(v_x21_243);
      }
    }
    default: return heff_nomatch(v_run_241);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_240, 0);
    V v_rest_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_seg_2410);
          heff_drop_cell(v_ru_24x21_248_24At, 2);
          V v_s_2416 = v_field_2414;
          V v_t_2422;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2416, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2417 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x11_2417)) {
            case TAG_MkPair: {
              V v_s0_2418 = heff_field(v_x11_2417, 0);
              V v_sp0_2419 = heff_field(v_x11_2417, 1);
              V v_ru_24x11_2417_24MkPair = heff_take_reuse_n(v_x11_2417, 3ULL, 2);
              V v_t_2420 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2421 = heff_tag_at_n(v_ru_24x11_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2418, v_s_2416), v_t_2420});
              v_t_2422 = heff_tag_at_n(v_ru_24run_241_24Just, TAG_Just, 1, (V[]){v_t_2421});
              break;
            }
            default: heff_nomatch(v_x11_2417);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = v_t_2422;
          V t_2 = v_acc_242;
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2423 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(heff_tag_at_n(v_ru_24x21_248_24At, TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})));
          V v_t_2429;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            v_t_2429 = v_acc_242;
            break;
          }
          case TAG_Just: {
            V v_x21_2424 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x21_2424)) {
            case TAG_MkPair: {
              V v_s_2425 = heff_field(v_x21_2424, 0);
              V v_sp_2426 = heff_field(v_x21_2424, 1);
              V v_ru_24x21_2424_24MkPair = heff_take_reuse_n(v_x21_2424, 3ULL, 2);
              V v_t_2427 = heff_tag_at_n(v_ru_24x21_2424_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_2425}), heff_dup(v_sp_2426)});
              V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2427}), v_sp_2426});
              v_t_2429 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2428, v_acc_242});
              break;
            }
            default: heff_nomatch(v_x21_2424);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = NTAG(TAG_Nothing);
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2429});
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_dup(heff_field(v_x2_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_ru_24x21_241_24EVar = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2418;
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EVar, 1);
          V v_c_248 = v_field_246;
          v_t_2418 = v_c_248;
        } else {
          if ((v_tag_245 == ((int64_t)1ULL))) {
            V v_i_2410 = v_field_246;
            V v_t_2413;
            switch (heff_tag_of(v_i_2410)) {
            case TAG_At: {
              V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
              v_t_2413 = v_s_2412;
              break;
            }
            default: heff_nomatch(v_i_2410);
            }
            v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_CInf, 1, (V[]){v_i_2410}), v_t_2413});
          } else {
            V v_t_2414 = v_field_246;
            V v_t_2417;
            switch (heff_tag_of(v_t_2414)) {
            case TAG_At: {
              V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
              v_t_2417 = v_s_2416;
              break;
            }
            default: heff_nomatch(v_t_2414);
            }
            v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
          }
        }
      }
      V v_t_2421;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2421 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2418}), v_t_2421});
    }
    case TAG_EImplicitVar: {
      V v_ru_24x21_241_24EImplicitVar = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2437;
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EImplicitVar, 1);
          V v_c_2427 = v_field_2425;
          v_t_2437 = v_c_2427;
        } else {
          if ((v_tag_2424 == ((int64_t)1ULL))) {
            V v_i_2429 = v_field_2425;
            V v_t_2432;
            switch (heff_tag_of(v_i_2429)) {
            case TAG_At: {
              V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
              v_t_2432 = v_s_2431;
              break;
            }
            default: heff_nomatch(v_i_2429);
            }
            v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2429}), v_t_2432});
          } else {
            V v_t_2433 = v_field_2425;
            V v_t_2436;
            switch (heff_tag_of(v_t_2433)) {
            case TAG_At: {
              V v_s_2435 = heff_dup(heff_field(v_t_2433, 1));
              v_t_2436 = v_s_2435;
              break;
            }
            default: heff_nomatch(v_t_2433);
            }
            v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2433}), v_t_2436});
          }
        }
      }
      V v_t_2440;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2439 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2440 = v_s_2439;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2437}), v_t_2440});
    }
    case TAG_ETag: {
      V v_ru_24x21_241_24ETag = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2456;
      {
        V v_field_2444 = v_t_2442.f[1];
        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
        if ((v_tag_2443 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ETag, 1);
          V v_c_2446 = v_field_2444;
          v_t_2456 = v_c_2446;
        } else {
          if ((v_tag_2443 == ((int64_t)1ULL))) {
            V v_i_2448 = v_field_2444;
            V v_t_2451;
            switch (heff_tag_of(v_i_2448)) {
            case TAG_At: {
              V v_s_2450 = heff_dup(heff_field(v_i_2448, 1));
              v_t_2451 = v_s_2450;
              break;
            }
            default: heff_nomatch(v_i_2448);
            }
            v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETag, TAG_CInf, 1, (V[]){v_i_2448}), v_t_2451});
          } else {
            V v_t_2452 = v_field_2444;
            V v_t_2455;
            switch (heff_tag_of(v_t_2452)) {
            case TAG_At: {
              V v_s_2454 = heff_dup(heff_field(v_t_2452, 1));
              v_t_2455 = v_s_2454;
              break;
            }
            default: heff_nomatch(v_t_2452);
            }
            v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETag, TAG_CType, 1, (V[]){v_t_2452}), v_t_2455});
          }
        }
      }
      V v_t_2459;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2458 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2459 = v_s_2458;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2456}), v_t_2459});
    }
    case TAG_EInt: {
      V v_ru_24x21_241_24EInt = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2461 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2475;
      {
        V v_field_2463 = v_t_2461.f[1];
        int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
        if ((v_tag_2462 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EInt, 1);
          V v_c_2465 = v_field_2463;
          v_t_2475 = v_c_2465;
        } else {
          if ((v_tag_2462 == ((int64_t)1ULL))) {
            V v_i_2467 = v_field_2463;
            V v_t_2470;
            switch (heff_tag_of(v_i_2467)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_i_2467, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_i_2467);
            }
            v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_CInf, 1, (V[]){v_i_2467}), v_t_2470});
          } else {
            V v_t_2471 = v_field_2463;
            V v_t_2474;
            switch (heff_tag_of(v_t_2471)) {
            case TAG_At: {
              V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
              v_t_2474 = v_s_2473;
              break;
            }
            default: heff_nomatch(v_t_2471);
            }
            v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
          }
        }
      }
      V v_t_2478;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EFloat: {
      V v_ru_24x21_241_24EFloat = heff_take_reuse_na(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2480 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2494;
      {
        V v_field_2482 = v_t_2480.f[1];
        int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
        if ((v_tag_2481 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EFloat, 1);
          V v_c_2484 = v_field_2482;
          v_t_2494 = v_c_2484;
        } else {
          if ((v_tag_2481 == ((int64_t)1ULL))) {
            V v_i_2486 = v_field_2482;
            V v_t_2489;
            switch (heff_tag_of(v_i_2486)) {
            case TAG_At: {
              V v_s_2488 = heff_dup(heff_field(v_i_2486, 1));
              v_t_2489 = v_s_2488;
              break;
            }
            default: heff_nomatch(v_i_2486);
            }
            v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_CInf, 1, (V[]){v_i_2486}), v_t_2489});
          } else {
            V v_t_2490 = v_field_2482;
            V v_t_2493;
            switch (heff_tag_of(v_t_2490)) {
            case TAG_At: {
              V v_s_2492 = heff_dup(heff_field(v_t_2490, 1));
              v_t_2493 = v_s_2492;
              break;
            }
            default: heff_nomatch(v_t_2490);
            }
            v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_CType, 1, (V[]){v_t_2490}), v_t_2493});
          }
        }
      }
      V v_t_2497;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2496 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2497 = v_s_2496;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2494}), v_t_2497});
    }
    case TAG_EString: {
      V v_ru_24x21_241_24EString = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2499 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24113;
      {
        V v_field_24101 = v_t_2499.f[1];
        int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
        if ((v_tag_24100 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EString, 1);
          V v_c_24103 = v_field_24101;
          v_t_24113 = v_c_24103;
        } else {
          if ((v_tag_24100 == ((int64_t)1ULL))) {
            V v_i_24105 = v_field_24101;
            V v_t_24108;
            switch (heff_tag_of(v_i_24105)) {
            case TAG_At: {
              V v_s_24107 = heff_dup(heff_field(v_i_24105, 1));
              v_t_24108 = v_s_24107;
              break;
            }
            default: heff_nomatch(v_i_24105);
            }
            v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EString, TAG_CInf, 1, (V[]){v_i_24105}), v_t_24108});
          } else {
            V v_t_24109 = v_field_24101;
            V v_t_24112;
            switch (heff_tag_of(v_t_24109)) {
            case TAG_At: {
              V v_s_24111 = heff_dup(heff_field(v_t_24109, 1));
              v_t_24112 = v_s_24111;
              break;
            }
            default: heff_nomatch(v_t_24109);
            }
            v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EString, TAG_CType, 1, (V[]){v_t_24109}), v_t_24112});
          }
        }
      }
      V v_t_24116;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24115 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24116 = v_s_24115;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24113}), v_t_24116});
    }
    case TAG_EBinary: {
      V v_ru_24x21_241_24EBinary = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24132;
      {
        V v_field_24120 = v_t_24118.f[1];
        int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
        if ((v_tag_24119 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
          V v_c_24122 = v_field_24120;
          v_t_24132 = v_c_24122;
        } else {
          if ((v_tag_24119 == ((int64_t)1ULL))) {
            V v_i_24124 = v_field_24120;
            V v_t_24127;
            switch (heff_tag_of(v_i_24124)) {
            case TAG_At: {
              V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
              v_t_24127 = v_s_24126;
              break;
            }
            default: heff_nomatch(v_i_24124);
            }
            v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
          } else {
            V v_t_24128 = v_field_24120;
            V v_t_24131;
            switch (heff_tag_of(v_t_24128)) {
            case TAG_At: {
              V v_s_24130 = heff_dup(heff_field(v_t_24128, 1));
              v_t_24131 = v_s_24130;
              break;
            }
            default: heff_nomatch(v_t_24128);
            }
            v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_CType, 1, (V[]){v_t_24128}), v_t_24131});
          }
        }
      }
      V v_t_24135;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24134 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24135 = v_s_24134;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24132}), v_t_24135});
    }
    case TAG_ERune: {
      V v_ru_24x21_241_24ERune = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24137 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24151;
      {
        V v_field_24139 = v_t_24137.f[1];
        int64_t v_tag_24138 = ((int64_t)v_t_24137.f[0]);
        if ((v_tag_24138 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ERune, 1);
          V v_c_24141 = v_field_24139;
          v_t_24151 = v_c_24141;
        } else {
          if ((v_tag_24138 == ((int64_t)1ULL))) {
            V v_i_24143 = v_field_24139;
            V v_t_24146;
            switch (heff_tag_of(v_i_24143)) {
            case TAG_At: {
              V v_s_24145 = heff_dup(heff_field(v_i_24143, 1));
              v_t_24146 = v_s_24145;
              break;
            }
            default: heff_nomatch(v_i_24143);
            }
            v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_CInf, 1, (V[]){v_i_24143}), v_t_24146});
          } else {
            V v_t_24147 = v_field_24139;
            V v_t_24150;
            switch (heff_tag_of(v_t_24147)) {
            case TAG_At: {
              V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
              v_t_24150 = v_s_24149;
              break;
            }
            default: heff_nomatch(v_t_24147);
            }
            v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
          }
        }
      }
      V v_t_24154;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_EWord: {
      V v_ru_24x21_241_24EWord = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24156 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24170;
      {
        V v_field_24158 = v_t_24156.f[1];
        int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
        if ((v_tag_24157 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EWord, 1);
          V v_c_24160 = v_field_24158;
          v_t_24170 = v_c_24160;
        } else {
          if ((v_tag_24157 == ((int64_t)1ULL))) {
            V v_i_24162 = v_field_24158;
            V v_t_24165;
            switch (heff_tag_of(v_i_24162)) {
            case TAG_At: {
              V v_s_24164 = heff_dup(heff_field(v_i_24162, 1));
              v_t_24165 = v_s_24164;
              break;
            }
            default: heff_nomatch(v_i_24162);
            }
            v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EWord, TAG_CInf, 1, (V[]){v_i_24162}), v_t_24165});
          } else {
            V v_t_24166 = v_field_24158;
            V v_t_24169;
            switch (heff_tag_of(v_t_24166)) {
            case TAG_At: {
              V v_s_24168 = heff_dup(heff_field(v_t_24166, 1));
              v_t_24169 = v_s_24168;
              break;
            }
            default: heff_nomatch(v_t_24166);
            }
            v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EWord, TAG_CType, 1, (V[]){v_t_24166}), v_t_24169});
          }
        }
      }
      V v_t_24173;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24172 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24173 = v_s_24172;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24170}), v_t_24173});
    }
    case TAG_EApp: {
      V v_ru_24x21_241_24EApp = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24176 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24190;
      {
        V v_field_24178 = v_t_24176.f[1];
        int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
        if ((v_tag_24177 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EApp, 2);
          V v_c_24180 = v_field_24178;
          v_t_24190 = v_c_24180;
        } else {
          if ((v_tag_24177 == ((int64_t)1ULL))) {
            V v_i_24182 = v_field_24178;
            V v_t_24185;
            switch (heff_tag_of(v_i_24182)) {
            case TAG_At: {
              V v_s_24184 = heff_dup(heff_field(v_i_24182, 1));
              v_t_24185 = v_s_24184;
              break;
            }
            default: heff_nomatch(v_i_24182);
            }
            v_t_24190 = heff_tag_at_n(v_ru_24x21_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24182}), v_t_24185});
          } else {
            V v_t_24186 = v_field_24178;
            V v_t_24189;
            switch (heff_tag_of(v_t_24186)) {
            case TAG_At: {
              V v_s_24188 = heff_dup(heff_field(v_t_24186, 1));
              v_t_24189 = v_s_24188;
              break;
            }
            default: heff_nomatch(v_t_24186);
            }
            v_t_24190 = heff_tag_at_n(v_ru_24x21_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24186}), v_t_24189});
          }
        }
      }
      V v_t_24193;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24192 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24193 = v_s_24192;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24190}), v_t_24193});
    }
    case TAG_EProject: {
      V v_x_24194 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EProject = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_tag(v_x2_240, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EProject, TAG_ArgProject, 1, (V[]){v_x_24194}), v_sp_242});
    }
    case TAG_ENamed: {
      V v_x_24195 = heff_field(v_x21_241, 0);
      V v_e_24196 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ENamed = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      HeffT2 v_t_24197 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_24196));
      V v_t_24211;
      {
        V v_field_24199 = v_t_24197.f[1];
        int64_t v_tag_24198 = ((int64_t)v_t_24197.f[0]);
        if ((v_tag_24198 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ENamed, 2);
          V v_c_24201 = v_field_24199;
          v_t_24211 = v_c_24201;
        } else {
          if ((v_tag_24198 == ((int64_t)1ULL))) {
            V v_i_24203 = v_field_24199;
            V v_t_24206;
            switch (heff_tag_of(v_i_24203)) {
            case TAG_At: {
              V v_s_24205 = heff_dup(heff_field(v_i_24203, 1));
              v_t_24206 = v_s_24205;
              break;
            }
            default: heff_nomatch(v_i_24203);
            }
            v_t_24211 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24203}), v_t_24206});
          } else {
            V v_t_24207 = v_field_24199;
            V v_t_24210;
            switch (heff_tag_of(v_t_24207)) {
            case TAG_At: {
              V v_s_24209 = heff_dup(heff_field(v_t_24207, 1));
              v_t_24210 = v_s_24209;
              break;
            }
            default: heff_nomatch(v_t_24207);
            }
            v_t_24211 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24207}), v_t_24210});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24195, v_t_24211}), v_sp_242});
    }
    case TAG_EPi: {
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24214 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24228;
      {
        V v_field_24216 = v_t_24214.f[1];
        int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
        if ((v_tag_24215 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EPi, 2);
          V v_c_24218 = v_field_24216;
          v_t_24228 = v_c_24218;
        } else {
          if ((v_tag_24215 == ((int64_t)1ULL))) {
            V v_i_24220 = v_field_24216;
            V v_t_24223;
            switch (heff_tag_of(v_i_24220)) {
            case TAG_At: {
              V v_s_24222 = heff_dup(heff_field(v_i_24220, 1));
              v_t_24223 = v_s_24222;
              break;
            }
            default: heff_nomatch(v_i_24220);
            }
            v_t_24228 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24220}), v_t_24223});
          } else {
            V v_t_24224 = v_field_24216;
            V v_t_24227;
            switch (heff_tag_of(v_t_24224)) {
            case TAG_At: {
              V v_s_24226 = heff_dup(heff_field(v_t_24224, 1));
              v_t_24227 = v_s_24226;
              break;
            }
            default: heff_nomatch(v_t_24224);
            }
            v_t_24228 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24224}), v_t_24227});
          }
        }
      }
      V v_t_24231;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24230 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24231 = v_s_24230;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24228}), v_t_24231});
    }
    case TAG_ELam: {
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24234 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24248;
      {
        V v_field_24236 = v_t_24234.f[1];
        int64_t v_tag_24235 = ((int64_t)v_t_24234.f[0]);
        if ((v_tag_24235 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELam, 2);
          V v_c_24238 = v_field_24236;
          v_t_24248 = v_c_24238;
        } else {
          if ((v_tag_24235 == ((int64_t)1ULL))) {
            V v_i_24240 = v_field_24236;
            V v_t_24243;
            switch (heff_tag_of(v_i_24240)) {
            case TAG_At: {
              V v_s_24242 = heff_dup(heff_field(v_i_24240, 1));
              v_t_24243 = v_s_24242;
              break;
            }
            default: heff_nomatch(v_i_24240);
            }
            v_t_24248 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24240}), v_t_24243});
          } else {
            V v_t_24244 = v_field_24236;
            V v_t_24247;
            switch (heff_tag_of(v_t_24244)) {
            case TAG_At: {
              V v_s_24246 = heff_dup(heff_field(v_t_24244, 1));
              v_t_24247 = v_s_24246;
              break;
            }
            default: heff_nomatch(v_t_24244);
            }
            v_t_24248 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24244}), v_t_24247});
          }
        }
      }
      V v_t_24251;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24250 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24251 = v_s_24250;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24248}), v_t_24251});
    }
    case TAG_EAnn: {
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24254 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24268;
      {
        V v_field_24256 = v_t_24254.f[1];
        int64_t v_tag_24255 = ((int64_t)v_t_24254.f[0]);
        if ((v_tag_24255 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
          V v_c_24258 = v_field_24256;
          v_t_24268 = v_c_24258;
        } else {
          if ((v_tag_24255 == ((int64_t)1ULL))) {
            V v_i_24260 = v_field_24256;
            V v_t_24263;
            switch (heff_tag_of(v_i_24260)) {
            case TAG_At: {
              V v_s_24262 = heff_dup(heff_field(v_i_24260, 1));
              v_t_24263 = v_s_24262;
              break;
            }
            default: heff_nomatch(v_i_24260);
            }
            v_t_24268 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24260}), v_t_24263});
          } else {
            V v_t_24264 = v_field_24256;
            V v_t_24267;
            switch (heff_tag_of(v_t_24264)) {
            case TAG_At: {
              V v_s_24266 = heff_dup(heff_field(v_t_24264, 1));
              v_t_24267 = v_s_24266;
              break;
            }
            default: heff_nomatch(v_t_24264);
            }
            v_t_24268 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24264}), v_t_24267});
          }
        }
      }
      V v_t_24271;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24270 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24271 = v_s_24270;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24268}), v_t_24271});
    }
    case TAG_ESpec: {
      heff_take_n(v_x21_241, 0ULL, 4);
      heff_drop(v_sp_242);
      HeffT2 v_t_24276 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24290;
      {
        V v_field_24278 = v_t_24276.f[1];
        int64_t v_tag_24277 = ((int64_t)v_t_24276.f[0]);
        if ((v_tag_24277 == ((int64_t)0ULL))) {
          V v_c_24280 = v_field_24278;
          v_t_24290 = v_c_24280;
        } else {
          if ((v_tag_24277 == ((int64_t)1ULL))) {
            V v_i_24282 = v_field_24278;
            V v_t_24285;
            switch (heff_tag_of(v_i_24282)) {
            case TAG_At: {
              V v_s_24284 = heff_dup(heff_field(v_i_24282, 1));
              v_t_24285 = v_s_24284;
              break;
            }
            default: heff_nomatch(v_i_24282);
            }
            v_t_24290 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24282}), v_t_24285});
          } else {
            V v_t_24286 = v_field_24278;
            V v_t_24289;
            switch (heff_tag_of(v_t_24286)) {
            case TAG_At: {
              V v_s_24288 = heff_dup(heff_field(v_t_24286, 1));
              v_t_24289 = v_s_24288;
              break;
            }
            default: heff_nomatch(v_t_24286);
            }
            v_t_24290 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24286}), v_t_24289});
          }
        }
      }
      V v_t_24293;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24292 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24293 = v_s_24292;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24290}), v_t_24293});
    }
    case TAG_ESig: {
      V v_ru_24x21_241_24ESig = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24295 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24309;
      {
        V v_field_24297 = v_t_24295.f[1];
        int64_t v_tag_24296 = ((int64_t)v_t_24295.f[0]);
        if ((v_tag_24296 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ESig, 1);
          V v_c_24299 = v_field_24297;
          v_t_24309 = v_c_24299;
        } else {
          if ((v_tag_24296 == ((int64_t)1ULL))) {
            V v_i_24301 = v_field_24297;
            V v_t_24304;
            switch (heff_tag_of(v_i_24301)) {
            case TAG_At: {
              V v_s_24303 = heff_dup(heff_field(v_i_24301, 1));
              v_t_24304 = v_s_24303;
              break;
            }
            default: heff_nomatch(v_i_24301);
            }
            v_t_24309 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_CInf, 1, (V[]){v_i_24301}), v_t_24304});
          } else {
            V v_t_24305 = v_field_24297;
            V v_t_24308;
            switch (heff_tag_of(v_t_24305)) {
            case TAG_At: {
              V v_s_24307 = heff_dup(heff_field(v_t_24305, 1));
              v_t_24308 = v_s_24307;
              break;
            }
            default: heff_nomatch(v_t_24305);
            }
            v_t_24309 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_CType, 1, (V[]){v_t_24305}), v_t_24308});
          }
        }
      }
      V v_t_24312;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24311 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24312 = v_s_24311;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24309}), v_t_24312});
    }
    case TAG_ESum: {
      V v_ru_24x21_241_24ESum = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24314 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24328;
      {
        V v_field_24316 = v_t_24314.f[1];
        int64_t v_tag_24315 = ((int64_t)v_t_24314.f[0]);
        if ((v_tag_24315 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ESum, 1);
          V v_c_24318 = v_field_24316;
          v_t_24328 = v_c_24318;
        } else {
          if ((v_tag_24315 == ((int64_t)1ULL))) {
            V v_i_24320 = v_field_24316;
            V v_t_24323;
            switch (heff_tag_of(v_i_24320)) {
            case TAG_At: {
              V v_s_24322 = heff_dup(heff_field(v_i_24320, 1));
              v_t_24323 = v_s_24322;
              break;
            }
            default: heff_nomatch(v_i_24320);
            }
            v_t_24328 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_CInf, 1, (V[]){v_i_24320}), v_t_24323});
          } else {
            V v_t_24324 = v_field_24316;
            V v_t_24327;
            switch (heff_tag_of(v_t_24324)) {
            case TAG_At: {
              V v_s_24326 = heff_dup(heff_field(v_t_24324, 1));
              v_t_24327 = v_s_24326;
              break;
            }
            default: heff_nomatch(v_t_24324);
            }
            v_t_24328 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_CType, 1, (V[]){v_t_24324}), v_t_24327});
          }
        }
      }
      V v_t_24331;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24330 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24331 = v_s_24330;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24328}), v_t_24331});
    }
    case TAG_EStruct: {
      V v_ru_24x21_241_24EStruct = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24333 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24347;
      {
        V v_field_24335 = v_t_24333.f[1];
        int64_t v_tag_24334 = ((int64_t)v_t_24333.f[0]);
        if ((v_tag_24334 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EStruct, 1);
          V v_c_24337 = v_field_24335;
          v_t_24347 = v_c_24337;
        } else {
          if ((v_tag_24334 == ((int64_t)1ULL))) {
            V v_i_24339 = v_field_24335;
            V v_t_24342;
            switch (heff_tag_of(v_i_24339)) {
            case TAG_At: {
              V v_s_24341 = heff_dup(heff_field(v_i_24339, 1));
              v_t_24342 = v_s_24341;
              break;
            }
            default: heff_nomatch(v_i_24339);
            }
            v_t_24347 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_CInf, 1, (V[]){v_i_24339}), v_t_24342});
          } else {
            V v_t_24343 = v_field_24335;
            V v_t_24346;
            switch (heff_tag_of(v_t_24343)) {
            case TAG_At: {
              V v_s_24345 = heff_dup(heff_field(v_t_24343, 1));
              v_t_24346 = v_s_24345;
              break;
            }
            default: heff_nomatch(v_t_24343);
            }
            v_t_24347 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_CType, 1, (V[]){v_t_24343}), v_t_24346});
          }
        }
      }
      V v_t_24350;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24349 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24350 = v_s_24349;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24347}), v_t_24350});
    }
    case TAG_EUpdate: {
      V v_ru_24x21_241_24EUpdate = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24353 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24367;
      {
        V v_field_24355 = v_t_24353.f[1];
        int64_t v_tag_24354 = ((int64_t)v_t_24353.f[0]);
        if ((v_tag_24354 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EUpdate, 2);
          V v_c_24357 = v_field_24355;
          v_t_24367 = v_c_24357;
        } else {
          if ((v_tag_24354 == ((int64_t)1ULL))) {
            V v_i_24359 = v_field_24355;
            V v_t_24362;
            switch (heff_tag_of(v_i_24359)) {
            case TAG_At: {
              V v_s_24361 = heff_dup(heff_field(v_i_24359, 1));
              v_t_24362 = v_s_24361;
              break;
            }
            default: heff_nomatch(v_i_24359);
            }
            v_t_24367 = heff_tag_at_n(v_ru_24x21_241_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24359}), v_t_24362});
          } else {
            V v_t_24363 = v_field_24355;
            V v_t_24366;
            switch (heff_tag_of(v_t_24363)) {
            case TAG_At: {
              V v_s_24365 = heff_dup(heff_field(v_t_24363, 1));
              v_t_24366 = v_s_24365;
              break;
            }
            default: heff_nomatch(v_t_24363);
            }
            v_t_24367 = heff_tag_at_n(v_ru_24x21_241_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24363}), v_t_24366});
          }
        }
      }
      V v_t_24370;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24369 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24370 = v_s_24369;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24367}), v_t_24370});
    }
    case TAG_EMatch: {
      V v_ru_24x21_241_24EMatch = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24373 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24387;
      {
        V v_field_24375 = v_t_24373.f[1];
        int64_t v_tag_24374 = ((int64_t)v_t_24373.f[0]);
        if ((v_tag_24374 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EMatch, 2);
          V v_c_24377 = v_field_24375;
          v_t_24387 = v_c_24377;
        } else {
          if ((v_tag_24374 == ((int64_t)1ULL))) {
            V v_i_24379 = v_field_24375;
            V v_t_24382;
            switch (heff_tag_of(v_i_24379)) {
            case TAG_At: {
              V v_s_24381 = heff_dup(heff_field(v_i_24379, 1));
              v_t_24382 = v_s_24381;
              break;
            }
            default: heff_nomatch(v_i_24379);
            }
            v_t_24387 = heff_tag_at_n(v_ru_24x21_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24379}), v_t_24382});
          } else {
            V v_t_24383 = v_field_24375;
            V v_t_24386;
            switch (heff_tag_of(v_t_24383)) {
            case TAG_At: {
              V v_s_24385 = heff_dup(heff_field(v_t_24383, 1));
              v_t_24386 = v_s_24385;
              break;
            }
            default: heff_nomatch(v_t_24383);
            }
            v_t_24387 = heff_tag_at_n(v_ru_24x21_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24383}), v_t_24386});
          }
        }
      }
      V v_t_24390;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24389 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24390 = v_s_24389;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24387}), v_t_24390});
    }
    case TAG_ELetIn: {
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24393 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24407;
      {
        V v_field_24395 = v_t_24393.f[1];
        int64_t v_tag_24394 = ((int64_t)v_t_24393.f[0]);
        if ((v_tag_24394 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELetIn, 2);
          V v_c_24397 = v_field_24395;
          v_t_24407 = v_c_24397;
        } else {
          if ((v_tag_24394 == ((int64_t)1ULL))) {
            V v_i_24399 = v_field_24395;
            V v_t_24402;
            switch (heff_tag_of(v_i_24399)) {
            case TAG_At: {
              V v_s_24401 = heff_dup(heff_field(v_i_24399, 1));
              v_t_24402 = v_s_24401;
              break;
            }
            default: heff_nomatch(v_i_24399);
            }
            v_t_24407 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24399}), v_t_24402});
          } else {
            V v_t_24403 = v_field_24395;
            V v_t_24406;
            switch (heff_tag_of(v_t_24403)) {
            case TAG_At: {
              V v_s_24405 = heff_dup(heff_field(v_t_24403, 1));
              v_t_24406 = v_s_24405;
              break;
            }
            default: heff_nomatch(v_t_24403);
            }
            v_t_24407 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24403}), v_t_24406});
          }
        }
      }
      V v_t_24410;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24409 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24410 = v_s_24409;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24407}), v_t_24410});
    }
    case TAG_EDo: {
      V v_ru_24x21_241_24EDo = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24412 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24426;
      {
        V v_field_24414 = v_t_24412.f[1];
        int64_t v_tag_24413 = ((int64_t)v_t_24412.f[0]);
        if ((v_tag_24413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EDo, 1);
          V v_c_24416 = v_field_24414;
          v_t_24426 = v_c_24416;
        } else {
          if ((v_tag_24413 == ((int64_t)1ULL))) {
            V v_i_24418 = v_field_24414;
            V v_t_24421;
            switch (heff_tag_of(v_i_24418)) {
            case TAG_At: {
              V v_s_24420 = heff_dup(heff_field(v_i_24418, 1));
              v_t_24421 = v_s_24420;
              break;
            }
            default: heff_nomatch(v_i_24418);
            }
            v_t_24426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_CInf, 1, (V[]){v_i_24418}), v_t_24421});
          } else {
            V v_t_24422 = v_field_24414;
            V v_t_24425;
            switch (heff_tag_of(v_t_24422)) {
            case TAG_At: {
              V v_s_24424 = heff_dup(heff_field(v_t_24422, 1));
              v_t_24425 = v_s_24424;
              break;
            }
            default: heff_nomatch(v_t_24422);
            }
            v_t_24426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_CType, 1, (V[]){v_t_24422}), v_t_24425});
          }
        }
      }
      V v_t_24429;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24428 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24429 = v_s_24428;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24426}), v_t_24429});
    }
    case TAG_ELocal: {
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24446;
      {
        V v_field_24434 = v_t_24432.f[1];
        int64_t v_tag_24433 = ((int64_t)v_t_24432.f[0]);
        if ((v_tag_24433 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELocal, 2);
          V v_c_24436 = v_field_24434;
          v_t_24446 = v_c_24436;
        } else {
          if ((v_tag_24433 == ((int64_t)1ULL))) {
            V v_i_24438 = v_field_24434;
            V v_t_24441;
            switch (heff_tag_of(v_i_24438)) {
            case TAG_At: {
              V v_s_24440 = heff_dup(heff_field(v_i_24438, 1));
              v_t_24441 = v_s_24440;
              break;
            }
            default: heff_nomatch(v_i_24438);
            }
            v_t_24446 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24438}), v_t_24441});
          } else {
            V v_t_24442 = v_field_24434;
            V v_t_24445;
            switch (heff_tag_of(v_t_24442)) {
            case TAG_At: {
              V v_s_24444 = heff_dup(heff_field(v_t_24442, 1));
              v_t_24445 = v_s_24444;
              break;
            }
            default: heff_nomatch(v_t_24442);
            }
            v_t_24446 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24442}), v_t_24445});
          }
        }
      }
      V v_t_24449;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24448 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24449 = v_s_24448;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24446}), v_t_24449});
    }
    case TAG_EInvalid: {
      V v_ru_24x21_241_24EInvalid = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24451 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24465;
      {
        V v_field_24453 = v_t_24451.f[1];
        int64_t v_tag_24452 = ((int64_t)v_t_24451.f[0]);
        if ((v_tag_24452 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EInvalid, 1);
          V v_c_24455 = v_field_24453;
          v_t_24465 = v_c_24455;
        } else {
          if ((v_tag_24452 == ((int64_t)1ULL))) {
            V v_i_24457 = v_field_24453;
            V v_t_24460;
            switch (heff_tag_of(v_i_24457)) {
            case TAG_At: {
              V v_s_24459 = heff_dup(heff_field(v_i_24457, 1));
              v_t_24460 = v_s_24459;
              break;
            }
            default: heff_nomatch(v_i_24457);
            }
            v_t_24465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInvalid, TAG_CInf, 1, (V[]){v_i_24457}), v_t_24460});
          } else {
            V v_t_24461 = v_field_24453;
            V v_t_24464;
            switch (heff_tag_of(v_t_24461)) {
            case TAG_At: {
              V v_s_24463 = heff_dup(heff_field(v_t_24461, 1));
              v_t_24464 = v_s_24463;
              break;
            }
            default: heff_nomatch(v_t_24461);
            }
            v_t_24465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInvalid, TAG_CType, 1, (V[]){v_t_24461}), v_t_24464});
          }
        }
      }
      V v_t_24468;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24467 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24468 = v_s_24467;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24465}), v_t_24468});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_t_243 = heff_field(v_x21_241, 0);
      V v_tsp_244 = heff_field(v_x21_241, 1);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 7ULL, 3);
      V v_t_246 = (g_list_2emap_24s1887874170x1747433177(v_args_245));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_243, v_tsp_244, v_t_246}), v_sp_242});
    }
    case TAG_BadVariant: {
      V v_e_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadVariant = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_247));
      V v_t_2422;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2412 = v_field_2410;
          V v_t_2415;
          switch (heff_tag_of(v_c_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_c_2412);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            V v_i_2417 = v_field_2410;
            V v_t_2420;
            switch (heff_tag_of(v_i_2417)) {
            case TAG_At: {
              V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
              v_t_2420 = v_s_2419;
              break;
            }
            default: heff_nomatch(v_i_2417);
            }
            v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2417}), v_t_2420});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2421 = v_field_2410;
            v_t_2422 = v_t_2421;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2422}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclareField: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_d_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclareField = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_t_243, 0);
      V v_sp_246 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_244)) {
    case TAG_Nothing: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_d_244, 0);
      V v_ru_24d_244_24Just = heff_take_reuse_n(v_d_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_n_249 = heff_field(v_x_248, 0);
        V v_sp_2410 = heff_field(v_x_248, 1);
        V v_ru_24x_248_24At = heff_take_reuse_n(v_x_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_249));
        v_t_2412 = heff_tag_at_n(v_ru_24x_248_24At, TAG_At, 2, (V[]){v_t_2411, v_sp_2410});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24d_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_241, v_sp_242, v_t_247, v_t_2413});
  }
  case TAG_BadFieldDecl: {
    V v_e_2414 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24BadFieldDecl = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_e_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_e_2414, 0);
      V v_sp_2416 = heff_field(v_e_2414, 1);
      heff_take_n(v_e_2414, 3ULL, 2);
      v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2416, v_n_2415));
      break;
    }
    default: heff_nomatch(v_e_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(v_b_241));
    V v_t_246;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_cod_242, 0);
      V v_sp_245 = heff_field(v_cod_242, 1);
      heff_take_n(v_cod_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at_n(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_243, v_t_246});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_248 = (g_list_2emap_24s1992667171x110340492(v_fs_247));
    return heff_tag_at_n(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){v_t_248});
  }
  case TAG_TSum: {
    V v_vs_249 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2410 = (g_list_2emap_24s513391942x823299088(v_vs_249));
    return heff_tag_at_n(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){v_t_2410});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TRune: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_2411 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_a_2411, 0);
      V v_sp_2413 = heff_field(v_a_2411, 1);
      heff_take_n(v_a_2411, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    return heff_tag_at_n(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2414});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2416 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_i_2416)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_i_2416, 0);
      V v_sp_2418 = heff_field(v_i_2416, 1);
      V v_ru_24i_2416_24At = heff_take_reuse_n(v_i_2416, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24i_2416_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_i_2416);
    }
    return heff_tag_at_n(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2420});
  }
  case TAG_TChk: {
    V v_c_2421 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2425;
    switch (heff_tag_of(v_c_2421)) {
    case TAG_At: {
      V v_n_2422 = heff_field(v_c_2421, 0);
      V v_sp_2423 = heff_field(v_c_2421, 1);
      V v_ru_24c_2421_24At = heff_take_reuse_n(v_c_2421, 3ULL, 2);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2422));
      v_t_2425 = heff_tag_at_n(v_ru_24c_2421_24At, TAG_At, 2, (V[]){v_t_2424, v_sp_2423});
      break;
    }
    default: heff_nomatch(v_c_2421);
    }
    return heff_tag_at_n(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2425});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
      v_t_245 = heff_tag_at_n(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at_n(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      heff_take_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2438 = (g_list_2emap_24s79542405x478516404(v_args_2437));
    return heff_tag_at_n(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, v_t_2438});
  }
  case TAG_CStruct: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1729787689x465380098(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){v_t_2440});
  }
  case TAG_CMatch: {
    V v_sc_2441 = heff_field(v_n_240, 0);
    V v_alts_2442 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_sc_2441)) {
    case TAG_At: {
      V v_n_2443 = heff_field(v_sc_2441, 0);
      V v_sp_2444 = heff_field(v_sc_2441, 1);
      V v_ru_24sc_2441_24At = heff_take_reuse_n(v_sc_2441, 3ULL, 2);
      V v_t_2445 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2443));
      v_t_2446 = heff_tag_at_n(v_ru_24sc_2441_24At, TAG_At, 2, (V[]){v_t_2445, v_sp_2444});
      break;
    }
    default: heff_nomatch(v_sc_2441);
    }
    V v_t_2447 = (g_list_2emap_24s244350250x1728178626(v_alts_2442));
    return heff_tag_at_n(v_ru_24n_240_24CMatch, TAG_CMatch, 2, (V[]){v_t_2446, v_t_2447});
  }
  case TAG_CLetIn: {
    V v_rhs_2448 = heff_field(v_n_240, 0);
    V v_alt_2449 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2453;
    switch (heff_tag_of(v_rhs_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_rhs_2448, 0);
      V v_sp_2451 = heff_field(v_rhs_2448, 1);
      V v_ru_24rhs_2448_24At = heff_take_reuse_n(v_rhs_2448, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24rhs_2448_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_rhs_2448);
    }
    V v_t_2463;
    switch (heff_tag_of(v_alt_2449)) {
    case TAG_At: {
      V v_x_2454 = heff_field(v_alt_2449, 0);
      V v_sp_2455 = heff_field(v_alt_2449, 1);
      V v_ru_24alt_2449_24At = heff_take_reuse_n(v_alt_2449, 3ULL, 2);
      V v_t_2462;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_MkAlt: {
        V v_p_2456 = heff_field(v_x_2454, 0);
        V v_b_2457 = heff_field(v_x_2454, 1);
        V v_ru_24x_2454_24MkAlt = heff_take_reuse_n(v_x_2454, 3ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_b_2457)) {
        case TAG_At: {
          V v_n_2458 = heff_field(v_b_2457, 0);
          V v_sp_2459 = heff_field(v_b_2457, 1);
          heff_take_n(v_b_2457, 3ULL, 2);
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2458));
          v_t_2461 = heff_tag_at_n(v_ru_24alt_2449_24At, TAG_At, 2, (V[]){v_t_2460, v_sp_2459});
          break;
        }
        default: heff_nomatch(v_b_2457);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x_2454_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2456, v_t_2461});
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_alt_2449);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2453, v_t_2463});
  }
  case TAG_CLocal: {
    V v_body_2464 = heff_field(v_n_240, 0);
    V v_ds_2465 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_body_2464)) {
    case TAG_At: {
      V v_n_2466 = heff_field(v_body_2464, 0);
      V v_sp_2467 = heff_field(v_body_2464, 1);
      V v_ru_24body_2464_24At = heff_take_reuse_n(v_body_2464, 3ULL, 2);
      V v_t_2468 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2466));
      v_t_2469 = heff_tag_at_n(v_ru_24body_2464_24At, TAG_At, 2, (V[]){v_t_2468, v_sp_2467});
      break;
    }
    default: heff_nomatch(v_body_2464);
    }
    V v_t_2470 = (g_list_2emap_24s386875578x1005587669(v_ds_2465));
    return heff_tag_at_n(v_ru_24n_240_24CLocal, TAG_CLocal, 2, (V[]){v_t_2469, v_t_2470});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IVar: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_244 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_IInt: {
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_247 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_IFloat: {
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2410 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_IString: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_IBytes: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2416 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_240});
  }
  case TAG_IPrim: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_IRune: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_IApp: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2426 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_sp_240});
  }
  case TAG_IAnn: {
    V v_c_2427 = heff_field(v_n_241, 0);
    V v_t_2428 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_2431;
    switch (heff_tag_of(v_c_2427)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_c_2427, 0);
      V v_sp_2430 = heff_field(v_c_2427, 1);
      heff_take_n(v_c_2427, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_c_2427);
    }
    V v_t_2434;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_t_2428, 0);
      V v_sp_2433 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2434 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2433, v_n_2432));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IAnn, TAG_IAnn, 2, (V[]){v_t_2431, v_t_2434}), v_sp_240});
  }
  case TAG_ISpec: {
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2440 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2439, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_240});
  }
  case TAG_IUpdate: {
    V v_t_2443 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2444 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_sp_240});
  }
  case TAG_IAnnLam: {
    V v_t_2449 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2450 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2449, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2450, v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2451 = heff_field(v_n_241, 0);
    V v_why_2452 = heff_field(v_n_241, 1);
    V v_note_2453 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 7ULL, 3);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IInvalid, TAG_IInvalid, 3, (V[]){v_code_2451, v_why_2452, v_note_2453}), v_sp_240});
  }
  case TAG_INominal: {
    V v_t_2455 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2456 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2455, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2456, v_sp_240});
  }
  case TAG_ILitEq: {
    V v_t_2461 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2462 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2461, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(a[0], a[1]);
}