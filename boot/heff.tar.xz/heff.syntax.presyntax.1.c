// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RuneWord 42901
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TypeWord 10401
#define LBL_args 9498020
#define LBL_e 319
#define LBL_end 310101
#define LBL_head 9693863
#define LBL_start 311115900
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryWith(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryWith_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryWith_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassify_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2edoStep(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoStep_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2esegmentPart(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentPart_clo;
V g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835(V);
V g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeSegment(V);
V g_heff_2esyntax_2epresyntax_2ewholeSegment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeSegment_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1688457226x2006118782(V);
V g_list_2emap_24s1688457226x2006118782_entry(V self, V *a);
extern Clo g_list_2emap_24s1688457226x2006118782_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2enatBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2enatBytes(V v_k_240, V v_u_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_244 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_245 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_244)), v_acc_242);
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2enatBytes(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
      return heff_rec_n(2, shape_head__args, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_tsp_245}), v_ps_246});
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_241, 0);
      V v_xsp_249 = heff_field(v_p1_241, 1);
      V v_ps_2410 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_248}), v_xsp_249});
      return heff_rec_n(2, shape_head__args, (V[]){v_t_2411, v_ps_2410});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str0, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str1, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str2, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2edoStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edoStep_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2edoStep(V v_sp_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x21_243, 0);
      V v_xsp_246 = heff_field(v_x21_243, 1);
      V v_e_247 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 7ULL, 3);
      heff_drop_rec(v_x22_244, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str0)}), v_sp_240});
      V v_t_249 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_245, heff_dup(v_xsp_246)}), heff_dup(v_rest_242)});
      V v_t_2412;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2413 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_246, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2413}), NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_e_247, v_t_2414})));
    }
    case TAG_StmtLet: {
      V v_p_2415 = heff_field(v_x21_243, 0);
      V v_rhs_2416 = heff_field(v_x21_243, 1);
      V v_ru_24x21_243_24StmtLet = heff_take_reuse_n(v_x21_243, 3ULL, 2);
      heff_drop_rec(v_sp_240, 2);
      V v_t_2419;
      switch (heff_tag_of(v_p_2415)) {
      case TAG_At: {
        V v_s_2418 = heff_dup(heff_field(v_p_2415, 1));
        v_t_2419 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_p_2415);
      }
      V v_t_2422;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_rest_242, 1));
        v_t_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2424 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2415, heff_dup(v_rest_242)}), v_t_2423});
      V v_t_2427;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_x22_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x21_243_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_2416, v_t_2424}), v_t_2428});
    }
    case TAG_StmtExpr: {
      V v_e_2429 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_rec(v_x22_244, 2);
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str1)}), heff_dup(v_sp_240)});
      V v_t_2431 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str2), heff_dup(v_sp_240)}), heff_dup(v_rest_242)});
      V v_t_2434;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2433 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2435 = ({ V rv_1 = heff_get_n(v_t_2434, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2430, heff_tag_n(TAG_Cons, 2, (V[]){v_e_2429, v_t_2436})));
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edoStep(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eargOf(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EVar, 1);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), v_t_2418});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EImplicitVar, 1);
        v_t_2430 = v_c_2425;
        break;
      }
      case TAG_IsType: {
        V v_t_2426 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2433;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2430}), v_t_2433});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ETag, 1);
        v_t_2445 = v_c_2440;
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_CType, 1, (V[]){v_t_2441}), v_t_2444});
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2448;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2445}), v_t_2448});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2460;
      switch (heff_tag_of(v_x1_2450)) {
      case TAG_IsInferable: {
        V v_i_2451 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2455 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EInt, 1);
        v_t_2460 = v_c_2455;
        break;
      }
      case TAG_IsType: {
        V v_t_2456 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
        break;
      }
      default: heff_nomatch(v_x1_2450);
      }
      V v_t_2463;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2460}), v_t_2463});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_na(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2475;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_IsInferable: {
        V v_i_2466 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2469;
        switch (heff_tag_of(v_i_2466)) {
        case TAG_At: {
          V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
          v_t_2469 = v_s_2468;
          break;
        }
        default: heff_nomatch(v_i_2466);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2470 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EFloat, 1);
        v_t_2475 = v_c_2470;
        break;
      }
      case TAG_IsType: {
        V v_t_2471 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2478;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2490;
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_IsInferable: {
        V v_i_2481 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2484;
        switch (heff_tag_of(v_i_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_i_2481);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_CInf, 1, (V[]){v_i_2481}), v_t_2484});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2485 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EString, 1);
        v_t_2490 = v_c_2485;
        break;
      }
      case TAG_IsType: {
        V v_t_2486 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_t_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_CType, 1, (V[]){v_t_2486}), v_t_2489});
        break;
      }
      default: heff_nomatch(v_x1_2480);
      }
      V v_t_2493;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2490}), v_t_2493});
    }
    case TAG_EBinary: {
      V v_ru_24e1_242_24EBinary = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24105;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_IsInferable: {
        V v_i_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_i_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_i_2496);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_CInf, 1, (V[]){v_i_2496}), v_t_2499});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24100 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EBinary, 1);
        v_t_24105 = v_c_24100;
        break;
      }
      case TAG_IsType: {
        V v_t_24101 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_t_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_CType, 1, (V[]){v_t_24101}), v_t_24104});
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_t_24108;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24105}), v_t_24108});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24120;
      switch (heff_tag_of(v_x1_24110)) {
      case TAG_IsInferable: {
        V v_i_24111 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24114;
        switch (heff_tag_of(v_i_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_i_24111);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24115 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ERune, 1);
        v_t_24120 = v_c_24115;
        break;
      }
      case TAG_IsType: {
        V v_t_24116 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_t_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_t_24116);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
        break;
      }
      default: heff_nomatch(v_x1_24110);
      }
      V v_t_24123;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24120}), v_t_24123});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24125 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24135;
      switch (heff_tag_of(v_x1_24125)) {
      case TAG_IsInferable: {
        V v_i_24126 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24129;
        switch (heff_tag_of(v_i_24126)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_i_24126, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_i_24126);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_CInf, 1, (V[]){v_i_24126}), v_t_24129});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24130 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EWord, 1);
        v_t_24135 = v_c_24130;
        break;
      }
      case TAG_IsType: {
        V v_t_24131 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24134;
        switch (heff_tag_of(v_t_24131)) {
        case TAG_At: {
          V v_s_24133 = heff_dup(heff_field(v_t_24131, 1));
          v_t_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_t_24131);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_CType, 1, (V[]){v_t_24131}), v_t_24134});
        break;
      }
      default: heff_nomatch(v_x1_24125);
      }
      V v_t_24138;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24137 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24138 = v_s_24137;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24135}), v_t_24138});
    }
    case TAG_EApp: {
      V v_ru_24e1_242_24EApp = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24151;
      switch (heff_tag_of(v_x1_24141)) {
      case TAG_IsInferable: {
        V v_i_24142 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24145;
        switch (heff_tag_of(v_i_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_dup(heff_field(v_i_24142, 1));
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_i_24142);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24142}), v_t_24145});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24146 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EApp, 2);
        v_t_24151 = v_c_24146;
        break;
      }
      case TAG_IsType: {
        V v_t_24147 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24150;
        switch (heff_tag_of(v_t_24147)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
          v_t_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_t_24147);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
        break;
      }
      default: heff_nomatch(v_x1_24141);
      }
      V v_t_24154;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_EProject: {
      V v_x_24155 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_24155}), v_sp_243});
    }
    case TAG_ENamed: {
      V v_x_24156 = heff_field(v_e1_242, 0);
      V v_e12_24157 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24ENamed = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_x1_24158 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e12_24157}));
      V v_t_24168;
      switch (heff_tag_of(v_x1_24158)) {
      case TAG_IsInferable: {
        V v_i_24159 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        V v_t_24162;
        switch (heff_tag_of(v_i_24159)) {
        case TAG_At: {
          V v_s_24161 = heff_dup(heff_field(v_i_24159, 1));
          v_t_24162 = v_s_24161;
          break;
        }
        default: heff_nomatch(v_i_24159);
        }
        v_t_24168 = heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24159}), v_t_24162});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24163 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ENamed, 2);
        v_t_24168 = v_c_24163;
        break;
      }
      case TAG_IsType: {
        V v_t_24164 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        V v_t_24167;
        switch (heff_tag_of(v_t_24164)) {
        case TAG_At: {
          V v_s_24166 = heff_dup(heff_field(v_t_24164, 1));
          v_t_24167 = v_s_24166;
          break;
        }
        default: heff_nomatch(v_t_24164);
        }
        v_t_24168 = heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24164}), v_t_24167});
        break;
      }
      default: heff_nomatch(v_x1_24158);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24168}), v_sp_243});
    }
    case TAG_EPi: {
      V v_ru_24e1_242_24EPi = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24171 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24181;
      switch (heff_tag_of(v_x1_24171)) {
      case TAG_IsInferable: {
        V v_i_24172 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24175;
        switch (heff_tag_of(v_i_24172)) {
        case TAG_At: {
          V v_s_24174 = heff_dup(heff_field(v_i_24172, 1));
          v_t_24175 = v_s_24174;
          break;
        }
        default: heff_nomatch(v_i_24172);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24172}), v_t_24175});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24176 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EPi, 2);
        v_t_24181 = v_c_24176;
        break;
      }
      case TAG_IsType: {
        V v_t_24177 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24180;
        switch (heff_tag_of(v_t_24177)) {
        case TAG_At: {
          V v_s_24179 = heff_dup(heff_field(v_t_24177, 1));
          v_t_24180 = v_s_24179;
          break;
        }
        default: heff_nomatch(v_t_24177);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24177}), v_t_24180});
        break;
      }
      default: heff_nomatch(v_x1_24171);
      }
      V v_t_24184;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24183 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24184 = v_s_24183;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24181}), v_t_24184});
    }
    case TAG_ELam: {
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24187 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24197;
      switch (heff_tag_of(v_x1_24187)) {
      case TAG_IsInferable: {
        V v_i_24188 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24191;
        switch (heff_tag_of(v_i_24188)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_i_24188, 1));
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_i_24188);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24188}), v_t_24191});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24192 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELam, 2);
        v_t_24197 = v_c_24192;
        break;
      }
      case TAG_IsType: {
        V v_t_24193 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24196;
        switch (heff_tag_of(v_t_24193)) {
        case TAG_At: {
          V v_s_24195 = heff_dup(heff_field(v_t_24193, 1));
          v_t_24196 = v_s_24195;
          break;
        }
        default: heff_nomatch(v_t_24193);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24193}), v_t_24196});
        break;
      }
      default: heff_nomatch(v_x1_24187);
      }
      V v_t_24200;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24199 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24200 = v_s_24199;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24197}), v_t_24200});
    }
    case TAG_EAnn: {
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24203 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24213;
      switch (heff_tag_of(v_x1_24203)) {
      case TAG_IsInferable: {
        V v_i_24204 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        V v_t_24207;
        switch (heff_tag_of(v_i_24204)) {
        case TAG_At: {
          V v_s_24206 = heff_dup(heff_field(v_i_24204, 1));
          v_t_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_i_24204);
        }
        v_t_24213 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24204}), v_t_24207});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24208 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EAnn, 2);
        v_t_24213 = v_c_24208;
        break;
      }
      case TAG_IsType: {
        V v_t_24209 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        V v_t_24212;
        switch (heff_tag_of(v_t_24209)) {
        case TAG_At: {
          V v_s_24211 = heff_dup(heff_field(v_t_24209, 1));
          v_t_24212 = v_s_24211;
          break;
        }
        default: heff_nomatch(v_t_24209);
        }
        v_t_24213 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24209}), v_t_24212});
        break;
      }
      default: heff_nomatch(v_x1_24203);
      }
      V v_t_24216;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24215 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24216 = v_s_24215;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24213}), v_t_24216});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_24221 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24231;
      switch (heff_tag_of(v_x1_24221)) {
      case TAG_IsInferable: {
        V v_i_24222 = heff_field(v_x1_24221, 0);
        V v_ru_24x1_24221_24IsInferable = heff_take_reuse_n(v_x1_24221, 1ULL, 1);
        V v_t_24225;
        switch (heff_tag_of(v_i_24222)) {
        case TAG_At: {
          V v_s_24224 = heff_dup(heff_field(v_i_24222, 1));
          v_t_24225 = v_s_24224;
          break;
        }
        default: heff_nomatch(v_i_24222);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24221_24IsInferable, TAG_CInf, 1, (V[]){v_i_24222}), v_t_24225});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24226 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        v_t_24231 = v_c_24226;
        break;
      }
      case TAG_IsType: {
        V v_t_24227 = heff_field(v_x1_24221, 0);
        V v_ru_24x1_24221_24IsType = heff_take_reuse_n(v_x1_24221, 1ULL, 1);
        V v_t_24230;
        switch (heff_tag_of(v_t_24227)) {
        case TAG_At: {
          V v_s_24229 = heff_dup(heff_field(v_t_24227, 1));
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_t_24227);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24221_24IsType, TAG_CType, 1, (V[]){v_t_24227}), v_t_24230});
        break;
      }
      default: heff_nomatch(v_x1_24221);
      }
      V v_t_24234;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24233 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24234 = v_s_24233;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24231}), v_t_24234});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24236 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24246;
      switch (heff_tag_of(v_x1_24236)) {
      case TAG_IsInferable: {
        V v_i_24237 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24240;
        switch (heff_tag_of(v_i_24237)) {
        case TAG_At: {
          V v_s_24239 = heff_dup(heff_field(v_i_24237, 1));
          v_t_24240 = v_s_24239;
          break;
        }
        default: heff_nomatch(v_i_24237);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_CInf, 1, (V[]){v_i_24237}), v_t_24240});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24241 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ESig, 1);
        v_t_24246 = v_c_24241;
        break;
      }
      case TAG_IsType: {
        V v_t_24242 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24245;
        switch (heff_tag_of(v_t_24242)) {
        case TAG_At: {
          V v_s_24244 = heff_dup(heff_field(v_t_24242, 1));
          v_t_24245 = v_s_24244;
          break;
        }
        default: heff_nomatch(v_t_24242);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_CType, 1, (V[]){v_t_24242}), v_t_24245});
        break;
      }
      default: heff_nomatch(v_x1_24236);
      }
      V v_t_24249;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24248 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24249 = v_s_24248;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24246}), v_t_24249});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24261;
      switch (heff_tag_of(v_x1_24251)) {
      case TAG_IsInferable: {
        V v_i_24252 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24255;
        switch (heff_tag_of(v_i_24252)) {
        case TAG_At: {
          V v_s_24254 = heff_dup(heff_field(v_i_24252, 1));
          v_t_24255 = v_s_24254;
          break;
        }
        default: heff_nomatch(v_i_24252);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_CInf, 1, (V[]){v_i_24252}), v_t_24255});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24256 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ESum, 1);
        v_t_24261 = v_c_24256;
        break;
      }
      case TAG_IsType: {
        V v_t_24257 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24260;
        switch (heff_tag_of(v_t_24257)) {
        case TAG_At: {
          V v_s_24259 = heff_dup(heff_field(v_t_24257, 1));
          v_t_24260 = v_s_24259;
          break;
        }
        default: heff_nomatch(v_t_24257);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_CType, 1, (V[]){v_t_24257}), v_t_24260});
        break;
      }
      default: heff_nomatch(v_x1_24251);
      }
      V v_t_24264;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24263 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24264 = v_s_24263;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24261}), v_t_24264});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24266 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24276;
      switch (heff_tag_of(v_x1_24266)) {
      case TAG_IsInferable: {
        V v_i_24267 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24270;
        switch (heff_tag_of(v_i_24267)) {
        case TAG_At: {
          V v_s_24269 = heff_dup(heff_field(v_i_24267, 1));
          v_t_24270 = v_s_24269;
          break;
        }
        default: heff_nomatch(v_i_24267);
        }
        v_t_24276 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_CInf, 1, (V[]){v_i_24267}), v_t_24270});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24271 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EStruct, 1);
        v_t_24276 = v_c_24271;
        break;
      }
      case TAG_IsType: {
        V v_t_24272 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24275;
        switch (heff_tag_of(v_t_24272)) {
        case TAG_At: {
          V v_s_24274 = heff_dup(heff_field(v_t_24272, 1));
          v_t_24275 = v_s_24274;
          break;
        }
        default: heff_nomatch(v_t_24272);
        }
        v_t_24276 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_CType, 1, (V[]){v_t_24272}), v_t_24275});
        break;
      }
      default: heff_nomatch(v_x1_24266);
      }
      V v_t_24279;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24278 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24279 = v_s_24278;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24276}), v_t_24279});
    }
    case TAG_EUpdate: {
      V v_ru_24e1_242_24EUpdate = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24282 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24292;
      switch (heff_tag_of(v_x1_24282)) {
      case TAG_IsInferable: {
        V v_i_24283 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24286;
        switch (heff_tag_of(v_i_24283)) {
        case TAG_At: {
          V v_s_24285 = heff_dup(heff_field(v_i_24283, 1));
          v_t_24286 = v_s_24285;
          break;
        }
        default: heff_nomatch(v_i_24283);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24e1_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24283}), v_t_24286});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24287 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EUpdate, 2);
        v_t_24292 = v_c_24287;
        break;
      }
      case TAG_IsType: {
        V v_t_24288 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24291;
        switch (heff_tag_of(v_t_24288)) {
        case TAG_At: {
          V v_s_24290 = heff_dup(heff_field(v_t_24288, 1));
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_t_24288);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24e1_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24288}), v_t_24291});
        break;
      }
      default: heff_nomatch(v_x1_24282);
      }
      V v_t_24295;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24294 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24295 = v_s_24294;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24292}), v_t_24295});
    }
    case TAG_EMatch: {
      V v_ru_24e1_242_24EMatch = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24298 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24308;
      switch (heff_tag_of(v_x1_24298)) {
      case TAG_IsInferable: {
        V v_i_24299 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24302;
        switch (heff_tag_of(v_i_24299)) {
        case TAG_At: {
          V v_s_24301 = heff_dup(heff_field(v_i_24299, 1));
          v_t_24302 = v_s_24301;
          break;
        }
        default: heff_nomatch(v_i_24299);
        }
        v_t_24308 = heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24299}), v_t_24302});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24303 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EMatch, 2);
        v_t_24308 = v_c_24303;
        break;
      }
      case TAG_IsType: {
        V v_t_24304 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24307;
        switch (heff_tag_of(v_t_24304)) {
        case TAG_At: {
          V v_s_24306 = heff_dup(heff_field(v_t_24304, 1));
          v_t_24307 = v_s_24306;
          break;
        }
        default: heff_nomatch(v_t_24304);
        }
        v_t_24308 = heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24304}), v_t_24307});
        break;
      }
      default: heff_nomatch(v_x1_24298);
      }
      V v_t_24311;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24310 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24311 = v_s_24310;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24308}), v_t_24311});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_242_24ELetIn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24314 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24324;
      switch (heff_tag_of(v_x1_24314)) {
      case TAG_IsInferable: {
        V v_i_24315 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24318;
        switch (heff_tag_of(v_i_24315)) {
        case TAG_At: {
          V v_s_24317 = heff_dup(heff_field(v_i_24315, 1));
          v_t_24318 = v_s_24317;
          break;
        }
        default: heff_nomatch(v_i_24315);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24315}), v_t_24318});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24319 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELetIn, 2);
        v_t_24324 = v_c_24319;
        break;
      }
      case TAG_IsType: {
        V v_t_24320 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24323;
        switch (heff_tag_of(v_t_24320)) {
        case TAG_At: {
          V v_s_24322 = heff_dup(heff_field(v_t_24320, 1));
          v_t_24323 = v_s_24322;
          break;
        }
        default: heff_nomatch(v_t_24320);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24320}), v_t_24323});
        break;
      }
      default: heff_nomatch(v_x1_24314);
      }
      V v_t_24327;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24326 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24327 = v_s_24326;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24324}), v_t_24327});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24339;
      switch (heff_tag_of(v_x1_24329)) {
      case TAG_IsInferable: {
        V v_i_24330 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24333;
        switch (heff_tag_of(v_i_24330)) {
        case TAG_At: {
          V v_s_24332 = heff_dup(heff_field(v_i_24330, 1));
          v_t_24333 = v_s_24332;
          break;
        }
        default: heff_nomatch(v_i_24330);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_CInf, 1, (V[]){v_i_24330}), v_t_24333});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24334 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EDo, 1);
        v_t_24339 = v_c_24334;
        break;
      }
      case TAG_IsType: {
        V v_t_24335 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24338;
        switch (heff_tag_of(v_t_24335)) {
        case TAG_At: {
          V v_s_24337 = heff_dup(heff_field(v_t_24335, 1));
          v_t_24338 = v_s_24337;
          break;
        }
        default: heff_nomatch(v_t_24335);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_CType, 1, (V[]){v_t_24335}), v_t_24338});
        break;
      }
      default: heff_nomatch(v_x1_24329);
      }
      V v_t_24342;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24341 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24342 = v_s_24341;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24339}), v_t_24342});
    }
    case TAG_ELocal: {
      V v_ru_24e1_242_24ELocal = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24345 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24355;
      switch (heff_tag_of(v_x1_24345)) {
      case TAG_IsInferable: {
        V v_i_24346 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        V v_t_24349;
        switch (heff_tag_of(v_i_24346)) {
        case TAG_At: {
          V v_s_24348 = heff_dup(heff_field(v_i_24346, 1));
          v_t_24349 = v_s_24348;
          break;
        }
        default: heff_nomatch(v_i_24346);
        }
        v_t_24355 = heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24346}), v_t_24349});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24350 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELocal, 2);
        v_t_24355 = v_c_24350;
        break;
      }
      case TAG_IsType: {
        V v_t_24351 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        V v_t_24354;
        switch (heff_tag_of(v_t_24351)) {
        case TAG_At: {
          V v_s_24353 = heff_dup(heff_field(v_t_24351, 1));
          v_t_24354 = v_s_24353;
          break;
        }
        default: heff_nomatch(v_t_24351);
        }
        v_t_24355 = heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24351}), v_t_24354});
        break;
      }
      default: heff_nomatch(v_x1_24345);
      }
      V v_t_24358;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24357 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24358 = v_s_24357;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24355}), v_t_24358});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24360 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24370;
      switch (heff_tag_of(v_x1_24360)) {
      case TAG_IsInferable: {
        V v_i_24361 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        V v_t_24364;
        switch (heff_tag_of(v_i_24361)) {
        case TAG_At: {
          V v_s_24363 = heff_dup(heff_field(v_i_24361, 1));
          v_t_24364 = v_s_24363;
          break;
        }
        default: heff_nomatch(v_i_24361);
        }
        v_t_24370 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_CInf, 1, (V[]){v_i_24361}), v_t_24364});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24365 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EInvalid, 1);
        v_t_24370 = v_c_24365;
        break;
      }
      case TAG_IsType: {
        V v_t_24366 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        V v_t_24369;
        switch (heff_tag_of(v_t_24366)) {
        case TAG_At: {
          V v_s_24368 = heff_dup(heff_field(v_t_24366, 1));
          v_t_24369 = v_s_24368;
          break;
        }
        default: heff_nomatch(v_t_24366);
        }
        v_t_24370 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_CType, 1, (V[]){v_t_24366}), v_t_24369});
        break;
      }
      default: heff_nomatch(v_x1_24360);
      }
      V v_t_24373;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24372 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24373 = v_s_24372;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24370}), v_t_24373});
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_e_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24SetField = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetField, TAG_SetField, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_BadFieldSet: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldSet = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2418}));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2429}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetPath, TAG_SetPath, 2, (V[]){v_path_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts(V v_r_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x11_244 = heff_field(v_run_242, 0);
      V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x11_244, 0);
        V v_sp_246 = heff_field(v_x11_244, 1);
        V v_ru_24x11_244_24MkPair = heff_take_reuse_n(v_x11_244, 3ULL, 2);
        V v_t_247 = heff_tag_at_n(v_ru_24x11_244_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IBytes, 1, (V[]){v_s_245}), heff_dup(v_sp_246)});
        V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_247}), v_sp_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_acc_243});
      }
      default: return heff_nomatch(v_x11_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_249 = heff_field(v_x2_241, 0);
    V v_rest_2410 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_249)) {
    case TAG_At: {
      V v_seg_2411 = heff_field(v_x21_249, 0);
      V v_sp_2412 = heff_field(v_x21_249, 1);
      V v_ru_24x21_249_24At = heff_take_reuse_n(v_x21_249, 3ULL, 2);
      V v_t_2413 = (g_heff_2esyntax_2epresyntax_2ewholeSegment(v_seg_2411));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        V v_t_2414 = (g_heff_2esyntax_2epresyntax_2esegmentPart(heff_dup(v_r_240), heff_tag_at_n(v_ru_24x21_249_24At, TAG_At, 2, (V[]){v_seg_2411, v_sp_2412})));
        V v_t_2420;
        switch (heff_tag_of(v_run_242)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          v_t_2420 = v_acc_243;
          break;
        }
        case TAG_Just: {
          V v_x11_2415 = heff_field(v_run_242, 0);
          V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
          switch (heff_tag_of(v_x11_2415)) {
          case TAG_MkPair: {
            V v_s_2416 = heff_field(v_x11_2415, 0);
            V v_sp_2417 = heff_field(v_x11_2415, 1);
            V v_ru_24x11_2415_24MkPair = heff_take_reuse_n(v_x11_2415, 3ULL, 2);
            V v_t_2418 = heff_tag_at_n(v_ru_24x11_2415_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IBytes, 1, (V[]){v_s_2416}), heff_dup(v_sp_2417)});
            V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_2417});
            v_t_2420 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, v_acc_243});
            break;
          }
          default: heff_nomatch(v_x11_2415);
          }
          break;
        }
        default: heff_nomatch(v_run_242);
        }
        V t_0 = v_r_240;
        V t_1 = v_rest_2410;
        V t_2 = NTAG(TAG_Nothing);
        V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2420});
        v_r_240 = t_0;
        v_x2_241 = t_1;
        v_run_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      case TAG_Just: {
        V v_s_2421 = heff_field(v_t_2413, 0);
        V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_seg_2411);
        heff_drop_cell(v_ru_24x21_249_24At, 2);
        V v_t_2427;
        switch (heff_tag_of(v_run_242)) {
        case TAG_Nothing: {
          v_t_2427 = heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2421, v_sp_2412})});
          break;
        }
        case TAG_Just: {
          V v_x11_2422 = heff_field(v_run_242, 0);
          heff_take_n(v_run_242, 1ULL, 1);
          switch (heff_tag_of(v_x11_2422)) {
          case TAG_MkPair: {
            V v_s0_2423 = heff_field(v_x11_2422, 0);
            V v_sp0_2424 = heff_field(v_x11_2422, 1);
            V v_ru_24x11_2422_24MkPair = heff_take_reuse_n(v_x11_2422, 3ULL, 2);
            V v_t_2425 = ({ V rv_1 = heff_get_n(v_sp_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2426 = heff_tag_at_n(v_ru_24x11_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2423, v_s_2421), v_t_2425});
            v_t_2427 = heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){v_t_2426});
            break;
          }
          default: heff_nomatch(v_x11_2422);
          }
          break;
        }
        default: heff_nomatch(v_run_242);
        }
        V t_0 = v_r_240;
        V t_1 = v_rest_2410;
        V t_2 = v_t_2427;
        V t_3 = v_acc_243;
        v_r_240 = t_0;
        v_x2_241 = t_1;
        v_run_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x21_249);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryWith_str0, 11, "bytesConcat");
Clo g_heff_2esyntax_2epresyntax_2ebinaryWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryWith_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryWith(V v_r_240, V v_segs_241, V v_sp_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebinaryWith_str0)}), heff_dup(v_sp_242)});
    V v_xs_245 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_r_240, v_segs_241, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_246, heff_dup(v_sp_242)));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_244, v_t_249}), v_sp_242});
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2410});
  }
  case TAG_Just: {
    V v_s_2411 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_segs_241);
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24Just, TAG_IBytes, 1, (V[]){v_s_2411}), v_sp_242});
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryWith(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclEquations = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2419;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_IsInferable: {
        V v_i_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_i_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_i_2410);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2410}), v_t_2413});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2414 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_c_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_c_2414);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
        break;
      }
      case TAG_IsType: {
        V v_t_2418 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2419 = v_t_2418;
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eequationOf_clo), 1, (V[]){v_r_240}));
      V v_t_2421 = (g_list_2emap(v_t_2420, v_eqs_248));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_2419, v_t_2421}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2422 = heff_field(v_x21_242, 0);
      V v_xsp_2423 = heff_field(v_x21_242, 1);
      V v_ps_2424 = heff_field(v_x21_242, 2);
      V v_u_2425 = heff_field(v_x21_242, 3);
      V v_body_2426 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclDefine = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eparamOf_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2428 = (g_list_2emap(v_t_2427, v_ps_2424));
      V v_x1_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2425}));
      V v_t_2439;
      switch (heff_tag_of(v_x1_2429)) {
      case TAG_IsInferable: {
        V v_i_2430 = heff_field(v_x1_2429, 0);
        heff_take_n(v_x1_2429, 1ULL, 1);
        V v_t_2433;
        switch (heff_tag_of(v_i_2430)) {
        case TAG_At: {
          V v_s_2432 = heff_dup(heff_field(v_i_2430, 1));
          v_t_2433 = v_s_2432;
          break;
        }
        default: heff_nomatch(v_i_2430);
        }
        v_t_2439 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2430}), v_t_2433});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2434 = heff_field(v_x1_2429, 0);
        heff_take_n(v_x1_2429, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_c_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_c_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_c_2434);
        }
        v_t_2439 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2434}), v_t_2437});
        break;
      }
      case TAG_IsType: {
        V v_t_2438 = heff_field(v_x1_2429, 0);
        heff_take_n(v_x1_2429, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2439 = v_t_2438;
        break;
      }
      default: heff_nomatch(v_x1_2429);
      }
      V v_x1_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2426}));
      V v_t_2450;
      switch (heff_tag_of(v_x1_2440)) {
      case TAG_IsInferable: {
        V v_i_2441 = heff_field(v_x1_2440, 0);
        V v_ru_24x1_2440_24IsInferable = heff_take_reuse_n(v_x1_2440, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_i_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_i_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_i_2441);
        }
        v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2440_24IsInferable, TAG_CInf, 1, (V[]){v_i_2441}), v_t_2444});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2445 = heff_field(v_x1_2440, 0);
        heff_take_n(v_x1_2440, 1ULL, 1);
        v_t_2450 = v_c_2445;
        break;
      }
      case TAG_IsType: {
        V v_t_2446 = heff_field(v_x1_2440, 0);
        V v_ru_24x1_2440_24IsType = heff_take_reuse_n(v_x1_2440, 1ULL, 1);
        V v_t_2449;
        switch (heff_tag_of(v_t_2446)) {
        case TAG_At: {
          V v_s_2448 = heff_dup(heff_field(v_t_2446, 1));
          v_t_2449 = v_s_2448;
          break;
        }
        default: heff_nomatch(v_t_2446);
        }
        v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2440_24IsType, TAG_CType, 1, (V[]){v_t_2446}), v_t_2449});
        break;
      }
      default: heff_nomatch(v_x1_2440);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2422, v_xsp_2423, v_t_2428, v_t_2439, v_t_2450}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2451 = heff_field(v_x21_242, 0);
      V v_xsp_2452 = heff_field(v_x21_242, 1);
      V v_ps_2453 = heff_field(v_x21_242, 2);
      V v_body_2454 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclTheory = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eparamOf_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2456 = (g_list_2emap(v_t_2455, v_ps_2453));
      V v_x1_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2454}));
      V v_t_2467;
      switch (heff_tag_of(v_x1_2457)) {
      case TAG_IsInferable: {
        V v_i_2458 = heff_field(v_x1_2457, 0);
        heff_take_n(v_x1_2457, 1ULL, 1);
        V v_t_2461;
        switch (heff_tag_of(v_i_2458)) {
        case TAG_At: {
          V v_s_2460 = heff_dup(heff_field(v_i_2458, 1));
          v_t_2461 = v_s_2460;
          break;
        }
        default: heff_nomatch(v_i_2458);
        }
        v_t_2467 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2458}), v_t_2461});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2462 = heff_field(v_x1_2457, 0);
        heff_take_n(v_x1_2457, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2467 = v_c_2462;
        break;
      }
      case TAG_IsType: {
        V v_t_2463 = heff_field(v_x1_2457, 0);
        heff_take_n(v_x1_2457, 1ULL, 1);
        V v_t_2466;
        switch (heff_tag_of(v_t_2463)) {
        case TAG_At: {
          V v_s_2465 = heff_dup(heff_field(v_t_2463, 1));
          v_t_2466 = v_s_2465;
          break;
        }
        default: heff_nomatch(v_t_2463);
        }
        v_t_2467 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2463}), v_t_2466});
        break;
      }
      default: heff_nomatch(v_x1_2457);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2451, v_xsp_2452, v_t_2456, v_t_2467}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2468 = heff_field(v_x21_242, 0);
      V v_xsp_2469 = heff_field(v_x21_242, 1);
      V v_t_2470 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24DeclPrimitive = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2470}));
      V v_t_2481;
      switch (heff_tag_of(v_x1_2471)) {
      case TAG_IsInferable: {
        V v_i_2472 = heff_field(v_x1_2471, 0);
        heff_take_n(v_x1_2471, 1ULL, 1);
        V v_t_2475;
        switch (heff_tag_of(v_i_2472)) {
        case TAG_At: {
          V v_s_2474 = heff_dup(heff_field(v_i_2472, 1));
          v_t_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_i_2472);
        }
        v_t_2481 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2472}), v_t_2475});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2476 = heff_field(v_x1_2471, 0);
        heff_take_n(v_x1_2471, 1ULL, 1);
        V v_t_2479;
        switch (heff_tag_of(v_c_2476)) {
        case TAG_At: {
          V v_s_2478 = heff_dup(heff_field(v_c_2476, 1));
          v_t_2479 = v_s_2478;
          break;
        }
        default: heff_nomatch(v_c_2476);
        }
        v_t_2481 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2476}), v_t_2479});
        break;
      }
      case TAG_IsType: {
        V v_t_2480 = heff_field(v_x1_2471, 0);
        heff_take_n(v_x1_2471, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2481 = v_t_2480;
        break;
      }
      default: heff_nomatch(v_x1_2471);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2468, v_xsp_2469, v_t_2481}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2482 = heff_field(v_x21_242, 0);
      V v_xsp_2483 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_rec(v_r_240, 2);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2482, v_xsp_2483}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2484 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2485 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2484}));
      V v_t_2486 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2485));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_2486}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460(V v_x2_240, V v_run_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_241)) {
    case TAG_Nothing: {
      return v_acc_242;
    }
    case TAG_Just: {
      V v_x11_243 = heff_field(v_run_241, 0);
      V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkPair: {
        V v_s_244 = heff_field(v_x11_243, 0);
        V v_sp_245 = heff_field(v_x11_243, 1);
        V v_ru_24x11_243_24MkPair = heff_take_reuse_n(v_x11_243, 3ULL, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24x11_243_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_244}), heff_dup(v_sp_245)});
        V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), v_sp_245});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_run_241);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_240, 0);
    V v_rest_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment(v_seg_2410));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        V v_t_2413 = (g_heff_2esyntax_2epresyntax_2esegmentPart_24s1720849450x1239647835(heff_tag_at_n(v_ru_24x21_248_24At, TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})));
        V v_t_2419;
        switch (heff_tag_of(v_run_241)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          v_t_2419 = v_acc_242;
          break;
        }
        case TAG_Just: {
          V v_x11_2414 = heff_field(v_run_241, 0);
          V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
          switch (heff_tag_of(v_x11_2414)) {
          case TAG_MkPair: {
            V v_s_2415 = heff_field(v_x11_2414, 0);
            V v_sp_2416 = heff_field(v_x11_2414, 1);
            V v_ru_24x11_2414_24MkPair = heff_take_reuse_n(v_x11_2414, 3ULL, 2);
            V v_t_2417 = heff_tag_at_n(v_ru_24x11_2414_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_2415}), heff_dup(v_sp_2416)});
            V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_2416});
            v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, v_acc_242});
            break;
          }
          default: heff_nomatch(v_x11_2414);
          }
          break;
        }
        default: heff_nomatch(v_run_241);
        }
        V t_0 = v_rest_249;
        V t_1 = NTAG(TAG_Nothing);
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2419});
        v_x2_240 = t_0;
        v_run_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      case TAG_Just: {
        V v_s_2420 = heff_field(v_t_2412, 0);
        V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_seg_2410);
        heff_drop_cell(v_ru_24x21_248_24At, 2);
        V v_t_2426;
        switch (heff_tag_of(v_run_241)) {
        case TAG_Nothing: {
          v_t_2426 = heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2420, v_sp_2411})});
          break;
        }
        case TAG_Just: {
          V v_x11_2421 = heff_field(v_run_241, 0);
          heff_take_n(v_run_241, 1ULL, 1);
          switch (heff_tag_of(v_x11_2421)) {
          case TAG_MkPair: {
            V v_s0_2422 = heff_field(v_x11_2421, 0);
            V v_sp0_2423 = heff_field(v_x11_2421, 1);
            V v_ru_24x11_2421_24MkPair = heff_take_reuse_n(v_x11_2421, 3ULL, 2);
            V v_t_2424 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2425 = heff_tag_at_n(v_ru_24x11_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2422, v_s_2420), v_t_2424});
            v_t_2426 = heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Just, 1, (V[]){v_t_2425});
            break;
          }
          default: heff_nomatch(v_x11_2421);
          }
          break;
        }
        default: heff_nomatch(v_run_241);
        }
        V t_0 = v_rest_249;
        V t_1 = v_t_2426;
        V t_2 = v_acc_242;
        v_x2_240 = t_0;
        v_run_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_str0, 11, "bytesConcat");
Clo g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051(V v_segs_240, V v_sp_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_str0)}), heff_dup(v_sp_241)});
    V v_xs_244 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1955062250x751333460(v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_245, heff_dup(v_sp_241)));
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_246}), heff_dup(v_sp_241)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_243, v_t_248}), v_sp_241});
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_249});
  }
  case TAG_Just: {
    V v_s_2410 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24Just = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_segs_240);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24Just, TAG_IBytes, 1, (V[]){v_s_2410}), v_sp_241});
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str1, 22, "`Array` takes one type");
Clo g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(V v_h_240, V v_args_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_243 = heff_dup(heff_field(v_h_240, 0));
    V v_tsp_244 = heff_dup(heff_field(v_h_240, 1));
    switch (heff_tag_of(v_h1_243)) {
    case TAG_EVar: {
      V v_ru_24h1_243_24EVar = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_247 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_246));
      V v_t_248 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_248}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EVar, TAG_IsInferable, 1, (V[]){v_t_249});
    }
    case TAG_EImplicitVar: {
      V v_ru_24h1_243_24EImplicitVar = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2411));
      V v_t_2413 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_2414});
    }
    case TAG_ETag: {
      V v_t_2415 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24ETag = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      heff_drop_tag(v_h_240, 2);
      V v_t_2416 = (g_list_2emap_24s1844509821x2028168277(v_args_241));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_2415, v_tsp_244, v_t_2416}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2417});
    }
    case TAG_EInt: {
      V v_ru_24h1_243_24EInt = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2420 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2419));
      V v_t_2421 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2420, v_t_2421}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EInt, TAG_IsInferable, 1, (V[]){v_t_2422});
    }
    case TAG_EFloat: {
      V v_ru_24h1_243_24EFloat = heff_take_reuse_na(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2424));
      V v_t_2426 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2425, v_t_2426}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2427});
    }
    case TAG_EString: {
      V v_ru_24h1_243_24EString = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2429 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2429));
      V v_t_2431 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2431}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EString, TAG_IsInferable, 1, (V[]){v_t_2432});
    }
    case TAG_EBinary: {
      V v_ru_24h1_243_24EBinary = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2434));
      V v_t_2436 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2435, v_t_2436}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EBinary, TAG_IsInferable, 1, (V[]){v_t_2437});
    }
    case TAG_ERune: {
      V v_ru_24h1_243_24ERune = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2439 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2439));
      V v_t_2441 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2440, v_t_2441}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24ERune, TAG_IsInferable, 1, (V[]){v_t_2442});
    }
    case TAG_EWord: {
      V v_h11_2443 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24EWord = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      heff_drop(v_tsp_244);
      switch (heff_tag_of(v_h11_2443)) {
      case TAG_TypeWord: {
        V v_t_2444 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2445 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2444));
        V v_t_2446 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
        V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2445, v_t_2446}), v_sp_242});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){v_t_2447});
      }
      case TAG_IntWord: {
        V v_t_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2449 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2448));
        V v_t_2450 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
        V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2449, v_t_2450}), v_sp_242});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){v_t_2451});
      }
      case TAG_FloatWord: {
        V v_t_2452 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2453 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2452));
        V v_t_2454 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
        V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2453, v_t_2454}), v_sp_242});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){v_t_2455});
      }
      case TAG_StringWord: {
        V v_t_2456 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2457 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2456));
        V v_t_2458 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
        V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2457, v_t_2458}), v_sp_242});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){v_t_2459});
      }
      case TAG_RuneWord: {
        V v_t_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2461 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2460));
        V v_t_2462 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
        V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2461, v_t_2462}), v_sp_242});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){v_t_2463});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_240, 2);
        switch (heff_tag_of(v_args_241)) {
        case TAG_Nil: {
          V v_t_2464 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str0), NTAG(TAG_Nothing)});
          V v_t_2465 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2464, heff_dup(v_sp_242)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2465, v_sp_242})});
        }
        case TAG_Cons: {
          V v_a_2466 = heff_field(v_args_241, 0);
          V v_args2_2467 = heff_field(v_args_241, 1);
          V v_ru_24args_241_24Cons = heff_take_reuse_n(v_args_241, 3ULL, 2);
          switch (heff_tag_of(v_args2_2467)) {
          case TAG_Nil: {
            V v_x1_2468 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_2466));
            V v_t_2478;
            switch (heff_tag_of(v_x1_2468)) {
            case TAG_IsInferable: {
              V v_i_2469 = heff_field(v_x1_2468, 0);
              heff_take_n(v_x1_2468, 1ULL, 1);
              V v_t_2472;
              switch (heff_tag_of(v_i_2469)) {
              case TAG_At: {
                V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
                v_t_2472 = v_s_2471;
                break;
              }
              default: heff_nomatch(v_i_2469);
              }
              v_t_2478 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2473 = heff_field(v_x1_2468, 0);
              heff_take_n(v_x1_2468, 1ULL, 1);
              V v_t_2476;
              switch (heff_tag_of(v_c_2473)) {
              case TAG_At: {
                V v_s_2475 = heff_dup(heff_field(v_c_2473, 1));
                v_t_2476 = v_s_2475;
                break;
              }
              default: heff_nomatch(v_c_2473);
              }
              v_t_2478 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TChk, 1, (V[]){v_c_2473}), v_t_2476});
              break;
            }
            case TAG_IsType: {
              V v_t_2477 = heff_field(v_x1_2468, 0);
              heff_take_n(v_x1_2468, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_243_24EWord, 1);
              heff_drop_cell(v_ru_24args_241_24Cons, 2);
              v_t_2478 = v_t_2477;
              break;
            }
            default: heff_nomatch(v_x1_2468);
            }
            V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2478}), v_sp_242});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2479});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2467, 0ULL, 2);
            heff_drop(v_a_2466);
            V v_t_2482 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str1), NTAG(TAG_Nothing)});
            V v_t_2483 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2482, heff_dup(v_sp_242)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_t_2483, v_sp_242})});
          }
          default: return heff_nomatch(v_args2_2467);
          }
        }
        default: return heff_nomatch(v_args_241);
        }
      }
      case TAG_AbandonWord: {
        V v_t_2484 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2485 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2484));
        V v_t_2486 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
        V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2485, v_t_2486}), v_sp_242});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){v_t_2487});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2443, 0ULL, 1);
        V v_t_2489 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2490 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2489));
        V v_t_2491 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
        V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2490, v_t_2491}), v_sp_242});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){v_t_2492});
      }
      default: return heff_nomatch(v_h11_2443);
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_243_24EApp = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2495 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2496 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2495));
      V v_t_2497 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_2498 = heff_tag_at_n(v_ru_24h1_243_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2496, v_t_2497}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2498});
    }
    case TAG_EProject: {
      V v_ru_24h1_243_24EProject = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24100 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24101 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24100));
      V v_t_24102 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24101, v_t_24102}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EProject, TAG_IsInferable, 1, (V[]){v_t_24103});
    }
    case TAG_ENamed: {
      V v_ru_24h1_243_24ENamed = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24106 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24107 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24106));
      V v_t_24108 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24109 = heff_tag_at_n(v_ru_24h1_243_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24107, v_t_24108}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24109});
    }
    case TAG_EPi: {
      V v_ru_24h1_243_24EPi = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24112 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24113 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24112));
      V v_t_24114 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24115 = heff_tag_at_n(v_ru_24h1_243_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24113, v_t_24114}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24115});
    }
    case TAG_ELam: {
      V v_ru_24h1_243_24ELam = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24119 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24118));
      V v_t_24120 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24121 = heff_tag_at_n(v_ru_24h1_243_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24119, v_t_24120}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24121});
    }
    case TAG_EAnn: {
      V v_ru_24h1_243_24EAnn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24124 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24125 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24124));
      V v_t_24126 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24127 = heff_tag_at_n(v_ru_24h1_243_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24125, v_t_24126}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24127});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_243, 0ULL, 4);
      heff_drop(v_tsp_244);
      V v_t_24132 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24133 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24132));
      V v_t_24134 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24133, v_t_24134}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24135});
    }
    case TAG_ESig: {
      V v_ru_24h1_243_24ESig = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24137 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24138 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24137));
      V v_t_24139 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24140 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24138, v_t_24139}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24ESig, TAG_IsInferable, 1, (V[]){v_t_24140});
    }
    case TAG_ESum: {
      V v_ru_24h1_243_24ESum = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24142 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24143 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24142));
      V v_t_24144 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24145 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24144}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24ESum, TAG_IsInferable, 1, (V[]){v_t_24145});
    }
    case TAG_EStruct: {
      V v_ru_24h1_243_24EStruct = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24147 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24148 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24147));
      V v_t_24149 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24150 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24148, v_t_24149}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EStruct, TAG_IsInferable, 1, (V[]){v_t_24150});
    }
    case TAG_EUpdate: {
      V v_ru_24h1_243_24EUpdate = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24153 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24154 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24153));
      V v_t_24155 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24156 = heff_tag_at_n(v_ru_24h1_243_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24154, v_t_24155}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24156});
    }
    case TAG_EMatch: {
      V v_ru_24h1_243_24EMatch = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24159 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24160 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24159));
      V v_t_24161 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24162 = heff_tag_at_n(v_ru_24h1_243_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24160, v_t_24161}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24162});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_243_24ELetIn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24165 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24166 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24165));
      V v_t_24167 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24168 = heff_tag_at_n(v_ru_24h1_243_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24166, v_t_24167}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24168});
    }
    case TAG_EDo: {
      V v_ru_24h1_243_24EDo = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24170 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24171 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24170));
      V v_t_24172 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24173 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24171, v_t_24172}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EDo, TAG_IsInferable, 1, (V[]){v_t_24173});
    }
    case TAG_ELocal: {
      V v_ru_24h1_243_24ELocal = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24176 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24177 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24176));
      V v_t_24178 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24179 = heff_tag_at_n(v_ru_24h1_243_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24177, v_t_24178}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24179});
    }
    case TAG_EInvalid: {
      V v_ru_24h1_243_24EInvalid = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24181 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24182 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24181));
      V v_t_24183 = (g_list_2emap_24s1688457226x2006118782(v_args_241));
      V v_t_24184 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24182, v_t_24183}), v_sp_242});
      return heff_tag_at_n(v_ru_24h1_243_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24184});
    }
    default: return heff_nomatch(v_h1_243);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24SetField = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_245));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetField, TAG_SetField, 3, (V[]){v_x_243, v_xsp_244, v_t_2416}), v_sp_242});
    }
    case TAG_BadFieldSet: {
      V v_e_2417 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldSet = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_2418 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2417));
      V v_t_2428;
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_IsInferable: {
        V v_i_2419 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2422;
        switch (heff_tag_of(v_i_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_i_2419);
        }
        v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2423 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2428 = v_c_2423;
        break;
      }
      case TAG_IsType: {
        V v_t_2424 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2427;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_t_2424, 1));
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2424}), v_t_2427});
        break;
      }
      default: heff_nomatch(v_x1_2418);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2428}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ExplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_245));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_c_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_c_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_c_2411);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2411}), v_t_2414});
        break;
      }
      case TAG_IsType: {
        V v_t_2415 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2416 = v_t_2415;
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_243, v_xsp_244, v_t_2416}), v_sp_242});
    }
    case TAG_ImplicitParam: {
      V v_x_2417 = heff_field(v_x21_241, 0);
      V v_xsp_2418 = heff_field(v_x21_241, 1);
      V v_t_2419 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ImplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_2420 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2419));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2417, v_xsp_2418, v_t_2430}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(a[0]);
}

static V g_heff_2esyntax_2epresyntax_2eclassify_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassify_st;
static V g_heff_2esyntax_2epresyntax_2eclassify_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo);
}
V g_heff_2esyntax_2epresyntax_2eclassify_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassify_st)) return g_heff_2esyntax_2epresyntax_2eclassify_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassify_val, &g_heff_2esyntax_2epresyntax_2eclassify_st, g_heff_2esyntax_2epresyntax_2eclassify_init);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclareField: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_d_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclareField = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_t_243, 0);
      V v_sp_246 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_244)) {
    case TAG_Nothing: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_d_244, 0);
      V v_ru_24d_244_24Just = heff_take_reuse_n(v_d_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_n_249 = heff_field(v_x_248, 0);
        V v_sp_2410 = heff_field(v_x_248, 1);
        V v_ru_24x_248_24At = heff_take_reuse_n(v_x_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_249));
        v_t_2412 = heff_tag_at_n(v_ru_24x_248_24At, TAG_At, 2, (V[]){v_t_2411, v_sp_2410});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24d_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_241, v_sp_242, v_t_247, v_t_2413});
  }
  case TAG_BadFieldDecl: {
    V v_e_2414 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24BadFieldDecl = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_e_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_e_2414, 0);
      V v_sp_2416 = heff_field(v_e_2414, 1);
      heff_take_n(v_e_2414, 3ULL, 2);
      v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2416, v_n_2415));
      break;
    }
    default: heff_nomatch(v_e_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(v_b_241));
    V v_t_246;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_cod_242, 0);
      V v_sp_245 = heff_field(v_cod_242, 1);
      heff_take_n(v_cod_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at_n(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_243, v_t_246});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_248 = (g_list_2emap_24s1992667171x110340492(v_fs_247));
    return heff_tag_at_n(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){v_t_248});
  }
  case TAG_TSum: {
    V v_vs_249 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2410 = (g_list_2emap_24s513391942x823299088(v_vs_249));
    return heff_tag_at_n(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){v_t_2410});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TRune: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_2411 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_a_2411, 0);
      V v_sp_2413 = heff_field(v_a_2411, 1);
      heff_take_n(v_a_2411, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    return heff_tag_at_n(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2414});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2416 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_i_2416)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_i_2416, 0);
      V v_sp_2418 = heff_field(v_i_2416, 1);
      V v_ru_24i_2416_24At = heff_take_reuse_n(v_i_2416, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24i_2416_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_i_2416);
    }
    return heff_tag_at_n(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2420});
  }
  case TAG_TChk: {
    V v_c_2421 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2425;
    switch (heff_tag_of(v_c_2421)) {
    case TAG_At: {
      V v_n_2422 = heff_field(v_c_2421, 0);
      V v_sp_2423 = heff_field(v_c_2421, 1);
      V v_ru_24c_2421_24At = heff_take_reuse_n(v_c_2421, 3ULL, 2);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2422));
      v_t_2425 = heff_tag_at_n(v_ru_24c_2421_24At, TAG_At, 2, (V[]){v_t_2424, v_sp_2423});
      break;
    }
    default: heff_nomatch(v_c_2421);
    }
    return heff_tag_at_n(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2425});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
      v_t_245 = heff_tag_at_n(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at_n(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      heff_take_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2438 = (g_list_2emap_24s79542405x478516404(v_args_2437));
    return heff_tag_at_n(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, v_t_2438});
  }
  case TAG_CStruct: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1729787689x465380098(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){v_t_2440});
  }
  case TAG_CMatch: {
    V v_sc_2441 = heff_field(v_n_240, 0);
    V v_alts_2442 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_sc_2441)) {
    case TAG_At: {
      V v_n_2443 = heff_field(v_sc_2441, 0);
      V v_sp_2444 = heff_field(v_sc_2441, 1);
      V v_ru_24sc_2441_24At = heff_take_reuse_n(v_sc_2441, 3ULL, 2);
      V v_t_2445 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2443));
      v_t_2446 = heff_tag_at_n(v_ru_24sc_2441_24At, TAG_At, 2, (V[]){v_t_2445, v_sp_2444});
      break;
    }
    default: heff_nomatch(v_sc_2441);
    }
    V v_t_2447 = (g_list_2emap_24s244350250x1728178626(v_alts_2442));
    return heff_tag_at_n(v_ru_24n_240_24CMatch, TAG_CMatch, 2, (V[]){v_t_2446, v_t_2447});
  }
  case TAG_CLetIn: {
    V v_rhs_2448 = heff_field(v_n_240, 0);
    V v_alt_2449 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2453;
    switch (heff_tag_of(v_rhs_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_rhs_2448, 0);
      V v_sp_2451 = heff_field(v_rhs_2448, 1);
      V v_ru_24rhs_2448_24At = heff_take_reuse_n(v_rhs_2448, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24rhs_2448_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_rhs_2448);
    }
    V v_t_2463;
    switch (heff_tag_of(v_alt_2449)) {
    case TAG_At: {
      V v_x_2454 = heff_field(v_alt_2449, 0);
      V v_sp_2455 = heff_field(v_alt_2449, 1);
      V v_ru_24alt_2449_24At = heff_take_reuse_n(v_alt_2449, 3ULL, 2);
      V v_t_2462;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_MkAlt: {
        V v_p_2456 = heff_field(v_x_2454, 0);
        V v_b_2457 = heff_field(v_x_2454, 1);
        V v_ru_24x_2454_24MkAlt = heff_take_reuse_n(v_x_2454, 3ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_b_2457)) {
        case TAG_At: {
          V v_n_2458 = heff_field(v_b_2457, 0);
          V v_sp_2459 = heff_field(v_b_2457, 1);
          heff_take_n(v_b_2457, 3ULL, 2);
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2458));
          v_t_2461 = heff_tag_at_n(v_ru_24alt_2449_24At, TAG_At, 2, (V[]){v_t_2460, v_sp_2459});
          break;
        }
        default: heff_nomatch(v_b_2457);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x_2454_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2456, v_t_2461});
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_alt_2449);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2453, v_t_2463});
  }
  case TAG_CLocal: {
    V v_body_2464 = heff_field(v_n_240, 0);
    V v_ds_2465 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_body_2464)) {
    case TAG_At: {
      V v_n_2466 = heff_field(v_body_2464, 0);
      V v_sp_2467 = heff_field(v_body_2464, 1);
      V v_ru_24body_2464_24At = heff_take_reuse_n(v_body_2464, 3ULL, 2);
      V v_t_2468 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2466));
      v_t_2469 = heff_tag_at_n(v_ru_24body_2464_24At, TAG_At, 2, (V[]){v_t_2468, v_sp_2467});
      break;
    }
    default: heff_nomatch(v_body_2464);
    }
    V v_t_2470 = (g_list_2emap_24s386875578x1005587669(v_ds_2465));
    return heff_tag_at_n(v_ru_24n_240_24CLocal, TAG_CLocal, 2, (V[]){v_t_2469, v_t_2470});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IVar: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_244 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_IInt: {
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_247 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_IFloat: {
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2410 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_IString: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_IBytes: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2416 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_240});
  }
  case TAG_IPrim: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_IRune: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_IApp: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2426 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_sp_240});
  }
  case TAG_IAnn: {
    V v_c_2427 = heff_field(v_n_241, 0);
    V v_t_2428 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_2431;
    switch (heff_tag_of(v_c_2427)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_c_2427, 0);
      V v_sp_2430 = heff_field(v_c_2427, 1);
      heff_take_n(v_c_2427, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_c_2427);
    }
    V v_t_2434;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_t_2428, 0);
      V v_sp_2433 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2434 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2433, v_n_2432));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IAnn, TAG_IAnn, 2, (V[]){v_t_2431, v_t_2434}), v_sp_240});
  }
  case TAG_ISpec: {
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2440 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2439, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_240});
  }
  case TAG_IUpdate: {
    V v_t_2443 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2444 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_sp_240});
  }
  case TAG_IAnnLam: {
    V v_t_2449 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2450 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2449, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2450, v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2451 = heff_field(v_n_241, 0);
    V v_why_2452 = heff_field(v_n_241, 1);
    V v_note_2453 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 7ULL, 3);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IInvalid, TAG_IInvalid, 3, (V[]){v_code_2451, v_why_2452, v_note_2453}), v_sp_240});
  }
  case TAG_INominal: {
    V v_t_2455 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2456 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2455, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2456, v_sp_240});
  }
  case TAG_ILitEq: {
    V v_t_2461 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2462 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2461, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(a[0], a[1]);
}