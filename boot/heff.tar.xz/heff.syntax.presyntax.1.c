// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo;
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate(V, V, V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_clo;
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(V, V, V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_clo;
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240(V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivingLoop_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etryScope(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_clo;
V g_heff_2esyntax_2epresyntax_2etryT(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryT_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240_clo;
V g_heff_2esyntax_2epresyntax_2ewithScopeOf(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo;
V g_heff_2esyntax_2epresyntax_2ewithT_24tok2(V, V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithT_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithT_24tok2_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SetField: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_xsp_246 = heff_field(v_x31_243, 1);
      V v_e_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_248 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_247}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x1_248, 0);
        V v_y_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_x_245, v_xsp_246, v_y_2410}), v_sp_244});
        return ((HeffT2){{v_x_249, v_t_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
      }
    }
    case TAG_BadFieldSet: {
      V v_e_2412 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_x1_2413 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2412}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        V v_y_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_y_2415}), v_sp_244});
        return ((HeffT2){{v_x_2414, v_t_2416}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_244;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_244 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      v_st_244 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_x_242)));
    }
    HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_st_244, v_xs_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      V v_y_249 = v_field_247;
      return ((HeffT2){{v_x_248, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_y_249})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_StmtBind: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLet: {
        heff_take_n(v_x111_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtExpr: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLetMut: {
        V v_x_2411 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 3);
        V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
        V v_u_2415 = (g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(v_rest_242, heff_dup(v_cell_2414)));
        heff_drop(v_u_2415);
        return v_cell_2414;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclaredMuts(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_str1, 6, "MkUnit");
V g_heff_2esyntax_2epresyntax_2ewhileGiving_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving(V v_t_240, V v_cx_241, V v_sp_242, V v_c_243, V v_body_244, V v_rest_245, V v_end_246) {
top: ;
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240(heff_dup(v_c_243), v_body_244));
  HeffT4 v_t_248 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr(heff_dup(v_sp_242), heff_dup(v_cx_241)));
  V v_t_2418;
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    heff_drop(v_t_248.f[3]);
    V v_vars_2413 = v_field_2410;
    V v_t_2417;
    if ((heff_dup(v_field_2411) == NTAG(TAG_True))) {
      heff_drop(v_field_2411);
      switch (heff_tag_of(v_vars_2413)) {
      case TAG_Nil: {
        V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_str0)}), heff_dup(v_sp_242)});
        v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2417 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2413));
        break;
      }
      default: heff_nomatch(v_vars_2413);
      }
    } else {
      heff_drop(v_field_2411);
      v_t_2417 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2413));
    }
    v_t_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_field_249, v_t_2417));
  }
  V v_t_2419 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_cx_241); V a_2 = heff_dup(v_sp_242); V a_3 = v_t_247; V a_4 = v_t_2418; V a_5 = v_t_2419; V a_6 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ewhileGiving_lam0, 1, 5, (V[]){v_cx_241, v_c_243, v_body_244, v_sp_242, v_t_240}); V a_7 = v_rest_245; V a_8 = v_end_246; V r_ = (g_heff_2esyntax_2epresyntax_2egivingLoop(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_247); r_; });
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewhileGiving(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_lam0(V self, V *args) {
  V v_exitJ_2420 = args[0];
  V v_cx_241 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  V v_t_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_cx_2421 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(heff_dup(v_cx_241), heff_dup(v_c_243), v_body_244));
  V v_t_2422 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_2421, 1)), NTAG(TAG_False)});
  HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_2421), v_t_2422}), NTAG(TAG_Nil), heff_dup(v_c_243)));
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_x_2426 = v_field_2424;
    V v_y_2427 = v_field_2425;
    V v_cx_2428 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(heff_dup(v_cx_241), v_c_243, v_body_244));
    V v_names_2429 = heff_take_field(v_cx_2428, 0);
    V v_muts_2430 = heff_take_field(v_cx_2428, 1);
    V v_sp_2431 = heff_take_field(v_cx_2428, 3);
    V v_depth_2432 = heff_take_field(v_cx_2428, 4);
    V v_giving_2433 = heff_get_n(v_cx_2428, 5, 6);
    V v_cont_2434 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_cont_2434, heff_dup(v_exitJ_2420)})});
    V v_t_2436 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242(heff_dup(v_sp_242), v_cx_241));
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){v_names_2429, v_muts_2430, v_t_2435, v_sp_2431, v_depth_2432, v_giving_2433}), v_body_244, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2436})}));
    V v_vars_2438 = heff_take_field(v_exitJ_2420, 1);
    V v_t_2439 = heff_take_field(v_exitJ_2420, 2);
    V v_t_2443;
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      switch (heff_tag_of(v_vars_2438)) {
      case TAG_Nil: {
        V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_str1)}), heff_dup(v_sp_242)});
        v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2443 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2438));
        break;
      }
      default: heff_nomatch(v_vars_2438);
      }
    } else {
      heff_drop(v_t_2439);
      v_t_2443 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2438));
    }
    V v_t_2444 = (g_heff_2esyntax_2epresyntax_2eapp(heff_get_n(v_exitJ_2420, 0, 4), v_t_2443));
    V v_t_2445 = (g_heff_2esyntax_2epresyntax_2eifOf(v_sp_242, v_y_2427, v_t_2437, v_t_2444));
    return ({ V a_0 = v_cx_2421; V a_1 = v_x_2426; V a_2 = v_t_2445; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2426); r_; });
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryT_str0, 89, "nothing after this `try` runs: neither its statements nor its `catch` arm reach their end");
Clo g_heff_2esyntax_2epresyntax_2etryT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryT_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2etryT(V v_t_240, V v_cx_241, V v_sp_242, V v_tr_243, V v_rest_244, V v_end_245) {
top: ;
  V v_scope_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2etryScope_clo), 4, (V[]){heff_dup(v_t_240), heff_dup(v_cx_241), heff_dup(v_sp_242), heff_dup(v_tr_243)}));
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETry, 1, (V[]){v_tr_243}), heff_dup(v_sp_242)});
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_249));
  V v_falls_2427;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_falls_2427 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    switch (heff_tag_of(v_x_2411)) {
    case TAG_At: {
      V v_it11_2413 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 2);
      switch (heff_tag_of(v_it11_2413)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2413, 0ULL, 2);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2420 = heff_field(v_it11_2413, 0);
        heff_take_n(v_it11_2413, 1ULL, 1);
        v_falls_2427 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2420));
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it11_2413);
      }
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  switch (heff_tag_of(v_rest_244)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_cx_241);
    heff_drop(v_sp_242);
    heff_drop(v_falls_2427);
    return heff_tail(v_scope_246, 1, (V[]){v_end_245});
  }
  case TAG_Cons: {
    V v_s_2428 = heff_field(v_rest_244, 0);
    V v_rest_2429 = heff_field(v_rest_244, 1);
    V v_ru_24rest_244_24Cons = heff_take_reuse_n(v_rest_244, 3ULL, 2);
    if ((heff_dup(v_falls_2427) == NTAG(TAG_True))) {
      heff_drop(v_falls_2427);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_246, heff_tag_at_n(v_ru_24rest_244_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_rest_2429}), v_end_245);
    } else {
      heff_drop(v_t_240);
      heff_drop(v_cx_241);
      heff_drop(v_sp_242);
      heff_drop(v_end_245);
      heff_drop(v_scope_246);
      heff_drop(v_falls_2427);
      heff_drop(v_rest_2429);
      heff_drop_cell(v_ru_24rest_244_24Cons, 2);
      V v_t_2432;
      switch (heff_tag_of(v_s_2428)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_s_2428, 1);
        heff_take_n(v_s_2428, 2ULL, 2);
        v_t_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_s_2428);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryT_str0)}), v_t_2432});
    }
  }
  default: return heff_nomatch(v_rest_244);
  }
}
V g_heff_2esyntax_2epresyntax_2etryT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etryT(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eelseFalls_str0, 136, "the `else` of `let p = e else ...` must leave the block: end it with `return`, `break`, `continue` or `abandon`; for a value, use `case`");

static V g_heff_2esyntax_2epresyntax_2eelseFalls_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eelseFalls_st;
static V g_heff_2esyntax_2epresyntax_2eelseFalls_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2eelseFalls_str0);
}
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eelseFalls_st)) return g_heff_2esyntax_2epresyntax_2eelseFalls_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eelseFalls_val, &g_heff_2esyntax_2epresyntax_2eelseFalls_st, g_heff_2esyntax_2epresyntax_2eelseFalls_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eargOf_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eargOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_dup(heff_field(v_x2_241, 0));
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EVar, 1);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), v_t_2418});
    }
    case TAG_EImplicitVar: {
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EImplicitVar, 1);
        v_t_2430 = v_c_2425;
        break;
      }
      case TAG_IsType: {
        V v_t_2426 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2433;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2430}), v_t_2433});
    }
    case TAG_ETag: {
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETag, 1);
        v_t_2445 = v_c_2440;
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CType, 1, (V[]){v_t_2441}), v_t_2444});
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2448;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2445}), v_t_2448});
    }
    case TAG_EInt: {
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2460;
      switch (heff_tag_of(v_x1_2450)) {
      case TAG_IsInferable: {
        V v_i_2451 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2455 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInt, 1);
        v_t_2460 = v_c_2455;
        break;
      }
      case TAG_IsType: {
        V v_t_2456 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
        break;
      }
      default: heff_nomatch(v_x1_2450);
      }
      V v_t_2463;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2460}), v_t_2463});
    }
    case TAG_EFloat: {
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2475;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_IsInferable: {
        V v_i_2466 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2469;
        switch (heff_tag_of(v_i_2466)) {
        case TAG_At: {
          V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
          v_t_2469 = v_s_2468;
          break;
        }
        default: heff_nomatch(v_i_2466);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2470 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EFloat, 1);
        v_t_2475 = v_c_2470;
        break;
      }
      case TAG_IsType: {
        V v_t_2471 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2478;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EString: {
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2490;
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_IsInferable: {
        V v_i_2481 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2484;
        switch (heff_tag_of(v_i_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_i_2481);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CInf, 1, (V[]){v_i_2481}), v_t_2484});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2485 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EString, 1);
        v_t_2490 = v_c_2485;
        break;
      }
      case TAG_IsType: {
        V v_t_2486 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_t_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CType, 1, (V[]){v_t_2486}), v_t_2489});
        break;
      }
      default: heff_nomatch(v_x1_2480);
      }
      V v_t_2493;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2490}), v_t_2493});
    }
    case TAG_EBinary: {
      V v_ru_24x21_242_24EBinary = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24105;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_IsInferable: {
        V v_i_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_i_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_i_2496);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CInf, 1, (V[]){v_i_2496}), v_t_2499});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24100 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EBinary, 1);
        v_t_24105 = v_c_24100;
        break;
      }
      case TAG_IsType: {
        V v_t_24101 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_t_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CType, 1, (V[]){v_t_24101}), v_t_24104});
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_t_24108;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24105}), v_t_24108});
    }
    case TAG_ERune: {
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24120;
      switch (heff_tag_of(v_x1_24110)) {
      case TAG_IsInferable: {
        V v_i_24111 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24114;
        switch (heff_tag_of(v_i_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_i_24111);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24115 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ERune, 1);
        v_t_24120 = v_c_24115;
        break;
      }
      case TAG_IsType: {
        V v_t_24116 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_t_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_t_24116);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
        break;
      }
      default: heff_nomatch(v_x1_24110);
      }
      V v_t_24123;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24120}), v_t_24123});
    }
    case TAG_EWord: {
      V v_ru_24x21_242_24EWord = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24125 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24135;
      switch (heff_tag_of(v_x1_24125)) {
      case TAG_IsInferable: {
        V v_i_24126 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24129;
        switch (heff_tag_of(v_i_24126)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_i_24126, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_i_24126);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CInf, 1, (V[]){v_i_24126}), v_t_24129});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24130 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EWord, 1);
        v_t_24135 = v_c_24130;
        break;
      }
      case TAG_IsType: {
        V v_t_24131 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24134;
        switch (heff_tag_of(v_t_24131)) {
        case TAG_At: {
          V v_s_24133 = heff_dup(heff_field(v_t_24131, 1));
          v_t_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_t_24131);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CType, 1, (V[]){v_t_24131}), v_t_24134});
        break;
      }
      default: heff_nomatch(v_x1_24125);
      }
      V v_t_24138;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24137 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24138 = v_s_24137;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24135}), v_t_24138});
    }
    case TAG_EApp: {
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24151;
      switch (heff_tag_of(v_x1_24141)) {
      case TAG_IsInferable: {
        V v_i_24142 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24145;
        switch (heff_tag_of(v_i_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_dup(heff_field(v_i_24142, 1));
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_i_24142);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24142}), v_t_24145});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24146 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EApp, 2);
        v_t_24151 = v_c_24146;
        break;
      }
      case TAG_IsType: {
        V v_t_24147 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24150;
        switch (heff_tag_of(v_t_24147)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
          v_t_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_t_24147);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
        break;
      }
      default: heff_nomatch(v_x1_24141);
      }
      V v_t_24154;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_EProject: {
      V v_x_24155 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_sp_24157 = heff_field(v_x2_241, 1);
        V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 2ULL, 2);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_24155}), v_sp_24157});
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_ENamed: {
      V v_x_24158 = heff_field(v_x21_242, 0);
      V v_x212_24159 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_sp_24161 = heff_field(v_x2_241, 1);
        V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 2ULL, 2);
        switch (heff_tag_of(v_x212_24159)) {
        case TAG_At: {
          V v_x2121_24162 = heff_dup(heff_field(v_x212_24159, 0));
          switch (heff_tag_of(v_x2121_24162)) {
          case TAG_EVar: {
            V v_x21211_24164 = heff_field(v_x2121_24162, 0);
            heff_take_n(v_x2121_24162, 1ULL, 1);
            if (heff_strEq_c(v_x21211_24164, ((V)&g_heff_2esyntax_2epresyntax_2eargOf_str0))) {
              heff_drop_rec(v_r_240, 2);
              heff_drop_tag(v_x212_24159, 2);
              heff_drop_cell(v_ru_24x2_241_24At, 2);
              return heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgEvidence, 1, (V[]){v_x_24158}), v_sp_24161});
            } else {
              V v_x1_24165 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
              V v_t_24175;
              switch (heff_tag_of(v_x1_24165)) {
              case TAG_IsInferable: {
                V v_i_24166 = heff_field(v_x1_24165, 0);
                heff_take_n(v_x1_24165, 1ULL, 1);
                V v_t_24169;
                switch (heff_tag_of(v_i_24166)) {
                case TAG_At: {
                  V v_s_24168 = heff_dup(heff_field(v_i_24166, 1));
                  v_t_24169 = v_s_24168;
                  break;
                }
                default: heff_nomatch(v_i_24166);
                }
                v_t_24175 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24166}), v_t_24169});
                break;
              }
              case TAG_IsCheckable: {
                V v_c_24170 = heff_field(v_x1_24165, 0);
                heff_take_n(v_x1_24165, 1ULL, 1);
                heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
                v_t_24175 = v_c_24170;
                break;
              }
              case TAG_IsType: {
                V v_t_24171 = heff_field(v_x1_24165, 0);
                heff_take_n(v_x1_24165, 1ULL, 1);
                V v_t_24174;
                switch (heff_tag_of(v_t_24171)) {
                case TAG_At: {
                  V v_s_24173 = heff_dup(heff_field(v_t_24171, 1));
                  v_t_24174 = v_s_24173;
                  break;
                }
                default: heff_nomatch(v_t_24171);
                }
                v_t_24175 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24171}), v_t_24174});
                break;
              }
              default: heff_nomatch(v_x1_24165);
              }
              return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24175}), v_sp_24161});
            }
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24177 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24187;
            switch (heff_tag_of(v_x1_24177)) {
            case TAG_IsInferable: {
              V v_i_24178 = heff_field(v_x1_24177, 0);
              heff_take_n(v_x1_24177, 1ULL, 1);
              V v_t_24181;
              switch (heff_tag_of(v_i_24178)) {
              case TAG_At: {
                V v_s_24180 = heff_dup(heff_field(v_i_24178, 1));
                v_t_24181 = v_s_24180;
                break;
              }
              default: heff_nomatch(v_i_24178);
              }
              v_t_24187 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24178}), v_t_24181});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24182 = heff_field(v_x1_24177, 0);
              heff_take_n(v_x1_24177, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24187 = v_c_24182;
              break;
            }
            case TAG_IsType: {
              V v_t_24183 = heff_field(v_x1_24177, 0);
              heff_take_n(v_x1_24177, 1ULL, 1);
              V v_t_24186;
              switch (heff_tag_of(v_t_24183)) {
              case TAG_At: {
                V v_s_24185 = heff_dup(heff_field(v_t_24183, 1));
                v_t_24186 = v_s_24185;
                break;
              }
              default: heff_nomatch(v_t_24183);
              }
              v_t_24187 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24183}), v_t_24186});
              break;
            }
            default: heff_nomatch(v_x1_24177);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24187}), v_sp_24161});
          }
          case TAG_ETag: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24189 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24199;
            switch (heff_tag_of(v_x1_24189)) {
            case TAG_IsInferable: {
              V v_i_24190 = heff_field(v_x1_24189, 0);
              heff_take_n(v_x1_24189, 1ULL, 1);
              V v_t_24193;
              switch (heff_tag_of(v_i_24190)) {
              case TAG_At: {
                V v_s_24192 = heff_dup(heff_field(v_i_24190, 1));
                v_t_24193 = v_s_24192;
                break;
              }
              default: heff_nomatch(v_i_24190);
              }
              v_t_24199 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24190}), v_t_24193});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24194 = heff_field(v_x1_24189, 0);
              heff_take_n(v_x1_24189, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24199 = v_c_24194;
              break;
            }
            case TAG_IsType: {
              V v_t_24195 = heff_field(v_x1_24189, 0);
              heff_take_n(v_x1_24189, 1ULL, 1);
              V v_t_24198;
              switch (heff_tag_of(v_t_24195)) {
              case TAG_At: {
                V v_s_24197 = heff_dup(heff_field(v_t_24195, 1));
                v_t_24198 = v_s_24197;
                break;
              }
              default: heff_nomatch(v_t_24195);
              }
              v_t_24199 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24195}), v_t_24198});
              break;
            }
            default: heff_nomatch(v_x1_24189);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24199}), v_sp_24161});
          }
          case TAG_EInt: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24201 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24211;
            switch (heff_tag_of(v_x1_24201)) {
            case TAG_IsInferable: {
              V v_i_24202 = heff_field(v_x1_24201, 0);
              heff_take_n(v_x1_24201, 1ULL, 1);
              V v_t_24205;
              switch (heff_tag_of(v_i_24202)) {
              case TAG_At: {
                V v_s_24204 = heff_dup(heff_field(v_i_24202, 1));
                v_t_24205 = v_s_24204;
                break;
              }
              default: heff_nomatch(v_i_24202);
              }
              v_t_24211 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24202}), v_t_24205});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24206 = heff_field(v_x1_24201, 0);
              heff_take_n(v_x1_24201, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24211 = v_c_24206;
              break;
            }
            case TAG_IsType: {
              V v_t_24207 = heff_field(v_x1_24201, 0);
              heff_take_n(v_x1_24201, 1ULL, 1);
              V v_t_24210;
              switch (heff_tag_of(v_t_24207)) {
              case TAG_At: {
                V v_s_24209 = heff_dup(heff_field(v_t_24207, 1));
                v_t_24210 = v_s_24209;
                break;
              }
              default: heff_nomatch(v_t_24207);
              }
              v_t_24211 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24207}), v_t_24210});
              break;
            }
            default: heff_nomatch(v_x1_24201);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24211}), v_sp_24161});
          }
          case TAG_EFloat: {
            heff_take_na(v_x2121_24162, 0ULL, 1);
            V v_x1_24213 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24223;
            switch (heff_tag_of(v_x1_24213)) {
            case TAG_IsInferable: {
              V v_i_24214 = heff_field(v_x1_24213, 0);
              heff_take_n(v_x1_24213, 1ULL, 1);
              V v_t_24217;
              switch (heff_tag_of(v_i_24214)) {
              case TAG_At: {
                V v_s_24216 = heff_dup(heff_field(v_i_24214, 1));
                v_t_24217 = v_s_24216;
                break;
              }
              default: heff_nomatch(v_i_24214);
              }
              v_t_24223 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24214}), v_t_24217});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24218 = heff_field(v_x1_24213, 0);
              heff_take_n(v_x1_24213, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24223 = v_c_24218;
              break;
            }
            case TAG_IsType: {
              V v_t_24219 = heff_field(v_x1_24213, 0);
              heff_take_n(v_x1_24213, 1ULL, 1);
              V v_t_24222;
              switch (heff_tag_of(v_t_24219)) {
              case TAG_At: {
                V v_s_24221 = heff_dup(heff_field(v_t_24219, 1));
                v_t_24222 = v_s_24221;
                break;
              }
              default: heff_nomatch(v_t_24219);
              }
              v_t_24223 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24219}), v_t_24222});
              break;
            }
            default: heff_nomatch(v_x1_24213);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24223}), v_sp_24161});
          }
          case TAG_EString: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24225 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24235;
            switch (heff_tag_of(v_x1_24225)) {
            case TAG_IsInferable: {
              V v_i_24226 = heff_field(v_x1_24225, 0);
              heff_take_n(v_x1_24225, 1ULL, 1);
              V v_t_24229;
              switch (heff_tag_of(v_i_24226)) {
              case TAG_At: {
                V v_s_24228 = heff_dup(heff_field(v_i_24226, 1));
                v_t_24229 = v_s_24228;
                break;
              }
              default: heff_nomatch(v_i_24226);
              }
              v_t_24235 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24226}), v_t_24229});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24230 = heff_field(v_x1_24225, 0);
              heff_take_n(v_x1_24225, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24235 = v_c_24230;
              break;
            }
            case TAG_IsType: {
              V v_t_24231 = heff_field(v_x1_24225, 0);
              heff_take_n(v_x1_24225, 1ULL, 1);
              V v_t_24234;
              switch (heff_tag_of(v_t_24231)) {
              case TAG_At: {
                V v_s_24233 = heff_dup(heff_field(v_t_24231, 1));
                v_t_24234 = v_s_24233;
                break;
              }
              default: heff_nomatch(v_t_24231);
              }
              v_t_24235 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24231}), v_t_24234});
              break;
            }
            default: heff_nomatch(v_x1_24225);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24235}), v_sp_24161});
          }
          case TAG_EBinary: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24237 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24247;
            switch (heff_tag_of(v_x1_24237)) {
            case TAG_IsInferable: {
              V v_i_24238 = heff_field(v_x1_24237, 0);
              heff_take_n(v_x1_24237, 1ULL, 1);
              V v_t_24241;
              switch (heff_tag_of(v_i_24238)) {
              case TAG_At: {
                V v_s_24240 = heff_dup(heff_field(v_i_24238, 1));
                v_t_24241 = v_s_24240;
                break;
              }
              default: heff_nomatch(v_i_24238);
              }
              v_t_24247 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24238}), v_t_24241});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24242 = heff_field(v_x1_24237, 0);
              heff_take_n(v_x1_24237, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24247 = v_c_24242;
              break;
            }
            case TAG_IsType: {
              V v_t_24243 = heff_field(v_x1_24237, 0);
              heff_take_n(v_x1_24237, 1ULL, 1);
              V v_t_24246;
              switch (heff_tag_of(v_t_24243)) {
              case TAG_At: {
                V v_s_24245 = heff_dup(heff_field(v_t_24243, 1));
                v_t_24246 = v_s_24245;
                break;
              }
              default: heff_nomatch(v_t_24243);
              }
              v_t_24247 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24243}), v_t_24246});
              break;
            }
            default: heff_nomatch(v_x1_24237);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24247}), v_sp_24161});
          }
          case TAG_ERune: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24249 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24259;
            switch (heff_tag_of(v_x1_24249)) {
            case TAG_IsInferable: {
              V v_i_24250 = heff_field(v_x1_24249, 0);
              heff_take_n(v_x1_24249, 1ULL, 1);
              V v_t_24253;
              switch (heff_tag_of(v_i_24250)) {
              case TAG_At: {
                V v_s_24252 = heff_dup(heff_field(v_i_24250, 1));
                v_t_24253 = v_s_24252;
                break;
              }
              default: heff_nomatch(v_i_24250);
              }
              v_t_24259 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24250}), v_t_24253});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24254 = heff_field(v_x1_24249, 0);
              heff_take_n(v_x1_24249, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24259 = v_c_24254;
              break;
            }
            case TAG_IsType: {
              V v_t_24255 = heff_field(v_x1_24249, 0);
              heff_take_n(v_x1_24249, 1ULL, 1);
              V v_t_24258;
              switch (heff_tag_of(v_t_24255)) {
              case TAG_At: {
                V v_s_24257 = heff_dup(heff_field(v_t_24255, 1));
                v_t_24258 = v_s_24257;
                break;
              }
              default: heff_nomatch(v_t_24255);
              }
              v_t_24259 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24255}), v_t_24258});
              break;
            }
            default: heff_nomatch(v_x1_24249);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24259}), v_sp_24161});
          }
          case TAG_EWord: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24261 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24271;
            switch (heff_tag_of(v_x1_24261)) {
            case TAG_IsInferable: {
              V v_i_24262 = heff_field(v_x1_24261, 0);
              heff_take_n(v_x1_24261, 1ULL, 1);
              V v_t_24265;
              switch (heff_tag_of(v_i_24262)) {
              case TAG_At: {
                V v_s_24264 = heff_dup(heff_field(v_i_24262, 1));
                v_t_24265 = v_s_24264;
                break;
              }
              default: heff_nomatch(v_i_24262);
              }
              v_t_24271 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24262}), v_t_24265});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24266 = heff_field(v_x1_24261, 0);
              heff_take_n(v_x1_24261, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24271 = v_c_24266;
              break;
            }
            case TAG_IsType: {
              V v_t_24267 = heff_field(v_x1_24261, 0);
              heff_take_n(v_x1_24261, 1ULL, 1);
              V v_t_24270;
              switch (heff_tag_of(v_t_24267)) {
              case TAG_At: {
                V v_s_24269 = heff_dup(heff_field(v_t_24267, 1));
                v_t_24270 = v_s_24269;
                break;
              }
              default: heff_nomatch(v_t_24267);
              }
              v_t_24271 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24267}), v_t_24270});
              break;
            }
            default: heff_nomatch(v_x1_24261);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24271}), v_sp_24161});
          }
          case TAG_EApp: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24274 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24284;
            switch (heff_tag_of(v_x1_24274)) {
            case TAG_IsInferable: {
              V v_i_24275 = heff_field(v_x1_24274, 0);
              heff_take_n(v_x1_24274, 1ULL, 1);
              V v_t_24278;
              switch (heff_tag_of(v_i_24275)) {
              case TAG_At: {
                V v_s_24277 = heff_dup(heff_field(v_i_24275, 1));
                v_t_24278 = v_s_24277;
                break;
              }
              default: heff_nomatch(v_i_24275);
              }
              v_t_24284 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24275}), v_t_24278});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24279 = heff_field(v_x1_24274, 0);
              heff_take_n(v_x1_24274, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24284 = v_c_24279;
              break;
            }
            case TAG_IsType: {
              V v_t_24280 = heff_field(v_x1_24274, 0);
              heff_take_n(v_x1_24274, 1ULL, 1);
              V v_t_24283;
              switch (heff_tag_of(v_t_24280)) {
              case TAG_At: {
                V v_s_24282 = heff_dup(heff_field(v_t_24280, 1));
                v_t_24283 = v_s_24282;
                break;
              }
              default: heff_nomatch(v_t_24280);
              }
              v_t_24284 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24280}), v_t_24283});
              break;
            }
            default: heff_nomatch(v_x1_24274);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24284}), v_sp_24161});
          }
          case TAG_EProject: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24286 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24296;
            switch (heff_tag_of(v_x1_24286)) {
            case TAG_IsInferable: {
              V v_i_24287 = heff_field(v_x1_24286, 0);
              heff_take_n(v_x1_24286, 1ULL, 1);
              V v_t_24290;
              switch (heff_tag_of(v_i_24287)) {
              case TAG_At: {
                V v_s_24289 = heff_dup(heff_field(v_i_24287, 1));
                v_t_24290 = v_s_24289;
                break;
              }
              default: heff_nomatch(v_i_24287);
              }
              v_t_24296 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24287}), v_t_24290});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24291 = heff_field(v_x1_24286, 0);
              heff_take_n(v_x1_24286, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24296 = v_c_24291;
              break;
            }
            case TAG_IsType: {
              V v_t_24292 = heff_field(v_x1_24286, 0);
              heff_take_n(v_x1_24286, 1ULL, 1);
              V v_t_24295;
              switch (heff_tag_of(v_t_24292)) {
              case TAG_At: {
                V v_s_24294 = heff_dup(heff_field(v_t_24292, 1));
                v_t_24295 = v_s_24294;
                break;
              }
              default: heff_nomatch(v_t_24292);
              }
              v_t_24296 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24292}), v_t_24295});
              break;
            }
            default: heff_nomatch(v_x1_24286);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24296}), v_sp_24161});
          }
          case TAG_ENamed: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24299 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24309;
            switch (heff_tag_of(v_x1_24299)) {
            case TAG_IsInferable: {
              V v_i_24300 = heff_field(v_x1_24299, 0);
              heff_take_n(v_x1_24299, 1ULL, 1);
              V v_t_24303;
              switch (heff_tag_of(v_i_24300)) {
              case TAG_At: {
                V v_s_24302 = heff_dup(heff_field(v_i_24300, 1));
                v_t_24303 = v_s_24302;
                break;
              }
              default: heff_nomatch(v_i_24300);
              }
              v_t_24309 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24300}), v_t_24303});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24304 = heff_field(v_x1_24299, 0);
              heff_take_n(v_x1_24299, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24309 = v_c_24304;
              break;
            }
            case TAG_IsType: {
              V v_t_24305 = heff_field(v_x1_24299, 0);
              heff_take_n(v_x1_24299, 1ULL, 1);
              V v_t_24308;
              switch (heff_tag_of(v_t_24305)) {
              case TAG_At: {
                V v_s_24307 = heff_dup(heff_field(v_t_24305, 1));
                v_t_24308 = v_s_24307;
                break;
              }
              default: heff_nomatch(v_t_24305);
              }
              v_t_24309 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24305}), v_t_24308});
              break;
            }
            default: heff_nomatch(v_x1_24299);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24309}), v_sp_24161});
          }
          case TAG_EPi: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24312 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24322;
            switch (heff_tag_of(v_x1_24312)) {
            case TAG_IsInferable: {
              V v_i_24313 = heff_field(v_x1_24312, 0);
              heff_take_n(v_x1_24312, 1ULL, 1);
              V v_t_24316;
              switch (heff_tag_of(v_i_24313)) {
              case TAG_At: {
                V v_s_24315 = heff_dup(heff_field(v_i_24313, 1));
                v_t_24316 = v_s_24315;
                break;
              }
              default: heff_nomatch(v_i_24313);
              }
              v_t_24322 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24313}), v_t_24316});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24317 = heff_field(v_x1_24312, 0);
              heff_take_n(v_x1_24312, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24322 = v_c_24317;
              break;
            }
            case TAG_IsType: {
              V v_t_24318 = heff_field(v_x1_24312, 0);
              heff_take_n(v_x1_24312, 1ULL, 1);
              V v_t_24321;
              switch (heff_tag_of(v_t_24318)) {
              case TAG_At: {
                V v_s_24320 = heff_dup(heff_field(v_t_24318, 1));
                v_t_24321 = v_s_24320;
                break;
              }
              default: heff_nomatch(v_t_24318);
              }
              v_t_24322 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24318}), v_t_24321});
              break;
            }
            default: heff_nomatch(v_x1_24312);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24322}), v_sp_24161});
          }
          case TAG_ELam: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24325 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24335;
            switch (heff_tag_of(v_x1_24325)) {
            case TAG_IsInferable: {
              V v_i_24326 = heff_field(v_x1_24325, 0);
              heff_take_n(v_x1_24325, 1ULL, 1);
              V v_t_24329;
              switch (heff_tag_of(v_i_24326)) {
              case TAG_At: {
                V v_s_24328 = heff_dup(heff_field(v_i_24326, 1));
                v_t_24329 = v_s_24328;
                break;
              }
              default: heff_nomatch(v_i_24326);
              }
              v_t_24335 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24326}), v_t_24329});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24330 = heff_field(v_x1_24325, 0);
              heff_take_n(v_x1_24325, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24335 = v_c_24330;
              break;
            }
            case TAG_IsType: {
              V v_t_24331 = heff_field(v_x1_24325, 0);
              heff_take_n(v_x1_24325, 1ULL, 1);
              V v_t_24334;
              switch (heff_tag_of(v_t_24331)) {
              case TAG_At: {
                V v_s_24333 = heff_dup(heff_field(v_t_24331, 1));
                v_t_24334 = v_s_24333;
                break;
              }
              default: heff_nomatch(v_t_24331);
              }
              v_t_24335 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24331}), v_t_24334});
              break;
            }
            default: heff_nomatch(v_x1_24325);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24335}), v_sp_24161});
          }
          case TAG_EAnn: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24338 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24348;
            switch (heff_tag_of(v_x1_24338)) {
            case TAG_IsInferable: {
              V v_i_24339 = heff_field(v_x1_24338, 0);
              heff_take_n(v_x1_24338, 1ULL, 1);
              V v_t_24342;
              switch (heff_tag_of(v_i_24339)) {
              case TAG_At: {
                V v_s_24341 = heff_dup(heff_field(v_i_24339, 1));
                v_t_24342 = v_s_24341;
                break;
              }
              default: heff_nomatch(v_i_24339);
              }
              v_t_24348 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24339}), v_t_24342});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24343 = heff_field(v_x1_24338, 0);
              heff_take_n(v_x1_24338, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24348 = v_c_24343;
              break;
            }
            case TAG_IsType: {
              V v_t_24344 = heff_field(v_x1_24338, 0);
              heff_take_n(v_x1_24338, 1ULL, 1);
              V v_t_24347;
              switch (heff_tag_of(v_t_24344)) {
              case TAG_At: {
                V v_s_24346 = heff_dup(heff_field(v_t_24344, 1));
                v_t_24347 = v_s_24346;
                break;
              }
              default: heff_nomatch(v_t_24344);
              }
              v_t_24348 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24344}), v_t_24347});
              break;
            }
            default: heff_nomatch(v_x1_24338);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24348}), v_sp_24161});
          }
          case TAG_ESpec: {
            heff_take_n(v_x2121_24162, 0ULL, 4);
            V v_x1_24353 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24363;
            switch (heff_tag_of(v_x1_24353)) {
            case TAG_IsInferable: {
              V v_i_24354 = heff_field(v_x1_24353, 0);
              heff_take_n(v_x1_24353, 1ULL, 1);
              V v_t_24357;
              switch (heff_tag_of(v_i_24354)) {
              case TAG_At: {
                V v_s_24356 = heff_dup(heff_field(v_i_24354, 1));
                v_t_24357 = v_s_24356;
                break;
              }
              default: heff_nomatch(v_i_24354);
              }
              v_t_24363 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24354}), v_t_24357});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24358 = heff_field(v_x1_24353, 0);
              heff_take_n(v_x1_24353, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24363 = v_c_24358;
              break;
            }
            case TAG_IsType: {
              V v_t_24359 = heff_field(v_x1_24353, 0);
              heff_take_n(v_x1_24353, 1ULL, 1);
              V v_t_24362;
              switch (heff_tag_of(v_t_24359)) {
              case TAG_At: {
                V v_s_24361 = heff_dup(heff_field(v_t_24359, 1));
                v_t_24362 = v_s_24361;
                break;
              }
              default: heff_nomatch(v_t_24359);
              }
              v_t_24363 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24359}), v_t_24362});
              break;
            }
            default: heff_nomatch(v_x1_24353);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24363}), v_sp_24161});
          }
          case TAG_ESig: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24365 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24375;
            switch (heff_tag_of(v_x1_24365)) {
            case TAG_IsInferable: {
              V v_i_24366 = heff_field(v_x1_24365, 0);
              heff_take_n(v_x1_24365, 1ULL, 1);
              V v_t_24369;
              switch (heff_tag_of(v_i_24366)) {
              case TAG_At: {
                V v_s_24368 = heff_dup(heff_field(v_i_24366, 1));
                v_t_24369 = v_s_24368;
                break;
              }
              default: heff_nomatch(v_i_24366);
              }
              v_t_24375 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24366}), v_t_24369});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24370 = heff_field(v_x1_24365, 0);
              heff_take_n(v_x1_24365, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24375 = v_c_24370;
              break;
            }
            case TAG_IsType: {
              V v_t_24371 = heff_field(v_x1_24365, 0);
              heff_take_n(v_x1_24365, 1ULL, 1);
              V v_t_24374;
              switch (heff_tag_of(v_t_24371)) {
              case TAG_At: {
                V v_s_24373 = heff_dup(heff_field(v_t_24371, 1));
                v_t_24374 = v_s_24373;
                break;
              }
              default: heff_nomatch(v_t_24371);
              }
              v_t_24375 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24371}), v_t_24374});
              break;
            }
            default: heff_nomatch(v_x1_24365);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24375}), v_sp_24161});
          }
          case TAG_ESum: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24377 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24387;
            switch (heff_tag_of(v_x1_24377)) {
            case TAG_IsInferable: {
              V v_i_24378 = heff_field(v_x1_24377, 0);
              heff_take_n(v_x1_24377, 1ULL, 1);
              V v_t_24381;
              switch (heff_tag_of(v_i_24378)) {
              case TAG_At: {
                V v_s_24380 = heff_dup(heff_field(v_i_24378, 1));
                v_t_24381 = v_s_24380;
                break;
              }
              default: heff_nomatch(v_i_24378);
              }
              v_t_24387 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24378}), v_t_24381});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24382 = heff_field(v_x1_24377, 0);
              heff_take_n(v_x1_24377, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24387 = v_c_24382;
              break;
            }
            case TAG_IsType: {
              V v_t_24383 = heff_field(v_x1_24377, 0);
              heff_take_n(v_x1_24377, 1ULL, 1);
              V v_t_24386;
              switch (heff_tag_of(v_t_24383)) {
              case TAG_At: {
                V v_s_24385 = heff_dup(heff_field(v_t_24383, 1));
                v_t_24386 = v_s_24385;
                break;
              }
              default: heff_nomatch(v_t_24383);
              }
              v_t_24387 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24383}), v_t_24386});
              break;
            }
            default: heff_nomatch(v_x1_24377);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24387}), v_sp_24161});
          }
          case TAG_EStruct: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24389 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24399;
            switch (heff_tag_of(v_x1_24389)) {
            case TAG_IsInferable: {
              V v_i_24390 = heff_field(v_x1_24389, 0);
              heff_take_n(v_x1_24389, 1ULL, 1);
              V v_t_24393;
              switch (heff_tag_of(v_i_24390)) {
              case TAG_At: {
                V v_s_24392 = heff_dup(heff_field(v_i_24390, 1));
                v_t_24393 = v_s_24392;
                break;
              }
              default: heff_nomatch(v_i_24390);
              }
              v_t_24399 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24390}), v_t_24393});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24394 = heff_field(v_x1_24389, 0);
              heff_take_n(v_x1_24389, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24399 = v_c_24394;
              break;
            }
            case TAG_IsType: {
              V v_t_24395 = heff_field(v_x1_24389, 0);
              heff_take_n(v_x1_24389, 1ULL, 1);
              V v_t_24398;
              switch (heff_tag_of(v_t_24395)) {
              case TAG_At: {
                V v_s_24397 = heff_dup(heff_field(v_t_24395, 1));
                v_t_24398 = v_s_24397;
                break;
              }
              default: heff_nomatch(v_t_24395);
              }
              v_t_24399 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24395}), v_t_24398});
              break;
            }
            default: heff_nomatch(v_x1_24389);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24399}), v_sp_24161});
          }
          case TAG_EUpdate: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24402 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24412;
            switch (heff_tag_of(v_x1_24402)) {
            case TAG_IsInferable: {
              V v_i_24403 = heff_field(v_x1_24402, 0);
              heff_take_n(v_x1_24402, 1ULL, 1);
              V v_t_24406;
              switch (heff_tag_of(v_i_24403)) {
              case TAG_At: {
                V v_s_24405 = heff_dup(heff_field(v_i_24403, 1));
                v_t_24406 = v_s_24405;
                break;
              }
              default: heff_nomatch(v_i_24403);
              }
              v_t_24412 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24403}), v_t_24406});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24407 = heff_field(v_x1_24402, 0);
              heff_take_n(v_x1_24402, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24412 = v_c_24407;
              break;
            }
            case TAG_IsType: {
              V v_t_24408 = heff_field(v_x1_24402, 0);
              heff_take_n(v_x1_24402, 1ULL, 1);
              V v_t_24411;
              switch (heff_tag_of(v_t_24408)) {
              case TAG_At: {
                V v_s_24410 = heff_dup(heff_field(v_t_24408, 1));
                v_t_24411 = v_s_24410;
                break;
              }
              default: heff_nomatch(v_t_24408);
              }
              v_t_24412 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24408}), v_t_24411});
              break;
            }
            default: heff_nomatch(v_x1_24402);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24412}), v_sp_24161});
          }
          case TAG_EMatch: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24425;
            switch (heff_tag_of(v_x1_24415)) {
            case TAG_IsInferable: {
              V v_i_24416 = heff_field(v_x1_24415, 0);
              heff_take_n(v_x1_24415, 1ULL, 1);
              V v_t_24419;
              switch (heff_tag_of(v_i_24416)) {
              case TAG_At: {
                V v_s_24418 = heff_dup(heff_field(v_i_24416, 1));
                v_t_24419 = v_s_24418;
                break;
              }
              default: heff_nomatch(v_i_24416);
              }
              v_t_24425 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24416}), v_t_24419});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24420 = heff_field(v_x1_24415, 0);
              heff_take_n(v_x1_24415, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24425 = v_c_24420;
              break;
            }
            case TAG_IsType: {
              V v_t_24421 = heff_field(v_x1_24415, 0);
              heff_take_n(v_x1_24415, 1ULL, 1);
              V v_t_24424;
              switch (heff_tag_of(v_t_24421)) {
              case TAG_At: {
                V v_s_24423 = heff_dup(heff_field(v_t_24421, 1));
                v_t_24424 = v_s_24423;
                break;
              }
              default: heff_nomatch(v_t_24421);
              }
              v_t_24425 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24421}), v_t_24424});
              break;
            }
            default: heff_nomatch(v_x1_24415);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24425}), v_sp_24161});
          }
          case TAG_ELetIn: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24438;
            switch (heff_tag_of(v_x1_24428)) {
            case TAG_IsInferable: {
              V v_i_24429 = heff_field(v_x1_24428, 0);
              heff_take_n(v_x1_24428, 1ULL, 1);
              V v_t_24432;
              switch (heff_tag_of(v_i_24429)) {
              case TAG_At: {
                V v_s_24431 = heff_dup(heff_field(v_i_24429, 1));
                v_t_24432 = v_s_24431;
                break;
              }
              default: heff_nomatch(v_i_24429);
              }
              v_t_24438 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24429}), v_t_24432});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24433 = heff_field(v_x1_24428, 0);
              heff_take_n(v_x1_24428, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24438 = v_c_24433;
              break;
            }
            case TAG_IsType: {
              V v_t_24434 = heff_field(v_x1_24428, 0);
              heff_take_n(v_x1_24428, 1ULL, 1);
              V v_t_24437;
              switch (heff_tag_of(v_t_24434)) {
              case TAG_At: {
                V v_s_24436 = heff_dup(heff_field(v_t_24434, 1));
                v_t_24437 = v_s_24436;
                break;
              }
              default: heff_nomatch(v_t_24434);
              }
              v_t_24438 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24434}), v_t_24437});
              break;
            }
            default: heff_nomatch(v_x1_24428);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24438}), v_sp_24161});
          }
          case TAG_EDo: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24450;
            switch (heff_tag_of(v_x1_24440)) {
            case TAG_IsInferable: {
              V v_i_24441 = heff_field(v_x1_24440, 0);
              heff_take_n(v_x1_24440, 1ULL, 1);
              V v_t_24444;
              switch (heff_tag_of(v_i_24441)) {
              case TAG_At: {
                V v_s_24443 = heff_dup(heff_field(v_i_24441, 1));
                v_t_24444 = v_s_24443;
                break;
              }
              default: heff_nomatch(v_i_24441);
              }
              v_t_24450 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24441}), v_t_24444});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24445 = heff_field(v_x1_24440, 0);
              heff_take_n(v_x1_24440, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24450 = v_c_24445;
              break;
            }
            case TAG_IsType: {
              V v_t_24446 = heff_field(v_x1_24440, 0);
              heff_take_n(v_x1_24440, 1ULL, 1);
              V v_t_24449;
              switch (heff_tag_of(v_t_24446)) {
              case TAG_At: {
                V v_s_24448 = heff_dup(heff_field(v_t_24446, 1));
                v_t_24449 = v_s_24448;
                break;
              }
              default: heff_nomatch(v_t_24446);
              }
              v_t_24450 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24446}), v_t_24449});
              break;
            }
            default: heff_nomatch(v_x1_24440);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24450}), v_sp_24161});
          }
          case TAG_ELocal: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24453 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24463;
            switch (heff_tag_of(v_x1_24453)) {
            case TAG_IsInferable: {
              V v_i_24454 = heff_field(v_x1_24453, 0);
              heff_take_n(v_x1_24453, 1ULL, 1);
              V v_t_24457;
              switch (heff_tag_of(v_i_24454)) {
              case TAG_At: {
                V v_s_24456 = heff_dup(heff_field(v_i_24454, 1));
                v_t_24457 = v_s_24456;
                break;
              }
              default: heff_nomatch(v_i_24454);
              }
              v_t_24463 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24454}), v_t_24457});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24458 = heff_field(v_x1_24453, 0);
              heff_take_n(v_x1_24453, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24463 = v_c_24458;
              break;
            }
            case TAG_IsType: {
              V v_t_24459 = heff_field(v_x1_24453, 0);
              heff_take_n(v_x1_24453, 1ULL, 1);
              V v_t_24462;
              switch (heff_tag_of(v_t_24459)) {
              case TAG_At: {
                V v_s_24461 = heff_dup(heff_field(v_t_24459, 1));
                v_t_24462 = v_s_24461;
                break;
              }
              default: heff_nomatch(v_t_24459);
              }
              v_t_24463 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24459}), v_t_24462});
              break;
            }
            default: heff_nomatch(v_x1_24453);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24463}), v_sp_24161});
          }
          case TAG_EInvalid: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24475;
            switch (heff_tag_of(v_x1_24465)) {
            case TAG_IsInferable: {
              V v_i_24466 = heff_field(v_x1_24465, 0);
              heff_take_n(v_x1_24465, 1ULL, 1);
              V v_t_24469;
              switch (heff_tag_of(v_i_24466)) {
              case TAG_At: {
                V v_s_24468 = heff_dup(heff_field(v_i_24466, 1));
                v_t_24469 = v_s_24468;
                break;
              }
              default: heff_nomatch(v_i_24466);
              }
              v_t_24475 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24466}), v_t_24469});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24470 = heff_field(v_x1_24465, 0);
              heff_take_n(v_x1_24465, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24475 = v_c_24470;
              break;
            }
            case TAG_IsType: {
              V v_t_24471 = heff_field(v_x1_24465, 0);
              heff_take_n(v_x1_24465, 1ULL, 1);
              V v_t_24474;
              switch (heff_tag_of(v_t_24471)) {
              case TAG_At: {
                V v_s_24473 = heff_dup(heff_field(v_t_24471, 1));
                v_t_24474 = v_s_24473;
                break;
              }
              default: heff_nomatch(v_t_24471);
              }
              v_t_24475 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24471}), v_t_24474});
              break;
            }
            default: heff_nomatch(v_x1_24465);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24475}), v_sp_24161});
          }
          case TAG_EAssign: {
            heff_take_n(v_x2121_24162, 0ULL, 3);
            V v_x1_24479 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24489;
            switch (heff_tag_of(v_x1_24479)) {
            case TAG_IsInferable: {
              V v_i_24480 = heff_field(v_x1_24479, 0);
              heff_take_n(v_x1_24479, 1ULL, 1);
              V v_t_24483;
              switch (heff_tag_of(v_i_24480)) {
              case TAG_At: {
                V v_s_24482 = heff_dup(heff_field(v_i_24480, 1));
                v_t_24483 = v_s_24482;
                break;
              }
              default: heff_nomatch(v_i_24480);
              }
              v_t_24489 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24480}), v_t_24483});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24484 = heff_field(v_x1_24479, 0);
              heff_take_n(v_x1_24479, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24489 = v_c_24484;
              break;
            }
            case TAG_IsType: {
              V v_t_24485 = heff_field(v_x1_24479, 0);
              heff_take_n(v_x1_24479, 1ULL, 1);
              V v_t_24488;
              switch (heff_tag_of(v_t_24485)) {
              case TAG_At: {
                V v_s_24487 = heff_dup(heff_field(v_t_24485, 1));
                v_t_24488 = v_s_24487;
                break;
              }
              default: heff_nomatch(v_t_24485);
              }
              v_t_24489 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24485}), v_t_24488});
              break;
            }
            default: heff_nomatch(v_x1_24479);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24489}), v_sp_24161});
          }
          case TAG_EWhile: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24492 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24502;
            switch (heff_tag_of(v_x1_24492)) {
            case TAG_IsInferable: {
              V v_i_24493 = heff_field(v_x1_24492, 0);
              heff_take_n(v_x1_24492, 1ULL, 1);
              V v_t_24496;
              switch (heff_tag_of(v_i_24493)) {
              case TAG_At: {
                V v_s_24495 = heff_dup(heff_field(v_i_24493, 1));
                v_t_24496 = v_s_24495;
                break;
              }
              default: heff_nomatch(v_i_24493);
              }
              v_t_24502 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24493}), v_t_24496});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24497 = heff_field(v_x1_24492, 0);
              heff_take_n(v_x1_24492, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24502 = v_c_24497;
              break;
            }
            case TAG_IsType: {
              V v_t_24498 = heff_field(v_x1_24492, 0);
              heff_take_n(v_x1_24492, 1ULL, 1);
              V v_t_24501;
              switch (heff_tag_of(v_t_24498)) {
              case TAG_At: {
                V v_s_24500 = heff_dup(heff_field(v_t_24498, 1));
                v_t_24501 = v_s_24500;
                break;
              }
              default: heff_nomatch(v_t_24498);
              }
              v_t_24502 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24498}), v_t_24501});
              break;
            }
            default: heff_nomatch(v_x1_24492);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24502}), v_sp_24161});
          }
          case TAG_EFor: {
            heff_take_n(v_x2121_24162, 0ULL, 3);
            V v_x1_24506 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24516;
            switch (heff_tag_of(v_x1_24506)) {
            case TAG_IsInferable: {
              V v_i_24507 = heff_field(v_x1_24506, 0);
              heff_take_n(v_x1_24506, 1ULL, 1);
              V v_t_24510;
              switch (heff_tag_of(v_i_24507)) {
              case TAG_At: {
                V v_s_24509 = heff_dup(heff_field(v_i_24507, 1));
                v_t_24510 = v_s_24509;
                break;
              }
              default: heff_nomatch(v_i_24507);
              }
              v_t_24516 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24507}), v_t_24510});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24511 = heff_field(v_x1_24506, 0);
              heff_take_n(v_x1_24506, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24516 = v_c_24511;
              break;
            }
            case TAG_IsType: {
              V v_t_24512 = heff_field(v_x1_24506, 0);
              heff_take_n(v_x1_24506, 1ULL, 1);
              V v_t_24515;
              switch (heff_tag_of(v_t_24512)) {
              case TAG_At: {
                V v_s_24514 = heff_dup(heff_field(v_t_24512, 1));
                v_t_24515 = v_s_24514;
                break;
              }
              default: heff_nomatch(v_t_24512);
              }
              v_t_24516 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24512}), v_t_24515});
              break;
            }
            default: heff_nomatch(v_x1_24506);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24516}), v_sp_24161});
          }
          case TAG_EIfThen: {
            heff_take_n(v_x2121_24162, 0ULL, 2);
            V v_x1_24519 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24529;
            switch (heff_tag_of(v_x1_24519)) {
            case TAG_IsInferable: {
              V v_i_24520 = heff_field(v_x1_24519, 0);
              heff_take_n(v_x1_24519, 1ULL, 1);
              V v_t_24523;
              switch (heff_tag_of(v_i_24520)) {
              case TAG_At: {
                V v_s_24522 = heff_dup(heff_field(v_i_24520, 1));
                v_t_24523 = v_s_24522;
                break;
              }
              default: heff_nomatch(v_i_24520);
              }
              v_t_24529 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24520}), v_t_24523});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24524 = heff_field(v_x1_24519, 0);
              heff_take_n(v_x1_24519, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24529 = v_c_24524;
              break;
            }
            case TAG_IsType: {
              V v_t_24525 = heff_field(v_x1_24519, 0);
              heff_take_n(v_x1_24519, 1ULL, 1);
              V v_t_24528;
              switch (heff_tag_of(v_t_24525)) {
              case TAG_At: {
                V v_s_24527 = heff_dup(heff_field(v_t_24525, 1));
                v_t_24528 = v_s_24527;
                break;
              }
              default: heff_nomatch(v_t_24525);
              }
              v_t_24529 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24525}), v_t_24528});
              break;
            }
            default: heff_nomatch(v_x1_24519);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24529}), v_sp_24161});
          }
          case TAG_EBreak: {
            V v_x1_24530 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24540;
            switch (heff_tag_of(v_x1_24530)) {
            case TAG_IsInferable: {
              V v_i_24531 = heff_field(v_x1_24530, 0);
              heff_take_n(v_x1_24530, 1ULL, 1);
              V v_t_24534;
              switch (heff_tag_of(v_i_24531)) {
              case TAG_At: {
                V v_s_24533 = heff_dup(heff_field(v_i_24531, 1));
                v_t_24534 = v_s_24533;
                break;
              }
              default: heff_nomatch(v_i_24531);
              }
              v_t_24540 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24531}), v_t_24534});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24535 = heff_field(v_x1_24530, 0);
              heff_take_n(v_x1_24530, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24540 = v_c_24535;
              break;
            }
            case TAG_IsType: {
              V v_t_24536 = heff_field(v_x1_24530, 0);
              heff_take_n(v_x1_24530, 1ULL, 1);
              V v_t_24539;
              switch (heff_tag_of(v_t_24536)) {
              case TAG_At: {
                V v_s_24538 = heff_dup(heff_field(v_t_24536, 1));
                v_t_24539 = v_s_24538;
                break;
              }
              default: heff_nomatch(v_t_24536);
              }
              v_t_24540 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24536}), v_t_24539});
              break;
            }
            default: heff_nomatch(v_x1_24530);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24540}), v_sp_24161});
          }
          case TAG_EContinue: {
            V v_x1_24541 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24551;
            switch (heff_tag_of(v_x1_24541)) {
            case TAG_IsInferable: {
              V v_i_24542 = heff_field(v_x1_24541, 0);
              heff_take_n(v_x1_24541, 1ULL, 1);
              V v_t_24545;
              switch (heff_tag_of(v_i_24542)) {
              case TAG_At: {
                V v_s_24544 = heff_dup(heff_field(v_i_24542, 1));
                v_t_24545 = v_s_24544;
                break;
              }
              default: heff_nomatch(v_i_24542);
              }
              v_t_24551 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24542}), v_t_24545});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24546 = heff_field(v_x1_24541, 0);
              heff_take_n(v_x1_24541, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24551 = v_c_24546;
              break;
            }
            case TAG_IsType: {
              V v_t_24547 = heff_field(v_x1_24541, 0);
              heff_take_n(v_x1_24541, 1ULL, 1);
              V v_t_24550;
              switch (heff_tag_of(v_t_24547)) {
              case TAG_At: {
                V v_s_24549 = heff_dup(heff_field(v_t_24547, 1));
                v_t_24550 = v_s_24549;
                break;
              }
              default: heff_nomatch(v_t_24547);
              }
              v_t_24551 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24547}), v_t_24550});
              break;
            }
            default: heff_nomatch(v_x1_24541);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24551}), v_sp_24161});
          }
          case TAG_EReturn: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24553 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24563;
            switch (heff_tag_of(v_x1_24553)) {
            case TAG_IsInferable: {
              V v_i_24554 = heff_field(v_x1_24553, 0);
              heff_take_n(v_x1_24553, 1ULL, 1);
              V v_t_24557;
              switch (heff_tag_of(v_i_24554)) {
              case TAG_At: {
                V v_s_24556 = heff_dup(heff_field(v_i_24554, 1));
                v_t_24557 = v_s_24556;
                break;
              }
              default: heff_nomatch(v_i_24554);
              }
              v_t_24563 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24554}), v_t_24557});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24558 = heff_field(v_x1_24553, 0);
              heff_take_n(v_x1_24553, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24563 = v_c_24558;
              break;
            }
            case TAG_IsType: {
              V v_t_24559 = heff_field(v_x1_24553, 0);
              heff_take_n(v_x1_24553, 1ULL, 1);
              V v_t_24562;
              switch (heff_tag_of(v_t_24559)) {
              case TAG_At: {
                V v_s_24561 = heff_dup(heff_field(v_t_24559, 1));
                v_t_24562 = v_s_24561;
                break;
              }
              default: heff_nomatch(v_t_24559);
              }
              v_t_24563 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24559}), v_t_24562});
              break;
            }
            default: heff_nomatch(v_x1_24553);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24563}), v_sp_24161});
          }
          case TAG_ENest: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24565 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24575;
            switch (heff_tag_of(v_x1_24565)) {
            case TAG_IsInferable: {
              V v_i_24566 = heff_field(v_x1_24565, 0);
              heff_take_n(v_x1_24565, 1ULL, 1);
              V v_t_24569;
              switch (heff_tag_of(v_i_24566)) {
              case TAG_At: {
                V v_s_24568 = heff_dup(heff_field(v_i_24566, 1));
                v_t_24569 = v_s_24568;
                break;
              }
              default: heff_nomatch(v_i_24566);
              }
              v_t_24575 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24566}), v_t_24569});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24570 = heff_field(v_x1_24565, 0);
              heff_take_n(v_x1_24565, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24575 = v_c_24570;
              break;
            }
            case TAG_IsType: {
              V v_t_24571 = heff_field(v_x1_24565, 0);
              heff_take_n(v_x1_24565, 1ULL, 1);
              V v_t_24574;
              switch (heff_tag_of(v_t_24571)) {
              case TAG_At: {
                V v_s_24573 = heff_dup(heff_field(v_t_24571, 1));
                v_t_24574 = v_s_24573;
                break;
              }
              default: heff_nomatch(v_t_24571);
              }
              v_t_24575 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24571}), v_t_24574});
              break;
            }
            default: heff_nomatch(v_x1_24565);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24575}), v_sp_24161});
          }
          case TAG_ELazy: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24577 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24587;
            switch (heff_tag_of(v_x1_24577)) {
            case TAG_IsInferable: {
              V v_i_24578 = heff_field(v_x1_24577, 0);
              heff_take_n(v_x1_24577, 1ULL, 1);
              V v_t_24581;
              switch (heff_tag_of(v_i_24578)) {
              case TAG_At: {
                V v_s_24580 = heff_dup(heff_field(v_i_24578, 1));
                v_t_24581 = v_s_24580;
                break;
              }
              default: heff_nomatch(v_i_24578);
              }
              v_t_24587 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24578}), v_t_24581});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24582 = heff_field(v_x1_24577, 0);
              heff_take_n(v_x1_24577, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24587 = v_c_24582;
              break;
            }
            case TAG_IsType: {
              V v_t_24583 = heff_field(v_x1_24577, 0);
              heff_take_n(v_x1_24577, 1ULL, 1);
              V v_t_24586;
              switch (heff_tag_of(v_t_24583)) {
              case TAG_At: {
                V v_s_24585 = heff_dup(heff_field(v_t_24583, 1));
                v_t_24586 = v_s_24585;
                break;
              }
              default: heff_nomatch(v_t_24583);
              }
              v_t_24587 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24583}), v_t_24586});
              break;
            }
            default: heff_nomatch(v_x1_24577);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24587}), v_sp_24161});
          }
          case TAG_ETuple: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24589 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24599;
            switch (heff_tag_of(v_x1_24589)) {
            case TAG_IsInferable: {
              V v_i_24590 = heff_field(v_x1_24589, 0);
              heff_take_n(v_x1_24589, 1ULL, 1);
              V v_t_24593;
              switch (heff_tag_of(v_i_24590)) {
              case TAG_At: {
                V v_s_24592 = heff_dup(heff_field(v_i_24590, 1));
                v_t_24593 = v_s_24592;
                break;
              }
              default: heff_nomatch(v_i_24590);
              }
              v_t_24599 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24590}), v_t_24593});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24594 = heff_field(v_x1_24589, 0);
              heff_take_n(v_x1_24589, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24599 = v_c_24594;
              break;
            }
            case TAG_IsType: {
              V v_t_24595 = heff_field(v_x1_24589, 0);
              heff_take_n(v_x1_24589, 1ULL, 1);
              V v_t_24598;
              switch (heff_tag_of(v_t_24595)) {
              case TAG_At: {
                V v_s_24597 = heff_dup(heff_field(v_t_24595, 1));
                v_t_24598 = v_s_24597;
                break;
              }
              default: heff_nomatch(v_t_24595);
              }
              v_t_24599 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24595}), v_t_24598});
              break;
            }
            default: heff_nomatch(v_x1_24589);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24599}), v_sp_24161});
          }
          case TAG_ETry: {
            heff_take_n(v_x2121_24162, 0ULL, 1);
            V v_x1_24601 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24611;
            switch (heff_tag_of(v_x1_24601)) {
            case TAG_IsInferable: {
              V v_i_24602 = heff_field(v_x1_24601, 0);
              heff_take_n(v_x1_24601, 1ULL, 1);
              V v_t_24605;
              switch (heff_tag_of(v_i_24602)) {
              case TAG_At: {
                V v_s_24604 = heff_dup(heff_field(v_i_24602, 1));
                v_t_24605 = v_s_24604;
                break;
              }
              default: heff_nomatch(v_i_24602);
              }
              v_t_24611 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24602}), v_t_24605});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24606 = heff_field(v_x1_24601, 0);
              heff_take_n(v_x1_24601, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24611 = v_c_24606;
              break;
            }
            case TAG_IsType: {
              V v_t_24607 = heff_field(v_x1_24601, 0);
              heff_take_n(v_x1_24601, 1ULL, 1);
              V v_t_24610;
              switch (heff_tag_of(v_t_24607)) {
              case TAG_At: {
                V v_s_24609 = heff_dup(heff_field(v_t_24607, 1));
                v_t_24610 = v_s_24609;
                break;
              }
              default: heff_nomatch(v_t_24607);
              }
              v_t_24611 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24607}), v_t_24610});
              break;
            }
            default: heff_nomatch(v_x1_24601);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24611}), v_sp_24161});
          }
          case TAG_EWith: {
            heff_take_n(v_x2121_24162, 0ULL, 4);
            V v_x1_24616 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_24159}));
            V v_t_24626;
            switch (heff_tag_of(v_x1_24616)) {
            case TAG_IsInferable: {
              V v_i_24617 = heff_field(v_x1_24616, 0);
              heff_take_n(v_x1_24616, 1ULL, 1);
              V v_t_24620;
              switch (heff_tag_of(v_i_24617)) {
              case TAG_At: {
                V v_s_24619 = heff_dup(heff_field(v_i_24617, 1));
                v_t_24620 = v_s_24619;
                break;
              }
              default: heff_nomatch(v_i_24617);
              }
              v_t_24626 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24617}), v_t_24620});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_24621 = heff_field(v_x1_24616, 0);
              heff_take_n(v_x1_24616, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_24626 = v_c_24621;
              break;
            }
            case TAG_IsType: {
              V v_t_24622 = heff_field(v_x1_24616, 0);
              heff_take_n(v_x1_24616, 1ULL, 1);
              V v_t_24625;
              switch (heff_tag_of(v_t_24622)) {
              case TAG_At: {
                V v_s_24624 = heff_dup(heff_field(v_t_24622, 1));
                v_t_24625 = v_s_24624;
                break;
              }
              default: heff_nomatch(v_t_24622);
              }
              v_t_24626 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24622}), v_t_24625});
              break;
            }
            default: heff_nomatch(v_x1_24616);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24158, v_t_24626}), v_sp_24161});
          }
          default: return heff_nomatch(v_x2121_24162);
          }
        }
        default: return heff_nomatch(v_x212_24159);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_EPi: {
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24629 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24639;
      switch (heff_tag_of(v_x1_24629)) {
      case TAG_IsInferable: {
        V v_i_24630 = heff_field(v_x1_24629, 0);
        heff_take_n(v_x1_24629, 1ULL, 1);
        V v_t_24633;
        switch (heff_tag_of(v_i_24630)) {
        case TAG_At: {
          V v_s_24632 = heff_dup(heff_field(v_i_24630, 1));
          v_t_24633 = v_s_24632;
          break;
        }
        default: heff_nomatch(v_i_24630);
        }
        v_t_24639 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24630}), v_t_24633});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24634 = heff_field(v_x1_24629, 0);
        heff_take_n(v_x1_24629, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EPi, 2);
        v_t_24639 = v_c_24634;
        break;
      }
      case TAG_IsType: {
        V v_t_24635 = heff_field(v_x1_24629, 0);
        heff_take_n(v_x1_24629, 1ULL, 1);
        V v_t_24638;
        switch (heff_tag_of(v_t_24635)) {
        case TAG_At: {
          V v_s_24637 = heff_dup(heff_field(v_t_24635, 1));
          v_t_24638 = v_s_24637;
          break;
        }
        default: heff_nomatch(v_t_24635);
        }
        v_t_24639 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24635}), v_t_24638});
        break;
      }
      default: heff_nomatch(v_x1_24629);
      }
      V v_t_24642;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24641 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24642 = v_s_24641;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24639}), v_t_24642});
    }
    case TAG_ELam: {
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24645 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24655;
      switch (heff_tag_of(v_x1_24645)) {
      case TAG_IsInferable: {
        V v_i_24646 = heff_field(v_x1_24645, 0);
        heff_take_n(v_x1_24645, 1ULL, 1);
        V v_t_24649;
        switch (heff_tag_of(v_i_24646)) {
        case TAG_At: {
          V v_s_24648 = heff_dup(heff_field(v_i_24646, 1));
          v_t_24649 = v_s_24648;
          break;
        }
        default: heff_nomatch(v_i_24646);
        }
        v_t_24655 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24646}), v_t_24649});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24650 = heff_field(v_x1_24645, 0);
        heff_take_n(v_x1_24645, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        v_t_24655 = v_c_24650;
        break;
      }
      case TAG_IsType: {
        V v_t_24651 = heff_field(v_x1_24645, 0);
        heff_take_n(v_x1_24645, 1ULL, 1);
        V v_t_24654;
        switch (heff_tag_of(v_t_24651)) {
        case TAG_At: {
          V v_s_24653 = heff_dup(heff_field(v_t_24651, 1));
          v_t_24654 = v_s_24653;
          break;
        }
        default: heff_nomatch(v_t_24651);
        }
        v_t_24655 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24651}), v_t_24654});
        break;
      }
      default: heff_nomatch(v_x1_24645);
      }
      V v_t_24658;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24657 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24658 = v_s_24657;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24655}), v_t_24658});
    }
    case TAG_EAnn: {
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24661 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24671;
      switch (heff_tag_of(v_x1_24661)) {
      case TAG_IsInferable: {
        V v_i_24662 = heff_field(v_x1_24661, 0);
        heff_take_n(v_x1_24661, 1ULL, 1);
        V v_t_24665;
        switch (heff_tag_of(v_i_24662)) {
        case TAG_At: {
          V v_s_24664 = heff_dup(heff_field(v_i_24662, 1));
          v_t_24665 = v_s_24664;
          break;
        }
        default: heff_nomatch(v_i_24662);
        }
        v_t_24671 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24662}), v_t_24665});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24666 = heff_field(v_x1_24661, 0);
        heff_take_n(v_x1_24661, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24671 = v_c_24666;
        break;
      }
      case TAG_IsType: {
        V v_t_24667 = heff_field(v_x1_24661, 0);
        heff_take_n(v_x1_24661, 1ULL, 1);
        V v_t_24670;
        switch (heff_tag_of(v_t_24667)) {
        case TAG_At: {
          V v_s_24669 = heff_dup(heff_field(v_t_24667, 1));
          v_t_24670 = v_s_24669;
          break;
        }
        default: heff_nomatch(v_t_24667);
        }
        v_t_24671 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24667}), v_t_24670});
        break;
      }
      default: heff_nomatch(v_x1_24661);
      }
      V v_t_24674;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24673 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24674 = v_s_24673;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24671}), v_t_24674});
    }
    case TAG_ESpec: {
      heff_take_n(v_x21_242, 0ULL, 4);
      V v_x1_24679 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24689;
      switch (heff_tag_of(v_x1_24679)) {
      case TAG_IsInferable: {
        V v_i_24680 = heff_field(v_x1_24679, 0);
        V v_ru_24x1_24679_24IsInferable = heff_take_reuse_n(v_x1_24679, 1ULL, 1);
        V v_t_24683;
        switch (heff_tag_of(v_i_24680)) {
        case TAG_At: {
          V v_s_24682 = heff_dup(heff_field(v_i_24680, 1));
          v_t_24683 = v_s_24682;
          break;
        }
        default: heff_nomatch(v_i_24680);
        }
        v_t_24689 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24679_24IsInferable, TAG_CInf, 1, (V[]){v_i_24680}), v_t_24683});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24684 = heff_field(v_x1_24679, 0);
        heff_take_n(v_x1_24679, 1ULL, 1);
        v_t_24689 = v_c_24684;
        break;
      }
      case TAG_IsType: {
        V v_t_24685 = heff_field(v_x1_24679, 0);
        V v_ru_24x1_24679_24IsType = heff_take_reuse_n(v_x1_24679, 1ULL, 1);
        V v_t_24688;
        switch (heff_tag_of(v_t_24685)) {
        case TAG_At: {
          V v_s_24687 = heff_dup(heff_field(v_t_24685, 1));
          v_t_24688 = v_s_24687;
          break;
        }
        default: heff_nomatch(v_t_24685);
        }
        v_t_24689 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24679_24IsType, TAG_CType, 1, (V[]){v_t_24685}), v_t_24688});
        break;
      }
      default: heff_nomatch(v_x1_24679);
      }
      V v_t_24692;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24691 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24692 = v_s_24691;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24689}), v_t_24692});
    }
    case TAG_ESig: {
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24694 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24704;
      switch (heff_tag_of(v_x1_24694)) {
      case TAG_IsInferable: {
        V v_i_24695 = heff_field(v_x1_24694, 0);
        heff_take_n(v_x1_24694, 1ULL, 1);
        V v_t_24698;
        switch (heff_tag_of(v_i_24695)) {
        case TAG_At: {
          V v_s_24697 = heff_dup(heff_field(v_i_24695, 1));
          v_t_24698 = v_s_24697;
          break;
        }
        default: heff_nomatch(v_i_24695);
        }
        v_t_24704 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CInf, 1, (V[]){v_i_24695}), v_t_24698});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24699 = heff_field(v_x1_24694, 0);
        heff_take_n(v_x1_24694, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESig, 1);
        v_t_24704 = v_c_24699;
        break;
      }
      case TAG_IsType: {
        V v_t_24700 = heff_field(v_x1_24694, 0);
        heff_take_n(v_x1_24694, 1ULL, 1);
        V v_t_24703;
        switch (heff_tag_of(v_t_24700)) {
        case TAG_At: {
          V v_s_24702 = heff_dup(heff_field(v_t_24700, 1));
          v_t_24703 = v_s_24702;
          break;
        }
        default: heff_nomatch(v_t_24700);
        }
        v_t_24704 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CType, 1, (V[]){v_t_24700}), v_t_24703});
        break;
      }
      default: heff_nomatch(v_x1_24694);
      }
      V v_t_24707;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24706 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24707 = v_s_24706;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24704}), v_t_24707});
    }
    case TAG_ESum: {
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24709 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24719;
      switch (heff_tag_of(v_x1_24709)) {
      case TAG_IsInferable: {
        V v_i_24710 = heff_field(v_x1_24709, 0);
        heff_take_n(v_x1_24709, 1ULL, 1);
        V v_t_24713;
        switch (heff_tag_of(v_i_24710)) {
        case TAG_At: {
          V v_s_24712 = heff_dup(heff_field(v_i_24710, 1));
          v_t_24713 = v_s_24712;
          break;
        }
        default: heff_nomatch(v_i_24710);
        }
        v_t_24719 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CInf, 1, (V[]){v_i_24710}), v_t_24713});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24714 = heff_field(v_x1_24709, 0);
        heff_take_n(v_x1_24709, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESum, 1);
        v_t_24719 = v_c_24714;
        break;
      }
      case TAG_IsType: {
        V v_t_24715 = heff_field(v_x1_24709, 0);
        heff_take_n(v_x1_24709, 1ULL, 1);
        V v_t_24718;
        switch (heff_tag_of(v_t_24715)) {
        case TAG_At: {
          V v_s_24717 = heff_dup(heff_field(v_t_24715, 1));
          v_t_24718 = v_s_24717;
          break;
        }
        default: heff_nomatch(v_t_24715);
        }
        v_t_24719 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CType, 1, (V[]){v_t_24715}), v_t_24718});
        break;
      }
      default: heff_nomatch(v_x1_24709);
      }
      V v_t_24722;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24721 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24722 = v_s_24721;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24719}), v_t_24722});
    }
    case TAG_EStruct: {
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24724 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24734;
      switch (heff_tag_of(v_x1_24724)) {
      case TAG_IsInferable: {
        V v_i_24725 = heff_field(v_x1_24724, 0);
        heff_take_n(v_x1_24724, 1ULL, 1);
        V v_t_24728;
        switch (heff_tag_of(v_i_24725)) {
        case TAG_At: {
          V v_s_24727 = heff_dup(heff_field(v_i_24725, 1));
          v_t_24728 = v_s_24727;
          break;
        }
        default: heff_nomatch(v_i_24725);
        }
        v_t_24734 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CInf, 1, (V[]){v_i_24725}), v_t_24728});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24729 = heff_field(v_x1_24724, 0);
        heff_take_n(v_x1_24724, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EStruct, 1);
        v_t_24734 = v_c_24729;
        break;
      }
      case TAG_IsType: {
        V v_t_24730 = heff_field(v_x1_24724, 0);
        heff_take_n(v_x1_24724, 1ULL, 1);
        V v_t_24733;
        switch (heff_tag_of(v_t_24730)) {
        case TAG_At: {
          V v_s_24732 = heff_dup(heff_field(v_t_24730, 1));
          v_t_24733 = v_s_24732;
          break;
        }
        default: heff_nomatch(v_t_24730);
        }
        v_t_24734 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CType, 1, (V[]){v_t_24730}), v_t_24733});
        break;
      }
      default: heff_nomatch(v_x1_24724);
      }
      V v_t_24737;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24736 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24737 = v_s_24736;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24734}), v_t_24737});
    }
    case TAG_EUpdate: {
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24740 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24750;
      switch (heff_tag_of(v_x1_24740)) {
      case TAG_IsInferable: {
        V v_i_24741 = heff_field(v_x1_24740, 0);
        heff_take_n(v_x1_24740, 1ULL, 1);
        V v_t_24744;
        switch (heff_tag_of(v_i_24741)) {
        case TAG_At: {
          V v_s_24743 = heff_dup(heff_field(v_i_24741, 1));
          v_t_24744 = v_s_24743;
          break;
        }
        default: heff_nomatch(v_i_24741);
        }
        v_t_24750 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24741}), v_t_24744});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24745 = heff_field(v_x1_24740, 0);
        heff_take_n(v_x1_24740, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EUpdate, 2);
        v_t_24750 = v_c_24745;
        break;
      }
      case TAG_IsType: {
        V v_t_24746 = heff_field(v_x1_24740, 0);
        heff_take_n(v_x1_24740, 1ULL, 1);
        V v_t_24749;
        switch (heff_tag_of(v_t_24746)) {
        case TAG_At: {
          V v_s_24748 = heff_dup(heff_field(v_t_24746, 1));
          v_t_24749 = v_s_24748;
          break;
        }
        default: heff_nomatch(v_t_24746);
        }
        v_t_24750 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24746}), v_t_24749});
        break;
      }
      default: heff_nomatch(v_x1_24740);
      }
      V v_t_24753;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24752 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24753 = v_s_24752;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24750}), v_t_24753});
    }
    case TAG_EMatch: {
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24756 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24766;
      switch (heff_tag_of(v_x1_24756)) {
      case TAG_IsInferable: {
        V v_i_24757 = heff_field(v_x1_24756, 0);
        heff_take_n(v_x1_24756, 1ULL, 1);
        V v_t_24760;
        switch (heff_tag_of(v_i_24757)) {
        case TAG_At: {
          V v_s_24759 = heff_dup(heff_field(v_i_24757, 1));
          v_t_24760 = v_s_24759;
          break;
        }
        default: heff_nomatch(v_i_24757);
        }
        v_t_24766 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24757}), v_t_24760});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24761 = heff_field(v_x1_24756, 0);
        heff_take_n(v_x1_24756, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EMatch, 2);
        v_t_24766 = v_c_24761;
        break;
      }
      case TAG_IsType: {
        V v_t_24762 = heff_field(v_x1_24756, 0);
        heff_take_n(v_x1_24756, 1ULL, 1);
        V v_t_24765;
        switch (heff_tag_of(v_t_24762)) {
        case TAG_At: {
          V v_s_24764 = heff_dup(heff_field(v_t_24762, 1));
          v_t_24765 = v_s_24764;
          break;
        }
        default: heff_nomatch(v_t_24762);
        }
        v_t_24766 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24762}), v_t_24765});
        break;
      }
      default: heff_nomatch(v_x1_24756);
      }
      V v_t_24769;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24768 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24769 = v_s_24768;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24766}), v_t_24769});
    }
    case TAG_ELetIn: {
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24772 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24782;
      switch (heff_tag_of(v_x1_24772)) {
      case TAG_IsInferable: {
        V v_i_24773 = heff_field(v_x1_24772, 0);
        heff_take_n(v_x1_24772, 1ULL, 1);
        V v_t_24776;
        switch (heff_tag_of(v_i_24773)) {
        case TAG_At: {
          V v_s_24775 = heff_dup(heff_field(v_i_24773, 1));
          v_t_24776 = v_s_24775;
          break;
        }
        default: heff_nomatch(v_i_24773);
        }
        v_t_24782 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24773}), v_t_24776});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24777 = heff_field(v_x1_24772, 0);
        heff_take_n(v_x1_24772, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELetIn, 2);
        v_t_24782 = v_c_24777;
        break;
      }
      case TAG_IsType: {
        V v_t_24778 = heff_field(v_x1_24772, 0);
        heff_take_n(v_x1_24772, 1ULL, 1);
        V v_t_24781;
        switch (heff_tag_of(v_t_24778)) {
        case TAG_At: {
          V v_s_24780 = heff_dup(heff_field(v_t_24778, 1));
          v_t_24781 = v_s_24780;
          break;
        }
        default: heff_nomatch(v_t_24778);
        }
        v_t_24782 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24778}), v_t_24781});
        break;
      }
      default: heff_nomatch(v_x1_24772);
      }
      V v_t_24785;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24784 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24785 = v_s_24784;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24782}), v_t_24785});
    }
    case TAG_EDo: {
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24787 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24797;
      switch (heff_tag_of(v_x1_24787)) {
      case TAG_IsInferable: {
        V v_i_24788 = heff_field(v_x1_24787, 0);
        heff_take_n(v_x1_24787, 1ULL, 1);
        V v_t_24791;
        switch (heff_tag_of(v_i_24788)) {
        case TAG_At: {
          V v_s_24790 = heff_dup(heff_field(v_i_24788, 1));
          v_t_24791 = v_s_24790;
          break;
        }
        default: heff_nomatch(v_i_24788);
        }
        v_t_24797 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CInf, 1, (V[]){v_i_24788}), v_t_24791});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24792 = heff_field(v_x1_24787, 0);
        heff_take_n(v_x1_24787, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EDo, 1);
        v_t_24797 = v_c_24792;
        break;
      }
      case TAG_IsType: {
        V v_t_24793 = heff_field(v_x1_24787, 0);
        heff_take_n(v_x1_24787, 1ULL, 1);
        V v_t_24796;
        switch (heff_tag_of(v_t_24793)) {
        case TAG_At: {
          V v_s_24795 = heff_dup(heff_field(v_t_24793, 1));
          v_t_24796 = v_s_24795;
          break;
        }
        default: heff_nomatch(v_t_24793);
        }
        v_t_24797 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CType, 1, (V[]){v_t_24793}), v_t_24796});
        break;
      }
      default: heff_nomatch(v_x1_24787);
      }
      V v_t_24800;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24799 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24800 = v_s_24799;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24797}), v_t_24800});
    }
    case TAG_ELocal: {
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24803 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24813;
      switch (heff_tag_of(v_x1_24803)) {
      case TAG_IsInferable: {
        V v_i_24804 = heff_field(v_x1_24803, 0);
        heff_take_n(v_x1_24803, 1ULL, 1);
        V v_t_24807;
        switch (heff_tag_of(v_i_24804)) {
        case TAG_At: {
          V v_s_24806 = heff_dup(heff_field(v_i_24804, 1));
          v_t_24807 = v_s_24806;
          break;
        }
        default: heff_nomatch(v_i_24804);
        }
        v_t_24813 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24804}), v_t_24807});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24808 = heff_field(v_x1_24803, 0);
        heff_take_n(v_x1_24803, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELocal, 2);
        v_t_24813 = v_c_24808;
        break;
      }
      case TAG_IsType: {
        V v_t_24809 = heff_field(v_x1_24803, 0);
        heff_take_n(v_x1_24803, 1ULL, 1);
        V v_t_24812;
        switch (heff_tag_of(v_t_24809)) {
        case TAG_At: {
          V v_s_24811 = heff_dup(heff_field(v_t_24809, 1));
          v_t_24812 = v_s_24811;
          break;
        }
        default: heff_nomatch(v_t_24809);
        }
        v_t_24813 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24809}), v_t_24812});
        break;
      }
      default: heff_nomatch(v_x1_24803);
      }
      V v_t_24816;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24815 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24816 = v_s_24815;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24813}), v_t_24816});
    }
    case TAG_EInvalid: {
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24818 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24828;
      switch (heff_tag_of(v_x1_24818)) {
      case TAG_IsInferable: {
        V v_i_24819 = heff_field(v_x1_24818, 0);
        heff_take_n(v_x1_24818, 1ULL, 1);
        V v_t_24822;
        switch (heff_tag_of(v_i_24819)) {
        case TAG_At: {
          V v_s_24821 = heff_dup(heff_field(v_i_24819, 1));
          v_t_24822 = v_s_24821;
          break;
        }
        default: heff_nomatch(v_i_24819);
        }
        v_t_24828 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CInf, 1, (V[]){v_i_24819}), v_t_24822});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24823 = heff_field(v_x1_24818, 0);
        heff_take_n(v_x1_24818, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInvalid, 1);
        v_t_24828 = v_c_24823;
        break;
      }
      case TAG_IsType: {
        V v_t_24824 = heff_field(v_x1_24818, 0);
        heff_take_n(v_x1_24818, 1ULL, 1);
        V v_t_24827;
        switch (heff_tag_of(v_t_24824)) {
        case TAG_At: {
          V v_s_24826 = heff_dup(heff_field(v_t_24824, 1));
          v_t_24827 = v_s_24826;
          break;
        }
        default: heff_nomatch(v_t_24824);
        }
        v_t_24828 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CType, 1, (V[]){v_t_24824}), v_t_24827});
        break;
      }
      default: heff_nomatch(v_x1_24818);
      }
      V v_t_24831;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24830 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24831 = v_s_24830;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24828}), v_t_24831});
    }
    case TAG_EAssign: {
      heff_take_n(v_x21_242, 0ULL, 3);
      V v_x1_24835 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24845;
      switch (heff_tag_of(v_x1_24835)) {
      case TAG_IsInferable: {
        V v_i_24836 = heff_field(v_x1_24835, 0);
        V v_ru_24x1_24835_24IsInferable = heff_take_reuse_n(v_x1_24835, 1ULL, 1);
        V v_t_24839;
        switch (heff_tag_of(v_i_24836)) {
        case TAG_At: {
          V v_s_24838 = heff_dup(heff_field(v_i_24836, 1));
          v_t_24839 = v_s_24838;
          break;
        }
        default: heff_nomatch(v_i_24836);
        }
        v_t_24845 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24835_24IsInferable, TAG_CInf, 1, (V[]){v_i_24836}), v_t_24839});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24840 = heff_field(v_x1_24835, 0);
        heff_take_n(v_x1_24835, 1ULL, 1);
        v_t_24845 = v_c_24840;
        break;
      }
      case TAG_IsType: {
        V v_t_24841 = heff_field(v_x1_24835, 0);
        V v_ru_24x1_24835_24IsType = heff_take_reuse_n(v_x1_24835, 1ULL, 1);
        V v_t_24844;
        switch (heff_tag_of(v_t_24841)) {
        case TAG_At: {
          V v_s_24843 = heff_dup(heff_field(v_t_24841, 1));
          v_t_24844 = v_s_24843;
          break;
        }
        default: heff_nomatch(v_t_24841);
        }
        v_t_24845 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24835_24IsType, TAG_CType, 1, (V[]){v_t_24841}), v_t_24844});
        break;
      }
      default: heff_nomatch(v_x1_24835);
      }
      V v_t_24848;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24847 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24848 = v_s_24847;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24845}), v_t_24848});
    }
    case TAG_EWhile: {
      V v_ru_24x21_242_24EWhile = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24851 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24861;
      switch (heff_tag_of(v_x1_24851)) {
      case TAG_IsInferable: {
        V v_i_24852 = heff_field(v_x1_24851, 0);
        heff_take_n(v_x1_24851, 1ULL, 1);
        V v_t_24855;
        switch (heff_tag_of(v_i_24852)) {
        case TAG_At: {
          V v_s_24854 = heff_dup(heff_field(v_i_24852, 1));
          v_t_24855 = v_s_24854;
          break;
        }
        default: heff_nomatch(v_i_24852);
        }
        v_t_24861 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24852}), v_t_24855});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24856 = heff_field(v_x1_24851, 0);
        heff_take_n(v_x1_24851, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EWhile, 2);
        v_t_24861 = v_c_24856;
        break;
      }
      case TAG_IsType: {
        V v_t_24857 = heff_field(v_x1_24851, 0);
        heff_take_n(v_x1_24851, 1ULL, 1);
        V v_t_24860;
        switch (heff_tag_of(v_t_24857)) {
        case TAG_At: {
          V v_s_24859 = heff_dup(heff_field(v_t_24857, 1));
          v_t_24860 = v_s_24859;
          break;
        }
        default: heff_nomatch(v_t_24857);
        }
        v_t_24861 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24857}), v_t_24860});
        break;
      }
      default: heff_nomatch(v_x1_24851);
      }
      V v_t_24864;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24863 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24864 = v_s_24863;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24861}), v_t_24864});
    }
    case TAG_EFor: {
      heff_take_n(v_x21_242, 0ULL, 3);
      V v_x1_24868 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24878;
      switch (heff_tag_of(v_x1_24868)) {
      case TAG_IsInferable: {
        V v_i_24869 = heff_field(v_x1_24868, 0);
        V v_ru_24x1_24868_24IsInferable = heff_take_reuse_n(v_x1_24868, 1ULL, 1);
        V v_t_24872;
        switch (heff_tag_of(v_i_24869)) {
        case TAG_At: {
          V v_s_24871 = heff_dup(heff_field(v_i_24869, 1));
          v_t_24872 = v_s_24871;
          break;
        }
        default: heff_nomatch(v_i_24869);
        }
        v_t_24878 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24868_24IsInferable, TAG_CInf, 1, (V[]){v_i_24869}), v_t_24872});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24873 = heff_field(v_x1_24868, 0);
        heff_take_n(v_x1_24868, 1ULL, 1);
        v_t_24878 = v_c_24873;
        break;
      }
      case TAG_IsType: {
        V v_t_24874 = heff_field(v_x1_24868, 0);
        V v_ru_24x1_24868_24IsType = heff_take_reuse_n(v_x1_24868, 1ULL, 1);
        V v_t_24877;
        switch (heff_tag_of(v_t_24874)) {
        case TAG_At: {
          V v_s_24876 = heff_dup(heff_field(v_t_24874, 1));
          v_t_24877 = v_s_24876;
          break;
        }
        default: heff_nomatch(v_t_24874);
        }
        v_t_24878 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24868_24IsType, TAG_CType, 1, (V[]){v_t_24874}), v_t_24877});
        break;
      }
      default: heff_nomatch(v_x1_24868);
      }
      V v_t_24881;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24880 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24881 = v_s_24880;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24878}), v_t_24881});
    }
    case TAG_EIfThen: {
      V v_ru_24x21_242_24EIfThen = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      V v_x1_24884 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24894;
      switch (heff_tag_of(v_x1_24884)) {
      case TAG_IsInferable: {
        V v_i_24885 = heff_field(v_x1_24884, 0);
        heff_take_n(v_x1_24884, 1ULL, 1);
        V v_t_24888;
        switch (heff_tag_of(v_i_24885)) {
        case TAG_At: {
          V v_s_24887 = heff_dup(heff_field(v_i_24885, 1));
          v_t_24888 = v_s_24887;
          break;
        }
        default: heff_nomatch(v_i_24885);
        }
        v_t_24894 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24885}), v_t_24888});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24889 = heff_field(v_x1_24884, 0);
        heff_take_n(v_x1_24884, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EIfThen, 2);
        v_t_24894 = v_c_24889;
        break;
      }
      case TAG_IsType: {
        V v_t_24890 = heff_field(v_x1_24884, 0);
        heff_take_n(v_x1_24884, 1ULL, 1);
        V v_t_24893;
        switch (heff_tag_of(v_t_24890)) {
        case TAG_At: {
          V v_s_24892 = heff_dup(heff_field(v_t_24890, 1));
          v_t_24893 = v_s_24892;
          break;
        }
        default: heff_nomatch(v_t_24890);
        }
        v_t_24894 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24890}), v_t_24893});
        break;
      }
      default: heff_nomatch(v_x1_24884);
      }
      V v_t_24897;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24896 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24897 = v_s_24896;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24894}), v_t_24897});
    }
    case TAG_EBreak: {
      V v_x1_24898 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24908;
      switch (heff_tag_of(v_x1_24898)) {
      case TAG_IsInferable: {
        V v_i_24899 = heff_field(v_x1_24898, 0);
        V v_ru_24x1_24898_24IsInferable = heff_take_reuse_n(v_x1_24898, 1ULL, 1);
        V v_t_24902;
        switch (heff_tag_of(v_i_24899)) {
        case TAG_At: {
          V v_s_24901 = heff_dup(heff_field(v_i_24899, 1));
          v_t_24902 = v_s_24901;
          break;
        }
        default: heff_nomatch(v_i_24899);
        }
        v_t_24908 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24898_24IsInferable, TAG_CInf, 1, (V[]){v_i_24899}), v_t_24902});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24903 = heff_field(v_x1_24898, 0);
        heff_take_n(v_x1_24898, 1ULL, 1);
        v_t_24908 = v_c_24903;
        break;
      }
      case TAG_IsType: {
        V v_t_24904 = heff_field(v_x1_24898, 0);
        V v_ru_24x1_24898_24IsType = heff_take_reuse_n(v_x1_24898, 1ULL, 1);
        V v_t_24907;
        switch (heff_tag_of(v_t_24904)) {
        case TAG_At: {
          V v_s_24906 = heff_dup(heff_field(v_t_24904, 1));
          v_t_24907 = v_s_24906;
          break;
        }
        default: heff_nomatch(v_t_24904);
        }
        v_t_24908 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24898_24IsType, TAG_CType, 1, (V[]){v_t_24904}), v_t_24907});
        break;
      }
      default: heff_nomatch(v_x1_24898);
      }
      V v_t_24911;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24910 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24911 = v_s_24910;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24908}), v_t_24911});
    }
    case TAG_EContinue: {
      V v_x1_24912 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24922;
      switch (heff_tag_of(v_x1_24912)) {
      case TAG_IsInferable: {
        V v_i_24913 = heff_field(v_x1_24912, 0);
        V v_ru_24x1_24912_24IsInferable = heff_take_reuse_n(v_x1_24912, 1ULL, 1);
        V v_t_24916;
        switch (heff_tag_of(v_i_24913)) {
        case TAG_At: {
          V v_s_24915 = heff_dup(heff_field(v_i_24913, 1));
          v_t_24916 = v_s_24915;
          break;
        }
        default: heff_nomatch(v_i_24913);
        }
        v_t_24922 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24912_24IsInferable, TAG_CInf, 1, (V[]){v_i_24913}), v_t_24916});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24917 = heff_field(v_x1_24912, 0);
        heff_take_n(v_x1_24912, 1ULL, 1);
        v_t_24922 = v_c_24917;
        break;
      }
      case TAG_IsType: {
        V v_t_24918 = heff_field(v_x1_24912, 0);
        V v_ru_24x1_24912_24IsType = heff_take_reuse_n(v_x1_24912, 1ULL, 1);
        V v_t_24921;
        switch (heff_tag_of(v_t_24918)) {
        case TAG_At: {
          V v_s_24920 = heff_dup(heff_field(v_t_24918, 1));
          v_t_24921 = v_s_24920;
          break;
        }
        default: heff_nomatch(v_t_24918);
        }
        v_t_24922 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24912_24IsType, TAG_CType, 1, (V[]){v_t_24918}), v_t_24921});
        break;
      }
      default: heff_nomatch(v_x1_24912);
      }
      V v_t_24925;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24924 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24925 = v_s_24924;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24922}), v_t_24925});
    }
    case TAG_EReturn: {
      V v_ru_24x21_242_24EReturn = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24927 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24937;
      switch (heff_tag_of(v_x1_24927)) {
      case TAG_IsInferable: {
        V v_i_24928 = heff_field(v_x1_24927, 0);
        heff_take_n(v_x1_24927, 1ULL, 1);
        V v_t_24931;
        switch (heff_tag_of(v_i_24928)) {
        case TAG_At: {
          V v_s_24930 = heff_dup(heff_field(v_i_24928, 1));
          v_t_24931 = v_s_24930;
          break;
        }
        default: heff_nomatch(v_i_24928);
        }
        v_t_24937 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_CInf, 1, (V[]){v_i_24928}), v_t_24931});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24932 = heff_field(v_x1_24927, 0);
        heff_take_n(v_x1_24927, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EReturn, 1);
        v_t_24937 = v_c_24932;
        break;
      }
      case TAG_IsType: {
        V v_t_24933 = heff_field(v_x1_24927, 0);
        heff_take_n(v_x1_24927, 1ULL, 1);
        V v_t_24936;
        switch (heff_tag_of(v_t_24933)) {
        case TAG_At: {
          V v_s_24935 = heff_dup(heff_field(v_t_24933, 1));
          v_t_24936 = v_s_24935;
          break;
        }
        default: heff_nomatch(v_t_24933);
        }
        v_t_24937 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_CType, 1, (V[]){v_t_24933}), v_t_24936});
        break;
      }
      default: heff_nomatch(v_x1_24927);
      }
      V v_t_24940;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24939 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24940 = v_s_24939;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24937}), v_t_24940});
    }
    case TAG_ENest: {
      V v_ru_24x21_242_24ENest = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24942 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24952;
      switch (heff_tag_of(v_x1_24942)) {
      case TAG_IsInferable: {
        V v_i_24943 = heff_field(v_x1_24942, 0);
        heff_take_n(v_x1_24942, 1ULL, 1);
        V v_t_24946;
        switch (heff_tag_of(v_i_24943)) {
        case TAG_At: {
          V v_s_24945 = heff_dup(heff_field(v_i_24943, 1));
          v_t_24946 = v_s_24945;
          break;
        }
        default: heff_nomatch(v_i_24943);
        }
        v_t_24952 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_CInf, 1, (V[]){v_i_24943}), v_t_24946});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24947 = heff_field(v_x1_24942, 0);
        heff_take_n(v_x1_24942, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ENest, 1);
        v_t_24952 = v_c_24947;
        break;
      }
      case TAG_IsType: {
        V v_t_24948 = heff_field(v_x1_24942, 0);
        heff_take_n(v_x1_24942, 1ULL, 1);
        V v_t_24951;
        switch (heff_tag_of(v_t_24948)) {
        case TAG_At: {
          V v_s_24950 = heff_dup(heff_field(v_t_24948, 1));
          v_t_24951 = v_s_24950;
          break;
        }
        default: heff_nomatch(v_t_24948);
        }
        v_t_24952 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_CType, 1, (V[]){v_t_24948}), v_t_24951});
        break;
      }
      default: heff_nomatch(v_x1_24942);
      }
      V v_t_24955;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24954 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24955 = v_s_24954;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24952}), v_t_24955});
    }
    case TAG_ELazy: {
      V v_ru_24x21_242_24ELazy = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24957 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24967;
      switch (heff_tag_of(v_x1_24957)) {
      case TAG_IsInferable: {
        V v_i_24958 = heff_field(v_x1_24957, 0);
        heff_take_n(v_x1_24957, 1ULL, 1);
        V v_t_24961;
        switch (heff_tag_of(v_i_24958)) {
        case TAG_At: {
          V v_s_24960 = heff_dup(heff_field(v_i_24958, 1));
          v_t_24961 = v_s_24960;
          break;
        }
        default: heff_nomatch(v_i_24958);
        }
        v_t_24967 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CInf, 1, (V[]){v_i_24958}), v_t_24961});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24962 = heff_field(v_x1_24957, 0);
        heff_take_n(v_x1_24957, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELazy, 1);
        v_t_24967 = v_c_24962;
        break;
      }
      case TAG_IsType: {
        V v_t_24963 = heff_field(v_x1_24957, 0);
        heff_take_n(v_x1_24957, 1ULL, 1);
        V v_t_24966;
        switch (heff_tag_of(v_t_24963)) {
        case TAG_At: {
          V v_s_24965 = heff_dup(heff_field(v_t_24963, 1));
          v_t_24966 = v_s_24965;
          break;
        }
        default: heff_nomatch(v_t_24963);
        }
        v_t_24967 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CType, 1, (V[]){v_t_24963}), v_t_24966});
        break;
      }
      default: heff_nomatch(v_x1_24957);
      }
      V v_t_24970;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24969 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24970 = v_s_24969;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24967}), v_t_24970});
    }
    case TAG_ETuple: {
      V v_ru_24x21_242_24ETuple = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24972 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24982;
      switch (heff_tag_of(v_x1_24972)) {
      case TAG_IsInferable: {
        V v_i_24973 = heff_field(v_x1_24972, 0);
        heff_take_n(v_x1_24972, 1ULL, 1);
        V v_t_24976;
        switch (heff_tag_of(v_i_24973)) {
        case TAG_At: {
          V v_s_24975 = heff_dup(heff_field(v_i_24973, 1));
          v_t_24976 = v_s_24975;
          break;
        }
        default: heff_nomatch(v_i_24973);
        }
        v_t_24982 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_CInf, 1, (V[]){v_i_24973}), v_t_24976});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24977 = heff_field(v_x1_24972, 0);
        heff_take_n(v_x1_24972, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETuple, 1);
        v_t_24982 = v_c_24977;
        break;
      }
      case TAG_IsType: {
        V v_t_24978 = heff_field(v_x1_24972, 0);
        heff_take_n(v_x1_24972, 1ULL, 1);
        V v_t_24981;
        switch (heff_tag_of(v_t_24978)) {
        case TAG_At: {
          V v_s_24980 = heff_dup(heff_field(v_t_24978, 1));
          v_t_24981 = v_s_24980;
          break;
        }
        default: heff_nomatch(v_t_24978);
        }
        v_t_24982 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_CType, 1, (V[]){v_t_24978}), v_t_24981});
        break;
      }
      default: heff_nomatch(v_x1_24972);
      }
      V v_t_24985;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24984 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24985 = v_s_24984;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24982}), v_t_24985});
    }
    case TAG_ETry: {
      V v_ru_24x21_242_24ETry = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      V v_x1_24987 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24997;
      switch (heff_tag_of(v_x1_24987)) {
      case TAG_IsInferable: {
        V v_i_24988 = heff_field(v_x1_24987, 0);
        heff_take_n(v_x1_24987, 1ULL, 1);
        V v_t_24991;
        switch (heff_tag_of(v_i_24988)) {
        case TAG_At: {
          V v_s_24990 = heff_dup(heff_field(v_i_24988, 1));
          v_t_24991 = v_s_24990;
          break;
        }
        default: heff_nomatch(v_i_24988);
        }
        v_t_24997 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_CInf, 1, (V[]){v_i_24988}), v_t_24991});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24992 = heff_field(v_x1_24987, 0);
        heff_take_n(v_x1_24987, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETry, 1);
        v_t_24997 = v_c_24992;
        break;
      }
      case TAG_IsType: {
        V v_t_24993 = heff_field(v_x1_24987, 0);
        heff_take_n(v_x1_24987, 1ULL, 1);
        V v_t_24996;
        switch (heff_tag_of(v_t_24993)) {
        case TAG_At: {
          V v_s_24995 = heff_dup(heff_field(v_t_24993, 1));
          v_t_24996 = v_s_24995;
          break;
        }
        default: heff_nomatch(v_t_24993);
        }
        v_t_24997 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_CType, 1, (V[]){v_t_24993}), v_t_24996});
        break;
      }
      default: heff_nomatch(v_x1_24987);
      }
      V v_t_241000;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24999 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_241000 = v_s_24999;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24997}), v_t_241000});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 4);
      V v_x1_241005 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_241015;
      switch (heff_tag_of(v_x1_241005)) {
      case TAG_IsInferable: {
        V v_i_241006 = heff_field(v_x1_241005, 0);
        V v_ru_24x1_241005_24IsInferable = heff_take_reuse_n(v_x1_241005, 1ULL, 1);
        V v_t_241009;
        switch (heff_tag_of(v_i_241006)) {
        case TAG_At: {
          V v_s_241008 = heff_dup(heff_field(v_i_241006, 1));
          v_t_241009 = v_s_241008;
          break;
        }
        default: heff_nomatch(v_i_241006);
        }
        v_t_241015 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_241005_24IsInferable, TAG_CInf, 1, (V[]){v_i_241006}), v_t_241009});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_241010 = heff_field(v_x1_241005, 0);
        heff_take_n(v_x1_241005, 1ULL, 1);
        v_t_241015 = v_c_241010;
        break;
      }
      case TAG_IsType: {
        V v_t_241011 = heff_field(v_x1_241005, 0);
        V v_ru_24x1_241005_24IsType = heff_take_reuse_n(v_x1_241005, 1ULL, 1);
        V v_t_241014;
        switch (heff_tag_of(v_t_241011)) {
        case TAG_At: {
          V v_s_241013 = heff_dup(heff_field(v_t_241011, 1));
          v_t_241014 = v_s_241013;
          break;
        }
        default: heff_nomatch(v_t_241011);
        }
        v_t_241015 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_241005_24IsType, TAG_CType, 1, (V[]){v_t_241011}), v_t_241014});
        break;
      }
      default: heff_nomatch(v_x1_241005);
      }
      V v_t_241018;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_241017 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_241018 = v_s_241017;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_241015}), v_t_241018});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesTerm_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesTerm(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_242}), v_sp_241});
  }
  case TAG_SizeNumber: {
    V v_n_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){heff_intDiv(v_n_243, MK_INT(8LL))});
    V v_t_245 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(8LL), 2)) {
      heff_drop(v_sp_241);
      heff_drop(v_x13_248);
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), v_xsp_247});
    } else {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_xsp_247});
      V v_t_2412 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intDiv(v_x13_248, MK_INT(8LL))});
      V v_t_2413 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_241)})});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
      V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2414})));
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesTerm_str0)}), heff_dup(v_sp_241)});
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_241)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_241});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesTerm(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclEquations = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2419;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_IsInferable: {
        V v_i_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_i_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_i_2410);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2410}), v_t_2413});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2414 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_c_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_c_2414);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
        break;
      }
      case TAG_IsType: {
        V v_t_2418 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2419 = v_t_2418;
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2420 = (g_list_2emap_24s1036840854x702708481(v_r_240, v_eqs_248));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_2419, v_t_2420}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_x21_242, 0);
      V v_xsp_2422 = heff_field(v_x21_242, 1);
      V v_ps_2423 = heff_field(v_x21_242, 2);
      V v_u_2424 = heff_field(v_x21_242, 3);
      V v_body_2425 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclDefine = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_t_2426 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2423));
      V v_x1_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2424}));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_IsInferable: {
        V v_i_2428 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_i_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_i_2428);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2432 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_c_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_c_2432);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
        break;
      }
      case TAG_IsType: {
        V v_t_2436 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2437 = v_t_2436;
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
      V v_x1_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2425}));
      V v_t_2448;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_IsInferable: {
        V v_i_2439 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsInferable = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_i_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_i_2439);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsInferable, TAG_CInf, 1, (V[]){v_i_2439}), v_t_2442});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2443 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2448 = v_c_2443;
        break;
      }
      case TAG_IsType: {
        V v_t_2444 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsType = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2447;
        switch (heff_tag_of(v_t_2444)) {
        case TAG_At: {
          V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
          v_t_2447 = v_s_2446;
          break;
        }
        default: heff_nomatch(v_t_2444);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsType, TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2421, v_xsp_2422, v_t_2426, v_t_2437, v_t_2448}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2449 = heff_field(v_x21_242, 0);
      V v_xsp_2450 = heff_field(v_x21_242, 1);
      V v_ps_2451 = heff_field(v_x21_242, 2);
      V v_body_2452 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclTheory = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_2453 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2451));
      V v_x1_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2452}));
      V v_t_2464;
      switch (heff_tag_of(v_x1_2454)) {
      case TAG_IsInferable: {
        V v_i_2455 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_i_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_i_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_i_2455);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2455}), v_t_2458});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2459 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2464 = v_c_2459;
        break;
      }
      case TAG_IsType: {
        V v_t_2460 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2463;
        switch (heff_tag_of(v_t_2460)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_t_2460);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
        break;
      }
      default: heff_nomatch(v_x1_2454);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2449, v_xsp_2450, v_t_2453, v_t_2464}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2465 = heff_field(v_x21_242, 0);
      V v_xsp_2466 = heff_field(v_x21_242, 1);
      V v_t_2467 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24DeclPrimitive = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2467}));
      V v_t_2478;
      switch (heff_tag_of(v_x1_2468)) {
      case TAG_IsInferable: {
        V v_i_2469 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2472;
        switch (heff_tag_of(v_i_2469)) {
        case TAG_At: {
          V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_i_2469);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2473 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2476;
        switch (heff_tag_of(v_c_2473)) {
        case TAG_At: {
          V v_s_2475 = heff_dup(heff_field(v_c_2473, 1));
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_c_2473);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2473}), v_t_2476});
        break;
      }
      case TAG_IsType: {
        V v_t_2477 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2478 = v_t_2477;
        break;
      }
      default: heff_nomatch(v_x1_2468);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2465, v_xsp_2466, v_t_2478}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2479 = heff_field(v_x21_242, 0);
      V v_xsp_2480 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_rec(v_r_240, 2);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2479, v_xsp_2480}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2481 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2481}));
      V v_t_2483 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2482));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_2483}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2425;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2416 = v_field_2415;
            v_t_2425 = v_c_2416;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2417 = v_field_2415;
              V v_t_2420;
              switch (heff_tag_of(v_i_2417)) {
              case TAG_At: {
                V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
                v_t_2420 = v_s_2419;
                break;
              }
              default: heff_nomatch(v_i_2417);
              }
              v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2417}), v_t_2420});
            } else {
              V v_t_2421 = v_field_2415;
              V v_t_2424;
              switch (heff_tag_of(v_t_2421)) {
              case TAG_At: {
                V v_s_2423 = heff_dup(heff_field(v_t_2421, 1));
                v_t_2424 = v_s_2423;
                break;
              }
              default: heff_nomatch(v_t_2421);
              }
              v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2421}), v_t_2424});
            }
          }
        }
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2426});
        V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2427});
        V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2428));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0)}), heff_dup(v_sp_242)});
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT2 v_t_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2434 = v_t_2432.f[1];
            int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
            if ((v_tag_2433 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2435 = v_field_2434;
              return v_c_2435;
            } else {
              if ((v_tag_2433 == ((int64_t)1ULL))) {
                V v_i_2436 = v_field_2434;
                V v_t_2439;
                switch (heff_tag_of(v_i_2436)) {
                case TAG_At: {
                  V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
                  v_t_2439 = v_s_2438;
                  break;
                }
                default: heff_nomatch(v_i_2436);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
              } else {
                V v_t_2440 = v_field_2434;
                V v_t_2443;
                switch (heff_tag_of(v_t_2440)) {
                case TAG_At: {
                  V v_s_2442 = heff_dup(heff_field(v_t_2440, 1));
                  v_t_2443 = v_s_2442;
                  break;
                }
                default: heff_nomatch(v_t_2440);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2440}), v_t_2443});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2445 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2446 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2458;
          {
            V v_field_2448 = v_t_2446.f[1];
            int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
            if ((v_tag_2447 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2449 = v_field_2448;
              v_t_2458 = v_c_2449;
            } else {
              if ((v_tag_2447 == ((int64_t)1ULL))) {
                V v_i_2450 = v_field_2448;
                V v_t_2453;
                switch (heff_tag_of(v_i_2450)) {
                case TAG_At: {
                  V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
                  v_t_2453 = v_s_2452;
                  break;
                }
                default: heff_nomatch(v_i_2450);
                }
                v_t_2458 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2450}), v_t_2453});
              } else {
                V v_t_2454 = v_field_2448;
                V v_t_2457;
                switch (heff_tag_of(v_t_2454)) {
                case TAG_At: {
                  V v_s_2456 = heff_dup(heff_field(v_t_2454, 1));
                  v_t_2457 = v_s_2456;
                  break;
                }
                default: heff_nomatch(v_t_2454);
                }
                v_t_2458 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2454}), v_t_2457});
              }
            }
          }
          V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
          V v_args_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2459});
          V v_t_2461 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2460));
          V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1)}), heff_dup(v_sp_242)});
          V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2462, v_t_2461}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2463}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2467 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2480;
          {
            V v_field_2470 = v_t_2468.f[1];
            int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
            if ((v_tag_2469 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2471 = v_field_2470;
              v_t_2480 = v_c_2471;
            } else {
              if ((v_tag_2469 == ((int64_t)1ULL))) {
                V v_i_2472 = v_field_2470;
                V v_t_2475;
                switch (heff_tag_of(v_i_2472)) {
                case TAG_At: {
                  V v_s_2474 = heff_dup(heff_field(v_i_2472, 1));
                  v_t_2475 = v_s_2474;
                  break;
                }
                default: heff_nomatch(v_i_2472);
                }
                v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2472}), v_t_2475});
              } else {
                V v_t_2476 = v_field_2470;
                V v_t_2479;
                switch (heff_tag_of(v_t_2476)) {
                case TAG_At: {
                  V v_s_2478 = heff_dup(heff_field(v_t_2476, 1));
                  v_t_2479 = v_s_2478;
                  break;
                }
                default: heff_nomatch(v_t_2476);
                }
                v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2476}), v_t_2479});
              }
            }
          }
          V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
          V v_args_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, v_t_2481});
          V v_t_2483 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2482));
          V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2)}), heff_dup(v_sp_242)});
          V v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2484, v_t_2483}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2485}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT2 v_t_2486 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2498;
        {
          V v_field_2488 = v_t_2486.f[1];
          int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
          if ((v_tag_2487 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2489 = v_field_2488;
            v_t_2498 = v_c_2489;
          } else {
            if ((v_tag_2487 == ((int64_t)1ULL))) {
              V v_i_2490 = v_field_2488;
              V v_t_2493;
              switch (heff_tag_of(v_i_2490)) {
              case TAG_At: {
                V v_s_2492 = heff_dup(heff_field(v_i_2490, 1));
                v_t_2493 = v_s_2492;
                break;
              }
              default: heff_nomatch(v_i_2490);
              }
              v_t_2498 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2490}), v_t_2493});
            } else {
              V v_t_2494 = v_field_2488;
              V v_t_2497;
              switch (heff_tag_of(v_t_2494)) {
              case TAG_At: {
                V v_s_2496 = heff_dup(heff_field(v_t_2494, 1));
                v_t_2497 = v_s_2496;
                break;
              }
              default: heff_nomatch(v_t_2494);
              }
              v_t_2498 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2494}), v_t_2497});
            }
          }
        }
        V v_args_2499 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, NTAG(TAG_Nil)});
        V v_t_24100 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2499));
        V v_t_24101 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3)}), heff_dup(v_sp_242)});
        V v_t_24102 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24101, v_t_24100}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24102}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24103 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24104;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24104 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24104 = ((int64_t)0ULL);
        }
        V v_t_24105 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24104 + ((int64_t)0ULL)))});
        V v_t_24106 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24105, heff_dup(v_sp_242)})});
        V v_t_24107 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT2 v_t_24108 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24120;
        {
          V v_field_24110 = v_t_24108.f[1];
          int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
          if ((v_tag_24109 == ((int64_t)0ULL))) {
            V v_c_24111 = v_field_24110;
            v_t_24120 = v_c_24111;
          } else {
            if ((v_tag_24109 == ((int64_t)1ULL))) {
              V v_i_24112 = v_field_24110;
              V v_t_24115;
              switch (heff_tag_of(v_i_24112)) {
              case TAG_At: {
                V v_s_24114 = heff_dup(heff_field(v_i_24112, 1));
                v_t_24115 = v_s_24114;
                break;
              }
              default: heff_nomatch(v_i_24112);
              }
              v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24112}), v_t_24115});
            } else {
              V v_t_24116 = v_field_24110;
              V v_t_24119;
              switch (heff_tag_of(v_t_24116)) {
              case TAG_At: {
                V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
                v_t_24119 = v_s_24118;
                break;
              }
              default: heff_nomatch(v_t_24116);
              }
              v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
            }
          }
        }
        V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24120, NTAG(TAG_Nil)});
        V v_args_24122 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, v_t_24121});
        V v_t_24123 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24122));
        V v_t_24124 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4)}), heff_dup(v_sp_242)});
        V v_t_24125 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24124, v_t_24123}), heff_dup(v_sp_242)});
        V v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24125}), heff_dup(v_sp_242)});
        V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
        V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24106, heff_dup(v_sp_242)}), v_t_24127});
        V v_args_24129 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, v_t_24128});
        V v_t_24130 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24129));
        V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5)}), heff_dup(v_sp_242)});
        V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24131, v_t_24130}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24132}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24133 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24133, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24133);
          V v_t_24134 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24135 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24134, NTAG(TAG_Nil)});
          V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24135));
          V v_t_24137 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6)}), heff_dup(v_sp_242)});
          V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24136}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24138}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24133, MK_INT(16LL))) {
            int64_t v_t_24139;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24139 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24139 = ((int64_t)0ULL);
            }
            V v_t_24140 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24139 + ((int64_t)0ULL)))});
            V v_t_24141 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24140, heff_dup(v_sp_242)})});
            V v_t_24142 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
            V v_args_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24141, heff_dup(v_sp_242)}), v_t_24143});
            V v_t_24145 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24144));
            V v_t_24146 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7)}), heff_dup(v_sp_242)});
            V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24146, v_t_24145}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24147}), v_sp_242});
          } else {
            int64_t v_t_24148;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24148 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24148 = ((int64_t)0ULL);
            }
            V v_t_24149 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24148 + ((int64_t)0ULL)))});
            V v_t_24150 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24149, heff_dup(v_sp_242)})});
            V v_t_24151 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24152 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24151, NTAG(TAG_Nil)});
            V v_args_24153 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24150, heff_dup(v_sp_242)}), v_t_24152});
            V v_t_24154 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24153));
            V v_t_24155 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8)}), heff_dup(v_sp_242)});
            V v_t_24156 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24155, v_t_24154}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24156}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
      v_t_245 = heff_tag_at_n(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at_n(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      V v_ru_24t_246_24At = heff_take_reuse_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_246_24At, v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      V v_ru_24t_2426_24At = heff_take_reuse_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2426_24At, v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2438 = (g_list_2emap_24s79542405x478516404(v_args_2437));
    return heff_tag_at_n(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, v_t_2438});
  }
  case TAG_CStruct: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1729787689x465380098(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){v_t_2440});
  }
  case TAG_CMatch: {
    V v_sc_2441 = heff_field(v_n_240, 0);
    V v_alts_2442 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_sc_2441)) {
    case TAG_At: {
      V v_n_2443 = heff_field(v_sc_2441, 0);
      V v_sp_2444 = heff_field(v_sc_2441, 1);
      V v_ru_24sc_2441_24At = heff_take_reuse_n(v_sc_2441, 3ULL, 2);
      V v_t_2445 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2443));
      v_t_2446 = heff_tag_at_n(v_ru_24sc_2441_24At, TAG_At, 2, (V[]){v_t_2445, v_sp_2444});
      break;
    }
    default: heff_nomatch(v_sc_2441);
    }
    V v_t_2447 = (g_list_2emap_24s244350250x1728178626(v_alts_2442));
    return heff_tag_at_n(v_ru_24n_240_24CMatch, TAG_CMatch, 2, (V[]){v_t_2446, v_t_2447});
  }
  case TAG_CLetIn: {
    V v_rhs_2448 = heff_field(v_n_240, 0);
    V v_alt_2449 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2453;
    switch (heff_tag_of(v_rhs_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_rhs_2448, 0);
      V v_sp_2451 = heff_field(v_rhs_2448, 1);
      V v_ru_24rhs_2448_24At = heff_take_reuse_n(v_rhs_2448, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24rhs_2448_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_rhs_2448);
    }
    V v_t_2463;
    switch (heff_tag_of(v_alt_2449)) {
    case TAG_At: {
      V v_x_2454 = heff_field(v_alt_2449, 0);
      V v_sp_2455 = heff_field(v_alt_2449, 1);
      V v_ru_24alt_2449_24At = heff_take_reuse_n(v_alt_2449, 3ULL, 2);
      V v_t_2462;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_MkAlt: {
        V v_p_2456 = heff_field(v_x_2454, 0);
        V v_b_2457 = heff_field(v_x_2454, 1);
        V v_ru_24x_2454_24MkAlt = heff_take_reuse_n(v_x_2454, 3ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_b_2457)) {
        case TAG_At: {
          V v_n_2458 = heff_field(v_b_2457, 0);
          V v_sp_2459 = heff_field(v_b_2457, 1);
          heff_take_n(v_b_2457, 3ULL, 2);
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2458));
          v_t_2461 = heff_tag_at_n(v_ru_24alt_2449_24At, TAG_At, 2, (V[]){v_t_2460, v_sp_2459});
          break;
        }
        default: heff_nomatch(v_b_2457);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x_2454_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2456, v_t_2461});
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_alt_2449);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2453, v_t_2463});
  }
  case TAG_CLocal: {
    V v_body_2464 = heff_field(v_n_240, 0);
    V v_ds_2465 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_body_2464)) {
    case TAG_At: {
      V v_n_2466 = heff_field(v_body_2464, 0);
      V v_sp_2467 = heff_field(v_body_2464, 1);
      V v_ru_24body_2464_24At = heff_take_reuse_n(v_body_2464, 3ULL, 2);
      V v_t_2468 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2466));
      v_t_2469 = heff_tag_at_n(v_ru_24body_2464_24At, TAG_At, 2, (V[]){v_t_2468, v_sp_2467});
      break;
    }
    default: heff_nomatch(v_body_2464);
    }
    V v_t_2470 = (g_list_2emap_24s386875578x1005587669(v_ds_2465));
    return heff_tag_at_n(v_ru_24n_240_24CLocal, TAG_CLocal, 2, (V[]){v_t_2469, v_t_2470});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eevidenceCandidate_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eevidenceCandidate(V v_sp_240, V v_path_241, V v_w_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2ep_240(heff_dup(v_sp_240)));
  V v_t_244 = (g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(v_w_242, heff_dup(v_sp_240), v_path_241));
  V v_t_245 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_243, heff_dup(v_sp_240)}), v_t_244});
  V v_e_246 = heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2410 = v_field_249;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_n_2411 = heff_field(v_c_2410, 0);
        V v_sp_2412 = heff_field(v_c_2410, 1);
        V v_ru_24c_2410_24At = heff_take_reuse_n(v_c_2410, 3ULL, 2);
        V v_t_2413 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2411));
        return heff_tag_at_n(v_ru_24c_2410_24At, TAG_At, 2, (V[]){v_t_2413, v_sp_2412});
      }
      default: return heff_nomatch(v_c_2410);
      }
    } else {
      if ((v_tag_248 == ((int64_t)1ULL))) {
        V v_i_2414 = v_field_249;
        V v_t_2418;
        switch (heff_tag_of(v_i_2414)) {
        case TAG_At: {
          V v_n_2415 = heff_dup(heff_field(v_i_2414, 0));
          V v_sp_2416 = heff_dup(heff_field(v_i_2414, 1));
          V v_t_2417 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2415));
          v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_2416});
          break;
        }
        default: heff_nomatch(v_i_2414);
        }
        V v_t_2421;
        switch (heff_tag_of(v_i_2414)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_i_2414, 1);
          heff_take_n(v_i_2414, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_i_2414);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_t_2421});
      } else {
        V v_t_2422 = v_field_249;
        V v_t_2425;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_n_2423 = heff_dup(heff_field(v_t_2422, 0));
          V v_sp_2424 = heff_dup(heff_field(v_t_2422, 1));
          v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2424, v_n_2423));
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2428;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_s_2427 = heff_field(v_t_2422, 1);
          heff_take_n(v_t_2422, 2ULL, 2);
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eevidenceCandidate(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str3, 69, "nothing after this `with` runs: its statements do not reach their end");
Clo g_heff_2esyntax_2epresyntax_2ewithT_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithT_24tok2_entry, 10, 0};

V g_heff_2esyntax_2epresyntax_2ewithT_24tok2(V v_tok_240, V v_t_241, V v_cx_242, V v_sp_243, V v_w_244, V v_x_245, V v_xsp_246, V v_body_247, V v_rest_248, V v_end_249) {
top: ;
  V v_t_2410 = (g_list_2eany_24s2077819594x1842428557(v_x_245, heff_rfield(v_cx_242, 1)));
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    heff_drop_rec(v_cx_242, 6);
    heff_drop(v_sp_243);
    heff_drop(v_w_244);
    heff_drop(v_body_247);
    heff_drop(v_rest_248);
    heff_drop(v_end_249);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str0), heff_strAppend(heff_dup(v_x_245), ((V)&g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str1)));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str2), heff_strAppend(v_x_245, v_t_2411));
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2412}), v_xsp_246});
  } else {
    heff_drop(v_t_2410);
    V v_scope_2413 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_clo), 7, (V[]){heff_dup(v_t_241), heff_dup(v_cx_242), heff_dup(v_sp_243), v_w_244, v_x_245, v_xsp_246, heff_dup(v_body_247)}));
    V v_x1_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_247));
    V v_falls_2431;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nil: {
      v_falls_2431 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 2);
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_it11_2417 = heff_field(v_x_2415, 0);
        heff_take_n(v_x_2415, 1ULL, 2);
        switch (heff_tag_of(v_it11_2417)) {
        case TAG_StmtBind: {
          heff_take_n(v_it11_2417, 0ULL, 3);
          v_falls_2431 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLet: {
          heff_take_n(v_it11_2417, 0ULL, 2);
          v_falls_2431 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtExpr: {
          V v_e_2424 = heff_field(v_it11_2417, 0);
          heff_take_n(v_it11_2417, 1ULL, 1);
          v_falls_2431 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2424));
          break;
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_it11_2417, 0ULL, 3);
          v_falls_2431 = NTAG(TAG_True);
          break;
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_it11_2417, 0ULL, 3);
          v_falls_2431 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it11_2417);
        }
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    switch (heff_tag_of(v_rest_248)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_t_241);
      heff_drop_rec(v_cx_242, 6);
      heff_drop(v_sp_243);
      heff_drop(v_falls_2431);
      return heff_tail(v_scope_2413, 1, (V[]){v_end_249});
    }
    case TAG_Cons: {
      V v_s_2432 = heff_field(v_rest_248, 0);
      V v_rest_2433 = heff_field(v_rest_248, 1);
      heff_take_n(v_rest_248, 3ULL, 2);
      if ((heff_dup(v_falls_2431) == NTAG(TAG_True))) {
        heff_drop(v_falls_2431);
        return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_241, v_cx_242, v_sp_243, v_scope_2413, heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_2432, v_rest_2433}), v_end_249));
      } else {
        heff_drop(v_t_241);
        heff_drop_rec(v_cx_242, 6);
        heff_drop(v_sp_243);
        heff_drop(v_end_249);
        heff_drop(v_scope_2413);
        heff_drop(v_falls_2431);
        heff_drop(v_rest_2433);
        V v_t_2436;
        switch (heff_tag_of(v_s_2432)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_s_2432, 1);
          heff_take_n(v_s_2432, 2ULL, 2);
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_s_2432);
        }
        return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithT_24tok2_str3)}), v_t_2436});
      }
    }
    default: return heff_nomatch(v_rest_248);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewithT_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithT_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(V v_tok_240, V v_x1_241, V v_sp_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_x1_241, v_sp_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_IsCheckable, 1, (V[]){v_field_245});
    } else {
      if ((v_tag_244 == ((int64_t)1ULL))) {
        return heff_tag_at_n(v_tok_240, TAG_IsInferable, 1, (V[]){v_field_245});
      } else {
        return heff_tag_at_n(v_tok_240, TAG_IsType, 1, (V[]){v_field_245});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(a[0], a[1], a[2]);
}