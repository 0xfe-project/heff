// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo;
V g_heff_2esyntax_2epresyntax_2edoT_get(void);
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void);
V g_heff_2esyntax_2epresyntax_2eelseLeaving(V, V);
V g_heff_2esyntax_2epresyntax_2eelseLeaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eelseLeaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_clo;
V g_heff_2esyntax_2epresyntax_2etryScope(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_clo;
V g_heff_2esyntax_2epresyntax_2etryT(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryT_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s930586707x1164893977(V, V);
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a);
extern Clo g_list_2eany_24s930586707x1164893977_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
      return heff_rec_n(2, shape_head__args, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_tsp_245}), v_ps_246});
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_241, 0);
      V v_xsp_249 = heff_field(v_p1_241, 1);
      V v_ps_2410 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_248}), v_xsp_249});
      return heff_rec_n(2, shape_head__args, (V[]){v_t_2411, v_ps_2410});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatSpineOf(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SetField: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_xsp_246 = heff_field(v_x31_243, 1);
      V v_e_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_248 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_247}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x1_248, 0);
        V v_y_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_x_245, v_xsp_246, v_y_2410}), v_sp_244});
        return ((HeffT2){{v_x_249, v_t_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
      }
    }
    case TAG_BadFieldSet: {
      V v_e_2412 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_x1_2413 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2412}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        V v_y_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_y_2415}), v_sp_244});
        return ((HeffT2){{v_x_2414, v_t_2416}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        heff_take_n(v_a_244, 31ULL, 5);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_246)));
        }
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(v_a_2411, v_xs_243));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v_y_2416 = v_field_2414;
          V v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
          return ((HeffT2){{v_x_2415, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, v_y_2416})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_t_244 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      v_t_244 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_x_242)));
    }
    HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eaccList_24s538324696x1253971197_24cpr(v_t_244, v_xs_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      V v_y_249 = v_field_247;
      return ((HeffT2){{v_x_248, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_y_249})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_StmtBind: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLet: {
        heff_take_n(v_x111_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtExpr: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLetMut: {
        V v_x_2411 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 3);
        V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
        V v_u_2415 = (g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(v_rest_242, heff_dup(v_cell_2414)));
        heff_drop(v_u_2415);
        return v_cell_2414;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclaredMuts(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryT_str0, 89, "nothing after this `try` runs: neither its statements nor its `catch` arm reach their end");
Clo g_heff_2esyntax_2epresyntax_2etryT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryT_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2etryT(V v_t_240, V v_cx_241, V v_sp_242, V v_tr_243, V v_rest_244, V v_end_245) {
top: ;
  V v_scope_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2etryScope_clo), 4, (V[]){heff_dup(v_t_240), heff_dup(v_cx_241), heff_dup(v_sp_242), heff_dup(v_tr_243)}));
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETry, 1, (V[]){v_tr_243}), heff_dup(v_sp_242)});
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_247}), heff_dup(v_sp_242)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_249));
  V v_falls_2427;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_falls_2427 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    switch (heff_tag_of(v_x_2411)) {
    case TAG_At: {
      V v_it11_2413 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 2);
      switch (heff_tag_of(v_it11_2413)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2413, 0ULL, 2);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2420 = heff_field(v_it11_2413, 0);
        heff_take_n(v_it11_2413, 1ULL, 1);
        v_falls_2427 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2420));
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2413, 0ULL, 3);
        v_falls_2427 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it11_2413);
      }
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  switch (heff_tag_of(v_rest_244)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_cx_241);
    heff_drop(v_sp_242);
    heff_drop(v_falls_2427);
    return heff_tail(v_scope_246, 1, (V[]){v_end_245});
  }
  case TAG_Cons: {
    V v_s_2428 = heff_field(v_rest_244, 0);
    V v_rest_2429 = heff_field(v_rest_244, 1);
    V v_ru_24rest_244_24Cons = heff_take_reuse_n(v_rest_244, 3ULL, 2);
    if ((heff_dup(v_falls_2427) == NTAG(TAG_True))) {
      heff_drop(v_falls_2427);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_240, v_cx_241, v_sp_242, v_scope_246, heff_tag_at_n(v_ru_24rest_244_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_rest_2429}), v_end_245);
    } else {
      heff_drop(v_t_240);
      heff_drop(v_cx_241);
      heff_drop(v_sp_242);
      heff_drop(v_end_245);
      heff_drop(v_scope_246);
      heff_drop(v_falls_2427);
      heff_drop(v_rest_2429);
      heff_drop_cell(v_ru_24rest_244_24Cons, 2);
      V v_t_2432;
      switch (heff_tag_of(v_s_2428)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_s_2428, 1);
        heff_take_n(v_s_2428, 2ULL, 2);
        v_t_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_s_2428);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryT_str0)}), v_t_2432});
    }
  }
  default: return heff_nomatch(v_rest_244);
  }
}
V g_heff_2esyntax_2epresyntax_2etryT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etryT(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eelseFalls_str0, 136, "the `else` of `let p = e else ...` must leave the block: end it with `return`, `break`, `continue` or `abandon`; for a value, use `case`");

static V g_heff_2esyntax_2epresyntax_2eelseFalls_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eelseFalls_st;
static V g_heff_2esyntax_2epresyntax_2eelseFalls_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2eelseFalls_str0);
}
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eelseFalls_st)) return g_heff_2esyntax_2epresyntax_2eelseFalls_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eelseFalls_val, &g_heff_2esyntax_2epresyntax_2eelseFalls_st, g_heff_2esyntax_2epresyntax_2eelseFalls_init);
}
Clo g_heff_2esyntax_2epresyntax_2eelseLeaving_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eelseLeaving_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eelseLeaving(V v_sp_240, V v_ss_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_241)));
  V v_t_2419;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_it11_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_it11_245)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_245, 0ULL, 3);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_245, 0ULL, 2);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2412 = heff_field(v_it11_245, 0);
        heff_take_n(v_it11_245, 1ULL, 1);
        v_t_2419 = (g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(v_e_2412));
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_245, 0ULL, 3);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_245, 0ULL, 3);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it11_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_sp_240);
    heff_drop(v_t_2419);
    return v_ss_241;
  } else {
    heff_drop(v_t_2419);
    V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_241));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eelseFalls_get())}), heff_dup(v_sp_240)});
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2421}), v_sp_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24Cons = heff_take_reuse_n(v_x1_2420, 1ULL, 2);
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_esp_2426 = heff_field(v_x_2423, 1);
        V v_ru_24x_2423_24At = heff_take_reuse_n(v_x_2423, 2ULL, 2);
        V v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eelseFalls_get())}), heff_dup(v_esp_2426)});
        V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2427}), v_esp_2426});
        return heff_tag_at_n(v_ru_24x1_2420_24Cons, TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_x_2423);
      }
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eelseLeaving_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eelseLeaving(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str0, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str1, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str3, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str4, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str6, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str7, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str8, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str10, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str11, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str12, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str13, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str15, 1, "_");
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V v_cx_240, V v_x3_241, V v_rest_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_sp_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_StmtBind: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_xsp_247 = heff_field(v_x31_244, 1);
      V v_e_248 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 7ULL, 3);
      heff_drop_rec(v_sp_245, 2);
      V v_t_249 = (g_list_2eany_24s930586707x1164893977(v_x_246, heff_rfield(v_cx_240, 1)));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop_rec(v_cx_240, 5);
        heff_drop(v_rest_242);
        heff_drop(v_end_243);
        heff_drop(v_e_248);
        heff_drop(v_t_249);
        V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str0), heff_strAppend(heff_dup(v_x_246), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str1)));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str2), heff_strAppend(v_x_246, v_t_2410));
        return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2411}), v_xsp_247});
      } else {
        heff_drop(v_t_249);
        V v_t_2412 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2412}), NTAG(TAG_Nil), v_e_248));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          V v_y_2417 = v_field_2415;
          V v_rest_2418 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_242; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_242); r_; });
          V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 2);
          V v_t_2420 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2419}), heff_dup(heff_rfield(v_cx_240, 3))});
          V v_t_2421 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_246, heff_dup(v_xsp_247)}), heff_dup(v_rest_2418)});
          V v_t_2424;
          switch (heff_tag_of(v_rest_2418)) {
          case TAG_At: {
            V v_s_2423 = heff_field(v_rest_2418, 1);
            heff_take_n(v_rest_2418, 2ULL, 2);
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_rest_2418);
          }
          V v_t_2425 = ({ V rv_1 = heff_get_n(v_t_2424, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_247, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_t_2425}), NTAG(TAG_Nil)});
          V v_t_2427 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2417, v_t_2426})));
          return ({ V a_0 = v_cx_240; V a_1 = v_x_2416; V a_2 = v_t_2427; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2416); r_; });
        }
      }
    }
    case TAG_StmtLet: {
      V v_p_2428 = heff_field(v_x31_244, 0);
      V v_e_2429 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24StmtLet = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_xs_2430 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_2428)));
      HeffT2 v_t_2432 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam0, 1, 1, (V[]){heff_dup(v_cx_240)}), v_xs_2430));
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          heff_drop_rec(v_cx_240, 5);
          heff_drop(v_rest_242);
          heff_drop(v_end_243);
          heff_drop_rec(v_sp_245, 2);
          heff_drop(v_e_2429);
          heff_drop_cell(v_ru_24x31_244_24StmtLet, 2);
          V v_x_2436 = v_field_2434;
          V v_t_2437 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str3), heff_strAppend(heff_dup(v_x_2436), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str4)));
          V v_t_2438 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str5), heff_strAppend(v_x_2436, v_t_2437));
          V v_t_2441;
          switch (heff_tag_of(v_p_2428)) {
          case TAG_At: {
            V v_s_2440 = heff_field(v_p_2428, 1);
            heff_take_n(v_p_2428, 2ULL, 2);
            v_t_2441 = v_s_2440;
            break;
          }
          default: heff_nomatch(v_p_2428);
          }
          return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2438}), v_t_2441});
        } else {
          heff_drop(v_field_2434);
          V v_t_2442 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2443 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2442}), NTAG(TAG_Nil), v_e_2429));
          {
            V v_field_2444 = v_t_2443.f[0];
            V v_field_2445 = v_t_2443.f[1];
            V v_x_2446 = v_field_2444;
            V v_y_2447 = v_field_2445;
            V v_body_2448 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_242; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_242); r_; });
            V v_t_2451;
            switch (heff_tag_of(v_p_2428)) {
            case TAG_At: {
              V v_s_2450 = heff_dup(heff_field(v_p_2428, 1));
              v_t_2451 = v_s_2450;
              break;
            }
            default: heff_nomatch(v_p_2428);
            }
            V v_t_2454;
            switch (heff_tag_of(v_body_2448)) {
            case TAG_At: {
              V v_s_2453 = heff_dup(heff_field(v_body_2448, 1));
              v_t_2454 = v_s_2453;
              break;
            }
            default: heff_nomatch(v_body_2448);
            }
            V v_t_2455 = ({ V rv_1 = heff_get_n(v_t_2454, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2451, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2456 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2428, heff_dup(v_body_2448)}), v_t_2455});
            V v_t_2459;
            switch (heff_tag_of(v_body_2448)) {
            case TAG_At: {
              V v_s_2458 = heff_field(v_body_2448, 1);
              heff_take_n(v_body_2448, 2ULL, 2);
              v_t_2459 = v_s_2458;
              break;
            }
            default: heff_nomatch(v_body_2448);
            }
            V v_t_2460 = ({ V rv_1 = heff_get_n(v_t_2459, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2461 = heff_tag_at_n(v_ru_24x31_244_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_2447, v_t_2456}), v_t_2460});
            return ({ V a_0 = v_cx_240; V a_1 = v_x_2446; V a_2 = v_t_2461; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2446); r_; });
          }
        }
      }
    }
    case TAG_StmtExpr: {
      V v_e_2462 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_rec(v_sp_245, 2);
      V v_t_2463 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2462));
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_t_2463);
        return (g_heff_2esyntax_2epresyntax_2econtrolT(heff_dup(g_heff_2esyntax_2epresyntax_2edoT_get()), v_cx_240, v_e_2462, v_rest_242, v_end_243));
      } else {
        heff_drop(v_t_2463);
        V v_t_2464 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_2465 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2464}), NTAG(TAG_Nil), v_e_2462));
        {
          V v_field_2466 = v_t_2465.f[0];
          V v_field_2467 = v_t_2465.f[1];
          V v_x_2468 = v_field_2466;
          V v_y_2469 = v_field_2467;
          V v_xsp_2470 = heff_dup(heff_rfield(v_cx_240, 3));
          V v_rest_2471 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_242; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_242); r_; });
          V v_t_2472 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 2);
          V v_t_2473 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2472}), heff_dup(heff_rfield(v_cx_240, 3))});
          V v_t_2474 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str6), heff_dup(v_xsp_2470)}), heff_dup(v_rest_2471)});
          V v_t_2477;
          switch (heff_tag_of(v_rest_2471)) {
          case TAG_At: {
            V v_s_2476 = heff_field(v_rest_2471, 1);
            heff_take_n(v_rest_2471, 2ULL, 2);
            v_t_2477 = v_s_2476;
            break;
          }
          default: heff_nomatch(v_rest_2471);
          }
          V v_t_2478 = ({ V rv_1 = heff_get_n(v_t_2477, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2470, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2474, v_t_2478}), NTAG(TAG_Nil)});
          V v_t_2480 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2473, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2469, v_t_2479})));
          return ({ V a_0 = v_cx_240; V a_1 = v_x_2468; V a_2 = v_t_2480; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2468); r_; });
        }
      }
    }
    case TAG_StmtLetMut: {
      V v_x_2481 = heff_field(v_x31_244, 0);
      V v_xsp_2482 = heff_field(v_x31_244, 1);
      V v_e_2483 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 7ULL, 3);
      heff_drop_rec(v_sp_245, 2);
      V v_t_2484 = (g_list_2eany_24s930586707x1164893977(v_x_2481, heff_rfield(v_cx_240, 1)));
      if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
        heff_drop_rec(v_cx_240, 5);
        heff_drop(v_rest_242);
        heff_drop(v_end_243);
        heff_drop(v_e_2483);
        heff_drop(v_t_2484);
        V v_t_2485 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str7), heff_strAppend(heff_dup(v_x_2481), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str8)));
        V v_t_2486 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str9), heff_strAppend(v_x_2481, v_t_2485));
        return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2486}), v_xsp_2482});
      } else {
        heff_drop(v_t_2484);
        V v_t_2487 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_2488 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2487}), NTAG(TAG_Nil), v_e_2483));
        {
          V v_field_2489 = v_t_2488.f[0];
          V v_field_2490 = v_t_2488.f[1];
          V v_x_2491 = v_field_2489;
          V v_y_2492 = v_field_2490;
          V v_sp_2495;
          switch (heff_tag_of(v_y_2492)) {
          case TAG_At: {
            V v_s_2494 = heff_dup(heff_field(v_y_2492, 1));
            v_sp_2495 = v_s_2494;
            break;
          }
          default: heff_nomatch(v_y_2492);
          }
          V v_t_2496 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str10)}), heff_dup(v_sp_2495)});
          V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str11)}), v_sp_2495});
          V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
          V v_t_2499 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2496, v_t_2498));
          V v_t_24102;
          switch (heff_tag_of(v_y_2492)) {
          case TAG_At: {
            V v_s_24101 = heff_dup(heff_field(v_y_2492, 1));
            v_t_24102 = v_s_24101;
            break;
          }
          default: heff_nomatch(v_y_2492);
          }
          V v_v_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_2492, v_t_2499}), v_t_24102});
          V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2481), NTAG(TAG_Nil)});
          V v_t_24105 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_cx_240, 1)), v_t_24104));
          V v_cx_24106 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), v_t_24105, heff_dup(heff_rfield(v_cx_240, 2)), heff_dup(heff_rfield(v_cx_240, 3)), heff_dup(heff_rfield(v_cx_240, 4))});
          V v_body_24107 = ({ V a_0 = v_cx_24106; V a_1 = v_rest_242; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_242); r_; });
          V v_t_24108 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2481}), heff_dup(v_xsp_2482)});
          V v_t_24111;
          switch (heff_tag_of(v_body_24107)) {
          case TAG_At: {
            V v_s_24110 = heff_dup(heff_field(v_body_24107, 1));
            v_t_24111 = v_s_24110;
            break;
          }
          default: heff_nomatch(v_body_24107);
          }
          V v_t_24112 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_2482, 0)); V rr_ = heff_rec_reuse_nf(v_t_24111, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_24108, heff_dup(v_body_24107)}), v_t_24112});
          V v_t_24116;
          switch (heff_tag_of(v_body_24107)) {
          case TAG_At: {
            V v_s_24115 = heff_field(v_body_24107, 1);
            heff_take_n(v_body_24107, 2ULL, 2);
            v_t_24116 = v_s_24115;
            break;
          }
          default: heff_nomatch(v_body_24107);
          }
          V v_t_24117 = ({ V rv_1 = heff_get_n(v_t_24116, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2482, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_24103, v_t_24113}), v_t_24117});
          return ({ V a_0 = v_cx_240; V a_1 = v_x_2491; V a_2 = v_t_24118; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2491); r_; });
        }
      }
    }
    case TAG_StmtLetElse: {
      V v_p_24119 = heff_field(v_x31_244, 0);
      V v_e_24120 = heff_field(v_x31_244, 1);
      V v_els_24121 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 7ULL, 3);
      V v_xs_24122 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24119)));
      HeffT2 v_t_24124 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam1, 1, 1, (V[]){heff_dup(v_cx_240)}), v_xs_24122));
      {
        V v_field_24126 = v_t_24124.f[1];
        int64_t v_tag_24125 = ((int64_t)v_t_24124.f[0]);
        if ((v_tag_24125 == ((int64_t)0ULL))) {
          heff_drop_rec(v_cx_240, 5);
          heff_drop(v_rest_242);
          heff_drop(v_end_243);
          heff_drop_rec(v_sp_245, 2);
          heff_drop(v_e_24120);
          heff_drop(v_els_24121);
          V v_x_24128 = v_field_24126;
          V v_t_24129 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str12), heff_strAppend(heff_dup(v_x_24128), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str13)));
          V v_t_24130 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str14), heff_strAppend(v_x_24128, v_t_24129));
          V v_t_24133;
          switch (heff_tag_of(v_p_24119)) {
          case TAG_At: {
            V v_s_24132 = heff_field(v_p_24119, 1);
            heff_take_n(v_p_24119, 2ULL, 2);
            v_t_24133 = v_s_24132;
            break;
          }
          default: heff_nomatch(v_p_24119);
          }
          return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24130}), v_t_24133});
        } else {
          heff_drop(v_field_24126);
          V v_t_24134 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str15)}), heff_dup(v_sp_245)});
          V v_t_24135 = (g_heff_2esyntax_2epresyntax_2eelseLeaving(heff_dup(v_sp_245), v_els_24121));
          V v_t_24136 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24134, v_t_24135}), NTAG(TAG_Nil)});
          V v_t_24137 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_p_24119, v_rest_242}), v_t_24136});
          return (g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(v_cx_240, v_sp_245, v_e_24120, v_t_24137, NTAG(TAG_Nil), v_end_243));
        }
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam0(V self, V *args) {
  V v_x_2431 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2431; V b_1 = heff_get_n(v_cx_240, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_2431); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam1(V self, V *args) {
  V v_x_24123 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24123; V b_1 = heff_get_n(v_cx_240, 1, 5); V r_ = (g_list_2eany_24s930586707x1164893977(a_0, b_1)); heff_drop(v_x_24123); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str0, 3, "run");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str3, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str5, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2erunArgs_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2erunArgs(V v_h_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_242 = heff_field(v_h_240, 0);
    V v_ru_24h_240_24At = heff_take_reuse_n(v_h_240, 1ULL, 2);
    switch (heff_tag_of(v_h1_242)) {
    case TAG_EVar: {
      V v_f_244 = heff_field(v_h1_242, 0);
      heff_take_n(v_h1_242, 1ULL, 1);
      switch (heff_tag_of(v_args_241)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24h_240_24At, 2);
        heff_drop(v_f_244);
        return v_args_241;
      }
      case TAG_Cons: {
        V v_args1_245 = heff_dup(heff_field(v_args_241, 0));
        V v_args2_246 = heff_dup(heff_field(v_args_241, 1));
        switch (heff_tag_of(v_args1_245)) {
        case TAG_At: {
          V v_args11_247 = heff_field(v_args1_245, 0);
          V v_dsp_248 = heff_field(v_args1_245, 1);
          V v_ru_24args1_245_24At = heff_take_reuse_n(v_args1_245, 3ULL, 2);
          switch (heff_tag_of(v_args11_247)) {
          case TAG_EVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETag: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInt: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFloat: {
            heff_take_na(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EString: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBinary: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ERune: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWord: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EApp: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EProject: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENamed: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EPi: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELam: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAnn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESpec: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESig: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESum: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EStruct: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EUpdate: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EMatch: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELetIn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EDo: {
            V v_ss_2442 = heff_field(v_args11_247, 0);
            heff_take_n(v_args11_247, 1ULL, 1);
            switch (heff_tag_of(v_args2_246)) {
            case TAG_Nil: {
              heff_drop_tag(v_args_241, 2);
              if (heff_strEq_c(v_f_244, ((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str0))) {
                V v_x1_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_2442)));
                V v_t_2463;
                switch (heff_tag_of(v_x1_2444)) {
                case TAG_Nil: {
                  heff_drop(v_ss_2442);
                  v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str1)}), v_dsp_248});
                  break;
                }
                case TAG_Cons: {
                  V v_x_2445 = heff_field(v_x1_2444, 0);
                  heff_take_n(v_x1_2444, 1ULL, 2);
                  switch (heff_tag_of(v_x_2445)) {
                  case TAG_At: {
                    V v_it11_2447 = heff_field(v_x_2445, 0);
                    heff_take_n(v_x_2445, 1ULL, 2);
                    switch (heff_tag_of(v_it11_2447)) {
                    case TAG_StmtBind: {
                      heff_take_n(v_it11_2447, 0ULL, 3);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str2)}), v_dsp_248});
                      break;
                    }
                    case TAG_StmtLet: {
                      heff_take_n(v_it11_2447, 0ULL, 2);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str3)}), v_dsp_248});
                      break;
                    }
                    case TAG_StmtExpr: {
                      heff_take_n(v_it11_2447, 0ULL, 1);
                      heff_drop_cell(v_ru_24h_240_24At, 2);
                      V v_t_2455 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eidNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_dsp_248, MK_INT(0LL)});
                      V v_t_2456 = ({ V a_0 = v_t_2455; V a_1 = v_ss_2442; V a_2 = NTAG(TAG_EndValue); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_ss_2442); r_; });
                      v_t_2463 = v_t_2456;
                      break;
                    }
                    case TAG_StmtLetMut: {
                      heff_take_n(v_it11_2447, 0ULL, 3);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str4)}), v_dsp_248});
                      break;
                    }
                    case TAG_StmtLetElse: {
                      heff_take_n(v_it11_2447, 0ULL, 3);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str5)}), v_dsp_248});
                      break;
                    }
                    default: heff_nomatch(v_it11_2447);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x_2445);
                  }
                  break;
                }
                default: heff_nomatch(v_x1_2444);
                }
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
              } else {
                V v_t_2464 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_ss_2442}), v_dsp_248});
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
              }
            }
            case TAG_Cons: {
              heff_take_n(v_args2_246, 0ULL, 2);
              heff_drop_cell(v_ru_24h_240_24At, 2);
              heff_drop(v_f_244);
              heff_drop(v_dsp_248);
              heff_drop_cell(v_ru_24args1_245_24At, 2);
              heff_drop(v_ss_2442);
              return v_args_241;
            }
            default: return heff_nomatch(v_args2_246);
            }
          }
          case TAG_ELocal: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInvalid: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAssign: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWhile: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFor: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EIfThen: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBreak: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EContinue: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EReturn: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENest: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELazy: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETuple: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETry: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWith: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          default: return heff_nomatch(v_args11_247);
          }
        }
        default: return heff_nomatch(v_args1_245);
        }
      }
      default: return heff_nomatch(v_args_241);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETag: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInt: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EString: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBinary: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ERune: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWord: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EApp: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EProject: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENamed: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EPi: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELam: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAnn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESig: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESum: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EStruct: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EUpdate: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELetIn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EDo: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELocal: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInvalid: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAssign: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWhile: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFor: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EIfThen: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EReturn: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENest: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELazy: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETuple: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETry: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWith: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    default: return heff_nomatch(v_h1_242);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2erunArgs(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eargOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_dup(heff_field(v_x2_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EVar, 1);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), v_t_2418});
    }
    case TAG_EImplicitVar: {
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EImplicitVar, 1);
        v_t_2430 = v_c_2425;
        break;
      }
      case TAG_IsType: {
        V v_t_2426 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2433;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2430}), v_t_2433});
    }
    case TAG_ETag: {
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETag, 1);
        v_t_2445 = v_c_2440;
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_CType, 1, (V[]){v_t_2441}), v_t_2444});
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2448;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2445}), v_t_2448});
    }
    case TAG_EInt: {
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2460;
      switch (heff_tag_of(v_x1_2450)) {
      case TAG_IsInferable: {
        V v_i_2451 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2455 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInt, 1);
        v_t_2460 = v_c_2455;
        break;
      }
      case TAG_IsType: {
        V v_t_2456 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
        break;
      }
      default: heff_nomatch(v_x1_2450);
      }
      V v_t_2463;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2460}), v_t_2463});
    }
    case TAG_EFloat: {
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2475;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_IsInferable: {
        V v_i_2466 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2469;
        switch (heff_tag_of(v_i_2466)) {
        case TAG_At: {
          V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
          v_t_2469 = v_s_2468;
          break;
        }
        default: heff_nomatch(v_i_2466);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2470 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EFloat, 1);
        v_t_2475 = v_c_2470;
        break;
      }
      case TAG_IsType: {
        V v_t_2471 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2478;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EString: {
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2490;
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_IsInferable: {
        V v_i_2481 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2484;
        switch (heff_tag_of(v_i_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_i_2481);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CInf, 1, (V[]){v_i_2481}), v_t_2484});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2485 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EString, 1);
        v_t_2490 = v_c_2485;
        break;
      }
      case TAG_IsType: {
        V v_t_2486 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_t_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_CType, 1, (V[]){v_t_2486}), v_t_2489});
        break;
      }
      default: heff_nomatch(v_x1_2480);
      }
      V v_t_2493;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2490}), v_t_2493});
    }
    case TAG_EBinary: {
      V v_ru_24x21_242_24EBinary = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24105;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_IsInferable: {
        V v_i_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_i_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_i_2496);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CInf, 1, (V[]){v_i_2496}), v_t_2499});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24100 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EBinary, 1);
        v_t_24105 = v_c_24100;
        break;
      }
      case TAG_IsType: {
        V v_t_24101 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_t_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EBinary, TAG_CType, 1, (V[]){v_t_24101}), v_t_24104});
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_t_24108;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24105}), v_t_24108});
    }
    case TAG_ERune: {
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24120;
      switch (heff_tag_of(v_x1_24110)) {
      case TAG_IsInferable: {
        V v_i_24111 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24114;
        switch (heff_tag_of(v_i_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_i_24111);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24115 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ERune, 1);
        v_t_24120 = v_c_24115;
        break;
      }
      case TAG_IsType: {
        V v_t_24116 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_t_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_t_24116);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
        break;
      }
      default: heff_nomatch(v_x1_24110);
      }
      V v_t_24123;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24120}), v_t_24123});
    }
    case TAG_EWord: {
      V v_ru_24x21_242_24EWord = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24125 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24135;
      switch (heff_tag_of(v_x1_24125)) {
      case TAG_IsInferable: {
        V v_i_24126 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24129;
        switch (heff_tag_of(v_i_24126)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_i_24126, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_i_24126);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CInf, 1, (V[]){v_i_24126}), v_t_24129});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24130 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EWord, 1);
        v_t_24135 = v_c_24130;
        break;
      }
      case TAG_IsType: {
        V v_t_24131 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24134;
        switch (heff_tag_of(v_t_24131)) {
        case TAG_At: {
          V v_s_24133 = heff_dup(heff_field(v_t_24131, 1));
          v_t_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_t_24131);
        }
        v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EWord, TAG_CType, 1, (V[]){v_t_24131}), v_t_24134});
        break;
      }
      default: heff_nomatch(v_x1_24125);
      }
      V v_t_24138;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24137 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24138 = v_s_24137;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24135}), v_t_24138});
    }
    case TAG_EApp: {
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24151;
      switch (heff_tag_of(v_x1_24141)) {
      case TAG_IsInferable: {
        V v_i_24142 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24145;
        switch (heff_tag_of(v_i_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_dup(heff_field(v_i_24142, 1));
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_i_24142);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24142}), v_t_24145});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24146 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EApp, 2);
        v_t_24151 = v_c_24146;
        break;
      }
      case TAG_IsType: {
        V v_t_24147 = heff_field(v_x1_24141, 0);
        heff_take_n(v_x1_24141, 1ULL, 1);
        V v_t_24150;
        switch (heff_tag_of(v_t_24147)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
          v_t_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_t_24147);
        }
        v_t_24151 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
        break;
      }
      default: heff_nomatch(v_x1_24141);
      }
      V v_t_24154;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_EProject: {
      V v_x_24155 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_tag(v_x2_241, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_24155}), v_sp_243});
    }
    case TAG_ENamed: {
      V v_x_24156 = heff_field(v_x21_242, 0);
      V v_e_24157 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      V v_x1_24158 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24157}));
      V v_t_24168;
      switch (heff_tag_of(v_x1_24158)) {
      case TAG_IsInferable: {
        V v_i_24159 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        V v_t_24162;
        switch (heff_tag_of(v_i_24159)) {
        case TAG_At: {
          V v_s_24161 = heff_dup(heff_field(v_i_24159, 1));
          v_t_24162 = v_s_24161;
          break;
        }
        default: heff_nomatch(v_i_24159);
        }
        v_t_24168 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24159}), v_t_24162});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24163 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
        v_t_24168 = v_c_24163;
        break;
      }
      case TAG_IsType: {
        V v_t_24164 = heff_field(v_x1_24158, 0);
        heff_take_n(v_x1_24158, 1ULL, 1);
        V v_t_24167;
        switch (heff_tag_of(v_t_24164)) {
        case TAG_At: {
          V v_s_24166 = heff_dup(heff_field(v_t_24164, 1));
          v_t_24167 = v_s_24166;
          break;
        }
        default: heff_nomatch(v_t_24164);
        }
        v_t_24168 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24164}), v_t_24167});
        break;
      }
      default: heff_nomatch(v_x1_24158);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24156, v_t_24168}), v_sp_243});
    }
    case TAG_EPi: {
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24171 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24181;
      switch (heff_tag_of(v_x1_24171)) {
      case TAG_IsInferable: {
        V v_i_24172 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24175;
        switch (heff_tag_of(v_i_24172)) {
        case TAG_At: {
          V v_s_24174 = heff_dup(heff_field(v_i_24172, 1));
          v_t_24175 = v_s_24174;
          break;
        }
        default: heff_nomatch(v_i_24172);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24172}), v_t_24175});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24176 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EPi, 2);
        v_t_24181 = v_c_24176;
        break;
      }
      case TAG_IsType: {
        V v_t_24177 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24180;
        switch (heff_tag_of(v_t_24177)) {
        case TAG_At: {
          V v_s_24179 = heff_dup(heff_field(v_t_24177, 1));
          v_t_24180 = v_s_24179;
          break;
        }
        default: heff_nomatch(v_t_24177);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24177}), v_t_24180});
        break;
      }
      default: heff_nomatch(v_x1_24171);
      }
      V v_t_24184;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24183 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24184 = v_s_24183;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24181}), v_t_24184});
    }
    case TAG_ELam: {
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24187 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24197;
      switch (heff_tag_of(v_x1_24187)) {
      case TAG_IsInferable: {
        V v_i_24188 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24191;
        switch (heff_tag_of(v_i_24188)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_i_24188, 1));
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_i_24188);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24188}), v_t_24191});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24192 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        v_t_24197 = v_c_24192;
        break;
      }
      case TAG_IsType: {
        V v_t_24193 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24196;
        switch (heff_tag_of(v_t_24193)) {
        case TAG_At: {
          V v_s_24195 = heff_dup(heff_field(v_t_24193, 1));
          v_t_24196 = v_s_24195;
          break;
        }
        default: heff_nomatch(v_t_24193);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24193}), v_t_24196});
        break;
      }
      default: heff_nomatch(v_x1_24187);
      }
      V v_t_24200;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24199 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24200 = v_s_24199;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24197}), v_t_24200});
    }
    case TAG_EAnn: {
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24203 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24213;
      switch (heff_tag_of(v_x1_24203)) {
      case TAG_IsInferable: {
        V v_i_24204 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        V v_t_24207;
        switch (heff_tag_of(v_i_24204)) {
        case TAG_At: {
          V v_s_24206 = heff_dup(heff_field(v_i_24204, 1));
          v_t_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_i_24204);
        }
        v_t_24213 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24204}), v_t_24207});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24208 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24213 = v_c_24208;
        break;
      }
      case TAG_IsType: {
        V v_t_24209 = heff_field(v_x1_24203, 0);
        heff_take_n(v_x1_24203, 1ULL, 1);
        V v_t_24212;
        switch (heff_tag_of(v_t_24209)) {
        case TAG_At: {
          V v_s_24211 = heff_dup(heff_field(v_t_24209, 1));
          v_t_24212 = v_s_24211;
          break;
        }
        default: heff_nomatch(v_t_24209);
        }
        v_t_24213 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24209}), v_t_24212});
        break;
      }
      default: heff_nomatch(v_x1_24203);
      }
      V v_t_24216;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24215 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24216 = v_s_24215;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24213}), v_t_24216});
    }
    case TAG_ESpec: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_24221 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24231;
      switch (heff_tag_of(v_x1_24221)) {
      case TAG_IsInferable: {
        V v_i_24222 = heff_field(v_x1_24221, 0);
        V v_ru_24x1_24221_24IsInferable = heff_take_reuse_n(v_x1_24221, 1ULL, 1);
        V v_t_24225;
        switch (heff_tag_of(v_i_24222)) {
        case TAG_At: {
          V v_s_24224 = heff_dup(heff_field(v_i_24222, 1));
          v_t_24225 = v_s_24224;
          break;
        }
        default: heff_nomatch(v_i_24222);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24221_24IsInferable, TAG_CInf, 1, (V[]){v_i_24222}), v_t_24225});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24226 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        v_t_24231 = v_c_24226;
        break;
      }
      case TAG_IsType: {
        V v_t_24227 = heff_field(v_x1_24221, 0);
        V v_ru_24x1_24221_24IsType = heff_take_reuse_n(v_x1_24221, 1ULL, 1);
        V v_t_24230;
        switch (heff_tag_of(v_t_24227)) {
        case TAG_At: {
          V v_s_24229 = heff_dup(heff_field(v_t_24227, 1));
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_t_24227);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24221_24IsType, TAG_CType, 1, (V[]){v_t_24227}), v_t_24230});
        break;
      }
      default: heff_nomatch(v_x1_24221);
      }
      V v_t_24234;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24233 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24234 = v_s_24233;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24231}), v_t_24234});
    }
    case TAG_ESig: {
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24236 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24246;
      switch (heff_tag_of(v_x1_24236)) {
      case TAG_IsInferable: {
        V v_i_24237 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24240;
        switch (heff_tag_of(v_i_24237)) {
        case TAG_At: {
          V v_s_24239 = heff_dup(heff_field(v_i_24237, 1));
          v_t_24240 = v_s_24239;
          break;
        }
        default: heff_nomatch(v_i_24237);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CInf, 1, (V[]){v_i_24237}), v_t_24240});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24241 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESig, 1);
        v_t_24246 = v_c_24241;
        break;
      }
      case TAG_IsType: {
        V v_t_24242 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24245;
        switch (heff_tag_of(v_t_24242)) {
        case TAG_At: {
          V v_s_24244 = heff_dup(heff_field(v_t_24242, 1));
          v_t_24245 = v_s_24244;
          break;
        }
        default: heff_nomatch(v_t_24242);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_CType, 1, (V[]){v_t_24242}), v_t_24245});
        break;
      }
      default: heff_nomatch(v_x1_24236);
      }
      V v_t_24249;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24248 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24249 = v_s_24248;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24246}), v_t_24249});
    }
    case TAG_ESum: {
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24261;
      switch (heff_tag_of(v_x1_24251)) {
      case TAG_IsInferable: {
        V v_i_24252 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24255;
        switch (heff_tag_of(v_i_24252)) {
        case TAG_At: {
          V v_s_24254 = heff_dup(heff_field(v_i_24252, 1));
          v_t_24255 = v_s_24254;
          break;
        }
        default: heff_nomatch(v_i_24252);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CInf, 1, (V[]){v_i_24252}), v_t_24255});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24256 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ESum, 1);
        v_t_24261 = v_c_24256;
        break;
      }
      case TAG_IsType: {
        V v_t_24257 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24260;
        switch (heff_tag_of(v_t_24257)) {
        case TAG_At: {
          V v_s_24259 = heff_dup(heff_field(v_t_24257, 1));
          v_t_24260 = v_s_24259;
          break;
        }
        default: heff_nomatch(v_t_24257);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_CType, 1, (V[]){v_t_24257}), v_t_24260});
        break;
      }
      default: heff_nomatch(v_x1_24251);
      }
      V v_t_24264;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24263 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24264 = v_s_24263;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24261}), v_t_24264});
    }
    case TAG_EStruct: {
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24266 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24276;
      switch (heff_tag_of(v_x1_24266)) {
      case TAG_IsInferable: {
        V v_i_24267 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24270;
        switch (heff_tag_of(v_i_24267)) {
        case TAG_At: {
          V v_s_24269 = heff_dup(heff_field(v_i_24267, 1));
          v_t_24270 = v_s_24269;
          break;
        }
        default: heff_nomatch(v_i_24267);
        }
        v_t_24276 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CInf, 1, (V[]){v_i_24267}), v_t_24270});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24271 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EStruct, 1);
        v_t_24276 = v_c_24271;
        break;
      }
      case TAG_IsType: {
        V v_t_24272 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24275;
        switch (heff_tag_of(v_t_24272)) {
        case TAG_At: {
          V v_s_24274 = heff_dup(heff_field(v_t_24272, 1));
          v_t_24275 = v_s_24274;
          break;
        }
        default: heff_nomatch(v_t_24272);
        }
        v_t_24276 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CType, 1, (V[]){v_t_24272}), v_t_24275});
        break;
      }
      default: heff_nomatch(v_x1_24266);
      }
      V v_t_24279;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24278 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24279 = v_s_24278;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24276}), v_t_24279});
    }
    case TAG_EUpdate: {
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24282 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24292;
      switch (heff_tag_of(v_x1_24282)) {
      case TAG_IsInferable: {
        V v_i_24283 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24286;
        switch (heff_tag_of(v_i_24283)) {
        case TAG_At: {
          V v_s_24285 = heff_dup(heff_field(v_i_24283, 1));
          v_t_24286 = v_s_24285;
          break;
        }
        default: heff_nomatch(v_i_24283);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24283}), v_t_24286});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24287 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EUpdate, 2);
        v_t_24292 = v_c_24287;
        break;
      }
      case TAG_IsType: {
        V v_t_24288 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24291;
        switch (heff_tag_of(v_t_24288)) {
        case TAG_At: {
          V v_s_24290 = heff_dup(heff_field(v_t_24288, 1));
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_t_24288);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24288}), v_t_24291});
        break;
      }
      default: heff_nomatch(v_x1_24282);
      }
      V v_t_24295;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24294 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24295 = v_s_24294;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24292}), v_t_24295});
    }
    case TAG_EMatch: {
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24298 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24308;
      switch (heff_tag_of(v_x1_24298)) {
      case TAG_IsInferable: {
        V v_i_24299 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24302;
        switch (heff_tag_of(v_i_24299)) {
        case TAG_At: {
          V v_s_24301 = heff_dup(heff_field(v_i_24299, 1));
          v_t_24302 = v_s_24301;
          break;
        }
        default: heff_nomatch(v_i_24299);
        }
        v_t_24308 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24299}), v_t_24302});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24303 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EMatch, 2);
        v_t_24308 = v_c_24303;
        break;
      }
      case TAG_IsType: {
        V v_t_24304 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24307;
        switch (heff_tag_of(v_t_24304)) {
        case TAG_At: {
          V v_s_24306 = heff_dup(heff_field(v_t_24304, 1));
          v_t_24307 = v_s_24306;
          break;
        }
        default: heff_nomatch(v_t_24304);
        }
        v_t_24308 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24304}), v_t_24307});
        break;
      }
      default: heff_nomatch(v_x1_24298);
      }
      V v_t_24311;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24310 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24311 = v_s_24310;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24308}), v_t_24311});
    }
    case TAG_ELetIn: {
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24314 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24324;
      switch (heff_tag_of(v_x1_24314)) {
      case TAG_IsInferable: {
        V v_i_24315 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24318;
        switch (heff_tag_of(v_i_24315)) {
        case TAG_At: {
          V v_s_24317 = heff_dup(heff_field(v_i_24315, 1));
          v_t_24318 = v_s_24317;
          break;
        }
        default: heff_nomatch(v_i_24315);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24315}), v_t_24318});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24319 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELetIn, 2);
        v_t_24324 = v_c_24319;
        break;
      }
      case TAG_IsType: {
        V v_t_24320 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24323;
        switch (heff_tag_of(v_t_24320)) {
        case TAG_At: {
          V v_s_24322 = heff_dup(heff_field(v_t_24320, 1));
          v_t_24323 = v_s_24322;
          break;
        }
        default: heff_nomatch(v_t_24320);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24320}), v_t_24323});
        break;
      }
      default: heff_nomatch(v_x1_24314);
      }
      V v_t_24327;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24326 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24327 = v_s_24326;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24324}), v_t_24327});
    }
    case TAG_EDo: {
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24339;
      switch (heff_tag_of(v_x1_24329)) {
      case TAG_IsInferable: {
        V v_i_24330 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24333;
        switch (heff_tag_of(v_i_24330)) {
        case TAG_At: {
          V v_s_24332 = heff_dup(heff_field(v_i_24330, 1));
          v_t_24333 = v_s_24332;
          break;
        }
        default: heff_nomatch(v_i_24330);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CInf, 1, (V[]){v_i_24330}), v_t_24333});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24334 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EDo, 1);
        v_t_24339 = v_c_24334;
        break;
      }
      case TAG_IsType: {
        V v_t_24335 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24338;
        switch (heff_tag_of(v_t_24335)) {
        case TAG_At: {
          V v_s_24337 = heff_dup(heff_field(v_t_24335, 1));
          v_t_24338 = v_s_24337;
          break;
        }
        default: heff_nomatch(v_t_24335);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_CType, 1, (V[]){v_t_24335}), v_t_24338});
        break;
      }
      default: heff_nomatch(v_x1_24329);
      }
      V v_t_24342;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24341 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24342 = v_s_24341;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24339}), v_t_24342});
    }
    case TAG_ELocal: {
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24345 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24355;
      switch (heff_tag_of(v_x1_24345)) {
      case TAG_IsInferable: {
        V v_i_24346 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        V v_t_24349;
        switch (heff_tag_of(v_i_24346)) {
        case TAG_At: {
          V v_s_24348 = heff_dup(heff_field(v_i_24346, 1));
          v_t_24349 = v_s_24348;
          break;
        }
        default: heff_nomatch(v_i_24346);
        }
        v_t_24355 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24346}), v_t_24349});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24350 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELocal, 2);
        v_t_24355 = v_c_24350;
        break;
      }
      case TAG_IsType: {
        V v_t_24351 = heff_field(v_x1_24345, 0);
        heff_take_n(v_x1_24345, 1ULL, 1);
        V v_t_24354;
        switch (heff_tag_of(v_t_24351)) {
        case TAG_At: {
          V v_s_24353 = heff_dup(heff_field(v_t_24351, 1));
          v_t_24354 = v_s_24353;
          break;
        }
        default: heff_nomatch(v_t_24351);
        }
        v_t_24355 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24351}), v_t_24354});
        break;
      }
      default: heff_nomatch(v_x1_24345);
      }
      V v_t_24358;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24357 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24358 = v_s_24357;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24355}), v_t_24358});
    }
    case TAG_EInvalid: {
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24360 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24370;
      switch (heff_tag_of(v_x1_24360)) {
      case TAG_IsInferable: {
        V v_i_24361 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        V v_t_24364;
        switch (heff_tag_of(v_i_24361)) {
        case TAG_At: {
          V v_s_24363 = heff_dup(heff_field(v_i_24361, 1));
          v_t_24364 = v_s_24363;
          break;
        }
        default: heff_nomatch(v_i_24361);
        }
        v_t_24370 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CInf, 1, (V[]){v_i_24361}), v_t_24364});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24365 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EInvalid, 1);
        v_t_24370 = v_c_24365;
        break;
      }
      case TAG_IsType: {
        V v_t_24366 = heff_field(v_x1_24360, 0);
        heff_take_n(v_x1_24360, 1ULL, 1);
        V v_t_24369;
        switch (heff_tag_of(v_t_24366)) {
        case TAG_At: {
          V v_s_24368 = heff_dup(heff_field(v_t_24366, 1));
          v_t_24369 = v_s_24368;
          break;
        }
        default: heff_nomatch(v_t_24366);
        }
        v_t_24370 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_CType, 1, (V[]){v_t_24366}), v_t_24369});
        break;
      }
      default: heff_nomatch(v_x1_24360);
      }
      V v_t_24373;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24372 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24373 = v_s_24372;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24370}), v_t_24373});
    }
    case TAG_EAssign: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_x1_24377 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24387;
      switch (heff_tag_of(v_x1_24377)) {
      case TAG_IsInferable: {
        V v_i_24378 = heff_field(v_x1_24377, 0);
        V v_ru_24x1_24377_24IsInferable = heff_take_reuse_n(v_x1_24377, 1ULL, 1);
        V v_t_24381;
        switch (heff_tag_of(v_i_24378)) {
        case TAG_At: {
          V v_s_24380 = heff_dup(heff_field(v_i_24378, 1));
          v_t_24381 = v_s_24380;
          break;
        }
        default: heff_nomatch(v_i_24378);
        }
        v_t_24387 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24377_24IsInferable, TAG_CInf, 1, (V[]){v_i_24378}), v_t_24381});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24382 = heff_field(v_x1_24377, 0);
        heff_take_n(v_x1_24377, 1ULL, 1);
        v_t_24387 = v_c_24382;
        break;
      }
      case TAG_IsType: {
        V v_t_24383 = heff_field(v_x1_24377, 0);
        V v_ru_24x1_24377_24IsType = heff_take_reuse_n(v_x1_24377, 1ULL, 1);
        V v_t_24386;
        switch (heff_tag_of(v_t_24383)) {
        case TAG_At: {
          V v_s_24385 = heff_dup(heff_field(v_t_24383, 1));
          v_t_24386 = v_s_24385;
          break;
        }
        default: heff_nomatch(v_t_24383);
        }
        v_t_24387 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24377_24IsType, TAG_CType, 1, (V[]){v_t_24383}), v_t_24386});
        break;
      }
      default: heff_nomatch(v_x1_24377);
      }
      V v_t_24390;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24389 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24390 = v_s_24389;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24387}), v_t_24390});
    }
    case TAG_EWhile: {
      V v_ru_24x21_242_24EWhile = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24393 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24403;
      switch (heff_tag_of(v_x1_24393)) {
      case TAG_IsInferable: {
        V v_i_24394 = heff_field(v_x1_24393, 0);
        heff_take_n(v_x1_24393, 1ULL, 1);
        V v_t_24397;
        switch (heff_tag_of(v_i_24394)) {
        case TAG_At: {
          V v_s_24396 = heff_dup(heff_field(v_i_24394, 1));
          v_t_24397 = v_s_24396;
          break;
        }
        default: heff_nomatch(v_i_24394);
        }
        v_t_24403 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24394}), v_t_24397});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24398 = heff_field(v_x1_24393, 0);
        heff_take_n(v_x1_24393, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EWhile, 2);
        v_t_24403 = v_c_24398;
        break;
      }
      case TAG_IsType: {
        V v_t_24399 = heff_field(v_x1_24393, 0);
        heff_take_n(v_x1_24393, 1ULL, 1);
        V v_t_24402;
        switch (heff_tag_of(v_t_24399)) {
        case TAG_At: {
          V v_s_24401 = heff_dup(heff_field(v_t_24399, 1));
          v_t_24402 = v_s_24401;
          break;
        }
        default: heff_nomatch(v_t_24399);
        }
        v_t_24403 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24399}), v_t_24402});
        break;
      }
      default: heff_nomatch(v_x1_24393);
      }
      V v_t_24406;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24405 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24406 = v_s_24405;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24403}), v_t_24406});
    }
    case TAG_EFor: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_x1_24410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24420;
      switch (heff_tag_of(v_x1_24410)) {
      case TAG_IsInferable: {
        V v_i_24411 = heff_field(v_x1_24410, 0);
        V v_ru_24x1_24410_24IsInferable = heff_take_reuse_n(v_x1_24410, 1ULL, 1);
        V v_t_24414;
        switch (heff_tag_of(v_i_24411)) {
        case TAG_At: {
          V v_s_24413 = heff_dup(heff_field(v_i_24411, 1));
          v_t_24414 = v_s_24413;
          break;
        }
        default: heff_nomatch(v_i_24411);
        }
        v_t_24420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24410_24IsInferable, TAG_CInf, 1, (V[]){v_i_24411}), v_t_24414});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24415 = heff_field(v_x1_24410, 0);
        heff_take_n(v_x1_24410, 1ULL, 1);
        v_t_24420 = v_c_24415;
        break;
      }
      case TAG_IsType: {
        V v_t_24416 = heff_field(v_x1_24410, 0);
        V v_ru_24x1_24410_24IsType = heff_take_reuse_n(v_x1_24410, 1ULL, 1);
        V v_t_24419;
        switch (heff_tag_of(v_t_24416)) {
        case TAG_At: {
          V v_s_24418 = heff_dup(heff_field(v_t_24416, 1));
          v_t_24419 = v_s_24418;
          break;
        }
        default: heff_nomatch(v_t_24416);
        }
        v_t_24420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24410_24IsType, TAG_CType, 1, (V[]){v_t_24416}), v_t_24419});
        break;
      }
      default: heff_nomatch(v_x1_24410);
      }
      V v_t_24423;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24422 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24423 = v_s_24422;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24420}), v_t_24423});
    }
    case TAG_EIfThen: {
      V v_ru_24x21_242_24EIfThen = heff_take_reuse_n(v_x21_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24436;
      switch (heff_tag_of(v_x1_24426)) {
      case TAG_IsInferable: {
        V v_i_24427 = heff_field(v_x1_24426, 0);
        heff_take_n(v_x1_24426, 1ULL, 1);
        V v_t_24430;
        switch (heff_tag_of(v_i_24427)) {
        case TAG_At: {
          V v_s_24429 = heff_dup(heff_field(v_i_24427, 1));
          v_t_24430 = v_s_24429;
          break;
        }
        default: heff_nomatch(v_i_24427);
        }
        v_t_24436 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24427}), v_t_24430});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24431 = heff_field(v_x1_24426, 0);
        heff_take_n(v_x1_24426, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EIfThen, 2);
        v_t_24436 = v_c_24431;
        break;
      }
      case TAG_IsType: {
        V v_t_24432 = heff_field(v_x1_24426, 0);
        heff_take_n(v_x1_24426, 1ULL, 1);
        V v_t_24435;
        switch (heff_tag_of(v_t_24432)) {
        case TAG_At: {
          V v_s_24434 = heff_dup(heff_field(v_t_24432, 1));
          v_t_24435 = v_s_24434;
          break;
        }
        default: heff_nomatch(v_t_24432);
        }
        v_t_24436 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24432}), v_t_24435});
        break;
      }
      default: heff_nomatch(v_x1_24426);
      }
      V v_t_24439;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24438 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24439 = v_s_24438;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24436}), v_t_24439});
    }
    case TAG_EBreak: {
      heff_drop(v_sp_243);
      V v_x1_24440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24450;
      switch (heff_tag_of(v_x1_24440)) {
      case TAG_IsInferable: {
        V v_i_24441 = heff_field(v_x1_24440, 0);
        V v_ru_24x1_24440_24IsInferable = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
        V v_t_24444;
        switch (heff_tag_of(v_i_24441)) {
        case TAG_At: {
          V v_s_24443 = heff_dup(heff_field(v_i_24441, 1));
          v_t_24444 = v_s_24443;
          break;
        }
        default: heff_nomatch(v_i_24441);
        }
        v_t_24450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24440_24IsInferable, TAG_CInf, 1, (V[]){v_i_24441}), v_t_24444});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24445 = heff_field(v_x1_24440, 0);
        heff_take_n(v_x1_24440, 1ULL, 1);
        v_t_24450 = v_c_24445;
        break;
      }
      case TAG_IsType: {
        V v_t_24446 = heff_field(v_x1_24440, 0);
        V v_ru_24x1_24440_24IsType = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
        V v_t_24449;
        switch (heff_tag_of(v_t_24446)) {
        case TAG_At: {
          V v_s_24448 = heff_dup(heff_field(v_t_24446, 1));
          v_t_24449 = v_s_24448;
          break;
        }
        default: heff_nomatch(v_t_24446);
        }
        v_t_24450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24440_24IsType, TAG_CType, 1, (V[]){v_t_24446}), v_t_24449});
        break;
      }
      default: heff_nomatch(v_x1_24440);
      }
      V v_t_24453;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24452 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24453 = v_s_24452;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24450}), v_t_24453});
    }
    case TAG_EContinue: {
      heff_drop(v_sp_243);
      V v_x1_24454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24464;
      switch (heff_tag_of(v_x1_24454)) {
      case TAG_IsInferable: {
        V v_i_24455 = heff_field(v_x1_24454, 0);
        V v_ru_24x1_24454_24IsInferable = heff_take_reuse_n(v_x1_24454, 1ULL, 1);
        V v_t_24458;
        switch (heff_tag_of(v_i_24455)) {
        case TAG_At: {
          V v_s_24457 = heff_dup(heff_field(v_i_24455, 1));
          v_t_24458 = v_s_24457;
          break;
        }
        default: heff_nomatch(v_i_24455);
        }
        v_t_24464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24454_24IsInferable, TAG_CInf, 1, (V[]){v_i_24455}), v_t_24458});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24459 = heff_field(v_x1_24454, 0);
        heff_take_n(v_x1_24454, 1ULL, 1);
        v_t_24464 = v_c_24459;
        break;
      }
      case TAG_IsType: {
        V v_t_24460 = heff_field(v_x1_24454, 0);
        V v_ru_24x1_24454_24IsType = heff_take_reuse_n(v_x1_24454, 1ULL, 1);
        V v_t_24463;
        switch (heff_tag_of(v_t_24460)) {
        case TAG_At: {
          V v_s_24462 = heff_dup(heff_field(v_t_24460, 1));
          v_t_24463 = v_s_24462;
          break;
        }
        default: heff_nomatch(v_t_24460);
        }
        v_t_24464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24454_24IsType, TAG_CType, 1, (V[]){v_t_24460}), v_t_24463});
        break;
      }
      default: heff_nomatch(v_x1_24454);
      }
      V v_t_24467;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24466 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24467 = v_s_24466;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24464}), v_t_24467});
    }
    case TAG_EReturn: {
      V v_ru_24x21_242_24EReturn = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24469 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24479;
      switch (heff_tag_of(v_x1_24469)) {
      case TAG_IsInferable: {
        V v_i_24470 = heff_field(v_x1_24469, 0);
        heff_take_n(v_x1_24469, 1ULL, 1);
        V v_t_24473;
        switch (heff_tag_of(v_i_24470)) {
        case TAG_At: {
          V v_s_24472 = heff_dup(heff_field(v_i_24470, 1));
          v_t_24473 = v_s_24472;
          break;
        }
        default: heff_nomatch(v_i_24470);
        }
        v_t_24479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_CInf, 1, (V[]){v_i_24470}), v_t_24473});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24474 = heff_field(v_x1_24469, 0);
        heff_take_n(v_x1_24469, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EReturn, 1);
        v_t_24479 = v_c_24474;
        break;
      }
      case TAG_IsType: {
        V v_t_24475 = heff_field(v_x1_24469, 0);
        heff_take_n(v_x1_24469, 1ULL, 1);
        V v_t_24478;
        switch (heff_tag_of(v_t_24475)) {
        case TAG_At: {
          V v_s_24477 = heff_dup(heff_field(v_t_24475, 1));
          v_t_24478 = v_s_24477;
          break;
        }
        default: heff_nomatch(v_t_24475);
        }
        v_t_24479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_CType, 1, (V[]){v_t_24475}), v_t_24478});
        break;
      }
      default: heff_nomatch(v_x1_24469);
      }
      V v_t_24482;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24481 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24482 = v_s_24481;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24479}), v_t_24482});
    }
    case TAG_ENest: {
      V v_ru_24x21_242_24ENest = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24484 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24494;
      switch (heff_tag_of(v_x1_24484)) {
      case TAG_IsInferable: {
        V v_i_24485 = heff_field(v_x1_24484, 0);
        heff_take_n(v_x1_24484, 1ULL, 1);
        V v_t_24488;
        switch (heff_tag_of(v_i_24485)) {
        case TAG_At: {
          V v_s_24487 = heff_dup(heff_field(v_i_24485, 1));
          v_t_24488 = v_s_24487;
          break;
        }
        default: heff_nomatch(v_i_24485);
        }
        v_t_24494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_CInf, 1, (V[]){v_i_24485}), v_t_24488});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24489 = heff_field(v_x1_24484, 0);
        heff_take_n(v_x1_24484, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ENest, 1);
        v_t_24494 = v_c_24489;
        break;
      }
      case TAG_IsType: {
        V v_t_24490 = heff_field(v_x1_24484, 0);
        heff_take_n(v_x1_24484, 1ULL, 1);
        V v_t_24493;
        switch (heff_tag_of(v_t_24490)) {
        case TAG_At: {
          V v_s_24492 = heff_dup(heff_field(v_t_24490, 1));
          v_t_24493 = v_s_24492;
          break;
        }
        default: heff_nomatch(v_t_24490);
        }
        v_t_24494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_CType, 1, (V[]){v_t_24490}), v_t_24493});
        break;
      }
      default: heff_nomatch(v_x1_24484);
      }
      V v_t_24497;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24496 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24497 = v_s_24496;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24494}), v_t_24497});
    }
    case TAG_ELazy: {
      V v_ru_24x21_242_24ELazy = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24509;
      switch (heff_tag_of(v_x1_24499)) {
      case TAG_IsInferable: {
        V v_i_24500 = heff_field(v_x1_24499, 0);
        heff_take_n(v_x1_24499, 1ULL, 1);
        V v_t_24503;
        switch (heff_tag_of(v_i_24500)) {
        case TAG_At: {
          V v_s_24502 = heff_dup(heff_field(v_i_24500, 1));
          v_t_24503 = v_s_24502;
          break;
        }
        default: heff_nomatch(v_i_24500);
        }
        v_t_24509 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CInf, 1, (V[]){v_i_24500}), v_t_24503});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24504 = heff_field(v_x1_24499, 0);
        heff_take_n(v_x1_24499, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ELazy, 1);
        v_t_24509 = v_c_24504;
        break;
      }
      case TAG_IsType: {
        V v_t_24505 = heff_field(v_x1_24499, 0);
        heff_take_n(v_x1_24499, 1ULL, 1);
        V v_t_24508;
        switch (heff_tag_of(v_t_24505)) {
        case TAG_At: {
          V v_s_24507 = heff_dup(heff_field(v_t_24505, 1));
          v_t_24508 = v_s_24507;
          break;
        }
        default: heff_nomatch(v_t_24505);
        }
        v_t_24509 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CType, 1, (V[]){v_t_24505}), v_t_24508});
        break;
      }
      default: heff_nomatch(v_x1_24499);
      }
      V v_t_24512;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24511 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24512 = v_s_24511;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24509}), v_t_24512});
    }
    case TAG_ETuple: {
      V v_ru_24x21_242_24ETuple = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24514 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24524;
      switch (heff_tag_of(v_x1_24514)) {
      case TAG_IsInferable: {
        V v_i_24515 = heff_field(v_x1_24514, 0);
        heff_take_n(v_x1_24514, 1ULL, 1);
        V v_t_24518;
        switch (heff_tag_of(v_i_24515)) {
        case TAG_At: {
          V v_s_24517 = heff_dup(heff_field(v_i_24515, 1));
          v_t_24518 = v_s_24517;
          break;
        }
        default: heff_nomatch(v_i_24515);
        }
        v_t_24524 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_CInf, 1, (V[]){v_i_24515}), v_t_24518});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24519 = heff_field(v_x1_24514, 0);
        heff_take_n(v_x1_24514, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETuple, 1);
        v_t_24524 = v_c_24519;
        break;
      }
      case TAG_IsType: {
        V v_t_24520 = heff_field(v_x1_24514, 0);
        heff_take_n(v_x1_24514, 1ULL, 1);
        V v_t_24523;
        switch (heff_tag_of(v_t_24520)) {
        case TAG_At: {
          V v_s_24522 = heff_dup(heff_field(v_t_24520, 1));
          v_t_24523 = v_s_24522;
          break;
        }
        default: heff_nomatch(v_t_24520);
        }
        v_t_24524 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_CType, 1, (V[]){v_t_24520}), v_t_24523});
        break;
      }
      default: heff_nomatch(v_x1_24514);
      }
      V v_t_24527;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24526 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24527 = v_s_24526;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24524}), v_t_24527});
    }
    case TAG_ETry: {
      V v_ru_24x21_242_24ETry = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24529 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24539;
      switch (heff_tag_of(v_x1_24529)) {
      case TAG_IsInferable: {
        V v_i_24530 = heff_field(v_x1_24529, 0);
        heff_take_n(v_x1_24529, 1ULL, 1);
        V v_t_24533;
        switch (heff_tag_of(v_i_24530)) {
        case TAG_At: {
          V v_s_24532 = heff_dup(heff_field(v_i_24530, 1));
          v_t_24533 = v_s_24532;
          break;
        }
        default: heff_nomatch(v_i_24530);
        }
        v_t_24539 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_CInf, 1, (V[]){v_i_24530}), v_t_24533});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24534 = heff_field(v_x1_24529, 0);
        heff_take_n(v_x1_24529, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24ETry, 1);
        v_t_24539 = v_c_24534;
        break;
      }
      case TAG_IsType: {
        V v_t_24535 = heff_field(v_x1_24529, 0);
        heff_take_n(v_x1_24529, 1ULL, 1);
        V v_t_24538;
        switch (heff_tag_of(v_t_24535)) {
        case TAG_At: {
          V v_s_24537 = heff_dup(heff_field(v_t_24535, 1));
          v_t_24538 = v_s_24537;
          break;
        }
        default: heff_nomatch(v_t_24535);
        }
        v_t_24539 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_CType, 1, (V[]){v_t_24535}), v_t_24538});
        break;
      }
      default: heff_nomatch(v_x1_24529);
      }
      V v_t_24542;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24541 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24542 = v_s_24541;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24539}), v_t_24542});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_24547 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_24557;
      switch (heff_tag_of(v_x1_24547)) {
      case TAG_IsInferable: {
        V v_i_24548 = heff_field(v_x1_24547, 0);
        V v_ru_24x1_24547_24IsInferable = heff_take_reuse_n(v_x1_24547, 1ULL, 1);
        V v_t_24551;
        switch (heff_tag_of(v_i_24548)) {
        case TAG_At: {
          V v_s_24550 = heff_dup(heff_field(v_i_24548, 1));
          v_t_24551 = v_s_24550;
          break;
        }
        default: heff_nomatch(v_i_24548);
        }
        v_t_24557 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24547_24IsInferable, TAG_CInf, 1, (V[]){v_i_24548}), v_t_24551});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24552 = heff_field(v_x1_24547, 0);
        heff_take_n(v_x1_24547, 1ULL, 1);
        v_t_24557 = v_c_24552;
        break;
      }
      case TAG_IsType: {
        V v_t_24553 = heff_field(v_x1_24547, 0);
        V v_ru_24x1_24547_24IsType = heff_take_reuse_n(v_x1_24547, 1ULL, 1);
        V v_t_24556;
        switch (heff_tag_of(v_t_24553)) {
        case TAG_At: {
          V v_s_24555 = heff_dup(heff_field(v_t_24553, 1));
          v_t_24556 = v_s_24555;
          break;
        }
        default: heff_nomatch(v_t_24553);
        }
        v_t_24557 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24547_24IsType, TAG_CType, 1, (V[]){v_t_24553}), v_t_24556});
        break;
      }
      default: heff_nomatch(v_x1_24547);
      }
      V v_t_24560;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_24559 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_24560 = v_s_24559;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24557}), v_t_24560});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IsInferable: {
    V v_b_245 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b_245}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_246}});
  }
  case TAG_IsCheckable: {
    V v_t_2417;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_248 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2412 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2417 = v_c_2412;
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2417}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
  }
  case TAG_IsType: {
    V v_t_2429;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_2420 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2423;
      switch (heff_tag_of(v_i_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_i_2420);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2424 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2429 = v_c_2424;
      break;
    }
    case TAG_IsType: {
      V v_t_2425 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2429}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_size_243 = heff_field(v_x1_240, 2);
    V v_little_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_EVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EImplicitVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        V v_v_2411 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return (g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(v_size_243, v_little_244, heff_dup(v_v_2411)));
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2412 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2412, MK_INT(8LL), 2)) {
            V v_f_2414 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_v_2411)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EFloat: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EString: {
        V v_s_2416 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_size_243)) {
          case TAG_SizeDefault: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_s_2416)}});
          }
          case TAG_SizeNumber: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SizeName: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_size_243)}});
          }
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EBinary: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERune: {
        V v_c_2423 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2424 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2424, MK_INT(8LL), 2)) {
            V v_f_2426 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_c_2423)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EWord: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProject: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENamed: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPi: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAnn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESpec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESig: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESum: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStruct: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EUpdate: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetIn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EDo: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELocal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInvalid: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAssign: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWhile: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFor: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EIfThen: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBreak: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EContinue: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EReturn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENest: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELazy: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETuple: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETry: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWith: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esizeTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esizeTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2esizeTerm(V v_x1_240, V v_x2_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x2_241}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_243}), v_sp_242});
  }
  case TAG_SizeNumber: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_x2_241);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){v_m_244}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), v_sp_242});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    heff_drop(v_x2_241);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(1LL), 2)) {
      heff_drop(v_sp_242);
      heff_drop(v_x13_248);
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_xsp_247});
    } else {
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x13_248}), heff_dup(v_sp_242)});
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), heff_dup(v_sp_242)});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415})));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esizeTerm_str0)}), heff_dup(v_sp_242)});
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_242});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esizeTerm(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesTerm_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesTerm(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_242}), v_sp_241});
  }
  case TAG_SizeNumber: {
    V v_n_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){heff_intDiv(v_n_243, MK_INT(8LL))});
    V v_t_245 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(8LL), 2)) {
      heff_drop(v_sp_241);
      heff_drop(v_x13_248);
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_xsp_247});
    } else {
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intDiv(v_x13_248, MK_INT(8LL))});
      V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_241)})});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415})));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesTerm_str0)}), heff_dup(v_sp_241)});
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_241)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_241});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesTerm(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclEquations = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2419;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_IsInferable: {
        V v_i_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_i_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_i_2410);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2410}), v_t_2413});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2414 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_c_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_c_2414);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
        break;
      }
      case TAG_IsType: {
        V v_t_2418 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2419 = v_t_2418;
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2420 = (g_list_2emap_24s1036840854x702708481(v_r_240, v_eqs_248));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_2419, v_t_2420}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_x21_242, 0);
      V v_xsp_2422 = heff_field(v_x21_242, 1);
      V v_ps_2423 = heff_field(v_x21_242, 2);
      V v_u_2424 = heff_field(v_x21_242, 3);
      V v_body_2425 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclDefine = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_t_2426 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2423));
      V v_x1_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2424}));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_IsInferable: {
        V v_i_2428 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_i_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_i_2428);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2432 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_c_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_c_2432);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
        break;
      }
      case TAG_IsType: {
        V v_t_2436 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2437 = v_t_2436;
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
      V v_x1_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2425}));
      V v_t_2448;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_IsInferable: {
        V v_i_2439 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsInferable = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_i_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_i_2439);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsInferable, TAG_CInf, 1, (V[]){v_i_2439}), v_t_2442});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2443 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2448 = v_c_2443;
        break;
      }
      case TAG_IsType: {
        V v_t_2444 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsType = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2447;
        switch (heff_tag_of(v_t_2444)) {
        case TAG_At: {
          V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
          v_t_2447 = v_s_2446;
          break;
        }
        default: heff_nomatch(v_t_2444);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsType, TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2421, v_xsp_2422, v_t_2426, v_t_2437, v_t_2448}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2449 = heff_field(v_x21_242, 0);
      V v_xsp_2450 = heff_field(v_x21_242, 1);
      V v_ps_2451 = heff_field(v_x21_242, 2);
      V v_body_2452 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclTheory = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_2453 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2451));
      V v_x1_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2452}));
      V v_t_2464;
      switch (heff_tag_of(v_x1_2454)) {
      case TAG_IsInferable: {
        V v_i_2455 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_i_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_i_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_i_2455);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2455}), v_t_2458});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2459 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2464 = v_c_2459;
        break;
      }
      case TAG_IsType: {
        V v_t_2460 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        V v_t_2463;
        switch (heff_tag_of(v_t_2460)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_t_2460);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
        break;
      }
      default: heff_nomatch(v_x1_2454);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2449, v_xsp_2450, v_t_2453, v_t_2464}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2465 = heff_field(v_x21_242, 0);
      V v_xsp_2466 = heff_field(v_x21_242, 1);
      V v_t_2467 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24DeclPrimitive = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2467}));
      V v_t_2478;
      switch (heff_tag_of(v_x1_2468)) {
      case TAG_IsInferable: {
        V v_i_2469 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2472;
        switch (heff_tag_of(v_i_2469)) {
        case TAG_At: {
          V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_i_2469);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2473 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        V v_t_2476;
        switch (heff_tag_of(v_c_2473)) {
        case TAG_At: {
          V v_s_2475 = heff_dup(heff_field(v_c_2473, 1));
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_c_2473);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2473}), v_t_2476});
        break;
      }
      case TAG_IsType: {
        V v_t_2477 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2478 = v_t_2477;
        break;
      }
      default: heff_nomatch(v_x1_2468);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2465, v_xsp_2466, v_t_2478}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2479 = heff_field(v_x21_242, 0);
      V v_xsp_2480 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_rec(v_r_240, 2);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2479, v_xsp_2480}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2481 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2481}));
      V v_t_2483 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2482));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclWatch, 1, (V[]){v_t_2483}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2427;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            v_t_2427 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2419 = v_field_2415;
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = v_field_2415;
              V v_t_2426;
              switch (heff_tag_of(v_t_2423)) {
              case TAG_At: {
                V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
                v_t_2426 = v_s_2425;
                break;
              }
              default: heff_nomatch(v_t_2423);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
            }
          }
        }
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2428});
        V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2429});
        V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2430));
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0)}), heff_dup(v_sp_242)});
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2431}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2436 = v_t_2434.f[1];
            int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
            if ((v_tag_2435 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2438 = v_field_2436;
              return v_c_2438;
            } else {
              if ((v_tag_2435 == ((int64_t)1ULL))) {
                V v_i_2440 = v_field_2436;
                V v_t_2443;
                switch (heff_tag_of(v_i_2440)) {
                case TAG_At: {
                  V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
                  v_t_2443 = v_s_2442;
                  break;
                }
                default: heff_nomatch(v_i_2440);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
              } else {
                V v_t_2444 = v_field_2436;
                V v_t_2447;
                switch (heff_tag_of(v_t_2444)) {
                case TAG_At: {
                  V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
                  v_t_2447 = v_s_2446;
                  break;
                }
                default: heff_nomatch(v_t_2444);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2449 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2464;
          {
            V v_field_2452 = v_t_2450.f[1];
            int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
            if ((v_tag_2451 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2454 = v_field_2452;
              v_t_2464 = v_c_2454;
            } else {
              if ((v_tag_2451 == ((int64_t)1ULL))) {
                V v_i_2456 = v_field_2452;
                V v_t_2459;
                switch (heff_tag_of(v_i_2456)) {
                case TAG_At: {
                  V v_s_2458 = heff_dup(heff_field(v_i_2456, 1));
                  v_t_2459 = v_s_2458;
                  break;
                }
                default: heff_nomatch(v_i_2456);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2456}), v_t_2459});
              } else {
                V v_t_2460 = v_field_2452;
                V v_t_2463;
                switch (heff_tag_of(v_t_2460)) {
                case TAG_At: {
                  V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
                  v_t_2463 = v_s_2462;
                  break;
                }
                default: heff_nomatch(v_t_2460);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
              }
            }
          }
          V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
          V v_args_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2465});
          V v_t_2467 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2466));
          V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1)}), heff_dup(v_sp_242)});
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2468, v_t_2467}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2469}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2473 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2474 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2488;
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            if ((v_tag_2475 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2478 = v_field_2476;
              v_t_2488 = v_c_2478;
            } else {
              if ((v_tag_2475 == ((int64_t)1ULL))) {
                V v_i_2480 = v_field_2476;
                V v_t_2483;
                switch (heff_tag_of(v_i_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_i_2480);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
              } else {
                V v_t_2484 = v_field_2476;
                V v_t_2487;
                switch (heff_tag_of(v_t_2484)) {
                case TAG_At: {
                  V v_s_2486 = heff_dup(heff_field(v_t_2484, 1));
                  v_t_2487 = v_s_2486;
                  break;
                }
                default: heff_nomatch(v_t_2484);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2484}), v_t_2487});
              }
            }
          }
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, NTAG(TAG_Nil)});
          V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2489});
          V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2490));
          V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2)}), heff_dup(v_sp_242)});
          V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT2 v_t_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24108;
        {
          V v_field_2496 = v_t_2494.f[1];
          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
          if ((v_tag_2495 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2498 = v_field_2496;
            v_t_24108 = v_c_2498;
          } else {
            if ((v_tag_2495 == ((int64_t)1ULL))) {
              V v_i_24100 = v_field_2496;
              V v_t_24103;
              switch (heff_tag_of(v_i_24100)) {
              case TAG_At: {
                V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
                v_t_24103 = v_s_24102;
                break;
              }
              default: heff_nomatch(v_i_24100);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
            } else {
              V v_t_24104 = v_field_2496;
              V v_t_24107;
              switch (heff_tag_of(v_t_24104)) {
              case TAG_At: {
                V v_s_24106 = heff_dup(heff_field(v_t_24104, 1));
                v_t_24107 = v_s_24106;
                break;
              }
              default: heff_nomatch(v_t_24104);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24104}), v_t_24107});
            }
          }
        }
        V v_args_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, NTAG(TAG_Nil)});
        V v_t_24110 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24109));
        V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3)}), heff_dup(v_sp_242)});
        V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24110}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24112}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24113 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24114;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)0ULL);
        }
        V v_t_24115 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24114 + ((int64_t)0ULL)))});
        V v_t_24116 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24115, heff_dup(v_sp_242)})});
        V v_t_24117 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT2 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24132;
        {
          V v_field_24120 = v_t_24118.f[1];
          int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
          if ((v_tag_24119 == ((int64_t)0ULL))) {
            V v_c_24122 = v_field_24120;
            v_t_24132 = v_c_24122;
          } else {
            if ((v_tag_24119 == ((int64_t)1ULL))) {
              V v_i_24124 = v_field_24120;
              V v_t_24127;
              switch (heff_tag_of(v_i_24124)) {
              case TAG_At: {
                V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
                v_t_24127 = v_s_24126;
                break;
              }
              default: heff_nomatch(v_i_24124);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
            } else {
              V v_t_24128 = v_field_24120;
              V v_t_24131;
              switch (heff_tag_of(v_t_24128)) {
              case TAG_At: {
                V v_s_24130 = heff_dup(heff_field(v_t_24128, 1));
                v_t_24131 = v_s_24130;
                break;
              }
              default: heff_nomatch(v_t_24128);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24128}), v_t_24131});
            }
          }
        }
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
        V v_args_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_t_24133});
        V v_t_24135 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24134));
        V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4)}), heff_dup(v_sp_242)});
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24136, v_t_24135}), heff_dup(v_sp_242)});
        V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24137}), heff_dup(v_sp_242)});
        V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
        V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24116, heff_dup(v_sp_242)}), v_t_24139});
        V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_t_24140});
        V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
        V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5)}), heff_dup(v_sp_242)});
        V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24145 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24145, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24145);
          V v_t_24147 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24148 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24147, NTAG(TAG_Nil)});
          V v_t_24149 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24148));
          V v_t_24150 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6)}), heff_dup(v_sp_242)});
          V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24150, v_t_24149}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24151}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24145, MK_INT(16LL))) {
            int64_t v_t_24153;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)0ULL);
            }
            V v_t_24154 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24153 + ((int64_t)0ULL)))});
            V v_t_24155 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24154, heff_dup(v_sp_242)})});
            V v_t_24156 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24156, NTAG(TAG_Nil)});
            V v_args_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24155, heff_dup(v_sp_242)}), v_t_24157});
            V v_t_24159 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24158));
            V v_t_24160 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7)}), heff_dup(v_sp_242)});
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24160, v_t_24159}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24161}), v_sp_242});
          } else {
            int64_t v_t_24162;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)0ULL);
            }
            V v_t_24163 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24162 + ((int64_t)0ULL)))});
            V v_t_24164 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24163, heff_dup(v_sp_242)})});
            V v_t_24165 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
            V v_args_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24164, heff_dup(v_sp_242)}), v_t_24166});
            V v_t_24168 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24167));
            V v_t_24169 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8)}), heff_dup(v_sp_242)});
            V v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24169, v_t_24168}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24170}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_dup(heff_field(v_x2_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_ru_24x21_241_24EVar = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2418;
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EVar, 1);
          V v_c_248 = v_field_246;
          v_t_2418 = v_c_248;
        } else {
          if ((v_tag_245 == ((int64_t)1ULL))) {
            V v_i_2410 = v_field_246;
            V v_t_2413;
            switch (heff_tag_of(v_i_2410)) {
            case TAG_At: {
              V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
              v_t_2413 = v_s_2412;
              break;
            }
            default: heff_nomatch(v_i_2410);
            }
            v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_CInf, 1, (V[]){v_i_2410}), v_t_2413});
          } else {
            V v_t_2414 = v_field_246;
            V v_t_2417;
            switch (heff_tag_of(v_t_2414)) {
            case TAG_At: {
              V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
              v_t_2417 = v_s_2416;
              break;
            }
            default: heff_nomatch(v_t_2414);
            }
            v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
          }
        }
      }
      V v_t_2421;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2421 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2418}), v_t_2421});
    }
    case TAG_EImplicitVar: {
      V v_ru_24x21_241_24EImplicitVar = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2437;
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EImplicitVar, 1);
          V v_c_2427 = v_field_2425;
          v_t_2437 = v_c_2427;
        } else {
          if ((v_tag_2424 == ((int64_t)1ULL))) {
            V v_i_2429 = v_field_2425;
            V v_t_2432;
            switch (heff_tag_of(v_i_2429)) {
            case TAG_At: {
              V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
              v_t_2432 = v_s_2431;
              break;
            }
            default: heff_nomatch(v_i_2429);
            }
            v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2429}), v_t_2432});
          } else {
            V v_t_2433 = v_field_2425;
            V v_t_2436;
            switch (heff_tag_of(v_t_2433)) {
            case TAG_At: {
              V v_s_2435 = heff_dup(heff_field(v_t_2433, 1));
              v_t_2436 = v_s_2435;
              break;
            }
            default: heff_nomatch(v_t_2433);
            }
            v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2433}), v_t_2436});
          }
        }
      }
      V v_t_2440;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2439 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2440 = v_s_2439;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2437}), v_t_2440});
    }
    case TAG_ETag: {
      V v_ru_24x21_241_24ETag = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2456;
      {
        V v_field_2444 = v_t_2442.f[1];
        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
        if ((v_tag_2443 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ETag, 1);
          V v_c_2446 = v_field_2444;
          v_t_2456 = v_c_2446;
        } else {
          if ((v_tag_2443 == ((int64_t)1ULL))) {
            V v_i_2448 = v_field_2444;
            V v_t_2451;
            switch (heff_tag_of(v_i_2448)) {
            case TAG_At: {
              V v_s_2450 = heff_dup(heff_field(v_i_2448, 1));
              v_t_2451 = v_s_2450;
              break;
            }
            default: heff_nomatch(v_i_2448);
            }
            v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETag, TAG_CInf, 1, (V[]){v_i_2448}), v_t_2451});
          } else {
            V v_t_2452 = v_field_2444;
            V v_t_2455;
            switch (heff_tag_of(v_t_2452)) {
            case TAG_At: {
              V v_s_2454 = heff_dup(heff_field(v_t_2452, 1));
              v_t_2455 = v_s_2454;
              break;
            }
            default: heff_nomatch(v_t_2452);
            }
            v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETag, TAG_CType, 1, (V[]){v_t_2452}), v_t_2455});
          }
        }
      }
      V v_t_2459;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2458 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2459 = v_s_2458;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2456}), v_t_2459});
    }
    case TAG_EInt: {
      V v_ru_24x21_241_24EInt = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2461 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2475;
      {
        V v_field_2463 = v_t_2461.f[1];
        int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
        if ((v_tag_2462 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EInt, 1);
          V v_c_2465 = v_field_2463;
          v_t_2475 = v_c_2465;
        } else {
          if ((v_tag_2462 == ((int64_t)1ULL))) {
            V v_i_2467 = v_field_2463;
            V v_t_2470;
            switch (heff_tag_of(v_i_2467)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_i_2467, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_i_2467);
            }
            v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_CInf, 1, (V[]){v_i_2467}), v_t_2470});
          } else {
            V v_t_2471 = v_field_2463;
            V v_t_2474;
            switch (heff_tag_of(v_t_2471)) {
            case TAG_At: {
              V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
              v_t_2474 = v_s_2473;
              break;
            }
            default: heff_nomatch(v_t_2471);
            }
            v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
          }
        }
      }
      V v_t_2478;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EFloat: {
      V v_ru_24x21_241_24EFloat = heff_take_reuse_na(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2480 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2494;
      {
        V v_field_2482 = v_t_2480.f[1];
        int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
        if ((v_tag_2481 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EFloat, 1);
          V v_c_2484 = v_field_2482;
          v_t_2494 = v_c_2484;
        } else {
          if ((v_tag_2481 == ((int64_t)1ULL))) {
            V v_i_2486 = v_field_2482;
            V v_t_2489;
            switch (heff_tag_of(v_i_2486)) {
            case TAG_At: {
              V v_s_2488 = heff_dup(heff_field(v_i_2486, 1));
              v_t_2489 = v_s_2488;
              break;
            }
            default: heff_nomatch(v_i_2486);
            }
            v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_CInf, 1, (V[]){v_i_2486}), v_t_2489});
          } else {
            V v_t_2490 = v_field_2482;
            V v_t_2493;
            switch (heff_tag_of(v_t_2490)) {
            case TAG_At: {
              V v_s_2492 = heff_dup(heff_field(v_t_2490, 1));
              v_t_2493 = v_s_2492;
              break;
            }
            default: heff_nomatch(v_t_2490);
            }
            v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_CType, 1, (V[]){v_t_2490}), v_t_2493});
          }
        }
      }
      V v_t_2497;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2496 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2497 = v_s_2496;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2494}), v_t_2497});
    }
    case TAG_EString: {
      V v_ru_24x21_241_24EString = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_2499 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24113;
      {
        V v_field_24101 = v_t_2499.f[1];
        int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
        if ((v_tag_24100 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EString, 1);
          V v_c_24103 = v_field_24101;
          v_t_24113 = v_c_24103;
        } else {
          if ((v_tag_24100 == ((int64_t)1ULL))) {
            V v_i_24105 = v_field_24101;
            V v_t_24108;
            switch (heff_tag_of(v_i_24105)) {
            case TAG_At: {
              V v_s_24107 = heff_dup(heff_field(v_i_24105, 1));
              v_t_24108 = v_s_24107;
              break;
            }
            default: heff_nomatch(v_i_24105);
            }
            v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EString, TAG_CInf, 1, (V[]){v_i_24105}), v_t_24108});
          } else {
            V v_t_24109 = v_field_24101;
            V v_t_24112;
            switch (heff_tag_of(v_t_24109)) {
            case TAG_At: {
              V v_s_24111 = heff_dup(heff_field(v_t_24109, 1));
              v_t_24112 = v_s_24111;
              break;
            }
            default: heff_nomatch(v_t_24109);
            }
            v_t_24113 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EString, TAG_CType, 1, (V[]){v_t_24109}), v_t_24112});
          }
        }
      }
      V v_t_24116;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24115 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24116 = v_s_24115;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24113}), v_t_24116});
    }
    case TAG_EBinary: {
      V v_ru_24x21_241_24EBinary = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24132;
      {
        V v_field_24120 = v_t_24118.f[1];
        int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
        if ((v_tag_24119 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
          V v_c_24122 = v_field_24120;
          v_t_24132 = v_c_24122;
        } else {
          if ((v_tag_24119 == ((int64_t)1ULL))) {
            V v_i_24124 = v_field_24120;
            V v_t_24127;
            switch (heff_tag_of(v_i_24124)) {
            case TAG_At: {
              V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
              v_t_24127 = v_s_24126;
              break;
            }
            default: heff_nomatch(v_i_24124);
            }
            v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
          } else {
            V v_t_24128 = v_field_24120;
            V v_t_24131;
            switch (heff_tag_of(v_t_24128)) {
            case TAG_At: {
              V v_s_24130 = heff_dup(heff_field(v_t_24128, 1));
              v_t_24131 = v_s_24130;
              break;
            }
            default: heff_nomatch(v_t_24128);
            }
            v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_CType, 1, (V[]){v_t_24128}), v_t_24131});
          }
        }
      }
      V v_t_24135;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24134 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24135 = v_s_24134;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24132}), v_t_24135});
    }
    case TAG_ERune: {
      V v_ru_24x21_241_24ERune = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24137 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24151;
      {
        V v_field_24139 = v_t_24137.f[1];
        int64_t v_tag_24138 = ((int64_t)v_t_24137.f[0]);
        if ((v_tag_24138 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ERune, 1);
          V v_c_24141 = v_field_24139;
          v_t_24151 = v_c_24141;
        } else {
          if ((v_tag_24138 == ((int64_t)1ULL))) {
            V v_i_24143 = v_field_24139;
            V v_t_24146;
            switch (heff_tag_of(v_i_24143)) {
            case TAG_At: {
              V v_s_24145 = heff_dup(heff_field(v_i_24143, 1));
              v_t_24146 = v_s_24145;
              break;
            }
            default: heff_nomatch(v_i_24143);
            }
            v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_CInf, 1, (V[]){v_i_24143}), v_t_24146});
          } else {
            V v_t_24147 = v_field_24139;
            V v_t_24150;
            switch (heff_tag_of(v_t_24147)) {
            case TAG_At: {
              V v_s_24149 = heff_dup(heff_field(v_t_24147, 1));
              v_t_24150 = v_s_24149;
              break;
            }
            default: heff_nomatch(v_t_24147);
            }
            v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_CType, 1, (V[]){v_t_24147}), v_t_24150});
          }
        }
      }
      V v_t_24154;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24153 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24151}), v_t_24154});
    }
    case TAG_EWord: {
      V v_ru_24x21_241_24EWord = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24156 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24170;
      {
        V v_field_24158 = v_t_24156.f[1];
        int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
        if ((v_tag_24157 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EWord, 1);
          V v_c_24160 = v_field_24158;
          v_t_24170 = v_c_24160;
        } else {
          if ((v_tag_24157 == ((int64_t)1ULL))) {
            V v_i_24162 = v_field_24158;
            V v_t_24165;
            switch (heff_tag_of(v_i_24162)) {
            case TAG_At: {
              V v_s_24164 = heff_dup(heff_field(v_i_24162, 1));
              v_t_24165 = v_s_24164;
              break;
            }
            default: heff_nomatch(v_i_24162);
            }
            v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EWord, TAG_CInf, 1, (V[]){v_i_24162}), v_t_24165});
          } else {
            V v_t_24166 = v_field_24158;
            V v_t_24169;
            switch (heff_tag_of(v_t_24166)) {
            case TAG_At: {
              V v_s_24168 = heff_dup(heff_field(v_t_24166, 1));
              v_t_24169 = v_s_24168;
              break;
            }
            default: heff_nomatch(v_t_24166);
            }
            v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EWord, TAG_CType, 1, (V[]){v_t_24166}), v_t_24169});
          }
        }
      }
      V v_t_24173;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24172 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24173 = v_s_24172;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24170}), v_t_24173});
    }
    case TAG_EApp: {
      V v_ru_24x21_241_24EApp = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24176 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24190;
      {
        V v_field_24178 = v_t_24176.f[1];
        int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
        if ((v_tag_24177 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EApp, 2);
          V v_c_24180 = v_field_24178;
          v_t_24190 = v_c_24180;
        } else {
          if ((v_tag_24177 == ((int64_t)1ULL))) {
            V v_i_24182 = v_field_24178;
            V v_t_24185;
            switch (heff_tag_of(v_i_24182)) {
            case TAG_At: {
              V v_s_24184 = heff_dup(heff_field(v_i_24182, 1));
              v_t_24185 = v_s_24184;
              break;
            }
            default: heff_nomatch(v_i_24182);
            }
            v_t_24190 = heff_tag_at_n(v_ru_24x21_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24182}), v_t_24185});
          } else {
            V v_t_24186 = v_field_24178;
            V v_t_24189;
            switch (heff_tag_of(v_t_24186)) {
            case TAG_At: {
              V v_s_24188 = heff_dup(heff_field(v_t_24186, 1));
              v_t_24189 = v_s_24188;
              break;
            }
            default: heff_nomatch(v_t_24186);
            }
            v_t_24190 = heff_tag_at_n(v_ru_24x21_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24186}), v_t_24189});
          }
        }
      }
      V v_t_24193;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24192 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24193 = v_s_24192;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24190}), v_t_24193});
    }
    case TAG_EProject: {
      V v_x_24194 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EProject = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_tag(v_x2_240, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EProject, TAG_ArgProject, 1, (V[]){v_x_24194}), v_sp_242});
    }
    case TAG_ENamed: {
      V v_x_24195 = heff_field(v_x21_241, 0);
      V v_e_24196 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ENamed = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      HeffT2 v_t_24197 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_24196));
      V v_t_24211;
      {
        V v_field_24199 = v_t_24197.f[1];
        int64_t v_tag_24198 = ((int64_t)v_t_24197.f[0]);
        if ((v_tag_24198 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ENamed, 2);
          V v_c_24201 = v_field_24199;
          v_t_24211 = v_c_24201;
        } else {
          if ((v_tag_24198 == ((int64_t)1ULL))) {
            V v_i_24203 = v_field_24199;
            V v_t_24206;
            switch (heff_tag_of(v_i_24203)) {
            case TAG_At: {
              V v_s_24205 = heff_dup(heff_field(v_i_24203, 1));
              v_t_24206 = v_s_24205;
              break;
            }
            default: heff_nomatch(v_i_24203);
            }
            v_t_24211 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24203}), v_t_24206});
          } else {
            V v_t_24207 = v_field_24199;
            V v_t_24210;
            switch (heff_tag_of(v_t_24207)) {
            case TAG_At: {
              V v_s_24209 = heff_dup(heff_field(v_t_24207, 1));
              v_t_24210 = v_s_24209;
              break;
            }
            default: heff_nomatch(v_t_24207);
            }
            v_t_24211 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24207}), v_t_24210});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24195, v_t_24211}), v_sp_242});
    }
    case TAG_EPi: {
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24214 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24228;
      {
        V v_field_24216 = v_t_24214.f[1];
        int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
        if ((v_tag_24215 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EPi, 2);
          V v_c_24218 = v_field_24216;
          v_t_24228 = v_c_24218;
        } else {
          if ((v_tag_24215 == ((int64_t)1ULL))) {
            V v_i_24220 = v_field_24216;
            V v_t_24223;
            switch (heff_tag_of(v_i_24220)) {
            case TAG_At: {
              V v_s_24222 = heff_dup(heff_field(v_i_24220, 1));
              v_t_24223 = v_s_24222;
              break;
            }
            default: heff_nomatch(v_i_24220);
            }
            v_t_24228 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24220}), v_t_24223});
          } else {
            V v_t_24224 = v_field_24216;
            V v_t_24227;
            switch (heff_tag_of(v_t_24224)) {
            case TAG_At: {
              V v_s_24226 = heff_dup(heff_field(v_t_24224, 1));
              v_t_24227 = v_s_24226;
              break;
            }
            default: heff_nomatch(v_t_24224);
            }
            v_t_24228 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24224}), v_t_24227});
          }
        }
      }
      V v_t_24231;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24230 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24231 = v_s_24230;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24228}), v_t_24231});
    }
    case TAG_ELam: {
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24234 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24248;
      {
        V v_field_24236 = v_t_24234.f[1];
        int64_t v_tag_24235 = ((int64_t)v_t_24234.f[0]);
        if ((v_tag_24235 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELam, 2);
          V v_c_24238 = v_field_24236;
          v_t_24248 = v_c_24238;
        } else {
          if ((v_tag_24235 == ((int64_t)1ULL))) {
            V v_i_24240 = v_field_24236;
            V v_t_24243;
            switch (heff_tag_of(v_i_24240)) {
            case TAG_At: {
              V v_s_24242 = heff_dup(heff_field(v_i_24240, 1));
              v_t_24243 = v_s_24242;
              break;
            }
            default: heff_nomatch(v_i_24240);
            }
            v_t_24248 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24240}), v_t_24243});
          } else {
            V v_t_24244 = v_field_24236;
            V v_t_24247;
            switch (heff_tag_of(v_t_24244)) {
            case TAG_At: {
              V v_s_24246 = heff_dup(heff_field(v_t_24244, 1));
              v_t_24247 = v_s_24246;
              break;
            }
            default: heff_nomatch(v_t_24244);
            }
            v_t_24248 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24244}), v_t_24247});
          }
        }
      }
      V v_t_24251;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24250 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24251 = v_s_24250;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24248}), v_t_24251});
    }
    case TAG_EAnn: {
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24254 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24268;
      {
        V v_field_24256 = v_t_24254.f[1];
        int64_t v_tag_24255 = ((int64_t)v_t_24254.f[0]);
        if ((v_tag_24255 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
          V v_c_24258 = v_field_24256;
          v_t_24268 = v_c_24258;
        } else {
          if ((v_tag_24255 == ((int64_t)1ULL))) {
            V v_i_24260 = v_field_24256;
            V v_t_24263;
            switch (heff_tag_of(v_i_24260)) {
            case TAG_At: {
              V v_s_24262 = heff_dup(heff_field(v_i_24260, 1));
              v_t_24263 = v_s_24262;
              break;
            }
            default: heff_nomatch(v_i_24260);
            }
            v_t_24268 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24260}), v_t_24263});
          } else {
            V v_t_24264 = v_field_24256;
            V v_t_24267;
            switch (heff_tag_of(v_t_24264)) {
            case TAG_At: {
              V v_s_24266 = heff_dup(heff_field(v_t_24264, 1));
              v_t_24267 = v_s_24266;
              break;
            }
            default: heff_nomatch(v_t_24264);
            }
            v_t_24268 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24264}), v_t_24267});
          }
        }
      }
      V v_t_24271;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24270 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24271 = v_s_24270;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24268}), v_t_24271});
    }
    case TAG_ESpec: {
      heff_take_n(v_x21_241, 0ULL, 4);
      heff_drop(v_sp_242);
      HeffT2 v_t_24276 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24290;
      {
        V v_field_24278 = v_t_24276.f[1];
        int64_t v_tag_24277 = ((int64_t)v_t_24276.f[0]);
        if ((v_tag_24277 == ((int64_t)0ULL))) {
          V v_c_24280 = v_field_24278;
          v_t_24290 = v_c_24280;
        } else {
          if ((v_tag_24277 == ((int64_t)1ULL))) {
            V v_i_24282 = v_field_24278;
            V v_t_24285;
            switch (heff_tag_of(v_i_24282)) {
            case TAG_At: {
              V v_s_24284 = heff_dup(heff_field(v_i_24282, 1));
              v_t_24285 = v_s_24284;
              break;
            }
            default: heff_nomatch(v_i_24282);
            }
            v_t_24290 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24282}), v_t_24285});
          } else {
            V v_t_24286 = v_field_24278;
            V v_t_24289;
            switch (heff_tag_of(v_t_24286)) {
            case TAG_At: {
              V v_s_24288 = heff_dup(heff_field(v_t_24286, 1));
              v_t_24289 = v_s_24288;
              break;
            }
            default: heff_nomatch(v_t_24286);
            }
            v_t_24290 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24286}), v_t_24289});
          }
        }
      }
      V v_t_24293;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24292 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24293 = v_s_24292;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24290}), v_t_24293});
    }
    case TAG_ESig: {
      V v_ru_24x21_241_24ESig = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24295 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24309;
      {
        V v_field_24297 = v_t_24295.f[1];
        int64_t v_tag_24296 = ((int64_t)v_t_24295.f[0]);
        if ((v_tag_24296 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ESig, 1);
          V v_c_24299 = v_field_24297;
          v_t_24309 = v_c_24299;
        } else {
          if ((v_tag_24296 == ((int64_t)1ULL))) {
            V v_i_24301 = v_field_24297;
            V v_t_24304;
            switch (heff_tag_of(v_i_24301)) {
            case TAG_At: {
              V v_s_24303 = heff_dup(heff_field(v_i_24301, 1));
              v_t_24304 = v_s_24303;
              break;
            }
            default: heff_nomatch(v_i_24301);
            }
            v_t_24309 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_CInf, 1, (V[]){v_i_24301}), v_t_24304});
          } else {
            V v_t_24305 = v_field_24297;
            V v_t_24308;
            switch (heff_tag_of(v_t_24305)) {
            case TAG_At: {
              V v_s_24307 = heff_dup(heff_field(v_t_24305, 1));
              v_t_24308 = v_s_24307;
              break;
            }
            default: heff_nomatch(v_t_24305);
            }
            v_t_24309 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_CType, 1, (V[]){v_t_24305}), v_t_24308});
          }
        }
      }
      V v_t_24312;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24311 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24312 = v_s_24311;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24309}), v_t_24312});
    }
    case TAG_ESum: {
      V v_ru_24x21_241_24ESum = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24314 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24328;
      {
        V v_field_24316 = v_t_24314.f[1];
        int64_t v_tag_24315 = ((int64_t)v_t_24314.f[0]);
        if ((v_tag_24315 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ESum, 1);
          V v_c_24318 = v_field_24316;
          v_t_24328 = v_c_24318;
        } else {
          if ((v_tag_24315 == ((int64_t)1ULL))) {
            V v_i_24320 = v_field_24316;
            V v_t_24323;
            switch (heff_tag_of(v_i_24320)) {
            case TAG_At: {
              V v_s_24322 = heff_dup(heff_field(v_i_24320, 1));
              v_t_24323 = v_s_24322;
              break;
            }
            default: heff_nomatch(v_i_24320);
            }
            v_t_24328 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_CInf, 1, (V[]){v_i_24320}), v_t_24323});
          } else {
            V v_t_24324 = v_field_24316;
            V v_t_24327;
            switch (heff_tag_of(v_t_24324)) {
            case TAG_At: {
              V v_s_24326 = heff_dup(heff_field(v_t_24324, 1));
              v_t_24327 = v_s_24326;
              break;
            }
            default: heff_nomatch(v_t_24324);
            }
            v_t_24328 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_CType, 1, (V[]){v_t_24324}), v_t_24327});
          }
        }
      }
      V v_t_24331;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24330 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24331 = v_s_24330;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24328}), v_t_24331});
    }
    case TAG_EStruct: {
      V v_ru_24x21_241_24EStruct = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24333 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24347;
      {
        V v_field_24335 = v_t_24333.f[1];
        int64_t v_tag_24334 = ((int64_t)v_t_24333.f[0]);
        if ((v_tag_24334 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EStruct, 1);
          V v_c_24337 = v_field_24335;
          v_t_24347 = v_c_24337;
        } else {
          if ((v_tag_24334 == ((int64_t)1ULL))) {
            V v_i_24339 = v_field_24335;
            V v_t_24342;
            switch (heff_tag_of(v_i_24339)) {
            case TAG_At: {
              V v_s_24341 = heff_dup(heff_field(v_i_24339, 1));
              v_t_24342 = v_s_24341;
              break;
            }
            default: heff_nomatch(v_i_24339);
            }
            v_t_24347 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_CInf, 1, (V[]){v_i_24339}), v_t_24342});
          } else {
            V v_t_24343 = v_field_24335;
            V v_t_24346;
            switch (heff_tag_of(v_t_24343)) {
            case TAG_At: {
              V v_s_24345 = heff_dup(heff_field(v_t_24343, 1));
              v_t_24346 = v_s_24345;
              break;
            }
            default: heff_nomatch(v_t_24343);
            }
            v_t_24347 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_CType, 1, (V[]){v_t_24343}), v_t_24346});
          }
        }
      }
      V v_t_24350;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24349 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24350 = v_s_24349;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24347}), v_t_24350});
    }
    case TAG_EUpdate: {
      V v_ru_24x21_241_24EUpdate = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24353 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24367;
      {
        V v_field_24355 = v_t_24353.f[1];
        int64_t v_tag_24354 = ((int64_t)v_t_24353.f[0]);
        if ((v_tag_24354 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EUpdate, 2);
          V v_c_24357 = v_field_24355;
          v_t_24367 = v_c_24357;
        } else {
          if ((v_tag_24354 == ((int64_t)1ULL))) {
            V v_i_24359 = v_field_24355;
            V v_t_24362;
            switch (heff_tag_of(v_i_24359)) {
            case TAG_At: {
              V v_s_24361 = heff_dup(heff_field(v_i_24359, 1));
              v_t_24362 = v_s_24361;
              break;
            }
            default: heff_nomatch(v_i_24359);
            }
            v_t_24367 = heff_tag_at_n(v_ru_24x21_241_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24359}), v_t_24362});
          } else {
            V v_t_24363 = v_field_24355;
            V v_t_24366;
            switch (heff_tag_of(v_t_24363)) {
            case TAG_At: {
              V v_s_24365 = heff_dup(heff_field(v_t_24363, 1));
              v_t_24366 = v_s_24365;
              break;
            }
            default: heff_nomatch(v_t_24363);
            }
            v_t_24367 = heff_tag_at_n(v_ru_24x21_241_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24363}), v_t_24366});
          }
        }
      }
      V v_t_24370;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24369 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24370 = v_s_24369;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24367}), v_t_24370});
    }
    case TAG_EMatch: {
      V v_ru_24x21_241_24EMatch = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24373 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24387;
      {
        V v_field_24375 = v_t_24373.f[1];
        int64_t v_tag_24374 = ((int64_t)v_t_24373.f[0]);
        if ((v_tag_24374 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EMatch, 2);
          V v_c_24377 = v_field_24375;
          v_t_24387 = v_c_24377;
        } else {
          if ((v_tag_24374 == ((int64_t)1ULL))) {
            V v_i_24379 = v_field_24375;
            V v_t_24382;
            switch (heff_tag_of(v_i_24379)) {
            case TAG_At: {
              V v_s_24381 = heff_dup(heff_field(v_i_24379, 1));
              v_t_24382 = v_s_24381;
              break;
            }
            default: heff_nomatch(v_i_24379);
            }
            v_t_24387 = heff_tag_at_n(v_ru_24x21_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24379}), v_t_24382});
          } else {
            V v_t_24383 = v_field_24375;
            V v_t_24386;
            switch (heff_tag_of(v_t_24383)) {
            case TAG_At: {
              V v_s_24385 = heff_dup(heff_field(v_t_24383, 1));
              v_t_24386 = v_s_24385;
              break;
            }
            default: heff_nomatch(v_t_24383);
            }
            v_t_24387 = heff_tag_at_n(v_ru_24x21_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24383}), v_t_24386});
          }
        }
      }
      V v_t_24390;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24389 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24390 = v_s_24389;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24387}), v_t_24390});
    }
    case TAG_ELetIn: {
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24393 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24407;
      {
        V v_field_24395 = v_t_24393.f[1];
        int64_t v_tag_24394 = ((int64_t)v_t_24393.f[0]);
        if ((v_tag_24394 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELetIn, 2);
          V v_c_24397 = v_field_24395;
          v_t_24407 = v_c_24397;
        } else {
          if ((v_tag_24394 == ((int64_t)1ULL))) {
            V v_i_24399 = v_field_24395;
            V v_t_24402;
            switch (heff_tag_of(v_i_24399)) {
            case TAG_At: {
              V v_s_24401 = heff_dup(heff_field(v_i_24399, 1));
              v_t_24402 = v_s_24401;
              break;
            }
            default: heff_nomatch(v_i_24399);
            }
            v_t_24407 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24399}), v_t_24402});
          } else {
            V v_t_24403 = v_field_24395;
            V v_t_24406;
            switch (heff_tag_of(v_t_24403)) {
            case TAG_At: {
              V v_s_24405 = heff_dup(heff_field(v_t_24403, 1));
              v_t_24406 = v_s_24405;
              break;
            }
            default: heff_nomatch(v_t_24403);
            }
            v_t_24407 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24403}), v_t_24406});
          }
        }
      }
      V v_t_24410;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24409 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24410 = v_s_24409;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24407}), v_t_24410});
    }
    case TAG_EDo: {
      V v_ru_24x21_241_24EDo = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24412 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24426;
      {
        V v_field_24414 = v_t_24412.f[1];
        int64_t v_tag_24413 = ((int64_t)v_t_24412.f[0]);
        if ((v_tag_24413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EDo, 1);
          V v_c_24416 = v_field_24414;
          v_t_24426 = v_c_24416;
        } else {
          if ((v_tag_24413 == ((int64_t)1ULL))) {
            V v_i_24418 = v_field_24414;
            V v_t_24421;
            switch (heff_tag_of(v_i_24418)) {
            case TAG_At: {
              V v_s_24420 = heff_dup(heff_field(v_i_24418, 1));
              v_t_24421 = v_s_24420;
              break;
            }
            default: heff_nomatch(v_i_24418);
            }
            v_t_24426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_CInf, 1, (V[]){v_i_24418}), v_t_24421});
          } else {
            V v_t_24422 = v_field_24414;
            V v_t_24425;
            switch (heff_tag_of(v_t_24422)) {
            case TAG_At: {
              V v_s_24424 = heff_dup(heff_field(v_t_24422, 1));
              v_t_24425 = v_s_24424;
              break;
            }
            default: heff_nomatch(v_t_24422);
            }
            v_t_24426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_CType, 1, (V[]){v_t_24422}), v_t_24425});
          }
        }
      }
      V v_t_24429;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24428 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24429 = v_s_24428;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24426}), v_t_24429});
    }
    case TAG_ELocal: {
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24446;
      {
        V v_field_24434 = v_t_24432.f[1];
        int64_t v_tag_24433 = ((int64_t)v_t_24432.f[0]);
        if ((v_tag_24433 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELocal, 2);
          V v_c_24436 = v_field_24434;
          v_t_24446 = v_c_24436;
        } else {
          if ((v_tag_24433 == ((int64_t)1ULL))) {
            V v_i_24438 = v_field_24434;
            V v_t_24441;
            switch (heff_tag_of(v_i_24438)) {
            case TAG_At: {
              V v_s_24440 = heff_dup(heff_field(v_i_24438, 1));
              v_t_24441 = v_s_24440;
              break;
            }
            default: heff_nomatch(v_i_24438);
            }
            v_t_24446 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24438}), v_t_24441});
          } else {
            V v_t_24442 = v_field_24434;
            V v_t_24445;
            switch (heff_tag_of(v_t_24442)) {
            case TAG_At: {
              V v_s_24444 = heff_dup(heff_field(v_t_24442, 1));
              v_t_24445 = v_s_24444;
              break;
            }
            default: heff_nomatch(v_t_24442);
            }
            v_t_24446 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24442}), v_t_24445});
          }
        }
      }
      V v_t_24449;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24448 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24449 = v_s_24448;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24446}), v_t_24449});
    }
    case TAG_EInvalid: {
      V v_ru_24x21_241_24EInvalid = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24451 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24465;
      {
        V v_field_24453 = v_t_24451.f[1];
        int64_t v_tag_24452 = ((int64_t)v_t_24451.f[0]);
        if ((v_tag_24452 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EInvalid, 1);
          V v_c_24455 = v_field_24453;
          v_t_24465 = v_c_24455;
        } else {
          if ((v_tag_24452 == ((int64_t)1ULL))) {
            V v_i_24457 = v_field_24453;
            V v_t_24460;
            switch (heff_tag_of(v_i_24457)) {
            case TAG_At: {
              V v_s_24459 = heff_dup(heff_field(v_i_24457, 1));
              v_t_24460 = v_s_24459;
              break;
            }
            default: heff_nomatch(v_i_24457);
            }
            v_t_24465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInvalid, TAG_CInf, 1, (V[]){v_i_24457}), v_t_24460});
          } else {
            V v_t_24461 = v_field_24453;
            V v_t_24464;
            switch (heff_tag_of(v_t_24461)) {
            case TAG_At: {
              V v_s_24463 = heff_dup(heff_field(v_t_24461, 1));
              v_t_24464 = v_s_24463;
              break;
            }
            default: heff_nomatch(v_t_24461);
            }
            v_t_24465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EInvalid, TAG_CType, 1, (V[]){v_t_24461}), v_t_24464});
          }
        }
      }
      V v_t_24468;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24467 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24468 = v_s_24467;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24465}), v_t_24468});
    }
    case TAG_EAssign: {
      heff_take_n(v_x21_241, 0ULL, 3);
      heff_drop(v_sp_242);
      HeffT2 v_t_24472 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24486;
      {
        V v_field_24474 = v_t_24472.f[1];
        int64_t v_tag_24473 = ((int64_t)v_t_24472.f[0]);
        if ((v_tag_24473 == ((int64_t)0ULL))) {
          V v_c_24476 = v_field_24474;
          v_t_24486 = v_c_24476;
        } else {
          if ((v_tag_24473 == ((int64_t)1ULL))) {
            V v_i_24478 = v_field_24474;
            V v_t_24481;
            switch (heff_tag_of(v_i_24478)) {
            case TAG_At: {
              V v_s_24480 = heff_dup(heff_field(v_i_24478, 1));
              v_t_24481 = v_s_24480;
              break;
            }
            default: heff_nomatch(v_i_24478);
            }
            v_t_24486 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24478}), v_t_24481});
          } else {
            V v_t_24482 = v_field_24474;
            V v_t_24485;
            switch (heff_tag_of(v_t_24482)) {
            case TAG_At: {
              V v_s_24484 = heff_dup(heff_field(v_t_24482, 1));
              v_t_24485 = v_s_24484;
              break;
            }
            default: heff_nomatch(v_t_24482);
            }
            v_t_24486 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24482}), v_t_24485});
          }
        }
      }
      V v_t_24489;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24488 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24489 = v_s_24488;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24486}), v_t_24489});
    }
    case TAG_EWhile: {
      V v_ru_24x21_241_24EWhile = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24492 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24506;
      {
        V v_field_24494 = v_t_24492.f[1];
        int64_t v_tag_24493 = ((int64_t)v_t_24492.f[0]);
        if ((v_tag_24493 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EWhile, 2);
          V v_c_24496 = v_field_24494;
          v_t_24506 = v_c_24496;
        } else {
          if ((v_tag_24493 == ((int64_t)1ULL))) {
            V v_i_24498 = v_field_24494;
            V v_t_24501;
            switch (heff_tag_of(v_i_24498)) {
            case TAG_At: {
              V v_s_24500 = heff_dup(heff_field(v_i_24498, 1));
              v_t_24501 = v_s_24500;
              break;
            }
            default: heff_nomatch(v_i_24498);
            }
            v_t_24506 = heff_tag_at_n(v_ru_24x21_241_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24498}), v_t_24501});
          } else {
            V v_t_24502 = v_field_24494;
            V v_t_24505;
            switch (heff_tag_of(v_t_24502)) {
            case TAG_At: {
              V v_s_24504 = heff_dup(heff_field(v_t_24502, 1));
              v_t_24505 = v_s_24504;
              break;
            }
            default: heff_nomatch(v_t_24502);
            }
            v_t_24506 = heff_tag_at_n(v_ru_24x21_241_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24502}), v_t_24505});
          }
        }
      }
      V v_t_24509;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24508 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24509 = v_s_24508;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24506}), v_t_24509});
    }
    case TAG_EFor: {
      heff_take_n(v_x21_241, 0ULL, 3);
      heff_drop(v_sp_242);
      HeffT2 v_t_24513 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24527;
      {
        V v_field_24515 = v_t_24513.f[1];
        int64_t v_tag_24514 = ((int64_t)v_t_24513.f[0]);
        if ((v_tag_24514 == ((int64_t)0ULL))) {
          V v_c_24517 = v_field_24515;
          v_t_24527 = v_c_24517;
        } else {
          if ((v_tag_24514 == ((int64_t)1ULL))) {
            V v_i_24519 = v_field_24515;
            V v_t_24522;
            switch (heff_tag_of(v_i_24519)) {
            case TAG_At: {
              V v_s_24521 = heff_dup(heff_field(v_i_24519, 1));
              v_t_24522 = v_s_24521;
              break;
            }
            default: heff_nomatch(v_i_24519);
            }
            v_t_24527 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24519}), v_t_24522});
          } else {
            V v_t_24523 = v_field_24515;
            V v_t_24526;
            switch (heff_tag_of(v_t_24523)) {
            case TAG_At: {
              V v_s_24525 = heff_dup(heff_field(v_t_24523, 1));
              v_t_24526 = v_s_24525;
              break;
            }
            default: heff_nomatch(v_t_24523);
            }
            v_t_24527 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24523}), v_t_24526});
          }
        }
      }
      V v_t_24530;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24529 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24530 = v_s_24529;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24527}), v_t_24530});
    }
    case TAG_EIfThen: {
      V v_ru_24x21_241_24EIfThen = heff_take_reuse_n(v_x21_241, 0ULL, 2);
      heff_drop(v_sp_242);
      HeffT2 v_t_24533 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24547;
      {
        V v_field_24535 = v_t_24533.f[1];
        int64_t v_tag_24534 = ((int64_t)v_t_24533.f[0]);
        if ((v_tag_24534 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EIfThen, 2);
          V v_c_24537 = v_field_24535;
          v_t_24547 = v_c_24537;
        } else {
          if ((v_tag_24534 == ((int64_t)1ULL))) {
            V v_i_24539 = v_field_24535;
            V v_t_24542;
            switch (heff_tag_of(v_i_24539)) {
            case TAG_At: {
              V v_s_24541 = heff_dup(heff_field(v_i_24539, 1));
              v_t_24542 = v_s_24541;
              break;
            }
            default: heff_nomatch(v_i_24539);
            }
            v_t_24547 = heff_tag_at_n(v_ru_24x21_241_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24539}), v_t_24542});
          } else {
            V v_t_24543 = v_field_24535;
            V v_t_24546;
            switch (heff_tag_of(v_t_24543)) {
            case TAG_At: {
              V v_s_24545 = heff_dup(heff_field(v_t_24543, 1));
              v_t_24546 = v_s_24545;
              break;
            }
            default: heff_nomatch(v_t_24543);
            }
            v_t_24547 = heff_tag_at_n(v_ru_24x21_241_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24543}), v_t_24546});
          }
        }
      }
      V v_t_24550;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24549 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24550 = v_s_24549;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24547}), v_t_24550});
    }
    case TAG_EBreak: {
      heff_drop(v_sp_242);
      HeffT2 v_t_24551 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24565;
      {
        V v_field_24553 = v_t_24551.f[1];
        int64_t v_tag_24552 = ((int64_t)v_t_24551.f[0]);
        if ((v_tag_24552 == ((int64_t)0ULL))) {
          V v_c_24555 = v_field_24553;
          v_t_24565 = v_c_24555;
        } else {
          if ((v_tag_24552 == ((int64_t)1ULL))) {
            V v_i_24557 = v_field_24553;
            V v_t_24560;
            switch (heff_tag_of(v_i_24557)) {
            case TAG_At: {
              V v_s_24559 = heff_dup(heff_field(v_i_24557, 1));
              v_t_24560 = v_s_24559;
              break;
            }
            default: heff_nomatch(v_i_24557);
            }
            v_t_24565 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24557}), v_t_24560});
          } else {
            V v_t_24561 = v_field_24553;
            V v_t_24564;
            switch (heff_tag_of(v_t_24561)) {
            case TAG_At: {
              V v_s_24563 = heff_dup(heff_field(v_t_24561, 1));
              v_t_24564 = v_s_24563;
              break;
            }
            default: heff_nomatch(v_t_24561);
            }
            v_t_24565 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24561}), v_t_24564});
          }
        }
      }
      V v_t_24568;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24567 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24568 = v_s_24567;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24565}), v_t_24568});
    }
    case TAG_EContinue: {
      heff_drop(v_sp_242);
      HeffT2 v_t_24569 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24583;
      {
        V v_field_24571 = v_t_24569.f[1];
        int64_t v_tag_24570 = ((int64_t)v_t_24569.f[0]);
        if ((v_tag_24570 == ((int64_t)0ULL))) {
          V v_c_24573 = v_field_24571;
          v_t_24583 = v_c_24573;
        } else {
          if ((v_tag_24570 == ((int64_t)1ULL))) {
            V v_i_24575 = v_field_24571;
            V v_t_24578;
            switch (heff_tag_of(v_i_24575)) {
            case TAG_At: {
              V v_s_24577 = heff_dup(heff_field(v_i_24575, 1));
              v_t_24578 = v_s_24577;
              break;
            }
            default: heff_nomatch(v_i_24575);
            }
            v_t_24583 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24575}), v_t_24578});
          } else {
            V v_t_24579 = v_field_24571;
            V v_t_24582;
            switch (heff_tag_of(v_t_24579)) {
            case TAG_At: {
              V v_s_24581 = heff_dup(heff_field(v_t_24579, 1));
              v_t_24582 = v_s_24581;
              break;
            }
            default: heff_nomatch(v_t_24579);
            }
            v_t_24583 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24579}), v_t_24582});
          }
        }
      }
      V v_t_24586;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24585 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24586 = v_s_24585;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24583}), v_t_24586});
    }
    case TAG_EReturn: {
      V v_ru_24x21_241_24EReturn = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24588 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24602;
      {
        V v_field_24590 = v_t_24588.f[1];
        int64_t v_tag_24589 = ((int64_t)v_t_24588.f[0]);
        if ((v_tag_24589 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EReturn, 1);
          V v_c_24592 = v_field_24590;
          v_t_24602 = v_c_24592;
        } else {
          if ((v_tag_24589 == ((int64_t)1ULL))) {
            V v_i_24594 = v_field_24590;
            V v_t_24597;
            switch (heff_tag_of(v_i_24594)) {
            case TAG_At: {
              V v_s_24596 = heff_dup(heff_field(v_i_24594, 1));
              v_t_24597 = v_s_24596;
              break;
            }
            default: heff_nomatch(v_i_24594);
            }
            v_t_24602 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EReturn, TAG_CInf, 1, (V[]){v_i_24594}), v_t_24597});
          } else {
            V v_t_24598 = v_field_24590;
            V v_t_24601;
            switch (heff_tag_of(v_t_24598)) {
            case TAG_At: {
              V v_s_24600 = heff_dup(heff_field(v_t_24598, 1));
              v_t_24601 = v_s_24600;
              break;
            }
            default: heff_nomatch(v_t_24598);
            }
            v_t_24602 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EReturn, TAG_CType, 1, (V[]){v_t_24598}), v_t_24601});
          }
        }
      }
      V v_t_24605;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24604 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24605 = v_s_24604;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24602}), v_t_24605});
    }
    case TAG_ENest: {
      V v_ru_24x21_241_24ENest = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24607 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24621;
      {
        V v_field_24609 = v_t_24607.f[1];
        int64_t v_tag_24608 = ((int64_t)v_t_24607.f[0]);
        if ((v_tag_24608 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ENest, 1);
          V v_c_24611 = v_field_24609;
          v_t_24621 = v_c_24611;
        } else {
          if ((v_tag_24608 == ((int64_t)1ULL))) {
            V v_i_24613 = v_field_24609;
            V v_t_24616;
            switch (heff_tag_of(v_i_24613)) {
            case TAG_At: {
              V v_s_24615 = heff_dup(heff_field(v_i_24613, 1));
              v_t_24616 = v_s_24615;
              break;
            }
            default: heff_nomatch(v_i_24613);
            }
            v_t_24621 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ENest, TAG_CInf, 1, (V[]){v_i_24613}), v_t_24616});
          } else {
            V v_t_24617 = v_field_24609;
            V v_t_24620;
            switch (heff_tag_of(v_t_24617)) {
            case TAG_At: {
              V v_s_24619 = heff_dup(heff_field(v_t_24617, 1));
              v_t_24620 = v_s_24619;
              break;
            }
            default: heff_nomatch(v_t_24617);
            }
            v_t_24621 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ENest, TAG_CType, 1, (V[]){v_t_24617}), v_t_24620});
          }
        }
      }
      V v_t_24624;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24623 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24624 = v_s_24623;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24621}), v_t_24624});
    }
    case TAG_ELazy: {
      V v_ru_24x21_241_24ELazy = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24626 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24640;
      {
        V v_field_24628 = v_t_24626.f[1];
        int64_t v_tag_24627 = ((int64_t)v_t_24626.f[0]);
        if ((v_tag_24627 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELazy, 1);
          V v_c_24630 = v_field_24628;
          v_t_24640 = v_c_24630;
        } else {
          if ((v_tag_24627 == ((int64_t)1ULL))) {
            V v_i_24632 = v_field_24628;
            V v_t_24635;
            switch (heff_tag_of(v_i_24632)) {
            case TAG_At: {
              V v_s_24634 = heff_dup(heff_field(v_i_24632, 1));
              v_t_24635 = v_s_24634;
              break;
            }
            default: heff_nomatch(v_i_24632);
            }
            v_t_24640 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ELazy, TAG_CInf, 1, (V[]){v_i_24632}), v_t_24635});
          } else {
            V v_t_24636 = v_field_24628;
            V v_t_24639;
            switch (heff_tag_of(v_t_24636)) {
            case TAG_At: {
              V v_s_24638 = heff_dup(heff_field(v_t_24636, 1));
              v_t_24639 = v_s_24638;
              break;
            }
            default: heff_nomatch(v_t_24636);
            }
            v_t_24640 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ELazy, TAG_CType, 1, (V[]){v_t_24636}), v_t_24639});
          }
        }
      }
      V v_t_24643;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24642 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24643 = v_s_24642;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24640}), v_t_24643});
    }
    case TAG_ETuple: {
      V v_ru_24x21_241_24ETuple = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24645 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24659;
      {
        V v_field_24647 = v_t_24645.f[1];
        int64_t v_tag_24646 = ((int64_t)v_t_24645.f[0]);
        if ((v_tag_24646 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ETuple, 1);
          V v_c_24649 = v_field_24647;
          v_t_24659 = v_c_24649;
        } else {
          if ((v_tag_24646 == ((int64_t)1ULL))) {
            V v_i_24651 = v_field_24647;
            V v_t_24654;
            switch (heff_tag_of(v_i_24651)) {
            case TAG_At: {
              V v_s_24653 = heff_dup(heff_field(v_i_24651, 1));
              v_t_24654 = v_s_24653;
              break;
            }
            default: heff_nomatch(v_i_24651);
            }
            v_t_24659 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETuple, TAG_CInf, 1, (V[]){v_i_24651}), v_t_24654});
          } else {
            V v_t_24655 = v_field_24647;
            V v_t_24658;
            switch (heff_tag_of(v_t_24655)) {
            case TAG_At: {
              V v_s_24657 = heff_dup(heff_field(v_t_24655, 1));
              v_t_24658 = v_s_24657;
              break;
            }
            default: heff_nomatch(v_t_24655);
            }
            v_t_24659 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETuple, TAG_CType, 1, (V[]){v_t_24655}), v_t_24658});
          }
        }
      }
      V v_t_24662;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24661 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24662 = v_s_24661;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24659}), v_t_24662});
    }
    case TAG_ETry: {
      V v_ru_24x21_241_24ETry = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      heff_drop(v_sp_242);
      HeffT2 v_t_24664 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24678;
      {
        V v_field_24666 = v_t_24664.f[1];
        int64_t v_tag_24665 = ((int64_t)v_t_24664.f[0]);
        if ((v_tag_24665 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ETry, 1);
          V v_c_24668 = v_field_24666;
          v_t_24678 = v_c_24668;
        } else {
          if ((v_tag_24665 == ((int64_t)1ULL))) {
            V v_i_24670 = v_field_24666;
            V v_t_24673;
            switch (heff_tag_of(v_i_24670)) {
            case TAG_At: {
              V v_s_24672 = heff_dup(heff_field(v_i_24670, 1));
              v_t_24673 = v_s_24672;
              break;
            }
            default: heff_nomatch(v_i_24670);
            }
            v_t_24678 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETry, TAG_CInf, 1, (V[]){v_i_24670}), v_t_24673});
          } else {
            V v_t_24674 = v_field_24666;
            V v_t_24677;
            switch (heff_tag_of(v_t_24674)) {
            case TAG_At: {
              V v_s_24676 = heff_dup(heff_field(v_t_24674, 1));
              v_t_24677 = v_s_24676;
              break;
            }
            default: heff_nomatch(v_t_24674);
            }
            v_t_24678 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ETry, TAG_CType, 1, (V[]){v_t_24674}), v_t_24677});
          }
        }
      }
      V v_t_24681;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24680 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24681 = v_s_24680;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24678}), v_t_24681});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_241, 0ULL, 4);
      heff_drop(v_sp_242);
      HeffT2 v_t_24686 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_24700;
      {
        V v_field_24688 = v_t_24686.f[1];
        int64_t v_tag_24687 = ((int64_t)v_t_24686.f[0]);
        if ((v_tag_24687 == ((int64_t)0ULL))) {
          V v_c_24690 = v_field_24688;
          v_t_24700 = v_c_24690;
        } else {
          if ((v_tag_24687 == ((int64_t)1ULL))) {
            V v_i_24692 = v_field_24688;
            V v_t_24695;
            switch (heff_tag_of(v_i_24692)) {
            case TAG_At: {
              V v_s_24694 = heff_dup(heff_field(v_i_24692, 1));
              v_t_24695 = v_s_24694;
              break;
            }
            default: heff_nomatch(v_i_24692);
            }
            v_t_24700 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24692}), v_t_24695});
          } else {
            V v_t_24696 = v_field_24688;
            V v_t_24699;
            switch (heff_tag_of(v_t_24696)) {
            case TAG_At: {
              V v_s_24698 = heff_dup(heff_field(v_t_24696, 1));
              v_t_24699 = v_s_24698;
              break;
            }
            default: heff_nomatch(v_t_24696);
            }
            v_t_24700 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24696}), v_t_24699});
          }
        }
      }
      V v_t_24703;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_24702 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_24703 = v_s_24702;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24700}), v_t_24703});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
      v_t_245 = heff_tag_at_n(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at_n(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      heff_take_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2438 = (g_list_2emap_24s79542405x478516404(v_args_2437));
    return heff_tag_at_n(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, v_t_2438});
  }
  case TAG_CStruct: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1729787689x465380098(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){v_t_2440});
  }
  case TAG_CMatch: {
    V v_sc_2441 = heff_field(v_n_240, 0);
    V v_alts_2442 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_sc_2441)) {
    case TAG_At: {
      V v_n_2443 = heff_field(v_sc_2441, 0);
      V v_sp_2444 = heff_field(v_sc_2441, 1);
      V v_ru_24sc_2441_24At = heff_take_reuse_n(v_sc_2441, 3ULL, 2);
      V v_t_2445 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2443));
      v_t_2446 = heff_tag_at_n(v_ru_24sc_2441_24At, TAG_At, 2, (V[]){v_t_2445, v_sp_2444});
      break;
    }
    default: heff_nomatch(v_sc_2441);
    }
    V v_t_2447 = (g_list_2emap_24s244350250x1728178626(v_alts_2442));
    return heff_tag_at_n(v_ru_24n_240_24CMatch, TAG_CMatch, 2, (V[]){v_t_2446, v_t_2447});
  }
  case TAG_CLetIn: {
    V v_rhs_2448 = heff_field(v_n_240, 0);
    V v_alt_2449 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2453;
    switch (heff_tag_of(v_rhs_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_rhs_2448, 0);
      V v_sp_2451 = heff_field(v_rhs_2448, 1);
      V v_ru_24rhs_2448_24At = heff_take_reuse_n(v_rhs_2448, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24rhs_2448_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_rhs_2448);
    }
    V v_t_2463;
    switch (heff_tag_of(v_alt_2449)) {
    case TAG_At: {
      V v_x_2454 = heff_field(v_alt_2449, 0);
      V v_sp_2455 = heff_field(v_alt_2449, 1);
      V v_ru_24alt_2449_24At = heff_take_reuse_n(v_alt_2449, 3ULL, 2);
      V v_t_2462;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_MkAlt: {
        V v_p_2456 = heff_field(v_x_2454, 0);
        V v_b_2457 = heff_field(v_x_2454, 1);
        V v_ru_24x_2454_24MkAlt = heff_take_reuse_n(v_x_2454, 3ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_b_2457)) {
        case TAG_At: {
          V v_n_2458 = heff_field(v_b_2457, 0);
          V v_sp_2459 = heff_field(v_b_2457, 1);
          heff_take_n(v_b_2457, 3ULL, 2);
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2458));
          v_t_2461 = heff_tag_at_n(v_ru_24alt_2449_24At, TAG_At, 2, (V[]){v_t_2460, v_sp_2459});
          break;
        }
        default: heff_nomatch(v_b_2457);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x_2454_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2456, v_t_2461});
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_alt_2449);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2453, v_t_2463});
  }
  case TAG_CLocal: {
    V v_body_2464 = heff_field(v_n_240, 0);
    V v_ds_2465 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_body_2464)) {
    case TAG_At: {
      V v_n_2466 = heff_field(v_body_2464, 0);
      V v_sp_2467 = heff_field(v_body_2464, 1);
      V v_ru_24body_2464_24At = heff_take_reuse_n(v_body_2464, 3ULL, 2);
      V v_t_2468 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2466));
      v_t_2469 = heff_tag_at_n(v_ru_24body_2464_24At, TAG_At, 2, (V[]){v_t_2468, v_sp_2467});
      break;
    }
    default: heff_nomatch(v_body_2464);
    }
    V v_t_2470 = (g_list_2emap_24s386875578x1005587669(v_ds_2465));
    return heff_tag_at_n(v_ru_24n_240_24CLocal, TAG_CLocal, 2, (V[]){v_t_2469, v_t_2470});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IVar: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_244 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_IInt: {
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_247 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_IFloat: {
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2410 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_IString: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_IBytes: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2416 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_240});
  }
  case TAG_IPrim: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_IRune: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_IApp: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2426 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_sp_240});
  }
  case TAG_IAnn: {
    V v_c_2427 = heff_field(v_n_241, 0);
    V v_t_2428 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_2431;
    switch (heff_tag_of(v_c_2427)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_c_2427, 0);
      V v_sp_2430 = heff_field(v_c_2427, 1);
      heff_take_n(v_c_2427, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_c_2427);
    }
    V v_t_2434;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_t_2428, 0);
      V v_sp_2433 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2434 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2433, v_n_2432));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IAnn, TAG_IAnn, 2, (V[]){v_t_2431, v_t_2434}), v_sp_240});
  }
  case TAG_ISpec: {
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2440 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2439, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_240});
  }
  case TAG_IUpdate: {
    V v_t_2443 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2444 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_sp_240});
  }
  case TAG_IAnnLam: {
    V v_t_2449 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2450 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2449, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2450, v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2451 = heff_field(v_n_241, 0);
    V v_why_2452 = heff_field(v_n_241, 1);
    V v_note_2453 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 7ULL, 3);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IInvalid, TAG_IInvalid, 3, (V[]){v_code_2451, v_why_2452, v_note_2453}), v_sp_240});
  }
  case TAG_INominal: {
    V v_t_2455 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2456 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2455, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2456, v_sp_240});
  }
  case TAG_ILitEq: {
    V v_t_2461 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2462 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2461, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_240});
  }
  case TAG_ILazy: {
    V v_t_2464 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2465 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2464, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2465, v_sp_240});
  }
  case TAG_ITuple: {
    V v_t_2467 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2468 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2467, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2468, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(a[0], a[1]);
}