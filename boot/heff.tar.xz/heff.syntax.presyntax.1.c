// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo;
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void);
V g_heff_2esyntax_2epresyntax_2eendOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_clo;
V g_heff_2esyntax_2epresyntax_2egathered(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackLet(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackLet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackLet_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_clo;
V g_heff_2esyntax_2epresyntax_2egivenTy(V, V, V);
V g_heff_2esyntax_2epresyntax_2egivenTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivenTy_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2epackPat(V, V);
V g_heff_2esyntax_2epresyntax_2epackPat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackPat_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s1732792088x1893487364(V, V, V);
V g_list_2emap_24s1732792088x1893487364_entry(V self, V *a);
extern Clo g_list_2emap_24s1732792088x1893487364_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        heff_take_n(v_p_240, 0ULL, 2);
        V v_t_249 = heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_head__args, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_tsp_245}), v_ps_246});
      }
      default: return heff_nomatch(v_p_240);
      }
    }
    case TAG_PatOp: {
      V v_x_2410 = heff_field(v_p1_241, 0);
      V v_xsp_2411 = heff_field(v_p1_241, 1);
      V v_ps_2412 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 0ULL, 2);
        V v_t_2415 = heff_tag_at_n(v_ru_24p_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2410}), v_xsp_2411});
        return heff_rec_n(2, shape_head__args, (V[]){v_t_2415, v_ps_2412});
      }
      default: return heff_nomatch(v_p_240);
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatSpineOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclaredMuts(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_StmtBind: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLet: {
        heff_take_n(v_x111_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtExpr: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_StmtLetMut: {
        V v_x_2411 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 3);
        V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
        V v_u_2415 = (g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(v_rest_242, heff_dup(v_cell_2414)));
        heff_drop(v_u_2415);
        return v_cell_2414;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclaredMuts(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackPat_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackPat_str1, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackPat_str2, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2epackPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackPat_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackPat(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackPat_str0)}), v_sp_240});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), v_sp_240});
    }
    case TAG_Cons: {
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_247 = (g_heff_2esyntax_2epresyntax_2epackPat(heff_dup(v_sp_240), v_x22_243));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_ps_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248});
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackPat_str1)}), heff_dup(v_sp_240)});
      V v_x1_2411 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2410, v_ps_249));
      V v_t_2414;
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_At: {
        V v_s_2413 = heff_field(v_x1_2411, 1);
        heff_take_n(v_x1_2411, 2ULL, 2);
        v_t_2414 = v_s_2413;
        break;
      }
      default: heff_nomatch(v_x1_2411);
      }
      V v_t_2415 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2414, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackPat_str2), v_sp_240, v_ps_249}), v_t_2415});
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epackPat(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT3 v_t_244 = ({ V a_0 = v_st_240; V a_1 = v_x_242; HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      V v_st_248 = v_field_245;
      V v_y_249 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_st_248, v_xs_243));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        return ((HeffT2){{v_x_2413, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_249, v_y_2414})}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackLet_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackLet_str1, 6, "given#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackLet_str2, 6, "given#");
Clo g_heff_2esyntax_2epresyntax_2egiveBackLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egiveBackLet_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2egiveBackLet(V v_sp_240, V v_xs_241, V v_e_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackLet_str0)}), heff_dup(v_sp_240)});
    V v_t_247;
    switch (heff_tag_of(v_body_243)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_body_243, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_body_243);
    }
    V v_t_248 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_247, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_244, heff_dup(v_body_243)}), v_t_248});
    V v_t_2412;
    switch (heff_tag_of(v_body_243)) {
    case TAG_At: {
      V v_s_2411 = heff_field(v_body_243, 1);
      heff_take_n(v_body_243, 2ULL, 2);
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_body_243);
    }
    V v_t_2413 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_e_242, v_t_249}), v_t_2413});
  }
  case TAG_Cons: {
    V v_xs2_2415 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_2415)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_241)) {
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_xs_241, 0);
        V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 1ULL, 2);
        V v_t_2418 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2416}), heff_dup(v_sp_240)});
        V v_t_2421;
        switch (heff_tag_of(v_body_243)) {
        case TAG_At: {
          V v_s_2420 = heff_dup(heff_field(v_body_243, 1));
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_body_243);
        }
        V v_t_2422 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2421, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2418, heff_dup(v_body_243)}), v_t_2422});
        V v_t_2426;
        switch (heff_tag_of(v_body_243)) {
        case TAG_At: {
          V v_s_2425 = heff_field(v_body_243, 1);
          heff_take_n(v_body_243, 2ULL, 2);
          v_t_2426 = v_s_2425;
          break;
        }
        default: heff_nomatch(v_body_243);
        }
        V v_t_2427 = ({ V rv_1 = heff_get_n(v_t_2426, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_e_242, v_t_2423}), v_t_2427});
      }
      default: return heff_nomatch(v_xs_241);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_2415_24Cons = heff_take_reuse_n(v_xs2_2415, 0ULL, 2);
      V v_t_2430 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_body_2431 = (g_heff_2esyntax_2epresyntax_2egiveBackMatch(heff_dup(v_sp_240), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackLet_str1), v_t_2430), v_xs_241, v_body_243));
      V v_t_2432 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_t_2433 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackLet_str2), v_t_2432)});
      V v_t_2434 = heff_tag_at_n(v_ru_24xs2_2415_24Cons, TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, heff_dup(v_sp_240)}), heff_dup(v_body_2431)});
      V v_t_2437;
      switch (heff_tag_of(v_body_2431)) {
      case TAG_At: {
        V v_s_2436 = heff_dup(heff_field(v_body_2431, 1));
        v_t_2437 = v_s_2436;
        break;
      }
      default: heff_nomatch(v_body_2431);
      }
      V v_t_2438 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2437, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2439 = heff_tag_n(TAG_ELetIn, 2, (V[]){v_e_242, heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_t_2438})});
      V v_t_2442;
      switch (heff_tag_of(v_body_2431)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_body_2431, 1);
        heff_take_n(v_body_2431, 2ULL, 2);
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_body_2431);
      }
      V v_t_2443 = ({ V rv_1 = heff_get_n(v_t_2442, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2439, v_t_2443});
    }
    default: return heff_nomatch(v_xs2_2415);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2esyntax_2epresyntax_2egiveBackLet_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egiveBackLet(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivenTy_str0, 14, "prelude.Either");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivenTy_str1, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivenTy_str2, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2egivenTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egivenTy_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2egivenTy(V v_sp_240, V v_x2_241, V v_vars_242) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egivenTy_str0)}), heff_dup(v_sp_240)});
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egivenTy_str1)}), heff_dup(v_sp_240)});
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egivenTy_str2)}), heff_dup(v_sp_240)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246));
    V v_t_248 = (g_heff_2esyntax_2epresyntax_2epackTy(v_sp_240, v_vars_242));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})));
  } else {
    return (g_heff_2esyntax_2epresyntax_2epackTy(v_sp_240, v_vars_242));
  }
}
V g_heff_2esyntax_2epresyntax_2egivenTy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2egivenTy(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eelseFalls_str0, 136, "the `else` of `let p = e else ...` must leave the block: end it with `return`, `break`, `continue` or `abandon`; for a value, use `case`");

static V g_heff_2esyntax_2epresyntax_2eelseFalls_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eelseFalls_st;
static V g_heff_2esyntax_2epresyntax_2eelseFalls_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2eelseFalls_str0);
}
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eelseFalls_st)) return g_heff_2esyntax_2epresyntax_2eelseFalls_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eelseFalls_val, &g_heff_2esyntax_2epresyntax_2eelseFalls_st, g_heff_2esyntax_2epresyntax_2eelseFalls_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str1, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str2, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str4, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str5, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str7, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str8, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str10, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str11, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str13, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str14, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str15, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str17, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str18, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str19, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str20, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str21, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str22, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str23, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str24, 1, "_");
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam2(V self, V *args);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam3(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V v_cx_240, V v_x3_241, V v_rest_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_sp_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_StmtBind: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_xsp_247 = heff_field(v_x31_244, 1);
      V v_x313_248 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 7ULL, 3);
      heff_drop_rec(v_sp_245, 2);
      switch (heff_tag_of(v_x313_248)) {
      case TAG_At: {
        V v_x3131_249 = heff_dup(heff_field(v_x313_248, 0));
        switch (heff_tag_of(v_x3131_249)) {
        case TAG_EFor: {
          V v_q_2411 = heff_field(v_x3131_249, 0);
          V v_c_2412 = heff_field(v_x3131_249, 1);
          V v_body_2413 = heff_field(v_x3131_249, 2);
          heff_take_n(v_x3131_249, 7ULL, 3);
          switch (heff_tag_of(v_x313_248)) {
          case TAG_At: {
            V v_fsp_2415 = heff_field(v_x313_248, 1);
            V v_ru_24x313_248_24At = heff_take_reuse_n(v_x313_248, 2ULL, 2);
            V v_t_2416 = (g_list_2eany_24s2077819594x1842428557(v_x_246, heff_rfield(v_cx_240, 1)));
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop_rec(v_cx_240, 6);
              heff_drop(v_rest_242);
              heff_drop(v_end_243);
              heff_drop(v_q_2411);
              heff_drop(v_c_2412);
              heff_drop(v_body_2413);
              heff_drop(v_fsp_2415);
              heff_drop_cell(v_ru_24x313_248_24At, 2);
              heff_drop(v_t_2416);
              V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str0), heff_dup(v_x_246)), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str1));
              V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_x_246), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str2));
              return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2418}), v_xsp_247});
            } else {
              heff_drop(v_t_2416);
              V v_t_2419 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_246}), v_xsp_247});
              V v_t_2420 = (g_heff_2esyntax_2epresyntax_2egathered(v_t_2419, v_fsp_2415, v_q_2411, v_c_2412, v_body_2413));
              V v_ss_2421 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x313_248_24At, v_t_2420, v_rest_242));
              V v_cx_2422 = v_cx_240;
              V v_x3_2423 = v_ss_2421;
              V v_end_2424 = v_end_243;
              switch (heff_tag_of(v_x3_2423)) {
              case TAG_Nil: {
                return (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_2422), heff_get_n(v_cx_2422, 3, 6), v_end_2424));
              }
              case TAG_Cons: {
                V v_s_2425 = heff_field(v_x3_2423, 0);
                V v_x32_2426 = heff_field(v_x3_2423, 1);
                V v_ru_24x3_2423_24Cons = heff_take_reuse_n(v_x3_2423, 3ULL, 2);
                switch (heff_tag_of(v_x32_2426)) {
                case TAG_Nil: {
                  switch (heff_tag_of(v_end_2424)) {
                  case TAG_EndValue: {
                    return (g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(v_ru_24x3_2423_24Cons, v_cx_2422, v_s_2425));
                  }
                  case TAG_EndJump: {
                    heff_drop_cell(v_ru_24x3_2423_24Cons, 2);
                    V t_0 = v_cx_2422;
                    V t_1 = v_s_2425;
                    V t_2 = v_x32_2426;
                    V t_3 = v_end_2424;
                    v_cx_240 = t_0;
                    v_x3_241 = t_1;
                    v_rest_242 = t_2;
                    v_end_243 = t_3;
                    goto top;
                  }
                  case TAG_EndGive: {
                    heff_drop_cell(v_ru_24x3_2423_24Cons, 2);
                    V t_0 = v_cx_2422;
                    V t_1 = v_s_2425;
                    V t_2 = v_x32_2426;
                    V t_3 = v_end_2424;
                    v_cx_240 = t_0;
                    v_x3_241 = t_1;
                    v_rest_242 = t_2;
                    v_end_243 = t_3;
                    goto top;
                  }
                  default: return heff_nomatch(v_end_2424);
                  }
                }
                case TAG_Cons: {
                  heff_drop_cell(v_ru_24x3_2423_24Cons, 2);
                  V t_0 = v_cx_2422;
                  V t_1 = v_s_2425;
                  V t_2 = v_x32_2426;
                  V t_3 = v_end_2424;
                  v_cx_240 = t_0;
                  v_x3_241 = t_1;
                  v_rest_242 = t_2;
                  v_end_243 = t_3;
                  goto top;
                }
                default: return heff_nomatch(v_x32_2426);
                }
              }
              default: return heff_nomatch(v_x3_2423);
              }
            }
          }
          default: return heff_nomatch(v_x313_248);
          }
        }
        default: {
          heff_drop(v_x3131_249);
          V v_t_2432 = (g_list_2eany_24s2077819594x1842428557(v_x_246, heff_rfield(v_cx_240, 1)));
          if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
            heff_drop_rec(v_cx_240, 6);
            heff_drop(v_rest_242);
            heff_drop(v_end_243);
            heff_drop_tag(v_x313_248, 2);
            heff_drop(v_t_2432);
            V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str3), heff_dup(v_x_246)), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str4));
            V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, v_x_246), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str5));
            return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2434}), v_xsp_247});
          } else {
            heff_drop(v_t_2432);
            V v_t_2435 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2436 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2435}), NTAG(TAG_Nil), v_x313_248));
            {
              V v_field_2437 = v_t_2436.f[0];
              V v_field_2438 = v_t_2436.f[1];
              V v_x_2439 = v_field_2437;
              V v_y_2440 = v_field_2438;
              V v_cx_2441 = heff_dup(v_cx_240);
              V v_x3_2442 = v_rest_242;
              V v_end_2443 = v_end_243;
              V v_rest_2451;
              switch (heff_tag_of(v_x3_2442)) {
              case TAG_Nil: {
                v_rest_2451 = (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_2441), heff_get_n(v_cx_2441, 3, 6), v_end_2443));
                break;
              }
              case TAG_Cons: {
                V v_s_2444 = heff_field(v_x3_2442, 0);
                V v_x32_2445 = heff_field(v_x3_2442, 1);
                V v_ru_24x3_2442_24Cons = heff_take_reuse_n(v_x3_2442, 3ULL, 2);
                switch (heff_tag_of(v_x32_2445)) {
                case TAG_Nil: {
                  switch (heff_tag_of(v_end_2443)) {
                  case TAG_EndValue: {
                    v_rest_2451 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(v_ru_24x3_2442_24Cons, v_cx_2441, v_s_2444));
                    break;
                  }
                  case TAG_EndJump: {
                    heff_drop_cell(v_ru_24x3_2442_24Cons, 2);
                    v_rest_2451 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2441, v_s_2444, v_x32_2445, v_end_2443));
                    break;
                  }
                  case TAG_EndGive: {
                    heff_drop_cell(v_ru_24x3_2442_24Cons, 2);
                    v_rest_2451 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2441, v_s_2444, v_x32_2445, v_end_2443));
                    break;
                  }
                  default: heff_nomatch(v_end_2443);
                  }
                  break;
                }
                case TAG_Cons: {
                  heff_drop_cell(v_ru_24x3_2442_24Cons, 2);
                  v_rest_2451 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2441, v_s_2444, v_x32_2445, v_end_2443));
                  break;
                }
                default: heff_nomatch(v_x32_2445);
                }
                break;
              }
              default: heff_nomatch(v_x3_2442);
              }
              V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
              V v_t_2453 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2452}), heff_dup(heff_rfield(v_cx_240, 3))});
              V v_t_2454 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_246, heff_dup(v_xsp_247)}), heff_dup(v_rest_2451)});
              V v_t_2457;
              switch (heff_tag_of(v_rest_2451)) {
              case TAG_At: {
                V v_s_2456 = heff_field(v_rest_2451, 1);
                heff_take_n(v_rest_2451, 2ULL, 2);
                v_t_2457 = v_s_2456;
                break;
              }
              default: heff_nomatch(v_rest_2451);
              }
              V v_t_2458 = ({ V rv_1 = heff_get_n(v_t_2457, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_247, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2454, v_t_2458}), NTAG(TAG_Nil)});
              V v_t_2460 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2453, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2440, v_t_2459})));
              return ({ V a_0 = v_cx_240; V a_1 = v_x_2439; V a_2 = v_t_2460; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2439); r_; });
            }
          }
        }
        }
      }
      default: return heff_nomatch(v_x313_248);
      }
    }
    case TAG_StmtLet: {
      V v_p_2461 = heff_field(v_x31_244, 0);
      V v_x312_2462 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24StmtLet = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      switch (heff_tag_of(v_x312_2462)) {
      case TAG_At: {
        V v_x3121_2463 = heff_dup(heff_field(v_x312_2462, 0));
        switch (heff_tag_of(v_x3121_2463)) {
        case TAG_ENest: {
          V v_x31211_2465 = heff_field(v_x3121_2463, 0);
          V v_ru_24x3121_2463_24ENest = heff_take_reuse_n(v_x3121_2463, 1ULL, 1);
          switch (heff_tag_of(v_x31211_2465)) {
          case TAG_At: {
            V v_x312111_2466 = heff_field(v_x31211_2465, 0);
            V v_fsp_2467 = heff_field(v_x31211_2465, 1);
            V v_ru_24x31211_2465_24At = heff_take_reuse_n(v_x31211_2465, 3ULL, 2);
            switch (heff_tag_of(v_x312111_2466)) {
            case TAG_EFor: {
              V v_q_2468 = heff_field(v_x312111_2466, 0);
              V v_c_2469 = heff_field(v_x312111_2466, 1);
              V v_body_2470 = heff_field(v_x312111_2466, 2);
              heff_take_n(v_x312111_2466, 7ULL, 3);
              heff_drop_rec(v_sp_245, 2);
              heff_drop_tag(v_x312_2462, 2);
              V v_xs_2471 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x31_244_24StmtLet, heff_dup(v_p_2461)));
              HeffT2 v_t_2473 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam0, 1, 1, (V[]){heff_dup(v_cx_240)}); V a_1 = v_xs_2471; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_xs_2471); r_; });
              {
                V v_field_2475 = v_t_2473.f[1];
                int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
                if ((v_tag_2474 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_cx_240, 6);
                  heff_drop(v_rest_242);
                  heff_drop(v_end_243);
                  heff_drop(v_fsp_2467);
                  heff_drop_cell(v_ru_24x31211_2465_24At, 2);
                  heff_drop(v_q_2468);
                  heff_drop(v_c_2469);
                  heff_drop(v_body_2470);
                  V v_x_2476 = v_field_2475;
                  V v_t_2477 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str6), heff_dup(v_x_2476)), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str7));
                  V v_t_2478 = heff_strAppend(heff_strAppend(v_t_2477, v_x_2476), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str8));
                  V v_t_2481;
                  switch (heff_tag_of(v_p_2461)) {
                  case TAG_At: {
                    V v_s_2480 = heff_field(v_p_2461, 1);
                    heff_take_n(v_p_2461, 2ULL, 2);
                    v_t_2481 = v_s_2480;
                    break;
                  }
                  default: heff_nomatch(v_p_2461);
                  }
                  return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x3121_2463_24ENest, TAG_EInvalid, 1, (V[]){v_t_2478}), v_t_2481});
                } else {
                  heff_drop_cell(v_ru_24x3121_2463_24ENest, 1);
                  heff_drop(v_field_2475);
                  V v_t_2482 = (g_heff_2esyntax_2epresyntax_2egathered(v_p_2461, v_fsp_2467, v_q_2468, v_c_2469, v_body_2470));
                  V v_ss_2483 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24At, v_t_2482, v_rest_242));
                  V v_cx_2484 = v_cx_240;
                  V v_x3_2485 = v_ss_2483;
                  V v_end_2486 = v_end_243;
                  switch (heff_tag_of(v_x3_2485)) {
                  case TAG_Nil: {
                    heff_drop_cell(v_ru_24x31211_2465_24At, 2);
                    return (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_2484), heff_get_n(v_cx_2484, 3, 6), v_end_2486));
                  }
                  case TAG_Cons: {
                    V v_s_2487 = heff_field(v_x3_2485, 0);
                    V v_x32_2488 = heff_field(v_x3_2485, 1);
                    heff_take_n(v_x3_2485, 3ULL, 2);
                    switch (heff_tag_of(v_x32_2488)) {
                    case TAG_Nil: {
                      switch (heff_tag_of(v_end_2486)) {
                      case TAG_EndValue: {
                        return (g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(v_ru_24x31211_2465_24At, v_cx_2484, v_s_2487));
                      }
                      case TAG_EndJump: {
                        heff_drop_cell(v_ru_24x31211_2465_24At, 2);
                        V t_0 = v_cx_2484;
                        V t_1 = v_s_2487;
                        V t_2 = v_x32_2488;
                        V t_3 = v_end_2486;
                        v_cx_240 = t_0;
                        v_x3_241 = t_1;
                        v_rest_242 = t_2;
                        v_end_243 = t_3;
                        goto top;
                      }
                      case TAG_EndGive: {
                        heff_drop_cell(v_ru_24x31211_2465_24At, 2);
                        V t_0 = v_cx_2484;
                        V t_1 = v_s_2487;
                        V t_2 = v_x32_2488;
                        V t_3 = v_end_2486;
                        v_cx_240 = t_0;
                        v_x3_241 = t_1;
                        v_rest_242 = t_2;
                        v_end_243 = t_3;
                        goto top;
                      }
                      default: return heff_nomatch(v_end_2486);
                      }
                    }
                    case TAG_Cons: {
                      heff_drop_cell(v_ru_24x31211_2465_24At, 2);
                      V t_0 = v_cx_2484;
                      V t_1 = v_s_2487;
                      V t_2 = v_x32_2488;
                      V t_3 = v_end_2486;
                      v_cx_240 = t_0;
                      v_x3_241 = t_1;
                      v_rest_242 = t_2;
                      v_end_243 = t_3;
                      goto top;
                    }
                    default: return heff_nomatch(v_x32_2488);
                    }
                  }
                  default: return heff_nomatch(v_x3_2485);
                  }
                }
              }
            }
            default: {
              heff_drop(v_x312111_2466);
              heff_drop(v_fsp_2467);
              V v_xs_2494 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_2461)));
              HeffT2 v_t_2496 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam1, 1, 1, (V[]){heff_dup(v_cx_240)}); V a_1 = v_xs_2494; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_xs_2494); r_; });
              {
                V v_field_2498 = v_t_2496.f[1];
                int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
                if ((v_tag_2497 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_cx_240, 6);
                  heff_drop(v_rest_242);
                  heff_drop(v_end_243);
                  heff_drop_rec(v_sp_245, 2);
                  heff_drop_tag(v_x312_2462, 2);
                  heff_drop_cell(v_ru_24x31_244_24StmtLet, 2);
                  heff_drop_cell(v_ru_24x31211_2465_24At, 2);
                  V v_x_2499 = v_field_2498;
                  V v_t_24100 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str9), heff_dup(v_x_2499)), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str10));
                  V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, v_x_2499), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str11));
                  V v_t_24104;
                  switch (heff_tag_of(v_p_2461)) {
                  case TAG_At: {
                    V v_s_24103 = heff_field(v_p_2461, 1);
                    heff_take_n(v_p_2461, 2ULL, 2);
                    v_t_24104 = v_s_24103;
                    break;
                  }
                  default: heff_nomatch(v_p_2461);
                  }
                  return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x3121_2463_24ENest, TAG_EInvalid, 1, (V[]){v_t_24101}), v_t_24104});
                } else {
                  heff_drop_cell(v_ru_24x3121_2463_24ENest, 1);
                  heff_drop(v_field_2498);
                  V v_t_24105 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
                  HeffT2 v_t_24106 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24105}), NTAG(TAG_Nil), v_x312_2462));
                  {
                    V v_field_24107 = v_t_24106.f[0];
                    V v_field_24108 = v_t_24106.f[1];
                    V v_x_24109 = v_field_24107;
                    V v_y_24110 = v_field_24108;
                    V v_cx_24111 = heff_dup(v_cx_240);
                    V v_x3_24112 = v_rest_242;
                    V v_end_24113 = v_end_243;
                    V v_body_24121;
                    switch (heff_tag_of(v_x3_24112)) {
                    case TAG_Nil: {
                      v_body_24121 = (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_24111), heff_get_n(v_cx_24111, 3, 6), v_end_24113));
                      break;
                    }
                    case TAG_Cons: {
                      V v_s_24114 = heff_field(v_x3_24112, 0);
                      V v_x32_24115 = heff_field(v_x3_24112, 1);
                      V v_ru_24x3_24112_24Cons = heff_take_reuse_n(v_x3_24112, 3ULL, 2);
                      switch (heff_tag_of(v_x32_24115)) {
                      case TAG_Nil: {
                        switch (heff_tag_of(v_end_24113)) {
                        case TAG_EndValue: {
                          v_body_24121 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(v_ru_24x3_24112_24Cons, v_cx_24111, v_s_24114));
                          break;
                        }
                        case TAG_EndJump: {
                          heff_drop_cell(v_ru_24x3_24112_24Cons, 2);
                          v_body_24121 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24111, v_s_24114, v_x32_24115, v_end_24113));
                          break;
                        }
                        case TAG_EndGive: {
                          heff_drop_cell(v_ru_24x3_24112_24Cons, 2);
                          v_body_24121 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24111, v_s_24114, v_x32_24115, v_end_24113));
                          break;
                        }
                        default: heff_nomatch(v_end_24113);
                        }
                        break;
                      }
                      case TAG_Cons: {
                        heff_drop_cell(v_ru_24x3_24112_24Cons, 2);
                        v_body_24121 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24111, v_s_24114, v_x32_24115, v_end_24113));
                        break;
                      }
                      default: heff_nomatch(v_x32_24115);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x3_24112);
                    }
                    V v_t_24124;
                    switch (heff_tag_of(v_p_2461)) {
                    case TAG_At: {
                      V v_s_24123 = heff_dup(heff_field(v_p_2461, 1));
                      v_t_24124 = v_s_24123;
                      break;
                    }
                    default: heff_nomatch(v_p_2461);
                    }
                    V v_t_24127;
                    switch (heff_tag_of(v_body_24121)) {
                    case TAG_At: {
                      V v_s_24126 = heff_dup(heff_field(v_body_24121, 1));
                      v_t_24127 = v_s_24126;
                      break;
                    }
                    default: heff_nomatch(v_body_24121);
                    }
                    V v_t_24128 = ({ V rv_1 = heff_get_n(v_t_24127, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24124, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_24129 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_244_24StmtLet, TAG_MkAlt, 2, (V[]){v_p_2461, heff_dup(v_body_24121)}), v_t_24128});
                    V v_t_24132;
                    switch (heff_tag_of(v_body_24121)) {
                    case TAG_At: {
                      V v_s_24131 = heff_field(v_body_24121, 1);
                      heff_take_n(v_body_24121, 2ULL, 2);
                      v_t_24132 = v_s_24131;
                      break;
                    }
                    default: heff_nomatch(v_body_24121);
                    }
                    V v_t_24133 = ({ V rv_1 = heff_get_n(v_t_24132, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                    V v_t_24134 = heff_tag_at_n(v_ru_24x31211_2465_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24110, v_t_24129}), v_t_24133});
                    return ({ V a_0 = v_cx_240; V a_1 = v_x_24109; V a_2 = v_t_24134; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24109); r_; });
                  }
                }
              }
            }
            }
          }
          default: return heff_nomatch(v_x31211_2465);
          }
        }
        default: {
          heff_drop(v_x3121_2463);
          V v_xs_24135 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_2461)));
          HeffT2 v_t_24137 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam2, 1, 1, (V[]){heff_dup(v_cx_240)}); V a_1 = v_xs_24135; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_xs_24135); r_; });
          {
            V v_field_24139 = v_t_24137.f[1];
            int64_t v_tag_24138 = ((int64_t)v_t_24137.f[0]);
            if ((v_tag_24138 == ((int64_t)0ULL))) {
              heff_drop_rec(v_cx_240, 6);
              heff_drop(v_rest_242);
              heff_drop(v_end_243);
              heff_drop_rec(v_sp_245, 2);
              heff_drop_tag(v_x312_2462, 2);
              heff_drop_cell(v_ru_24x31_244_24StmtLet, 2);
              V v_x_24140 = v_field_24139;
              V v_t_24141 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str12), heff_dup(v_x_24140)), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str13));
              V v_t_24142 = heff_strAppend(heff_strAppend(v_t_24141, v_x_24140), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str14));
              V v_t_24145;
              switch (heff_tag_of(v_p_2461)) {
              case TAG_At: {
                V v_s_24144 = heff_field(v_p_2461, 1);
                heff_take_n(v_p_2461, 2ULL, 2);
                v_t_24145 = v_s_24144;
                break;
              }
              default: heff_nomatch(v_p_2461);
              }
              return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24142}), v_t_24145});
            } else {
              heff_drop(v_field_24139);
              V v_t_24146 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
              HeffT2 v_t_24147 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24146}), NTAG(TAG_Nil), v_x312_2462));
              {
                V v_field_24148 = v_t_24147.f[0];
                V v_field_24149 = v_t_24147.f[1];
                V v_x_24150 = v_field_24148;
                V v_y_24151 = v_field_24149;
                V v_cx_24152 = heff_dup(v_cx_240);
                V v_x3_24153 = v_rest_242;
                V v_end_24154 = v_end_243;
                V v_body_24162;
                switch (heff_tag_of(v_x3_24153)) {
                case TAG_Nil: {
                  v_body_24162 = (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_24152), heff_get_n(v_cx_24152, 3, 6), v_end_24154));
                  break;
                }
                case TAG_Cons: {
                  V v_s_24155 = heff_field(v_x3_24153, 0);
                  V v_x32_24156 = heff_field(v_x3_24153, 1);
                  V v_ru_24x3_24153_24Cons = heff_take_reuse_n(v_x3_24153, 3ULL, 2);
                  switch (heff_tag_of(v_x32_24156)) {
                  case TAG_Nil: {
                    switch (heff_tag_of(v_end_24154)) {
                    case TAG_EndValue: {
                      v_body_24162 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(v_ru_24x3_24153_24Cons, v_cx_24152, v_s_24155));
                      break;
                    }
                    case TAG_EndJump: {
                      heff_drop_cell(v_ru_24x3_24153_24Cons, 2);
                      v_body_24162 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24152, v_s_24155, v_x32_24156, v_end_24154));
                      break;
                    }
                    case TAG_EndGive: {
                      heff_drop_cell(v_ru_24x3_24153_24Cons, 2);
                      v_body_24162 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24152, v_s_24155, v_x32_24156, v_end_24154));
                      break;
                    }
                    default: heff_nomatch(v_end_24154);
                    }
                    break;
                  }
                  case TAG_Cons: {
                    heff_drop_cell(v_ru_24x3_24153_24Cons, 2);
                    v_body_24162 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24152, v_s_24155, v_x32_24156, v_end_24154));
                    break;
                  }
                  default: heff_nomatch(v_x32_24156);
                  }
                  break;
                }
                default: heff_nomatch(v_x3_24153);
                }
                V v_t_24165;
                switch (heff_tag_of(v_p_2461)) {
                case TAG_At: {
                  V v_s_24164 = heff_dup(heff_field(v_p_2461, 1));
                  v_t_24165 = v_s_24164;
                  break;
                }
                default: heff_nomatch(v_p_2461);
                }
                V v_t_24168;
                switch (heff_tag_of(v_body_24162)) {
                case TAG_At: {
                  V v_s_24167 = heff_dup(heff_field(v_body_24162, 1));
                  v_t_24168 = v_s_24167;
                  break;
                }
                default: heff_nomatch(v_body_24162);
                }
                V v_t_24169 = ({ V rv_1 = heff_get_n(v_t_24168, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24165, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24170 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_244_24StmtLet, TAG_MkAlt, 2, (V[]){v_p_2461, heff_dup(v_body_24162)}), v_t_24169});
                V v_t_24173;
                switch (heff_tag_of(v_body_24162)) {
                case TAG_At: {
                  V v_s_24172 = heff_field(v_body_24162, 1);
                  heff_take_n(v_body_24162, 2ULL, 2);
                  v_t_24173 = v_s_24172;
                  break;
                }
                default: heff_nomatch(v_body_24162);
                }
                V v_t_24174 = ({ V rv_1 = heff_get_n(v_t_24173, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24175 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_y_24151, v_t_24170}), v_t_24174});
                return ({ V a_0 = v_cx_240; V a_1 = v_x_24150; V a_2 = v_t_24175; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24150); r_; });
              }
            }
          }
        }
        }
      }
      default: return heff_nomatch(v_x312_2462);
      }
    }
    case TAG_StmtExpr: {
      V v_e_24176 = heff_field(v_x31_244, 0);
      V v_ru_24x31_244_24StmtExpr = heff_take_reuse_n(v_x31_244, 1ULL, 1);
      heff_drop_rec(v_sp_245, 2);
      V v_t_24177 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_24176));
      if ((heff_dup(v_t_24177) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop_cell(v_ru_24x31_244_24StmtExpr, 1);
        heff_drop(v_t_24177);
        HEFF_LAST return g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(v_cx_240, v_e_24176, v_rest_242, v_end_243);
      } else {
        heff_drop(v_t_24177);
        V v_t_24178 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_24179 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24178}), NTAG(TAG_Nil), v_e_24176));
        {
          V v_field_24180 = v_t_24179.f[0];
          V v_field_24181 = v_t_24179.f[1];
          V v_x_24182 = v_field_24180;
          V v_y_24183 = v_field_24181;
          V v_xsp_24184 = heff_dup(heff_rfield(v_cx_240, 3));
          V v_cx_24185 = heff_dup(v_cx_240);
          V v_x3_24186 = v_rest_242;
          V v_end_24187 = v_end_243;
          V v_rest_24195;
          switch (heff_tag_of(v_x3_24186)) {
          case TAG_Nil: {
            v_rest_24195 = (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_24185), heff_get_n(v_cx_24185, 3, 6), v_end_24187));
            break;
          }
          case TAG_Cons: {
            V v_s_24188 = heff_field(v_x3_24186, 0);
            V v_x32_24189 = heff_field(v_x3_24186, 1);
            V v_ru_24x3_24186_24Cons = heff_take_reuse_n(v_x3_24186, 3ULL, 2);
            switch (heff_tag_of(v_x32_24189)) {
            case TAG_Nil: {
              switch (heff_tag_of(v_end_24187)) {
              case TAG_EndValue: {
                v_rest_24195 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(v_ru_24x3_24186_24Cons, v_cx_24185, v_s_24188));
                break;
              }
              case TAG_EndJump: {
                heff_drop_cell(v_ru_24x3_24186_24Cons, 2);
                v_rest_24195 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24185, v_s_24188, v_x32_24189, v_end_24187));
                break;
              }
              case TAG_EndGive: {
                heff_drop_cell(v_ru_24x3_24186_24Cons, 2);
                v_rest_24195 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24185, v_s_24188, v_x32_24189, v_end_24187));
                break;
              }
              default: heff_nomatch(v_end_24187);
              }
              break;
            }
            case TAG_Cons: {
              heff_drop_cell(v_ru_24x3_24186_24Cons, 2);
              v_rest_24195 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24185, v_s_24188, v_x32_24189, v_end_24187));
              break;
            }
            default: heff_nomatch(v_x32_24189);
            }
            break;
          }
          default: heff_nomatch(v_x3_24186);
          }
          V v_t_24196 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
          V v_t_24197 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_244_24StmtExpr, TAG_EVar, 1, (V[]){v_t_24196}), heff_dup(heff_rfield(v_cx_240, 3))});
          V v_t_24198 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str15), heff_dup(v_xsp_24184)}), heff_dup(v_rest_24195)});
          V v_t_24201;
          switch (heff_tag_of(v_rest_24195)) {
          case TAG_At: {
            V v_s_24200 = heff_field(v_rest_24195, 1);
            heff_take_n(v_rest_24195, 2ULL, 2);
            v_t_24201 = v_s_24200;
            break;
          }
          default: heff_nomatch(v_rest_24195);
          }
          V v_t_24202 = ({ V rv_1 = heff_get_n(v_t_24201, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24184, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24203 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24198, v_t_24202}), NTAG(TAG_Nil)});
          V v_t_24204 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24197, heff_tag_n(TAG_Cons, 2, (V[]){v_y_24183, v_t_24203})));
          return ({ V a_0 = v_cx_240; V a_1 = v_x_24182; V a_2 = v_t_24204; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24182); r_; });
        }
      }
    }
    case TAG_StmtLetMut: {
      V v_x_24205 = heff_field(v_x31_244, 0);
      V v_xsp_24206 = heff_field(v_x31_244, 1);
      V v_e_24207 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 7ULL, 3);
      heff_drop_rec(v_sp_245, 2);
      V v_t_24208 = (g_list_2eany_24s2077819594x1842428557(v_x_24205, heff_rfield(v_cx_240, 1)));
      if ((heff_dup(v_t_24208) == NTAG(TAG_True))) {
        heff_drop_rec(v_cx_240, 6);
        heff_drop(v_rest_242);
        heff_drop(v_end_243);
        heff_drop(v_e_24207);
        heff_drop(v_t_24208);
        V v_t_24209 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str16), heff_dup(v_x_24205)), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str17));
        V v_t_24210 = heff_strAppend(heff_strAppend(v_t_24209, v_x_24205), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str18));
        return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24210}), v_xsp_24206});
      } else {
        heff_drop(v_t_24208);
        V v_t_24211 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_24212 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24211}), NTAG(TAG_Nil), v_e_24207));
        {
          V v_field_24213 = v_t_24212.f[0];
          V v_field_24214 = v_t_24212.f[1];
          V v_x_24215 = v_field_24213;
          V v_y_24216 = v_field_24214;
          V v_sp_24219;
          switch (heff_tag_of(v_y_24216)) {
          case TAG_At: {
            V v_s_24218 = heff_dup(heff_field(v_y_24216, 1));
            v_sp_24219 = v_s_24218;
            break;
          }
          default: heff_nomatch(v_y_24216);
          }
          V v_t_24220 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str19)}), heff_dup(v_sp_24219)});
          V v_t_24221 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str20)}), v_sp_24219});
          V v_t_24222 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24221, NTAG(TAG_Nil)});
          V v_t_24223 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24220, v_t_24222));
          V v_t_24226;
          switch (heff_tag_of(v_y_24216)) {
          case TAG_At: {
            V v_s_24225 = heff_dup(heff_field(v_y_24216, 1));
            v_t_24226 = v_s_24225;
            break;
          }
          default: heff_nomatch(v_y_24216);
          }
          V v_v_24227 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_24216, v_t_24223}), v_t_24226});
          V v_t_24228 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_24205), NTAG(TAG_Nil)});
          V v_t_24229 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_cx_240, 1)), v_t_24228));
          V v_cx_24230 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), v_t_24229, heff_dup(heff_rfield(v_cx_240, 2)), heff_dup(heff_rfield(v_cx_240, 3)), heff_dup(heff_rfield(v_cx_240, 4)), heff_dup(heff_rfield(v_cx_240, 5))});
          V v_cx_24231 = v_cx_24230;
          V v_x3_24232 = v_rest_242;
          V v_end_24233 = v_end_243;
          V v_body_24241;
          switch (heff_tag_of(v_x3_24232)) {
          case TAG_Nil: {
            v_body_24241 = (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_24231), heff_get_n(v_cx_24231, 3, 6), v_end_24233));
            break;
          }
          case TAG_Cons: {
            V v_s_24234 = heff_field(v_x3_24232, 0);
            V v_x32_24235 = heff_field(v_x3_24232, 1);
            V v_ru_24x3_24232_24Cons = heff_take_reuse_n(v_x3_24232, 3ULL, 2);
            switch (heff_tag_of(v_x32_24235)) {
            case TAG_Nil: {
              switch (heff_tag_of(v_end_24233)) {
              case TAG_EndValue: {
                v_body_24241 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_24tok2(v_ru_24x3_24232_24Cons, v_cx_24231, v_s_24234));
                break;
              }
              case TAG_EndJump: {
                heff_drop_cell(v_ru_24x3_24232_24Cons, 2);
                v_body_24241 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24231, v_s_24234, v_x32_24235, v_end_24233));
                break;
              }
              case TAG_EndGive: {
                heff_drop_cell(v_ru_24x3_24232_24Cons, 2);
                v_body_24241 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24231, v_s_24234, v_x32_24235, v_end_24233));
                break;
              }
              default: heff_nomatch(v_end_24233);
              }
              break;
            }
            case TAG_Cons: {
              heff_drop_cell(v_ru_24x3_24232_24Cons, 2);
              v_body_24241 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_24231, v_s_24234, v_x32_24235, v_end_24233));
              break;
            }
            default: heff_nomatch(v_x32_24235);
            }
            break;
          }
          default: heff_nomatch(v_x3_24232);
          }
          V v_t_24242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_24205}), heff_dup(v_xsp_24206)});
          V v_t_24245;
          switch (heff_tag_of(v_body_24241)) {
          case TAG_At: {
            V v_s_24244 = heff_dup(heff_field(v_body_24241, 1));
            v_t_24245 = v_s_24244;
            break;
          }
          default: heff_nomatch(v_body_24241);
          }
          V v_t_24246 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_24206, 0)); V rr_ = heff_rec_reuse_nf(v_t_24245, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_24247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_24242, heff_dup(v_body_24241)}), v_t_24246});
          V v_t_24250;
          switch (heff_tag_of(v_body_24241)) {
          case TAG_At: {
            V v_s_24249 = heff_field(v_body_24241, 1);
            heff_take_n(v_body_24241, 2ULL, 2);
            v_t_24250 = v_s_24249;
            break;
          }
          default: heff_nomatch(v_body_24241);
          }
          V v_t_24251 = ({ V rv_1 = heff_get_n(v_t_24250, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_24206, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_24252 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_24227, v_t_24247}), v_t_24251});
          return ({ V a_0 = v_cx_240; V a_1 = v_x_24215; V a_2 = v_t_24252; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24215); r_; });
        }
      }
    }
    case TAG_StmtLetElse: {
      V v_p_24253 = heff_field(v_x31_244, 0);
      V v_e_24254 = heff_field(v_x31_244, 1);
      V v_els_24255 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 7ULL, 3);
      V v_xs_24256 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_24253)));
      HeffT2 v_t_24258 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam3, 1, 1, (V[]){heff_dup(v_cx_240)}); V a_1 = v_xs_24256; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_xs_24256); r_; });
      {
        V v_field_24260 = v_t_24258.f[1];
        int64_t v_tag_24259 = ((int64_t)v_t_24258.f[0]);
        if ((v_tag_24259 == ((int64_t)0ULL))) {
          heff_drop_rec(v_cx_240, 6);
          heff_drop(v_rest_242);
          heff_drop(v_end_243);
          heff_drop_rec(v_sp_245, 2);
          heff_drop(v_e_24254);
          heff_drop(v_els_24255);
          V v_x_24261 = v_field_24260;
          V v_t_24262 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str21), heff_dup(v_x_24261)), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str22));
          V v_t_24263 = heff_strAppend(heff_strAppend(v_t_24262, v_x_24261), ((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str23));
          V v_t_24266;
          switch (heff_tag_of(v_p_24253)) {
          case TAG_At: {
            V v_s_24265 = heff_field(v_p_24253, 1);
            heff_take_n(v_p_24253, 2ULL, 2);
            v_t_24266 = v_s_24265;
            break;
          }
          default: heff_nomatch(v_p_24253);
          }
          return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_24263}), v_t_24266});
        } else {
          heff_drop(v_field_24260);
          V v_t_24267 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_str24)}), heff_dup(v_sp_245)});
          V v_sp_24268 = heff_dup(v_sp_245);
          V v_ss_24269 = v_els_24255;
          V v_x1_24270 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_24269)));
          V v_t_24287;
          switch (heff_tag_of(v_x1_24270)) {
          case TAG_Nil: {
            v_t_24287 = NTAG(TAG_False);
            break;
          }
          case TAG_Cons: {
            V v_x_24271 = heff_field(v_x1_24270, 0);
            heff_take_n(v_x1_24270, 1ULL, 2);
            switch (heff_tag_of(v_x_24271)) {
            case TAG_At: {
              V v_it11_24273 = heff_field(v_x_24271, 0);
              heff_take_n(v_x_24271, 1ULL, 2);
              switch (heff_tag_of(v_it11_24273)) {
              case TAG_StmtBind: {
                heff_take_n(v_it11_24273, 0ULL, 3);
                v_t_24287 = NTAG(TAG_False);
                break;
              }
              case TAG_StmtLet: {
                heff_take_n(v_it11_24273, 0ULL, 2);
                v_t_24287 = NTAG(TAG_False);
                break;
              }
              case TAG_StmtExpr: {
                V v_e_24280 = heff_field(v_it11_24273, 0);
                heff_take_n(v_it11_24273, 1ULL, 1);
                v_t_24287 = (g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(v_e_24280));
                break;
              }
              case TAG_StmtLetMut: {
                heff_take_n(v_it11_24273, 0ULL, 3);
                v_t_24287 = NTAG(TAG_False);
                break;
              }
              case TAG_StmtLetElse: {
                heff_take_n(v_it11_24273, 0ULL, 3);
                v_t_24287 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_it11_24273);
              }
              break;
            }
            default: heff_nomatch(v_x_24271);
            }
            break;
          }
          default: heff_nomatch(v_x1_24270);
          }
          V v_t_24297;
          if ((heff_dup(v_t_24287) == NTAG(TAG_True))) {
            heff_drop(v_sp_24268);
            heff_drop(v_t_24287);
            v_t_24297 = v_ss_24269;
          } else {
            heff_drop(v_t_24287);
            V v_x1_24288 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_24269));
            switch (heff_tag_of(v_x1_24288)) {
            case TAG_Nil: {
              V v_t_24289 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eelseFalls_get())}), heff_dup(v_sp_24268)});
              V v_t_24290 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_24289}), v_sp_24268});
              v_t_24297 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24290, NTAG(TAG_Nil)});
              break;
            }
            case TAG_Cons: {
              V v_x_24291 = heff_field(v_x1_24288, 0);
              V v_ru_24x1_24288_24Cons = heff_take_reuse_n(v_x1_24288, 1ULL, 2);
              heff_drop(v_sp_24268);
              switch (heff_tag_of(v_x_24291)) {
              case TAG_At: {
                V v_esp_24294 = heff_field(v_x_24291, 1);
                V v_ru_24x_24291_24At = heff_take_reuse_n(v_x_24291, 2ULL, 2);
                V v_t_24295 = heff_tag_at_n(v_ru_24x_24291_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eelseFalls_get())}), heff_dup(v_esp_24294)});
                V v_t_24296 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_24295}), v_esp_24294});
                v_t_24297 = heff_tag_at_n(v_ru_24x1_24288_24Cons, TAG_Cons, 2, (V[]){v_t_24296, NTAG(TAG_Nil)});
                break;
              }
              default: heff_nomatch(v_x_24291);
              }
              break;
            }
            default: heff_nomatch(v_x1_24288);
            }
          }
          V v_t_24298 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24267, v_t_24297}), NTAG(TAG_Nil)});
          V v_arms_24299 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_p_24253, v_rest_242}), v_t_24298});
          V v_t_24300 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_24301 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24300}), NTAG(TAG_Nil), v_e_24254));
          {
            V v_field_24302 = v_t_24301.f[0];
            V v_field_24303 = v_t_24301.f[1];
            V v_x_24304 = v_field_24302;
            V v_y_24305 = v_field_24303;
            V v_alts_24306 = (g_list_2emap_24s1732792088x1893487364(heff_dup(v_cx_240), v_end_243, v_arms_24299));
            V v_t_24307 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_24305, v_alts_24306}), v_sp_245});
            return ({ V a_0 = v_cx_240; V a_1 = v_x_24304; V a_2 = v_t_24307; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24304); r_; });
          }
        }
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam0(V self, V *args) {
  V v_x_2472 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2472; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2472); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam1(V self, V *args) {
  V v_x_2495 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2495; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2495); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam2(V self, V *args) {
  V v_x_24136 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24136; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24136); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_lam3(V self, V *args) {
  V v_x_24257 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24257; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_24257); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str0, 3, "run");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str1, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2erunArgs_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2erunArgs(V v_h_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_242 = heff_field(v_h_240, 0);
    V v_ru_24h_240_24At = heff_take_reuse_n(v_h_240, 1ULL, 2);
    switch (heff_tag_of(v_h1_242)) {
    case TAG_EVar: {
      V v_f_244 = heff_field(v_h1_242, 0);
      V v_ru_24h1_242_24EVar = heff_take_reuse_n(v_h1_242, 1ULL, 1);
      switch (heff_tag_of(v_args_241)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24h_240_24At, 2);
        heff_drop(v_f_244);
        heff_drop_cell(v_ru_24h1_242_24EVar, 1);
        return v_args_241;
      }
      case TAG_Cons: {
        V v_args1_245 = heff_dup(heff_field(v_args_241, 0));
        V v_args2_246 = heff_dup(heff_field(v_args_241, 1));
        switch (heff_tag_of(v_args1_245)) {
        case TAG_At: {
          V v_args11_247 = heff_field(v_args1_245, 0);
          V v_dsp_248 = heff_field(v_args1_245, 1);
          V v_ru_24args1_245_24At = heff_take_reuse_n(v_args1_245, 3ULL, 2);
          switch (heff_tag_of(v_args11_247)) {
          case TAG_EVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENotationVar: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETag: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInt: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFloat: {
            heff_take_nf(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EString: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBinary: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ERune: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWord: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EApp: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EProject: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENamed: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EPi: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELam: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAnn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESpec: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESig: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESum: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EStruct: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EUpdate: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EMatch: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELetIn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EDo: {
            V v_ss_2445 = heff_field(v_args11_247, 0);
            V v_ru_24args11_247_24EDo = heff_take_reuse_n(v_args11_247, 1ULL, 1);
            switch (heff_tag_of(v_args2_246)) {
            case TAG_Nil: {
              heff_drop_tag(v_args_241, 2);
              if (heff_strEq_c(v_f_244, ((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str0))) {
                V v_sp_2446 = heff_dup(v_dsp_248);
                V v_stmts_2447 = v_ss_2445;
                V v_x1_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_2447)));
                V v_x2_2467;
                switch (heff_tag_of(v_x1_2448)) {
                case TAG_Nil: {
                  heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                  heff_drop(v_sp_2446);
                  heff_drop(v_stmts_2447);
                  v_x2_2467 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2449 = heff_field(v_x1_2448, 0);
                  heff_take_n(v_x1_2448, 1ULL, 2);
                  switch (heff_tag_of(v_x_2449)) {
                  case TAG_At: {
                    V v_it11_2451 = heff_field(v_x_2449, 0);
                    heff_take_n(v_x_2449, 1ULL, 2);
                    switch (heff_tag_of(v_it11_2451)) {
                    case TAG_StmtBind: {
                      heff_take_n(v_it11_2451, 0ULL, 3);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_StmtLet: {
                      heff_take_n(v_it11_2451, 0ULL, 2);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_StmtExpr: {
                      heff_take_n(v_it11_2451, 0ULL, 1);
                      V v_t_2459 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eidNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_sp_2446, MK_INT(0LL), NTAG(TAG_Nothing)});
                      V v_t_2460 = ({ V a_0 = v_t_2459; V a_1 = v_stmts_2447; V a_2 = NTAG(TAG_EndValue); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_stmts_2447); r_; });
                      v_x2_2467 = heff_tag_at_n(v_ru_24h1_242_24EVar, TAG_Just, 1, (V[]){v_t_2460});
                      break;
                    }
                    case TAG_StmtLetMut: {
                      heff_take_n(v_it11_2451, 0ULL, 3);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_StmtLetElse: {
                      heff_take_n(v_it11_2451, 0ULL, 3);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_it11_2451);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x_2449);
                  }
                  break;
                }
                default: heff_nomatch(v_x1_2448);
                }
                V v_t_2469;
                switch (heff_tag_of(v_x2_2467)) {
                case TAG_Nothing: {
                  v_t_2469 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24args11_247_24EDo, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str1)}), v_dsp_248});
                  break;
                }
                case TAG_Just: {
                  V v_x_2468 = heff_field(v_x2_2467, 0);
                  heff_take_n(v_x2_2467, 1ULL, 1);
                  heff_drop_cell(v_ru_24h_240_24At, 2);
                  heff_drop(v_dsp_248);
                  heff_drop_cell(v_ru_24args11_247_24EDo, 1);
                  v_t_2469 = v_x_2468;
                  break;
                }
                default: heff_nomatch(v_x2_2467);
                }
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
              } else {
                heff_drop_cell(v_ru_24args11_247_24EDo, 1);
                V v_t_2470 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_242_24EVar, TAG_EDo, 1, (V[]){v_ss_2445}), v_dsp_248});
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
              }
            }
            case TAG_Cons: {
              heff_take_n(v_args2_246, 0ULL, 2);
              heff_drop_cell(v_ru_24h_240_24At, 2);
              heff_drop(v_f_244);
              heff_drop_cell(v_ru_24h1_242_24EVar, 1);
              heff_drop(v_dsp_248);
              heff_drop_cell(v_ru_24args1_245_24At, 2);
              heff_drop(v_ss_2445);
              heff_drop_cell(v_ru_24args11_247_24EDo, 1);
              return v_args_241;
            }
            default: return heff_nomatch(v_args2_246);
            }
          }
          case TAG_ELocal: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInvalid: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAssign: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWhile: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFor: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EIfThen: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBreak: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EContinue: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EReturn: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENest: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELazy: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETuple: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETry: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWith: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          default: return heff_nomatch(v_args11_247);
          }
        }
        default: return heff_nomatch(v_args1_245);
        }
      }
      default: return heff_nomatch(v_args_241);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENotationVar: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETag: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInt: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFloat: {
      heff_take_nf(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EString: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBinary: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ERune: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWord: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EApp: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EProject: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENamed: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EPi: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELam: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAnn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESig: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESum: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EStruct: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EUpdate: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELetIn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EDo: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELocal: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInvalid: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAssign: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWhile: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFor: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EIfThen: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EReturn: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENest: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELazy: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETuple: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETry: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWith: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    default: return heff_nomatch(v_h1_242);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2erunArgs(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eargOf_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eargOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_dup(heff_field(v_x2_241, 0));
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EProject: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_sp_246 = heff_field(v_x2_241, 1);
        V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 2ULL, 2);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_244}), v_sp_246});
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_ENamed: {
      V v_x_247 = heff_field(v_x21_242, 0);
      V v_x212_248 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_sp_2410 = heff_field(v_x2_241, 1);
        V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 2ULL, 2);
        switch (heff_tag_of(v_x212_248)) {
        case TAG_At: {
          V v_x2121_2411 = heff_dup(heff_field(v_x212_248, 0));
          switch (heff_tag_of(v_x2121_2411)) {
          case TAG_EVar: {
            V v_x21211_2413 = heff_field(v_x2121_2411, 0);
            V v_ru_24x2121_2411_24EVar = heff_take_reuse_n(v_x2121_2411, 1ULL, 1);
            if (heff_strEq_c(v_x21211_2413, ((V)&g_heff_2esyntax_2epresyntax_2eargOf_str0))) {
              heff_drop_rec(v_r_240, 2);
              heff_drop_tag(v_x212_248, 2);
              heff_drop_cell(v_ru_24x2_241_24At, 2);
              return heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2121_2411_24EVar, TAG_ArgEvidence, 1, (V[]){v_x_247}), v_sp_2410});
            } else {
              V v_x1_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_248}));
              V v_t_2424;
              switch (heff_tag_of(v_x1_2414)) {
              case TAG_IsInferable: {
                V v_i_2415 = heff_field(v_x1_2414, 0);
                heff_take_n(v_x1_2414, 1ULL, 1);
                V v_t_2418;
                switch (heff_tag_of(v_i_2415)) {
                case TAG_At: {
                  V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
                  v_t_2418 = v_s_2417;
                  break;
                }
                default: heff_nomatch(v_i_2415);
                }
                v_t_2424 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2121_2411_24EVar, TAG_CInf, 1, (V[]){v_i_2415}), v_t_2418});
                break;
              }
              case TAG_IsCheckable: {
                V v_c_2419 = heff_field(v_x1_2414, 0);
                heff_take_n(v_x1_2414, 1ULL, 1);
                heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
                heff_drop_cell(v_ru_24x2121_2411_24EVar, 1);
                v_t_2424 = v_c_2419;
                break;
              }
              case TAG_IsType: {
                V v_t_2420 = heff_field(v_x1_2414, 0);
                heff_take_n(v_x1_2414, 1ULL, 1);
                V v_t_2423;
                switch (heff_tag_of(v_t_2420)) {
                case TAG_At: {
                  V v_s_2422 = heff_dup(heff_field(v_t_2420, 1));
                  v_t_2423 = v_s_2422;
                  break;
                }
                default: heff_nomatch(v_t_2420);
                }
                v_t_2424 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2121_2411_24EVar, TAG_CType, 1, (V[]){v_t_2420}), v_t_2423});
                break;
              }
              default: heff_nomatch(v_x1_2414);
              }
              return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_247, v_t_2424}), v_sp_2410});
            }
          }
          default: {
            heff_drop(v_x2121_2411);
            V v_x1_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x212_248}));
            V v_t_2435;
            switch (heff_tag_of(v_x1_2425)) {
            case TAG_IsInferable: {
              V v_i_2426 = heff_field(v_x1_2425, 0);
              V v_ru_24x1_2425_24IsInferable = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
              V v_t_2429;
              switch (heff_tag_of(v_i_2426)) {
              case TAG_At: {
                V v_s_2428 = heff_dup(heff_field(v_i_2426, 1));
                v_t_2429 = v_s_2428;
                break;
              }
              default: heff_nomatch(v_i_2426);
              }
              v_t_2435 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsInferable, TAG_CInf, 1, (V[]){v_i_2426}), v_t_2429});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2430 = heff_field(v_x1_2425, 0);
              heff_take_n(v_x1_2425, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_242_24ENamed, 2);
              v_t_2435 = v_c_2430;
              break;
            }
            case TAG_IsType: {
              V v_t_2431 = heff_field(v_x1_2425, 0);
              V v_ru_24x1_2425_24IsType = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
              V v_t_2434;
              switch (heff_tag_of(v_t_2431)) {
              case TAG_At: {
                V v_s_2433 = heff_dup(heff_field(v_t_2431, 1));
                v_t_2434 = v_s_2433;
                break;
              }
              default: heff_nomatch(v_t_2431);
              }
              v_t_2435 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsType, TAG_CType, 1, (V[]){v_t_2431}), v_t_2434});
              break;
            }
            default: heff_nomatch(v_x1_2425);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_247, v_t_2435}), v_sp_2410});
          }
          }
        }
        default: return heff_nomatch(v_x212_248);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    default: {
      heff_drop(v_x21_242);
      V v_x1_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_x2_241)}));
      V v_t_2446;
      switch (heff_tag_of(v_x1_2436)) {
      case TAG_IsInferable: {
        V v_i_2437 = heff_field(v_x1_2436, 0);
        V v_ru_24x1_2436_24IsInferable = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
        V v_t_2440;
        switch (heff_tag_of(v_i_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_i_2437);
        }
        v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2436_24IsInferable, TAG_CInf, 1, (V[]){v_i_2437}), v_t_2440});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2441 = heff_field(v_x1_2436, 0);
        heff_take_n(v_x1_2436, 1ULL, 1);
        v_t_2446 = v_c_2441;
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2436, 0);
        V v_ru_24x1_2436_24IsType = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
        V v_t_2445;
        switch (heff_tag_of(v_t_2442)) {
        case TAG_At: {
          V v_s_2444 = heff_dup(heff_field(v_t_2442, 1));
          v_t_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_t_2442);
        }
        v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2436_24IsType, TAG_CType, 1, (V[]){v_t_2442}), v_t_2445});
        break;
      }
      default: heff_nomatch(v_x1_2436);
      }
      V v_t_2449;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_s_2448 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 2ULL, 2);
        v_t_2449 = v_s_2448;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2446}), v_t_2449});
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf(a[0], a[1]);
}

HeffT3 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IsInferable: {
    V v_b_245 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b_245}), v_sp_244});
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_246, MK_INT(0LL)}});
  }
  case TAG_IsCheckable: {
    V v_t_2417;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_248 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2412 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2417 = v_c_2412;
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2418 = heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2417});
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2418, v_sp_244}});
  }
  case TAG_IsType: {
    V v_t_2429;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_2420 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2423;
      switch (heff_tag_of(v_i_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_i_2420);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2424 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2429 = v_c_2424;
      break;
    }
    case TAG_IsType: {
      V v_t_2425 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2430 = heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2429});
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2430, v_sp_244}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x4_243)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str3, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_size_243 = heff_field(v_x1_240, 2);
    V v_little_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_EVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EImplicitVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENotationVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        V v_v_2414 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          V v_x1_2415 = heff_dup(v_size_243);
          V v_little_2416 = heff_dup(v_little_244);
          V v_v_2417 = heff_dup(v_v_2414);
          switch (heff_tag_of(v_x1_2415)) {
          case TAG_SizeDefault: {
            V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
            V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
            V v_t_2420 = heff_intAdd(heff_intMod(v_v_2417, v_t_2418), v_t_2419);
            V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
            V v_b_2422 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_box_word((((int64_t)8ULL) / ((int64_t)8ULL))), heff_intMod(v_t_2420, v_t_2421), ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str0)));
            V v_f_2423;
            if ((heff_dup(v_little_2416) == NTAG(TAG_True))) {
              heff_drop(v_little_2416);
              v_f_2423 = ({ V a_0 = v_b_2422; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str1); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2422); r_; });
            } else {
              heff_drop(v_little_2416);
              v_f_2423 = v_b_2422;
            }
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
          }
          case TAG_SizeNumber: {
            V v_n_2424 = heff_field(v_x1_2415, 0);
            heff_take_n(v_x1_2415, 1ULL, 1);
            if ((heff_unbox_word(heff_intMod(heff_dup(v_n_2424), MK_INT(8LL))) == ((int64_t)0ULL))) {
              V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_2424)));
              V v_t_2426 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_2424)));
              V v_t_2427 = heff_intAdd(heff_intMod(v_v_2417, v_t_2425), v_t_2426);
              V v_t_2428 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_2424)));
              V v_b_2429 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(v_n_2424, MK_INT(8LL)), heff_intMod(v_t_2427, v_t_2428), ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str2)));
              V v_f_2430;
              if ((heff_dup(v_little_2416) == NTAG(TAG_True))) {
                heff_drop(v_little_2416);
                v_f_2430 = ({ V a_0 = v_b_2429; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str3); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2429); r_; });
              } else {
                heff_drop(v_little_2416);
                v_f_2430 = v_b_2429;
              }
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
            } else {
              heff_drop(v_little_2416);
              heff_drop(v_v_2417);
              heff_drop(v_n_2424);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_SizeName: {
            heff_take_n(v_x1_2415, 0ULL, 3);
            heff_drop(v_little_2416);
            heff_drop(v_v_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2415)}});
          }
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2434 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2434, MK_INT(8LL), 2)) {
            V v_f_2435 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_v_2414)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2435}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EFloat: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EString: {
        V v_s_2437 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_size_243)) {
          case TAG_SizeDefault: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_s_2437)}});
          }
          case TAG_SizeNumber: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SizeName: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_size_243)}});
          }
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EBinary: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERune: {
        V v_c_2444 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2445 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2445, MK_INT(8LL), 2)) {
            V v_f_2446 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_c_2444)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EWord: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProject: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENamed: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPi: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAnn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESpec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESig: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESum: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStruct: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EUpdate: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetIn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EDo: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELocal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInvalid: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAssign: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWhile: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFor: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EIfThen: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBreak: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EContinue: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EReturn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENest: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELazy: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETuple: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETry: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWith: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esizeTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esizeTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2esizeTerm(V v_x1_240, V v_x2_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x2_241}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_243}), v_sp_242});
  }
  case TAG_SizeNumber: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_x2_241);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){v_m_244}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), v_sp_242});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    heff_drop(v_x2_241);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(1LL), 2)) {
      heff_drop(v_sp_242);
      heff_drop(v_x13_248);
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), v_xsp_247});
    } else {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esizeTerm_str0)}), heff_dup(v_sp_242)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2412}), heff_dup(v_sp_242)});
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x13_248}), heff_dup(v_sp_242)});
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), heff_dup(v_sp_242)});
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), heff_dup(v_sp_242)});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      V v_t_2418 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_242)})});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_242});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esizeTerm(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesTerm_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ebytesTerm(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_242}), v_sp_241});
  }
  case TAG_SizeNumber: {
    V v_n_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){heff_intDiv(v_n_243, MK_INT(8LL))});
    V v_t_245 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(8LL), 2)) {
      heff_drop(v_sp_241);
      heff_drop(v_x13_248);
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), v_xsp_247});
    } else {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesTerm_str0)}), heff_dup(v_sp_241)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2412}), heff_dup(v_sp_241)});
      V v_t_2414 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intDiv(v_x13_248, MK_INT(8LL))});
      V v_t_2415 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_241)})});
      V v_t_2416 = heff_tag_n(TAG_ArgExplicit, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_241)})});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
      V v_t_2418 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_241)})});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_241});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesTerm(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclEquations = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2419;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_IsInferable: {
        V v_i_2410 = heff_field(v_x1_249, 0);
        V v_ru_24x1_249_24IsInferable = heff_take_reuse_n(v_x1_249, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_i_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_i_2410);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_249_24IsInferable, TAG_TInf, 1, (V[]){v_i_2410}), v_t_2413});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2414 = heff_field(v_x1_249, 0);
        V v_ru_24x1_249_24IsCheckable = heff_take_reuse_n(v_x1_249, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_c_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_c_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_c_2414);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_249_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2414}), v_t_2417});
        break;
      }
      case TAG_IsType: {
        V v_t_2418 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2419 = v_t_2418;
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2420 = (g_list_2emap_24s1036840854x702708481(v_r_240, v_eqs_248));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_2419, v_t_2420}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_x21_242, 0);
      V v_xsp_2422 = heff_field(v_x21_242, 1);
      V v_ps_2423 = heff_field(v_x21_242, 2);
      V v_u_2424 = heff_field(v_x21_242, 3);
      V v_body_2425 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclDefine = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_t_2426 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2423));
      V v_x1_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2424}));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_IsInferable: {
        V v_i_2428 = heff_field(v_x1_2427, 0);
        V v_ru_24x1_2427_24IsInferable = heff_take_reuse_n(v_x1_2427, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_i_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_i_2428);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2427_24IsInferable, TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2432 = heff_field(v_x1_2427, 0);
        V v_ru_24x1_2427_24IsCheckable = heff_take_reuse_n(v_x1_2427, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_c_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_c_2432);
        }
        v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2427_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
        break;
      }
      case TAG_IsType: {
        V v_t_2436 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2437 = v_t_2436;
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
      V v_x1_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2425}));
      V v_t_2448;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_IsInferable: {
        V v_i_2439 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsInferable = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_i_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_i_2439);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsInferable, TAG_CInf, 1, (V[]){v_i_2439}), v_t_2442});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2443 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2448 = v_c_2443;
        break;
      }
      case TAG_IsType: {
        V v_t_2444 = heff_field(v_x1_2438, 0);
        V v_ru_24x1_2438_24IsType = heff_take_reuse_n(v_x1_2438, 1ULL, 1);
        V v_t_2447;
        switch (heff_tag_of(v_t_2444)) {
        case TAG_At: {
          V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
          v_t_2447 = v_s_2446;
          break;
        }
        default: heff_nomatch(v_t_2444);
        }
        v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2438_24IsType, TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2421, v_xsp_2422, v_t_2426, v_t_2437, v_t_2448}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2449 = heff_field(v_x21_242, 0);
      V v_xsp_2450 = heff_field(v_x21_242, 1);
      V v_ps_2451 = heff_field(v_x21_242, 2);
      V v_body_2452 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclTheory = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_2453 = (g_list_2emap_24s1157931537x649184066(heff_dup(v_r_240), v_ps_2451));
      V v_x1_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2452}));
      V v_t_2464;
      switch (heff_tag_of(v_x1_2454)) {
      case TAG_IsInferable: {
        V v_i_2455 = heff_field(v_x1_2454, 0);
        V v_ru_24x1_2454_24IsInferable = heff_take_reuse_n(v_x1_2454, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_i_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_i_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_i_2455);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2454_24IsInferable, TAG_CInf, 1, (V[]){v_i_2455}), v_t_2458});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2459 = heff_field(v_x1_2454, 0);
        heff_take_n(v_x1_2454, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2464 = v_c_2459;
        break;
      }
      case TAG_IsType: {
        V v_t_2460 = heff_field(v_x1_2454, 0);
        V v_ru_24x1_2454_24IsType = heff_take_reuse_n(v_x1_2454, 1ULL, 1);
        V v_t_2463;
        switch (heff_tag_of(v_t_2460)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_t_2460);
        }
        v_t_2464 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2454_24IsType, TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
        break;
      }
      default: heff_nomatch(v_x1_2454);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2449, v_xsp_2450, v_t_2453, v_t_2464}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2465 = heff_field(v_x21_242, 0);
      V v_xsp_2466 = heff_field(v_x21_242, 1);
      V v_t_2467 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24DeclPrimitive = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2467}));
      V v_t_2478;
      switch (heff_tag_of(v_x1_2468)) {
      case TAG_IsInferable: {
        V v_i_2469 = heff_field(v_x1_2468, 0);
        V v_ru_24x1_2468_24IsInferable = heff_take_reuse_n(v_x1_2468, 1ULL, 1);
        V v_t_2472;
        switch (heff_tag_of(v_i_2469)) {
        case TAG_At: {
          V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_i_2469);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2468_24IsInferable, TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2473 = heff_field(v_x1_2468, 0);
        V v_ru_24x1_2468_24IsCheckable = heff_take_reuse_n(v_x1_2468, 1ULL, 1);
        V v_t_2476;
        switch (heff_tag_of(v_c_2473)) {
        case TAG_At: {
          V v_s_2475 = heff_dup(heff_field(v_c_2473, 1));
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_c_2473);
        }
        v_t_2478 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2468_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2473}), v_t_2476});
        break;
      }
      case TAG_IsType: {
        V v_t_2477 = heff_field(v_x1_2468, 0);
        heff_take_n(v_x1_2468, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2478 = v_t_2477;
        break;
      }
      default: heff_nomatch(v_x1_2468);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2465, v_xsp_2466, v_t_2478}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2479 = heff_field(v_x21_242, 0);
      V v_xsp_2480 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24DeclTest = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      heff_drop_rec(v_r_240, 2);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2479, v_xsp_2480}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2481 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24DeclWatch = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2481}));
      V v_t_2483 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2482));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2483}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT3 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2426;
        {
          V v_field_2415 = v_t_2413.f[1];
          V v_field_2416 = v_t_2413.f[2];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = heff_tag_n(TAG_At, 2, (V[]){v_field_2415, v_field_2416});
            v_t_2426 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              heff_drop(v_field_2416);
              V v_i_2418 = v_field_2415;
              V v_t_2421;
              switch (heff_tag_of(v_i_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_i_2418);
              }
              v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2418}), v_t_2421});
            } else {
              V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){v_field_2415, v_field_2416});
              V v_t_2425;
              switch (heff_tag_of(v_t_2422)) {
              case TAG_At: {
                V v_s_2424 = heff_dup(heff_field(v_t_2422, 1));
                v_t_2425 = v_s_2424;
                break;
              }
              default: heff_nomatch(v_t_2422);
              }
              v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2422}), v_t_2425});
            }
          }
        }
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2427});
        V v_args_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2428});
        V v_t_2430 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2429));
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str0)}), heff_dup(v_sp_242)});
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, v_t_2430}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2432}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT3 v_t_2433 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2435 = v_t_2433.f[1];
            V v_field_2436 = v_t_2433.f[2];
            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
            if ((v_tag_2434 == ((int64_t)0ULL))) {
              V v_c_2437 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2435, v_field_2436});
              return v_c_2437;
            } else {
              if ((v_tag_2434 == ((int64_t)1ULL))) {
                heff_drop(v_field_2436);
                V v_i_2438 = v_field_2435;
                V v_t_2441;
                switch (heff_tag_of(v_i_2438)) {
                case TAG_At: {
                  V v_s_2440 = heff_dup(heff_field(v_i_2438, 1));
                  v_t_2441 = v_s_2440;
                  break;
                }
                default: heff_nomatch(v_i_2438);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2438}), v_t_2441});
              } else {
                V v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2435, v_field_2436});
                V v_t_2445;
                switch (heff_tag_of(v_t_2442)) {
                case TAG_At: {
                  V v_s_2444 = heff_dup(heff_field(v_t_2442, 1));
                  v_t_2445 = v_s_2444;
                  break;
                }
                default: heff_nomatch(v_t_2442);
                }
                return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2442}), v_t_2445});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2447 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT3 v_t_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2461;
          {
            V v_field_2450 = v_t_2448.f[1];
            V v_field_2451 = v_t_2448.f[2];
            int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
            if ((v_tag_2449 == ((int64_t)0ULL))) {
              V v_c_2452 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2450, v_field_2451});
              v_t_2461 = v_c_2452;
            } else {
              if ((v_tag_2449 == ((int64_t)1ULL))) {
                heff_drop(v_field_2451);
                V v_i_2453 = v_field_2450;
                V v_t_2456;
                switch (heff_tag_of(v_i_2453)) {
                case TAG_At: {
                  V v_s_2455 = heff_dup(heff_field(v_i_2453, 1));
                  v_t_2456 = v_s_2455;
                  break;
                }
                default: heff_nomatch(v_i_2453);
                }
                v_t_2461 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2453}), v_t_2456});
              } else {
                V v_t_2457 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2450, v_field_2451});
                V v_t_2460;
                switch (heff_tag_of(v_t_2457)) {
                case TAG_At: {
                  V v_s_2459 = heff_dup(heff_field(v_t_2457, 1));
                  v_t_2460 = v_s_2459;
                  break;
                }
                default: heff_nomatch(v_t_2457);
                }
                v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2457}), v_t_2460});
              }
            }
          }
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
          V v_args_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2462});
          V v_t_2464 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2463));
          V v_t_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str1)}), heff_dup(v_sp_242)});
          V v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2465, v_t_2464}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2466}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2470 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT3 v_t_2471 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2484;
          {
            V v_field_2473 = v_t_2471.f[1];
            V v_field_2474 = v_t_2471.f[2];
            int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
            if ((v_tag_2472 == ((int64_t)0ULL))) {
              V v_c_2475 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2473, v_field_2474});
              v_t_2484 = v_c_2475;
            } else {
              if ((v_tag_2472 == ((int64_t)1ULL))) {
                heff_drop(v_field_2474);
                V v_i_2476 = v_field_2473;
                V v_t_2479;
                switch (heff_tag_of(v_i_2476)) {
                case TAG_At: {
                  V v_s_2478 = heff_dup(heff_field(v_i_2476, 1));
                  v_t_2479 = v_s_2478;
                  break;
                }
                default: heff_nomatch(v_i_2476);
                }
                v_t_2484 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2476}), v_t_2479});
              } else {
                V v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2473, v_field_2474});
                V v_t_2483;
                switch (heff_tag_of(v_t_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_t_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_t_2480);
                }
                v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2480}), v_t_2483});
              }
            }
          }
          V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
          V v_args_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, v_t_2485});
          V v_t_2487 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2486));
          V v_t_2488 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str2)}), heff_dup(v_sp_242)});
          V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2488, v_t_2487}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2489}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT3 v_t_2490 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24103;
        {
          V v_field_2492 = v_t_2490.f[1];
          V v_field_2493 = v_t_2490.f[2];
          int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
          if ((v_tag_2491 == ((int64_t)0ULL))) {
            V v_c_2494 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2492, v_field_2493});
            v_t_24103 = v_c_2494;
          } else {
            if ((v_tag_2491 == ((int64_t)1ULL))) {
              heff_drop(v_field_2493);
              V v_i_2495 = v_field_2492;
              V v_t_2498;
              switch (heff_tag_of(v_i_2495)) {
              case TAG_At: {
                V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
                v_t_2498 = v_s_2497;
                break;
              }
              default: heff_nomatch(v_i_2495);
              }
              v_t_24103 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
            } else {
              V v_t_2499 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2492, v_field_2493});
              V v_t_24102;
              switch (heff_tag_of(v_t_2499)) {
              case TAG_At: {
                V v_s_24101 = heff_dup(heff_field(v_t_2499, 1));
                v_t_24102 = v_s_24101;
                break;
              }
              default: heff_nomatch(v_t_2499);
              }
              v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2499}), v_t_24102});
            }
          }
        }
        V v_args_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
        V v_t_24105 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24104));
        V v_t_24106 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str3)}), heff_dup(v_sp_242)});
        V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24106, v_t_24105}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24107}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24108 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24109;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24109 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24109 = ((int64_t)0ULL);
        }
        V v_t_24110 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24109 + ((int64_t)0ULL)))});
        V v_t_24111 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24110, heff_dup(v_sp_242)})});
        V v_t_24112 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT3 v_t_24113 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24126;
        {
          V v_field_24115 = v_t_24113.f[1];
          V v_field_24116 = v_t_24113.f[2];
          int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
          if ((v_tag_24114 == ((int64_t)0ULL))) {
            V v_c_24117 = heff_tag_n(TAG_At, 2, (V[]){v_field_24115, v_field_24116});
            v_t_24126 = v_c_24117;
          } else {
            if ((v_tag_24114 == ((int64_t)1ULL))) {
              heff_drop(v_field_24116);
              V v_i_24118 = v_field_24115;
              V v_t_24121;
              switch (heff_tag_of(v_i_24118)) {
              case TAG_At: {
                V v_s_24120 = heff_dup(heff_field(v_i_24118, 1));
                v_t_24121 = v_s_24120;
                break;
              }
              default: heff_nomatch(v_i_24118);
              }
              v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24118}), v_t_24121});
            } else {
              V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){v_field_24115, v_field_24116});
              V v_t_24125;
              switch (heff_tag_of(v_t_24122)) {
              case TAG_At: {
                V v_s_24124 = heff_dup(heff_field(v_t_24122, 1));
                v_t_24125 = v_s_24124;
                break;
              }
              default: heff_nomatch(v_t_24122);
              }
              v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24122}), v_t_24125});
            }
          }
        }
        V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
        V v_args_24128 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24112, v_t_24127});
        V v_t_24129 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24128));
        V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str4)}), heff_dup(v_sp_242)});
        V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24130, v_t_24129}), heff_dup(v_sp_242)});
        V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24131}), heff_dup(v_sp_242)});
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
        V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24111, heff_dup(v_sp_242)}), v_t_24133});
        V v_args_24135 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, v_t_24134});
        V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24135));
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str5)}), heff_dup(v_sp_242)});
        V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24136}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24138}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24139 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24139, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24139);
          V v_t_24140 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24140, NTAG(TAG_Nil)});
          V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
          V v_t_24143 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str6)}), heff_dup(v_sp_242)});
          V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24139, MK_INT(16LL))) {
            int64_t v_t_24145;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24145 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24145 = ((int64_t)0ULL);
            }
            V v_t_24146 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24145 + ((int64_t)0ULL)))});
            V v_t_24147 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24146, heff_dup(v_sp_242)})});
            V v_t_24148 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24149 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
            V v_args_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24147, heff_dup(v_sp_242)}), v_t_24149});
            V v_t_24151 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24150));
            V v_t_24152 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str7)}), heff_dup(v_sp_242)});
            V v_t_24153 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24152, v_t_24151}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24153}), v_sp_242});
          } else {
            int64_t v_t_24154;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24154 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24154 = ((int64_t)0ULL);
            }
            V v_t_24155 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24154 + ((int64_t)0ULL)))});
            V v_t_24156 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24155, heff_dup(v_sp_242)})});
            V v_t_24157 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24157, NTAG(TAG_Nil)});
            V v_args_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24156, heff_dup(v_sp_242)}), v_t_24158});
            V v_t_24160 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24159));
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_str8)}), heff_dup(v_sp_242)});
            V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24161, v_t_24160}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24162}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_dup(heff_field(v_x2_240, 0));
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EProject: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EProject = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_sp_245 = heff_field(v_x2_240, 1);
        V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 2ULL, 2);
        return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EProject, TAG_ArgProject, 1, (V[]){v_x_243}), v_sp_245});
      }
      default: return heff_nomatch(v_x2_240);
      }
    }
    case TAG_ENamed: {
      V v_x_246 = heff_field(v_x21_241, 0);
      V v_x212_247 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ENamed = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_sp_249 = heff_field(v_x2_240, 1);
        V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 2ULL, 2);
        switch (heff_tag_of(v_x212_247)) {
        case TAG_At: {
          V v_x2121_2410 = heff_dup(heff_field(v_x212_247, 0));
          switch (heff_tag_of(v_x2121_2410)) {
          case TAG_EVar: {
            V v_x21211_2412 = heff_field(v_x2121_2410, 0);
            V v_ru_24x2121_2410_24EVar = heff_take_reuse_n(v_x2121_2410, 1ULL, 1);
            if (heff_strEq_c(v_x21211_2412, ((V)&g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_str0))) {
              heff_drop_tag(v_x212_247, 2);
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              return heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2121_2410_24EVar, TAG_ArgEvidence, 1, (V[]){v_x_246}), v_sp_249});
            } else {
              HeffT3 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x212_247));
              V v_t_2426;
              {
                V v_field_2415 = v_t_2413.f[1];
                V v_field_2416 = v_t_2413.f[2];
                int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  heff_drop_cell(v_ru_24x2_240_24At, 2);
                  heff_drop_cell(v_ru_24x2121_2410_24EVar, 1);
                  V v_c_2417 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){v_field_2415, v_field_2416});
                  v_t_2426 = v_c_2417;
                } else {
                  if ((v_tag_2414 == ((int64_t)1ULL))) {
                    heff_drop_cell(v_ru_24x2_240_24At, 2);
                    heff_drop(v_field_2416);
                    V v_i_2418 = v_field_2415;
                    V v_t_2421;
                    switch (heff_tag_of(v_i_2418)) {
                    case TAG_At: {
                      V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
                      v_t_2421 = v_s_2420;
                      break;
                    }
                    default: heff_nomatch(v_i_2418);
                    }
                    v_t_2426 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2121_2410_24EVar, TAG_CInf, 1, (V[]){v_i_2418}), v_t_2421});
                  } else {
                    V v_t_2422 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){v_field_2415, v_field_2416});
                    V v_t_2425;
                    switch (heff_tag_of(v_t_2422)) {
                    case TAG_At: {
                      V v_s_2424 = heff_dup(heff_field(v_t_2422, 1));
                      v_t_2425 = v_s_2424;
                      break;
                    }
                    default: heff_nomatch(v_t_2422);
                    }
                    v_t_2426 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2121_2410_24EVar, TAG_CType, 1, (V[]){v_t_2422}), v_t_2425});
                  }
                }
              }
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_246, v_t_2426}), v_sp_249});
            }
          }
          default: {
            heff_drop(v_x2121_2410);
            HeffT3 v_t_2427 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x212_247));
            V v_t_2440;
            {
              V v_field_2429 = v_t_2427.f[1];
              V v_field_2430 = v_t_2427.f[2];
              int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
              if ((v_tag_2428 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24At, 2);
                V v_c_2431 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){v_field_2429, v_field_2430});
                v_t_2440 = v_c_2431;
              } else {
                if ((v_tag_2428 == ((int64_t)1ULL))) {
                  heff_drop_cell(v_ru_24x2_240_24At, 2);
                  heff_drop(v_field_2430);
                  V v_i_2432 = v_field_2429;
                  V v_t_2435;
                  switch (heff_tag_of(v_i_2432)) {
                  case TAG_At: {
                    V v_s_2434 = heff_dup(heff_field(v_i_2432, 1));
                    v_t_2435 = v_s_2434;
                    break;
                  }
                  default: heff_nomatch(v_i_2432);
                  }
                  v_t_2440 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2432}), v_t_2435});
                } else {
                  V v_t_2436 = heff_tag_at_n(v_ru_24x21_241_24ENamed, TAG_At, 2, (V[]){v_field_2429, v_field_2430});
                  V v_t_2439;
                  switch (heff_tag_of(v_t_2436)) {
                  case TAG_At: {
                    V v_s_2438 = heff_dup(heff_field(v_t_2436, 1));
                    v_t_2439 = v_s_2438;
                    break;
                  }
                  default: heff_nomatch(v_t_2436);
                  }
                  v_t_2440 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2436}), v_t_2439});
                }
              }
            }
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_246, v_t_2440}), v_sp_249});
          }
          }
        }
        default: return heff_nomatch(v_x212_247);
        }
      }
      default: return heff_nomatch(v_x2_240);
      }
    }
    default: {
      heff_drop(v_x21_241);
      HeffT3 v_t_2441 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_dup(v_x2_240)));
      V v_t_2454;
      {
        V v_field_2443 = v_t_2441.f[1];
        V v_field_2444 = v_t_2441.f[2];
        int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
        if ((v_tag_2442 == ((int64_t)0ULL))) {
          V v_c_2445 = heff_tag_n(TAG_At, 2, (V[]){v_field_2443, v_field_2444});
          v_t_2454 = v_c_2445;
        } else {
          if ((v_tag_2442 == ((int64_t)1ULL))) {
            heff_drop(v_field_2444);
            V v_i_2446 = v_field_2443;
            V v_t_2449;
            switch (heff_tag_of(v_i_2446)) {
            case TAG_At: {
              V v_s_2448 = heff_dup(heff_field(v_i_2446, 1));
              v_t_2449 = v_s_2448;
              break;
            }
            default: heff_nomatch(v_i_2446);
            }
            v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2446}), v_t_2449});
          } else {
            V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){v_field_2443, v_field_2444});
            V v_t_2453;
            switch (heff_tag_of(v_t_2450)) {
            case TAG_At: {
              V v_s_2452 = heff_dup(heff_field(v_t_2450, 1));
              v_t_2453 = v_s_2452;
              break;
            }
            default: heff_nomatch(v_t_2450);
            }
            v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2450}), v_t_2453});
          }
        }
      }
      V v_t_2457;
      switch (heff_tag_of(v_x2_240)) {
      case TAG_At: {
        V v_s_2456 = heff_field(v_x2_240, 1);
        heff_take_n(v_x2_240, 2ULL, 2);
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_x2_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2454}), v_t_2457});
    }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
      v_t_245 = heff_tag_at_n(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at_n(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      V v_ru_24t_246_24At = heff_take_reuse_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_246_24At, v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      V v_ru_24t_2426_24At = heff_take_reuse_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2426_24At, v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2438 = (g_list_2emap_24s79542405x478516404(v_args_2437));
    return heff_tag_at_n(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, v_t_2438});
  }
  case TAG_CStruct: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1729787689x465380098(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){v_t_2440});
  }
  case TAG_CMatch: {
    V v_sc_2441 = heff_field(v_n_240, 0);
    V v_alts_2442 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_sc_2441)) {
    case TAG_At: {
      V v_n_2443 = heff_field(v_sc_2441, 0);
      V v_sp_2444 = heff_field(v_sc_2441, 1);
      V v_ru_24sc_2441_24At = heff_take_reuse_n(v_sc_2441, 3ULL, 2);
      V v_t_2445 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2443));
      v_t_2446 = heff_tag_at_n(v_ru_24sc_2441_24At, TAG_At, 2, (V[]){v_t_2445, v_sp_2444});
      break;
    }
    default: heff_nomatch(v_sc_2441);
    }
    V v_t_2447 = (g_list_2emap_24s244350250x1728178626(v_alts_2442));
    return heff_tag_at_n(v_ru_24n_240_24CMatch, TAG_CMatch, 2, (V[]){v_t_2446, v_t_2447});
  }
  case TAG_CLetIn: {
    V v_rhs_2448 = heff_field(v_n_240, 0);
    V v_alt_2449 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2453;
    switch (heff_tag_of(v_rhs_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_rhs_2448, 0);
      V v_sp_2451 = heff_field(v_rhs_2448, 1);
      V v_ru_24rhs_2448_24At = heff_take_reuse_n(v_rhs_2448, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24rhs_2448_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_rhs_2448);
    }
    V v_t_2463;
    switch (heff_tag_of(v_alt_2449)) {
    case TAG_At: {
      V v_x_2454 = heff_field(v_alt_2449, 0);
      V v_sp_2455 = heff_field(v_alt_2449, 1);
      V v_ru_24alt_2449_24At = heff_take_reuse_n(v_alt_2449, 3ULL, 2);
      V v_t_2462;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_MkAlt: {
        V v_p_2456 = heff_field(v_x_2454, 0);
        V v_b_2457 = heff_field(v_x_2454, 1);
        V v_ru_24x_2454_24MkAlt = heff_take_reuse_n(v_x_2454, 3ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_b_2457)) {
        case TAG_At: {
          V v_n_2458 = heff_field(v_b_2457, 0);
          V v_sp_2459 = heff_field(v_b_2457, 1);
          heff_take_n(v_b_2457, 3ULL, 2);
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2458));
          v_t_2461 = heff_tag_at_n(v_ru_24alt_2449_24At, TAG_At, 2, (V[]){v_t_2460, v_sp_2459});
          break;
        }
        default: heff_nomatch(v_b_2457);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x_2454_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2456, v_t_2461});
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_alt_2449);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2453, v_t_2463});
  }
  case TAG_CLocal: {
    V v_body_2464 = heff_field(v_n_240, 0);
    V v_ds_2465 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_body_2464)) {
    case TAG_At: {
      V v_n_2466 = heff_field(v_body_2464, 0);
      V v_sp_2467 = heff_field(v_body_2464, 1);
      V v_ru_24body_2464_24At = heff_take_reuse_n(v_body_2464, 3ULL, 2);
      V v_t_2468 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2466));
      v_t_2469 = heff_tag_at_n(v_ru_24body_2464_24At, TAG_At, 2, (V[]){v_t_2468, v_sp_2467});
      break;
    }
    default: heff_nomatch(v_body_2464);
    }
    V v_t_2470 = (g_list_2emap_24s386875578x1005587669(v_ds_2465));
    return heff_tag_at_n(v_ru_24n_240_24CLocal, TAG_CLocal, 2, (V[]){v_t_2469, v_t_2470});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IAnn: {
    V v_c_242 = heff_field(v_n_241, 0);
    V v_t_243 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_c_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_c_242, 0);
      V v_sp_245 = heff_field(v_c_242, 1);
      heff_take_n(v_c_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_243, 0);
      V v_sp_248 = heff_field(v_t_243, 1);
      V v_ru_24t_243_24At = heff_take_reuse_n(v_t_243, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_243_24At, v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IAnn, TAG_IAnn, 2, (V[]){v_t_246, v_t_249}), v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2410 = heff_field(v_n_241, 0);
    V v_why_2411 = heff_field(v_n_241, 1);
    V v_note_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 7ULL, 3);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IInvalid, TAG_IInvalid, 3, (V[]){v_code_2410, v_why_2411, v_note_2412}), v_sp_240});
  }
  default: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2414 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(V v_tok_240, V v_x1_241, V v_sp_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_x1_241, v_sp_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_245, v_field_246})});
    } else {
      if ((v_tag_244 == ((int64_t)1ULL))) {
        heff_drop(v_field_246);
        return heff_tag_at_n(v_tok_240, TAG_IsInferable, 1, (V[]){v_field_245});
      } else {
        return heff_tag_at_n(v_tok_240, TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_245, v_field_246})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(a[0], a[1], a[2]);
}