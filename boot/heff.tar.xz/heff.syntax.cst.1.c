// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_Braces 8205
#define TAG_DPrimitive 59284
#define TAG_Do 8988
#define TAG_ECon 35052
#define TAG_EFSet 34673
#define TAG_EJump 55703
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_MkSep 6724
#define TAG_Named 2049
#define TAG_OpRhs 36076
#define TAG_PCon 35123
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_arm 306390
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blockArg 80527375
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_opExpr 935619233
#define LBL_patAtom 1586746071
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo;
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(V, V);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo;
V g_heff_2esyntax_2ecst_2econtinuesBlock(V, V);
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclNameLen(V, V, V);
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2eexprHead(V, V);
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eheadGram_get(void);
V g_heff_2esyntax_2ecst_2eifStmtAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2eifStmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifStmtAt_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2elamBinderF(V, V, V);
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinderF_clo;
V g_heff_2esyntax_2ecst_2elamBinders(V, V, V, V);
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinders_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011(V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo;
V g_heff_2esyntax_2ecst_2epatHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatHeadF_clo;
V g_heff_2esyntax_2ecst_2eprimitiveDecl(V, V, V);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprimitiveDecl_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_clo;
V g_heff_2esyntax_2ecst_2esegValueF_24s755176901x1919437034(V, V);
V g_heff_2esyntax_2ecst_2esegValueF_24s755176901x1919437034_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegValueF_24s755176901x1919437034_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s141384968x582145146(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s141384968x582145146_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s141384968x582145146_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s719949573x737501204(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s719949573x737501204_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s719949573x737501204_clo;
V g_heff_2esyntax_2ecst_2esigName(V, V);
V g_heff_2esyntax_2ecst_2esigName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigName_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2etryCaught(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2etryCaught_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryCaught_clo;
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943(V, V, V, V);
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str5, 7, "`, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str6, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str7, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str8, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str11, 7, "`, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str12, 10, "expected `");
V g_heff_2esyntax_2ecst_2eexpectKw_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectKw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectKw_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectKw(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectKw_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectKw(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectKw_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), heff_dup(v_x_240))) {
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_x_240);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
    } else {
      V v_t_2410;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str1))) {
        v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str2);
      } else {
        V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str3));
        v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str4), v_t_249);
      }
      V v_t_2411 = heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str5), v_t_2410));
      V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str6), v_t_2411), v_t_2412, NTAG(TAG_Nothing)});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
      V f_ = heff_get_n(v_hd_241, 1, 3);
      heff_room[0] = v_t_2415;
      heff_room[1] = v_k_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  } else {
    V v_t_2418;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str7))) {
      v_t_2418 = ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str8);
    } else {
      V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str9));
      v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str10), v_t_2417);
    }
    V v_t_2419 = heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str11), v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str12), v_t_2419), v_t_2420, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2econtinuesBlock_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2econtinuesBlock_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2econtinuesBlock_str2, 5, "where");
Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2econtinuesBlock_entry, 2, 0};

V g_heff_2esyntax_2ecst_2econtinuesBlock(V v_t_240, V v_col_241) {
top: ;
  V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2econtinuesBlock_str0)) ? 0 : ({ V v_t_243 = heff_dup(heff_rfield(v_t_240, 6)); int c_ = ((heff_dup(v_t_243) == NTAG(TAG_True)) && (heff_intEq_c(heff_dup(heff_rfield(v_t_240, 5)), heff_dup(v_col_241)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2econtinuesBlock_str1)) ? !heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2econtinuesBlock_str2)) : 1))); heff_drop(v_t_243); c_; })));
  heff_drop_rec(v_t_240, 9);
  heff_drop(v_col_241);
  return v_ret_24bool;
}
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2econtinuesBlock(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str11, 5, "break");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str12, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str13, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str14, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str15, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str16, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str17, 6, "return");
V g_heff_2esyntax_2ecst_2eexprHead_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_lam2(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprHead(V v_g_240, V v_t_241) {
top: ;
  V v_t_243 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str1))));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_241, 9);
    heff_drop(v_t_243);
    return heff_get_n(v_g_240, 8, 17);
  } else {
    heff_drop(v_t_243);
    V v_t_245 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str3))));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_241, 9);
      heff_drop(v_t_245);
      return heff_get_n(v_g_240, 9, 17);
    } else {
      heff_drop(v_t_245);
      V v_t_247 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str5))));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_241, 9);
        heff_drop(v_t_247);
        return heff_get_n(v_g_240, 10, 17);
      } else {
        heff_drop(v_t_247);
        V v_t_249 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str6)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str7))));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop_rec(v_t_241, 9);
          heff_drop(v_t_249);
          return heff_get_n(v_g_240, 11, 17);
        } else {
          heff_drop(v_t_249);
          V v_t_2411 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str8)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str9))));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_241, 9);
            heff_drop(v_t_2411);
            return heff_get_n(v_g_240, 12, 17);
          } else {
            heff_drop(v_t_2411);
            V v_t_2416 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str10)) ? (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str11)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str12)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str13)))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str14)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str15)))));
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop_rec(v_g_240, 17);
              heff_drop_rec(v_t_241, 9);
              heff_drop(v_t_2416);
              return ((V)&g_heff_2esyntax_2ecst_2eexprHead_lam0_clo);
            } else {
              heff_drop(v_t_2416);
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str16))) {
                if (heff_strEq_c(heff_get_n(v_t_241, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str17))) {
                  return heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_lam2, 2, 1, (V[]){v_g_240});
                } else {
                  return heff_tail(heff_get_n(v_g_240, 1, 17), 1, (V[]){MK_INT(0LL)});
                }
              } else {
                heff_drop_rec(v_t_241, 9);
                return heff_tail(heff_get_n(v_g_240, 1, 17), 1, (V[]){MK_INT(0LL)});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprHead_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_EJump, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2417, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_lam1, 1, 1, (V[]){v_k_2418})));
}
V g_heff_2esyntax_2ecst_2eexprHead_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_EReturn, 2, (V[]){v_x_2424, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_2422;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_lam4, 1, 2, (V[]){v_k_2423, v_x_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprHead_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2422), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_lam3, 1, 3, (V[]){v_g_240, v_hd_2422, v_k_2423})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str2, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str4, 1, "(");
V g_heff_2esyntax_2ecst_2elamBinders_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elamBinders_entry, 4, 0};

V g_heff_2esyntax_2ecst_2elamBinders(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elamBinders(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2elamBinders_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str0))) {
    heff_drop_rec(v_x_246, 9);
    return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam1, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str1))) {
      heff_drop_rec(v_x_246, 9);
      return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam2, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str2))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 1)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str3))) {
          heff_drop_rec(v_x_246, 9);
          return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam3, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
        } else {
          if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str4))) {
            return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam4, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
          } else {
            heff_drop(v_g_240);
            heff_drop_rec(v_hd_242, 3);
            V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
            V f_ = v_k_243;
            args[0] = v_x_2416;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        }
      } else {
        heff_drop_rec(v_x_246, 9);
        heff_drop(v_g_240);
        heff_drop_rec(v_hd_242, 3);
        V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
        V f_ = v_k_243;
        args[0] = v_x_2417;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str0, 4, "then");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str2, 4, "else");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str4, 2, "if");
V g_heff_2esyntax_2ecst_2eifStmtAt_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eifStmtAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eifStmtAt_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eifStmtAt(V v_g_240, V v_col_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_col_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eifStmtAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eifStmtAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam8(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_If, 6, (V[]){v_x_244, v_x_245, v_x_246, v_x_247, v_x_2416, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_x_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2422;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2419, 0)), ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str3))) {
    if (heff_strEq_c(heff_get_n(v_x_2419, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str4))) {
      v_c_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2eifStmtAt_clo), 2, (V[]){v_g_240, v_col_241}));
    } else {
      heff_drop(v_col_241);
      v_c_2422 = heff_get_n(v_g_240, 15, 17);
    }
  } else {
    heff_drop_rec(v_x_2419, 9);
    heff_drop(v_col_241);
    v_c_2422 = heff_get_n(v_g_240, 15, 17);
  }
  V f_ = v_c_2422;
  heff_room[0] = v_hd_242;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam8, 1, 6, (V[]){v_k_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2417}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam7, 1, 9, (V[]){v_g_240, v_col_241, v_hd_242, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam5(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_x_245 = heff_env(self)[6];
  V v_x_246 = heff_env(self)[7];
  V v_x_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 0)), ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str1)) && (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str2)) && ((heff_dup(v_x_2411) == NTAG(TAG_True)) ? ({ V v_t_2414 = heff_dup(heff_rfield(v_x_2410, 6)); int c_ = ((heff_dup(v_t_2414) == NTAG(TAG_True)) && heff_intEq_c(heff_dup(heff_rfield(v_x_2410, 5)), heff_dup(v_col_241))); heff_drop(v_t_2414); c_; }) : 1))));
  heff_drop(v_x_2411);
  heff_drop_rec(v_x_2410, 9);
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam6, 1, 8, (V[]){v_hd_242, v_g_240, v_col_241, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247})));
  } else {
    heff_drop(v_col_241);
    heff_drop_rec(v_hd_242, 3);
    heff_drop_rec(v_g_240, 17);
    heff_drop(v_t_2415);
    V f_ = v_k_243;
    args[0] = heff_tag_n(TAG_IfThen, 4, (V[]){v_x_244, v_x_245, v_x_246, v_x_247});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam5, 1, 9, (V[]){v_x_2410, v_col_241, v_hd_242, v_g_240, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247})));
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam4, 1, 8, (V[]){v_hd_242, v_col_241, v_g_240, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_g_240, 15));
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam3, 1, 7, (V[]){v_hd_242, v_col_241, v_g_240, v_k_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str0), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam2, 1, 6, (V[]){v_g_240, v_hd_242, v_col_241, v_k_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam1, 1, 5, (V[]){v_hd_242, v_g_240, v_col_241, v_k_243, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etryCaught_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2etryCaught_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2etryCaught_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2etryCaught_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2etryCaught_str4, 31, "a `try` has a `catch` arm, not ");
V g_heff_2esyntax_2ecst_2etryCaught_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etryCaught_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etryCaught_entry, 6, 0};

V g_heff_2esyntax_2ecst_2etryCaught(V v_kw_240, V v_ty_241, V v_body_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_kw_240);
    heff_drop(v_ty_241);
    heff_drop(v_body_242);
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){v_t_246}));
    return heff_tail(heff_dup(heff_rfield(v_p_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2etryCaught_lam0, 1, 2, (V[]){v_p_244, v_p_245})});
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_p_244, 3);
    return heff_tail(v_p_245, 1, (V[]){heff_tag_n(TAG_ETry, 4, (V[]){v_kw_240, v_ty_241, v_body_242, heff_dup(v_c_2416)})});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2ecst_2etryCaught_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2ecst_2etryCaught(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2esyntax_2ecst_2etryCaught_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2etryCaught_str0))) {
    v_t_2411 = ((V)&g_heff_2esyntax_2ecst_2etryCaught_str1);
  } else {
    V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_x_248, 1)), ((V)&g_heff_2esyntax_2ecst_2etryCaught_str2));
    v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2etryCaught_str3), v_t_2410);
  }
  V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_248, 3), heff_get_n(v_x_248, 4, 9)});
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2etryCaught_str4), v_t_2411), v_t_2412, NTAG(TAG_Nothing)});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2414}));
  V f_ = heff_get_n(v_p_244, 1, 3);
  heff_room[0] = v_t_2415;
  heff_room[1] = v_p_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatHeadF_str0, 3, "con");
V g_heff_2esyntax_2ecst_2epatHeadF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatHeadF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2epatHeadF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatHeadF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatHeadF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PCon, 2, (V[]){v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_get_n(v_g_240, 7, 17), NTAG(TAG_Nil), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam2, 1, 2, (V[]){v_k_242, v_x_247})));
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2epatHeadF_str0))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam1, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
  } else {
    V f_ = heff_get_n(v_g_240, 7, 17);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_a_2410, v_a_2411}), v_items_241});
  return ({ V a_0 = v_sep_240; V a_1 = v_t_2412; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam2(V self, V *args) {
  V v_a_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam3, 1, 7, (V[]){v_a_2410, v_items_241, v_sep_240, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam2, 1, 6, (V[]){v_hd_243, v_items_241, v_sep_240, v_x_249, v_seps_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam1, 1, 5, (V[]){v_hd_243, v_items_241, v_sep_240, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2415 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2413, v_t_2414});
    V f_ = v_k_244;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str2, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str4, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str5, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str8, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str9, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str10, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str11, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str12, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str13, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str14, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str15, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str17, 1, ")");
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2415});
  V f_ = v_k_244;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam7(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, heff_tag_n(TAG_Atom, 1, (V[]){v_x_2421}), v_x_2422});
  V f_ = v_k_244;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam7, 1, 3, (V[]){v_x_242, v_x_2421, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_ENest, 4, (V[]){v_x_242, v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str6), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam10, 1, 4, (V[]){v_k_244, v_x_242, v_x_2426, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam9, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam14(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Named, 5, (V[]){v_x_242, v_x_2434, v_x_2435, v_x_2436, v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam13(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str13), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam14, 1, 5, (V[]){v_k_244, v_x_242, v_x_2434, v_x_2435, v_x_2436})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam12(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam13, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2434, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam11(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam12, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2434})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam18(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2448;
  switch (heff_tag_of(v_x_2444)) {
  case TAG_MkSep: {
    V v_items_2446 = heff_field(v_x_2444, 0);
    V v_seps_2447 = heff_field(v_x_2444, 1);
    heff_take_n(v_x_2444, 3ULL, 2);
    v_t_2448 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, v_items_2446, v_seps_2447, v_x_2445});
    break;
  }
  default: heff_nomatch(v_x_2444);
  }
  V f_ = v_k_244;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam17(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str16), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam18, 1, 3, (V[]){v_x_2444, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam19(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, v_x_2438, v_x_2449});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam16(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_2438 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get_n(v_x_2441, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str14))) {
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2438, NTAG(TAG_Nil)});
    return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str15); V a_1 = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 0)); V a_2 = v_t_2443; V a_3 = NTAG(TAG_Nil); V a_4 = heff_dup(v_hd_243); V a_5 = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam17, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244}); V r_ = (g_heff_2esyntax_2ecst_2esepGo(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); r_; });
  } else {
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str17), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam19, 1, 3, (V[]){v_k_244, v_x_242, v_x_2438})));
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam15(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2439}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam16, 1, 4, (V[]){v_x_2438, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str1))));
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2412, 9);
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_t_2414);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam5, 1, 2, (V[]){v_x_242, v_k_244})));
  } else {
    heff_drop(v_t_2414);
    V v_t_2420 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str2)) && ({ V v_t_2418 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_247, 1))})); int c_ = ({ V v_x1_2419 = ({ V a_0 = heff_dup(v_t_2418); V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; }); int c_ = ((heff_dup(v_x1_2419) == NTAG(TAG_True)) ? 0 : heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str3))); heff_drop(v_x1_2419); c_; }); heff_drop(v_t_2418); c_; })));
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2412, 9);
      heff_drop_rec(v_x_247, 9);
      heff_drop(v_t_2420);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam6, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
    } else {
      heff_drop(v_t_2420);
      V v_t_2425 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str5))));
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2412, 9);
        heff_drop_rec(v_x_247, 9);
        heff_drop(v_t_2425);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam8, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
      } else {
        heff_drop(v_t_2425);
        V v_t_2433 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str7)) ? (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str8)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str9))) : (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str10)) && (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str11)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str12))))));
        heff_drop_rec(v_x_2412, 9);
        heff_drop_rec(v_x_247, 9);
        if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
          heff_drop(v_t_2433);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam11, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
        } else {
          heff_drop(v_t_2433);
          return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam15, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str1, 2, "::");
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2esegValueF_24s755176901x1919437034(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Seg, 3, (V[]){v_x_242, v_x_248, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam3, 1, 3, (V[]){v_k_241, v_x_242, v_x_248})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str1))) {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
    } else {
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_242;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_a_2410, v_a_2411}), v_items_241});
  return ({ V a_0 = v_sep_240; V a_1 = v_t_2412; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam2(V self, V *args) {
  V v_a_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam3, 1, 7, (V[]){v_a_2410, v_items_241, v_sep_240, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam2, 1, 6, (V[]){v_hd_243, v_items_241, v_sep_240, v_x_249, v_seps_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam1, 1, 5, (V[]){v_hd_243, v_items_241, v_sep_240, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2415 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2413, v_t_2414});
    V f_ = v_k_244;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_244;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_str0, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_str1, 1, "}");
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943(V v_o_240, V v_r_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam0, 1, 4, (V[]){v_hd_242, v_o_240, v_r_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkSep: {
    V v_items_249 = heff_field(v_x_247, 0);
    V v_seps_2410 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 3ULL, 2);
    v_t_2411 = heff_tag_n(TAG_Update, 6, (V[]){v_o_240, v_r_241, v_x_244, v_items_249, v_seps_2410, v_x_248});
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_k_243;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_str1), v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam3, 1, 5, (V[]){v_x_247, v_o_240, v_r_241, v_x_244, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_str0); V a_1 = v_t_246; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_242); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam2, 1, 5, (V[]){v_hd_242, v_o_240, v_r_241, v_x_244, v_k_243}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943_lam1, 1, 5, (V[]){v_hd_242, v_o_240, v_r_241, v_x_244, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str1, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str2, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str3, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str6, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str7, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str8, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str9, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str10, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str11, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str12, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str13, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str14, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str15, 1, "}");
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam20(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry, 2, 0};

V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_InstB, 5, (V[]){v_x_242, v_x_2415, v_x_2416, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str3), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8, 1, 5, (V[]){v_k_244, v_x_242, v_x_2415, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str2), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0)), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2420});
  V f_ = v_k_244;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkSep: {
    V v_items_2429 = heff_field(v_x_2427, 0);
    V v_seps_2430 = heff_field(v_x_2427, 1);
    heff_take_n(v_x_2427, 3ULL, 2);
    v_t_2431 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2429, v_seps_2430, v_x_2428});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_244;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str9), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14, 1, 3, (V[]){v_x_2427, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFSet, 3, (V[]){v_x_2423, v_x_2424, v_x_2425}), NTAG(TAG_Nil)});
  return ({ V a_0 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str7); V b_1 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str8); V a_2 = v_t_2426; V a_3 = NTAG(TAG_Nil); V a_4 = heff_dup(v_hd_243); V a_5 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s141384968x582145146(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12, 1, 5, (V[]){v_x_2423, v_x_2424, v_hd_243, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str6), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11, 1, 4, (V[]){v_hd_243, v_x_2423, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam18(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2439 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443;
  switch (heff_tag_of(v_x_2439)) {
  case TAG_MkSep: {
    V v_items_2441 = heff_field(v_x_2439, 0);
    V v_seps_2442 = heff_field(v_x_2439, 1);
    heff_take_n(v_x_2439, 3ULL, 2);
    v_t_2443 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2441, v_seps_2442, v_x_2440});
    break;
  }
  default: heff_nomatch(v_x_2439);
  }
  V f_ = v_k_244;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str13), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam18, 1, 3, (V[]){v_x_2439, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam20(V self, V *args) {
  V v_x_2446 = args[0];
  V v_x_2445 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2449;
  switch (heff_tag_of(v_x_2445)) {
  case TAG_MkSep: {
    V v_items_2447 = heff_field(v_x_2445, 0);
    V v_seps_2448 = heff_field(v_x_2445, 1);
    heff_take_n(v_x_2445, 3ULL, 2);
    v_t_2449 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2447, v_seps_2448, v_x_2446});
    break;
  }
  default: heff_nomatch(v_x_2445);
  }
  V f_ = v_k_244;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam19(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str15), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam20, 1, 3, (V[]){v_x_2445, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2435, 0)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str10))) {
    if (heff_strEq_c(heff_get_n(v_x_2435, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str11))) {
      return (g_heff_2esyntax_2ecst_2eupdateF_24s332506245x1412911943(v_x_242, v_x_2432, v_hd_243, v_k_244));
    } else {
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2ecst_2esepGo_24s719949573x737501204(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str12), v_t_2438, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
    }
  } else {
    heff_drop_rec(v_x_2435, 9);
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo_24s719949573x737501204(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str14), v_t_2444, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam19, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2433}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2434;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16, 1, 4, (V[]){v_x_242, v_x_2432, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str1))));
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2412, 9);
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_t_2414);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
  } else {
    heff_drop(v_t_2414);
    if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str4))) {
      heff_drop_rec(v_x_2412, 9);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9, 1, 2, (V[]){v_x_242, v_k_244})));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2412, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str5))) {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      } else {
        return (g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_hd_244) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam0, 1, 5, (V[]){v_hd_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2418, v_x_2419}), NTAG(TAG_Nil)});
  V v_t_2421 = (g_prelude_2e_2b_2b(v_x_246, v_t_2420));
  V v_x_2422 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_x_2422}), v_lit_241});
  return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(v_t_2423, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 14)), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam5, 1, 7, (V[]){v_x_2418, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_hd_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 16));
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_249, 0)), ((V)&g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str0))) {
      if (heff_strEq_c(heff_get_n(v_x_249, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str1))) {
        if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
          heff_drop(v_x_2410);
          heff_drop_rec(v_hd_244, 3);
          V v_t_2416;
          switch (heff_tag_of(v_x_246)) {
          case TAG_Nil: {
            v_t_2416 = v_x_245;
            break;
          }
          case TAG_Cons: {
            v_t_2416 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_x_246});
            break;
          }
          default: heff_nomatch(v_x_246);
          }
          V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_t_2416}), v_lit_241});
          return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(v_t_2417, v_lit_242, v_lit_243));
        } else {
          heff_drop(v_x_2410);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam4, 1, 7, (V[]){v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
        }
      } else {
        heff_drop(v_x_2410);
        heff_drop_rec(v_hd_244, 3);
        V v_t_2426;
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nil: {
          v_t_2426 = v_x_245;
          break;
        }
        case TAG_Cons: {
          v_t_2426 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_x_246});
          break;
        }
        default: heff_nomatch(v_x_246);
        }
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_t_2426}), v_lit_241});
        return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(v_t_2427, v_lit_242, v_lit_243));
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop_rec(v_x_249, 9);
      heff_drop_rec(v_hd_244, 3);
      V v_t_2430;
      switch (heff_tag_of(v_x_246)) {
      case TAG_Nil: {
        v_t_2430 = v_x_245;
        break;
      }
      case TAG_Cons: {
        v_t_2430 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_x_246});
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_t_2430}), v_lit_241});
      return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(v_t_2431, v_lit_242, v_lit_243));
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_249, 9);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_t_2411);
    V v_t_2434;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Nil: {
      v_t_2434 = v_x_245;
      break;
    }
    case TAG_Cons: {
      v_t_2434 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_x_246});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_t_2434}), v_lit_241});
    return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(v_t_2435, v_lit_242, v_lit_243));
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam3, 1, 8, (V[]){v_x_249, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_hd_244})));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam2, 1, 7, (V[]){v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam1, 1, 6, (V[]){v_hd_244, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str1, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str2, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V v_t_2411 = heff_tag_n(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_2410;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str1); V a_1 = v_t_2415; V a_2 = NTAG(TAG_Nil); V a_3 = v_hd_2412; V a_4 = v_k_2413; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  return (g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(heff_dup(v_hd_2412), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam5, 1, 2, (V[]){v_hd_2412, v_k_2413})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_MkSep: {
    V v_items_2419 = heff_field(v_x_2417, 0);
    V v_seps_2420 = heff_field(v_x_2417, 1);
    heff_take_n(v_x_2417, 3ULL, 2);
    v_t_2421 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, v_items_2419, v_seps_2420, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_k_244;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str2), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam7, 1, 3, (V[]){v_x_2417, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416;
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str0))) {
    v_t_2416 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3_clo);
  } else {
    v_t_2416 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4_clo);
  }
  V f_ = v_t_2416;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam6, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str3, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str4, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str7, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str8, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str9, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str10, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str11, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str12, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str14, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str15, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str16, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str17, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str18, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str19, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str20, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str21, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str22, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str24, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str25, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str26, 4, "lazy");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str27, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str29, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str30, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str31, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str32, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str33, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str34, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str35, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str36, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str37, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str39, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str40, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str41, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str43, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str44, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam5(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam5, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam9(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V v_t_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 0))}));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str0), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str2), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str4), v_t_243})});
  V v_t_245 = ({ V a_0 = v_t_241; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str5), v_t_244}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2418;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_2418 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_245);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str6))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str7), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str9), v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str11), v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str13), v_t_2410})});
      V v_t_2412 = ({ V a_0 = v_t_247; V a_1 = v_t_2411; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2411, 2); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2418 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2412);
        HeffT2 v_t_2413 = (g_list_2efind_24s1236173780x2048419812_24cpr(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str14), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str15), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str16), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str17), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str18), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str19), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str20), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str21), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str22), heff_rfield(v_t_240, 1), heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          v_t_2418 = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) && ({ V v_x_2417 = heff_dup(v_field_2415); int c_ = 1; heff_drop(v_x_2417); c_; })));
          heff_drop(v_field_2415);
        }
      }
    } else {
      v_t_2418 = NTAG(TAG_False);
    }
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_2418);
    return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    V v_t_2423 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str23)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str24))));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_t_2423);
      return ((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo);
    } else {
      heff_drop(v_t_2423);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str25))) {
        heff_drop_rec(v_t_240, 9);
        return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2_clo);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str26))) {
          heff_drop_rec(v_t_240, 9);
          return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam5_clo);
        } else {
          V v_t_2435 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str27)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str28))));
          if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 9);
            heff_drop(v_t_2435);
            return ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo);
          } else {
            heff_drop(v_t_2435);
            V v_t_2437 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str29)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str30))));
            if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
              heff_drop_rec(v_t_240, 9);
              heff_drop(v_t_2437);
              return ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo);
            } else {
              heff_drop(v_t_2437);
              V v_t_2439 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str31)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str32))));
              if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                heff_drop_rec(v_t_240, 9);
                heff_drop(v_t_2439);
                return heff_tail(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo), 1, (V[]){heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0))});
              } else {
                heff_drop(v_t_2439);
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str33))) {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str34))) {
                    heff_drop_rec(v_t_240, 9);
                    return ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_clo);
                  } else {
                    return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam8, 2, 1, (V[]){v_t_240});
                  }
                } else {
                  return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam9, 2, 1, (V[]){v_t_240});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(a[0]);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2419, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2426;
  args[0] = heff_tag_n(TAG_ENeg, 2, (V[]){v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2425 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(v_hd_2425, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam4, 1, 2, (V[]){v_k_2426, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2425), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3, 1, 2, (V[]){v_hd_2425, v_k_2426})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2431 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_ETilde, 2, (V[]){v_x_2432, v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(v_hd_2430, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam7, 1, 2, (V[]){v_k_2431, v_x_2432})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2430), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam6, 1, 2, (V[]){v_hd_2430, v_k_2431})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam8(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str35))) {
    v_t_2446 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str36);
  } else {
    V v_t_2445 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str37));
    v_t_2446 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str38), v_t_2445);
  }
  V v_t_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str39), v_t_2446), v_t_2447, NTAG(TAG_Nothing)});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2442, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam9(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k2_2452 = args[1];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str40))) {
    v_t_2455 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str41);
  } else {
    V v_t_2454 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str42));
    v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str43), v_t_2454);
  }
  V v_t_2456 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str44), v_t_2455), v_t_2456, NTAG(TAG_Nothing)});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_take_field(v_hd_2451, 2), 1, (V[]){v_t_2458}));
  V f_ = heff_get_n(v_hd_2451, 1, 3);
  args[0] = v_t_2459;
  args[1] = v_k2_2452;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5, 1, 3, (V[]){v_k_241, v_x_246, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_249, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_249, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str1))) {
      if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
        heff_drop(v_x_2410);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_246;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_2410);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})));
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_246;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_249, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3, 1, 4, (V[]){v_x_249, v_k_241, v_x_246, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245 = (g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(v_x_244));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1, 1, 2, (V[]){v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprimitiveDecl_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprimitiveDecl_str1, 20, "the primitive's name");
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eprimitiveDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eprimitiveDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eprimitiveDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_247 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_247, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eprimitiveDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DPrimitive, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3, 1, 4, (V[]){v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eprimitiveDecl_str0); V a_1 = ((V)&g_heff_2esyntax_2ecst_2eprimitiveDecl_str1); V a_2 = heff_dup(v_hd_240); V a_3 = heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243}); V r_ = (g_heff_2esyntax_2ecst_2eexpectKind(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigName_str0, 53, "a signature's names are `f`, `C` or `(+)`: `f, g : T`");
V g_heff_2esyntax_2ecst_2esigName_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigName_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigName_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2esigName_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigName_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigName_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2esigName_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigName_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esigName_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigName_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esigName(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2esigName_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2esigName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigName(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esigName_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_245, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_245, v_t_246));
}
V g_heff_2esyntax_2ecst_2esigName_lam3(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_s_2410, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2410, v_t_2411));
}
V g_heff_2esyntax_2ecst_2esigName_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_x_244), heff_dup(v_x_249), heff_dup(v_x_2414)));
  if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
    heff_drop(v_x_2414);
    heff_drop(v_x_249);
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2esigName_str0), v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2421 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_x_244, v_x_249, v_x_2414));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2421, v_hd_240, v_k_241));
  }
}
V g_heff_2esyntax_2ecst_2esigName_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigName_lam3_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigName_lam4, 1, 4, (V[]){v_x_244, v_x_249, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigName_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigName_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigName_lam2, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2esigName(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_244;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}