// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_Braces 8205
#define TAG_DPrimitive 59284
#define TAG_Do 8988
#define TAG_ECon 35052
#define TAG_EJump 55703
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ETilde 53294
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_MkSep 6724
#define TAG_Named 2049
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PCon 35123
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_arm 306390
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blockArg 80527375
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_opExpr 935619233
#define LBL_patAtom 1586746071
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo;
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V, V, V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(V, V);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclNameLen(V, V, V);
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2eexprHead(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V, V, V);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eheadGram_get(void);
V g_heff_2esyntax_2ecst_2eifStmtAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2eifStmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifStmtAt_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2elamBinderF(V, V, V);
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinderF_clo;
V g_heff_2esyntax_2ecst_2elamBinders(V, V, V, V);
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinders_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011(V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo;
V g_heff_2esyntax_2ecst_2epatHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatHeadF_clo;
V g_heff_2esyntax_2ecst_2eprimitiveDecl(V, V, V);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprimitiveDecl_clo;
V g_heff_2esyntax_2ecst_2escrutineeF(V, V, V);
V g_heff_2esyntax_2ecst_2escrutineeF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2escrutineeF_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1640861710x1034297351(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1640861710x1034297351_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1640861710x1034297351_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_clo;
V g_heff_2esyntax_2ecst_2esettingF_24s1757998429x401865903(V, V);
V g_heff_2esyntax_2ecst_2esettingF_24s1757998429x401865903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esettingF_24s1757998429x401865903_clo;
V g_heff_2esyntax_2ecst_2esigName(V, V);
V g_heff_2esyntax_2ecst_2esigName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigName_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str5, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str6, 7, "`, not ");
V g_heff_2esyntax_2ecst_2eexpectKw_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectKw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectKw_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectKw(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectKw_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectKw(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectKw_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_take_field(v_x_245, 1);
  V v_start_248 = heff_take_field(v_x_245, 3);
  V v_end_249 = heff_get_n(v_x_245, 4, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str0), 2) && heff_strEq_c_lent(v_text_247, v_x_240, 0))) {
    heff_clo_take(self, 3);
    heff_drop(v_x_240);
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    heff_drop(v_start_248);
    heff_drop(v_end_249);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
  } else {
    V v_span_2410 = heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249});
    V v_t_2411;
    if (heff_strEq_c(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str1))) {
      heff_drop(v_text_247);
      v_t_2411 = ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str2);
    } else {
      v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str3), v_text_247), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str4));
    }
    heff_clo_take(self, 3);
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str5), v_x_240), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str6));
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2412, v_t_2411), v_span_2410, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str11, 5, "break");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str12, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str13, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str14, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str15, 6, "return");
V g_heff_2esyntax_2ecst_2eexprHead_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eexprHead(V v_g_240, V v_t_241, V v_z_242, V v_z_243) {
top: ;
  V v_text_244 = heff_take_field(v_t_241, 1);
  V v_kind_245 = heff_get_n(v_t_241, 0, 9);
  V v_lambda_246 = heff_take_field(v_g_240, 8);
  V v_caseE_247 = heff_take_field(v_g_240, 9);
  V v_ifE_248 = heff_take_field(v_g_240, 10);
  V v_doE_249 = heff_take_field(v_g_240, 11);
  V v_letE_2410 = heff_take_field(v_g_240, 12);
  V v_expr_2411 = heff_take_field(v_g_240, 0);
  V v_opExpr_2412 = heff_get_n(v_g_240, 1, 17);
  if ((heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str0), 2) && heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str1), 2))) {
    heff_drop(v_text_244);
    heff_drop(v_kind_245);
    heff_drop(v_caseE_247);
    heff_drop(v_ifE_248);
    heff_drop(v_doE_249);
    heff_drop(v_letE_2410);
    heff_drop(v_expr_2411);
    heff_drop(v_opExpr_2412);
    return heff_tail(v_lambda_246, 2, (V[]){v_z_242, v_z_243});
  } else {
    heff_drop(v_lambda_246);
    if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str2), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str3), 2))) {
      heff_drop(v_text_244);
      heff_drop(v_kind_245);
      heff_drop(v_ifE_248);
      heff_drop(v_doE_249);
      heff_drop(v_letE_2410);
      heff_drop(v_expr_2411);
      heff_drop(v_opExpr_2412);
      return heff_tail(v_caseE_247, 2, (V[]){v_z_242, v_z_243});
    } else {
      heff_drop(v_caseE_247);
      if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str4), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str5), 2))) {
        heff_drop(v_text_244);
        heff_drop(v_kind_245);
        heff_drop(v_doE_249);
        heff_drop(v_letE_2410);
        heff_drop(v_expr_2411);
        heff_drop(v_opExpr_2412);
        return heff_tail(v_ifE_248, 2, (V[]){v_z_242, v_z_243});
      } else {
        heff_drop(v_ifE_248);
        if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str6), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str7), 2))) {
          heff_drop(v_text_244);
          heff_drop(v_kind_245);
          heff_drop(v_letE_2410);
          heff_drop(v_expr_2411);
          heff_drop(v_opExpr_2412);
          return heff_tail(v_doE_249, 2, (V[]){v_z_242, v_z_243});
        } else {
          heff_drop(v_doE_249);
          if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str8), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str9), 2))) {
            heff_drop(v_text_244);
            heff_drop(v_kind_245);
            heff_drop(v_expr_2411);
            heff_drop(v_opExpr_2412);
            return heff_tail(v_letE_2410, 2, (V[]){v_z_242, v_z_243});
          } else {
            heff_drop(v_letE_2410);
            if (((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str10), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str11), 2)) || (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str12), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str13), 2)))) {
              heff_drop(v_text_244);
              heff_drop(v_kind_245);
              heff_drop(v_expr_2411);
              heff_drop(v_opExpr_2412);
              return (g_heff_2esyntax_2ecst_2enext(v_z_242, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_lam0, 1, 1, (V[]){v_z_243})));
            } else {
              if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str14), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_str15), 2))) {
                heff_drop(v_text_244);
                heff_drop(v_kind_245);
                heff_drop(v_opExpr_2412);
                return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_242), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_lam1, 1, 3, (V[]){v_expr_2411, v_z_242, v_z_243})));
              } else {
                heff_drop(v_text_244);
                heff_drop(v_kind_245);
                heff_drop(v_expr_2411);
                return heff_tail(v_opExpr_2412, 3, (V[]){MK_INT(0LL), v_z_242, v_z_243});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eexprHead_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_243;
  args[0] = heff_tag_n(TAG_EJump, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_243;
  args[0] = heff_tag_n(TAG_EReturn, 2, (V[]){v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_expr_2411 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_expr_2411;
  heff_room[0] = v_z_242;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_lam2, 1, 2, (V[]){v_z_243, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str2, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str4, 1, "(");
V g_heff_2esyntax_2ecst_2elamBinders_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elamBinders_entry, 4, 0};

V g_heff_2esyntax_2ecst_2elamBinders(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elamBinders(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2elamBinders_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_kind_247 = heff_take_field(v_x_246, 0);
  V v_text_248 = heff_get_n(v_x_246, 1, 9);
  if ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2elamBinders_str0), 2) || (heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2elamBinders_str1), 2) || (heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2elamBinders_str2), 2) && (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2ecst_2elamBinders_str3), 2) || heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2ecst_2elamBinders_str4), 2)))))) {
    heff_drop(v_kind_247);
    heff_drop(v_text_248);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam1, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
  } else {
    heff_clo_take(self, 4);
    heff_drop(v_g_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_kind_247);
    heff_drop(v_text_248);
    V v_x_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_2410;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str0, 4, "then");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str2, 4, "else");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtAt_str4, 2, "if");
V g_heff_2esyntax_2ecst_2eifStmtAt_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtAt_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eifStmtAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eifStmtAt_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eifStmtAt(V v_g_240, V v_col_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_col_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eifStmtAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eifStmtAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam8(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_If, 6, (V[]){v_x_244, v_x_245, v_x_246, v_x_247, v_x_2416, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_x_2416 = heff_env(self)[8];
  V v_kind_2420 = heff_take_field(v_x_2419, 0);
  V v_text_2421 = heff_get_n(v_x_2419, 1, 9);
  V v_c_2422;
  heff_clo_take(self, 9);
  if ((heff_strEq_c_lent(v_kind_2420, ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str3), 2) && heff_strEq_c_lent(v_text_2421, ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str4), 2))) {
    heff_drop(v_kind_2420);
    heff_drop(v_text_2421);
    v_c_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2eifStmtAt_clo), 2, (V[]){v_g_240, v_col_241}));
  } else {
    heff_drop(v_col_241);
    heff_drop(v_kind_2420);
    heff_drop(v_text_2421);
    v_c_2422 = heff_get_n(v_g_240, 15, 17);
  }
  V f_ = v_c_2422;
  heff_room[0] = v_hd_242;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam8, 1, 6, (V[]){v_k_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2417}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam7, 1, 9, (V[]){v_g_240, v_col_241, v_hd_242, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_kind_2411 = heff_env(self)[0];
  V v_text_2412 = heff_env(self)[1];
  V v_first_2413 = heff_env(self)[2];
  V v_col_2414 = heff_env(self)[3];
  V v_col_241 = heff_env(self)[4];
  V v_hd_242 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  V v_k_243 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  V v_x_246 = heff_env(self)[10];
  V v_x_247 = heff_env(self)[11];
  if (((heff_strEq_c_lent(v_kind_2411, ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str1), 2) && heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str2), 2)) && ((heff_dup(v_x_2415) == NTAG(TAG_True)) ? ((heff_dup(v_first_2413) == NTAG(TAG_True)) && heff_intEq_c_lent(v_col_2414, v_col_241, 0)) : 1))) {
    heff_drop(v_x_2415);
    heff_clo_take(self, 12);
    heff_drop(v_kind_2411);
    heff_drop(v_text_2412);
    heff_drop(v_first_2413);
    heff_drop(v_col_2414);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam6, 1, 8, (V[]){v_hd_242, v_g_240, v_col_241, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247})));
  } else {
    heff_drop(v_x_2415);
    heff_clo_take(self, 12);
    heff_drop(v_kind_2411);
    heff_drop(v_text_2412);
    heff_drop(v_first_2413);
    heff_drop(v_col_2414);
    heff_drop(v_col_241);
    heff_drop_rec(v_hd_242, 3);
    heff_drop_rec(v_g_240, 17);
    V f_ = v_k_243;
    args[0] = heff_tag_n(TAG_IfThen, 4, (V[]){v_x_244, v_x_245, v_x_246, v_x_247});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_kind_2411 = heff_take_field(v_x_2410, 0);
  V v_text_2412 = heff_take_field(v_x_2410, 1);
  V v_first_2413 = heff_take_field(v_x_2410, 6);
  V v_col_2414 = heff_get_n(v_x_2410, 5, 9);
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam5, 1, 12, (V[]){v_kind_2411, v_text_2412, v_first_2413, v_col_2414, v_col_241, v_hd_242, v_g_240, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247})));
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_248}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam4, 1, 8, (V[]){v_hd_242, v_col_241, v_g_240, v_k_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_g_240, 15));
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam3, 1, 7, (V[]){v_hd_242, v_col_241, v_g_240, v_k_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eifStmtAt_str0), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam2, 1, 6, (V[]){v_g_240, v_hd_242, v_col_241, v_k_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eifStmtAt_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2escrutineeF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtAt_lam1, 1, 5, (V[]){v_hd_242, v_g_240, v_col_241, v_k_243, v_x_244})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatHeadF_str0, 3, "con");
V g_heff_2esyntax_2ecst_2epatHeadF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatHeadF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2epatHeadF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatHeadF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatHeadF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PCon, 2, (V[]){v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_get_n(v_g_240, 7, 17), NTAG(TAG_Nil), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam2, 1, 2, (V[]){v_k_242, v_x_246})));
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2epatHeadF_str0))) {
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam1, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
  } else {
    heff_clo_take(self, 3);
    V f_ = heff_get_n(v_g_240, 7, 17);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_249 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_a_249, v_a_2410}), v_items_241});
  return ({ V a_0 = v_sep_240; V a_1 = v_t_2411; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam2(V self, V *args) {
  V v_a_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam3, 1, 7, (V[]){v_a_249, v_items_241, v_sep_240, v_x_248, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam2, 1, 6, (V[]){v_hd_243, v_items_241, v_sep_240, v_x_248, v_seps_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_lam1, 1, 5, (V[]){v_hd_243, v_items_241, v_sep_240, v_seps_242, v_k_244})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2414 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2412, v_t_2413});
    V f_ = v_k_244;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str2, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str4, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str5, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str8, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str9, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str10, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str12, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str13, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str15, 1, ")");
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2415});
  V f_ = v_k_244;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, heff_tag_n(TAG_Atom, 1, (V[]){v_x_2419}), v_x_2420});
  V f_ = v_k_244;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam7, 1, 3, (V[]){v_x_242, v_x_2419, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam10(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_ENest, 4, (V[]){v_x_242, v_x_2422, v_x_2423, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam9(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str6), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam10, 1, 4, (V[]){v_k_244, v_x_242, v_x_2422, v_x_2423})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam9, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2422})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam14(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Named, 5, (V[]){v_x_242, v_x_2425, v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam13(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str11), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam14, 1, 5, (V[]){v_k_244, v_x_242, v_x_2425, v_x_2426, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam12(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam13, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam11(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam12, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam18(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2438;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkSep: {
    V v_items_2436 = heff_field(v_x_2434, 0);
    V v_seps_2437 = heff_field(v_x_2434, 1);
    heff_take_n(v_x_2434, 3ULL, 2);
    v_t_2438 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, v_items_2436, v_seps_2437, v_x_2435});
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_k_244;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam17(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str14), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam18, 1, 3, (V[]){v_x_2434, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam19(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, v_x_2429, v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam16(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  if (heff_strEq_c(heff_get_n(v_x_2432, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str12))) {
    heff_clo_take(self, 4);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, NTAG(TAG_Nil)});
    return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str13); V a_1 = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 0)); V a_2 = v_t_2433; V a_3 = NTAG(TAG_Nil); V a_4 = heff_dup(v_hd_243); V a_5 = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam17, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244}); V r_ = (g_heff_2esyntax_2ecst_2esepGo(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); r_; });
  } else {
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str15), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam19, 1, 3, (V[]){v_k_244, v_x_242, v_x_2429})));
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam15(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2430}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam16, 1, 4, (V[]){v_x_2429, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_text_2413 = heff_take_field(v_x_2412, 1);
  V v_kind_2414 = heff_get_n(v_x_2412, 0, 9);
  if ((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str1)))) {
    heff_clo_take(self, 4);
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_text_2413);
    heff_drop(v_kind_2414);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam5, 1, 2, (V[]){v_x_242, v_k_244})));
  } else {
    V v_t_2418;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str2))) {
      V v_x1_2417 = ({ V a_0 = heff_dup(v_x_247); V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s565534491x447967237(a_0, b_1)); heff_drop(b_1); r_; });
      v_t_2418 = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
      heff_drop(v_x1_2417);
    } else {
      v_t_2418 = NTAG(TAG_False);
    }
    if (((heff_dup(v_t_2418) == NTAG(TAG_True)) && heff_strEq_c_lent(v_text_2413, ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str3), 2))) {
      heff_clo_take(self, 4);
      heff_drop_rec(v_x_247, 9);
      heff_drop(v_text_2413);
      heff_drop(v_kind_2414);
      heff_drop(v_t_2418);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam6, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
    } else {
      heff_drop(v_t_2418);
      if ((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str5)))) {
        heff_clo_take(self, 4);
        heff_drop_rec(v_x_247, 9);
        heff_drop(v_text_2413);
        heff_drop(v_kind_2414);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam8, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
      } else {
        if (((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str7)) || heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str8))) && (heff_strEq_c_lent(v_kind_2414, ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str9), 2) && heff_strEq_c_lent(v_text_2413, ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_str10), 2)))) {
          heff_clo_take(self, 4);
          heff_drop_rec(v_x_247, 9);
          heff_drop(v_text_2413);
          heff_drop(v_kind_2414);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam11, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
        } else {
          heff_clo_take(self, 4);
          heff_drop_rec(v_x_247, 9);
          heff_drop(v_text_2413);
          heff_drop(v_kind_2414);
          return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam15, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2410}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str1, 2, "::");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str2, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str4, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str6, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str7, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str9, 2, "do");
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam4(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(V v_hd_240, V v_k_241) {
top: ;
  V v_hd_242 = heff_dup(v_hd_240);
  V v_k_2411 = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam0, 1, 2, (V[]){v_hd_240, v_k_241});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam4, 1, 2, (V[]){v_hd_242, v_k_2411})});
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Seg, 3, (V[]){v_x_243, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam3, 1, 3, (V[]){v_k_241, v_x_243, v_x_249})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_kind_247 = heff_take_field(v_x_246, 0);
  V v_text_248 = heff_get_n(v_x_246, 1, 9);
  if ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str0), 2) && heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str1), 2))) {
    heff_drop(v_kind_247);
    heff_drop(v_text_248);
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
  } else {
    heff_clo_take(self, 3);
    heff_drop_rec(v_hd_240, 3);
    heff_drop(v_kind_247);
    heff_drop(v_text_248);
    V f_ = v_k_241;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  V v_t_2422;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nil: {
    v_t_2422 = v_x_2418;
    break;
  }
  case TAG_Cons: {
    v_t_2422 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2418, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V f_ = v_k_2411;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(NTAG(TAG_Nil), v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam6, 1, 2, (V[]){v_x_2418, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam12(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2432, v_x_2433}), NTAG(TAG_Nil)});
  V v_t_2435 = (g_prelude_2e_2b_2b(v_x_2425, v_t_2434));
  V v_x_2436 = heff_tag_n(TAG_App, 2, (V[]){v_x_2424, v_t_2435});
  V f_ = v_k_2423;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam11(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 14)), v_hd_2417, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam12, 1, 4, (V[]){v_x_2432, v_x_2425, v_x_2424, v_k_2423})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam10(V self, V *args) {
  V v_x_2431 = args[0];
  V v_kind_2429 = heff_env(self)[0];
  V v_text_2430 = heff_env(self)[1];
  V v_hd_2417 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  if (((heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 16)) == NTAG(TAG_True)) && ((heff_strEq_c_lent(v_kind_2429, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str8), 2) && heff_strEq_c_lent(v_text_2430, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str9), 2)) && !(heff_dup(v_x_2431) == NTAG(TAG_True))))) {
    heff_drop(v_x_2431);
    heff_clo_take(self, 6);
    heff_drop(v_kind_2429);
    heff_drop(v_text_2430);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2417), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam11, 1, 4, (V[]){v_hd_2417, v_x_2425, v_x_2424, v_k_2423})));
  } else {
    heff_drop(v_x_2431);
    heff_clo_take(self, 6);
    heff_drop(v_kind_2429);
    heff_drop(v_text_2430);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_2439;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_Nil: {
      v_t_2439 = v_x_2424;
      break;
    }
    case TAG_Cons: {
      v_t_2439 = heff_tag_n(TAG_App, 2, (V[]){v_x_2424, v_x_2425});
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    V f_ = v_k_2423;
    args[0] = v_t_2439;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam9(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  V v_kind_2429 = heff_take_field(v_x_2428, 0);
  V v_text_2430 = heff_get_n(v_x_2428, 1, 9);
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_2417), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam10, 1, 6, (V[]){v_kind_2429, v_text_2430, v_hd_2417, v_x_2425, v_x_2424, v_k_2423})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2426}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
  heff_room[0] = v_t_2427;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam9, 1, 4, (V[]){v_hd_2417, v_x_2425, v_x_2424, v_k_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_2417), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam8, 1, 3, (V[]){v_hd_2417, v_x_2424, v_k_2423})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  V v_text_2415 = heff_take_field(v_x_2414, 1);
  V v_kind_2416 = heff_get_n(v_x_2414, 0, 9);
  if ((heff_strEq_c_lent(v_text_2415, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str2), 2) || (heff_strEq_c_lent(v_kind_2416, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str3), 2) && (heff_strEq_c_lent(v_text_2415, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str4), 2) || (heff_strEq_c_lent(v_text_2415, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str5), 2) || (heff_strEq_c_lent(v_text_2415, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str6), 2) || heff_strEq_c_lent(v_text_2415, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_str7), 2))))))) {
    heff_drop(v_text_2415);
    heff_drop(v_kind_2416);
    heff_clo_take(self, 2);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_242, v_k_2411));
  } else {
    heff_drop(v_text_2415);
    heff_drop(v_kind_2416);
    V v_hd_2417 = heff_dup(v_hd_242);
    heff_clo_take(self, 2);
    V v_k_2423 = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam5, 1, 2, (V[]){v_hd_242, v_k_2411});
    return (g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(heff_dup(v_hd_2417), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s435414490x1216453893_lam7, 1, 2, (V[]){v_hd_2417, v_k_2423})));
  }
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_249 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_a_249, v_a_2410}), v_items_241});
  return ({ V a_0 = v_sep_240; V a_1 = v_t_2411; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam2(V self, V *args) {
  V v_a_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam3, 1, 7, (V[]){v_a_249, v_items_241, v_sep_240, v_x_248, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam2, 1, 6, (V[]){v_hd_243, v_items_241, v_sep_240, v_x_248, v_seps_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s2106021041x1795232874_lam1, 1, 5, (V[]){v_hd_243, v_items_241, v_sep_240, v_seps_242, v_k_244})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2414 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2412, v_t_2413});
    V f_ = v_k_244;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_248, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2410, v_t_2411});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str1, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str2, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str3, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str6, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str8, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str9, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str10, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str11, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str12, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str13, 1, "}");
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam20(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam22(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam21(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry, 2, 0};

V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_s_2410, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2410, v_t_2411));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_InstB, 5, (V[]){v_x_242, v_x_2415, v_x_2416, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str3), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8, 1, 5, (V[]){v_k_244, v_x_242, v_x_2415, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str2), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0)), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2419});
  V f_ = v_k_244;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2427;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkSep: {
    V v_items_2425 = heff_field(v_x_2423, 0);
    V v_seps_2426 = heff_field(v_x_2423, 1);
    heff_take_n(v_x_2423, 3ULL, 2);
    v_t_2427 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2425, v_seps_2426, v_x_2424});
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_244;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str7), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12, 1, 3, (V[]){v_x_2423, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2421, NTAG(TAG_Nil)});
  heff_clo_take(self, 3);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str6); V a_1 = v_t_2422; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_243); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1640861710x1034297351(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam18(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  V v_t_2445;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2441)) {
  case TAG_MkSep: {
    V v_items_2443 = heff_field(v_x_2441, 0);
    V v_seps_2444 = heff_field(v_x_2441, 1);
    heff_take_n(v_x_2441, 3ULL, 2);
    v_t_2445 = heff_tag_n(TAG_Update, 6, (V[]){v_o_2434, v_r_2435, v_x_2438, v_items_2443, v_seps_2444, v_x_2442});
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V f_ = v_k_2437;
  args[0] = v_t_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str11), v_hd_2436, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam18, 1, 5, (V[]){v_x_2441, v_o_2434, v_r_2435, v_x_2438, v_k_2437})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
  heff_clo_take(self, 5);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str10); V a_1 = v_t_2440; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_2436); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17, 1, 5, (V[]){v_hd_2436, v_o_2434, v_r_2435, v_x_2438, v_k_2437}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s236422621x345722353(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_o_2434 = heff_env(self)[1];
  V v_r_2435 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s183877967x2048990742(heff_dup(v_hd_2436), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16, 1, 5, (V[]){v_hd_2436, v_o_2434, v_r_2435, v_x_2438, v_k_2437})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam20(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2450 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2454;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkSep: {
    V v_items_2452 = heff_field(v_x_2450, 0);
    V v_seps_2453 = heff_field(v_x_2450, 1);
    heff_take_n(v_x_2450, 3ULL, 2);
    v_t_2454 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2452, v_seps_2453, v_x_2451});
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V f_ = v_k_244;
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam19(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str13), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam20, 1, 3, (V[]){v_x_2450, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam22(V self, V *args) {
  V v_x_2459 = args[0];
  V v_sep_2446 = heff_env(self)[0];
  V v_items_2447 = heff_env(self)[1];
  V v_seps_2448 = heff_env(self)[2];
  V v_hd_2449 = heff_env(self)[3];
  V v_k_2455 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2446, v_items_2447, v_x_2459, v_seps_2448, heff_dup(v_hd_2449), v_k_2455, v_hd_2449));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam21(V self, V *args) {
  V v_x_2458 = args[0];
  V v_sep_2446 = heff_env(self)[0];
  V v_hd_2449 = heff_env(self)[1];
  V v_items_2447 = heff_env(self)[2];
  V v_seps_2448 = heff_env(self)[3];
  V v_k_2455 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_2458, 1, 9), heff_dup(v_sep_2446))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2449), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam22, 1, 5, (V[]){v_sep_2446, v_items_2447, v_seps_2448, v_hd_2449, v_k_2455})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_2446);
    heff_drop_rec(v_hd_2449, 3);
    V v_t_2460 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2447));
    V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2448));
    V v_x_2462 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2460, v_t_2461});
    V f_ = v_k_2455;
    args[0] = v_x_2462;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_kind_2432 = heff_take_field(v_x_2431, 0);
  V v_text_2433 = heff_get_n(v_x_2431, 1, 9);
  if ((heff_strEq_c_lent(v_kind_2432, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str8), 2) && heff_strEq_c_lent(v_text_2433, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str9), 2))) {
    heff_drop(v_kind_2432);
    heff_drop(v_text_2433);
    heff_clo_take(self, 4);
    V v_o_2434 = v_x_242;
    V v_r_2435 = v_x_2428;
    V v_hd_2436 = v_hd_243;
    V v_k_2437 = v_k_244;
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2436), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15, 1, 4, (V[]){v_hd_2436, v_o_2434, v_r_2435, v_k_2437})));
  } else {
    heff_drop(v_kind_2432);
    heff_drop(v_text_2433);
    V v_sep_2446 = ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str12);
    heff_clo_take(self, 4);
    V v_items_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2428, NTAG(TAG_Nil)});
    V v_seps_2448 = NTAG(TAG_Nil);
    V v_hd_2449 = heff_dup(v_hd_243);
    V v_k_2455 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam19, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){v_t_2456}));
    V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
    heff_room[0] = v_t_2457;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam21, 1, 5, (V[]){v_sep_2446, v_hd_2449, v_items_2447, v_seps_2448, v_k_2455});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2429}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14, 1, 4, (V[]){v_x_242, v_x_2428, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_kind_248 = heff_env(self)[0];
  V v_text_249 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str0), 2) && heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str1), 2))) {
    heff_drop_rec(v_x_2414, 9);
    heff_clo_take(self, 5);
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_kind_248);
    if (heff_strEq_c(v_text_249, ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str4))) {
      heff_drop_rec(v_x_2414, 9);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9, 1, 2, (V[]){v_x_242, v_k_244})));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2414, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str5))) {
        return (g_heff_2esyntax_2ecst_2esettingF_24s1757998429x401865903(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      } else {
        return (g_heff_2esyntax_2ecst_2edefaultedF_24s1606802912x1330557668(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_kind_248 = heff_take_field(v_x_247, 0);
  V v_text_249 = heff_get_n(v_x_247, 1, 9);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2412}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4, 1, 5, (V[]){v_kind_248, v_text_249, v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_hd_244) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam0, 1, 5, (V[]){v_hd_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2413, v_x_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_x_246, v_t_2415));
  V v_x_2417 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_x_2417}), v_lit_241});
  return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(v_t_2418, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 14)), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam5, 1, 7, (V[]){v_x_2413, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_kind_2410 = heff_env(self)[0];
  V v_text_2411 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  if (((heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 16)) == NTAG(TAG_True)) && ((heff_strEq_c_lent(v_kind_2410, ((V)&g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str0), 2) && heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_str1), 2)) && !(heff_dup(v_x_2412) == NTAG(TAG_True))))) {
    heff_drop(v_x_2412);
    heff_clo_take(self, 9);
    heff_drop(v_kind_2410);
    heff_drop(v_text_2411);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam4, 1, 7, (V[]){v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
  } else {
    heff_drop(v_x_2412);
    heff_clo_take(self, 9);
    heff_drop(v_kind_2410);
    heff_drop(v_text_2411);
    heff_drop_rec(v_hd_244, 3);
    V v_t_2421;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Nil: {
      v_t_2421 = v_x_245;
      break;
    }
    case TAG_Cons: {
      v_t_2421 = heff_tag_n(TAG_App, 2, (V[]){v_x_245, v_x_246});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_240, v_t_2421}), v_lit_241});
    return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(v_t_2422, v_lit_242, v_lit_243));
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_kind_2410 = heff_take_field(v_x_249, 0);
  V v_text_2411 = heff_get_n(v_x_249, 1, 9);
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam3, 1, 9, (V[]){v_kind_2410, v_text_2411, v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam2, 1, 7, (V[]){v_hd_244, v_x_246, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_lam1, 1, 6, (V[]){v_hd_244, v_x_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str1, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str2, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str3, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_248});
  V f_ = v_k_244;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2416;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkSep: {
    V v_items_2414 = heff_field(v_x_2412, 0);
    V v_seps_2415 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 3ULL, 2);
    v_t_2416 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, v_items_2414, v_seps_2415, v_x_2413});
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_k_244;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str3), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam6, 1, 3, (V[]){v_x_2412, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
  heff_clo_take(self, 3);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str2); V a_1 = v_t_2411; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_243); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam5, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str0))) {
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_str1), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam3, 1, 2, (V[]){v_x_242, v_k_244})));
  } else {
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam4, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  }
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str2, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str3, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str4, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str5, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str7, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str8, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str9, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str10, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str11, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str12, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str13, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str14, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str15, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str16, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str17, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str18, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str19, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str20, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str21, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str22, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str24, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str25, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str26, 4, "lazy");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str27, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str29, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str30, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str31, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str32, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str33, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str34, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str35, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str36, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str37, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str39, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V v_t_240, V v_z_241, V v_z_242) {
top: ;
  V v_kind_243 = heff_take_field(v_t_240, 0);
  V v_text_244 = heff_take_field(v_t_240, 1);
  V v_start_245 = heff_take_field(v_t_240, 3);
  V v_end_246 = heff_get_n(v_t_240, 4, 9);
  V v_t_2411;
  if ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str0), 2) || (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str1), 2) || (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str2), 2) || (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str3), 2) || (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str4), 2) || heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str5), 2))))))) {
    v_t_2411 = NTAG(TAG_True);
  } else {
    if (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str6), 2)) {
      if ((heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str7), 2) || (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str8), 2) || (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str9), 2) || (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str10), 2) || (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str11), 2) || (heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str12), 2) || heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str13), 2)))))))) {
        v_t_2411 = NTAG(TAG_True);
      } else {
        HeffT2 v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str14); V a_1 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str15); V a_2 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str16); V a_3 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str17); V a_4 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str18); V a_5 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str19); V a_6 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str20); V a_7 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str21); V a_8 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str22); V a_9 = v_text_244; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          v_t_2411 = heff_bool(((v_tag_248 == ((int64_t)0ULL)) && ({ V v_x_2410 = heff_dup(v_field_249); int c_ = 1; heff_drop(v_x_2410); c_; })));
          heff_drop(v_field_249);
        }
      }
    } else {
      v_t_2411 = NTAG(TAG_False);
    }
  }
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_kind_243);
    heff_drop(v_text_244);
    heff_drop(v_start_245);
    heff_drop(v_end_246);
    heff_drop(v_t_2411);
    return (g_heff_2esyntax_2ecst_2enext(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0, 1, 1, (V[]){v_z_242})));
  } else {
    heff_drop(v_t_2411);
    if ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str23), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str24), 2))) {
      heff_drop(v_kind_243);
      heff_drop(v_text_244);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      return (g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(v_z_241, v_z_242));
    } else {
      if (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str25), 2)) {
        heff_drop(v_kind_243);
        heff_drop(v_text_244);
        heff_drop(v_start_245);
        heff_drop(v_end_246);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1, 1, 2, (V[]){v_z_241, v_z_242})));
      } else {
        if (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str26), 2)) {
          heff_drop(v_kind_243);
          heff_drop(v_text_244);
          heff_drop(v_start_245);
          heff_drop(v_end_246);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3, 1, 2, (V[]){v_z_241, v_z_242})));
        } else {
          if ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str27), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str28), 2))) {
            heff_drop(v_kind_243);
            heff_drop(v_text_244);
            heff_drop(v_start_245);
            heff_drop(v_end_246);
            return (g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(v_z_241, v_z_242));
          } else {
            if ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str29), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str30), 2))) {
              heff_drop(v_kind_243);
              heff_drop(v_text_244);
              heff_drop(v_start_245);
              heff_drop(v_end_246);
              return (g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(v_z_241, v_z_242));
            } else {
              if ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str31), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str32), 2))) {
                heff_drop(v_kind_243);
                heff_drop(v_text_244);
                heff_drop(v_start_245);
                heff_drop(v_end_246);
                HEFF_LAST return g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0)), v_z_241, v_z_242);
              } else {
                if ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str33), 2) && heff_strEq_c_lent(v_text_244, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str34), 2))) {
                  heff_drop(v_kind_243);
                  heff_drop(v_text_244);
                  heff_drop(v_start_245);
                  heff_drop(v_end_246);
                  return (g_heff_2esyntax_2ecst_2elistOfF_24s1941325751x229839011(v_z_241, v_z_242));
                } else {
                  V v_span_2417 = heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246});
                  V v_t_2418;
                  if (heff_strEq_c(v_kind_243, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str35))) {
                    heff_drop(v_text_244);
                    v_t_2418 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str36);
                  } else {
                    v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str37), v_text_244), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str38));
                  }
                  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str39), v_t_2418), v_span_2417, NTAG(TAG_Nothing)});
                  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
                  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_z_241, 2), 1, (V[]){v_t_2420}));
                  return heff_tail(heff_get_n(v_z_241, 1, 3), 2, (V[]){v_t_2421, v_z_242});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_ENeg, 2, (V[]){v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2, 1, 2, (V[]){v_z_242, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_ETilde, 2, (V[]){v_x_2415, v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam4, 1, 2, (V[]){v_z_242, v_x_2415})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_245, v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5, 1, 3, (V[]){v_k_241, v_x_245, v_x_2412})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_text_249 = heff_env(self)[0];
  V v_kind_2410 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  if ((heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str0), 2) && (heff_strEq_c_lent(v_kind_2410, ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str1), 2) && !(heff_dup(v_x_2411) == NTAG(TAG_True))))) {
    heff_drop(v_x_2411);
    heff_clo_take(self, 5);
    heff_drop(v_text_249);
    heff_drop(v_kind_2410);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_245})));
  } else {
    heff_drop(v_x_2411);
    heff_clo_take(self, 5);
    heff_drop(v_text_249);
    heff_drop(v_kind_2410);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_245;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_text_249 = heff_take_field(v_x_248, 1);
  V v_kind_2410 = heff_get_n(v_x_248, 0, 9);
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3, 1, 5, (V[]){v_text_249, v_kind_2410, v_hd_240, v_k_241, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(v_x_244, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprimitiveDecl_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprimitiveDecl_str1, 20, "the primitive's name");
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eprimitiveDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eprimitiveDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eprimitiveDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_247 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_247, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eprimitiveDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DPrimitive, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3, 1, 4, (V[]){v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eprimitiveDecl_str0); V a_1 = ((V)&g_heff_2esyntax_2ecst_2eprimitiveDecl_str1); V a_2 = heff_dup(v_hd_240); V a_3 = heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243}); V r_ = (g_heff_2esyntax_2ecst_2eexpectKind(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigName_str0, 53, "a signature's names are `f`, `C` or `(+)`: `f, g : T`");
V g_heff_2esyntax_2ecst_2esigName_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigName_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigName_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2esigName_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigName_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigName_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2esigName_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigName_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esigName_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigName_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esigName(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2esigName_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2esigName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigName(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esigName_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_245, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_245, v_t_246));
}
V g_heff_2esyntax_2ecst_2esigName_lam3(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_s_2410, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2410, v_t_2411));
}
V g_heff_2esyntax_2ecst_2esigName_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_t_2415 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_x_244), heff_dup(v_x_249), heff_dup(v_x_2414)));
  if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
    heff_drop(v_x_2414);
    heff_clo_take(self, 4);
    heff_drop(v_x_249);
    V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2esigName_str0), v_t_2416, NTAG(TAG_Nothing)});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2418}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2419;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 4);
    V v_t_2420 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_x_244, v_x_249, v_x_2414));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2420, v_hd_240, v_k_241));
  }
}
V g_heff_2esyntax_2ecst_2esigName_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigName_lam3_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2412}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigName_lam4, 1, 4, (V[]){v_x_244, v_x_249, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigName_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigName_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigName_lam2, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2esigName(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_248, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2410, v_t_2411});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}