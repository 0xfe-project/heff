// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayLength 32493
#define TAG_At 8900
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CDrop 58400
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_CondRelU 46269
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_JString 41091
#define TAG_Many 40086
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_RDup 30328
#define TAG_RPrim 49376
#define TAG_RUnbox 59387
#define TAG_RepInt 62369
#define TAG_Rest 61983
#define TAG_SBytes 19273
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_Some 35658
#define TAG_Unreached 46435
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_WordLe 48792
#define LBL_again 294104954
#define LBL_alias 294261354
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_by 9918
#define LBL_code 9554612
#define LBL_deps 9575179
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_from 9647217
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_path 9928940
#define LBL_read 9991773
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tested 1069972444
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2edocpages_2efirstParagraph(V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo;
V g_heff_2ebuild_2edocpages_2eheaderComment(V);
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo;
HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1128783263x249153925(V, V);
V g_list_2eany_24s1128783263x249153925_entry(V self, V *a);
extern Clo g_list_2eany_24s1128783263x249153925_clo;
V g_list_2eany_24s1435008228x557204311(V, V);
V g_list_2eany_24s1435008228x557204311_entry(V self, V *a);
extern Clo g_list_2eany_24s1435008228x557204311_clo;
V g_list_2eany_24s1690524253x1144193326(V, V);
V g_list_2eany_24s1690524253x1144193326_entry(V self, V *a);
extern Clo g_list_2eany_24s1690524253x1144193326_clo;
V g_list_2eany_24s1795474228x706402294(V, V);
V g_list_2eany_24s1795474228x706402294_entry(V self, V *a);
extern Clo g_list_2eany_24s1795474228x706402294_clo;
V g_list_2eany_24s1946659387x922023683(V, V);
V g_list_2eany_24s1946659387x922023683_entry(V self, V *a);
extern Clo g_list_2eany_24s1946659387x922023683_clo;
V g_list_2eany_24s280395686x983781620(V);
V g_list_2eany_24s280395686x983781620_entry(V self, V *a);
extern Clo g_list_2eany_24s280395686x983781620_clo;
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
V g_list_2ecollapse_24s1005822741x724228783(V, V, V, V);
V g_list_2ecollapse_24s1005822741x724228783_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1005822741x724228783_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1922266401x1990263591(V, V);
V g_list_2efoldl_24s1922266401x1990263591_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1922266401x1990263591_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
HeffT2 g_list_2efoldl_24s509733942x1507005169_24scalars_24cpr(V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s14815453x1234467625_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s14815453x1234467625_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s14815453x1234467625_24dps_clo;
V g_list_2ekeepIf_24s1491357071x1050483543(V, V);
V g_list_2ekeepIf_24s1491357071x1050483543_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1491357071x1050483543_clo;
V g_list_2ekeepIf_24s1491357071x1050483543_24dps(V, V, V);
V g_list_2ekeepIf_24s1491357071x1050483543_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1491357071x1050483543_24dps_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s1943838498x1969994910_24dps(V, V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_24dps_clo;
V g_list_2ekeepIf_24s924780574x2000457388_24dps(V, V, V);
V g_list_2ekeepIf_24s924780574x2000457388_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_24dps_clo;
V g_list_2emap_24f1050596570x1917004924_24dps(V, V, V, V);
V g_list_2emap_24f1050596570x1917004924_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1050596570x1917004924_24dps_clo;
V g_list_2emap_24s1134414872x1001811115_24dps(V, V);
V g_list_2emap_24s1134414872x1001811115_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1134414872x1001811115_24dps_clo;
V g_list_2emap_24s1173914895x100384474_24dps(V, V);
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24dps_clo;
V g_list_2emap_24s1289827711x943898099_24dps(V, V);
V g_list_2emap_24s1289827711x943898099_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1289827711x943898099_24dps_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s129316455x2072694707_24dps(V, V);
V g_list_2emap_24s129316455x2072694707_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_24dps_clo;
V g_list_2emap_24s1368853467x919806006(V);
V g_list_2emap_24s1368853467x919806006_entry(V self, V *a);
extern Clo g_list_2emap_24s1368853467x919806006_clo;
V g_list_2emap_24s1368853467x919806006_24dps(V, V);
V g_list_2emap_24s1368853467x919806006_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1368853467x919806006_24dps_clo;
V g_list_2emap_24s1455783996x1449538216_24dps(V, V);
V g_list_2emap_24s1455783996x1449538216_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_24dps_clo;
V g_list_2emap_24s1531069132x955165792(V);
V g_list_2emap_24s1531069132x955165792_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_clo;
V g_list_2emap_24s1531069132x955165792_24dps(V, V);
V g_list_2emap_24s1531069132x955165792_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_24dps_clo;
V g_list_2emap_24s1792553290x233563724_24dps(V, V);
V g_list_2emap_24s1792553290x233563724_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_24dps_clo;
V g_list_2emap_24s1796125103x644876049_24dps(V, V);
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24dps_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1817208647x1282894070_24dps(V, V);
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_24dps_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s1901363476x1479927424_24dps(V, V);
V g_list_2emap_24s1901363476x1479927424_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_24dps_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s2029999044x514618413_24dps(V, V);
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_24dps_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s338694954x1326523169_24dps(V, V);
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_24dps_clo;
V g_list_2emap_24s391650521x1406868658(V);
V g_list_2emap_24s391650521x1406868658_entry(V self, V *a);
extern Clo g_list_2emap_24s391650521x1406868658_clo;
V g_list_2emap_24s391650521x1406868658_24dps(V, V);
V g_list_2emap_24s391650521x1406868658_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391650521x1406868658_24dps_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s435407392x1528135477_24dps(V, V);
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_24dps_clo;
V g_list_2emap_24s45270243x110012769_24dps(V, V);
V g_list_2emap_24s45270243x110012769_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_24dps_clo;
V g_list_2emap_24s501902900x1631592417(V, V, V, V);
V g_list_2emap_24s501902900x1631592417_entry(V self, V *a);
extern Clo g_list_2emap_24s501902900x1631592417_clo;
V g_list_2emap_24s501902900x1631592417_24dps(V, V, V, V, V);
V g_list_2emap_24s501902900x1631592417_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s501902900x1631592417_24dps_clo;
V g_list_2emap_24s60612435x257154841_24dps(V, V);
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_24dps_clo;
V g_list_2emap_24s631322900x900609068_24dps(V, V);
V g_list_2emap_24s631322900x900609068_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_24dps_clo;
V g_list_2emap_24s723912745x1713553694_24dps(V, V);
V g_list_2emap_24s723912745x1713553694_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2epushRun_24s1176995660x590208736(V, V, V, V, V);
V g_list_2epushRun_24s1176995660x590208736_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1176995660x590208736_clo;
V g_list_2ezipWith_24s1026658656x682908126(V, V);
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_clo;
V g_list_2ezipWith_24s1026658656x682908126_24dps(V, V, V);
V g_list_2ezipWith_24s1026658656x682908126_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_24dps_clo;
V g_list_2ezipWith_24s511663487x682582558(V, V, V, V);
V g_list_2ezipWith_24s511663487x682582558_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s511663487x682582558_clo;
V g_list_2ezipWith_24s511663487x682582558_24dps(V, V, V, V, V);
V g_list_2ezipWith_24s511663487x682582558_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s511663487x682582558_24dps_clo;
V g_list_2ezipWith_24s952564628x174753269_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2emap_24s1173914895x100384474_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_24dps_entry, 2, 0};

V g_list_2emap_24s1173914895x100384474_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_243;
    V t_1 = v_u_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1173914895x100384474_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1289827711x943898099_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1289827711x943898099_24dps_entry, 2, 0};

V g_list_2emap_24s1289827711x943898099_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2eelab_2eprimitive_2eprimName(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_x_242}), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1289827711x943898099_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1289827711x943898099_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s445268946x679229867_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s445268946x679229867_entry, 2, 0};

V g_list_2efoldl_24s445268946x679229867(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_m_244 = v_z_240;
    V v_d_245 = heff_dup(v_x_242);
    V v_body_246 = heff_take_field(v_d_245, 2);
    V v_key_247 = heff_get_n(v_d_245, 0, 3);
    V v_t_248 = v_body_246;
    V v_t_2449;
    switch (heff_tag_of(v_t_248)) {
    case TAG_EVar: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ELam: {
      V v_xs_2411 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 2);
      V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      v_t_2449 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_key_247, v_t_2413));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_248, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_248, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_248, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_248, 0ULL, 4);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_248, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_248, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_248, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_248, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_248, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_t_248, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_248, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V t_0 = v_t_2449;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s445268946x679229867(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1026658656x682908126_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1026658656x682908126_entry, 2, 0};

V g_list_2ezipWith_24s1026658656x682908126(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2eranges_2ejoin(v_x_242, v_y_244));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1026658656x682908126_24dps(v_xs_243, v_ys_245, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1026658656x682908126(a[0], a[1]);
}
Clo g_list_2emap_24s1792553290x233563724_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1792553290x233563724_24dps_entry, 2, 0};

V g_list_2emap_24s1792553290x233563724_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Unreached), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1792553290x233563724_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1792553290x233563724_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s565534491x447967237_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s565534491x447967237_entry, 2, 0};

V g_list_2eany_24s565534491x447967237(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(v_x_242))) {
      heff_drop_rec(v_lit_240, 9);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s565534491x447967237_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s565534491x447967237(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s338694954x1326523169_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s338694954x1326523169_entry, 1, 0};

V g_list_2emap_24s338694954x1326523169(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_msg_243 = heff_take_field(v_x_241, 2);
    V v_start_244 = heff_take_field(v_x_241, 0);
    V v_end_245 = heff_get_n(v_x_241, 1, 3);
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_243, heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s338694954x1326523169_24dps(v_xs_242, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s338694954x1326523169(a[0]);
}
Clo g_list_2emap_24s1531069132x955165792_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531069132x955165792_entry, 1, 0};

V g_list_2emap_24s1531069132x955165792(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1531069132x955165792_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531069132x955165792_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1531069132x955165792(a[0]);
}
Clo g_list_2emap_24s60612435x257154841_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_24dps_entry, 2, 0};

V g_list_2emap_24s60612435x257154841_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s60612435x257154841_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1651310864x859456474_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1651310864x859456474_entry, 2, 0};

V g_list_2efoldl_24s1651310864x859456474(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1651310864x859456474(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1128783263x249153925_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1128783263x249153925_entry, 2, 0};

V g_list_2eany_24s1128783263x249153925(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_lit_240, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c_lent(v_t_246, v_x_242, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1128783263x249153925_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1128783263x249153925(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1548442597x958354846_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1548442597x958354846_entry, 2, 0};

V g_list_2efoldl_24s1548442597x958354846(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1548442597x958354846(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1901363476x1479927424_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1901363476x1479927424_entry, 1, 0};

V g_list_2emap_24s1901363476x1479927424(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_241, NTAG(TAG_Nothing)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_t_243}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1901363476x1479927424_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1901363476x1479927424(a[0]);
}
Clo g_list_2efoldl_24s1922266401x1990263591_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1922266401x1990263591_entry, 2, 0};

V g_list_2efoldl_24s1922266401x1990263591(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_n_244 = v_x_242;
    V v_tested_245 = heff_take_field(v_n_244, 1);
    V v_read_246 = heff_get_n(v_n_244, 2, 4);
    V v_t_2415;
    if (heff_strEq_c_lent(v_tested_245, v_read_246, 0)) {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_tested_245);
      heff_drop(v_read_246);
      v_t_2415 = NTAG(TAG_Nil);
    } else {
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_RDup, 1, (V[]){v_tested_245}), NTAG(TAG_Nil)});
      V v_t_248 = heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayLength), v_t_247});
      V v_t_249 = heff_tag_n(TAG_RUnbox, 2, (V[]){NTAG(TAG_RepInt), v_t_248});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RDup, 1, (V[]){v_read_246}), NTAG(TAG_Nil)});
      V v_t_2411 = heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayLength), v_t_2410});
      V v_t_2412 = heff_tag_n(TAG_RUnbox, 2, (V[]){NTAG(TAG_RepInt), v_t_2411});
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_CondRelU, 2, (V[]){NTAG(TAG_WordLe), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2413})});
      v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
    }
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2415, v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1922266401x1990263591_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1922266401x1990263591(a[0], a[1]);
}
Clo g_list_2emap_24s45270243x110012769_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s45270243x110012769_24dps_entry, 2, 0};

V g_list_2emap_24s45270243x110012769_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s45270243x110012769_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s45270243x110012769_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1946659387x922023683_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1946659387x922023683_entry, 2, 0};

V g_list_2eany_24s1946659387x922023683(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 4);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_x_242))) {
      heff_drop_rec(v_lit_240, 4);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1946659387x922023683_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1946659387x922023683(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s924780574x2000457388_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s924780574x2000457388_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s924780574x2000457388_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_243)) {
    case TAG_UpdateTo: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_2413 = v_a_245;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_249 = heff_dup(heff_field(v_x_243, 0));
      v_t_2413 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_2413, v_lit_240, 1)) {
      V v_cell_2414 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_2415;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s924780574x2000457388_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s924780574x2000457388_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s391650521x1406868658_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391650521x1406868658_entry, 1, 0};

V g_list_2emap_24s391650521x1406868658(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s391650521x1406868658_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391650521x1406868658_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391650521x1406868658(a[0]);
}
Clo g_list_2ekeepIf_24s1491357071x1050483543_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1491357071x1050483543_entry, 2, 0};

V g_list_2ekeepIf_24s1491357071x1050483543(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = heff_bool((heff_strEq_c_lent(v_lit_240, v_a_244, 0) || heff_strEq_c_lent(v_lit_240, v_a_245, 0)));
      heff_drop(v_a_244);
      heff_drop(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (!(heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1491357071x1050483543_24dps(v_lit_240, v_xs_243, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1491357071x1050483543_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1491357071x1050483543(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s511663487x682582558_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s511663487x682582558_entry, 4, 0};

V g_list_2ezipWith_24s511663487x682582558(V v_lit_240, V v_lit_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_x3_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_t_248;
      if (heff_intEq_c_lent(v_x_244, v_lit_240, 1)) {
        heff_drop(v_y_246);
        v_t_248 = heff_dup(v_lit_241);
      } else {
        v_t_248 = v_y_246;
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = (g_list_2ezipWith_24s511663487x682582558_24dps(v_lit_240, v_lit_241, v_xs_245, v_ys_247, v_cell_249));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ezipWith_24s511663487x682582558_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s511663487x682582558(a[0], a[1], a[2], a[3]);
}

HeffT2 g_list_2efoldl_24s509733942x1507005169_24scalars_24cpr(V v_lit_240, V v_lit_241, V v_js_242, V v_env_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return ((HeffT2){{v_js_242, v_env_243}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_245), heff_dup(v_lit_240)));
    V v_t_248 = (g_heff_2ecompile_2eemit_2esafe(v_t_247));
    HeffT2 v_t_249 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(v_env_243, v_x_245, v_t_248, heff_dup(v_lit_241)));
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_t_2412 = heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){v_field_2410, NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(v_js_242, v_t_2412));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_2413;
      V t_3 = v_field_2411;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_js_242 = t_2;
      v_env_243 = t_3;
      v_x3_244 = t_4;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
  }
}
Clo g_list_2emap_24s1455783996x1449538216_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1455783996x1449538216_24dps_entry, 2, 0};

V g_list_2emap_24s1455783996x1449538216_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_244 = v_x_242;
    V v_t_2438;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_PartVal: {
      V v_x11_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24PartVal = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      switch (heff_tag_of(v_x11_245)) {
      case TAG_SVar: {
        heff_take_n(v_x11_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_247 = heff_field(v_x11_245, 0);
        heff_take_n(v_x11_245, 1ULL, 1);
        v_t_2438 = heff_tag_at_n(v_ru_24x1_244_24PartVal, TAG_Just, 1, (V[]){v_g_247});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_x11_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24PartVal, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_245);
      }
      break;
    }
    case TAG_PartOp: {
      V v_x11_2429 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24PartOp = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      switch (heff_tag_of(v_x11_2429)) {
      case TAG_OSimple: {
        heff_take_n(v_x11_2429, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartOp, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OCall: {
        V v_g_2431 = heff_field(v_x11_2429, 0);
        heff_take_n(v_x11_2429, 1ULL, 2);
        v_t_2438 = heff_tag_at_n(v_ru_24x1_244_24PartOp, TAG_Just, 1, (V[]){v_g_2431});
        break;
      }
      case TAG_OApply: {
        heff_take_n(v_x11_2429, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24PartOp, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OPrim: {
        heff_take_n(v_x11_2429, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24PartOp, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x1_244_24PartOp, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OBool: {
        heff_take_n(v_x11_2429, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24PartOp, 1);
        v_t_2438 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2429);
      }
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_cell_2439 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2438, heff_hole()});
    V v_u_2440 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2439);
    V t_0 = v_xs_243;
    V t_1 = v_u_2440;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1455783996x1449538216_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1455783996x1449538216_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s129316455x2072694707_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s129316455x2072694707_entry, 1, 0};

V g_list_2emap_24s129316455x2072694707(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_a_243), v_a_243});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s129316455x2072694707_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s129316455x2072694707(a[0]);
}
Clo g_list_2ezipWith_24s952564628x174753269_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s952564628x174753269_24dps_entry, 6, 0};

V g_list_2ezipWith_24s952564628x174753269_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs_247);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_x3_244, 0);
      V v_ys_249 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2410 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_y_248));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_lit_241)), v_x_246);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_245, MK_INT(1LL), v_cell_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_247;
      V t_4 = v_ys_249;
      V t_5 = v_u_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_x3_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s952564628x174753269_24dps_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_list_2ezipWith_24s952564628x174753269_24dps(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_list_2eany_24s280395686x983781620_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s280395686x983781620_entry, 1, 0};

V g_list_2eany_24s280395686x983781620(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_CInteger: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CDouble: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CBool: {
      return NTAG(TAG_True);
    }
    case TAG_CString: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CText: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_COwnedString: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CBytes: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_COwnedBytes: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CPointer: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CVoid: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s280395686x983781620_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s280395686x983781620(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1817208647x1282894070_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817208647x1282894070_entry, 1, 0};

V g_list_2emap_24s1817208647x1282894070(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1817208647x1282894070_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817208647x1282894070(a[0]);
}
Clo g_list_2emap_24s1368853467x919806006_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1368853467x919806006_entry, 1, 0};

V g_list_2emap_24s1368853467x919806006(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nil: {
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_PVar: {
        V v_ru_24a_243_24PVar = heff_take_reuse_n(v_a_243, 0ULL, 1);
        v_t_2416 = heff_tag_at_n(v_ru_24a_243_24PVar, TAG_Just, 1, (V[]){v_a_244});
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_a_243, 0ULL, 3);
        heff_drop(v_a_244);
        v_t_2416 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_a_243, 0ULL, 1);
        heff_drop(v_a_244);
        v_t_2416 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PRec: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop(v_a_244);
        v_t_2416 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PAs: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop(v_a_244);
        v_t_2416 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_a_243, 0ULL, 2);
        heff_drop(v_a_244);
        v_t_2416 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s1368853467x919806006_24dps(v_xs_242, v_cell_2417));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1368853467x919806006_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1368853467x919806006(a[0]);
}
Clo g_list_2emap_24s1134414872x1001811115_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1134414872x1001811115_24dps_entry, 2, 0};

V g_list_2emap_24s1134414872x1001811115_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 3), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1134414872x1001811115_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1134414872x1001811115_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2ekeepIf_24s14815453x1234467625_24dps_lam0(V self, V *args);
Clo g_list_2ekeepIf_24s14815453x1234467625_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s14815453x1234467625_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s14815453x1234467625_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_done_247 = heff_dup(v_lit_240);
    V v_imps_248 = heff_dup(v_lit_241);
    V v_c_249 = heff_dup(v_lit_242);
    V v_t_2410 = heff_dup(v_x_245);
    V v_again_2411 = heff_take_field(v_t_2410, 1);
    V v_first_2412 = heff_get_n(v_t_2410, 0, 2);
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_again_2411, 1)), 0, 14);
    V v_t_2435;
    if (heff_strEq_c(v_t_2413, heff_get_n(v_c_249, 0, 14))) {
      heff_drop(v_done_247);
      heff_drop_rec(v_imps_248, 4);
      heff_drop_rec(v_again_2411, 3);
      heff_drop_rec(v_first_2412, 3);
      v_t_2435 = NTAG(TAG_True);
    } else {
      V v_x1_2434 = ({ V a_0 = heff_clo_n(g_list_2ekeepIf_24s14815453x1234467625_24dps_lam0, 1, 3, (V[]){v_done_247, v_first_2412, v_again_2411}); V b_1 = heff_get_n(v_imps_248, 0, 4); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      v_t_2435 = heff_bool(!(heff_dup(v_x1_2434) == NTAG(TAG_True)));
      heff_drop(v_x1_2434);
    }
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_t_2435);
      V v_cell_2436 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
      V v_u_2437 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2436);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_u_2437;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_2435);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s14815453x1234467625_24dps_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2ekeepIf_24s14815453x1234467625_24dps(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_list_2ekeepIf_24s14815453x1234467625_24dps_lam0(V self, V *args) {
  V v_i_2414 = args[0];
  V v_done_247 = heff_env(self)[0];
  V v_first_2412 = heff_env(self)[1];
  V v_again_2411 = heff_env(self)[2];
  V v_t_2415 = heff_dup(heff_rfield(v_i_2414, 0));
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(v_done_247, v_t_2415));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_ys_2420;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_c_2419 = v_field_2418;
      v_ys_2420 = heff_get_n(v_c_2419, 8, 14);
    } else {
      heff_drop(v_field_2418);
      v_ys_2420 = NTAG(TAG_Nil);
    }
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    V v_t_2422 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_247, v_t_2421, v_ys_2420));
    heff_clo_take(self, 3);
    V v_t_2423 = heff_get_n(heff_get_n(v_first_2412, 1, 3), 0, 14);
    V v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = v_t_2422; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_2423); heff_drop(v_t_2422); r_; });
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_t_2424);
      V v_t_2425 = heff_get_n(v_i_2414, 0, 3);
      HeffT2 v_t_2426 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(v_done_247, v_t_2425));
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        V v_ys_2430;
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_c_2429 = v_field_2428;
          v_ys_2430 = heff_get_n(v_c_2429, 8, 14);
        } else {
          heff_drop(v_field_2428);
          v_ys_2430 = NTAG(TAG_Nil);
        }
        V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        V v_t_2432 = ({ V a_0 = v_done_247; V a_1 = v_t_2431; V a_2 = v_ys_2430; V r_ = (g_heff_2ebuild_2edriver_2eclosureGo(a_0, a_1, a_2)); heff_drop(v_done_247); r_; });
        V v_t_2433 = heff_get_n(heff_get_n(v_again_2411, 1, 3), 0, 14);
        return ({ V a_0 = v_t_2433; V a_1 = v_t_2432; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_2433); heff_drop(v_t_2432); r_; });
      }
    } else {
      heff_drop_rec(v_i_2414, 3);
      heff_drop(v_done_247);
      heff_drop_rec(v_again_2411, 3);
      heff_drop(v_t_2424);
      return NTAG(TAG_False);
    }
  }
}
V g_list_2ecollapse_24s1005822741x724228783_lam0(V self, V *args);
Clo g_list_2ecollapse_24s1005822741x724228783_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s1005822741x724228783_entry, 4, 0};

V g_list_2ecollapse_24s1005822741x724228783(V v_lit_240, V v_lit_241, V v_run_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_run_242;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_rest_245 = heff_field(v_x3_243, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_below_247 = heff_field(v_x31_244, 1);
      V v_t_2412 = (g_list_2emerge(heff_clo_n(g_list_2ecollapse_24s1005822741x724228783_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), heff_dup(v_below_247), v_run_242));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_2412;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_run_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2ecollapse_24s1005822741x724228783_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2ecollapse_24s1005822741x724228783(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_list_2ecollapse_24s1005822741x724228783_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_249 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_intSub(v_lit_240, heff_get_n(v_a_248, 0, 10));
  V v_t_2411 = heff_intSub(v_lit_241, heff_get_n(v_a_249, 0, 10));
  V v_ret_24bool = heff_bool(heff_intLe_c_lent(v_t_2410, v_t_2411, 0));
  heff_drop(v_t_2410);
  heff_drop(v_t_2411);
  return v_ret_24bool;
}
V g_list_2epushRun_24s1176995660x590208736_lam0(V self, V *args);
Clo g_list_2epushRun_24s1176995660x590208736_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s1176995660x590208736_entry, 5, 0};

V g_list_2epushRun_24s1176995660x590208736(V v_lit_240, V v_lit_241, V v_k_242, V v_run_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_244, 0);
    V v_rest_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_j_247 = heff_field(v_x41_245, 0);
      V v_below_248 = heff_field(v_x41_245, 1);
      V v_ru_24x41_245_24MkPair = heff_take_reuse_n(v_x41_245, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_247, v_k_242, 0)) {
        heff_drop_cell(v_ru_24x4_244_24Cons, 2);
        heff_drop(v_j_247);
        heff_drop_cell(v_ru_24x41_245_24MkPair, 2);
        V v_t_2412 = (g_list_2emerge(heff_clo_n(g_list_2epushRun_24s1176995660x590208736_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_below_248, v_run_243));
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
        V t_3 = v_t_2412;
        V t_4 = v_rest_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_k_242 = t_2;
        v_run_243 = t_3;
        v_x4_244 = t_4;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        V v_t_2413 = heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x41_245_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_j_247, v_below_248}), v_rest_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), v_t_2413});
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2epushRun_24s1176995660x590208736_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s1176995660x590208736(a[0], a[1], a[2], a[3], a[4]);
}
V g_list_2epushRun_24s1176995660x590208736_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_a_2411 = heff_strCompare(v_a_249, v_a_2410);
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2411, v_lit_240, 0) || heff_intEq_c_lent(v_a_2411, v_lit_241, 0)));
  heff_drop(self);
  heff_drop(v_a_2411);
  return v_ret_24bool;
}
Clo g_list_2ekeepIf_24s1943838498x1969994910_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1943838498x1969994910_entry, 2, 0};

V g_list_2ekeepIf_24s1943838498x1969994910(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1943838498x1969994910_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1943838498x1969994910(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s435407392x1528135477_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s435407392x1528135477_entry, 1, 0};

V g_list_2emap_24s435407392x1528135477(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s435407392x1528135477_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s435407392x1528135477(a[0]);
}
Clo g_list_2eany_24s1690524253x1144193326_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1690524253x1144193326_entry, 2, 0};

V g_list_2eany_24s1690524253x1144193326(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 2);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1690524253x1144193326_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1690524253x1144193326(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1975553568x1034350329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1975553568x1034350329_entry, 2, 0};

V g_list_2efoldl_24s1975553568x1034350329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1975553568x1034350329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s723912745x1713553694_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s723912745x1713553694_24dps_entry, 2, 0};

V g_list_2emap_24s723912745x1713553694_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s723912745x1713553694_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s723912745x1713553694_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str0, 1, ".");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str1, 1, ".");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str3, 1, "/");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str6, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str7, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str9, 1, " ");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str10, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str11, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str12, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str13, 1, " ");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str14, 2, ": ");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str15, 4, "- [`");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str16, 3, "`](");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str17, 3, ".md");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str18, 1, ")");
HEFF_LIT(g_list_2emap_24s631322900x900609068_24dps_str19, 1, "\012");
Clo g_list_2emap_24s631322900x900609068_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s631322900x900609068_24dps_entry, 2, 0};

V g_list_2emap_24s631322900x900609068_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_c_244 = v_x_242;
    V v_module_245 = heff_take_field(v_c_244, 0);
    V v_source_246 = heff_get_n(v_c_244, 3, 14);
    V v_m_247 = heff_dup(v_module_245);
    V v_x2_248 = ({ V a_0 = v_m_247; V b_1 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2emap_24s631322900x900609068_24dps_str1), v_m_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_m_247); heff_drop(b_1); r_; });
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = (g_heff_2ebuild_2edocpages_2eheaderComment(v_source_246));
    V v_t_2429;
    if (heff_strEq_c(v_t_2412, ((V)&g_list_2emap_24s631322900x900609068_24dps_str4))) {
      heff_drop(v_source_246);
      v_t_2429 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str5);
    } else {
      V v_header_2413 = ({ V a_0 = v_source_246; V r_ = (g_heff_2ebuild_2edocpages_2eheaderComment(a_0)); heff_drop(v_source_246); r_; });
      V v_t_2414 = ({ V a_0 = v_header_2413; V b_1 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2emap_24s631322900x900609068_24dps_str7), v_header_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_x2_2415 = (g_heff_2ebuild_2edocpages_2efirstParagraph(v_t_2414));
      V v_s_2418;
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nil: {
        v_s_2418 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_xs_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        v_s_2418 = ({ V a_0 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str9); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
      V v_t_2419 = ({ V a_0 = v_header_2413; V b_1 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str10); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2emap_24s631322900x900609068_24dps_str11), v_header_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_header_2413); heff_drop(b_1); r_; });
      V v_x2_2420 = (g_heff_2ebuild_2edocpages_2efirstParagraph(v_t_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_list_2emap_24s631322900x900609068_24dps_str13); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      HeffT2 v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        V v_t_2428;
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_i_2427 = v_field_2426;
          v_t_2428 = heff_strSlice(v_s_2418, MK_INT(0LL), heff_intAdd(v_i_2427, MK_INT(1LL)));
        } else {
          heff_drop(v_field_2426);
          v_t_2428 = v_s_2418;
        }
        v_t_2429 = heff_strAppend(((V)&g_list_2emap_24s631322900x900609068_24dps_str14), v_t_2428);
      }
    }
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s631322900x900609068_24dps_str15), v_module_245), ((V)&g_list_2emap_24s631322900x900609068_24dps_str16));
    V v_t_2431 = heff_strAppend(v_t_2430, heff_strAppend(v_t_2411, ((V)&g_list_2emap_24s631322900x900609068_24dps_str17)));
    V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_list_2emap_24s631322900x900609068_24dps_str18)), v_t_2429);
    V v_cell_2433 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2432, ((V)&g_list_2emap_24s631322900x900609068_24dps_str19)), heff_hole()});
    V v_u_2434 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2433);
    V t_0 = v_xs_243;
    V t_1 = v_u_2434;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s631322900x900609068_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s631322900x900609068_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1435008228x557204311_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1435008228x557204311_entry, 2, 0};

V g_list_2eany_24s1435008228x557204311(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1435008228x557204311_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1435008228x557204311(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1795474228x706402294_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1795474228x706402294_entry, 2, 0};

V g_list_2eany_24s1795474228x706402294(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1795474228x706402294_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1795474228x706402294(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str3, 4, "...]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str4, 3, "...");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str5, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str6, 4, "...]");
Clo g_list_2emap_24s2029999044x514618413_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_entry, 1, 0};

V g_list_2emap_24s2029999044x514618413(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_meta_243 = heff_take_field(v_x_241, 0);
    V v_arity_244 = heff_get_n(v_x_241, 1, 3);
    V v_m_245 = v_meta_243;
    V v_t_246 = v_arity_244;
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_One: {
      v_t_247 = v_m_245;
      break;
    }
    case TAG_Optional: {
      v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str0), v_m_245), ((V)&g_list_2emap_24s2029999044x514618413_str1));
      break;
    }
    case TAG_Many: {
      v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str2), v_m_245), ((V)&g_list_2emap_24s2029999044x514618413_str3));
      break;
    }
    case TAG_Some: {
      v_t_247 = heff_strAppend(v_m_245, ((V)&g_list_2emap_24s2029999044x514618413_str4));
      break;
    }
    case TAG_Rest: {
      v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str5), v_m_245), ((V)&g_list_2emap_24s2029999044x514618413_str6));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s2029999044x514618413_24dps(v_xs_242, v_cell_248));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413(a[0]);
}
Clo g_list_2emap_24s501902900x1631592417_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s501902900x1631592417_entry, 4, 0};

V g_list_2emap_24s501902900x1631592417(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412;
    if (heff_strEq_c_lent(v_a_2411, v_lit_240, 0)) {
      heff_drop(v_a_2411);
      v_t_2412 = v_a_248;
    } else {
      v_t_2412 = heff_strAppend(heff_strAppend(v_a_248, heff_dup(v_lit_241)), v_a_2411);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2414 = (g_list_2emap_24s501902900x1631592417_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, v_cell_2413));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s501902900x1631592417_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s501902900x1631592417(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f1050596570x1917004924_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1050596570x1917004924_24dps_entry, 4, 0};

V g_list_2emap_24f1050596570x1917004924_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_module_246 = heff_take_field(v_x_244, 0);
    V v_alias_247 = heff_get_n(v_x_244, 1, 2);
    if (heff_strEq_c_lent(v_module_246, v_lit_241, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_alias_247, heff_dup(v_lit_240)), heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_u_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_alias_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1050596570x1917004924_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_list_2emap_24f1050596570x1917004924_24dps(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24s1796125103x644876049_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1796125103x644876049_24tok1_entry, 2, 0};

V g_list_2emap_24s1796125103x644876049_24tok1(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_CDrop, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1796125103x644876049_24dps(v_xs_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1796125103x644876049_24tok1(a[0], a[1]);
}