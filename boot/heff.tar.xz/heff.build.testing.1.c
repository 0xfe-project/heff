// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Collected 38917
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_GetEnv 43934
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_MkWith 3751
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_Processors 11008
#define TAG_RealPath 18882
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Value 50841
#define TAG_Wait 10206
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alias 294261354
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_implicit 319715269
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_loaded 849622832
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_program 2069953735
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_wrong 314763719
static uint32_t shape_at__pending__launch[] = {LBL_at, LBL_pending, LBL_launch};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_program__env[] = {LBL_program, LBL_env};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s199044798x1745934964(V, V, V, V);
V g_co_2eop_24s199044798x1745934964_entry(V self, V *a);
extern Clo g_co_2eop_24s199044798x1745934964_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_clo;
V g_heff_2ebuild_2edriver_2etestsOf(V);
V g_heff_2ebuild_2edriver_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestsOf_clo;
V g_heff_2ebuild_2etesting_2ebrokenJob(V, V);
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo;
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_clo;
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562_clo;
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void);
V g_heff_2ebuild_2etesting_2ejsonFailure(V);
V g_heff_2ebuild_2etesting_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_clo;
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V, V);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo;
V g_heff_2ebuild_2etesting_2elastLines(V, V);
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elastLines_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1(V, V, V);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_clo;
V g_heff_2ebuild_2etesting_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2etesting_2epassedOver(V, V);
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2epassedOver_clo;
HeffT2 g_heff_2ebuild_2etesting_2equalifierOf_24cpr(V);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_clo;
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_clo;
V g_heff_2ebuild_2etesting_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2etesting_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranOutcome_clo;
V g_heff_2ebuild_2etesting_2etestDir(V, V);
V g_heff_2ebuild_2etesting_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestDir_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_clo;
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(V, V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
HeffT2 g_json_2eat_24cpr(V, V);
HeffT2 g_json_2esteps_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s595925281x993936542_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1113395621x248103432(V);
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_clo;
V g_list_2emap_24s1681408447x1763680441(V, V, V);
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_list_2emap_24s2029356170x1054793697(V);
V g_list_2emap_24s2029356170x1054793697_entry(V self, V *a);
extern Clo g_list_2emap_24s2029356170x1054793697_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2elevelsOf_2ecut_240(V, V, V, V, V, V);
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a);
extern Clo g_regex_2elevelsOf_2ecut_240_clo;
V g_std_2efilesystem_2efromSystem_24s1965754558x142330605(V, V, V);
V g_std_2efilesystem_2efromSystem_24s1965754558x142330605_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s1965754558x142330605_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(V, V, V);
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2etesting_2equalifierOf_24cpr_str0, 5, "check");
HEFF_LIT(g_heff_2ebuild_2etesting_2equalifierOf_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2equalifierOf_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2etesting_2equalifierOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_name_243 = heff_dup(heff_rfield(v_i_241, 0));
    V v_alias_244 = heff_dup(heff_rfield(v_i_241, 1));
    if (heff_strEq_c(v_name_243, ((V)&g_heff_2ebuild_2etesting_2equalifierOf_24cpr_str0))) {
      V v_f_246;
      switch (heff_tag_of(v_alias_244)) {
      case TAG_Nothing: {
        v_f_246 = ((V)&g_heff_2ebuild_2etesting_2equalifierOf_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_245 = heff_field(v_alias_244, 0);
        heff_take_n(v_alias_244, 1ULL, 1);
        v_f_246 = heff_strAppend(v_alias_245, ((V)&g_heff_2ebuild_2etesting_2equalifierOf_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_alias_244);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_alias_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str0, 33, "took longer than its time limit, ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str1, 11, " ms: killed");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str2, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str3, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str4, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str7, 9, "not run: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str8, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str9, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str12, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranOutcome_str13, 45, "what it said of how it went could not be read");
Clo g_heff_2ebuild_2etesting_2eranOutcome_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranOutcome_entry, 4, 0};

V g_heff_2ebuild_2etesting_2eranOutcome(V v_name_240, V v_limit_241, V v_r_242, V v_said_243) {
top: ;
  V v_ended_244 = heff_take_field(v_r_242, 0);
  V v_err_245 = heff_get_n(v_r_242, 2, 3);
  switch (heff_tag_of(v_ended_244)) {
  case TAG_TimedOut: {
    heff_drop(v_said_243);
    heff_drop(v_err_245);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranOutcome_str0), heff_intShow(v_limit_241));
    V v_t_247 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2etesting_2eranOutcome_str1))});
    return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_247}), MK_INT(0LL), NTAG(TAG_Nil)});
  }
  default: {
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2416;
      switch (heff_tag_of(v_ended_244)) {
      case TAG_Exited: {
        V v_n_248 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranOutcome_str2), heff_intShow(v_n_248));
        break;
      }
      case TAG_Signalled: {
        V v_n_249 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranOutcome_str3), heff_intShow(v_n_249));
        break;
      }
      case TAG_TimedOut: {
        v_t_2416 = ((V)&g_heff_2ebuild_2etesting_2eranOutcome_str4);
        break;
      }
      case TAG_NotRun: {
        V v_err_2410 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        V v_path_2411 = heff_take_field(v_err_2410, 3);
        V v_name_2412 = heff_take_field(v_err_2410, 1);
        V v_message_2413 = heff_get_n(v_err_2410, 2, 4);
        V v_t_2414 = heff_strAppend(heff_strAppend(v_path_2411, ((V)&g_heff_2ebuild_2etesting_2eranOutcome_str5)), v_name_2412);
        V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2etesting_2eranOutcome_str6)), v_message_2413);
        v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranOutcome_str7), v_t_2415);
        break;
      }
      default: heff_nomatch(v_ended_244);
      }
      V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranOutcome_str8), v_t_2416), ((V)&g_heff_2ebuild_2etesting_2eranOutcome_str9));
      V v_t_2419;
      if (heff_strEq_c_lent(v_err_245, ((V)&g_heff_2ebuild_2etesting_2eranOutcome_str10), 2)) {
        heff_drop(v_err_245);
        v_t_2419 = ((V)&g_heff_2ebuild_2etesting_2eranOutcome_str11);
      } else {
        V v_t_2418 = ({ V a_0 = MK_INT(20LL); V a_1 = v_err_245; V r_ = (g_heff_2ebuild_2etesting_2elastLines(a_0, a_1)); heff_drop(v_err_245); r_; });
        v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranOutcome_str12), v_t_2418);
      }
      V v_why_2420 = heff_strAppend(v_t_2417, v_t_2419);
      V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2420})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2421, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2422 = heff_field(v_said_243, 0);
      V v_ru_24said_243_24Just = heff_take_reuse_n(v_said_243, 1ULL, 1);
      heff_drop(v_ended_244);
      heff_drop(v_err_245);
      V v_t_2423 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2424 = (g_json_2esteps_24cpr(v_text_2422, v_t_2423));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_why_2427 = v_field_2426;
          heff_drop(v_why_2427);
          V v_t_2428 = heff_tag_at_n(v_ru_24said_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2eranOutcome_str13)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2428, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          V v_j_2429 = v_field_2426;
          return (g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1(v_ru_24said_243_24Just, v_name_240, v_j_2429));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  }
}
V g_heff_2ebuild_2etesting_2eranOutcome_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eranOutcome(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestDir_str0, 10, ".heff/test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestDir_str6, 1, "_");
Clo g_heff_2ebuild_2etesting_2etestDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestDir_entry, 2, 0};

V g_heff_2ebuild_2etesting_2etestDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2etesting_2etestDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(heff_dup(v_style_242), v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2etestDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2etesting_2etestDir_str2); V b_3 = ((V)&g_heff_2ebuild_2etesting_2etestDir_str3); V a_4 = ((V)&g_heff_2ebuild_2etesting_2etestDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2414); heff_drop(b_3); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2etesting_2etestDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2etestDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2etesting_2etestDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str2, 17, "heff test: --run ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str5, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str6, 0, "");
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam2, 2, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam7(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam7, 1, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023(V v_e_240, V v_seed_241, V v_pattern_242, V v_jobs_243, V v_update_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_pattern_242)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str0);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_pattern_242, 0);
    v_t_246 = heff_dup(v_x_245);
    break;
  }
  default: heff_nomatch(v_pattern_242);
  }
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_False); V a_4 = MK_INT(0LL); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2elevelsOf_2ecut_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1007499915x73800978(v_t_247));
  HeffT2 v_t_249 = (g_regex_2eallRead_24cpr(v_t_248));
  V v_c_2437;
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_why_2412 = v_field_2411;
      v_c_2437 = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam0, 2, 3, (V[]){heff_dup(v_pattern_242), v_why_2412, heff_dup(v_e_240)});
    } else {
      V v_x_2434 = v_field_2411;
      heff_drop(v_x_2434);
      v_c_2437 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam2_clo);
    }
  }
  return heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam3, 2, 6, (V[]){v_c_2437, v_e_240, heff_dup(v_seed_241), heff_dup(v_pattern_242), heff_dup(v_jobs_243), v_update_244});
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_pattern_242 = heff_env(self)[0];
  V v_why_2412 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416;
  switch (heff_tag_of(v_pattern_242)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_pattern_242, 0);
    heff_take_n(v_pattern_242, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_pattern_242);
  }
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str2), v_t_2416), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str3));
  V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_why_2412), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str4));
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam1, 1, 3, (V[]){v_e_240, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam2(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam5(V self, V *args) {
  V v_n_2441 = args[0];
  return v_n_2441;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam7(V self, V *args) {
  V v_v_2450 = args[0];
  return v_v_2450;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_seed_241 = heff_env(self)[0];
  V v_pattern_242 = heff_env(self)[1];
  V v_x_2449 = heff_env(self)[2];
  V v_jobs_243 = heff_env(self)[3];
  V v_update_244 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2464;
  switch (heff_tag_of(v_seed_241)) {
  case TAG_Nothing: {
    v_t_2464 = MK_INT(2026LL);
    break;
  }
  case TAG_Just: {
    V v_s_2459 = heff_field(v_seed_241, 0);
    heff_take_n(v_seed_241, 1ULL, 1);
    HeffT2 v_t_2460 = ({ V a_0 = v_s_2459; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2459); r_; });
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_x_2463 = v_field_2462;
        v_t_2464 = v_x_2463;
      } else {
        heff_drop(v_field_2462);
        v_t_2464 = MK_INT(2026LL);
      }
    }
    break;
  }
  default: heff_nomatch(v_seed_241);
  }
  V v_t_2466;
  switch (heff_tag_of(v_pattern_242)) {
  case TAG_Nothing: {
    v_t_2466 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2465 = heff_field(v_pattern_242, 0);
    heff_take_n(v_pattern_242, 1ULL, 1);
    v_t_2466 = v_x_2465;
    break;
  }
  default: heff_nomatch(v_pattern_242);
  }
  V v_fallback_2467;
  if (heff_intLt_c(heff_intDiv(heff_dup(v_x_2449), MK_INT(2LL)), MK_INT(1LL))) {
    heff_drop(v_x_2449);
    v_fallback_2467 = MK_INT(1LL);
  } else {
    v_fallback_2467 = heff_intDiv(v_x_2449, MK_INT(2LL));
  }
  V v_fallback_2473;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_fallback_2473 = v_fallback_2467;
    break;
  }
  case TAG_Just: {
    V v_n_2468 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    HeffT2 v_t_2469 = ({ V a_0 = v_n_2468; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2468); r_; });
    {
      V v_field_2471 = v_t_2469.f[1];
      int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
      if ((v_tag_2470 == ((int64_t)0ULL))) {
        V v_k_2472 = v_field_2471;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2472, 1)) {
          heff_drop(v_fallback_2467);
          v_fallback_2473 = v_k_2472;
        } else {
          heff_drop(v_k_2472);
          v_fallback_2473 = v_fallback_2467;
        }
      } else {
        heff_drop(v_field_2471);
        v_fallback_2473 = v_fallback_2467;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_t_2479;
  switch (heff_tag_of(v_jobs_243)) {
  case TAG_Nothing: {
    v_t_2479 = v_fallback_2473;
    break;
  }
  case TAG_Just: {
    V v_n_2474 = heff_field(v_jobs_243, 0);
    heff_take_n(v_jobs_243, 1ULL, 1);
    HeffT2 v_t_2475 = ({ V a_0 = v_n_2474; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2474); r_; });
    {
      V v_field_2477 = v_t_2475.f[1];
      int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
      if ((v_tag_2476 == ((int64_t)0ULL))) {
        V v_k_2478 = v_field_2477;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2478, 1)) {
          heff_drop(v_fallback_2473);
          v_t_2479 = v_k_2478;
        } else {
          heff_drop(v_k_2478);
          v_t_2479 = v_fallback_2473;
        }
      } else {
        heff_drop(v_field_2477);
        v_t_2479 = v_fallback_2473;
      }
    }
    break;
  }
  default: heff_nomatch(v_jobs_243);
  }
  V v_x_2480 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_t_2464, v_t_2466, v_t_2479, v_update_244});
  V f_ = v_k_2439;
  args[0] = v_x_2480;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam6(V self, V *args) {
  V v_x_2449 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2438 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_pattern_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_update_244 = heff_env(self)[5];
  V v_k_2439 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_str5), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam7_clo)})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2457, v_hd_2438, heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam8, 1, 6, (V[]){v_seed_241, v_pattern_242, v_x_2449, v_jobs_243, v_update_244, v_k_2439})));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2438 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_pattern_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_update_244 = heff_env(self)[5];
  V v_k_2439 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2440);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Processors, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam5_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2448, heff_dup(v_hd_2438), heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam6, 1, 7, (V[]){v_e_240, v_hd_2438, v_seed_241, v_pattern_242, v_jobs_243, v_update_244, v_k_2439})));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam3(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_pattern_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_update_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2437;
  args[0] = heff_dup(v_hd_2438);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_lam4, 1, 7, (V[]){v_e_240, v_hd_2438, v_seed_241, v_pattern_242, v_jobs_243, v_update_244, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str3, 30, "its program could not be run: ");
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam7(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam7, 3, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam11(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_entry, 6, 0};

V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310(V v_e_240, V v_sel_241, V v_j_242, V v_dir_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 0, 2);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_j_242, 3)), heff_dup(heff_rfield(v_j_242, 4))});
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_243)));
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2etesting_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_243), ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str0))});
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 1, 2);
  V v_t_2411 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_246, v_t_247, v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2410}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_dup(heff_rfield(v_j_242, 5)), MK_INT(0LL), NTAG(TAG_True)});
  V v_c_2423 = (g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(heff_dup(v_e_240), v_t_2411, heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam2, 2, 5, (V[]){v_c_2423, heff_dup(v_e_240), heff_dup(v_sel_241), heff_dup(v_j_242), heff_dup(v_dir_243)}), heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam6, 1, 3, (V[]){v_dir_243, heff_dup(v_e_240), v_j_242})})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam11, 1, 2, (V[]){v_z_244, v_z_245})));
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam1(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkWith: {
    V v_x_2413 = heff_field(v_p_2412, 0);
    heff_take_n(v_p_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam1_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V f_ = ((V)&g_co_2eop_24s310169282x2049378029_clo);
  heff_room[0] = v_e_240;
  heff_room[1] = v_t_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2425;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam5, 3, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sel_241 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  V v_dir_243 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2427 = ({ V a_0 = v_e_240; V a_1 = v_sel_241; V a_2 = v_j_242; V a_3 = v_dir_243; V a_4 = v_x_2426; V r_ = (g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sel_241); r_; });
  V f_ = v_c_2427;
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam4, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sel_241 = heff_env(self)[2];
  V v_j_242 = heff_env(self)[3];
  V v_dir_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam3, 1, 6, (V[]){v_e_240, v_sel_241, v_j_242, v_dir_243, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam10(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_x_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2449);
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = v_x_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_path_2433 = heff_env(self)[0];
  V v_name_2434 = heff_env(self)[1];
  V v_message_2435 = heff_env(self)[2];
  V v_j_242 = heff_env(self)[3];
  V v_k_2444 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_strAppend(heff_strAppend(v_path_2433, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str1)), v_name_2434);
  V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str2)), v_message_2435);
  V v_x_2448 = (g_heff_2ebuild_2etesting_2ebrokenJob(v_j_242, heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_str3), v_t_2447)));
  V f_ = v_k_2444;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam10, 3, 1, (V[]){v_x_2448});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam8(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_path_2433 = heff_env(self)[1];
  V v_name_2434 = heff_env(self)[2];
  V v_message_2435 = heff_env(self)[3];
  V v_j_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam9, 1, 5, (V[]){v_path_2433, v_name_2434, v_message_2435, v_j_242, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam6(V self, V *args) {
  V v_err_2432 = args[0];
  V v_dir_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_2433 = heff_take_field(v_err_2432, 3);
  V v_name_2434 = heff_take_field(v_err_2432, 1);
  V v_message_2435 = heff_get_n(v_err_2432, 2, 4);
  V v_path_2436 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_243));
  V v_c_2437 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2436; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2436); r_; });
  V v_t_2438 = (g_exception_2eattempted(v_e_240));
  V v_c_2442 = heff_tr(heff_call(v_c_2437, 2, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam7_clo)}));
  return heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam8, 2, 5, (V[]){v_c_2442, v_path_2433, v_name_2434, v_message_2435, v_j_242});
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_lam11(V self, V *args) {
  V v_x_2453 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2453;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str0, 40, "files that do not check as they should:\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str3, 27, "heff test: no tests match '");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str4, 1, "'");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str6, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str7, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str12, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str13, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str14, 11, " tests hold");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str15, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str16, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str18, 2, " (");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str19, 22, " with expected errors)");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str20, 27, " files check as they should");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str21, 1, "\012");
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam6(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam6, 2, 0};
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439(V v_e_240, V v_opts_241, V v_acc_242, V v_p_243, V v_p_244) {
top: ;
  V v_ws_245 = heff_dup(heff_rfield(v_acc_242, 4));
  V v_c_2421;
  switch (heff_tag_of(v_ws_245)) {
  case TAG_Nil: {
    v_c_2421 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam0_clo);
    break;
  }
  case TAG_Cons: {
    v_c_2421 = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam1, 2, 2, (V[]){heff_dup(v_e_240), v_ws_245});
    break;
  }
  default: heff_nomatch(v_ws_245);
  }
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam3, 1, 5, (V[]){v_opts_241, v_acc_242, v_e_240, v_p_243, v_p_244})});
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ws_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2419);
  V v_t_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str1), v_ws_245));
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(v_e_240, v_t_2420, v_hd_2410, v_k_2411));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_ws_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str0), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam2, 1, 4, (V[]){v_ws_245, v_e_240, v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_2423, v_k_2424));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_opts_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str3), heff_get_n(v_opts_241, 1, 4));
  V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str4)), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str5));
  V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_hd_2423), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam5, 1, 3, (V[]){v_e_240, v_hd_2423, v_k_2424})));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam6(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam8(V self, V *args) {
  V v_x_2478 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2478);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 3)))) {
    heff_drop_rec(v_acc_242, 8);
    V v_t_2479 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2485}), v_p_243, v_p_244));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 6)))) {
      heff_drop_rec(v_acc_242, 8);
      V v_t_2486 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2492}), v_p_243, v_p_244));
    } else {
      V v_t_2493 = heff_get_n(v_acc_242, 4, 8);
      switch (heff_tag_of(v_t_2493)) {
      case TAG_Nil: {
        heff_drop(v_e_240);
        heff_drop(v_p_243);
        V f_ = v_p_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2493_24Cons = heff_take_reuse_n(v_t_2493, 0ULL, 2);
        V v_t_2496 = heff_tag_at_n(v_ru_24t_2493_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
        V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
        V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
        V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
        V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
        V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24102}), v_p_243, v_p_244));
      }
      default: return heff_nomatch(v_t_2493);
      }
    }
  }
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_intSub(heff_dup(heff_rfield(v_acc_242, 2)), heff_dup(heff_rfield(v_acc_242, 3)));
  V v_t_2447 = heff_strAppend(heff_intShow(v_t_2446), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str6));
  V v_t_2448 = heff_intShow(heff_dup(heff_rfield(v_acc_242, 2)));
  V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2447, v_t_2448), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str7));
  V v_tests_2450 = heff_dup(heff_rfield(v_acc_242, 5));
  V v_failed_2451 = heff_dup(heff_rfield(v_acc_242, 6));
  V v_skipped_2452 = heff_dup(heff_rfield(v_acc_242, 7));
  V v_t_2458;
  if (heff_intEq_c_lent(v_tests_2450, MK_INT(0LL), 2)) {
    heff_drop(v_tests_2450);
    heff_drop(v_failed_2451);
    heff_drop(v_skipped_2452);
    v_t_2458 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str8);
  } else {
    V v_t_2453 = heff_intSub(heff_intSub(heff_dup(v_tests_2450), v_failed_2451), heff_dup(v_skipped_2452));
    V v_t_2454 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str9), heff_intShow(v_t_2453));
    V v_t_2455 = heff_strAppend(heff_strAppend(v_t_2454, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str10)), heff_intShow(v_tests_2450));
    V v_t_2457;
    if (heff_intEq_c_lent(v_skipped_2452, MK_INT(0LL), 2)) {
      heff_drop(v_skipped_2452);
      v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str11);
    } else {
      V v_t_2456 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str12), heff_intShow(v_skipped_2452));
      v_t_2457 = heff_strAppend(v_t_2456, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str13));
    }
    v_t_2458 = heff_strAppend(heff_strAppend(v_t_2455, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str14)), v_t_2457);
  }
  V v_r_2459 = heff_dup(v_acc_242);
  V v_files_2460 = heff_take_field(v_r_2459, 0);
  V v_unchecked_2461 = heff_take_field(v_r_2459, 4);
  V v_expectErrors_2462 = heff_get_n(v_r_2459, 1, 8);
  V v_t_2463 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_unchecked_2461; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_unchecked_2461); r_; });
  V v_t_2464 = heff_intShow(heff_intSub(heff_dup(v_files_2460), v_t_2463));
  V v_t_2465 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str15), v_t_2464), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str16));
  V v_t_2466 = heff_strAppend(v_t_2465, heff_intShow(v_files_2460));
  V v_t_2468;
  if (heff_intEq_c_lent(v_expectErrors_2462, MK_INT(0LL), 2)) {
    heff_drop(v_expectErrors_2462);
    v_t_2468 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str17);
  } else {
    V v_t_2467 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str18), heff_intShow(v_expectErrors_2462));
    v_t_2468 = heff_strAppend(v_t_2467, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str19));
  }
  V v_t_2469 = heff_strAppend(heff_strAppend(v_t_2466, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str20)), v_t_2468);
  V v_str_2470 = heff_strAppend(heff_strAppend(v_t_2449, v_t_2458), v_t_2469);
  V v_t_2471 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2470, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str21)), NTAG(TAG_MkUnit)});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2477}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam8, 1, 4, (V[]){v_acc_242, v_e_240, v_p_243, v_p_244})));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2422);
  V v_t_2444;
  if ((heff_strEq_c(heff_dup(heff_rfield(v_opts_241, 1)), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_str2)) ? 0 : heff_intEq_c(heff_dup(heff_rfield(v_acc_242, 5)), MK_INT(0LL)))) {
    v_t_2444 = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam4, 2, 2, (V[]){v_opts_241, heff_dup(v_e_240)});
  } else {
    heff_drop_rec(v_opts_241, 4);
    v_t_2444 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam6_clo);
  }
  V f_ = v_t_2444;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s15492814x885516439_lam7, 1, 4, (V[]){v_acc_242, v_e_240, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str0, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str1, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str2, 13, "Integrations\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str3, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str4, 17, "integrationMain [");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str6, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str7, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str8, 19, ": integration tests");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str9, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str10, 4, "main");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str11, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str12, 4, "main");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str13, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str14, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str15, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str16, 9, "heff test");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str18, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str19, 1, "1");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str20, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str21, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str22, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str23, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str24, 45, "its file does not import check, which runs it");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str25, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str26, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str27, 34, "its file is not among those loaded");
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam12(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam12, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam14(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam14, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam16(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam15(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam13(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam11(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam21(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam20(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam19(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam18(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam17(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam23(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam22(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam25(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam24(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam27(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam26(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_entry, 7, 0};

V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471(V v_e_240, V v_opts_241, V v_at_242, V v_p_243, V v_k_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_p_243, 5)), 0, 5);
  HeffT2 v_t_248 = ({ V a_0 = heff_dup(v_p_243); V a_1 = v_t_247; HeffT2 r_ = (g_list_2efind_24s595925281x993936542_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_src_2411 = v_field_2410;
      V v_p_2412 = heff_dup(v_p_243);
      V v_loaded_2413 = heff_take_field(v_p_2412, 5);
      V v_checked_2414 = heff_get_n(v_p_2412, 6, 7);
      V v_src_2415 = v_src_2411;
      V v_renames_2416 = heff_take_field(v_src_2415, 5);
      V v_implicit_2417 = heff_take_field(v_src_2415, 6);
      V v_source_2418 = heff_get_n(v_src_2415, 4, 8);
      V v_t_2419 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_2417, v_source_2418));
      HeffT4 v_t_2420 = ({ V a_0 = v_renames_2416; V a_1 = v_t_2419; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(a_0, a_1)); heff_drop(v_renames_2416); r_; });
      V v_t_2425;
      {
        V v_field_2421 = v_t_2420.f[0];
        heff_drop(v_t_2420.f[1]);
        heff_drop(v_t_2420.f[2]);
        heff_drop(v_t_2420.f[3]);
        v_t_2425 = v_field_2421;
      }
      HeffT2 v_t_2426 = ({ V a_0 = v_t_2425; HeffT2 r_ = (g_heff_2ebuild_2etesting_2equalifierOf_24cpr(a_0)); heff_drop(v_t_2425); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_q_2429 = v_field_2428;
          V v_l_2430 = heff_dup(v_loaded_2413);
          V v_q_2431 = v_q_2429;
          V v_ts_2432 = (g_heff_2ebuild_2edriver_2etestsOf(heff_dup(v_checked_2414)));
          V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str0), heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str1));
          V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, heff_dup(v_q_2431)), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str2));
          V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str3));
          V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, v_q_2431), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str4));
          V v_x2_2437 = (g_list_2emap_24s467798769x1763085075(v_ts_2432));
          V v_t_2440;
          switch (heff_tag_of(v_x2_2437)) {
          case TAG_Nil: {
            v_t_2440 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str5);
            break;
          }
          case TAG_Cons: {
            V v_x_2438 = heff_field(v_x2_2437, 0);
            V v_xs_2439 = heff_field(v_x2_2437, 1);
            heff_take_n(v_x2_2437, 3ULL, 2);
            v_t_2440 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str6); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2437);
          }
          V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2436, v_t_2440), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str7));
          V v_sources_2442 = ({ V b_0 = heff_get_n(v_checked_2414, 0, 14); V a_1 = v_t_2441; V a_2 = heff_get_n(v_loaded_2413, 0, 5); V r_ = (g_list_2emap_24s1681408447x1763680441(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          V v_l_2443 = ({ V rv_0 = v_sources_2442; V rr_ = heff_rec_reuse_nf(v_l_2430, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2444 = heff_strAppend(heff_dup(heff_rfield(v_p_243, 0)), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str8));
          V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2444, MK_INT(2LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam0_clo)})});
          V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
          return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2447, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam1, 1, 8, (V[]){v_e_240, v_z_245, v_l_2443, v_p_243, v_opts_241, v_k_244, v_at_242, v_z_246})));
        } else {
          heff_drop(v_at_242);
          heff_drop_rec(v_loaded_2413, 5);
          heff_drop_rec(v_checked_2414, 14);
          heff_drop(v_field_2428);
          V v_why_24149 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str24);
          V v_more_24150 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str25), v_why_24149, MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
          V v_t_24151 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_24150));
          V v_c_24152 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(heff_dup(v_e_240), heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_24151));
          return heff_tail(v_c_24152, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam24, 1, 6, (V[]){v_opts_241, v_k_244, v_z_245, v_z_246, v_e_240, v_p_243})});
        }
      }
    } else {
      heff_drop(v_at_242);
      heff_drop(v_field_2410);
      V v_more_24156 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str26), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str27), MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
      V v_t_24157 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_24156));
      V v_c_24158 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(heff_dup(v_e_240), heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_24157));
      return heff_tail(v_c_24158, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam26, 1, 6, (V[]){v_opts_241, v_k_244, v_z_245, v_z_246, v_e_240, v_p_243})});
    }
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam0(V self, V *args) {
  V v_t_2445 = args[0];
  return v_t_2445;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam2(V self, V *args) {
  V v_t_2449 = args[0];
  return v_t_2449;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam4(V self, V *args) {
  V v_r_2473 = args[0];
  return v_r_2473;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam8(V self, V *args) {
  V v_x_2489 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_2479 = heff_env(self)[1];
  V v_k_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2489});
  heff_room[1] = v_hd_2479;
  heff_room[2] = v_k_2480;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam7(V self, V *args) {
  V v_x_2487 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_2479 = heff_env(self)[2];
  V v_k_2480 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2488 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_241, heff_dup(v_x_2487)));
  if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
    heff_drop(v_x_2487);
    heff_drop(v_e_240);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_2488);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_hd_2479;
    heff_room[2] = v_k_2480;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2488);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(v_e_240, heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_2487, heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam8, 1, 3, (V[]){v_k_244, v_hd_2479, v_k_2480})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam6(V self, V *args) {
  V v_x_2483 = args[0];
  V v_why_2478 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_hd_2479 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_k_2480 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2483);
  V v_more_2484 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str15), v_why_2478, MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
  V v_t_2485 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_2484));
  V v_c_2486 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(heff_dup(v_e_240), heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_2485));
  V f_ = v_c_2486;
  heff_room[0] = heff_dup(v_hd_2479);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam7, 1, 6, (V[]){v_opts_241, v_k_244, v_hd_2479, v_k_2480, v_e_240, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam5(V self, V *args) {
  V v_why_2478 = args[0];
  V v_hd_2479 = args[1];
  V v_k_2480 = args[2];
  V v_x_2448 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2481 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam6, 1, 7, (V[]){v_why_2478, v_p_243, v_e_240, v_opts_241, v_hd_2479, v_k_244, v_k_2480})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam12(V self, V *args) {
  V v_r_2496 = args[0];
  return v_r_2496;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam14(V self, V *args) {
  V v_r_24104 = args[0];
  return v_r_24104;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam16(V self, V *args) {
  V v_x_24111 = args[0];
  V v_x_2492 = heff_env(self)[0];
  V v_l_2443 = heff_env(self)[1];
  V v_x_24100 = heff_env(self)[2];
  V v_x_2493 = heff_env(self)[3];
  V v_x_24108 = heff_env(self)[4];
  V v_at_242 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  V v_k_244 = heff_env(self)[7];
  V v_hd_2490 = heff_env(self)[8];
  V v_k_2491 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_24111);
  V v_t_24115;
  switch (heff_tag_of(v_x_2492)) {
  case TAG_Left: {
    heff_take_n(v_x_2492, 0ULL, 1);
    v_t_24115 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str17);
    break;
  }
  case TAG_Right: {
    V v_real_24113 = heff_field(v_x_2492, 0);
    heff_take_n(v_x_2492, 1ULL, 1);
    V v_t_24114 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 5, 6);
    v_t_24115 = ({ V a_0 = v_t_24114; V a_1 = v_real_24113; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24114); heff_drop(v_real_24113); r_; });
    break;
  }
  default: heff_nomatch(v_x_2492);
  }
  V v_t_24119;
  switch (heff_tag_of(v_x_24100)) {
  case TAG_Left: {
    heff_take_n(v_x_24100, 0ULL, 1);
    v_t_24119 = v_x_2493;
    break;
  }
  case TAG_Right: {
    V v_real_24117 = heff_field(v_x_24100, 0);
    heff_take_n(v_x_24100, 1ULL, 1);
    heff_drop(v_x_2493);
    V v_t_24118 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 5, 6);
    v_t_24119 = ({ V a_0 = v_t_24118; V a_1 = v_real_24117; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24118); heff_drop(v_real_24117); r_; });
    break;
  }
  default: heff_nomatch(v_x_24100);
  }
  V v_t_24123;
  switch (heff_tag_of(v_x_24108)) {
  case TAG_Left: {
    heff_take_n(v_x_24108, 0ULL, 1);
    v_t_24123 = heff_get_n(heff_get_n(v_l_2443, 2, 5), 0, 6);
    break;
  }
  case TAG_Right: {
    V v_real_24121 = heff_field(v_x_24108, 0);
    heff_take_n(v_x_24108, 1ULL, 1);
    V v_t_24122 = heff_get_n(heff_get_n(v_l_2443, 2, 5), 5, 6);
    v_t_24123 = ({ V a_0 = v_t_24122; V a_1 = v_real_24121; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24122); heff_drop(v_real_24121); r_; });
    break;
  }
  default: heff_nomatch(v_x_24108);
  }
  V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str18), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str19)}), NTAG(TAG_Nil)});
  V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str20), v_t_24123}), v_t_24124});
  V v_t_24126 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str21), v_t_24119}), v_t_24125});
  V v_t_24127 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_242, v_p_243, heff_rec_n(2, shape_program__env, (V[]){v_t_24115, v_t_24126})});
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_24127});
  heff_room[1] = v_hd_2490;
  heff_room[2] = v_k_2491;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam15(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2490 = heff_env(self)[2];
  V v_x_2492 = heff_env(self)[3];
  V v_l_2443 = heff_env(self)[4];
  V v_x_24100 = heff_env(self)[5];
  V v_x_2493 = heff_env(self)[6];
  V v_at_242 = heff_env(self)[7];
  V v_p_243 = heff_env(self)[8];
  V v_k_244 = heff_env(self)[9];
  V v_k_2491 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_24109 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24110}), heff_dup(v_hd_2490), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam16, 1, 10, (V[]){v_x_2492, v_l_2443, v_x_24100, v_x_2493, v_x_24108, v_at_242, v_p_243, v_k_244, v_hd_2490, v_k_2491})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam13(V self, V *args) {
  V v_x_24100 = args[0];
  V v_l_2443 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2490 = heff_env(self)[2];
  V v_x_2448 = heff_env(self)[3];
  V v_x_2492 = heff_env(self)[4];
  V v_x_2493 = heff_env(self)[5];
  V v_at_242 = heff_env(self)[6];
  V v_p_243 = heff_env(self)[7];
  V v_k_244 = heff_env(self)[8];
  V v_k_2491 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_24101 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 0, 6);
  V v_path_24102 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_t_24101));
  V v_t_24103 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24102; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24102); r_; });
  V v_p_231002_24105 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_24103, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam14_clo)});
  V v_t_24106 = heff_tr(heff_call(((V)&g_co_2eop_24s199044798x1745934964_clo), 2, (V[]){v_p_231002_24105, heff_dup(v_e_240)}));
  V v_c_24107 = heff_tr(g_std_2efilesystem_2efromSystem_24s1965754558x142330605(heff_dup(v_e_240), v_e_240, v_t_24106));
  V f_ = v_c_24107;
  heff_room[0] = heff_dup(v_hd_2490);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam15, 1, 11, (V[]){v_x_2448, v_e_240, v_hd_2490, v_x_2492, v_l_2443, v_x_24100, v_x_2493, v_at_242, v_p_243, v_k_244, v_k_2491});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam11(V self, V *args) {
  V v_x_2493 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2490 = heff_env(self)[1];
  V v_l_2443 = heff_env(self)[2];
  V v_x_2448 = heff_env(self)[3];
  V v_x_2492 = heff_env(self)[4];
  V v_at_242 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  V v_k_244 = heff_env(self)[7];
  V v_k_2491 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_path_2494 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2493)));
  V v_t_2495 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2494; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2494); r_; });
  V v_p_231002_2497 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2495, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam12_clo)});
  V v_t_2498 = heff_tr(heff_call(((V)&g_co_2eop_24s199044798x1745934964_clo), 2, (V[]){v_p_231002_2497, heff_dup(v_e_240)}));
  V v_c_2499 = heff_tr(g_std_2efilesystem_2efromSystem_24s1965754558x142330605(heff_dup(v_e_240), v_e_240, v_t_2498));
  V f_ = v_c_2499;
  heff_room[0] = heff_dup(v_hd_2490);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam13, 1, 10, (V[]){v_l_2443, v_e_240, v_hd_2490, v_x_2448, v_x_2492, v_x_2493, v_at_242, v_p_243, v_k_244, v_k_2491});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam10(V self, V *args) {
  V v_x_2492 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2490 = heff_env(self)[1];
  V v_l_2443 = heff_env(self)[2];
  V v_x_2448 = heff_env(self)[3];
  V v_at_242 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  V v_k_2491 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(heff_dup(v_e_240), heff_dup(v_hd_2490), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam11, 1, 9, (V[]){v_e_240, v_hd_2490, v_l_2443, v_x_2448, v_x_2492, v_at_242, v_p_243, v_k_244, v_k_2491})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam9(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k_2491 = args[1];
  V v_c_2476 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_l_2443 = heff_env(self)[2];
  V v_x_2448 = heff_env(self)[3];
  V v_at_242 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2476;
  args[0] = heff_dup(v_hd_2490);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam10, 1, 8, (V[]){v_e_240, v_hd_2490, v_l_2443, v_x_2448, v_at_242, v_p_243, v_k_244, v_k_2491});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam21(V self, V *args) {
  V v_x_24143 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_24130 = heff_env(self)[1];
  V v_k_24131 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24143});
  heff_room[1] = v_hd_24130;
  heff_room[2] = v_k_24131;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam20(V self, V *args) {
  V v_x_24141 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_24130 = heff_env(self)[2];
  V v_k_24131 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24142 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_241, heff_dup(v_x_24141)));
  if ((heff_dup(v_t_24142) == NTAG(TAG_True))) {
    heff_drop(v_x_24141);
    heff_drop(v_e_240);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_24142);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_hd_24130;
    heff_room[2] = v_k_24131;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24142);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(v_e_240, heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_24141, heff_dup(v_hd_24130), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam21, 1, 3, (V[]){v_k_244, v_hd_24130, v_k_24131})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam19(V self, V *args) {
  V v_x_24137 = args[0];
  V v_why_24129 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_hd_24130 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_k_24131 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24137);
  V v_more_24138 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str22), v_why_24129, MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
  V v_t_24139 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_24138));
  V v_c_24140 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(heff_dup(v_e_240), heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_24139));
  V f_ = v_c_24140;
  heff_room[0] = heff_dup(v_hd_24130);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam20, 1, 6, (V[]){v_opts_241, v_k_244, v_hd_24130, v_k_24131, v_e_240, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam18(V self, V *args) {
  V v_x_24134 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_24130 = heff_env(self)[2];
  V v_why_24129 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_opts_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  V v_k_24131 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_24134);
  V v_t_24135 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24136}), heff_dup(v_hd_24130), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam19, 1, 7, (V[]){v_why_24129, v_p_243, v_e_240, v_opts_241, v_hd_24130, v_k_244, v_k_24131})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam17(V self, V *args) {
  V v_why_24129 = args[0];
  V v_hd_24130 = args[1];
  V v_k_24131 = args[2];
  V v_x_2452 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2448 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24132 = heff_tag_n(TAG_End, 2, (V[]){v_x_2452, NTAG(TAG_MkUnit)});
  V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24133}), heff_dup(v_hd_24130), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam18, 1, 8, (V[]){v_x_2448, v_e_240, v_hd_24130, v_why_24129, v_p_243, v_opts_241, v_k_244, v_k_24131})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam23(V self, V *args) {
  V v_x_24148 = args[0];
  V v_next_24128 = heff_env(self)[0];
  V v_hd_24144 = heff_env(self)[1];
  V v_k_24145 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24148);
  V f_ = v_next_24128;
  heff_room[0] = v_hd_24144;
  heff_room[1] = v_k_24145;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam22(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_x_2452 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_24128 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24146 = heff_tag_n(TAG_End, 2, (V[]){v_x_2452, NTAG(TAG_MkUnit)});
  V v_t_24147 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24147}), heff_dup(v_hd_24144), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam23, 1, 3, (V[]){v_next_24128, v_hd_24144, v_k_24145})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam3(V self, V *args) {
  V v_x_2452 = args[0];
  V v_l_2443 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_x_2448 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_at_242 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  V v_z_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2453 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2443, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_dir_2454 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2443, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_d_2455 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2443, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_st_2456 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 5, 6);
  V v_t_2457 = (g_std_2epath_2eparse(heff_dup(v_st_2456), v_d_2455));
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 5, 6);
  V v_t_2459;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_Posix: {
    v_t_2459 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str10);
    break;
  }
  case TAG_Windows: {
    v_t_2459 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str11);
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  V v_t_2460 = (g_std_2epath_2eparse(heff_dup(v_st_2456), v_t_2459));
  V v_t_2461 = (g_std_2epath_2ejoin(v_t_2457, v_t_2460));
  V v_out_2462 = ({ V a_0 = v_st_2456; V a_1 = v_t_2461; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2456); heff_drop(v_t_2461); r_; });
  V v_d_2463 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2443, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_st_2464 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 5, 6);
  V v_t_2465 = (g_std_2epath_2eparse(heff_dup(v_st_2464), v_d_2463));
  V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 5, 6);
  V v_t_2467;
  switch (heff_tag_of(v_t_2466)) {
  case TAG_Posix: {
    v_t_2467 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str12);
    break;
  }
  case TAG_Windows: {
    v_t_2467 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str13);
    break;
  }
  default: heff_nomatch(v_t_2466);
  }
  V v_t_2468 = (g_std_2epath_2eparse(heff_dup(v_st_2464), v_t_2467));
  V v_t_2469 = (g_std_2epath_2ejoin(v_t_2465, v_t_2468));
  V v_s_2470 = ({ V a_0 = v_st_2464; V a_1 = v_t_2469; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2464); heff_drop(v_t_2469); r_; });
  V v_path_2471 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2470));
  V v_t_2472 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2471; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2471); r_; });
  V v_p_231002_2474 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2472, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam4_clo)});
  V v_t_2475 = heff_tr(heff_call(((V)&g_co_2eop_24s199044798x1745934964_clo), 2, (V[]){v_p_231002_2474, heff_dup(v_e_240)}));
  V v_c_2476 = heff_tr(g_std_2efilesystem_2efromSystem_24s1965754558x142330605(heff_dup(v_e_240), v_e_240, v_t_2475));
  V v_t_2477 = heff_get_n(heff_dup(heff_rfield(v_l_2443, 2)), 5, 6);
  V v_next_24128 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str14), heff_dup(v_e_240), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam5, 3, 5, (V[]){heff_dup(v_x_2448), heff_dup(v_e_240), heff_dup(v_p_243), heff_dup(v_opts_241), heff_dup(v_k_244)}), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str16), v_t_2477, heff_dup(v_x_2448), v_dir_2454, v_out_2462, heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam9, 2, 7, (V[]){v_c_2476, heff_dup(v_e_240), heff_dup(v_l_2443), heff_dup(v_x_2448), v_at_242, heff_dup(v_p_243), heff_dup(v_k_244)})));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(heff_dup(v_e_240), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam17, 3, 6, (V[]){heff_dup(v_x_2452), heff_dup(v_e_240), v_x_2448, heff_dup(v_p_243), v_opts_241, v_k_244}), v_l_2443, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())}), heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str23)), heff_get_n(v_p_243, 0, 7), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam22, 2, 3, (V[]){v_x_2452, v_e_240, v_next_24128}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam1(V self, V *args) {
  V v_x_2448 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_l_2443 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_at_242 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2448), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_str9), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam2_clo)})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2451, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam3, 1, 9, (V[]){v_l_2443, v_p_243, v_e_240, v_x_2448, v_opts_241, v_k_244, v_at_242, v_z_245, v_z_246})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam25(V self, V *args) {
  V v_x_24155 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24155});
  heff_room[1] = v_z_245;
  heff_room[2] = v_z_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam24(V self, V *args) {
  V v_x_24153 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24154 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_241, heff_dup(v_x_24153)));
  if ((heff_dup(v_t_24154) == NTAG(TAG_True))) {
    heff_drop(v_x_24153);
    heff_drop(v_e_240);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_24154);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_z_245;
    heff_room[2] = v_z_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24154);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(v_e_240, heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_24153, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam25, 1, 3, (V[]){v_k_244, v_z_245, v_z_246})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam27(V self, V *args) {
  V v_x_24161 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24161});
  heff_room[1] = v_z_245;
  heff_room[2] = v_z_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam26(V self, V *args) {
  V v_x_24159 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24160 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_241, heff_dup(v_x_24159)));
  if ((heff_dup(v_t_24160) == NTAG(TAG_True))) {
    heff_drop(v_x_24159);
    heff_drop(v_e_240);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_24160);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_z_245;
    heff_room[2] = v_z_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24160);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(v_e_240, heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_24159, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s1956840743x1231875471_lam27, 1, 3, (V[]){v_k_244, v_z_245, v_z_246})));
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str4, 7, "goldens");
Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_entry, 3, 0};

V g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1(V v_tok_240, V v_name_241, V v_j_242) {
top: ;
  V v_t_2422;
  switch (heff_tag_of(v_j_242)) {
  case TAG_JNull: {
    v_t_2422 = NTAG(TAG_False);
    break;
  }
  case TAG_JBool: {
    v_t_2422 = NTAG(TAG_False);
    break;
  }
  case TAG_JInt: {
    v_t_2422 = NTAG(TAG_False);
    break;
  }
  case TAG_JFloat: {
    v_t_2422 = NTAG(TAG_False);
    break;
  }
  case TAG_JString: {
    v_t_2422 = NTAG(TAG_False);
    break;
  }
  case TAG_JArray: {
    v_t_2422 = NTAG(TAG_False);
    break;
  }
  case TAG_JObject: {
    V v_fs_248 = heff_dup(heff_field(v_j_242, 0));
    HeffT2 v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str0); V a_1 = v_fs_248; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_248); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_p_2412 = v_field_2411;
        V v_t_2415;
        switch (heff_tag_of(v_p_2412)) {
        case TAG_MkPair: {
          V v_y_2414 = heff_field(v_p_2412, 1);
          heff_take_n(v_p_2412, 2ULL, 2);
          v_t_2415 = v_y_2414;
          break;
        }
        default: heff_nomatch(v_p_2412);
        }
        switch (heff_tag_of(v_t_2415)) {
        case TAG_JNull: {
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          V v_b_2416 = heff_field(v_t_2415, 0);
          heff_take_n(v_t_2415, 1ULL, 1);
          v_t_2422 = v_b_2416;
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2415, 0ULL, 1);
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2415, 0ULL, 1);
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2415, 0ULL, 1);
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2415, 0ULL, 1);
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2415, 0ULL, 1);
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2415);
        }
      } else {
        heff_drop(v_field_2411);
        v_t_2422 = NTAG(TAG_False);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_242);
  }
  V v_t_2442;
  switch (heff_tag_of(v_j_242)) {
  case TAG_JNull: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2442 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2442 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2442 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2442 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2442 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2442 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2428 = heff_dup(heff_field(v_j_242, 0));
    HeffT2 v_t_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str1); V a_1 = v_fs_2428; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2428); r_; });
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_p_2432 = v_field_2431;
        V v_t_2435;
        switch (heff_tag_of(v_p_2432)) {
        case TAG_MkPair: {
          V v_y_2434 = heff_field(v_p_2432, 1);
          heff_take_n(v_p_2432, 2ULL, 2);
          v_t_2435 = v_y_2434;
          break;
        }
        default: heff_nomatch(v_p_2432);
        }
        switch (heff_tag_of(v_t_2435)) {
        case TAG_JNull: {
          heff_drop_cell(v_tok_240, 1);
          v_t_2442 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2435, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2442 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2435, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2442 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2435, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2442 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2439 = heff_field(v_t_2435, 0);
          heff_take_n(v_t_2435, 1ULL, 1);
          v_t_2442 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_s_2439});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2435, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2442 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2435, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2442 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2435);
        }
      } else {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_field_2431);
        v_t_2442 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_242);
  }
  V v_t_2462;
  switch (heff_tag_of(v_j_242)) {
  case TAG_JNull: {
    v_t_2462 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JBool: {
    v_t_2462 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JInt: {
    v_t_2462 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JFloat: {
    v_t_2462 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JString: {
    v_t_2462 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JArray: {
    v_t_2462 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JObject: {
    V v_fs_2448 = heff_dup(heff_field(v_j_242, 0));
    HeffT2 v_t_2449 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str2); V a_1 = v_fs_2448; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2448); r_; });
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        V v_p_2452 = v_field_2451;
        V v_t_2455;
        switch (heff_tag_of(v_p_2452)) {
        case TAG_MkPair: {
          V v_y_2454 = heff_field(v_p_2452, 1);
          heff_take_n(v_p_2452, 2ULL, 2);
          v_t_2455 = v_y_2454;
          break;
        }
        default: heff_nomatch(v_p_2452);
        }
        switch (heff_tag_of(v_t_2455)) {
        case TAG_JNull: {
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2455, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2455, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2455, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2455, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JArray: {
          V v_xs_2460 = heff_field(v_t_2455, 0);
          heff_take_n(v_t_2455, 1ULL, 1);
          v_t_2462 = v_xs_2460;
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2455, 0ULL, 1);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_t_2455);
        }
      } else {
        heff_drop(v_field_2451);
        v_t_2462 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_242);
  }
  V v_t_2463 = (g_list_2emap_24s1113395621x248103432(v_t_2462));
  V v_t_2477;
  switch (heff_tag_of(v_j_242)) {
  case TAG_JNull: {
    v_t_2477 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2477 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2477 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2477 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2477 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2477 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2469 = heff_dup(heff_field(v_j_242, 0));
    HeffT2 v_t_2470 = ({ V b_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str3); V a_1 = v_fs_2469; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2469); r_; });
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      if ((v_tag_2471 == ((int64_t)0ULL))) {
        V v_p_2473 = v_field_2472;
        V v_t_2476;
        switch (heff_tag_of(v_p_2473)) {
        case TAG_MkPair: {
          V v_y_2475 = heff_field(v_p_2473, 1);
          heff_take_n(v_p_2473, 2ULL, 2);
          v_t_2476 = v_y_2475;
          break;
        }
        default: heff_nomatch(v_p_2473);
        }
        v_t_2477 = (g_heff_2ebuild_2etesting_2ejsonFailure(v_t_2476));
      } else {
        heff_drop(v_field_2472);
        v_t_2477 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_242);
  }
  V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2479 = ({ V a_0 = v_t_2478; V a_1 = v_j_242; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2478, 2); r_; });
  V v_t_2489;
  {
    V v_field_2481 = v_t_2479.f[1];
    int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
    if ((v_tag_2480 == ((int64_t)0ULL))) {
      V v_it1_2482 = v_field_2481;
      switch (heff_tag_of(v_it1_2482)) {
      case TAG_JNull: {
        v_t_2489 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        v_t_2489 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        v_t_2489 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2482, 0ULL, 1);
        v_t_2489 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        v_t_2489 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2487 = heff_field(v_it1_2482, 0);
        heff_take_n(v_it1_2482, 1ULL, 1);
        v_t_2489 = v_xs_2487;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2482, 0ULL, 1);
        v_t_2489 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2482);
      }
    } else {
      heff_drop(v_field_2481);
      v_t_2489 = NTAG(TAG_Nil);
    }
  }
  V v_t_2490 = (g_list_2emap_24s2029356170x1054793697(v_t_2489));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_241, v_t_2422, v_t_2442, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2463, v_t_2477, MK_INT(0LL), v_t_2490});
}
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eoutcomeOfJson_24tok1(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str3, 30, "its program could not be run: ");
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam7(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam7, 3, 0};
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam11(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_entry, 7, 0};

V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1(V v_tok_240, V v_e_241, V v_sel_242, V v_j_243, V v_dir_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_j_243, 1)), 0, 2);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_j_243, 3)), heff_dup(heff_rfield(v_j_243, 4))});
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_244)));
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2etesting_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_244), ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str0))});
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_j_243, 1)), 1, 2);
  V v_t_2412 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_247, v_t_248, v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2411}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_dup(heff_rfield(v_j_243, 5)), MK_INT(0LL), NTAG(TAG_True)});
  V v_c_2424 = (g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(heff_dup(v_e_241), v_t_2412, heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam0, 1, 1, (V[]){heff_dup(v_e_241)})));
  V v_t_2453 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam2, 2, 5, (V[]){v_c_2424, heff_dup(v_e_241), heff_dup(v_sel_242), heff_dup(v_j_243), heff_dup(v_dir_244)}), heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam6, 1, 3, (V[]){v_dir_244, heff_dup(v_e_241), v_j_243})})});
  return (g_co_2eop_24s310169282x2049378029(v_e_241, heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam11, 1, 2, (V[]){v_z_245, v_z_246})));
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam1(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkWith: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    heff_take_n(v_p_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam1_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V f_ = ((V)&g_co_2eop_24s310169282x2049378029_clo);
  heff_room[0] = v_e_241;
  heff_room[1] = v_t_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2426;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam5, 3, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_sel_242 = heff_env(self)[1];
  V v_j_243 = heff_env(self)[2];
  V v_dir_244 = heff_env(self)[3];
  V v_hd_2425 = heff_env(self)[4];
  V v_k_2426 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2428 = ({ V a_0 = v_e_241; V a_1 = v_sel_242; V a_2 = v_j_243; V a_3 = v_dir_244; V a_4 = v_x_2427; V r_ = (g_heff_2ebuild_2etesting_2eendedJob_24s459684418x423473562(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sel_242); r_; });
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2425;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam4, 1, 1, (V[]){v_k_2426});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_sel_242 = heff_env(self)[2];
  V v_j_243 = heff_env(self)[3];
  V v_dir_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam3, 1, 6, (V[]){v_e_241, v_sel_242, v_j_243, v_dir_244, v_hd_2425, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2441 = args[1];
  V v_k_2442 = args[2];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam10(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_path_2434 = heff_env(self)[0];
  V v_name_2435 = heff_env(self)[1];
  V v_message_2436 = heff_env(self)[2];
  V v_j_243 = heff_env(self)[3];
  V v_k_2445 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_strAppend(heff_strAppend(v_path_2434, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str1)), v_name_2435);
  V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str2)), v_message_2436);
  V v_x_2449 = (g_heff_2ebuild_2etesting_2ebrokenJob(v_j_243, heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_str3), v_t_2448)));
  V f_ = v_k_2445;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam10, 3, 1, (V[]){v_x_2449});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam8(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_path_2434 = heff_env(self)[1];
  V v_name_2435 = heff_env(self)[2];
  V v_message_2436 = heff_env(self)[3];
  V v_j_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2443;
  args[0] = v_hd_2444;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam9, 1, 5, (V[]){v_path_2434, v_name_2435, v_message_2436, v_j_243, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam6(V self, V *args) {
  V v_err_2433 = args[0];
  V v_dir_244 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_j_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_2434 = heff_take_field(v_err_2433, 3);
  V v_name_2435 = heff_take_field(v_err_2433, 1);
  V v_message_2436 = heff_get_n(v_err_2433, 2, 4);
  V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_244));
  V v_c_2438 = ({ V a_0 = heff_dup(v_e_241); V a_1 = v_path_2437; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2437); r_; });
  V v_t_2439 = (g_exception_2eattempted(v_e_241));
  V v_c_2443 = heff_tr(heff_call(v_c_2438, 2, (V[]){v_t_2439, ((V)&g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam7_clo)}));
  return heff_clo_n(g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam8, 2, 5, (V[]){v_c_2443, v_path_2434, v_name_2435, v_message_2436, v_j_243});
}
V g_heff_2ebuild_2etesting_2eranJob_24s254533242x1659764310_24tok1_lam11(V self, V *args) {
  V v_x_2454 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2454;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_z_245;
  heff_room[2] = v_z_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}