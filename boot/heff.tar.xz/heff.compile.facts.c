// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_byFun 295539138
#define LBL_cells 295903083
#define LBL_flat 9641024
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lent 9813446
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tokens 1078955205
#define LBL_tuples 1084651734
#define LBL_words 314676931
#define LBL_workers 1757018875
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words, LBL_tokens};
static uint32_t shape_byFun__cells[] = {LBL_byFun, LBL_cells};
V g_heff_2ecompile_2efacts_2earityOfBody(V);
V g_heff_2ecompile_2efacts_2earityOfBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2earityOfBody_clo;
V g_heff_2ecompile_2efacts_2earityOne(V, V);
V g_heff_2ecompile_2efacts_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2earityOne_clo;
V g_heff_2ecompile_2efacts_2ebodyBounces(V, V);
V g_heff_2ecompile_2efacts_2ebodyBounces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ebodyBounces_clo;
V g_heff_2ecompile_2efacts_2ebounceGo(V, V);
V g_heff_2ecompile_2efacts_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ebounceGo_clo;
V g_heff_2ecompile_2efacts_2efactsOf(V);
V g_heff_2ecompile_2efacts_2efactsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2efactsOf_clo;
V g_heff_2ecompile_2efacts_2eflatInto(V, V, V);
V g_heff_2ecompile_2efacts_2eflatInto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2eflatInto_clo;
V g_heff_2ecompile_2efacts_2eflatW(V, V);
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2eflatW_clo;
V g_heff_2ecompile_2efacts_2elazyOf(V, V, V);
V g_heff_2ecompile_2efacts_2elazyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2elazyOf_clo;
V g_heff_2ecompile_2efacts_2enoTokens_get(void);
V g_heff_2ecompile_2efacts_2esureRecW(V, V);
V g_heff_2ecompile_2efacts_2esureRecW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureRecW_clo;
V g_heff_2ecompile_2efacts_2esureW(V, V);
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureW_clo;
V g_heff_2ecompile_2efacts_2etailApp(V);
V g_heff_2ecompile_2efacts_2etailApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailApp_clo;
V g_heff_2ecompile_2efacts_2etailGlobals(V);
V g_heff_2ecompile_2efacts_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailGlobals_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s495437461x764444341(V);
V g_list_2eany_24s495437461x764444341_entry(V self, V *a);
extern Clo g_list_2eany_24s495437461x764444341_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1232551929x416126852(V, V);
V g_list_2efoldl_24s1232551929x416126852_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1232551929x416126852_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1722165992x1349408496(V, V);
V g_list_2efoldl_24s1722165992x1349408496_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722165992x1349408496_clo;
V g_list_2efoldl_24s249275339x7045056(V, V);
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a);
extern Clo g_list_2efoldl_24s249275339x7045056_clo;
V g_list_2efoldl_24s532345456x1351763934(V, V);
V g_list_2efoldl_24s532345456x1351763934_entry(V self, V *a);
extern Clo g_list_2efoldl_24s532345456x1351763934_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s110788034x1785682300(V);
V g_list_2ekeepIf_24s110788034x1785682300_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s110788034x1785682300_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;

static V g_heff_2ecompile_2efacts_2enoTokens_val;
static HEFF_ONCE g_heff_2ecompile_2efacts_2enoTokens_st;
static V g_heff_2ecompile_2efacts_2enoTokens_init(void) {
  return heff_rec_n(2, shape_byFun__cells, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2efacts_2enoTokens_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2efacts_2enoTokens_st)) return g_heff_2ecompile_2efacts_2enoTokens_val;
  return heff_global(&g_heff_2ecompile_2efacts_2enoTokens_val, &g_heff_2ecompile_2efacts_2enoTokens_st, g_heff_2ecompile_2efacts_2enoTokens_init);
}
Clo g_heff_2ecompile_2efacts_2earityOfBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2earityOfBody_entry, 1, 0};

V g_heff_2ecompile_2efacts_2earityOfBody(V v_b_240) {
top: ;
  switch (heff_tag_of(v_b_240)) {
  case TAG_EVar: {
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_b_240, 0);
    return (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
  }
  case TAG_EApp: {
    return MK_INT(0LL);
  }
  case TAG_ELet: {
    return MK_INT(0LL);
  }
  case TAG_ERecord: {
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    return MK_INT(0LL);
  }
  case TAG_EPrim: {
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    return MK_INT(0LL);
  }
  case TAG_EValues: {
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_b_240);
  }
}
V g_heff_2ecompile_2efacts_2earityOfBody_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2earityOfBody(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efacts_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2efacts_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 2);
    V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_key_243, v_t_248));
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2efacts_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2earityOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2efacts_2etailApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2etailApp_entry, 1, 0};

V g_heff_2ecompile_2efacts_2etailApp(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_True);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    HEFF_LAST return g_list_2eany_24s495437461x764444341(v_arms_2420);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    V v_b_2436 = heff_field(v_e_240, 2);
    V t_0 = v_b_2436;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2efacts_2etailApp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2etailApp(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efacts_2etailGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2etailGlobals_entry, 1, 0};

V g_heff_2ecompile_2efacts_2etailGlobals(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2420));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s249275339x7045056(a_0, a_1)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    V v_g_2425 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_Cons, 2, (V[]){v_g_2425, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    V v_b_2437 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_2437;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2efacts_2etailGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2etailGlobals(a[0]);
}
V g_heff_2ecompile_2efacts_2ebodyBounces_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2ebodyBounces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2ebodyBounces_entry, 2, 0};

V g_heff_2ecompile_2efacts_2ebodyBounces(V v_set_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_body_242, 1);
    heff_take_n(v_body_242, 2ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2efacts_2etailApp(v_b_247));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_key_243);
      heff_drop(v_b_247);
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V v_t_249 = (g_heff_2ecompile_2efacts_2etailGlobals(v_b_247));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efacts_2ebodyBounces_lam0, 1, 2, (V[]){v_key_243, heff_dup(v_set_240)}); V a_1 = v_t_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2efacts_2ebodyBounces_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2ebodyBounces(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efacts_2ebodyBounces_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_key_243 = heff_env(self)[0];
  V v_set_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (!heff_strEq_c_lent(v_g_2410, v_key_243, 0)) {
    heff_drop(v_key_243);
    HeffT2 v_t_2411 = ({ V a_0 = v_set_240; V a_1 = v_g_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_set_240); heff_drop(v_g_2410); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2412 == ((int64_t)0ULL)) && ({ V v_x_2414 = heff_dup(v_field_2413); int c_ = 1; heff_drop(v_x_2414); c_; })));
      heff_drop(v_field_2413);
      return v_ret_24bool;
    }
  } else {
    heff_drop(v_g_2410);
    heff_drop(v_key_243);
    heff_drop(v_set_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2ebounceGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2ebounceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2ebounceGo_entry, 2, 0};

V g_heff_2ecompile_2efacts_2ebounceGo(V v_defs_240, V v_set_241) {
top: ;
  V v_t_245 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2efacts_2ebounceGo_lam0, 2, 1, (V[]){heff_dup(v_set_241)}), heff_dup(v_set_241), v_defs_240));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_std_2emap_2esize(a_0)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_std_2emap_2esize(v_set_241));
  if (heff_intEq_c(v_t_246, v_t_247)) {
    return v_set_241;
  } else {
    V v_t_2411 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2efacts_2ebounceGo_lam1, 2, 1, (V[]){heff_dup(v_set_241)}), v_set_241, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_2411;
    v_defs_240 = t_0;
    v_set_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2ebounceGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_d_243 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_243); V r_ = (g_heff_2ecompile_2efacts_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, heff_get_n(v_d_243, 0, 3), NTAG(TAG_MkUnit)));
  } else {
    heff_drop_rec(v_d_243, 3);
    heff_drop(v_t_244);
    return v_m_242;
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam1(V self, V *args) {
  V v_m_248 = args[0];
  V v_d_249 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_249); V r_ = (g_heff_2ecompile_2efacts_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_248, heff_get_n(v_d_249, 0, 3), NTAG(TAG_MkUnit)));
  } else {
    heff_drop_rec(v_d_249, 3);
    heff_drop(v_t_2410);
    return v_m_248;
  }
}
V g_heff_2ecompile_2efacts_2elazyOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2elazyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2elazyOf_entry, 3, 0};

V g_heff_2ecompile_2efacts_2elazyOf(V v_seen_240, V v_key_241, V v_b_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2efacts_2earityOfBody(v_b_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    V v_t_244 = (g_heff_2ecompile_2eir_2eisValue(v_b_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
      V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
      V v_x1_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efacts_2elazyOf_lam0, 1, 2, (V[]){heff_dup(v_key_241), heff_dup(v_seen_240)}); V a_1 = v_t_246; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_246); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
      heff_drop(v_x1_2412);
      return v_ret_24bool;
    } else {
      heff_drop(v_b_242);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    }
  } else {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efacts_2elazyOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efacts_2elazyOf(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efacts_2elazyOf_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_key_241 = heff_env(self)[0];
  V v_seen_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (!heff_strEq_c_lent(v_k_247, v_key_241, 0)) {
    heff_drop(v_key_241);
    HeffT2 v_t_248 = ({ V a_0 = v_seen_240; V a_1 = v_k_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_seen_240); heff_drop(v_k_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_lz_2411 = v_field_2410;
        V v_ret_24bool = heff_bool(!(heff_dup(v_lz_2411) == NTAG(TAG_True)));
        heff_drop(v_lz_2411);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2410);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop(v_k_247);
    heff_drop(v_key_241);
    heff_drop(v_seen_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efacts_2eflatInto_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2eflatInto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2eflatInto_entry, 3, 0};

V g_heff_2ecompile_2efacts_2eflatInto(V v_m_240, V v_t_241, V v_is_242) {
top: ;
  switch (heff_tag_of(v_is_242)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    return v_m_240;
  }
  case TAG_Cons: {
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_m_240, v_t_241));
    V v_t_2413;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_xs_249;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        v_xs_249 = v_x_248;
      } else {
        heff_drop(v_field_247);
        v_xs_249 = NTAG(TAG_Nil);
      }
      V v_t_2412 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2eflatInto_lam0, 1, 1, (V[]){heff_dup(v_xs_249)}), v_is_242));
      v_t_2413 = (g_prelude_2e_2b_2b(v_xs_249, v_t_2412));
    }
    HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_241, v_t_2413);
  }
  default: return heff_nomatch(v_is_242);
  }
}
V g_heff_2ecompile_2efacts_2eflatInto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2eflatInto(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efacts_2eflatInto_lam0(V self, V *args) {
  V v_y_2410 = args[0];
  V v_xs_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_y_2410; V a_1 = v_xs_249; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efacts_2eflatW_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2eflatW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2eflatW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2eflatW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_args_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_args_249, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2414;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2417;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_t_2422 = heff_field(v_x21_242, 0);
      V v_args_2423 = heff_field(v_x21_242, 1);
      V v_ts_2424 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_n_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
      V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2425, MK_INT(1LL))));
      V v_rs_2429 = (g_list_2emap_24tok2(v_ru_24x2_241_24Cons, heff_clo_n(g_heff_2ecompile_2efacts_2eflatW_lam0, 1, 1, (V[]){v_ts_2424}), v_t_2426));
      V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2429));
      V v_t_2431 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2430, MK_INT(1LL))));
      V v_t_2432 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2431, v_rs_2429));
      V v_t_2433 = (g_list_2ekeepIf_24s110788034x1785682300(v_t_2432));
      V v_t_2434 = (g_list_2emap_24s1937570095x2110149801(v_t_2433));
      V v_t_2435 = (g_heff_2ecompile_2efacts_2eflatInto(v_m_240, v_t_2422, v_t_2434));
      V v_t_2436 = (g_heff_2ecompile_2eir_2eappendI(v_args_2423, v_rest_243));
      V t_0 = v_t_2435;
      V t_1 = v_t_2436;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2437 = heff_field(v_x21_242, 0);
      V v_arms_2438 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2438, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2437, v_t_2439});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2442 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2443 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2442, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2443;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2445 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2446 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2445, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2446;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2454 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2455 = ({ V a_0 = v_c_2454; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2454); r_; });
      V t_0 = v_m_240;
      V t_1 = v_t_2455;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2457 = heff_field(v_x21_242, 1);
      V v_b_2458 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2459 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2457, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2458, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2459;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2460 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2461 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2460, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2461;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      V v_b_2463 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_2463, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2eflatW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2eflatW_lam0(V self, V *args) {
  V v_i_2427 = args[0];
  V v_ts_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = ({ V a_0 = heff_dup(v_i_2427); V a_1 = v_ts_2424; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2424); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2427, v_t_2428));
}
V g_heff_2ecompile_2efacts_2esureW_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2esureW_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2esureW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2esureW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2esureW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_args_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_args_249, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2414;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2417;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_t_2422 = heff_field(v_x21_242, 0);
      V v_args_2423 = heff_field(v_x21_242, 1);
      V v_ts_2424 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_n_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
      V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2425, MK_INT(1LL))));
      V v_rs_2429 = (g_list_2emap_24tok2(v_ru_24x2_241_24Cons, heff_clo_n(g_heff_2ecompile_2efacts_2esureW_lam0, 1, 1, (V[]){v_ts_2424}), v_t_2426));
      V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2429));
      V v_t_2431 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2430, MK_INT(1LL))));
      V v_t_2432 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2431, v_rs_2429));
      V v_t_2433 = (g_list_2ekeepIf_24s110788034x1785682300(v_t_2432));
      V v_is_2434 = (g_list_2emap_24s1937570095x2110149801(v_t_2433));
      HeffT2 v_t_2435 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_m_240, v_t_2422));
      V v_t_2441;
      {
        V v_field_2437 = v_t_2435.f[1];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          V v_js_2438 = v_field_2437;
          V v_t_2440 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2esureW_lam1, 1, 1, (V[]){v_is_2434}), v_js_2438));
          v_t_2441 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_2422, v_t_2440));
        } else {
          heff_drop(v_field_2437);
          v_t_2441 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_2422, v_is_2434));
        }
      }
      V v_t_2442 = (g_heff_2ecompile_2eir_2eappendI(v_args_2423, v_rest_243));
      V t_0 = v_t_2441;
      V t_1 = v_t_2442;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2443 = heff_field(v_x21_242, 0);
      V v_arms_2444 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2445 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2444, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2443, v_t_2445});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2448 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2449 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2448, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2449;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2451 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2452 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2451, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2452;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2460 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2461 = ({ V a_0 = v_c_2460; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2460); r_; });
      V t_0 = v_m_240;
      V t_1 = v_t_2461;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2463 = heff_field(v_x21_242, 1);
      V v_b_2464 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2465 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2463, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2464, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2465;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2466 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2467 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2466, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2467;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      V v_b_2469 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_2469, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2esureW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2esureW_lam0(V self, V *args) {
  V v_i_2427 = args[0];
  V v_ts_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = ({ V a_0 = heff_dup(v_i_2427); V a_1 = v_ts_2424; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2424); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2427, v_t_2428));
}
V g_heff_2ecompile_2efacts_2esureW_lam1(V self, V *args) {
  V v_j_2439 = args[0];
  V v_is_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_j_2439; V a_1 = v_is_2434; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_is_2434); r_; });
}
HEFF_LIT(g_heff_2ecompile_2efacts_2esureRecW_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2efacts_2esureRecW_str1, 1, ",");
V g_heff_2ecompile_2efacts_2esureRecW_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2esureRecW_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2esureRecW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2esureRecW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2esureRecW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_args_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_args_249, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2414;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      V v_ts_2416 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ERecord = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_ls_2417 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x2_241_24Cons, heff_dup(v_fs_2415)));
      V v_t_2420;
      switch (heff_tag_of(v_ls_2417)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2ecompile_2efacts_2esureRecW_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_ls_2417, 0);
        V v_xs_2419 = heff_field(v_ls_2417, 1);
        heff_take_n(v_ls_2417, 3ULL, 2);
        v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2efacts_2esureRecW_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2417);
      }
      V v_n_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2415));
      V v_t_2422 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2421, MK_INT(1LL))));
      V v_rs_2425 = (g_list_2emap_24tok2(v_ru_24x21_242_24ERecord, heff_clo_n(g_heff_2ecompile_2efacts_2esureRecW_lam0, 1, 1, (V[]){v_ts_2416}), v_t_2422));
      V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2425));
      V v_t_2427 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2426, MK_INT(1LL))));
      V v_t_2428 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2427, v_rs_2425));
      V v_t_2429 = (g_list_2ekeepIf_24s110788034x1785682300(v_t_2428));
      V v_is_2430 = (g_list_2emap_24s1937570095x2110149801(v_t_2429));
      HeffT2 v_t_2431 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_m_240, v_t_2420));
      V v_t_2437;
      {
        V v_field_2433 = v_t_2431.f[1];
        int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
        if ((v_tag_2432 == ((int64_t)0ULL))) {
          V v_js_2434 = v_field_2433;
          V v_t_2436 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2esureRecW_lam1, 1, 1, (V[]){v_is_2430}), v_js_2434));
          v_t_2437 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_2420, v_t_2436));
        } else {
          heff_drop(v_field_2433);
          v_t_2437 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_2420, v_is_2430));
        }
      }
      V v_t_2438 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = v_t_2437;
      V t_1 = v_t_2438;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2439 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2439, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2444 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2446 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2444, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2446;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2447 = heff_field(v_x21_242, 0);
      V v_arms_2448 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2449 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2448, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2447, v_t_2449});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2452 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2453 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2452, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2453;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2455 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2456 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2455, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2456;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2464 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2465 = ({ V a_0 = v_c_2464; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2464); r_; });
      V t_0 = v_m_240;
      V t_1 = v_t_2465;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2467 = heff_field(v_x21_242, 1);
      V v_b_2468 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2469 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2467, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2468, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2469;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2470 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2471 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2470, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2471;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      V v_b_2473 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_2473, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2esureRecW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2esureRecW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2esureRecW_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_ts_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = ({ V a_0 = heff_dup(v_i_2423); V a_1 = v_ts_2416; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2416); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2423, v_t_2424));
}
V g_heff_2ecompile_2efacts_2esureRecW_lam1(V self, V *args) {
  V v_j_2435 = args[0];
  V v_is_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_j_2435; V a_1 = v_is_2430; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_is_2430); r_; });
}
Clo g_heff_2ecompile_2efacts_2efactsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2efactsOf_entry, 1, 0};

V g_heff_2ecompile_2efacts_2efactsOf(V v_defs_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1232551929x416126852(heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  V v_t_242 = (g_heff_2ecompile_2efacts_2ebounceGo(v_defs_240, heff_dup(g_std_2emap_2eempty_get())));
  V v_m_243 = (g_list_2efoldl_24s1722165992x1349408496(heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  V v_t_244 = ({ V a_0 = v_m_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_243); r_; });
  V v_t_245 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s532345456x1351763934(a_0, a_1)); heff_drop(v_t_244); r_; });
  return heff_rec_n(11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, (V[]){v_t_241, v_t_242, v_t_245, heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_heff_2ecompile_2efacts_2enoTokens_get())});
}
V g_heff_2ecompile_2efacts_2efactsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2efactsOf(a0); heff_drop(a0); return r;
}