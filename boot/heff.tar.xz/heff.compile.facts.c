// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define LBL_body 9524841
#define LBL_key 315609
V g_heff_2ecompile_2efacts_2earityOne(V, V);
V g_heff_2ecompile_2efacts_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2earityOne_clo;
V g_heff_2ecompile_2efacts_2ebodyBounces(V, V);
V g_heff_2ecompile_2efacts_2ebodyBounces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ebodyBounces_clo;
V g_heff_2ecompile_2efacts_2ebounceGo(V, V);
V g_heff_2ecompile_2efacts_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ebounceGo_clo;
V g_heff_2ecompile_2efacts_2eflatInto(V, V, V);
V g_heff_2ecompile_2efacts_2eflatInto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2eflatInto_clo;
V g_heff_2ecompile_2efacts_2eflatW(V, V);
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2eflatW_clo;
V g_heff_2ecompile_2efacts_2elazyOf(V, V, V);
V g_heff_2ecompile_2efacts_2elazyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2elazyOf_clo;
V g_heff_2ecompile_2efacts_2esureW(V, V);
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureW_clo;
V g_heff_2ecompile_2efacts_2etailApp(V);
V g_heff_2ecompile_2efacts_2etailApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailApp_clo;
V g_heff_2ecompile_2efacts_2etailGlobals(V);
V g_heff_2ecompile_2efacts_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2etailGlobals_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2eany_24s495437461x764444341(V);
V g_list_2eany_24s495437461x764444341_entry(V self, V *a);
extern Clo g_list_2eany_24s495437461x764444341_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s33860258x1274478326(V);
V g_list_2efilter_24s33860258x1274478326_entry(V self, V *a);
extern Clo g_list_2efilter_24s33860258x1274478326_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s249275339x7045056(V, V);
V g_list_2efoldl_24s249275339x7045056_entry(V self, V *a);
extern Clo g_list_2efoldl_24s249275339x7045056_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2efacts_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2efacts_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_247, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2efacts_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2earityOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2efacts_2etailApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2etailApp_entry, 1, 0};

V g_heff_2ecompile_2efacts_2etailApp(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_True);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    HEFF_LAST return g_list_2eany_24s495437461x764444341(v_arms_2420);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2efacts_2etailApp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2etailApp(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efacts_2etailGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2etailGlobals_entry, 1, 0};

V g_heff_2ecompile_2efacts_2etailGlobals(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2420));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s249275339x7045056(a_0, a_1)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    V v_g_2425 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_Cons, 2, (V[]){v_g_2425, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2efacts_2etailGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2etailGlobals(a[0]);
}
V g_heff_2ecompile_2efacts_2ebodyBounces_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2ebodyBounces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2ebodyBounces_entry, 2, 0};

V g_heff_2ecompile_2efacts_2ebodyBounces(V v_set_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 2ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2efacts_2etailApp(v_b_246));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop_rec(v_d_241, 3);
      heff_drop(v_b_246);
      heff_drop(v_t_247);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_247);
      V v_t_248 = (g_heff_2ecompile_2efacts_2etailGlobals(v_b_246));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efacts_2ebodyBounces_lam0, 1, 2, (V[]){v_d_241, heff_dup(v_set_240)}); V a_1 = v_t_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2efacts_2ebodyBounces_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2ebodyBounces(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efacts_2ebodyBounces_lam0(V self, V *args) {
  V v_g_249 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_set_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_g_249), heff_get_n(v_d_241, 0, 3))) {
    heff_drop(v_g_249);
    heff_drop(v_set_240);
    return NTAG(TAG_False);
  } else {
    V v_x3_2411 = ({ V a_0 = v_g_249; V a_1 = v_set_240; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_set_240); r_; });
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_2411);
    }
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2ebounceGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2ebounceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2ebounceGo_entry, 2, 0};

V g_heff_2ecompile_2efacts_2ebounceGo(V v_defs_240, V v_set_241) {
top: ;
  V v_t_245 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2efacts_2ebounceGo_lam0, 2, 1, (V[]){heff_dup(v_set_241)}), heff_dup(v_set_241), v_defs_240));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_map_2esize(a_0)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_map_2esize(v_set_241));
  if (heff_intEq_c(v_t_246, v_t_247)) {
    return v_set_241;
  } else {
    V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2efacts_2ebounceGo_lam1, 2, 1, (V[]){heff_dup(v_set_241)}), v_set_241, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_2412;
    v_defs_240 = t_0;
    v_set_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2ebounceGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_d_243 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_243); V r_ = (g_heff_2ecompile_2efacts_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_243, 0, 3), NTAG(TAG_MkUnit), v_m_242));
  } else {
    heff_drop_rec(v_d_243, 3);
    heff_drop(v_t_244);
    return v_m_242;
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam1(V self, V *args) {
  V v_m_249 = args[0];
  V v_d_2410 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_2410); V r_ = (g_heff_2ecompile_2efacts_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_2410, 0, 3), NTAG(TAG_MkUnit), v_m_249));
  } else {
    heff_drop_rec(v_d_2410, 3);
    heff_drop(v_t_2411);
    return v_m_249;
  }
}
V g_heff_2ecompile_2efacts_2elazyOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2elazyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2elazyOf_entry, 3, 0};

V g_heff_2ecompile_2efacts_2elazyOf(V v_seen_240, V v_key_241, V v_b_242) {
top: ;
  V v_t_2437;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EGlobal: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_dup(heff_field(v_b_242, 0));
    v_t_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  case TAG_EApp: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_ELet: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_ERecord: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EProj: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_ETag: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EMatch: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EPrim: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_ECall: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EInt: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EStr: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EBytes: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EFixed: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat32: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EAbandon: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  case TAG_EFix: {
    v_t_2437 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_b_242);
  }
  if (heff_intEq_c(v_t_2437, MK_INT(0LL))) {
    V v_t_2439 = (g_heff_2ecompile_2eir_2eisValue(v_b_242));
    V v_x1_2446;
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      V v_t_2440 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
      V v_t_2441 = (g_heff_2ecompile_2eir_2enubI(v_t_2440));
      v_x1_2446 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efacts_2elazyOf_lam0, 1, 2, (V[]){v_key_241, heff_dup(v_seen_240)}); V a_1 = v_t_2441; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2441); r_; });
    } else {
      heff_drop(v_key_241);
      heff_drop(v_b_242);
      heff_drop(v_t_2439);
      v_x1_2446 = NTAG(TAG_False);
    }
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2446) == NTAG(TAG_True)));
    heff_drop(v_x1_2446);
    return v_ret_24bool;
  } else {
    heff_drop(v_key_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efacts_2elazyOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2elazyOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efacts_2elazyOf_lam0(V self, V *args) {
  V v_k_2442 = args[0];
  V v_key_241 = heff_env(self)[0];
  V v_seen_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_k_2442), v_key_241)) {
    heff_drop(v_k_2442);
    heff_drop(v_seen_240);
    return NTAG(TAG_False);
  } else {
    V v_t_2444 = ({ V a_0 = v_k_2442; V a_1 = v_seen_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_seen_240); r_; });
    switch (heff_tag_of(v_t_2444)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_lz_2445 = heff_field(v_t_2444, 0);
      heff_take_n(v_t_2444, 1ULL, 1);
      V v_ret_24bool = heff_bool(!(heff_dup(v_lz_2445) == NTAG(TAG_True)));
      heff_drop(v_lz_2445);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
}
V g_heff_2ecompile_2efacts_2eflatInto_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2eflatInto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2eflatInto_entry, 3, 0};

V g_heff_2ecompile_2efacts_2eflatInto(V v_m_240, V v_t_241, V v_is_242) {
top: ;
  switch (heff_tag_of(v_is_242)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x2_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_t_241), v_m_240));
    V v_xs_247;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_xs_247 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_xs_247 = v_x_246;
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2efacts_2eflatInto_lam0, 1, 1, (V[]){heff_dup(v_xs_247)}), v_is_242));
    V v_t_2411 = (g_prelude_2e_2b_2b(v_xs_247, v_t_2410));
    HEFF_LAST return g_map_2einsert_24s1341440536x470972936(v_t_241, v_t_2411, v_m_240);
  }
  default: return heff_nomatch(v_is_242);
  }
}
V g_heff_2ecompile_2efacts_2eflatInto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2eflatInto(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efacts_2eflatInto_lam0(V self, V *args) {
  V v_y_248 = args[0];
  V v_xs_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_y_248; V a_1 = v_xs_247; V r_ = (g_list_2eany_24s120814613x1439363162(a_0, a_1)); heff_drop(v_xs_247); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efacts_2eflatW_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2eflatW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2eflatW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2eflatW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_as_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI(v_as_249, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2414;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2417;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_t_2422 = heff_field(v_x21_242, 0);
      V v_as_2423 = heff_field(v_x21_242, 1);
      V v_ts_2424 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_n_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2423));
      V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2425, MK_INT(1LL))));
      V v_rs_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efacts_2eflatW_lam0, 1, 1, (V[]){v_ts_2424}), v_t_2426));
      V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2429));
      V v_t_2431 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2430, MK_INT(1LL))));
      V v_t_2432 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2431, v_rs_2429));
      V v_t_2433 = (g_list_2efilter_24s33860258x1274478326(v_t_2432));
      V v_t_2434 = (g_list_2emap_24s1937570095x2110149801(v_t_2433));
      V v_t_2435 = (g_heff_2ecompile_2efacts_2eflatInto(v_m_240, v_t_2422, v_t_2434));
      V v_t_2436 = (g_heff_2ecompile_2eir_2eappendI(v_as_2423, v_rest_243));
      V t_0 = v_t_2435;
      V t_1 = v_t_2436;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2437 = heff_field(v_x21_242, 0);
      V v_arms_2438 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2438, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2437, v_t_2439});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2442 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2443 = (g_heff_2ecompile_2eir_2eappendI(v_as_2442, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2443;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2445 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2446 = (g_heff_2ecompile_2eir_2eappendI(v_as_2445, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2446;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      V v_b_2455 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_2455, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2eflatW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2eflatW_lam0(V self, V *args) {
  V v_i_2427 = args[0];
  V v_ts_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = ({ V a_0 = heff_dup(v_i_2427); V a_1 = v_ts_2424; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2424); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2427, v_t_2428));
}
V g_heff_2ecompile_2efacts_2esureW_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2esureW_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2esureW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2esureW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2esureW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_as_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI(v_as_249, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2414;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2417;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_t_2422 = heff_field(v_x21_242, 0);
      V v_as_2423 = heff_field(v_x21_242, 1);
      V v_ts_2424 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_n_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2423));
      V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2425, MK_INT(1LL))));
      V v_rs_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efacts_2esureW_lam0, 1, 1, (V[]){v_ts_2424}), v_t_2426));
      V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2429));
      V v_t_2431 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2430, MK_INT(1LL))));
      V v_t_2432 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2431, v_rs_2429));
      V v_t_2433 = (g_list_2efilter_24s33860258x1274478326(v_t_2432));
      V v_is_2434 = (g_list_2emap_24s1937570095x2110149801(v_t_2433));
      V v_t_2435 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_t_2422), v_m_240));
      V v_t_2439;
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nothing: {
        v_t_2439 = (g_map_2einsert_24s1341440536x470972936(v_t_2422, v_is_2434, v_m_240));
        break;
      }
      case TAG_Just: {
        V v_js_2436 = heff_field(v_t_2435, 0);
        heff_take_n(v_t_2435, 1ULL, 1);
        V v_t_2438 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2efacts_2esureW_lam1, 1, 1, (V[]){v_is_2434}), v_js_2436));
        v_t_2439 = (g_map_2einsert_24s1341440536x470972936(v_t_2422, v_t_2438, v_m_240));
        break;
      }
      default: heff_nomatch(v_t_2435);
      }
      V v_t_2440 = (g_heff_2ecompile_2eir_2eappendI(v_as_2423, v_rest_243));
      V t_0 = v_t_2439;
      V t_1 = v_t_2440;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2441 = heff_field(v_x21_242, 0);
      V v_arms_2442 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2443 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2442, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2441, v_t_2443});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2446 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2447 = (g_heff_2ecompile_2eir_2eappendI(v_as_2446, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2447;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2449 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2450 = (g_heff_2ecompile_2eir_2eappendI(v_as_2449, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2450;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      V v_b_2459 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_2459, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2esureW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2esureW_lam0(V self, V *args) {
  V v_i_2427 = args[0];
  V v_ts_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = ({ V a_0 = heff_dup(v_i_2427); V a_1 = v_ts_2424; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2424); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2427, v_t_2428));
}
V g_heff_2ecompile_2efacts_2esureW_lam1(V self, V *args) {
  V v_j_2437 = args[0];
  V v_is_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_j_2437; V a_1 = v_is_2434; V r_ = (g_list_2eany_24s120814613x1439363162(a_0, a_1)); heff_drop(v_is_2434); r_; });
}