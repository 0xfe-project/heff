// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_byFun 295539138
#define LBL_cells 295903083
#define LBL_flat 9641024
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lent 9813446
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tokens 1078955205
#define LBL_tuples 1084651734
#define LBL_words 314676931
#define LBL_workers 1757018875
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words, LBL_tokens};
static uint32_t shape_byFun__cells[] = {LBL_byFun, LBL_cells};
V g_heff_2ecompile_2efacts_2ebodyBounces(V, V);
V g_heff_2ecompile_2efacts_2ebodyBounces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ebodyBounces_clo;
V g_heff_2ecompile_2efacts_2ebounceGo(V, V);
V g_heff_2ecompile_2efacts_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ebounceGo_clo;
HeffT11 g_heff_2ecompile_2efacts_2efactsOf_24cpr(V);
V g_heff_2ecompile_2efacts_2eflatW(V, V);
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2eflatW_clo;
V g_heff_2ecompile_2efacts_2enoTokens_get(void);
V g_heff_2ecompile_2efacts_2esureOnlyHere(V, V, V);
V g_heff_2ecompile_2efacts_2esureOnlyHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureOnlyHere_clo;
V g_heff_2ecompile_2efacts_2esureRecW(V, V);
V g_heff_2ecompile_2efacts_2esureRecW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureRecW_clo;
V g_heff_2ecompile_2efacts_2esureW(V, V);
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureW_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1037819844x481859879(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1037819844x481859879_entry(V self, V *a);
extern Clo g_list_2eany_24s1037819844x481859879_clo;
V g_list_2eany_24s1128783263x249153925(V, V);
V g_list_2eany_24s1128783263x249153925_entry(V self, V *a);
extern Clo g_list_2eany_24s1128783263x249153925_clo;
V g_list_2eany_24s245529025x1335240420(V);
V g_list_2eany_24s245529025x1335240420_entry(V self, V *a);
extern Clo g_list_2eany_24s245529025x1335240420_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1083429683x1325725555(V, V);
V g_list_2efoldl_24s1083429683x1325725555_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1083429683x1325725555_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1372957693x1709266208(V, V);
V g_list_2efoldl_24s1372957693x1709266208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1372957693x1709266208_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s630841978x1026694071(V, V);
V g_list_2efoldl_24s630841978x1026694071_entry(V self, V *a);
extern Clo g_list_2efoldl_24s630841978x1026694071_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s110788034x1785682300(V);
V g_list_2ekeepIf_24s110788034x1785682300_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s110788034x1785682300_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;

static V g_heff_2ecompile_2efacts_2enoTokens_val;
static HEFF_ONCE g_heff_2ecompile_2efacts_2enoTokens_st;
static V g_heff_2ecompile_2efacts_2enoTokens_init(void) {
  return heff_rec_n(2, shape_byFun__cells, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2efacts_2enoTokens_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2efacts_2enoTokens_st)) return g_heff_2ecompile_2efacts_2enoTokens_val;
  return heff_global(&g_heff_2ecompile_2efacts_2enoTokens_val, &g_heff_2ecompile_2efacts_2enoTokens_st, g_heff_2ecompile_2efacts_2enoTokens_init);
}
V g_heff_2ecompile_2efacts_2ebodyBounces_lam0(V self, V *args);
Clo g_heff_2ecompile_2efacts_2ebodyBounces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2ebodyBounces_entry, 2, 0};

V g_heff_2ecompile_2efacts_2ebodyBounces(V v_set_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_body_242, 1);
    heff_take_n(v_body_242, 2ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_247), NTAG(TAG_Nil)));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_list_2eany_24s245529025x1335240420(a_0)); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_key_243);
      heff_drop(v_b_247);
      heff_drop(v_t_249);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_249);
      V v_xs_2410 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b_247, NTAG(TAG_Nil)));
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
      V v_t_2412 = (g_list_2efoldl_24s630841978x1026694071(NTAG(TAG_Nil), v_t_2411));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efacts_2ebodyBounces_lam0, 1, 2, (V[]){v_key_243, heff_dup(v_set_240)}); V a_1 = v_t_2412; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2efacts_2ebodyBounces_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2ebodyBounces(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efacts_2ebodyBounces_lam0(V self, V *args) {
  V v_g_2413 = args[0];
  V v_key_243 = heff_env(self)[0];
  V v_set_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (!heff_strEq_c_lent(v_g_2413, v_key_243, 0)) {
    heff_drop(v_key_243);
    HeffT2 v_t_2414 = ({ V a_0 = v_set_240; V a_1 = v_g_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_set_240); heff_drop(v_g_2413); r_; });
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2415 == ((int64_t)0ULL)) && ({ V v_x_2417 = heff_dup(v_field_2416); int c_ = 1; heff_drop(v_x_2417); c_; })));
      heff_drop(v_field_2416);
      return v_ret_24bool;
    }
  } else {
    heff_drop(v_g_2413);
    heff_drop(v_key_243);
    heff_drop(v_set_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2ebounceGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2ebounceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2ebounceGo_entry, 2, 0};

V g_heff_2ecompile_2efacts_2ebounceGo(V v_defs_240, V v_set_241) {
top: ;
  V v_t_245 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2efacts_2ebounceGo_lam0, 2, 1, (V[]){heff_dup(v_set_241)}), heff_dup(v_set_241), v_defs_240));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_std_2eordmap_2esize(a_0)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_std_2eordmap_2esize(v_set_241));
  if (heff_intEq_c(v_t_246, v_t_247)) {
    return v_set_241;
  } else {
    V v_t_2411 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2efacts_2ebounceGo_lam1, 2, 1, (V[]){heff_dup(v_set_241)}), v_set_241, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_2411;
    v_defs_240 = t_0;
    v_set_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efacts_2ebounceGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_d_243 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_243); V r_ = (g_heff_2ecompile_2efacts_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, heff_get_n(v_d_243, 0, 3), NTAG(TAG_MkUnit)));
  } else {
    heff_drop_rec(v_d_243, 3);
    heff_drop(v_t_244);
    return v_m_242;
  }
}
V g_heff_2ecompile_2efacts_2ebounceGo_lam1(V self, V *args) {
  V v_m_248 = args[0];
  V v_d_249 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_249); V r_ = (g_heff_2ecompile_2efacts_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_248, heff_get_n(v_d_249, 0, 3), NTAG(TAG_MkUnit)));
  } else {
    heff_drop_rec(v_d_249, 3);
    heff_drop(v_t_2410);
    return v_m_248;
  }
}
V g_heff_2ecompile_2efacts_2eflatW_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2eflatW_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2eflatW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2eflatW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2eflatW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ETag: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_args_245 = heff_field(v_x21_242, 1);
      V v_ts_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_m_247 = v_m_240;
      V v_t_248 = v_t_244;
      V v_n_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_245));
      V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_249, MK_INT(1LL))));
      V v_rs_2413 = (g_list_2emap_24tok2(v_ru_24x2_241_24Cons, heff_clo_n(g_heff_2ecompile_2efacts_2eflatW_lam0, 1, 1, (V[]){v_ts_246}), v_t_2410));
      V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2413));
      V v_t_2415 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
      V v_t_2416 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2415, v_rs_2413));
      V v_t_2417 = (g_list_2ekeepIf_24s110788034x1785682300(v_t_2416));
      V v_is_2418 = (g_list_2emap_24s1937570095x2110149801(v_t_2417));
      V v_t_2430;
      switch (heff_tag_of(v_is_2418)) {
      case TAG_Nil: {
        heff_drop(v_t_248);
        v_t_2430 = v_m_247;
        break;
      }
      case TAG_Cons: {
        HeffT2 v_t_2421 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_247, v_t_248));
        V v_t_2429;
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          V v_xs_2425;
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_x_2424 = v_field_2423;
            v_xs_2425 = v_x_2424;
          } else {
            heff_drop(v_field_2423);
            v_xs_2425 = NTAG(TAG_Nil);
          }
          V v_t_2428 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2eflatW_lam1, 1, 1, (V[]){heff_dup(v_xs_2425)}), v_is_2418));
          v_t_2429 = (g_prelude_2e_2b_2b(v_xs_2425, v_t_2428));
        }
        v_t_2430 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_247, v_t_248, v_t_2429));
        break;
      }
      default: heff_nomatch(v_is_2418);
      }
      V v_t_2431 = (g_heff_2ecompile_2eir_2eappendI(v_args_245, v_rest_243));
      V t_0 = v_t_2430;
      V t_1 = v_t_2431;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2432;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2eflatW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2eflatW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2eflatW_lam0(V self, V *args) {
  V v_i_2411 = args[0];
  V v_ts_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = heff_dup(v_i_2411); V a_1 = v_ts_246; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_246); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2411, v_t_2412));
}
V g_heff_2ecompile_2efacts_2eflatW_lam1(V self, V *args) {
  V v_y_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2427 = ({ V a_0 = v_y_2426; V a_1 = v_xs_2425; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_xs_2425); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2427) == NTAG(TAG_True)));
  heff_drop(v_x1_2427);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efacts_2esureW_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2esureW_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2esureW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2esureW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2esureW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ETag: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_args_245 = heff_field(v_x21_242, 1);
      V v_ts_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_n_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_245));
      V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_247, MK_INT(1LL))));
      V v_rs_2411 = (g_list_2emap_24tok2(v_ru_24x2_241_24Cons, heff_clo_n(g_heff_2ecompile_2efacts_2esureW_lam0, 1, 1, (V[]){v_ts_246}), v_t_248));
      V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2411));
      V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2412, MK_INT(1LL))));
      V v_t_2414 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2413, v_rs_2411));
      V v_t_2415 = (g_list_2ekeepIf_24s110788034x1785682300(v_t_2414));
      V v_is_2416 = (g_list_2emap_24s1937570095x2110149801(v_t_2415));
      HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_240, v_t_244));
      V v_t_2423;
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_js_2420 = v_field_2419;
          V v_t_2422 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2esureW_lam1, 1, 1, (V[]){v_is_2416}), v_js_2420));
          v_t_2423 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, v_t_244, v_t_2422));
        } else {
          heff_drop(v_field_2419);
          v_t_2423 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, v_t_244, v_is_2416));
        }
      }
      V v_t_2424 = (g_heff_2ecompile_2eir_2eappendI(v_args_245, v_rest_243));
      V t_0 = v_t_2423;
      V t_1 = v_t_2424;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2425 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2425;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2esureW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2esureW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2esureW_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_ts_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = ({ V a_0 = heff_dup(v_i_249); V a_1 = v_ts_246; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_246); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_249, v_t_2410));
}
V g_heff_2ecompile_2efacts_2esureW_lam1(V self, V *args) {
  V v_j_2421 = args[0];
  V v_is_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_j_2421; V a_1 = v_is_2416; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_is_2416); r_; });
}
HEFF_LIT(g_heff_2ecompile_2efacts_2esureRecW_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2efacts_2esureRecW_str1, 1, ",");
V g_heff_2ecompile_2efacts_2esureRecW_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2esureRecW_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2esureRecW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2esureRecW_entry, 2, 0};

V g_heff_2ecompile_2efacts_2esureRecW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ERecord: {
      V v_fs_244 = heff_field(v_x21_242, 0);
      V v_ts_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ERecord = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_ls_246 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x2_241_24Cons, heff_dup(v_fs_244)));
      V v_t_249;
      switch (heff_tag_of(v_ls_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2ecompile_2efacts_2esureRecW_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_ls_246, 0);
        V v_xs_248 = heff_field(v_ls_246, 1);
        heff_take_n(v_ls_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2efacts_2esureRecW_str1); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_ls_246);
      }
      V v_n_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_244));
      V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2410, MK_INT(1LL))));
      V v_rs_2414 = (g_list_2emap_24tok2(v_ru_24x21_242_24ERecord, heff_clo_n(g_heff_2ecompile_2efacts_2esureRecW_lam0, 1, 1, (V[]){v_ts_245}), v_t_2411));
      V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rs_2414));
      V v_t_2416 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL))));
      V v_t_2417 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2416, v_rs_2414));
      V v_t_2418 = (g_list_2ekeepIf_24s110788034x1785682300(v_t_2417));
      V v_is_2419 = (g_list_2emap_24s1937570095x2110149801(v_t_2418));
      HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_240, v_t_249));
      V v_t_2426;
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_js_2423 = v_field_2422;
          V v_t_2425 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2esureRecW_lam1, 1, 1, (V[]){v_is_2419}), v_js_2423));
          v_t_2426 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, v_t_249, v_t_2425));
        } else {
          heff_drop(v_field_2422);
          v_t_2426 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, v_t_249, v_is_2419));
        }
      }
      V v_t_2427 = (g_heff_2ecompile_2eir_2epushFields(v_fs_244, v_rest_243));
      V t_0 = v_t_2426;
      V t_1 = v_t_2427;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2428;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efacts_2esureRecW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efacts_2esureRecW(a[0], a[1]);
}
V g_heff_2ecompile_2efacts_2esureRecW_lam0(V self, V *args) {
  V v_i_2412 = args[0];
  V v_ts_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = ({ V a_0 = heff_dup(v_i_2412); V a_1 = v_ts_245; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_245); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2412, v_t_2413));
}
V g_heff_2ecompile_2efacts_2esureRecW_lam1(V self, V *args) {
  V v_j_2424 = args[0];
  V v_is_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_j_2424; V a_1 = v_is_2419; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_is_2419); r_; });
}

HeffT11 g_heff_2ecompile_2efacts_2efactsOf_24cpr(V v_defs_240) {
top: ;
  V v_f_241 = (g_list_2efoldl_24s445268946x679229867(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_240));
  V v_f_242 = (g_heff_2ecompile_2efacts_2ebounceGo(v_defs_240, heff_dup(g_std_2eordmap_2eempty_get())));
  V v_m_243 = (g_list_2efoldl_24s1083429683x1325725555(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_240));
  V v_t_244 = ({ V a_0 = v_m_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_243); r_; });
  V v_f_245 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1372957693x1709266208(a_0, a_1)); heff_drop(v_t_244); r_; });
  return ((HeffT11){{v_f_241, v_f_242, v_f_245, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_heff_2ecompile_2efacts_2enoTokens_get())}});
}
HEFF_LIT(g_heff_2ecompile_2efacts_2esureOnlyHere_str0, 1, ",");
HEFF_LIT(g_heff_2ecompile_2efacts_2esureOnlyHere_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2efacts_2esureOnlyHere_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2efacts_2esureOnlyHere_str3, 1, ",");
V g_heff_2ecompile_2efacts_2esureOnlyHere_lam0(V self, V *args);
V g_heff_2ecompile_2efacts_2esureOnlyHere_lam1(V self, V *args);
Clo g_heff_2ecompile_2efacts_2esureOnlyHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efacts_2esureOnlyHere_entry, 3, 0};

V g_heff_2ecompile_2efacts_2esureOnlyHere(V v_tags_240, V v_lbls_241, V v_f_242) {
top: ;
  V v_t_243 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_f_242, 7), NTAG(TAG_Nil)));
  V v_ps_246 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2esureOnlyHere_lam0, 1, 1, (V[]){heff_dup(v_lbls_241)}), v_t_243));
  V v_su_247 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_246; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_246); r_; });
  V v_t_248 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_f_242, 6), NTAG(TAG_Nil)));
  V v_ps_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2efacts_2esureOnlyHere_lam1, 1, 1, (V[]){heff_dup(v_tags_240)}), v_t_248));
  V v_su_2412 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2411; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2411); r_; });
  V v_t_2413 = heff_take_field(v_f_242, 0);
  V v_t_2414 = heff_take_field(v_f_242, 1);
  V v_t_2415 = heff_take_field(v_f_242, 2);
  V v_t_2416 = heff_take_field(v_f_242, 3);
  V v_t_2417 = heff_take_field(v_f_242, 4);
  V v_t_2418 = heff_take_field(v_f_242, 5);
  V v_t_2419 = heff_take_field(v_f_242, 8);
  V v_t_2420 = heff_take_field(v_f_242, 9);
  return ({ V rv_0 = v_t_2413; V rv_1 = v_t_2414; V rv_2 = v_t_2415; V rv_3 = v_t_2416; V rv_4 = v_t_2417; V rv_5 = v_t_2418; V rv_6 = v_su_2412; V rv_7 = v_su_247; V rv_8 = v_t_2419; V rv_9 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_f_242, 1024ULL, 11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, 3145728u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2ecompile_2efacts_2esureOnlyHere_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efacts_2esureOnlyHere(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efacts_2esureOnlyHere_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_lbls_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2efacts_2esureOnlyHere_str0); V a_2 = ((V)&g_heff_2ecompile_2efacts_2esureOnlyHere_str1); V a_3 = ((V)&g_heff_2ecompile_2efacts_2esureOnlyHere_str2); V a_4 = v_p_244; V a_5 = ((V)&g_heff_2ecompile_2efacts_2esureOnlyHere_str3); V b_6 = MK_INT(0LL); V a_7 = v_lbls_241; V r_ = (g_list_2eany_24s1037819844x481859879(a_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7)); heff_drop(v_p_244); heff_drop(b_6); heff_drop(v_lbls_241); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efacts_2esureOnlyHere_lam1(V self, V *args) {
  V v_p_249 = args[0];
  V v_tags_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_p_249; V a_1 = v_tags_240; V r_ = (g_list_2eany_24s1128783263x249153925(a_0, a_1)); heff_drop(v_p_249); heff_drop(v_tags_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}