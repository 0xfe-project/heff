// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_aliases 1464806715
#define LBL_answered 245579351
#define LBL_args 9498020
#define LBL_byName 571997869
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_fun 311289
#define LBL_includes 835398315
#define LBL_leaf 9813029
#define LBL_module 878357911
#define LBL_ops 319788
#define LBL_result 1012715336
#define LBL_syntax 1059664654
#define LBL_tag 324116
#define LBL_values 1123329101
static uint32_t shape_module__leaf__includes__ops__entry[] = {LBL_module, LBL_leaf, LBL_includes, LBL_ops, LBL_entry};
static uint32_t shape_tag__fun__args__result__answered[] = {LBL_tag, LBL_fun, LBL_args, LBL_result, LBL_answered};
V g_heff_2ecompile_2eglue_2eappendF_24dps(V, V, V);
V g_heff_2ecompile_2eglue_2eappendF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eappendF_24dps_clo;
HeffT2 g_heff_2ecompile_2eglue_2eargsBad_24cpr(V, V, V, V);
V g_heff_2ecompile_2eglue_2ebindingOf(V, V);
V g_heff_2ecompile_2eglue_2ebindingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ebindingOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(V, V, V);
V g_heff_2ecompile_2eglue_2edescribedIn(V, V);
V g_heff_2ecompile_2eglue_2edescribedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2edescribedIn_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1899415673x1401347262_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2eglueOf(V, V, V);
V g_heff_2ecompile_2eglue_2eglueOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eglueOf_clo;
V g_heff_2ecompile_2eglue_2eisGlobalTy(V, V);
V g_heff_2ecompile_2eglue_2eisGlobalTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eisGlobalTy_clo;
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2ecompile_2eglue_2ejusts_24dps(V, V);
V g_heff_2ecompile_2eglue_2ejusts_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_24dps_clo;
HeffT2 g_heff_2ecompile_2eglue_2elastOf_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(V, V);
V g_heff_2ecompile_2eglue_2ereadOp(V);
V g_heff_2ecompile_2eglue_2ereadOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ereadOp_clo;
HeffT2 g_heff_2ecompile_2eglue_2eresultBad_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eglue_2erightOf_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2esumOf_24cpr(V);
V g_heff_2ecompile_2eglue_2etyOf(V);
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2etyOf_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_heff_2ecompile_2eglue_2eappendF_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eappendF_24dps_entry, 3, 0};

V g_heff_2ecompile_2eglue_2eappendF_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2eappendF_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2eappendF_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1899415673x1401347262_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_v_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_v_241; V r_ = heff_tr(g_heff_2ecompile_2eglue_2ereadOp(a_0)); heff_drop(v_v_241); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      HeffT2 v_t_245 = (g_heff_2ecompile_2eglue_2eeachOf_24s1899415673x1401347262_24cpr(v_rest_242));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_xs_248 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_xs_248})}});
        } else {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_x_244);
          heff_drop(v_field_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_heff_2ecompile_2eglue_2eisGlobalTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eisGlobalTy_entry, 2, 0};

V g_heff_2ecompile_2eglue_2eisGlobalTy(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SU: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24SDecode = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SLocal: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SGlobal: {
      V v_g_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_g_245, v_k_240, 0));
      heff_drop(v_g_245);
      return v_ret_24bool;
    }
    case TAG_SCode: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x21_243, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      V v_e_2421 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      V t_0 = v_k_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24SDecode, TAG_SDecode, 1, (V[]){v_e_2421});
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x21_243, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_x2_241, 0ULL, 5);
    return NTAG(TAG_False);
  }
  case TAG_SRecord: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_SSum: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SIsTy: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SPrimInt: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SFixed: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eglue_2eisGlobalTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eglue_2eisGlobalTy(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eglue_2esumOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_SU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SDecode: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFunction: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRecord: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSum: {
      V v_vs_2414 = heff_field(v_x11_243, 0);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_vs_2414)}});
    }
    case TAG_SIsTy: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimString: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimRune: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrimArray: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_243)}});
    }
  }
  case TAG_SApp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    V v_x12_2421 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2421)) {
    case TAG_MkAbs: {
      V v_body_2423 = heff_field(v_x12_2421, 1);
      V t_0 = v_body_2423;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_AbsConst: {
      V v_body_2424 = heff_field(v_x12_2421, 0);
      V t_0 = v_body_2424;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2421)}});
    }
  }
  case TAG_SCons: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    V v_e_2435 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2435;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eoperationsOf_24cpr_str0, 1, "f");

HeffT2 g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(V v_g_240, V v_k_241) {
top: ;
  V v_entries_242 = heff_take_field(v_g_240, 1);
  V v_aliases_243 = heff_get_n(v_g_240, 2, 8);
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_242, v_k_241));
  V v_t_2412;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_247 = v_field_246;
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_e_247});
    } else {
      heff_drop(v_field_246);
      HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_aliases_243, v_k_241));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_k2_2411 = v_field_2410;
          v_t_2412 = ({ V a_0 = v_entries_242; V a_1 = v_k2_2411; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_k2_2411); r_; });
        } else {
          heff_drop(v_field_2410);
          v_t_2412 = NTAG(TAG_Nothing);
        }
      }
    }
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    heff_drop(v_entries_242);
    heff_drop(v_aliases_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_entry_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    V v_t_2414 = heff_get_n(v_entry_2413, 0, 4);
    switch (heff_tag_of(v_t_2414)) {
    case TAG_SLocal: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLam: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      V v_fs_2422 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      V v_byName_2423 = heff_take_field(v_fs_2422, 1);
      V v_values_2424 = heff_get_n(v_fs_2422, 2, 3);
      HeffT2 v_t_2425 = ({ V a_0 = v_byName_2423; V b_1 = ((V)&g_heff_2ecompile_2eglue_2eoperationsOf_24cpr_str0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_byName_2423); heff_drop(b_1); r_; });
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_i_2428 = v_field_2427;
          V v_xs_2429 = v_values_2424;
          if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2428, 1) && heff_intLt_c(heff_dup(v_i_2428), heff_arrayLength_lent(v_xs_2429, 0)))) {
            V v_t_2430 = heff_arrayIndex(v_xs_2429, v_i_2428);
            switch (heff_tag_of(v_t_2430)) {
            case TAG_SLocal: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SGlobal: {
              V v_fk_2432 = heff_field(v_t_2430, 0);
              heff_take_n(v_t_2430, 1ULL, 1);
              HeffT2 v_t_2433 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_242, v_fk_2432));
              {
                V v_field_2435 = v_t_2433.f[1];
                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                if ((v_tag_2434 == ((int64_t)0ULL))) {
                  heff_drop(v_entries_242);
                  heff_drop(v_aliases_243);
                  heff_drop(v_fk_2432);
                  V v_e_2436 = v_field_2435;
                  return ({ V b_0 = heff_get_n(v_e_2436, 0, 4); HeffT2 r_ = (g_heff_2ecompile_2eglue_2esumOf_24cpr(b_0)); heff_drop(b_0); r_; });
                } else {
                  heff_drop(v_field_2435);
                  HeffT2 v_t_2437 = ({ V a_0 = v_aliases_243; V a_1 = v_fk_2432; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_243); heff_drop(v_fk_2432); r_; });
                  {
                    V v_field_2439 = v_t_2437.f[1];
                    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
                    if ((v_tag_2438 == ((int64_t)0ULL))) {
                      V v_k2_2440 = v_field_2439;
                      HeffT2 v_t_2441 = ({ V a_0 = v_entries_242; V a_1 = v_k2_2440; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_242); heff_drop(v_k2_2440); r_; });
                      {
                        V v_field_2443 = v_t_2441.f[1];
                        int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                        if ((v_tag_2442 == ((int64_t)0ULL))) {
                          V v_fentry_2444 = v_field_2443;
                          return ({ V b_0 = heff_get_n(v_fentry_2444, 0, 4); HeffT2 r_ = (g_heff_2ecompile_2eglue_2esumOf_24cpr(b_0)); heff_drop(b_0); r_; });
                        } else {
                          heff_drop(v_field_2443);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_entries_242);
                      heff_drop(v_field_2439);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
              }
            }
            case TAG_SCode: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SApp: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLam: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SCons: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SProj: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_STag: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SMatch: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SSpecialize: {
              heff_take_n(v_t_2430, 0ULL, 3);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SIs: {
              V v_it11_2460 = heff_field(v_t_2430, 0);
              heff_take_n(v_t_2430, 1ULL, 1);
              switch (heff_tag_of(v_it11_2460)) {
              case TAG_SLocal: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SGlobal: {
                V v_fk_2462 = heff_field(v_it11_2460, 0);
                heff_take_n(v_it11_2460, 1ULL, 1);
                HeffT2 v_t_2463 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_242, v_fk_2462));
                {
                  V v_field_2465 = v_t_2463.f[1];
                  int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                  if ((v_tag_2464 == ((int64_t)0ULL))) {
                    heff_drop(v_entries_242);
                    heff_drop(v_aliases_243);
                    heff_drop(v_fk_2462);
                    V v_e_2466 = v_field_2465;
                    return ({ V b_0 = heff_get_n(v_e_2466, 0, 4); HeffT2 r_ = (g_heff_2ecompile_2eglue_2esumOf_24cpr(b_0)); heff_drop(b_0); r_; });
                  } else {
                    heff_drop(v_field_2465);
                    HeffT2 v_t_2467 = ({ V a_0 = v_aliases_243; V a_1 = v_fk_2462; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_243); heff_drop(v_fk_2462); r_; });
                    {
                      V v_field_2469 = v_t_2467.f[1];
                      int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
                      if ((v_tag_2468 == ((int64_t)0ULL))) {
                        V v_k2_2470 = v_field_2469;
                        HeffT2 v_t_2471 = ({ V a_0 = v_entries_242; V a_1 = v_k2_2470; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_242); heff_drop(v_k2_2470); r_; });
                        {
                          V v_field_2473 = v_t_2471.f[1];
                          int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
                          if ((v_tag_2472 == ((int64_t)0ULL))) {
                            V v_fentry_2474 = v_field_2473;
                            return ({ V b_0 = heff_get_n(v_fentry_2474, 0, 4); HeffT2 r_ = (g_heff_2ecompile_2eglue_2esumOf_24cpr(b_0)); heff_drop(b_0); r_; });
                          } else {
                            heff_drop(v_field_2473);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop(v_entries_242);
                        heff_drop(v_field_2469);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                }
              }
              case TAG_SCode: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SApp: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLam: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SCons: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SProj: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_STag: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SMatch: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SSpecialize: {
                heff_take_n(v_it11_2460, 0ULL, 3);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SIs: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SOpaque: {
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SAbandon: {
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SRec: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SFix: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SImplicit: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SPrim: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SMetaApp: {
                heff_take_n(v_it11_2460, 0ULL, 3);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLitInt: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLitFloat: {
                heff_take_na(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLitString: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLitBytes: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLitRune: {
                heff_take_n(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLitFixed: {
                heff_take_n(v_it11_2460, 0ULL, 2);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_SLitFloat32: {
                heff_take_na(v_it11_2460, 0ULL, 1);
                heff_drop(v_entries_242);
                heff_drop(v_aliases_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it11_2460)}});
              }
            }
            case TAG_SOpaque: {
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SAbandon: {
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SRec: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SFix: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SImplicit: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SPrim: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SMetaApp: {
              heff_take_n(v_t_2430, 0ULL, 3);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLitInt: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLitFloat: {
              heff_take_na(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLitString: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLitBytes: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLitRune: {
              heff_take_n(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLitFixed: {
              heff_take_n(v_t_2430, 0ULL, 2);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_SLitFloat32: {
              heff_take_na(v_t_2430, 0ULL, 1);
              heff_drop(v_entries_242);
              heff_drop(v_aliases_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_t_2430)}});
            }
          } else {
            heff_drop(v_entries_242);
            heff_drop(v_aliases_243);
            heff_drop(v_i_2428);
            heff_drop(v_xs_2429);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_entries_242);
          heff_drop(v_aliases_243);
          heff_drop(v_values_2424);
          heff_drop(v_field_2427);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_SProj: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_2414, 0ULL, 3);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SOpaque: {
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_2414, 0ULL, 3);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_2414, 0ULL, 2);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_t_2414, 0ULL, 1);
      heff_drop(v_entries_242);
      heff_drop(v_aliases_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2414)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_2412)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2erightOf_24cpr_str0, 14, "prelude.Either");

HeffT2 g_heff_2ecompile_2eglue_2erightOf_24cpr(V v_t_240) {
top: ;
  V v_it_241 = (g_heff_2ecompile_2eglue_2etyOf(v_t_240));
  switch (heff_tag_of(v_it_241)) {
  case TAG_SU: {
    heff_take_n(v_it_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SDecode: {
    V v_it1_243 = heff_field(v_it_241, 0);
    V v_ru_24it_241_24SDecode = heff_take_reuse_n(v_it_241, 1ULL, 1);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_SLocal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      V v_it11_247 = heff_field(v_it1_243, 0);
      V v_r_248 = heff_field(v_it1_243, 1);
      heff_take_n(v_it1_243, 3ULL, 2);
      switch (heff_tag_of(v_it11_247)) {
      case TAG_SLocal: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SGlobal: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCode: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SApp: {
        V v_it111_2412 = heff_field(v_it11_247, 0);
        heff_take_n(v_it11_247, 1ULL, 2);
        switch (heff_tag_of(v_it111_2412)) {
        case TAG_SLocal: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          V v_e_2415 = heff_field(v_it111_2412, 0);
          heff_take_n(v_it111_2412, 1ULL, 1);
          if (heff_strEq_c(v_e_2415, ((V)&g_heff_2ecompile_2eglue_2erightOf_24cpr_str0))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24it_241_24SDecode, TAG_SDecode, 1, (V[]){v_r_248})}});
          } else {
            heff_drop_cell(v_ru_24it_241_24SDecode, 1);
            heff_drop(v_r_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_SCode: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCons: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          heff_take_n(v_it111_2412, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SOpaque: {
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          heff_take_n(v_it111_2412, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          heff_take_na(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          heff_take_n(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          heff_take_n(v_it111_2412, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_it111_2412, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24SDecode, 1);
          heff_drop(v_r_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it111_2412)}});
        }
      }
      case TAG_SLam: {
        heff_take_n(v_it11_247, 0ULL, 2);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCons: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SProj: {
        heff_take_n(v_it11_247, 0ULL, 2);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_STag: {
        heff_take_n(v_it11_247, 0ULL, 2);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMatch: {
        heff_take_n(v_it11_247, 0ULL, 2);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it11_247, 0ULL, 3);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SIs: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SOpaque: {
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SAbandon: {
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SRec: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SFix: {
        heff_take_n(v_it11_247, 0ULL, 2);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SImplicit: {
        heff_take_n(v_it11_247, 0ULL, 2);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SPrim: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it11_247, 0ULL, 3);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitInt: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitString: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitRune: {
        heff_take_n(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it11_247, 0ULL, 2);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it11_247, 0ULL, 1);
        heff_drop_cell(v_ru_24it_241_24SDecode, 1);
        heff_drop(v_r_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it11_247)}});
      }
    }
    case TAG_SLam: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_it1_243, 0ULL, 3);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SOpaque: {
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_it1_243, 0ULL, 3);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_241_24SDecode, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_it1_243)}});
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_it_241, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRecord: {
    heff_take_n(v_it_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSum: {
    heff_take_n(v_it_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIsTy: {
    heff_take_n(v_it_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimArray: {
    heff_take_n(v_it_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFixed: {
    heff_take_n(v_it_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}

HeffT2 g_heff_2ecompile_2eglue_2elastOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_241)}});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str0, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str1, 33, "` has no field: no answer to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str2, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str3, 6, "` has ");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str4, 31, " arguments and its answer, but ");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str5, 14, " are described");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str6, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str7, 33, "` has no field: no answer to give");
Clo g_heff_2ecompile_2eglue_2ebindingOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ebindingOf_entry, 2, 0};

V g_heff_2ecompile_2eglue_2ebindingOf(V v_r_240, V v_fields_241) {
top: ;
  V v_tag_242 = heff_take_field(v_r_240, 0);
  V v_args_243 = heff_take_field(v_r_240, 2);
  V v_result_244 = heff_take_field(v_r_240, 3);
  V v_fun_245 = heff_get_n(v_r_240, 1, 4);
  if ((heff_unbox_word(heff_arrayLength_lent(v_fields_241, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_fields_241);
    heff_drop(v_args_243);
    heff_drop(v_result_244);
    heff_drop(v_fun_245);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str0), v_tag_242), ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str1));
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_246});
  } else {
    V v_x_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
    int64_t v_t_248 = (heff_unbox_word(heff_arrayLength_lent(v_fields_241, 0)) - ((int64_t)1ULL));
    if (!heff_intEq_c_lent(v_x_247, heff_box_word(v_t_248), 2)) {
      heff_drop(v_result_244);
      heff_drop(v_fun_245);
      heff_drop(v_x_247);
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str2), v_tag_242), ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str3));
      int64_t v_t_2410 = (heff_unbox_word(heff_arrayLength(v_fields_241)) - ((int64_t)1ULL));
      V v_t_2411 = heff_strAppend(v_t_249, heff_intShow(heff_box_word(v_t_2410)));
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
      V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str4)), heff_intShow(v_t_2412));
      return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str5))});
    } else {
      heff_drop(v_x_247);
      HeffT2 v_t_2414 = ({ V b_0 = heff_arrayToList(heff_dup(v_fields_241)); HeffT2 r_ = (g_heff_2ecompile_2eglue_2elastOf_24cpr(b_0)); heff_drop(b_0); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_last_2417 = v_field_2416;
          HeffT2 v_t_2418 = ({ V a_0 = heff_dup(v_tag_242); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V b_3 = heff_arrayToList(v_fields_241); HeffT2 r_ = (g_heff_2ecompile_2eglue_2eargsBad_24cpr(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          {
            V v_field_2420 = v_t_2418.f[1];
            int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
            HeffT2 v_t_2421 = (g_heff_2ecompile_2eglue_2eresultBad_24cpr(heff_dup(v_tag_242), v_result_244, v_last_2417));
            {
              V v_field_2423 = v_t_2421.f[1];
              int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
              if ((v_tag_2419 == ((int64_t)0ULL))) {
                heff_drop(v_tag_242);
                heff_drop(v_args_243);
                heff_drop(v_result_244);
                heff_drop(v_fun_245);
                heff_drop(v_last_2417);
                heff_drop(v_field_2423);
                V v_m_2424 = v_field_2420;
                return heff_tag_n(TAG_Left, 1, (V[]){v_m_2424});
              } else {
                heff_drop(v_field_2420);
                if ((v_tag_2422 == ((int64_t)0ULL))) {
                  heff_drop(v_tag_242);
                  heff_drop(v_args_243);
                  heff_drop(v_result_244);
                  heff_drop(v_fun_245);
                  heff_drop(v_last_2417);
                  V v_m_2425 = v_field_2423;
                  return heff_tag_n(TAG_Left, 1, (V[]){v_m_2425});
                } else {
                  heff_drop(v_field_2423);
                  V v_t_2440;
                  switch (heff_tag_of(v_last_2417)) {
                  case TAG_SU: {
                    heff_take_n(v_last_2417, 0ULL, 1);
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SDecode: {
                    heff_take_n(v_last_2417, 0ULL, 1);
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SFunction: {
                    heff_take_n(v_last_2417, 0ULL, 5);
                    v_t_2440 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SRecord: {
                    heff_take_n(v_last_2417, 0ULL, 3);
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SSum: {
                    heff_take_n(v_last_2417, 0ULL, 1);
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SIsTy: {
                    heff_take_n(v_last_2417, 0ULL, 1);
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SPrimInt: {
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SPrimFloat: {
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SPrimString: {
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SPrimRune: {
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SPrimArray: {
                    heff_take_n(v_last_2417, 0ULL, 1);
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SFixed: {
                    heff_take_n(v_last_2417, 0ULL, 1);
                    v_t_2440 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_last_2417);
                  }
                  return heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_tag__fun__args__result__answered, (V[]){v_tag_242, v_fun_245, v_args_243, v_result_244, v_t_2440})});
                }
              }
            }
          }
        } else {
          heff_drop(v_fields_241);
          heff_drop(v_args_243);
          heff_drop(v_result_244);
          heff_drop(v_fun_245);
          heff_drop(v_field_2416);
          V v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str6), v_tag_242), ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str7));
          return heff_tag_n(TAG_Left, 1, (V[]){v_t_2441});
        }
      }
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2ebindingOf(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      V v_why_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_243}});
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_245 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_rest_242));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_244);
          V v_why_248 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_248}});
        } else {
          V v_xs_249 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_xs_249})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str4, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str7, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str8, 2, ": ");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str9, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str10, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str12, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str13, 2, ": ");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str14, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str15, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str17, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str18, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eglueOf_str19, 1, ".");
Clo g_heff_2ecompile_2eglue_2eglueOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eglueOf_entry, 3, 0};

V g_heff_2ecompile_2eglue_2eglueOf(V v_g_240, V v_handWritten_241, V v_k_242) {
top: ;
  V v_t_243 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str0); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2eglueOf_str1), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_x2_244 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_243));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_it_248 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_t_247; V r_ = (g_heff_2ecompile_2eglue_2edescribedIn(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_it_248)) {
  case TAG_Left: {
    V v_why_249 = heff_field(v_it_248, 0);
    V v_ru_24it_248_24Left = heff_take_reuse_n(v_it_248, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_handWritten_241);
    V v_t_2410 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str4); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2eglueOf_str5), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_k_242); r_; });
    V v_x2_2411 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str7); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eglue_2eglueOf_str8)), v_why_249);
    return heff_tag_at_n(v_ru_24it_248_24Left, TAG_Left, 1, (V[]){v_t_2415});
  }
  case TAG_Right: {
    V v_it1_2416 = heff_field(v_it_248, 0);
    V v_ru_24it_248_24Right = heff_take_reuse_n(v_it_248, 1ULL, 1);
    switch (heff_tag_of(v_it1_2416)) {
    case TAG_MkPair: {
      V v_incs_2417 = heff_field(v_it1_2416, 0);
      V v_it12_2418 = heff_field(v_it1_2416, 1);
      heff_take_n(v_it1_2416, 3ULL, 2);
      switch (heff_tag_of(v_it12_2418)) {
      case TAG_Nil: {
        heff_drop(v_g_240);
        heff_drop(v_handWritten_241);
        heff_drop(v_k_242);
        heff_drop(v_incs_2417);
        return heff_tag_at_n(v_ru_24it_248_24Right, TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
      }
      case TAG_Cons: {
        HeffT2 v_t_2421 = (g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(v_g_240, heff_dup(v_k_242), v_it12_2418));
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            heff_drop(v_handWritten_241);
            heff_drop_cell(v_ru_24it_248_24Right, 1);
            heff_drop(v_incs_2417);
            V v_why_2424 = v_field_2423;
            V v_t_2425 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str9); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2eglueOf_str10), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_k_242); r_; });
            V v_x2_2426 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2425));
            V v_t_2429;
            switch (heff_tag_of(v_x2_2426)) {
            case TAG_Nil: {
              v_t_2429 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str11);
              break;
            }
            case TAG_Cons: {
              V v_x_2427 = heff_field(v_x2_2426, 0);
              V v_xs_2428 = heff_field(v_x2_2426, 1);
              heff_take_n(v_x2_2426, 3ULL, 2);
              v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str12); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2426);
            }
            V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eglue_2eglueOf_str13)), v_why_2424);
            return heff_tag_n(TAG_Left, 1, (V[]){v_t_2430});
          } else {
            V v_it1_2431 = v_field_2423;
            switch (heff_tag_of(v_it1_2431)) {
            case TAG_Nil: {
              heff_drop(v_handWritten_241);
              heff_drop(v_k_242);
              heff_drop(v_incs_2417);
              return heff_tag_at_n(v_ru_24it_248_24Right, TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
            }
            case TAG_Cons: {
              V v_t_2434 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str14); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2eglueOf_str15), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
              V v_x2_2435 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2434));
              V v_t_2438;
              switch (heff_tag_of(v_x2_2435)) {
              case TAG_Nil: {
                v_t_2438 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str16);
                break;
              }
              case TAG_Cons: {
                V v_x_2436 = heff_field(v_x2_2435, 0);
                V v_xs_2437 = heff_field(v_x2_2435, 1);
                heff_take_n(v_x2_2435, 3ULL, 2);
                v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str17); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
                break;
              }
              default: heff_nomatch(v_x2_2435);
              }
              V v_t_2439 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2eglueOf_str18); V a_1 = v_k_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2eglueOf_str19), v_k_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
              V v_t_2440 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_2439; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2439); r_; });
              V v_x1_2441 = heff_tr(heff_call(v_handWritten_241, 1, (V[]){v_k_242}));
              V v_t_2442 = heff_bool(!(heff_dup(v_x1_2441) == NTAG(TAG_True)));
              heff_drop(v_x1_2441);
              V v_t_2443 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(5, shape_module__leaf__includes__ops__entry, (V[]){v_t_2438, v_t_2440, v_incs_2417, v_it1_2431, v_t_2442})});
              return heff_tag_at_n(v_ru_24it_248_24Right, TAG_Right, 1, (V[]){v_t_2443});
            }
            default: return heff_nomatch(v_it1_2431);
            }
          }
        }
      }
      default: return heff_nomatch(v_it12_2418);
      }
    }
    default: return heff_nomatch(v_it1_2416);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
V g_heff_2ecompile_2eglue_2eglueOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2eglueOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eglue_2ejusts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ejusts_entry, 1, 0};

V g_heff_2ecompile_2eglue_2ejusts(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eglue_2ejusts_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2ejusts(a[0]);
}
Clo g_heff_2ecompile_2eglue_2ejusts_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ejusts_24dps_entry, 2, 0};

V g_heff_2ecompile_2eglue_2ejusts_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2ejusts_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2ejusts_24dps(a[0], a[1]);
}