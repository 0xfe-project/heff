// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EApp 33163
#define TAG_EGlobal 62762
#define TAG_ELam 43266
#define TAG_EPrimCall 6589
#define TAG_ERecord 5518
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_FtOther 63706
#define TAG_HS 9084
#define TAG_Kept 49931
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_defs 9574869
#define LBL_done 9584713
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_globals 352931696
#define LBL_go 10063
#define LBL_groups 709681407
#define LBL_ir 10128
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_len 316559
#define LBL_lent 9813446
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_owner 307523277
#define LBL_pa 10328
#define LBL_pieces 958716528
#define LBL_refs 9991943
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_simplified 1686448252
#define LBL_supply 1056026650
#define LBL_syntax 1059664654
#define LBL_tables 1065764240
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_units 312791945
#define LBL_value 313331083
#define LBL_ver 326173
#define LBL_workers 1757018875
static uint32_t shape_arity__bounce__lazy__lent__workers[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_defs__facts__errors[] = {LBL_defs, LBL_facts, LBL_errors};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_done__name__refs__sgSafe__sgTotal[] = {LBL_done, LBL_name, LBL_refs, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
static uint32_t shape_owner__key__name__item__refs[] = {LBL_owner, LBL_key, LBL_name, LBL_item, LBL_refs};
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_pieces__errors__supply[] = {LBL_pieces, LBL_errors, LBL_supply};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_simplified__errors__groups__copies[] = {LBL_simplified, LBL_errors, LBL_groups, LBL_copies};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
V g_heff_2ecompile_2earity_2esatOf(V);
V g_heff_2ecompile_2earity_2esatOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2esatOf_clo;
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2ecallarity_2erounds(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2erounds_clo;
V g_heff_2ecompile_2ecallarity_2eroundsMost_get(void);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2efacts_2ebounceGo(V, V);
V g_heff_2ecompile_2efacts_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ebounceGo_clo;
V g_heff_2ecompile_2efuse_2efuseProgram(V, V);
V g_heff_2ecompile_2efuse_2efuseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseProgram_clo;
V g_heff_2ecompile_2eimp_2edefOf(V, V, V);
V g_heff_2ecompile_2eimp_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2edefOf_clo;
V g_heff_2ecompile_2eimp_2egenOf(V);
V g_heff_2ecompile_2eimp_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2egenOf_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eirtext_2ehashW(V, V, V);
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ehashW_clo;
V g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576(V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576_clo;
V g_heff_2ecompile_2elower_2ecDef(V, V, V);
V g_heff_2ecompile_2elower_2ecDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecDef_clo;
V g_heff_2ecompile_2elower_2ecErased(V, V);
V g_heff_2ecompile_2elower_2ecErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecErased_clo;
V g_heff_2ecompile_2elower_2ecFused(V, V, V);
V g_heff_2ecompile_2elower_2ecFused_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecFused_clo;
V g_heff_2ecompile_2elower_2ecKept(V, V, V);
V g_heff_2ecompile_2elower_2ecKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecKept_clo;
V g_heff_2ecompile_2elower_2ecLowered(V, V);
V g_heff_2ecompile_2elower_2ecLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecLowered_clo;
V g_heff_2ecompile_2elower_2eentryBody(V, V);
V g_heff_2ecompile_2elower_2eentryBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryBody_clo;
V g_heff_2ecompile_2elower_2eentryKept(V, V);
V g_heff_2ecompile_2elower_2eentryKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryKept_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2eentryPieces(V, V, V, V);
V g_heff_2ecompile_2elower_2eentryPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryPieces_clo;
V g_heff_2ecompile_2elower_2eerasedPieces(V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_clo;
V g_heff_2ecompile_2elower_2efindDef(V, V);
V g_heff_2ecompile_2elower_2efindDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efindDef_clo;
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2egroupCons(V, V);
V g_heff_2ecompile_2elower_2egroupCons_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupCons_clo;
V g_heff_2ecompile_2elower_2egroupGo(V);
V g_heff_2ecompile_2elower_2egroupGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupGo_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2ecompile_2elower_2ejsDef(V, V);
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ejsDef_clo;
V g_heff_2ecompile_2elower_2ekeptFor(V, V, V);
V g_heff_2ecompile_2elower_2ekeptFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ekeptFor_clo;
V g_heff_2ecompile_2elower_2ekeptPiece(V, V, V, V);
V g_heff_2ecompile_2elower_2ekeptPiece_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ekeptPiece_clo;
V g_heff_2ecompile_2elower_2elowerErased(V, V);
V g_heff_2ecompile_2elower_2elowerErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerErased_clo;
V g_heff_2ecompile_2elower_2elowerFused(V, V, V);
V g_heff_2ecompile_2elower_2elowerFused_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerFused_clo;
V g_heff_2ecompile_2elower_2elowerProgramC(V, V);
V g_heff_2ecompile_2elower_2elowerProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramC_clo;
V g_heff_2ecompile_2elower_2elowerProgramKept(V, V, V, V);
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo;
V g_heff_2ecompile_2elower_2epieceStep(V, V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_clo;
V g_heff_2ecompile_2elower_2epiecesWith(V, V, V, V);
V g_heff_2ecompile_2elower_2epiecesWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epiecesWith_clo;
V g_heff_2ecompile_2elower_2ereachedPieces(V);
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ereachedPieces_clo;
V g_heff_2ecompile_2elower_2eredoErased(V, V, V, V);
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eredoErased_clo;
V g_heff_2ecompile_2elower_2erevOnto(V, V);
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_clo;
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V, V, V);
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo;
V g_heff_2ecompile_2elower_2esaturated(V, V);
V g_heff_2ecompile_2elower_2esaturated_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2esaturated_clo;
V g_heff_2ecompile_2elower_2esharedLowered(V, V);
V g_heff_2ecompile_2elower_2esharedLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2esharedLowered_clo;
V g_heff_2ecompile_2elower_2esimplifyWith(V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2esimplifyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2esimplifyWith_clo;
V g_heff_2ecompile_2elower_2eunitOut(V, V, V);
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitOut_clo;
V g_heff_2ecompile_2elower_2eunitVers(V, V);
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitVers_clo;
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667(V);
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_clo;
V g_heff_2ecompile_2erc_2ercDef(V, V, V);
V g_heff_2ecompile_2erc_2ercDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ercDef_clo;
V g_heff_2ecompile_2erepr_2ereprsWith(V, V);
V g_heff_2ecompile_2erepr_2ereprsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsWith_clo;
V g_heff_2ecompile_2eshake_2ereachBy(V, V, V);
V g_heff_2ecompile_2eshake_2ereachBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachBy_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2etrmc_2etraverseS_24s701664737x420605422(V);
V g_heff_2ecompile_2etrmc_2etraverseS_24s701664737x420605422_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2etraverseS_24s701664737x420605422_clo;
V g_heff_2ecompile_2eworker_2eworkers(V, V);
V g_heff_2ecompile_2eworker_2eworkers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eworkers_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s455618083x1946283732(V, V);
V g_list_2eall_24s455618083x1946283732_entry(V self, V *a);
extern Clo g_list_2eall_24s455618083x1946283732_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1176174831x1580549308(V, V);
V g_list_2efoldl_24s1176174831x1580549308_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1176174831x1580549308_clo;
V g_list_2efoldl_24s1232551929x416126852(V, V);
V g_list_2efoldl_24s1232551929x416126852_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1232551929x416126852_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1577366920x1019062938(V, V);
V g_list_2efoldl_24s1577366920x1019062938_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1577366920x1019062938_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1748401606x190338434(V, V);
V g_list_2efoldl_24s1748401606x190338434_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1748401606x190338434_clo;
V g_list_2efoldl_24s1769360958x1839054239(V, V);
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1769360958x1839054239_clo;
V g_list_2efoldl_24s1915639815x253536901(V, V);
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1915639815x253536901_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s31530661x2067693293(V, V);
V g_list_2efoldl_24s31530661x2067693293_entry(V self, V *a);
extern Clo g_list_2efoldl_24s31530661x2067693293_clo;
V g_list_2efoldl_24s525916660x1238865713(V, V);
V g_list_2efoldl_24s525916660x1238865713_entry(V self, V *a);
extern Clo g_list_2efoldl_24s525916660x1238865713_clo;
V g_list_2efoldl_24s936309876x1530772408(V, V, V);
V g_list_2efoldl_24s936309876x1530772408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s936309876x1530772408_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s510639937x1058700299(V);
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2ecompile_2elower_2esaturated_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2esaturated_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2esaturated_entry, 2, 0};

V g_heff_2ecompile_2elower_2esaturated(V v_ar_240, V v_c_241) {
top: ;
  V v_defs_245 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2esaturated_lam0, 1, 1, (V[]){heff_dup(v_ar_240)}), heff_take_field(v_c_241, 0)));
  V v_t_246 = (g_heff_2ecompile_2etrmc_2etraverseS_24s701664737x420605422(v_defs_245));
  V v_t_247 = heff_tr(heff_call(v_t_246, 1, (V[]){heff_get_n(v_c_241, 1, 2)}));
  switch (heff_tag_of(v_t_247)) {
  case TAG_MkPair: {
    V v_dss_248 = heff_field(v_t_247, 0);
    V v_n_249 = heff_field(v_t_247, 1);
    heff_take_n(v_t_247, 3ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_248));
    V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_rec_n(2, shape_defs__supply, (V[]){v_t_2411, v_n_249});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2elower_2esaturated_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2esaturated(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2elower_2esaturated_lam0(V self, V *args) {
  V v_d_242 = args[0];
  V v_ar_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = ({ V a_0 = v_ar_240; V r_ = (g_heff_2ecompile_2earity_2esatOf(a_0)); heff_drop(v_ar_240); r_; });
  V v_t_244 = heff_tr(heff_call(heff_get_n(v_t_243, 0, 1), 1, (V[]){heff_take_field(v_d_242, 2)}));
  return ({ V rv_2 = v_t_244; V rr_ = heff_rec_reuse_nf(v_d_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
Clo g_heff_2ecompile_2elower_2esharedLowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2esharedLowered_entry, 2, 0};

V g_heff_2ecompile_2elower_2esharedLowered(V v_errors_240, V v_t_241) {
top: ;
  V v_defs_242 = heff_dup(heff_rfield(v_t_241, 0));
  V v_t_243 = (g_list_2efoldl_24s1232551929x416126852(heff_dup(g_map_2eempty_get()), v_defs_242));
  V v_t_244 = (g_heff_2ecompile_2efacts_2ebounceGo(v_defs_242, heff_dup(g_map_2eempty_get())));
  V v_m_245 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_defs_242; V r_ = (g_list_2efoldl_24s525916660x1238865713(a_0, a_1)); heff_drop(v_defs_242); r_; });
  V v_t_246 = ({ V a_0 = v_m_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_245); r_; });
  V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1176174831x1580549308(a_0, a_1)); heff_drop(v_t_246); r_; });
  return heff_rec_n(3, shape_defs__facts__errors, (V[]){heff_get_n(v_t_241, 0, 2), heff_rec_n(5, shape_arity__bounce__lazy__lent__workers, (V[]){v_t_243, v_t_244, v_t_247, heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}), v_errors_240});
}
V g_heff_2ecompile_2elower_2esharedLowered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2esharedLowered(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2ejsDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ejsDef_entry, 2, 0};

V g_heff_2ecompile_2elower_2ejsDef(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_b0_242 = heff_field(v_x2_241, 0);
    V v_n_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(heff_rfield(v_d_240, 1)), heff_dup(v_b0_242)});
    V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_t_246 = (g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667(v_t_245));
    V v_it_247 = heff_tr(heff_call(v_t_246, 1, (V[]){v_n_243}));
    switch (heff_tag_of(v_it_247)) {
    case TAG_MkPair: {
      V v_it1_248 = heff_field(v_it_247, 0);
      V v_n2_249 = heff_field(v_it_247, 1);
      heff_take_n(v_it_247, 3ULL, 2);
      switch (heff_tag_of(v_it1_248)) {
      case TAG_Nil: {
        V v_t_2410 = (g_heff_2ecompile_2eimp_2egenOf(NTAG(TAG_True)));
        V v_t_2411 = ({ V rv_2 = v_b0_242; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_x1_2412 = (g_heff_2ecompile_2eimp_2edefOf(v_t_2410, v_t_2411, v_n2_249));
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x1_2412, 0);
          heff_take_n(v_x1_2412, 1ULL, 2);
          return v_x_2413;
        }
        default: return heff_nomatch(v_x1_2412);
        }
      }
      case TAG_Cons: {
        V v_m_2415 = heff_field(v_it1_248, 0);
        heff_take_n(v_it1_248, 1ULL, 2);
        heff_drop_rec(v_d_240, 3);
        heff_drop(v_b0_242);
        V v_t_2417 = (g_heff_2ecompile_2eimp_2egenOf(NTAG(TAG_True)));
        V v_x1_2418 = (g_heff_2ecompile_2eimp_2edefOf(v_t_2417, v_m_2415, v_n2_249));
        switch (heff_tag_of(v_x1_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x1_2418, 0);
          heff_take_n(v_x1_2418, 1ULL, 2);
          return v_x_2419;
        }
        default: return heff_nomatch(v_x1_2418);
        }
      }
      default: return heff_nomatch(v_it1_248);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ejsDef(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2efusedOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2efusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efusedOf_entry, 2, 0};

V g_heff_2ecompile_2elower_2efusedOf(V v_roots_240, V v_si_241) {
top: ;
  V v_defs_242 = heff_take_field(v_si_241, 0);
  V v_t_243 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_242));
  V v_reached_244 = ({ V a_0 = v_t_243; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_roots_240; V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_lam0, 1, 1, (V[]){v_reached_244}), v_defs_242));
  HEFF_LAST return g_heff_2ecompile_2efuse_2efuseProgram(heff_get_n(v_si_241, 1, 4), v_t_248);
}
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2efusedOf(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2efusedOf_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_reached_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_246 = ({ V a_0 = heff_get_n(v_d_245, 0, 3); V a_1 = v_reached_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_244); r_; });
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ecompile_2elower_2elowerFused_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2elowerFused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerFused_entry, 3, 0};

V g_heff_2ecompile_2elower_2elowerFused(V v_roots_240, V v_errors_241, V v_f_242) {
top: ;
  V v_defs_243 = heff_take_field(v_f_242, 0);
  V v_t_244 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_roots_240; V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_kept_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2elowerFused_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  V v_t_2410 = heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){heff_dup(g_map_2eempty_get())}), heff_dup(g_map_2eempty_get())});
  V v_c_2411 = heff_tr(g_heff_2ecompile_2ecallarity_2erounds(heff_dup(g_heff_2ecompile_2ecallarity_2eroundsMost_get()), v_t_2410, v_kept_249, heff_get_n(v_f_242, 1, 2)));
  V v_t_2412 = (g_list_2efoldl_24s1915639815x253536901(heff_dup(g_map_2eempty_get()), heff_rfield(v_c_2411, 0)));
  V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_c_2411; V r_ = (g_heff_2ecompile_2elower_2esaturated(a_0, a_1)); heff_drop(v_t_2412); r_; });
  return (g_heff_2ecompile_2elower_2esharedLowered(v_errors_241, v_t_2413));
}
V g_heff_2ecompile_2elower_2elowerFused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerFused(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2elowerFused_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ecompile_2elower_2elowerErased_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2elowerErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerErased_entry, 2, 0};

V g_heff_2ecompile_2elower_2elowerErased(V v_roots_240, V v_er_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_er_241, 0)));
  V v_defs_243 = (g_list_2efoldl_24s936309876x1530772408(MK_INT(0LL), NTAG(TAG_Nil), v_t_242));
  V v_t_244 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2elowerErased_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  V v_si_2410 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(heff_take_field(v_er_241, 2), v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2elower_2efusedOf(heff_dup(v_roots_240), v_si_2410));
  return (g_heff_2ecompile_2elower_2elowerFused(v_roots_240, heff_get_n(v_er_241, 1, 3), v_t_2411));
}
V g_heff_2ecompile_2elower_2elowerErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerErased(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2elowerErased_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryKey_str0, 9, "run$entry");

static V g_heff_2ecompile_2elower_2eentryKey_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2eentryKey_st;
static V g_heff_2ecompile_2elower_2eentryKey_init(void) {
  return ((V)&g_heff_2ecompile_2elower_2eentryKey_str0);
}
V g_heff_2ecompile_2elower_2eentryKey_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2eentryKey_st)) return g_heff_2ecompile_2elower_2eentryKey_val;
  return heff_global(&g_heff_2ecompile_2elower_2eentryKey_val, &g_heff_2ecompile_2elower_2eentryKey_st, g_heff_2ecompile_2elower_2eentryKey_init);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str0, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str1, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str2, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str3, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str4, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str5, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str6, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str7, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str8, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str9, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str10, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str11, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str12, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str13, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str14, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str15, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str16, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str17, 4, "malg");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str18, 4, "bind");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str19, 3, "ret");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str20, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str21, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str22, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str23, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str24, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str25, 6, "MkUnit");
Clo g_heff_2ecompile_2elower_2eentryBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryBody_entry, 2, 0};

V g_heff_2ecompile_2elower_2eentryBody(V v_key_240, V v_n_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str0), heff_intShow(heff_dup(v_n_241)));
  V v_t_243 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str1), v_t_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_246 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str2), v_t_245)});
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str3), heff_intShow(heff_dup(v_n_241)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244}), heff_tag_n(TAG_EApp, 2, (V[]){v_t_246, v_t_248})});
  V v_t_2410 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2411 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2412 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str4), v_t_2412), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str5), v_t_2411), v_t_2413});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str6), v_t_2410), v_t_2414});
  V v_t_2416 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2417 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str7), v_t_2416)});
  V v_t_2418 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str8), v_t_2418), NTAG(TAG_Nil)});
  V v_t_2420 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2421 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str9), v_t_2420)});
  V v_t_2422 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2423 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str10), v_t_2422)});
  V v_t_2424 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2425 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str11), v_t_2424)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2419, v_t_2427}), NTAG(TAG_Nil)});
  V v_t_2429 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2417, v_t_2428})});
  V v_t_2430 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2431 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str12), v_t_2431), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str13), v_t_2430), v_t_2432});
  V v_t_2434 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2435 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str14), v_t_2434)});
  V v_t_2436 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2437 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str15), v_t_2436)});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
  V v_t_2439 = heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str17), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2433, v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str18), v_t_2429}), v_t_2441});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str19), v_t_249}), v_t_2442});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2444});
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2445});
  V v_t_2447 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2448 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str20), v_t_2448), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str21), v_t_2447), v_t_2449});
  V v_t_2451 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2452 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str22), v_t_2451)});
  V v_t_2453 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2454 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str23), v_t_2453)});
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2450, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2452, v_t_2455})});
  V v_t_2457 = heff_intShow(heff_intAdd(v_n_241, MK_INT(10LL)));
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str24), v_t_2457), NTAG(TAG_Nil)});
  V v_t_2459 = heff_tag_n(TAG_ETag, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str25), NTAG(TAG_Nil)});
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2458, v_t_2459}), NTAG(TAG_Nil)});
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2443, v_t_2446}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, v_t_2460})});
  return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_240}), v_t_2461});
}
V g_heff_2ecompile_2elower_2eentryBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eentryBody(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2ecLowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecLowered_entry, 2, 0};

V g_heff_2ecompile_2elower_2ecLowered(V v_errors_240, V v_defs_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1769360958x1839054239(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_lent_243 = (g_heff_2ecompile_2eborrow_2eborFix(v_defs_241, MK_INT(-1LL), v_t_242));
  V v_t_244 = (g_list_2efoldl_24s1232551929x416126852(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_245 = (g_heff_2ecompile_2efacts_2ebounceGo(v_defs_241, heff_dup(g_map_2eempty_get())));
  V v_m_246 = (g_list_2efoldl_24s525916660x1238865713(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_247 = ({ V a_0 = v_m_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_246); r_; });
  V v_t_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1176174831x1580549308(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_f_249 = heff_rec_n(5, shape_arity__bounce__lazy__lent__workers, (V[]){v_t_244, v_t_245, v_t_248, heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
  V v_facts_2410 = ({ V rv_3 = v_lent_243; V rr_ = heff_rec_reuse_nf(v_f_249, 23ULL, 5, shape_arity__bounce__lazy__lent__workers, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_ws_2411 = (g_heff_2ecompile_2eworker_2eworkers(heff_dup(v_facts_2410), heff_dup(v_defs_241)));
  V v_t_2412 = ({ V rv_4 = v_ws_2411; V rr_ = heff_rec_reuse_nf(v_facts_2410, 15ULL, 5, shape_arity__bounce__lazy__lent__workers, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_rec_n(3, shape_defs__facts__errors, (V[]){v_defs_241, v_t_2412, v_errors_240});
}
V g_heff_2ecompile_2elower_2ecLowered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecLowered(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2ecKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecKept_entry, 3, 0};

V g_heff_2ecompile_2elower_2ecKept(V v_supply_240, V v_kept_241, V v_errors_242) {
top: ;
  V v_t_243 = heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){heff_dup(g_map_2eempty_get())}), heff_dup(g_map_2eempty_get())});
  V v_c_244 = heff_tr(g_heff_2ecompile_2ecallarity_2erounds(heff_dup(g_heff_2ecompile_2ecallarity_2eroundsMost_get()), v_t_243, v_kept_241, v_supply_240));
  V v_t_245 = (g_list_2efoldl_24s1915639815x253536901(heff_dup(g_map_2eempty_get()), heff_rfield(v_c_244, 0)));
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_c_244; V r_ = (g_heff_2ecompile_2elower_2esaturated(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667(heff_take_field(v_t_246, 0)));
  V v_x1_248 = heff_tr(heff_call(v_t_247, 1, (V[]){heff_get_n(v_t_246, 1, 2)}));
  V v_t_2411;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 2);
    v_t_2411 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  return (g_heff_2ecompile_2elower_2ecLowered(v_errors_242, v_t_2411));
}
V g_heff_2ecompile_2elower_2ecKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecKept(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2ecFused_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2ecFused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecFused_entry, 3, 0};

V g_heff_2ecompile_2elower_2ecFused(V v_roots_240, V v_errors_241, V v_f_242) {
top: ;
  V v_defs_243 = heff_take_field(v_f_242, 0);
  V v_t_244 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_roots_240; V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2ecFused_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  HEFF_LAST return g_heff_2ecompile_2elower_2ecKept(heff_get_n(v_f_242, 1, 2), v_t_249, v_errors_241);
}
V g_heff_2ecompile_2elower_2ecFused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecFused(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2ecFused_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ecompile_2elower_2ecErased_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2ecErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecErased_entry, 2, 0};

V g_heff_2ecompile_2elower_2ecErased(V v_roots_240, V v_er_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_er_241, 0)));
  V v_defs_243 = (g_list_2efoldl_24s936309876x1530772408(MK_INT(0LL), NTAG(TAG_Nil), v_t_242));
  V v_t_244 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2ecErased_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  V v_si_2410 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(heff_take_field(v_er_241, 2), v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2elower_2efusedOf(heff_dup(v_roots_240), v_si_2410));
  return (g_heff_2ecompile_2elower_2ecFused(v_roots_240, heff_get_n(v_er_241, 1, 3), v_t_2411));
}
V g_heff_2ecompile_2elower_2ecErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecErased(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2ecErased_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
Clo g_heff_2ecompile_2elower_2elowerProgramC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerProgramC_entry, 2, 0};

V g_heff_2ecompile_2elower_2elowerProgramC(V v_g_240, V v_key_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_er_243 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_g_240));
  V v_body_244 = (g_heff_2ecompile_2elower_2eentryBody(v_key_241, heff_dup(heff_rfield(v_er_243, 2))));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_244}), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_er_243, 0), v_t_245));
  V v_t_247 = heff_intAdd(heff_take_field(v_er_243, 2), MK_INT(11LL));
  V v_t_248 = ({ V rv_0 = v_t_246; V rv_2 = v_t_247; V rr_ = heff_rec_reuse_nf(v_er_243, 2ULL, 3, shape_defs__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  HEFF_LAST return g_heff_2ecompile_2elower_2ecErased(v_t_242, v_t_248);
}
V g_heff_2ecompile_2elower_2elowerProgramC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerProgramC(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2ecDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecDef_entry, 3, 0};

V g_heff_2ecompile_2elower_2ecDef(V v_facts_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_b0_243 = heff_field(v_x3_242, 0);
    V v_n_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2eimp_2egenOf(NTAG(TAG_True)));
    V v_t_246 = ({ V rv_2 = heff_dup(v_b0_243); V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_x1_247 = (g_heff_2ecompile_2eimp_2edefOf(v_t_245, v_t_246, heff_dup(v_n_244)));
    V v_md_2410;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      v_md_2410 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2411 = (g_heff_2ecompile_2erepr_2ereprsWith(heff_rfield(v_facts_240, 4), heff_dup(v_md_2410)));
    return ({ V a_0 = v_facts_240; V a_1 = v_t_2411; V a_2 = v_md_2410; V r_ = (g_heff_2ecompile_2erc_2ercDef(a_0, a_1, a_2)); heff_drop(v_md_2410); r_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2elower_2ecDef_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2elower_2ecDef(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2elower_2efindDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efindDef_entry, 2, 0};

V g_heff_2ecompile_2elower_2efindDef(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_ds_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_d_242, 0)), heff_dup(v_k_240))) {
      heff_drop(v_k_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_d_242)});
    } else {
      V t_0 = v_k_240;
      V t_1 = v_ds_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2elower_2efindDef_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2efindDef(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2elower_2eredoErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eredoErased_entry, 4, 0};

V g_heff_2ecompile_2elower_2eredoErased(V v_k_240, V v_uk_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    heff_drop(v_k_240);
    heff_drop(v_uk_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_242});
  }
  case TAG_Right: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    heff_drop(v_n_242);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_body_246 = heff_field(v_x41_245, 0);
      V v_n2_247 = heff_field(v_x41_245, 1);
      V v_t_248 = (g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), heff_dup(v_body_246)}), heff_dup(v_body_246)));
      V v_t_2412;
      switch (heff_tag_of(v_t_248)) {
      case TAG_MkPair: {
        V v_b_249 = heff_field(v_t_248, 0);
        V v_acc_2410 = heff_field(v_t_248, 1);
        V v_ru_24t_248_24MkPair = heff_take_reuse_n(v_t_248, 3ULL, 2);
        V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_2410, 0, 2)));
        v_t_2412 = heff_tag_at_n(v_ru_24t_248_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), v_k_240, v_b_249}), v_t_2411});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2413 = ({ V a_0 = v_uk_241; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2elower_2efindDef(a_0, a_1)); heff_drop(v_t_2412); r_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_dup(v_n2_247)});
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2elower_2eredoErased(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2elower_2ekeptPiece_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2ekeptPiece_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2ekeptPiece_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ekeptPiece_entry, 4, 0};

V g_heff_2ecompile_2elower_2ekeptPiece(V v_g_240, V v_k_241, V v_e_242, V v_u_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_u_243, 0)), 0, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_u_243, 0)), 1, 7);
  V v_t_2415 = heff_tag_n(TAG_Kept, 2, (V[]){heff_dup(heff_rfield(v_u_243, 0)), heff_clo_n(g_heff_2ecompile_2elower_2ekeptPiece_lam0, 1, 4, (V[]){heff_dup(v_u_243), heff_dup(v_k_241), v_e_242, v_g_240})});
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){v_k_241, v_t_244, v_t_245, v_t_2415, heff_get_n(v_u_243, 1, 2)});
}
V g_heff_2ecompile_2elower_2ekeptPiece_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ekeptPiece(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2elower_2ekeptPiece_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return heff_get_n(v_e_242, 2, 4);
}
V g_heff_2ecompile_2elower_2ekeptPiece_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_u_243 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_get_n(heff_get_n(v_u_243, 0, 2), 0, 7);
  V v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_k_241)})});
  V v_t_249 = heff_rec_n(2, shape_ir__ty, (V[]){v_t_248, heff_dup(heff_rfield(v_e_242, 3))});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2ecompile_2elower_2ekeptPiece_lam1, 1, 1, (V[]){heff_dup(v_e_242)})});
  V v_t_2413 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2410, v_t_2412, MK_INT(1LL), v_g_240}), heff_take_field(v_e_242, 0), heff_take_field(v_e_242, 3), heff_get_n(v_e_242, 2, 4)));
  V v_t_2414 = heff_tr(heff_call(v_t_2413, 1, (V[]){heff_dup(v_n_246)}));
  return ({ V a_0 = v_k_241; V a_1 = v_t_247; V a_2 = v_n_246; V a_3 = v_t_2414; V r_ = (g_heff_2ecompile_2elower_2eredoErased(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
}
Clo g_heff_2ecompile_2elower_2erevOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2erevOnto_entry, 2, 0};

V g_heff_2ecompile_2elower_2erevOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2erevOnto(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2ekeptFor_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2ekeptFor_str1, 0, "");
Clo g_heff_2ecompile_2elower_2ekeptFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ekeptFor_entry, 3, 0};

V g_heff_2ecompile_2elower_2ekeptFor(V v_vers_240, V v_ks_241, V v_k_242) {
top: ;
  V v_it_243 = ({ V a_0 = heff_dup(v_k_242); V b_1 = heff_get_n(v_ks_241, 0, 2); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_k_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_MkPair: {
      V v_v_245 = heff_field(v_it1_244, 0);
      V v_us_246 = heff_field(v_it1_244, 1);
      heff_take_n(v_it1_244, 3ULL, 2);
      if (heff_strEq_c(heff_dup(v_v_245), ((V)&g_heff_2ecompile_2elower_2ekeptFor_str0))) {
        heff_drop(v_k_242);
        heff_drop_cell(v_ru_24it_243_24Just, 1);
        heff_drop(v_v_245);
        heff_drop(v_us_246);
        return NTAG(TAG_Nothing);
      } else {
        V v_x2_248 = (g_map_2elookup_24s1546226666x2146984184(v_k_242, v_vers_240));
        V v_t_2410;
        switch (heff_tag_of(v_x2_248)) {
        case TAG_Nothing: {
          v_t_2410 = ((V)&g_heff_2ecompile_2elower_2ekeptFor_str1);
          break;
        }
        case TAG_Just: {
          V v_x_249 = heff_field(v_x2_248, 0);
          heff_take_n(v_x2_248, 1ULL, 1);
          v_t_2410 = v_x_249;
          break;
        }
        default: heff_nomatch(v_x2_248);
        }
        if (heff_strEq_c(v_v_245, v_t_2410)) {
          return heff_tag_at_n(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_us_246});
        } else {
          heff_drop_cell(v_ru_24it_243_24Just, 1);
          heff_drop(v_us_246);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ecompile_2elower_2ekeptFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2ekeptFor(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2elower_2eerasedPieces_str0, 2, ": ");
V g_heff_2ecompile_2elower_2eerasedPieces_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eerasedPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eerasedPieces_entry, 3, 0};

V g_heff_2ecompile_2elower_2eerasedPieces(V v_k_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_244 = heff_strAppend(v_k_240, heff_strAppend(((V)&g_heff_2ecompile_2elower_2eerasedPieces_str0), v_err_243));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_take_field(v_acc_241, 1)});
    return ({ V rv_1 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_241, 5ULL, 3, shape_pieces__errors__supply, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Right: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_body_247 = heff_field(v_x31_246, 0);
      V v_n_248 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      V v_t_249 = (g_heff_2ecompile_2elift_2eliftGo_24s1828885796x1813809576(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), heff_dup(v_body_247)}), v_body_247));
      V v_t_2413;
      switch (heff_tag_of(v_t_249)) {
      case TAG_MkPair: {
        V v_b_2410 = heff_field(v_t_249, 0);
        V v_acc_2411 = heff_field(v_t_249, 1);
        heff_take_n(v_t_249, 3ULL, 2);
        V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_2411, 0, 2)));
        v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), v_b_2410}), v_t_2412});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_t_2417 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_241, 0), heff_clo_n(g_heff_2ecompile_2elower_2eerasedPieces_lam0, 1, 1, (V[]){v_k_240}), v_t_2413));
      return ({ V rv_0 = v_t_2417; V rv_2 = v_n_248; V rr_ = heff_rec_reuse_nf(v_acc_241, 2ULL, 3, shape_pieces__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eerasedPieces(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2eerasedPieces_lam0(V self, V *args) {
  V v_d_2414 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_2414, 2))));
  V v_t_2416 = (g_heff_2ecompile_2eir_2enubI(v_t_2415));
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){v_k_240, heff_dup(heff_rfield(v_d_2414, 0)), heff_dup(heff_rfield(v_d_2414, 1)), heff_tag_n(TAG_Fresh, 1, (V[]){v_d_2414}), v_t_2416});
}
V g_heff_2ecompile_2elower_2epieceStep_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2epieceStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2epieceStep_entry, 5, 0};

V g_heff_2ecompile_2elower_2epieceStep(V v_g_240, V v_vers_241, V v_ks_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_246, 3))));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_ks_242);
      heff_drop(v_k_245);
      heff_drop_rec(v_e_246, 4);
      heff_drop_cell(v_ru_24x5_244_24MkPair, 2);
      heff_drop(v_t_247);
      return v_acc_243;
    } else {
      heff_drop(v_t_247);
      V v_t_248 = (g_heff_2ecompile_2elower_2ekeptFor(v_vers_241, v_ks_242, heff_dup(v_k_245)));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        V v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_k_245)})});
        V v_t_2410 = heff_rec_n(2, shape_ir__ty, (V[]){v_t_249, heff_dup(heff_rfield(v_e_246, 3))});
        V v_t_2411 = heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
        V v_t_2413 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_lam0, 1, 1, (V[]){heff_dup(v_e_246)})});
        V v_t_2414 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2411, v_t_2413, MK_INT(1LL), v_g_240}), heff_take_field(v_e_246, 0), heff_take_field(v_e_246, 3), heff_get_n(v_e_246, 2, 4)));
        V v_t_2415 = heff_tr(heff_call(v_t_2414, 1, (V[]){heff_dup(heff_rfield(v_acc_243, 2))}));
        return (g_heff_2ecompile_2elower_2eerasedPieces(v_k_245, v_acc_243, v_t_2415));
      }
      case TAG_Just: {
        V v_us_2416 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x5_244_24MkPair, 2);
        V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2ekeptPiece_clo), 3, (V[]){v_g_240, v_k_245, v_e_246}));
        V v_t_2418 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_243, 0), v_t_2417, v_us_2416));
        return ({ V rv_0 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_acc_243, 6ULL, 3, shape_pieces__errors__supply, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
      default: return heff_nomatch(v_t_248);
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2epieceStep(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2epieceStep_lam0(V self, V *args) {
  V v_u_2412 = args[0];
  V v_e_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return heff_get_n(v_e_246, 2, 4);
}
V g_heff_2ecompile_2elower_2eentryKept_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eentryKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryKept_entry, 2, 0};

V g_heff_2ecompile_2elower_2eentryKept(V v_key_240, V v_u_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_u_241, 0)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_u_241, 0)), 1, 7);
  V v_t_247 = heff_tag_n(TAG_Kept, 2, (V[]){heff_take_field(v_u_241, 0), heff_clo_n(g_heff_2ecompile_2elower_2eentryKept_lam0, 1, 1, (V[]){v_key_240})});
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_242, v_t_243, v_t_247, heff_get_n(v_u_241, 1, 2)});
}
V g_heff_2ecompile_2elower_2eentryKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eentryKept(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2eentryKept_lam0(V self, V *args) {
  V v_m_244 = args[0];
  V v_key_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_body_245 = (g_heff_2ecompile_2elower_2eentryBody(v_key_240, heff_dup(v_m_244)));
  V v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_245})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_intAdd(v_m_244, MK_INT(11LL))});
}
Clo g_heff_2ecompile_2elower_2eentryPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryPieces_entry, 4, 0};

V g_heff_2ecompile_2elower_2eentryPieces(V v_vers_240, V v_ks_241, V v_key_242, V v_n_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2elower_2ekeptFor(v_vers_240, v_ks_241, heff_dup(g_heff_2ecompile_2elower_2eentryKey_get())));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_body_245 = (g_heff_2ecompile_2elower_2eentryBody(v_key_242, v_n_243));
    V v_t_246 = heff_tag_n(TAG_Fresh, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(v_body_245)})});
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_body_245));
    V v_t_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_246, v_t_248}), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_us_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_n_243);
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2eentryKept_clo), 1, (V[]){v_key_242}));
    return (g_list_2emap(v_t_2410, v_us_249));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2elower_2eentryPieces_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2eentryPieces(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2elower_2eunitVers_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eunitVers_str1, 1, "-");
V g_heff_2ecompile_2elower_2eunitVers_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eunitVers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eunitVers_entry, 2, 0};

V g_heff_2ecompile_2elower_2eunitVers(V v_vers_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2elower_2eunitVers_lam0, 2, 1, (V[]){heff_dup(v_vers_240)}), heff_dup(g_map_2eempty_get()), v_ps_241));
}
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2elower_2eunitVers(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2eunitVers_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_vers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_take_field(v_p_243, 0); V a_1 = v_vers_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_vers_240); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_p_243, 5);
    return v_m_242;
  }
  case TAG_Just: {
    V v_v_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_v_245), ((V)&g_heff_2ecompile_2elower_2eunitVers_str0))) {
      heff_drop_rec(v_p_243, 5);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      return v_m_242;
    } else {
      V v_t_247 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_HS, 1, (V[]){heff_dup(heff_rfield(v_p_243, 1))});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_v_245}), v_t_248});
      V v_t_2410 = (g_heff_2ecompile_2eirtext_2ehashW(MK_INT(5381LL), MK_INT(7919LL), v_t_249));
      V v_t_2414;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_a_2411 = heff_field(v_t_2410, 0);
        V v_b_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2eunitVers_str1), heff_intShow(v_b_2412));
        v_t_2414 = heff_strAppend(heff_intShow(v_a_2411), v_t_2413);
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_p_243, 1, 5), v_t_2414, v_m_242));
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2ecompile_2elower_2eunitOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eunitOut_entry, 3, 0};

V g_heff_2ecompile_2elower_2eunitOut(V v_sg_240, V v_dm_241, V v_p_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_p_242, 1)), v_dm_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_sg_240, 2);
    heff_drop_rec(v_p_242, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_d_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(heff_rfield(v_p_242, 1)), heff_rfield(v_sg_240, 0)));
    V v_t_247;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    V v_x2_248 = ({ V a_0 = heff_take_field(v_p_242, 1); V b_1 = heff_get_n(v_sg_240, 1, 2); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      v_t_2410 = MK_INT(-1LL);
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      v_t_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2411 = heff_rec_n(5, shape_done__name__refs__sgSafe__sgTotal, (V[]){v_d_244, heff_take_field(v_p_242, 2), heff_get_n(v_p_242, 4, 5), v_t_247, v_t_2410});
    return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2eunitOut(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2elower_2egroupCons_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2egroupCons_entry, 2, 0};

V g_heff_2ecompile_2elower_2egroupCons(V v_p_240, V v_gs_241) {
top: ;
  switch (heff_tag_of(v_gs_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_gs_241});
  }
  case TAG_Cons: {
    V v_gs1_243 = heff_dup(heff_field(v_gs_241, 0));
    V v_rest_244 = heff_dup(heff_field(v_gs_241, 1));
    switch (heff_tag_of(v_gs1_243)) {
    case TAG_Nil: {
      heff_drop(v_rest_244);
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_gs_241});
    }
    case TAG_Cons: {
      V v_q_246 = heff_field(v_gs1_243, 0);
      V v_qs_247 = heff_field(v_gs1_243, 1);
      V v_ru_24gs1_243_24Cons = heff_take_reuse_n(v_gs1_243, 3ULL, 2);
      heff_drop_tag(v_gs_241, 2);
      if (heff_strEq_c(heff_dup(heff_rfield(v_p_240, 0)), heff_dup(heff_rfield(v_q_246, 0)))) {
        V v_t_249 = heff_tag_at_n(v_ru_24gs1_243_24Cons, TAG_Cons, 2, (V[]){v_p_240, heff_tag_n(TAG_Cons, 2, (V[]){v_q_246, v_qs_247})});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_rest_244});
      } else {
        V v_t_2410 = heff_tag_at_n(v_ru_24gs1_243_24Cons, TAG_Cons, 2, (V[]){v_p_240, NTAG(TAG_Nil)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_q_246, v_qs_247}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2411});
      }
    }
    default: return heff_nomatch(v_gs1_243);
    }
  }
  default: return heff_nomatch(v_gs_241);
  }
}
V g_heff_2ecompile_2elower_2egroupCons_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2egroupCons(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2egroupGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2egroupGo_entry, 1, 0};

V g_heff_2ecompile_2elower_2egroupGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_ps_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2ecompile_2elower_2egroupGo(v_ps_242));
    return (g_heff_2ecompile_2elower_2egroupCons(heff_dup(v_p_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2egroupGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2egroupGo(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2egroupOut_str3, 0, "");
V g_heff_2ecompile_2elower_2egroupOut_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2egroupOut_lam2(V self, V *args);
Clo g_heff_2ecompile_2elower_2egroupOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2egroupOut_entry, 4, 0};

V g_heff_2ecompile_2elower_2egroupOut(V v_vers_240, V v_sg_241, V v_dm_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sg_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ps_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x2_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_p_244, 0)), v_vers_240));
    V v_t_248;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      v_t_248 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str0);
      break;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 1);
      v_t_248 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    if (heff_strEq_c(v_t_248, ((V)&g_heff_2ecompile_2elower_2egroupOut_str1))) {
      heff_drop(v_sg_241);
      heff_drop_rec(v_p_244, 5);
      heff_drop(v_ps_245);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    } else {
      V v_x1_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam0, 1, 1, (V[]){heff_dup(v_dm_242)}); V b_1 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_p_244), heff_dup(v_ps_245)}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_x1_2413) == NTAG(TAG_True))) {
        heff_drop(v_x1_2413);
        V v_x1_2418 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam1, 1, 2, (V[]){heff_dup(v_sg_241), heff_dup(v_dm_242)}); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_p_244), heff_dup(v_ps_245)}); V r_ = (g_list_2eall(a_0, b_1)); heff_drop(b_1); r_; });
        if ((heff_dup(v_x1_2418) == NTAG(TAG_True))) {
          heff_drop(v_x1_2418);
          V v_x2_2419 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_p_244, 0)), v_vers_240));
          V v_t_2421;
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_Nothing: {
            v_t_2421 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str3);
            break;
          }
          case TAG_Just: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            heff_take_n(v_x2_2419, 1ULL, 1);
            v_t_2421 = v_x_2420;
            break;
          }
          default: heff_nomatch(v_x2_2419);
          }
          V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2egroupOut_lam2, 1, 2, (V[]){v_sg_241, heff_dup(v_dm_242)}), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_p_244), v_ps_245})));
          V v_t_2425 = heff_rec_n(3, shape_owner__ver__units, (V[]){heff_get_n(v_p_244, 0, 5), v_t_2421, v_t_2424});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
        } else {
          heff_drop(v_sg_241);
          heff_drop_rec(v_p_244, 5);
          heff_drop(v_ps_245);
          heff_drop(v_x1_2418);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_sg_241);
        heff_drop_rec(v_p_244, 5);
        heff_drop(v_ps_245);
        heff_drop(v_x1_2413);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2elower_2egroupOut(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2elower_2egroupOut_lam0(V self, V *args) {
  V v_q_2410 = args[0];
  V v_dm_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2411 = ({ V a_0 = heff_get_n(v_q_2410, 1, 5); V a_1 = v_dm_242; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_dm_242); r_; });
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2411, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam1(V self, V *args) {
  V v_q_2414 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2415 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = v_q_2414; V r_ = (g_heff_2ecompile_2elower_2eunitOut(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nothing: {
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_u_2416 = heff_field(v_x1_2415, 0);
    heff_take_n(v_x1_2415, 1ULL, 1);
    V v_t_2417 = heff_get_n(heff_get_n(v_u_2416, 0, 5), 3, 4);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2elower_2egroupOut_str2); V a_1 = v_t_2417; V r_ = (g_list_2eall_24s455618083x1946283732(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_heff_2ecompile_2elower_2egroupOut_lam2(V self, V *args) {
  V v_q_2422 = args[0];
  V v_sg_241 = heff_env(self)[0];
  V v_dm_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = ({ V a_0 = v_sg_241; V a_1 = v_dm_242; V a_2 = heff_dup(v_q_2422); V r_ = (g_heff_2ecompile_2elower_2eunitOut(a_0, a_1, a_2)); heff_drop(v_dm_242); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_q_2422, 1, 5), v_t_2423});
}
Clo g_heff_2ecompile_2elower_2esimplifyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2esimplifyWith_entry, 6, 0};

V g_heff_2ecompile_2elower_2esimplifyWith(V v_errors_240, V v_vers_241, V v_ks_242, V v_n_243, V v_ps_244, V v_sg_245) {
top: ;
  V v_t_246 = (g_heff_2ecompile_2elower_2eunitVers(v_vers_241, v_ps_244));
  V v_t_247 = (g_list_2emap_24s510639937x1058700299(heff_dup(v_ps_244)));
  V v_si_248 = (g_heff_2ecompile_2esimplify_2esimplifyItems(v_n_243, heff_dup(v_sg_245), v_t_246, heff_get_n(v_ks_242, 1, 2), v_t_247));
  V v_t_249 = (g_list_2efoldl_24s31530661x2067693293(heff_dup(g_map_2eempty_get()), heff_rfield(v_si_248, 2)));
  V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2egroupOut_clo), 3, (V[]){v_vers_241, v_sg_245, v_t_249}));
  V v_t_2411 = ({ V a_0 = v_ps_244; V r_ = (g_heff_2ecompile_2elower_2egroupGo(a_0)); heff_drop(v_ps_244); r_; });
  V v_t_2412 = (g_list_2emap(v_t_2410, v_t_2411));
  V v_t_2413 = (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2412));
  return heff_rec_n(4, shape_simplified__errors__groups__copies, (V[]){heff_dup(v_si_248), v_errors_240, v_t_2413, heff_get_n(v_si_248, 3, 4)});
}
V g_heff_2ecompile_2elower_2esimplifyWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2esimplifyWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2elower_2ereachedPieces_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2ereachedPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ereachedPieces_entry, 1, 0};

V g_heff_2ecompile_2elower_2ereachedPieces(V v_ps_240) {
top: ;
  V v_refs_241 = (g_list_2efoldl_24s1577366920x1019062938(heff_dup(g_map_2eempty_get()), v_ps_240));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_r_243 = ({ V a_0 = v_refs_241; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_t_242; V r_ = (g_heff_2ecompile_2eshake_2ereachBy(a_0, a_1, a_2)); heff_drop(v_refs_241); r_; });
  return (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2ereachedPieces_lam0, 1, 1, (V[]){v_r_243}), v_ps_240));
}
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ereachedPieces(a[0]);
}
V g_heff_2ecompile_2elower_2ereachedPieces_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_r_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_245 = ({ V a_0 = heff_get_n(v_p_244, 1, 5); V a_1 = v_r_243; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_r_243); r_; });
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_245, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_245);
  }
}
Clo g_heff_2ecompile_2elower_2epiecesWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2epiecesWith_entry, 4, 0};

V g_heff_2ecompile_2elower_2epiecesWith(V v_vers_240, V v_ks_241, V v_key_242, V v_acc_243) {
top: ;
  V v_errors_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
  V v_t_245 = (g_heff_2ecompile_2elower_2eentryPieces(v_vers_240, heff_dup(v_ks_241), v_key_242, heff_dup(heff_rfield(v_acc_243, 2))));
  V v_xs_246 = (g_heff_2ecompile_2elower_2erevOnto(v_t_245, heff_take_field(v_acc_243, 0)));
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  V v_ps_248 = (g_heff_2ecompile_2elower_2ereachedPieces(v_t_247));
  V v_t_249 = heff_intAdd(heff_get_n(v_acc_243, 2, 3), MK_INT(11LL));
  V v_items_2410 = (g_list_2emap_24s510639937x1058700299(heff_dup(v_ps_248)));
  V v_t_2411 = ({ V a_0 = heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}); V a_1 = v_items_2410; V r_ = (g_list_2efoldl_24s2070597502x591087275(a_0, a_1)); heff_drop(v_items_2410); r_; });
  return (g_heff_2ecompile_2elower_2esimplifyWith(v_errors_244, v_vers_240, v_ks_241, v_t_249, v_ps_248, v_t_2411));
}
V g_heff_2ecompile_2elower_2epiecesWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2epiecesWith(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2elowerProgramKept_str3, 6, "entry/");
V g_heff_2ecompile_2elower_2elowerProgramKept_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerProgramKept_entry, 4, 0};

V g_heff_2ecompile_2elower_2elowerProgramKept(V v_g_240, V v_key_241, V v_vers_242, V v_ks_243) {
top: ;
  V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_key_241), v_vers_242));
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_247 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_str0);
    break;
  }
  case TAG_Just: {
    V v_v_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_v_245), ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_str1))) {
      heff_drop(v_v_245);
      v_t_247 = ((V)&g_heff_2ecompile_2elower_2elowerProgramKept_str2);
    } else {
      v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2elowerProgramKept_str3), v_v_245);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_247, heff_dup(v_vers_242)));
  V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2epieceStep_clo), 3, (V[]){heff_dup(v_g_240), v_vers_242, heff_dup(v_ks_243)}));
  V v_t_2410 = heff_rec_n(3, shape_pieces__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2elowerProgramKept_lam0, 2, 1, (V[]){heff_dup(v_g_240)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_g_240, 0, 7); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2416 = ({ V a_0 = v_t_249; V a_1 = v_t_2410; V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
  HEFF_LAST return g_heff_2ecompile_2elower_2epiecesWith(v_t_248, v_ks_243, v_key_241, v_t_2416);
}
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerProgramKept(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2elower_2elowerProgramKept_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = ({ V a_0 = heff_dup(v_k_2412); V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_k_2412);
    return v_acc_2411;
  }
  case TAG_Just: {
    V v_e_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2412, v_e_2414}), v_acc_2411});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry, 3, 0};

V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V v_acc_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_acc_240});
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_acc_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(a[0], a[1], a[2]);
}