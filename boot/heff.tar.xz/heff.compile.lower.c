// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EApp 33163
#define TAG_EGlobal 62762
#define TAG_ELam 43266
#define TAG_EPrimCall 6589
#define TAG_ERecord 5518
#define TAG_ETag 50948
#define TAG_EVar 52881
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_errors 652506774
#define LBL_go 10063
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_supply 1056026650
static uint32_t shape_defs__errors[] = {LBL_defs, LBL_errors};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
V g_heff_2ecompile_2eanf_2etraverseN_24s662052527x1189617974(V);
V g_heff_2ecompile_2eanf_2etraverseN_24s662052527x1189617974_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eanf_2etraverseN_24s662052527x1189617974_clo;
V g_heff_2ecompile_2earity_2esatOf(V);
V g_heff_2ecompile_2earity_2esatOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2esatOf_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2elower_2eanfKept(V, V, V);
V g_heff_2ecompile_2elower_2eanfKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eanfKept_clo;
V g_heff_2ecompile_2elower_2eanfLowered(V, V);
V g_heff_2ecompile_2elower_2eanfLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eanfLowered_clo;
V g_heff_2ecompile_2elower_2eanfSimplified(V, V, V);
V g_heff_2ecompile_2elower_2eanfSimplified_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eanfSimplified_clo;
V g_heff_2ecompile_2elower_2eentryBody(V, V);
V g_heff_2ecompile_2elower_2eentryBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryBody_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2elowerErased(V, V);
V g_heff_2ecompile_2elower_2elowerErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerErased_clo;
V g_heff_2ecompile_2elower_2elowerProgram(V, V);
V g_heff_2ecompile_2elower_2elowerProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgram_clo;
V g_heff_2ecompile_2elower_2elowerProgramAnf(V, V);
V g_heff_2ecompile_2elower_2elowerProgramAnf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramAnf_clo;
V g_heff_2ecompile_2elower_2elowerSimplified(V, V, V);
V g_heff_2ecompile_2elower_2elowerSimplified_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerSimplified_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1915639815x253536901(V, V);
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1915639815x253536901_clo;
V g_list_2efoldl_24s1938129198x1830848254(V, V, V);
V g_list_2efoldl_24s1938129198x1830848254_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1938129198x1830848254_clo;
V g_list_2efoldl_24s91733047x1482905949(V, V);
V g_list_2efoldl_24s91733047x1482905949_entry(V self, V *a);
extern Clo g_list_2efoldl_24s91733047x1482905949_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2ecompile_2elower_2elowerSimplified_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2elowerSimplified_lam1(V self, V *args);
Clo g_heff_2ecompile_2elower_2elowerSimplified_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerSimplified_entry, 3, 0};

V g_heff_2ecompile_2elower_2elowerSimplified(V v_roots_240, V v_errors_241, V v_si_242) {
top: ;
  V v_defs_243 = heff_get_n(v_si_242, 0, 2);
  V v_t_244 = (g_list_2efoldl_24s91733047x1482905949(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_roots_240; V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_kept_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2elowerSimplified_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  V v_ar_2410 = (g_list_2efoldl_24s1915639815x253536901(heff_dup(g_map_2eempty_get()), v_kept_249));
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2elowerSimplified_lam1, 1, 1, (V[]){v_ar_2410}), v_kept_249));
  return heff_rec_n(2, shape_defs__errors, (V[]){v_t_2414, v_errors_241});
}
V g_heff_2ecompile_2elower_2elowerSimplified_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerSimplified(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2elowerSimplified_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ecompile_2elower_2elowerSimplified_lam1(V self, V *args) {
  V v_d_2411 = args[0];
  V v_ar_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = v_ar_2410; V r_ = (g_heff_2ecompile_2earity_2esatOf(a_0)); heff_drop(v_ar_2410); r_; });
  V v_t_2413 = heff_tr(heff_apply(heff_get_n(v_t_2412, 0, 1), 1, (V[]){heff_take_field(v_d_2411, 2)}));
  return ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_n(v_d_2411, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2elower_2elowerErased_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2elowerErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerErased_entry, 2, 0};

V g_heff_2ecompile_2elower_2elowerErased(V v_roots_240, V v_er_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_er_241, 0)));
  V v_defs_243 = (g_list_2efoldl_24s1938129198x1830848254(MK_INT(0LL), NTAG(TAG_Nil), v_t_242));
  V v_t_244 = (g_list_2efoldl_24s91733047x1482905949(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2elowerErased_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(heff_take_field(v_er_241, 2), v_t_249));
  return (g_heff_2ecompile_2elower_2elowerSimplified(v_roots_240, heff_get_n(v_er_241, 1, 3), v_t_2410));
}
V g_heff_2ecompile_2elower_2elowerErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerErased(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2elowerErased_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryKey_str0, 9, "run$entry");

static V g_heff_2ecompile_2elower_2eentryKey_val;
static int g_heff_2ecompile_2elower_2eentryKey_st;
static V g_heff_2ecompile_2elower_2eentryKey_init(void) {
  return ((V)&g_heff_2ecompile_2elower_2eentryKey_str0);
}
V g_heff_2ecompile_2elower_2eentryKey_get(void) {
  if (g_heff_2ecompile_2elower_2eentryKey_st == 2) return g_heff_2ecompile_2elower_2eentryKey_val;
  if (g_heff_2ecompile_2elower_2eentryKey_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2elower_2eentryKey_st = 1;
  g_heff_2ecompile_2elower_2eentryKey_val = heff_tr(g_heff_2ecompile_2elower_2eentryKey_init());
  g_heff_2ecompile_2elower_2eentryKey_st = 2;
  return g_heff_2ecompile_2elower_2eentryKey_val;
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str0, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str1, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str2, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str3, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str4, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str5, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str6, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str7, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str8, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str9, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str10, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str11, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str12, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str13, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str14, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str15, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str16, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str17, 4, "malg");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str18, 4, "bind");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str19, 3, "ret");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str20, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str21, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str22, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str23, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str24, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryBody_str25, 6, "MkUnit");
Clo g_heff_2ecompile_2elower_2eentryBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryBody_entry, 2, 0};

V g_heff_2ecompile_2elower_2eentryBody(V v_key_240, V v_n_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str0), heff_intShow(heff_dup(v_n_241)));
  V v_t_243 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str1), v_t_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(1LL)));
  V v_t_246 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str2), v_t_245)});
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str3), heff_intShow(heff_dup(v_n_241)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244}), heff_tag_n(TAG_EApp, 2, (V[]){v_t_246, v_t_248})});
  V v_t_2410 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2411 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2412 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str4), v_t_2412), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str5), v_t_2411), v_t_2413});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str6), v_t_2410), v_t_2414});
  V v_t_2416 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(2LL)));
  V v_t_2417 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str7), v_t_2416)});
  V v_t_2418 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str8), v_t_2418), NTAG(TAG_Nil)});
  V v_t_2420 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(3LL)));
  V v_t_2421 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str9), v_t_2420)});
  V v_t_2422 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(5LL)));
  V v_t_2423 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str10), v_t_2422)});
  V v_t_2424 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(4LL)));
  V v_t_2425 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str11), v_t_2424)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2419, v_t_2427}), NTAG(TAG_Nil)});
  V v_t_2429 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2417, v_t_2428})});
  V v_t_2430 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2431 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str12), v_t_2431), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str13), v_t_2430), v_t_2432});
  V v_t_2434 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(6LL)));
  V v_t_2435 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str14), v_t_2434)});
  V v_t_2436 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)));
  V v_t_2437 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str15), v_t_2436)});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
  V v_t_2439 = heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str17), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2433, v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str18), v_t_2429}), v_t_2441});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str19), v_t_249}), v_t_2442});
  V v_t_2444 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2445 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str20), v_t_2445), NTAG(TAG_Nil)});
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str21), v_t_2444), v_t_2446});
  V v_t_2448 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(9LL)));
  V v_t_2449 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str22), v_t_2448)});
  V v_t_2450 = heff_intShow(heff_intAdd(heff_dup(v_n_241), MK_INT(8LL)));
  V v_t_2451 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str23), v_t_2450)});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
  V v_t_2453 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2447, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2449, v_t_2452})});
  V v_t_2454 = heff_intShow(heff_intAdd(v_n_241, MK_INT(10LL)));
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryBody_str24), v_t_2454), NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag_n(TAG_ETag, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryBody_str25), NTAG(TAG_Nil)});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2455, v_t_2456}), NTAG(TAG_Nil)});
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ERecord, 1, (V[]){v_t_2443}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2457})});
  return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_240}), v_t_2458});
}
V g_heff_2ecompile_2elower_2eentryBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eentryBody(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2elowerProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerProgram_entry, 2, 0};

V g_heff_2ecompile_2elower_2elowerProgram(V v_g_240, V v_key_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_er_243 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_g_240));
  V v_body_244 = (g_heff_2ecompile_2elower_2eentryBody(v_key_241, heff_dup(heff_rfield(v_er_243, 2))));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_244}), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_er_243, 0), v_t_245));
  V v_t_247 = heff_intAdd(heff_take_field(v_er_243, 2), MK_INT(11LL));
  V v_t_248 = ({ V rv_0 = v_t_246; V rv_2 = v_t_247; V rr_ = heff_rec_reuse_n(v_er_243, 2ULL, 3, shape_defs__errors__supply); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  HEFF_LAST return g_heff_2ecompile_2elower_2elowerErased(v_t_242, v_t_248);
}
V g_heff_2ecompile_2elower_2elowerProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerProgram(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2eanfKept_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eanfKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eanfKept_entry, 3, 0};

V g_heff_2ecompile_2elower_2eanfKept(V v_supply_240, V v_kept_241, V v_errors_242) {
top: ;
  V v_ar_243 = (g_list_2efoldl_24s1915639815x253536901(heff_dup(g_map_2eempty_get()), v_kept_241));
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2eanfKept_lam0, 1, 1, (V[]){v_ar_243}), v_kept_241));
  V v_l_248 = heff_rec_n(2, shape_defs__errors, (V[]){v_t_247, v_errors_242});
  V v_t_249 = (g_heff_2ecompile_2eanf_2etraverseN_24s662052527x1189617974(heff_take_field(v_l_248, 0)));
  V v_x1_2410 = heff_tr(heff_apply(v_t_249, 1, (V[]){v_supply_240}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_n(v_l_248, 2ULL, 2, shape_defs__errors); heff_rfield(rr_, 0) = rv_0; rr_; });
}
V g_heff_2ecompile_2elower_2eanfKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eanfKept(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2eanfKept_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_ar_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = ({ V a_0 = v_ar_243; V r_ = (g_heff_2ecompile_2earity_2esatOf(a_0)); heff_drop(v_ar_243); r_; });
  V v_t_246 = heff_tr(heff_apply(heff_get_n(v_t_245, 0, 1), 1, (V[]){heff_take_field(v_d_244, 2)}));
  return ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_n(v_d_244, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2elower_2eanfSimplified_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eanfSimplified_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eanfSimplified_entry, 3, 0};

V g_heff_2ecompile_2elower_2eanfSimplified(V v_roots_240, V v_errors_241, V v_si_242) {
top: ;
  V v_defs_243 = heff_take_field(v_si_242, 0);
  V v_t_244 = (g_list_2efoldl_24s91733047x1482905949(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_roots_240; V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2eanfSimplified_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  HEFF_LAST return g_heff_2ecompile_2elower_2eanfKept(heff_get_n(v_si_242, 1, 2), v_t_249, v_errors_241);
}
V g_heff_2ecompile_2elower_2eanfSimplified_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eanfSimplified(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2eanfSimplified_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ecompile_2elower_2eanfLowered_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eanfLowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eanfLowered_entry, 2, 0};

V g_heff_2ecompile_2elower_2eanfLowered(V v_roots_240, V v_er_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_er_241, 0)));
  V v_defs_243 = (g_list_2efoldl_24s1938129198x1830848254(MK_INT(0LL), NTAG(TAG_Nil), v_t_242));
  V v_t_244 = (g_list_2efoldl_24s91733047x1482905949(heff_dup(g_map_2eempty_get()), v_defs_243));
  V v_reached_245 = ({ V a_0 = v_t_244; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2elower_2eanfLowered_lam0, 1, 1, (V[]){v_reached_245}), v_defs_243));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(heff_take_field(v_er_241, 2), v_t_249));
  return (g_heff_2ecompile_2elower_2eanfSimplified(v_roots_240, heff_get_n(v_er_241, 1, 3), v_t_2410));
}
V g_heff_2ecompile_2elower_2eanfLowered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eanfLowered(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2eanfLowered_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_reached_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_247 = ({ V a_0 = heff_get_n(v_d_246, 0, 3); V a_1 = v_reached_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_reached_245); r_; });
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
Clo g_heff_2ecompile_2elower_2elowerProgramAnf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2elowerProgramAnf_entry, 2, 0};

V g_heff_2ecompile_2elower_2elowerProgramAnf(V v_g_240, V v_key_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_er_243 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_g_240));
  V v_body_244 = (g_heff_2ecompile_2elower_2eentryBody(v_key_241, heff_dup(heff_rfield(v_er_243, 2))));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_244}), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_er_243, 0), v_t_245));
  V v_t_247 = heff_intAdd(heff_take_field(v_er_243, 2), MK_INT(11LL));
  V v_t_248 = ({ V rv_0 = v_t_246; V rv_2 = v_t_247; V rr_ = heff_rec_reuse_n(v_er_243, 2ULL, 3, shape_defs__errors__supply); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  HEFF_LAST return g_heff_2ecompile_2elower_2eanfLowered(v_t_242, v_t_248);
}
V g_heff_2ecompile_2elower_2elowerProgramAnf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2elowerProgramAnf(a[0], a[1]);
}