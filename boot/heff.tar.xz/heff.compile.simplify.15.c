// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyArm(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebindPushable(V);
V g_heff_2ecompile_2esimplify_2ebindPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindPushable_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eetaArg(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArg_clo;
V g_heff_2ecompile_2esimplify_2eetaCapturing(V);
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo;
V g_heff_2ecompile_2esimplify_2eetaLets_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_24tok2_clo;
V g_heff_2ecompile_2esimplify_2efieldBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldBound_clo;
V g_heff_2ecompile_2esimplify_2efieldsBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo;
V g_heff_2ecompile_2esimplify_2efollowOver(V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowOver_clo;
V g_heff_2ecompile_2esimplify_2efollowOver_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowOver_24tok2_clo;
V g_heff_2ecompile_2esimplify_2einlinedCall(V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eorMarks(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_clo;
V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2epushBound(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2especLam_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_24tok2_clo;
V g_heff_2ecompile_2esimplify_2esumOver(V, V, V);
V g_heff_2ecompile_2esimplify_2esumOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumOver_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etieGo(V, V, V);
V g_heff_2ecompile_2esimplify_2etieGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieGo_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2ecompile_2espec_2ecallsOnce(V);
V g_heff_2ecompile_2espec_2ecallsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsOnce_clo;
V g_list_2eany_24s155774913x881635560(V, V, V);
V g_list_2eany_24s155774913x881635560_entry(V self, V *a);
extern Clo g_list_2eany_24s155774913x881635560_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2ebinOp_24cpr(v_p_240, v_x2_241, v_x3_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ebinOp(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2esumOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumOver_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esumOver(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EGlobal: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EMatch: {
    V v_b1_2421 = heff_dup(heff_field(v_b_242, 0));
    switch (heff_tag_of(v_b1_2421)) {
    case TAG_EVar: {
      V v_y_2423 = heff_field(v_b1_2421, 0);
      V v_ru_24b1_2421_24EVar = heff_take_reuse_n(v_b1_2421, 1ULL, 1);
      switch (heff_tag_of(v_b_242)) {
      case TAG_EMatch: {
        V v_arms_2425 = heff_field(v_b_242, 1);
        V v_ru_24b_242_24EMatch = heff_take_reuse_n(v_b_242, 2ULL, 2);
        if (heff_strEq_c_lent(v_x_240, v_y_2423, 0)) {
          heff_drop(v_y_2423);
          heff_drop_cell(v_ru_24b1_2421_24EVar, 1);
          heff_drop_cell(v_ru_24b_242_24EMatch, 2);
          V v_x1_2426 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_dup(v_a_241)));
          V v_t_2430;
          switch (heff_tag_of(v_x1_2426)) {
          case TAG_MkPair: {
            V v_ts_2427 = heff_field(v_x1_2426, 0);
            heff_take_n(v_x1_2426, 1ULL, 2);
            V v_x_2429 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_2427; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_2427); r_; });
            v_t_2430 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2429, 1));
            heff_drop(v_x_2429);
            break;
          }
          default: heff_nomatch(v_x1_2426);
          }
          if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
            heff_drop(v_t_2430);
            V v_t_2431 = (g_heff_2ecompile_2esimplify_2ewaysOut(v_a_241));
            V v_x1_2432 = ({ V a_0 = MK_INT(100LL); V a_1 = v_t_2431; V a_2 = v_arms_2425; V r_ = (g_list_2eany_24s155774913x881635560(a_0, a_1, a_2)); heff_drop(v_arms_2425); r_; });
            return v_x1_2432;
          } else {
            heff_drop(v_a_241);
            heff_drop(v_arms_2425);
            heff_drop(v_t_2430);
            return NTAG(TAG_True);
          }
        } else {
          V v_t_2433 = heff_tag_at_n(v_ru_24b_242_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24b1_2421_24EVar, TAG_EVar, 1, (V[]){v_y_2423}), v_arms_2425});
          return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_t_2433));
        }
      }
      default: return heff_nomatch(v_b_242);
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_ELam: {
      V v_ru_24b1_2421_24ELam = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24ELam, v_a_241, v_b_242);
    }
    case TAG_EApp: {
      V v_ru_24b1_2421_24EApp = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24EApp, v_a_241, v_b_242);
    }
    case TAG_ELet: {
      heff_take_n(v_b1_2421, 0ULL, 3);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_ERecord: {
      V v_ru_24b1_2421_24ERecord = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24ERecord, v_a_241, v_b_242);
    }
    case TAG_EProj: {
      heff_take_n(v_b1_2421, 0ULL, 4);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_ETag: {
      heff_take_n(v_b1_2421, 0ULL, 3);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EMatch: {
      V v_ru_24b1_2421_24EMatch = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24EMatch, v_a_241, v_b_242);
    }
    case TAG_EPrim: {
      heff_take_n(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EPrimCall: {
      V v_ru_24b1_2421_24EPrimCall = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24EPrimCall, v_a_241, v_b_242);
    }
    case TAG_ECall: {
      V v_ru_24b1_2421_24ECall = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24ECall, v_a_241, v_b_242);
    }
    case TAG_EInt: {
      heff_take_n(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EFloat: {
      heff_take_na(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EStr: {
      heff_take_n(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EBytes: {
      heff_take_n(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EFixed: {
      V v_ru_24b1_2421_24EFixed = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24EFixed, v_a_241, v_b_242);
    }
    case TAG_EFloat32: {
      heff_take_na(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EAbandon: {
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EBool: {
      heff_take_n(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_ESet: {
      heff_take_n(v_b1_2421, 0ULL, 3);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EValues: {
      heff_take_n(v_b1_2421, 0ULL, 1);
      return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
    }
    case TAG_EFix: {
      V v_ru_24b1_2421_24EFix = heff_take_reuse_n(v_b1_2421, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowOver_24tok2(v_ru_24b1_2421_24EFix, v_a_241, v_b_242);
    }
    default: return heff_nomatch(v_b1_2421);
    }
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EBool: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_ESet: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EValues: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2esimplify_2efollowOver(v_a_241, v_b_242));
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2ecompile_2esimplify_2esumOver_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esumOver(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2efieldsBound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldsBound_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2efieldsBound_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldsBound_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldsBound(V v_tag_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_tag_240);
    return ((V)&g_heff_2ecompile_2esimplify_2efieldsBound_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x2_241, 0);
    V v_argv_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(g_heff_2ecompile_2esimplify_2efieldBound(heff_dup(v_tag_240), v_a_244));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldsBound_lam1, 1, 3, (V[]){v_m_246, v_tag_240, v_argv_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efieldsBound(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_s_242});
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_tag_240 = heff_env(self)[1];
  V v_argv_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2esimplify_2efieldsBound(v_tag_240, v_argv_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_x_2420;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_bs_2415 = heff_field(v_x_249, 0);
        V v_e_2416 = heff_field(v_x_249, 1);
        V v_ru_24x_249_24MkPair = heff_take_reuse_n(v_x_249, 3ULL, 2);
        switch (heff_tag_of(v_x_2413)) {
        case TAG_MkPair: {
          V v_rest_2417 = heff_field(v_x_2413, 0);
          V v_es_2418 = heff_field(v_x_2413, 1);
          heff_take_n(v_x_2413, 3ULL, 2);
          V v_t_2419 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x_249_24MkPair, v_bs_2415, v_rest_2417));
          v_x_2420 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_e_2416, v_es_2418})});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2ecompile_2esimplify_2eorMarks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eorMarks_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eorMarks(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return v_x1_240;
  }
  case TAG_Cons: {
    V v_m_242 = heff_dup(heff_field(v_x1_240, 0));
    V v_ms_243 = heff_dup(heff_field(v_x1_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      return v_x1_240;
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_x2_241, 0);
      V v_ns_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_x1_240, 2);
      V v_t_246 = heff_bool(((heff_dup(v_m_242) == NTAG(TAG_True)) || (heff_dup(v_n_244) == NTAG(TAG_True))));
      heff_drop(v_m_242);
      heff_drop(v_n_244);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2esimplify_2eorMarks_24dps(v_ms_243, v_ns_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eorMarks(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaCapturing_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eetaCapturing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (!heff_intLt_c_lent(MK_INT(60LL), v_x_246, 1)) {
      heff_drop(v_x_246);
      V v_t_247 = ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}); V r_ = (g_heff_2ecompile_2espec_2ecallsNothing(b_0)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_xs_243);
        heff_drop(v_b_244);
        heff_drop(v_t_247);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_247);
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
        V v_x_249 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_248));
        if (!heff_intLt_c_lent(MK_INT(60LL), v_x_249, 1)) {
          heff_drop(v_x_249);
          return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsOnce(b_0)); heff_drop(b_0); r_; });
        } else {
          heff_drop(v_xs_243);
          heff_drop(v_b_244);
          heff_drop(v_x_249);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_x_246);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
      V v_x_2411 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2410));
      if (!heff_intLt_c_lent(MK_INT(60LL), v_x_2411, 1)) {
        heff_drop(v_x_2411);
        return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsOnce(b_0)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_xs_243);
        heff_drop(v_b_244);
        heff_drop(v_x_2411);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaCapturing(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2etrySpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etrySpec_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_argv_242, V v_s_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_it1_248 = v_field_247;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_EVar: {
        V v_ru_24it1_248_24EVar = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2410 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EVar, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_s_243});
      }
      case TAG_EGlobal: {
        V v_ru_24it1_248_24EGlobal = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2412 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, v_s_243});
      }
      case TAG_ELam: {
        V v_xs_2413 = heff_field(v_it1_248, 0);
        V v_b_2414 = heff_field(v_it1_248, 1);
        V v_ru_24it1_248_24ELam = heff_take_reuse_n(v_it1_248, 3ULL, 2);
        return (g_heff_2ecompile_2esimplify_2especLam_24tok2(v_ru_24it1_248_24ELam, v_r_240, v_g_241, v_xs_2413, v_b_2414, v_argv_242, v_s_243));
      }
      case TAG_EApp: {
        V v_ru_24it1_248_24EApp = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        heff_drop(v_r_240);
        V v_x_2417 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_at_n(v_ru_24it1_248_24EApp, TAG_MkPair, 2, (V[]){v_x_2417, v_s_243});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_248, 0ULL, 3);
        heff_drop(v_r_240);
        V v_x_2421 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2421, v_s_243});
      }
      case TAG_ERecord: {
        V v_ru_24it1_248_24ERecord = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        heff_drop(v_r_240);
        V v_x_2424 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_at_n(v_ru_24it1_248_24ERecord, TAG_MkPair, 2, (V[]){v_x_2424, v_s_243});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_248, 0ULL, 4);
        heff_drop(v_r_240);
        V v_x_2429 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2429, v_s_243});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_248, 0ULL, 3);
        heff_drop(v_r_240);
        V v_x_2433 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2433, v_s_243});
      }
      case TAG_EMatch: {
        V v_ru_24it1_248_24EMatch = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        heff_drop(v_r_240);
        V v_x_2436 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_at_n(v_ru_24it1_248_24EMatch, TAG_MkPair, 2, (V[]){v_x_2436, v_s_243});
      }
      case TAG_EPrim: {
        V v_ru_24it1_248_24EPrim = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2438 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EPrim, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2438, v_s_243});
      }
      case TAG_EPrimCall: {
        V v_ru_24it1_248_24EPrimCall = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        heff_drop(v_r_240);
        V v_x_2441 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_at_n(v_ru_24it1_248_24EPrimCall, TAG_MkPair, 2, (V[]){v_x_2441, v_s_243});
      }
      case TAG_ECall: {
        V v_ru_24it1_248_24ECall = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        heff_drop(v_r_240);
        V v_x_2444 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_at_n(v_ru_24it1_248_24ECall, TAG_MkPair, 2, (V[]){v_x_2444, v_s_243});
      }
      case TAG_EInt: {
        V v_ru_24it1_248_24EInt = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2446 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EInt, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2446, v_s_243});
      }
      case TAG_EFloat: {
        V v_ru_24it1_248_24EFloat = heff_take_reuse_na(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2448 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EFloat, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2448, v_s_243});
      }
      case TAG_EStr: {
        V v_ru_24it1_248_24EStr = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2450 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EStr, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2450, v_s_243});
      }
      case TAG_EBytes: {
        V v_ru_24it1_248_24EBytes = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2452 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EBytes, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2452, v_s_243});
      }
      case TAG_EFixed: {
        V v_ru_24it1_248_24EFixed = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        heff_drop(v_r_240);
        V v_x_2455 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_at_n(v_ru_24it1_248_24EFixed, TAG_MkPair, 2, (V[]){v_x_2455, v_s_243});
      }
      case TAG_EFloat32: {
        V v_ru_24it1_248_24EFloat32 = heff_take_reuse_na(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2457 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EFloat32, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2457, v_s_243});
      }
      case TAG_EAbandon: {
        heff_drop(v_r_240);
        V v_x_2458 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2458, v_s_243});
      }
      case TAG_EBool: {
        V v_ru_24it1_248_24EBool = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2460 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EBool, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2460, v_s_243});
      }
      case TAG_ESet: {
        heff_take_n(v_it1_248, 0ULL, 3);
        heff_drop(v_r_240);
        V v_x_2464 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2464, v_s_243});
      }
      case TAG_EValues: {
        V v_ru_24it1_248_24EValues = heff_take_reuse_n(v_it1_248, 0ULL, 1);
        heff_drop(v_r_240);
        V v_x_2466 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it1_248_24EValues, TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2466, v_s_243});
      }
      case TAG_EFix: {
        V v_ru_24it1_248_24EFix = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        heff_drop(v_r_240);
        V v_x_2469 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
        return heff_tag_at_n(v_ru_24it1_248_24EFix, TAG_MkPair, 2, (V[]){v_x_2469, v_s_243});
      }
      default: return heff_nomatch(v_it1_248);
      }
    } else {
      heff_drop(v_r_240);
      heff_drop(v_field_247);
      V v_x_2470 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2470, v_s_243});
    }
  }
}
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etrySpec(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2epushBound_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epushBound_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epushBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushBound_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2epushBound(V v_r_240, V v_s_241, V v_arms_242, V v_argv_243, V v_z_244) {
top: ;
  V v_m_245 = heff_tr(g_heff_2ecompile_2esimplify_2ebindPushable(v_argv_243));
  V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_244}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2421 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2epushBound_lam0, 1, 2, (V[]){heff_dup(v_x_247), v_r_240}), v_arms_242));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_s_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      V v_t_2427;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2425 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 2);
        v_t_2427 = v_x_2425;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_x_2428 = ({ V a_0 = v_t_2427; V a_1 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_EMatch, 2, (V[]){v_s_241, v_x_2423}); V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2427); r_; });
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2esimplify_2epushBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushBound(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2epushBound_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2419}), v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2esimplify_2epushBound_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_a_249, 0);
    V v_vs_2411 = heff_field(v_a_249, 1);
    V v_b_2412 = heff_field(v_a_249, 2);
    heff_take_n(v_a_249, 7ULL, 3);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_y_2414 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2415 = v_y_2414;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_m_2416 = (g_heff_2ecompile_2esimplify_2eapplyArm(v_r_240, v_b_2412, v_t_2415));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2epushBound_lam1, 1, 3, (V[]){v_m_2416, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
Clo g_heff_2ecompile_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_sp_243 = heff_take_field(v_s_242, 7);
  V v_supply_244 = heff_take_field(v_s_242, 0);
  V v_fuel_245 = heff_take_field(v_s_242, 1);
  V v_defs_246 = heff_take_field(v_s_242, 2);
  V v_safe_247 = heff_take_field(v_s_242, 3);
  V v_base_248 = heff_take_field(v_s_242, 4);
  V v_total_249 = heff_take_field(v_s_242, 5);
  V v_plain_2410 = heff_take_field(v_s_242, 6);
  V v_kp_2411 = heff_get_n(v_s_242, 8, 9);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_x_2413 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_2412));
  V v_t_2414;
  if (!heff_intLt_c_lent(MK_INT(1200LL), v_x_2413, 1)) {
    heff_drop(v_x_2413);
    v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(v_key_240), heff_dup(v_b_241)));
  } else {
    heff_drop(v_x_2413);
    v_t_2414 = heff_dup(heff_rfield(v_sp_243, 0));
  }
  V v_t_2454;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 4);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2454 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2455;
  if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
    heff_drop(v_t_2454);
    v_t_2455 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(heff_rfield(v_sp_243, 1)), v_key_240, NTAG(TAG_MkUnit)));
  } else {
    heff_drop(v_key_240);
    heff_drop(v_t_2454);
    v_t_2455 = heff_dup(heff_rfield(v_sp_243, 1));
  }
  V v_p_2456 = ({ V rv_0 = v_t_2414; V rv_1 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_sp_243, 124ULL, 7, shape_all__kinds__recipes__depths__made__count__off, 16368u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_244, v_fuel_245, v_defs_246, v_safe_247, v_base_248, v_total_249, v_plain_2410, v_p_2456, v_kp_2411});
}
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeFresh_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emakeFresh(V v_h_240, V v_b0_241, V v_s_242) {
top: ;
  V v_kp_243 = heff_take_field(v_s_242, 8);
  V v_supply_244 = heff_take_field(v_s_242, 0);
  V v_fuel_245 = heff_take_field(v_s_242, 1);
  V v_defs_246 = heff_take_field(v_s_242, 2);
  V v_safe_247 = heff_take_field(v_s_242, 3);
  V v_base_248 = heff_take_field(v_s_242, 4);
  V v_total_249 = heff_take_field(v_s_242, 5);
  V v_plain_2410 = heff_take_field(v_s_242, 6);
  V v_sp_2411 = heff_get_n(v_s_242, 7, 9);
  V v_k_2412 = heff_dup(v_kp_243);
  V v_vers_2413 = heff_take_field(v_k_2412, 0);
  V v_kept_2414 = heff_take_field(v_k_2412, 1);
  V v_fresh_2415 = heff_take_field(v_k_2412, 3);
  V v_madeFresh_2416 = heff_get_n(v_k_2412, 4, 5);
  V v_t_2417 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_2413, v_kept_2414, NTAG(TAG_Nil), v_fresh_2415, v_madeFresh_2416});
  HeffT2 v_t_2418 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_244, v_fuel_245, v_defs_246, v_safe_247, v_base_248, v_total_249, v_plain_2410, v_sp_2411, v_t_2417})));
  {
    V v_field_2419 = v_t_2418.f[0];
    V v_field_2420 = v_t_2418.f[1];
    V v_x_2421 = v_field_2419;
    heff_drop(v_x_2421);
    V v_s_2422 = v_field_2420;
    V v_m_2423 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b0_241));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2422}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
      V v_m_2427 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2425));
      V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2426}));
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_MkPair: {
        V v_x_2429 = heff_field(v_x2_2428, 0);
        V v_s_2430 = heff_field(v_x2_2428, 1);
        heff_take_n(v_x2_2428, 3ULL, 2);
        HeffT2 v_t_2431 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2429, v_s_2430));
        {
          V v_field_2432 = v_t_2431.f[0];
          V v_field_2433 = v_t_2431.f[1];
          V v_x_2434 = v_field_2432;
          V v_s_2435 = v_field_2433;
          V v_kp_2436 = heff_take_field(v_s_2435, 8);
          V v_supply_2437 = heff_take_field(v_s_2435, 0);
          V v_fuel_2438 = heff_take_field(v_s_2435, 1);
          V v_defs_2439 = heff_take_field(v_s_2435, 2);
          V v_safe_2440 = heff_take_field(v_s_2435, 3);
          V v_base_2441 = heff_take_field(v_s_2435, 4);
          V v_total_2442 = heff_take_field(v_s_2435, 5);
          V v_plain_2443 = heff_take_field(v_s_2435, 6);
          V v_sp_2444 = heff_get_n(v_s_2435, 7, 9);
          V v_k_2445 = heff_dup(v_kp_2436);
          V v_vers_2446 = heff_take_field(v_k_2445, 0);
          V v_kept_2447 = heff_take_field(v_k_2445, 1);
          V v_fresh_2448 = heff_take_field(v_k_2445, 3);
          V v_madeFresh_2449 = heff_get_n(v_k_2445, 4, 5);
          V v_t_2450 = (g_std_2emap_2einsert_24s93785294x875597928(v_madeFresh_2449, v_h_240, heff_get_n(v_kp_2436, 2, 5)));
          V v_k_2451 = ({ V rv_0 = v_vers_2446; V rv_1 = v_kept_2447; V rv_3 = v_fresh_2448; V rv_4 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_kp_243, 4ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
          return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_x_2434, heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_2437, v_fuel_2438, v_defs_2439, v_safe_2440, v_base_2441, v_total_2442, v_plain_2443, v_sp_2444, v_k_2451})});
        }
      }
      default: return heff_nomatch(v_x2_2428);
      }
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
}
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeFresh(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2etieGo_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam46(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam47(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam48(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieGo_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etieGo(V v_h_240, V v_lam1_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam0, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EGlobal: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam1, 1, 1, (V[]){v_x3_242});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_x3_242, 0);
    V v_b_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_lam1_241, v_b_248));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam2, 1, 2, (V[]){v_m_249, v_xs_247});
  }
  case TAG_EApp: {
    V v_x31_2414 = heff_field(v_x3_242, 0);
    V v_argv_2415 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_2414)) {
    case TAG_EVar: {
      V v_m_2417 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam3, 1, 4, (V[]){v_m_2417, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EGlobal: {
      V v_g_2427 = heff_field(v_x31_2414, 0);
      heff_take_n(v_x31_2414, 1ULL, 1);
      V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){heff_dup(v_h_240), heff_dup(v_lam1_241)}));
      V v_m_2429 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_2428, v_argv_2415));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam4, 1, 4, (V[]){v_m_2429, v_g_2427, v_h_240, v_lam1_241});
    }
    case TAG_ELam: {
      V v_m_2437 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam5, 1, 4, (V[]){v_m_2437, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EApp: {
      V v_m_2449 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam6, 1, 4, (V[]){v_m_2449, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_ELet: {
      V v_m_2462 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam7, 1, 4, (V[]){v_m_2462, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_ERecord: {
      V v_m_2474 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam8, 1, 4, (V[]){v_m_2474, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EProj: {
      V v_m_2488 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam9, 1, 4, (V[]){v_m_2488, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_ETag: {
      V v_m_24101 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam10, 1, 4, (V[]){v_m_24101, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EMatch: {
      V v_m_24113 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam11, 1, 4, (V[]){v_m_24113, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EPrim: {
      V v_m_24124 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam12, 1, 4, (V[]){v_m_24124, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EPrimCall: {
      V v_m_24136 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam13, 1, 4, (V[]){v_m_24136, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_ECall: {
      V v_m_24148 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam14, 1, 4, (V[]){v_m_24148, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EInt: {
      V v_m_24159 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam15, 1, 4, (V[]){v_m_24159, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EFloat: {
      V v_m_24170 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam16, 1, 4, (V[]){v_m_24170, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EStr: {
      V v_m_24181 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam17, 1, 4, (V[]){v_m_24181, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EBytes: {
      V v_m_24192 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam18, 1, 4, (V[]){v_m_24192, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EFixed: {
      V v_m_24204 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam19, 1, 4, (V[]){v_m_24204, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EFloat32: {
      V v_m_24215 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam20, 1, 4, (V[]){v_m_24215, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EAbandon: {
      V v_m_24225 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam21, 1, 4, (V[]){v_m_24225, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EBool: {
      V v_m_24236 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam22, 1, 4, (V[]){v_m_24236, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_ESet: {
      V v_m_24249 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam23, 1, 4, (V[]){v_m_24249, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EValues: {
      V v_m_24260 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam24, 1, 4, (V[]){v_m_24260, v_h_240, v_lam1_241, v_argv_2415});
    }
    case TAG_EFix: {
      V v_m_24272 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_x31_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam25, 1, 4, (V[]){v_m_24272, v_h_240, v_lam1_241, v_argv_2415});
    }
    default: return heff_nomatch(v_x31_2414);
    }
  }
  case TAG_ELet: {
    V v_x_24282 = heff_field(v_x3_242, 0);
    V v_a_24283 = heff_field(v_x3_242, 1);
    V v_b_24284 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_m_24285 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_a_24283));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam26, 1, 5, (V[]){v_m_24285, v_h_240, v_lam1_241, v_b_24284, v_x_24282});
  }
  case TAG_ERecord: {
    V v_fs_24294 = heff_field(v_x3_242, 0);
    V v_ts_24295 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_f_24296 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24305 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam27, 1, 1, (V[]){v_f_24296}), v_fs_24294));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam29, 1, 2, (V[]){v_m_24305, v_ts_24295});
  }
  case TAG_EProj: {
    V v_e_24310 = heff_field(v_x3_242, 0);
    V v_l_24311 = heff_field(v_x3_242, 1);
    V v_sh_24312 = heff_field(v_x3_242, 2);
    V v_t_24313 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 15ULL, 4);
    V v_m_24314 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_lam1_241, v_e_24310));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam30, 1, 4, (V[]){v_m_24314, v_l_24311, v_sh_24312, v_t_24313});
  }
  case TAG_ETag: {
    V v_t_24319 = heff_field(v_x3_242, 0);
    V v_argv_24320 = heff_field(v_x3_242, 1);
    V v_ts_24321 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_24322 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24323 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24322, v_argv_24320));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam31, 1, 3, (V[]){v_m_24323, v_t_24319, v_ts_24321});
  }
  case TAG_EMatch: {
    V v_sc_24328 = heff_field(v_x3_242, 0);
    V v_arms_24329 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_24330 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_sc_24328));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam32, 1, 4, (V[]){v_m_24330, v_h_240, v_lam1_241, v_arms_24329});
  }
  case TAG_EPrim: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam35, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EPrimCall: {
    V v_p_24351 = heff_field(v_x3_242, 0);
    V v_argv_24352 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_24353 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24354 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24353, v_argv_24352));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam36, 1, 2, (V[]){v_m_24354, v_p_24351});
  }
  case TAG_ECall: {
    V v_g_24359 = heff_field(v_x3_242, 0);
    V v_argv_24360 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_24361 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24362 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24361, v_argv_24360));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam37, 1, 2, (V[]){v_m_24362, v_g_24359});
  }
  case TAG_EInt: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam38, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EFloat: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam39, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EStr: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam40, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EBytes: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam41, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EFixed: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam42, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam43, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam44, 1, 1, (V[]){v_x3_242});
  }
  case TAG_EBool: {
    V v_c_24381 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24382 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24383 = (g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(v_t_24382, v_c_24381));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam45, 1, 1, (V[]){v_m_24383});
  }
  case TAG_ESet: {
    V v_xs_24388 = heff_field(v_x3_242, 0);
    V v_a_24389 = heff_field(v_x3_242, 1);
    V v_b_24390 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_m_24391 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_a_24389));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam46, 1, 5, (V[]){v_m_24391, v_h_240, v_lam1_241, v_b_24390, v_xs_24388});
  }
  case TAG_EValues: {
    V v_es_24400 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24401 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24402 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24401, v_es_24400));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam47, 1, 1, (V[]){v_m_24402});
  }
  case TAG_EFix: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam48, 1, 1, (V[]){v_x3_242});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etieGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2etieGo_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_244});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_246});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_xs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_247, v_x_2412}), v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2423 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_2422, v_argv_2415));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2421}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2420, v_x_2425}), v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam4(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_g_2427 = heff_env(self)[1];
  V v_h_240 = heff_env(self)[2];
  V v_lam1_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_2427, v_h_240, 0)) {
      heff_drop(v_g_2427);
      heff_drop_cell(v_ru_24x2_2431_24MkPair, 2);
      return (g_heff_2ecompile_2esimplify_2einlinedCall(v_h_240, v_lam1_241, v_x_2432, v_s_2433));
    } else {
      heff_drop(v_h_240);
      heff_drop(v_lam1_241);
      V v_t_2434 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2427}), v_x_2432});
      return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_t_2434, v_s_2433});
    }
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam5(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2443 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_2442, v_argv_2415));
    V v_x2_2444 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2441}));
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_MkPair: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      V v_s_2446 = heff_field(v_x2_2444, 1);
      heff_take_n(v_x2_2444, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2440, v_x_2445}), v_s_2446});
    }
    default: return heff_nomatch(v_x2_2444);
    }
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam6(V self, V *args) {
  V v_s_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_s_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_s_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2455 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_2454, v_argv_2415));
    V v_x2_2456 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2453}));
    switch (heff_tag_of(v_x2_2456)) {
    case TAG_MkPair: {
      V v_x_2457 = heff_field(v_x2_2456, 0);
      V v_s_2458 = heff_field(v_x2_2456, 1);
      heff_take_n(v_x2_2456, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2452, v_x_2457}), v_s_2458});
    }
    default: return heff_nomatch(v_x2_2456);
    }
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam7(V self, V *args) {
  V v_s_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_s_2463}));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_s_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2468 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_2467, v_argv_2415));
    V v_x2_2469 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_s_2466}));
    switch (heff_tag_of(v_x2_2469)) {
    case TAG_MkPair: {
      V v_x_2470 = heff_field(v_x2_2469, 0);
      V v_s_2471 = heff_field(v_x2_2469, 1);
      heff_take_n(v_x2_2469, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2465, v_x_2470}), v_s_2471});
    }
    default: return heff_nomatch(v_x2_2469);
    }
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam8(V self, V *args) {
  V v_s_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_s_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_s_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    V v_t_2479 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2480 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_2479, v_argv_2415));
    V v_x2_2481 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_s_2478}));
    switch (heff_tag_of(v_x2_2481)) {
    case TAG_MkPair: {
      V v_x_2482 = heff_field(v_x2_2481, 0);
      V v_s_2483 = heff_field(v_x2_2481, 1);
      heff_take_n(v_x2_2481, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2477, v_x_2482}), v_s_2483});
    }
    default: return heff_nomatch(v_x2_2481);
    }
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam9(V self, V *args) {
  V v_s_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_s_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    V v_t_2493 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2494 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_2493, v_argv_2415));
    V v_x2_2495 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_s_2492}));
    switch (heff_tag_of(v_x2_2495)) {
    case TAG_MkPair: {
      V v_x_2496 = heff_field(v_x2_2495, 0);
      V v_s_2497 = heff_field(v_x2_2495, 1);
      heff_take_n(v_x2_2495, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2491, v_x_2496}), v_s_2497});
    }
    default: return heff_nomatch(v_x2_2495);
    }
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam10(V self, V *args) {
  V v_s_24102 = args[0];
  V v_m_24101 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24103 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_s_24102}));
  switch (heff_tag_of(v_x2_24103)) {
  case TAG_MkPair: {
    V v_x_24104 = heff_field(v_x2_24103, 0);
    V v_s_24105 = heff_field(v_x2_24103, 1);
    V v_ru_24x2_24103_24MkPair = heff_take_reuse_n(v_x2_24103, 3ULL, 2);
    V v_t_24106 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24107 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24106, v_argv_2415));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_24105}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_s_24110 = heff_field(v_x2_24108, 1);
      heff_take_n(v_x2_24108, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24104, v_x_24109}), v_s_24110});
    }
    default: return heff_nomatch(v_x2_24108);
    }
  }
  default: return heff_nomatch(v_x2_24103);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam11(V self, V *args) {
  V v_s_24114 = args[0];
  V v_m_24113 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24115 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_s_24114}));
  switch (heff_tag_of(v_x2_24115)) {
  case TAG_MkPair: {
    V v_x_24116 = heff_field(v_x2_24115, 0);
    V v_s_24117 = heff_field(v_x2_24115, 1);
    V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
    V v_t_24118 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24119 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24118, v_argv_2415));
    V v_x2_24120 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_s_24117}));
    switch (heff_tag_of(v_x2_24120)) {
    case TAG_MkPair: {
      V v_x_24121 = heff_field(v_x2_24120, 0);
      V v_s_24122 = heff_field(v_x2_24120, 1);
      heff_take_n(v_x2_24120, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24116, v_x_24121}), v_s_24122});
    }
    default: return heff_nomatch(v_x2_24120);
    }
  }
  default: return heff_nomatch(v_x2_24115);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam12(V self, V *args) {
  V v_s_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_s_24125}));
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_MkPair: {
    V v_x_24127 = heff_field(v_x2_24126, 0);
    V v_s_24128 = heff_field(v_x2_24126, 1);
    V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
    V v_t_24129 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24130 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24129, v_argv_2415));
    V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_s_24128}));
    switch (heff_tag_of(v_x2_24131)) {
    case TAG_MkPair: {
      V v_x_24132 = heff_field(v_x2_24131, 0);
      V v_s_24133 = heff_field(v_x2_24131, 1);
      heff_take_n(v_x2_24131, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24127, v_x_24132}), v_s_24133});
    }
    default: return heff_nomatch(v_x2_24131);
    }
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam13(V self, V *args) {
  V v_s_24137 = args[0];
  V v_m_24136 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24138 = heff_tr(heff_call(v_m_24136, 1, (V[]){v_s_24137}));
  switch (heff_tag_of(v_x2_24138)) {
  case TAG_MkPair: {
    V v_x_24139 = heff_field(v_x2_24138, 0);
    V v_s_24140 = heff_field(v_x2_24138, 1);
    V v_ru_24x2_24138_24MkPair = heff_take_reuse_n(v_x2_24138, 3ULL, 2);
    V v_t_24141 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24142 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24141, v_argv_2415));
    V v_x2_24143 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_s_24140}));
    switch (heff_tag_of(v_x2_24143)) {
    case TAG_MkPair: {
      V v_x_24144 = heff_field(v_x2_24143, 0);
      V v_s_24145 = heff_field(v_x2_24143, 1);
      heff_take_n(v_x2_24143, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24138_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24139, v_x_24144}), v_s_24145});
    }
    default: return heff_nomatch(v_x2_24143);
    }
  }
  default: return heff_nomatch(v_x2_24138);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam14(V self, V *args) {
  V v_s_24149 = args[0];
  V v_m_24148 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24150 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_s_24149}));
  switch (heff_tag_of(v_x2_24150)) {
  case TAG_MkPair: {
    V v_x_24151 = heff_field(v_x2_24150, 0);
    V v_s_24152 = heff_field(v_x2_24150, 1);
    V v_ru_24x2_24150_24MkPair = heff_take_reuse_n(v_x2_24150, 3ULL, 2);
    V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24154 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24153, v_argv_2415));
    V v_x2_24155 = heff_tr(heff_call(v_m_24154, 1, (V[]){v_s_24152}));
    switch (heff_tag_of(v_x2_24155)) {
    case TAG_MkPair: {
      V v_x_24156 = heff_field(v_x2_24155, 0);
      V v_s_24157 = heff_field(v_x2_24155, 1);
      heff_take_n(v_x2_24155, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24150_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24151, v_x_24156}), v_s_24157});
    }
    default: return heff_nomatch(v_x2_24155);
    }
  }
  default: return heff_nomatch(v_x2_24150);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam15(V self, V *args) {
  V v_s_24160 = args[0];
  V v_m_24159 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24161 = heff_tr(heff_call(v_m_24159, 1, (V[]){v_s_24160}));
  switch (heff_tag_of(v_x2_24161)) {
  case TAG_MkPair: {
    V v_x_24162 = heff_field(v_x2_24161, 0);
    V v_s_24163 = heff_field(v_x2_24161, 1);
    V v_ru_24x2_24161_24MkPair = heff_take_reuse_n(v_x2_24161, 3ULL, 2);
    V v_t_24164 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24165 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24164, v_argv_2415));
    V v_x2_24166 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_s_24163}));
    switch (heff_tag_of(v_x2_24166)) {
    case TAG_MkPair: {
      V v_x_24167 = heff_field(v_x2_24166, 0);
      V v_s_24168 = heff_field(v_x2_24166, 1);
      heff_take_n(v_x2_24166, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24162, v_x_24167}), v_s_24168});
    }
    default: return heff_nomatch(v_x2_24166);
    }
  }
  default: return heff_nomatch(v_x2_24161);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam16(V self, V *args) {
  V v_s_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_s_24171}));
  switch (heff_tag_of(v_x2_24172)) {
  case TAG_MkPair: {
    V v_x_24173 = heff_field(v_x2_24172, 0);
    V v_s_24174 = heff_field(v_x2_24172, 1);
    V v_ru_24x2_24172_24MkPair = heff_take_reuse_n(v_x2_24172, 3ULL, 2);
    V v_t_24175 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24176 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24175, v_argv_2415));
    V v_x2_24177 = heff_tr(heff_call(v_m_24176, 1, (V[]){v_s_24174}));
    switch (heff_tag_of(v_x2_24177)) {
    case TAG_MkPair: {
      V v_x_24178 = heff_field(v_x2_24177, 0);
      V v_s_24179 = heff_field(v_x2_24177, 1);
      heff_take_n(v_x2_24177, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24172_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24173, v_x_24178}), v_s_24179});
    }
    default: return heff_nomatch(v_x2_24177);
    }
  }
  default: return heff_nomatch(v_x2_24172);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam17(V self, V *args) {
  V v_s_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_s_24182}));
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_MkPair: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    V v_s_24185 = heff_field(v_x2_24183, 1);
    V v_ru_24x2_24183_24MkPair = heff_take_reuse_n(v_x2_24183, 3ULL, 2);
    V v_t_24186 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24187 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24186, v_argv_2415));
    V v_x2_24188 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_s_24185}));
    switch (heff_tag_of(v_x2_24188)) {
    case TAG_MkPair: {
      V v_x_24189 = heff_field(v_x2_24188, 0);
      V v_s_24190 = heff_field(v_x2_24188, 1);
      heff_take_n(v_x2_24188, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24184, v_x_24189}), v_s_24190});
    }
    default: return heff_nomatch(v_x2_24188);
    }
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam18(V self, V *args) {
  V v_s_24193 = args[0];
  V v_m_24192 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24194 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_s_24193}));
  switch (heff_tag_of(v_x2_24194)) {
  case TAG_MkPair: {
    V v_x_24195 = heff_field(v_x2_24194, 0);
    V v_s_24196 = heff_field(v_x2_24194, 1);
    V v_ru_24x2_24194_24MkPair = heff_take_reuse_n(v_x2_24194, 3ULL, 2);
    V v_t_24197 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24198 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24197, v_argv_2415));
    V v_x2_24199 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_s_24196}));
    switch (heff_tag_of(v_x2_24199)) {
    case TAG_MkPair: {
      V v_x_24200 = heff_field(v_x2_24199, 0);
      V v_s_24201 = heff_field(v_x2_24199, 1);
      heff_take_n(v_x2_24199, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24195, v_x_24200}), v_s_24201});
    }
    default: return heff_nomatch(v_x2_24199);
    }
  }
  default: return heff_nomatch(v_x2_24194);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam19(V self, V *args) {
  V v_s_24205 = args[0];
  V v_m_24204 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24206 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_s_24205}));
  switch (heff_tag_of(v_x2_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_x2_24206, 0);
    V v_s_24208 = heff_field(v_x2_24206, 1);
    V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
    V v_t_24209 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24210 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24209, v_argv_2415));
    V v_x2_24211 = heff_tr(heff_call(v_m_24210, 1, (V[]){v_s_24208}));
    switch (heff_tag_of(v_x2_24211)) {
    case TAG_MkPair: {
      V v_x_24212 = heff_field(v_x2_24211, 0);
      V v_s_24213 = heff_field(v_x2_24211, 1);
      heff_take_n(v_x2_24211, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24206_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24207, v_x_24212}), v_s_24213});
    }
    default: return heff_nomatch(v_x2_24211);
    }
  }
  default: return heff_nomatch(v_x2_24206);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam20(V self, V *args) {
  V v_s_24216 = args[0];
  V v_m_24215 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24217 = heff_tr(heff_call(v_m_24215, 1, (V[]){v_s_24216}));
  switch (heff_tag_of(v_x2_24217)) {
  case TAG_MkPair: {
    V v_x_24218 = heff_field(v_x2_24217, 0);
    V v_s_24219 = heff_field(v_x2_24217, 1);
    V v_ru_24x2_24217_24MkPair = heff_take_reuse_n(v_x2_24217, 3ULL, 2);
    V v_t_24220 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24221 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24220, v_argv_2415));
    V v_x2_24222 = heff_tr(heff_call(v_m_24221, 1, (V[]){v_s_24219}));
    switch (heff_tag_of(v_x2_24222)) {
    case TAG_MkPair: {
      V v_x_24223 = heff_field(v_x2_24222, 0);
      V v_s_24224 = heff_field(v_x2_24222, 1);
      heff_take_n(v_x2_24222, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24218, v_x_24223}), v_s_24224});
    }
    default: return heff_nomatch(v_x2_24222);
    }
  }
  default: return heff_nomatch(v_x2_24217);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam21(V self, V *args) {
  V v_s_24226 = args[0];
  V v_m_24225 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24227 = heff_tr(heff_call(v_m_24225, 1, (V[]){v_s_24226}));
  switch (heff_tag_of(v_x2_24227)) {
  case TAG_MkPair: {
    V v_x_24228 = heff_field(v_x2_24227, 0);
    V v_s_24229 = heff_field(v_x2_24227, 1);
    V v_ru_24x2_24227_24MkPair = heff_take_reuse_n(v_x2_24227, 3ULL, 2);
    V v_t_24230 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24231 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24230, v_argv_2415));
    V v_x2_24232 = heff_tr(heff_call(v_m_24231, 1, (V[]){v_s_24229}));
    switch (heff_tag_of(v_x2_24232)) {
    case TAG_MkPair: {
      V v_x_24233 = heff_field(v_x2_24232, 0);
      V v_s_24234 = heff_field(v_x2_24232, 1);
      heff_take_n(v_x2_24232, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24228, v_x_24233}), v_s_24234});
    }
    default: return heff_nomatch(v_x2_24232);
    }
  }
  default: return heff_nomatch(v_x2_24227);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam22(V self, V *args) {
  V v_s_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_s_24237}));
  switch (heff_tag_of(v_x2_24238)) {
  case TAG_MkPair: {
    V v_x_24239 = heff_field(v_x2_24238, 0);
    V v_s_24240 = heff_field(v_x2_24238, 1);
    V v_ru_24x2_24238_24MkPair = heff_take_reuse_n(v_x2_24238, 3ULL, 2);
    V v_t_24241 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24242 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24241, v_argv_2415));
    V v_x2_24243 = heff_tr(heff_call(v_m_24242, 1, (V[]){v_s_24240}));
    switch (heff_tag_of(v_x2_24243)) {
    case TAG_MkPair: {
      V v_x_24244 = heff_field(v_x2_24243, 0);
      V v_s_24245 = heff_field(v_x2_24243, 1);
      heff_take_n(v_x2_24243, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24239, v_x_24244}), v_s_24245});
    }
    default: return heff_nomatch(v_x2_24243);
    }
  }
  default: return heff_nomatch(v_x2_24238);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam23(V self, V *args) {
  V v_s_24250 = args[0];
  V v_m_24249 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24251 = heff_tr(heff_call(v_m_24249, 1, (V[]){v_s_24250}));
  switch (heff_tag_of(v_x2_24251)) {
  case TAG_MkPair: {
    V v_x_24252 = heff_field(v_x2_24251, 0);
    V v_s_24253 = heff_field(v_x2_24251, 1);
    V v_ru_24x2_24251_24MkPair = heff_take_reuse_n(v_x2_24251, 3ULL, 2);
    V v_t_24254 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24255 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24254, v_argv_2415));
    V v_x2_24256 = heff_tr(heff_call(v_m_24255, 1, (V[]){v_s_24253}));
    switch (heff_tag_of(v_x2_24256)) {
    case TAG_MkPair: {
      V v_x_24257 = heff_field(v_x2_24256, 0);
      V v_s_24258 = heff_field(v_x2_24256, 1);
      heff_take_n(v_x2_24256, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24252, v_x_24257}), v_s_24258});
    }
    default: return heff_nomatch(v_x2_24256);
    }
  }
  default: return heff_nomatch(v_x2_24251);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam24(V self, V *args) {
  V v_s_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_s_24261}));
  switch (heff_tag_of(v_x2_24262)) {
  case TAG_MkPair: {
    V v_x_24263 = heff_field(v_x2_24262, 0);
    V v_s_24264 = heff_field(v_x2_24262, 1);
    V v_ru_24x2_24262_24MkPair = heff_take_reuse_n(v_x2_24262, 3ULL, 2);
    V v_t_24265 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24266 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24265, v_argv_2415));
    V v_x2_24267 = heff_tr(heff_call(v_m_24266, 1, (V[]){v_s_24264}));
    switch (heff_tag_of(v_x2_24267)) {
    case TAG_MkPair: {
      V v_x_24268 = heff_field(v_x2_24267, 0);
      V v_s_24269 = heff_field(v_x2_24267, 1);
      heff_take_n(v_x2_24267, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24263, v_x_24268}), v_s_24269});
    }
    default: return heff_nomatch(v_x2_24267);
    }
  }
  default: return heff_nomatch(v_x2_24262);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam25(V self, V *args) {
  V v_s_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_argv_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_s_24273}));
  switch (heff_tag_of(v_x2_24274)) {
  case TAG_MkPair: {
    V v_x_24275 = heff_field(v_x2_24274, 0);
    V v_s_24276 = heff_field(v_x2_24274, 1);
    V v_ru_24x2_24274_24MkPair = heff_take_reuse_n(v_x2_24274, 3ULL, 2);
    V v_t_24277 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24278 = (g_prelude_2etraverse_24s2064368144x1684679122(v_t_24277, v_argv_2415));
    V v_x2_24279 = heff_tr(heff_call(v_m_24278, 1, (V[]){v_s_24276}));
    switch (heff_tag_of(v_x2_24279)) {
    case TAG_MkPair: {
      V v_x_24280 = heff_field(v_x2_24279, 0);
      V v_s_24281 = heff_field(v_x2_24279, 1);
      heff_take_n(v_x2_24279, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24275, v_x_24280}), v_s_24281});
    }
    default: return heff_nomatch(v_x2_24279);
    }
  }
  default: return heff_nomatch(v_x2_24274);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam26(V self, V *args) {
  V v_s_24286 = args[0];
  V v_m_24285 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_b_24284 = heff_env(self)[3];
  V v_x_24282 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24287 = heff_tr(heff_call(v_m_24285, 1, (V[]){v_s_24286}));
  switch (heff_tag_of(v_x2_24287)) {
  case TAG_MkPair: {
    V v_x_24288 = heff_field(v_x2_24287, 0);
    V v_s_24289 = heff_field(v_x2_24287, 1);
    V v_ru_24x2_24287_24MkPair = heff_take_reuse_n(v_x2_24287, 3ULL, 2);
    V v_m_24290 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_lam1_241, v_b_24284));
    V v_x2_24291 = heff_tr(heff_call(v_m_24290, 1, (V[]){v_s_24289}));
    switch (heff_tag_of(v_x2_24291)) {
    case TAG_MkPair: {
      V v_x_24292 = heff_field(v_x2_24291, 0);
      V v_s_24293 = heff_field(v_x2_24291, 1);
      heff_take_n(v_x2_24291, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24287_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24282, v_x_24288, v_x_24292}), v_s_24293});
    }
    default: return heff_nomatch(v_x2_24291);
    }
  }
  default: return heff_nomatch(v_x2_24287);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam28(V self, V *args) {
  V v_s_24301 = args[0];
  V v_m_24300 = heff_env(self)[0];
  V v_l_24298 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24302 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_s_24301}));
  switch (heff_tag_of(v_x2_24302)) {
  case TAG_MkPair: {
    V v_x_24303 = heff_field(v_x2_24302, 0);
    V v_s_24304 = heff_field(v_x2_24302, 1);
    V v_ru_24x2_24302_24MkPair = heff_take_reuse_n(v_x2_24302, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_24298, v_x_24303}), v_s_24304});
  }
  default: return heff_nomatch(v_x2_24302);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam27(V self, V *args) {
  V v_p_24297 = args[0];
  V v_f_24296 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24297)) {
  case TAG_MkPair: {
    V v_l_24298 = heff_field(v_p_24297, 0);
    V v_e_24299 = heff_field(v_p_24297, 1);
    heff_take_n(v_p_24297, 3ULL, 2);
    V v_m_24300 = heff_tr(heff_call(v_f_24296, 1, (V[]){v_e_24299}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam28, 1, 2, (V[]){v_m_24300, v_l_24298});
  }
  default: return heff_nomatch(v_p_24297);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam29(V self, V *args) {
  V v_s_24306 = args[0];
  V v_m_24305 = heff_env(self)[0];
  V v_ts_24295 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24307 = heff_tr(heff_call(v_m_24305, 1, (V[]){v_s_24306}));
  switch (heff_tag_of(v_x2_24307)) {
  case TAG_MkPair: {
    V v_x_24308 = heff_field(v_x2_24307, 0);
    V v_s_24309 = heff_field(v_x2_24307, 1);
    V v_ru_24x2_24307_24MkPair = heff_take_reuse_n(v_x2_24307, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24307_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_24308, v_ts_24295}), v_s_24309});
  }
  default: return heff_nomatch(v_x2_24307);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam30(V self, V *args) {
  V v_s_24315 = args[0];
  V v_m_24314 = heff_env(self)[0];
  V v_l_24311 = heff_env(self)[1];
  V v_sh_24312 = heff_env(self)[2];
  V v_t_24313 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24316 = heff_tr(heff_call(v_m_24314, 1, (V[]){v_s_24315}));
  switch (heff_tag_of(v_x2_24316)) {
  case TAG_MkPair: {
    V v_x_24317 = heff_field(v_x2_24316, 0);
    V v_s_24318 = heff_field(v_x2_24316, 1);
    V v_ru_24x2_24316_24MkPair = heff_take_reuse_n(v_x2_24316, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_24317, v_l_24311, v_sh_24312, v_t_24313}), v_s_24318});
  }
  default: return heff_nomatch(v_x2_24316);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam31(V self, V *args) {
  V v_s_24324 = args[0];
  V v_m_24323 = heff_env(self)[0];
  V v_t_24319 = heff_env(self)[1];
  V v_ts_24321 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24325 = heff_tr(heff_call(v_m_24323, 1, (V[]){v_s_24324}));
  switch (heff_tag_of(v_x2_24325)) {
  case TAG_MkPair: {
    V v_x_24326 = heff_field(v_x2_24325, 0);
    V v_s_24327 = heff_field(v_x2_24325, 1);
    V v_ru_24x2_24325_24MkPair = heff_take_reuse_n(v_x2_24325, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24325_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24319, v_x_24326, v_ts_24321}), v_s_24327});
  }
  default: return heff_nomatch(v_x2_24325);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam34(V self, V *args) {
  V v_s_24341 = args[0];
  V v_m_24340 = heff_env(self)[0];
  V v_t_24337 = heff_env(self)[1];
  V v_vs_24338 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24342 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_s_24341}));
  switch (heff_tag_of(v_x2_24342)) {
  case TAG_MkPair: {
    V v_x_24343 = heff_field(v_x2_24342, 0);
    V v_s_24344 = heff_field(v_x2_24342, 1);
    V v_ru_24x2_24342_24MkPair = heff_take_reuse_n(v_x2_24342, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24337, v_vs_24338, v_x_24343}), v_s_24344});
  }
  default: return heff_nomatch(v_x2_24342);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam33(V self, V *args) {
  V v_a_24336 = args[0];
  V v_f_24335 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24336)) {
  case TAG_MkArm: {
    V v_t_24337 = heff_field(v_a_24336, 0);
    V v_vs_24338 = heff_field(v_a_24336, 1);
    V v_b_24339 = heff_field(v_a_24336, 2);
    heff_take_n(v_a_24336, 7ULL, 3);
    V v_m_24340 = heff_tr(heff_call(v_f_24335, 1, (V[]){v_b_24339}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam34, 1, 3, (V[]){v_m_24340, v_t_24337, v_vs_24338});
  }
  default: return heff_nomatch(v_a_24336);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam32(V self, V *args) {
  V v_s_24331 = args[0];
  V v_m_24330 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_arms_24329 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24332 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_s_24331}));
  switch (heff_tag_of(v_x2_24332)) {
  case TAG_MkPair: {
    V v_x_24333 = heff_field(v_x2_24332, 0);
    V v_s_24334 = heff_field(v_x2_24332, 1);
    V v_ru_24x2_24332_24MkPair = heff_take_reuse_n(v_x2_24332, 3ULL, 2);
    V v_f_24335 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24345 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam33, 1, 1, (V[]){v_f_24335}), v_arms_24329));
    V v_x2_24346 = heff_tr(heff_call(v_m_24345, 1, (V[]){v_s_24334}));
    switch (heff_tag_of(v_x2_24346)) {
    case TAG_MkPair: {
      V v_x_24347 = heff_field(v_x2_24346, 0);
      V v_s_24348 = heff_field(v_x2_24346, 1);
      heff_take_n(v_x2_24346, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24333, v_x_24347}), v_s_24348});
    }
    default: return heff_nomatch(v_x2_24346);
    }
  }
  default: return heff_nomatch(v_x2_24332);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam35(V self, V *args) {
  V v_s_24350 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24350});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam36(V self, V *args) {
  V v_s_24355 = args[0];
  V v_m_24354 = heff_env(self)[0];
  V v_p_24351 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24356 = heff_tr(heff_call(v_m_24354, 1, (V[]){v_s_24355}));
  switch (heff_tag_of(v_x2_24356)) {
  case TAG_MkPair: {
    V v_x_24357 = heff_field(v_x2_24356, 0);
    V v_s_24358 = heff_field(v_x2_24356, 1);
    V v_ru_24x2_24356_24MkPair = heff_take_reuse_n(v_x2_24356, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24356_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24351, v_x_24357}), v_s_24358});
  }
  default: return heff_nomatch(v_x2_24356);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam37(V self, V *args) {
  V v_s_24363 = args[0];
  V v_m_24362 = heff_env(self)[0];
  V v_g_24359 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24364 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_s_24363}));
  switch (heff_tag_of(v_x2_24364)) {
  case TAG_MkPair: {
    V v_x_24365 = heff_field(v_x2_24364, 0);
    V v_s_24366 = heff_field(v_x2_24364, 1);
    V v_ru_24x2_24364_24MkPair = heff_take_reuse_n(v_x2_24364, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24364_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24359, v_x_24365}), v_s_24366});
  }
  default: return heff_nomatch(v_x2_24364);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam38(V self, V *args) {
  V v_s_24368 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24368});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam39(V self, V *args) {
  V v_s_24370 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24370});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam40(V self, V *args) {
  V v_s_24372 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24372});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam41(V self, V *args) {
  V v_s_24374 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24374});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam42(V self, V *args) {
  V v_s_24377 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24377});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam43(V self, V *args) {
  V v_s_24379 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24379});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam44(V self, V *args) {
  V v_s_24380 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24380});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam45(V self, V *args) {
  V v_s_24384 = args[0];
  V v_m_24383 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24385 = heff_tr(heff_call(v_m_24383, 1, (V[]){v_s_24384}));
  switch (heff_tag_of(v_x2_24385)) {
  case TAG_MkPair: {
    V v_x_24386 = heff_field(v_x2_24385, 0);
    V v_s_24387 = heff_field(v_x2_24385, 1);
    V v_ru_24x2_24385_24MkPair = heff_take_reuse_n(v_x2_24385, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24385_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24386}), v_s_24387});
  }
  default: return heff_nomatch(v_x2_24385);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam46(V self, V *args) {
  V v_s_24392 = args[0];
  V v_m_24391 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_b_24390 = heff_env(self)[3];
  V v_xs_24388 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24393 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_s_24392}));
  switch (heff_tag_of(v_x2_24393)) {
  case TAG_MkPair: {
    V v_x_24394 = heff_field(v_x2_24393, 0);
    V v_s_24395 = heff_field(v_x2_24393, 1);
    V v_ru_24x2_24393_24MkPair = heff_take_reuse_n(v_x2_24393, 3ULL, 2);
    V v_m_24396 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_lam1_241, v_b_24390));
    V v_x2_24397 = heff_tr(heff_call(v_m_24396, 1, (V[]){v_s_24395}));
    switch (heff_tag_of(v_x2_24397)) {
    case TAG_MkPair: {
      V v_x_24398 = heff_field(v_x2_24397, 0);
      V v_s_24399 = heff_field(v_x2_24397, 1);
      heff_take_n(v_x2_24397, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24388, v_x_24394, v_x_24398}), v_s_24399});
    }
    default: return heff_nomatch(v_x2_24397);
    }
  }
  default: return heff_nomatch(v_x2_24393);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam47(V self, V *args) {
  V v_s_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_s_24403}));
  switch (heff_tag_of(v_x2_24404)) {
  case TAG_MkPair: {
    V v_x_24405 = heff_field(v_x2_24404, 0);
    V v_s_24406 = heff_field(v_x2_24404, 1);
    V v_ru_24x2_24404_24MkPair = heff_take_reuse_n(v_x2_24404, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24405}), v_s_24406});
  }
  default: return heff_nomatch(v_x2_24404);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam48(V self, V *args) {
  V v_s_24409 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x3_242, v_s_24409});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(V v_tok_240, V v_r_241, V v_xs_242, V v_b_243, V v_argv_244) {
top: ;
  V v_simp_245 = heff_take_field(v_r_241, 0);
  V v_applyTo_246 = heff_get_n(v_r_241, 1, 4);
  V v_a_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_b_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
  V v_t_249;
  if (heff_intLe_c_lent(v_a_247, v_b_248, 0)) {
    heff_drop(v_b_248);
    v_t_249 = v_a_247;
  } else {
    heff_drop(v_a_247);
    v_t_249 = v_b_248;
  }
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_249, heff_dup(v_xs_242)));
  V v_a_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_b_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
  V v_t_2413;
  if (heff_intLe_c_lent(v_a_2411, v_b_2412, 0)) {
    heff_drop(v_b_2412);
    v_t_2413 = v_a_2411;
  } else {
    heff_drop(v_a_2411);
    v_t_2413 = v_b_2412;
  }
  V v_t_2414 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_2413, heff_dup(v_argv_244)));
  V v_t_2415 = (g_heff_2ecompile_2esimplify_2ezipL(v_t_2410, v_t_2414));
  V v_x_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_a_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_b_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
  V v_t_2419;
  if (heff_intLe_c_lent(v_a_2417, v_b_2418, 0)) {
    heff_drop(v_b_2418);
    v_t_2419 = v_a_2417;
  } else {
    heff_drop(v_a_2417);
    v_t_2419 = v_b_2418;
  }
  V v_t_2424;
  if (heff_intLt_c(v_t_2419, v_x_2416)) {
    V v_a_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
    V v_b_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
    V v_t_2422;
    if (heff_intLe_c_lent(v_a_2420, v_b_2421, 0)) {
      heff_drop(v_b_2421);
      v_t_2422 = v_a_2420;
    } else {
      heff_drop(v_a_2420);
      v_t_2422 = v_b_2421;
    }
    V v_t_2423 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2422, heff_dup(v_xs_242)));
    v_t_2424 = heff_tag_at_n(v_tok_240, TAG_ELam, 2, (V[]){v_t_2423, v_b_243});
  } else {
    heff_drop_cell(v_tok_240, 2);
    v_t_2424 = v_b_243;
  }
  V v_t_2425 = ({ V a_0 = v_t_2415; V a_1 = v_t_2424; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_m_2426 = heff_tr(heff_call(v_simp_245, 1, (V[]){v_t_2425}));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_lam0, 1, 4, (V[]){v_m_2426, v_xs_242, v_argv_244, v_applyTo_246});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyLam_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_24tok2_lam0(V self, V *args) {
  V v_s_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  V v_argv_244 = heff_env(self)[2];
  V v_applyTo_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_s_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_s_2430 = heff_field(v_x2_2428, 1);
    heff_take_n(v_x2_2428, 3ULL, 2);
    V v_a_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
    V v_b_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
    V v_t_2433;
    if (heff_intLe_c_lent(v_a_2431, v_b_2432, 0)) {
      heff_drop(v_b_2432);
      v_t_2433 = v_a_2431;
    } else {
      heff_drop(v_a_2431);
      v_t_2433 = v_b_2432;
    }
    V v_t_2434 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2433, v_argv_244));
    V f_ = v_applyTo_246;
    heff_room[0] = v_x_2429;
    heff_room[1] = v_t_2434;
    heff_room[2] = v_s_2430;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
Clo g_heff_2ecompile_2esimplify_2eetaLets_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLets_24tok2_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2eetaLets_24tok2(V v_tok_240, V v_r_241, V v_x2_242, V v_x3_243, V v_rest_244, V v_z_245) {
top: ;
  if ((heff_dup(v_x2_242) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_x3_243)) {
    case TAG_MkPair: {
      V v_bds_246 = heff_field(v_x3_243, 0);
      V v_a_247 = heff_field(v_x3_243, 1);
      V v_ru_24x3_243_24MkPair = heff_take_reuse_n(v_x3_243, 3ULL, 2);
      V v_x2_248 = ({ V a_0 = v_r_241; V b_1 = NTAG(TAG_True); V a_2 = v_a_247; V a_3 = v_rest_244; V a_4 = v_z_245; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2eetaArg(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_s_2410 = heff_field(v_x2_248, 1);
        V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
        V v_x_2414;
        switch (heff_tag_of(v_x_249)) {
        case TAG_MkPair: {
          V v_rest_2411 = heff_field(v_x_249, 0);
          V v_argv_2412 = heff_field(v_x_249, 1);
          heff_take_n(v_x_249, 3ULL, 2);
          V v_t_2413 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x2_248_24MkPair, v_bds_246, v_rest_2411));
          v_x_2414 = heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_t_2413, v_argv_2412});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return heff_tag_at_n(v_ru_24x3_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_s_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_x3_243);
    }
  } else {
    heff_drop(v_r_241);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_MkPair: {
      V v_bds_2415 = heff_field(v_x3_243, 0);
      V v_a_2416 = heff_field(v_x3_243, 1);
      V v_ru_24x3_243_24MkPair = heff_take_reuse_n(v_x3_243, 3ULL, 2);
      V v_t_2419;
      switch (heff_tag_of(v_rest_244)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_dup(heff_field(v_rest_244, 0));
        v_t_2419 = v_x_2417;
        break;
      }
      default: heff_nomatch(v_rest_244);
      }
      V v_t_2420 = ({ V a_0 = v_bds_2415; V a_1 = v_a_2416; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2415); r_; });
      V v_t_2423;
      switch (heff_tag_of(v_rest_244)) {
      case TAG_MkPair: {
        V v_y_2422 = heff_field(v_rest_244, 1);
        heff_take_n(v_rest_244, 2ULL, 2);
        v_t_2423 = v_y_2422;
        break;
      }
      default: heff_nomatch(v_rest_244);
      }
      V v_x_2424 = heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2423})});
      return heff_tag_at_n(v_ru_24x3_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_z_245});
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eetaLets_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eetaLets_24tok2(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}