// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2evalue_2elocalsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2elocalsAt_entry, 2, 0};

V g_heff_2evalue_2elocalsAt(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LNil: {
    heff_drop(v_i_241);
    return heff_abandon();
  }
  case TAG_LSnoc: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_v_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tail(heff_dup(v_v_243), 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_False: {
      V t_0 = v_e_242;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_LChunkSnoc: {
    V v_e_245 = heff_field(v_x1_240, 0);
    V v_vs_246 = heff_field(v_x1_240, 1);
    V v_t_247 = heff_intLt(heff_dup(v_i_241), heff_arrayLength(heff_dup(v_vs_246)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_intSub(heff_arrayLength(heff_dup(v_vs_246)), v_i_241);
      return heff_arrayIndex(heff_dup(v_vs_246), heff_intSub(v_t_248, MK_INT(1LL)));
    }
    case TAG_False: {
      V v_t_249 = heff_intSub(v_i_241, heff_arrayLength(heff_dup(v_vs_246)));
      V t_0 = v_e_245;
      V t_1 = v_t_249;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2evalue_2elocalsAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2evalue_2elocalsAt(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2evalue_2ebehavior_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2ebehavior_entry, 1, 0};

V g_heff_2evalue_2ebehavior(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    V v_u_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VU = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_240_24VU, TAG_LikeU, 1, (V[]){v_u_241});
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_apply(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return NTAG(TAG_NoRules);
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    V v_level_249 = heff_field(v_x1_240, 0);
    V v_dom_2410 = heff_field(v_x1_240, 1);
    V v_cod_2411 = heff_field(v_x1_240, 2);
    V v_implicit_2412 = heff_field(v_x1_240, 3);
    V v_ru_24x1_240_24VFunction = heff_take_reuse_n(v_x1_240, 15ULL, 4);
    return heff_tag_at(v_ru_24x1_240_24VFunction, TAG_LikeFunction, 4, (V[]){v_level_249, v_dom_2410, v_cod_2411, v_implicit_2412});
  }
  case TAG_VRecord: {
    V v_level_2413 = heff_field(v_x1_240, 0);
    V v_capture_2414 = heff_field(v_x1_240, 1);
    V v_fieldTypes_2415 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 4);
    return heff_tag(TAG_LikeRecord, 3, (V[]){v_level_2413, v_capture_2414, v_fieldTypes_2415});
  }
  case TAG_VSum: {
    V v_st_2417 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VSum = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_240_24VSum, TAG_LikeSum, 1, (V[]){v_st_2417});
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_LikeInt);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_LikeFloat);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_LikeString);
  }
  case TAG_VPrimArray: {
    V v_a_2418 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VPrimArray = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_240_24VPrimArray, TAG_LikeArray, 1, (V[]){v_a_2418});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2evalue_2ebehavior_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2ebehavior(a[0]);
}
Clo g_heff_2evalue_2elevelOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2elevelOf_entry, 1, 0};

V g_heff_2evalue_2elevelOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    V v_u_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_u_241)) {
    case TAG_SmallU: {
      return NTAG(TAG_Large);
    }
    case TAG_LargeU: {
      return NTAG(TAG_TopL);
    }
    default: return heff_nomatch(v_u_241);
    }
  }
  case TAG_VDecode: {
    V v_u_244 = heff_field(v_x1_240, 2);
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      return NTAG(TAG_Small);
    }
    case TAG_LargeU: {
      return NTAG(TAG_Large);
    }
    default: return heff_nomatch(v_u_244);
    }
  }
  case TAG_VFunction: {
    V v_level_247 = heff_field(v_x1_240, 0);
    return heff_dup(v_level_247);
  }
  case TAG_VRecord: {
    V v_level_2411 = heff_field(v_x1_240, 0);
    return heff_dup(v_level_2411);
  }
  case TAG_VSum: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimArray: {
    V v_a_2416 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2416;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2evalue_2elevelOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2evalue_2elevelOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2evalue_2ecoerceToFieldsMaybe_lam0(V self, V *args);
Clo g_heff_2evalue_2ecoerceToFieldsMaybe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2ecoerceToFieldsMaybe_entry, 1, 0};

V g_heff_2evalue_2ecoerceToFieldsMaybe(V v_v_240) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_expansion_244 = heff_field(v_v_240, 3);
    heff_take_n(v_v_240, 8ULL, 5);
    V v_t_246 = heff_tr(heff_apply(v_expansion_244, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_IntoCons: {
      V v_fields_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24IntoCons = heff_take_reuse_n(v_t_246, 1ULL, 1);
      V v_xs_248 = heff_get(heff_dup(v_fields_247), LBL_values);
      V v_t_2411 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_248)), heff_clo(g_heff_2evalue_2ecoerceToFieldsMaybe_lam0, 1, 1, (V[]){v_xs_248}));
      V v_t_2412 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fields_247), LBL_keys), heff_get(v_fields_247, LBL_byName), v_t_2411});
      return heff_tag_at(v_ru_24t_246_24IntoCons, TAG_Just, 1, (V[]){v_t_2412});
    }
    case TAG_NotApplicable: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_v_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VLam: {
    heff_take_n(v_v_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_VCons: {
    V v_fields_2416 = heff_field(v_v_240, 0);
    V v_ru_24v_240_24VCons = heff_take_reuse_n(v_v_240, 1ULL, 1);
    return heff_tag_at(v_ru_24v_240_24VCons, TAG_Just, 1, (V[]){v_fields_2416});
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2ecoerceToFieldsMaybe(a[0]);
}
V g_heff_2evalue_2ecoerceToFieldsMaybe_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_xs_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_arrayIndex(v_xs_248, v_i_249);
  return heff_tag(TAG_Nom, 1, (V[]){v_t_2410});
}
Clo g_heff_2evalue_2eproj_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eproj_entry, 2, 0};

V g_heff_2evalue_2eproj(V v_v_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_t_247 = (g_heff_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_d_249 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_d_249 = v_fields_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_d_249), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop(v_d_249);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_xs_2412 = heff_get(v_d_249, LBL_values);
      V v_t_2413 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2411));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        V v_t_2414 = heff_intLt(heff_dup(v_i_2411), heff_arrayLength(heff_dup(v_xs_2412)));
        switch (heff_tag_of(v_t_2414)) {
        case TAG_True: {
          V v_v_2415 = heff_arrayIndex(v_xs_2412, v_i_2411);
          return v_v_2415;
        }
        case TAG_False: {
          heff_drop(v_i_2411);
          heff_drop(v_xs_2412);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
      case TAG_False: {
        heff_drop(v_i_2411);
        heff_drop(v_xs_2412);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2417 = (g_heff_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_2419;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      v_d_2419 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      v_d_2419 = v_fields_2418;
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2420 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_d_2419), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2420)) {
    case TAG_Nothing: {
      heff_drop(v_d_2419);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2421 = heff_field(v_t_2420, 0);
      heff_take_n(v_t_2420, 1ULL, 1);
      V v_xs_2422 = heff_get(v_d_2419, LBL_values);
      V v_t_2423 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2421));
      switch (heff_tag_of(v_t_2423)) {
      case TAG_True: {
        V v_t_2424 = heff_intLt(heff_dup(v_i_2421), heff_arrayLength(heff_dup(v_xs_2422)));
        switch (heff_tag_of(v_t_2424)) {
        case TAG_True: {
          V v_v_2425 = heff_arrayIndex(v_xs_2422, v_i_2421);
          return v_v_2425;
        }
        case TAG_False: {
          heff_drop(v_i_2421);
          heff_drop(v_xs_2422);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_2424);
        }
      }
      case TAG_False: {
        heff_drop(v_i_2421);
        heff_drop(v_xs_2422);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_VLam: {
    V v_t_2428 = (g_heff_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_2430;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      v_d_2430 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_2429 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      v_d_2430 = v_fields_2429;
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    V v_t_2431 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_d_2430), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Nothing: {
      heff_drop(v_d_2430);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2432 = heff_field(v_t_2431, 0);
      heff_take_n(v_t_2431, 1ULL, 1);
      V v_xs_2433 = heff_get(v_d_2430, LBL_values);
      V v_t_2434 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2432));
      switch (heff_tag_of(v_t_2434)) {
      case TAG_True: {
        V v_t_2435 = heff_intLt(heff_dup(v_i_2432), heff_arrayLength(heff_dup(v_xs_2433)));
        switch (heff_tag_of(v_t_2435)) {
        case TAG_True: {
          V v_v_2436 = heff_arrayIndex(v_xs_2433, v_i_2432);
          return v_v_2436;
        }
        case TAG_False: {
          heff_drop(v_i_2432);
          heff_drop(v_xs_2433);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_2435);
        }
      }
      case TAG_False: {
        heff_drop(v_i_2432);
        heff_drop(v_xs_2433);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2434);
      }
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  case TAG_VCons: {
    V v_t_2438 = (g_heff_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    V v_d_2440;
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nothing: {
      v_d_2440 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_fields_2439 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      v_d_2440 = v_fields_2439;
      break;
    }
    default: heff_nomatch(v_t_2438);
    }
    V v_t_2441 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_d_2440), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Nothing: {
      heff_drop(v_d_2440);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2442 = heff_field(v_t_2441, 0);
      heff_take_n(v_t_2441, 1ULL, 1);
      V v_xs_2443 = heff_get(v_d_2440, LBL_values);
      V v_t_2444 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2442));
      switch (heff_tag_of(v_t_2444)) {
      case TAG_True: {
        V v_t_2445 = heff_intLt(heff_dup(v_i_2442), heff_arrayLength(heff_dup(v_xs_2443)));
        switch (heff_tag_of(v_t_2445)) {
        case TAG_True: {
          V v_v_2446 = heff_arrayIndex(v_xs_2443, v_i_2442);
          return v_v_2446;
        }
        case TAG_False: {
          heff_drop(v_i_2442);
          heff_drop(v_xs_2443);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_2445);
        }
      }
      case TAG_False: {
        heff_drop(v_i_2442);
        heff_drop(v_xs_2443);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2444);
      }
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_x_241);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2evalue_2eproj_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2eproj(a[0], a[1]);
}
V g_heff_2evalue_2egoER_24s11_lam0(V self, V *args);
V g_heff_2evalue_2egoER_24s11_lam1(V self, V *args);
V g_heff_2evalue_2egoER_24s11_lam2(V self, V *args);
Clo g_heff_2evalue_2egoER_24s11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2egoER_24s11_entry, 6, 0};

V g_heff_2evalue_2egoER_24s11(V v_vs_240, V v_h_241, V v_sp_242, V v_desc_243, V v_x6_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_vs_240);
    heff_drop(v_h_241);
    heff_drop(v_sp_242);
    heff_drop(v_desc_243);
    return v_acc_245;
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_f_249 = heff_field(v_x61_246, 1);
      V v_ru_24x61_246_24MkPair = heff_take_reuse_n(v_x61_246, 3ULL, 2);
      V v_x6_2410 = heff_tr(heff_apply(v_f_249, 1, (V[]){heff_dup(v_vs_240)}));
      V v_v_2418;
      switch (heff_tag_of(v_x6_2410)) {
      case TAG_MkField: {
        V v_fty_2411 = heff_field(v_x6_2410, 0);
        V v_x62_2412 = heff_field(v_x6_2410, 1);
        heff_take_n(v_x6_2410, 3ULL, 2);
        switch (heff_tag_of(v_x62_2412)) {
        case TAG_Nothing: {
          V v_d2_2414;
          switch (heff_tag_of(v_desc_243)) {
          case TAG_Nothing: {
            v_d2_2414 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x_2413 = heff_dup(heff_field(v_desc_243, 0));
            v_d2_2414 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2evalue_2eproj(v_x_2413, heff_dup(v_x_248)))});
            break;
          }
          default: heff_nomatch(v_desc_243);
          }
          v_v_2418 = (g_heff_2evalue_2ereflect(heff_dup(v_h_241), heff_clo(g_heff_2evalue_2egoER_24s11_lam0, 1, 2, (V[]){heff_dup(v_sp_242), v_x_248}), heff_clo(g_heff_2evalue_2egoER_24s11_lam1, 1, 1, (V[]){v_fty_2411}), v_d2_2414));
          break;
        }
        case TAG_Just: {
          V v_v_2417 = heff_field(v_x62_2412, 0);
          heff_take_n(v_x62_2412, 1ULL, 1);
          heff_drop(v_x_248);
          heff_drop(v_fty_2411);
          v_v_2418 = v_v_2417;
          break;
        }
        default: heff_nomatch(v_x62_2412);
        }
        break;
      }
      default: heff_nomatch(v_x6_2410);
      }
      V t_0 = heff_tag_at(v_ru_24x6_244_24Cons, TAG_LSnoc, 2, (V[]){v_vs_240, heff_clo(g_heff_2evalue_2egoER_24s11_lam2, 1, 1, (V[]){heff_dup(v_v_2418)})});
      V t_1 = v_h_241;
      V t_2 = v_sp_242;
      V t_3 = v_desc_243;
      V t_4 = v_rest_247;
      V t_5 = heff_tag_at(v_ru_24x61_246_24MkPair, TAG_Cons, 2, (V[]){v_v_2418, v_acc_245});
      v_vs_240 = t_0;
      v_h_241 = t_1;
      v_sp_242 = t_2;
      v_desc_243 = t_3;
      v_x6_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2evalue_2egoER_24s11_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2egoER_24s11(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2evalue_2egoER_24s11_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2415);
  return heff_tag(TAG_SpProj, 2, (V[]){v_sp_242, v_x_248});
}
V g_heff_2evalue_2egoER_24s11_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  return v_fty_2411;
}
V g_heff_2evalue_2egoER_24s11_lam2(V self, V *args) {
  V v_u_2419 = args[0];
  V v_v_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_v_2418;
}
V g_heff_2evalue_2emkNeu_24s10_lam0(V self, V *args);
V g_heff_2evalue_2emkNeu_24s10_lam1(V self, V *args);
Clo g_heff_2evalue_2emkNeu_24s10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2emkNeu_24s10_entry, 4, 0};

V g_heff_2evalue_2emkNeu_24s10(V v_h_240, V v_spine_241, V v_ty_242, V v_desc_243) {
top: ;
  return heff_tag(TAG_VNeu, 5, (V[]){heff_dup(v_h_240), heff_dup(v_spine_241), heff_dup(v_ty_242), heff_clo(g_heff_2evalue_2emkNeu_24s10_lam0, 1, 4, (V[]){v_ty_242, v_h_240, v_spine_241, heff_dup(v_desc_243)}), heff_clo(g_heff_2evalue_2emkNeu_24s10_lam1, 1, 1, (V[]){v_desc_243})});
}
V g_heff_2evalue_2emkNeu_24s10_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2emkNeu_24s10(a[0], a[1], a[2], a[3]);
}
V g_heff_2evalue_2emkNeu_24s10_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_spine_241 = heff_env(self)[2];
  V v_desc_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_244);
  V v_t_245 = heff_tr(heff_apply(v_ty_242, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_246 = (g_heff_2evalue_2ebehavior(v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_LikeU: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_246, 0ULL, 4);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRecord: {
    V v_capture_2413 = heff_field(v_t_246, 1);
    V v_fieldTypes_2414 = heff_field(v_t_246, 2);
    heff_take_n(v_t_246, 6ULL, 3);
    V v_t_2415 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2414), LBL_keys));
    V v_t_2416 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2414), LBL_values));
    V v_t_2417 = (g_heff_2edict_2ezipKV(v_t_2415, v_t_2416));
    V v_xs_2418 = (g_heff_2evalue_2egoER_24s11(v_capture_2413, v_h_240, v_spine_241, v_desc_243, v_t_2417, NTAG(TAG_Nil)));
    V v_t_2419 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_2414), LBL_keys), heff_get(v_fieldTypes_2414, LBL_byName), heff_arrayFromList(v_t_2419)});
    return heff_tag(TAG_IntoCons, 1, (V[]){v_t_2420});
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeInt: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFloat: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeString: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_NoRules: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2evalue_2emkNeu_24s10_lam1(V self, V *args) {
  V v_u_2423 = args[0];
  V v_desc_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return v_desc_243;
}
Clo g_heff_2evalue_2ereflect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2ereflect_entry, 4, 0};

V g_heff_2evalue_2ereflect(V v_h_240, V v_spineTh_241, V v_ty_242, V v_edesc_243) {
top: ;
  switch (heff_tag_of(v_edesc_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tr(heff_apply(v_spineTh_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    HEFF_LAST return g_heff_2evalue_2emkNeu_24s10(v_h_240, v_t_244, v_ty_242, NTAG(TAG_Nothing));
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_edesc_243, 0);
    V v_ru_24edesc_243_24Just = heff_take_reuse_n(v_edesc_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_Nom: {
      V v_v_246 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      heff_drop(v_h_240);
      heff_drop(v_spineTh_241);
      heff_drop(v_ty_242);
      heff_drop_cell(v_ru_24edesc_243_24Just, 1);
      return v_v_246;
    }
    case TAG_Describe: {
      V v_desc_247 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      V v_t_248 = heff_tr(heff_apply(v_spineTh_241, 1, (V[]){NTAG(TAG_MkUnit)}));
      HEFF_LAST return g_heff_2evalue_2emkNeu_24s10(v_h_240, v_t_248, v_ty_242, heff_tag_at(v_ru_24edesc_243_24Just, TAG_Just, 1, (V[]){v_desc_247}));
    }
    case TAG_Become: {
      V v_v_249 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      heff_drop(v_h_240);
      heff_drop(v_spineTh_241);
      heff_drop(v_ty_242);
      heff_drop_cell(v_ru_24edesc_243_24Just, 1);
      return v_v_249;
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_edesc_243);
  }
}
V g_heff_2evalue_2ereflect_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2ereflect(a[0], a[1], a[2], a[3]);
}
V g_heff_2evalue_2eprojAt_lam0(V self, V *args);
Clo g_heff_2evalue_2eprojAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eprojAt_entry, 3, 0};

V g_heff_2evalue_2eprojAt(V v_v_240, V v_x_241, V v_a_242) {
top: ;
  V v_t_243 = (g_heff_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_v_240)) {
    case TAG_VNeu: {
      V v_h_244 = heff_field(v_v_240, 0);
      V v_sp_245 = heff_field(v_v_240, 1);
      heff_take_n(v_v_240, 3ULL, 5);
      return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2emkNeu_24s10(v_h_244, heff_tag(TAG_SpProj, 2, (V[]){v_sp_245, v_x_241}), heff_clo(g_heff_2evalue_2eprojAt_lam0, 1, 1, (V[]){v_a_242}), NTAG(TAG_Nothing)))});
    }
    case TAG_VCode: {
      heff_drop(v_a_242);
      return (g_heff_2evalue_2eproj(v_v_240, v_x_241));
    }
    case TAG_VLam: {
      heff_drop(v_a_242);
      return (g_heff_2evalue_2eproj(v_v_240, v_x_241));
    }
    case TAG_VCons: {
      heff_drop(v_a_242);
      return (g_heff_2evalue_2eproj(v_v_240, v_x_241));
    }
    case TAG_VOpaque: {
      heff_drop(v_a_242);
      return (g_heff_2evalue_2eproj(v_v_240, v_x_241));
    }
    default: return heff_nomatch(v_v_240);
    }
  }
  case TAG_Just: {
    V v_fields_2414 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop(v_a_242);
    V v_t_2415 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_fields_2414), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      heff_drop(v_fields_2414);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      V v_xs_2417 = heff_get(v_fields_2414, LBL_values);
      V v_t_2418 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2416));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_True: {
        V v_t_2419 = heff_intLt(heff_dup(v_i_2416), heff_arrayLength(heff_dup(v_xs_2417)));
        switch (heff_tag_of(v_t_2419)) {
        case TAG_True: {
          V v_v_2420 = heff_arrayIndex(v_xs_2417, v_i_2416);
          return v_v_2420;
        }
        case TAG_False: {
          heff_drop(v_i_2416);
          heff_drop(v_xs_2417);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_2419);
        }
      }
      case TAG_False: {
        heff_drop(v_i_2416);
        heff_drop(v_xs_2417);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2418);
      }
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2evalue_2eprojAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2eprojAt(a[0], a[1], a[2]);
}
V g_heff_2evalue_2eprojAt_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_a_242;
}
V g_heff_2evalue_2edecodeNeu_lam0(V self, V *args); static Clo g_heff_2evalue_2edecodeNeu_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2edecodeNeu_lam0, 1, 0};
V g_heff_2evalue_2edecodeNeu_lam1(V self, V *args);
V g_heff_2evalue_2edecodeNeu_lam2(V self, V *args);
V g_heff_2evalue_2edecodeNeu_lam3(V self, V *args);
Clo g_heff_2evalue_2edecodeNeu_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2edecodeNeu_entry, 7, 0};

V g_heff_2evalue_2edecodeNeu(V v_h_240, V v_sp_241, V v_ty_242, V v_expansion_243, V v_desc_244, V v_u_245, V v_decoded_246) {
top: ;
  switch (heff_tag_of(v_decoded_246)) {
  case TAG_Nothing: {
    return heff_tag(TAG_VDecode, 5, (V[]){heff_dup(v_h_240), heff_dup(v_sp_241), v_u_245, ((V)&g_heff_2evalue_2edecodeNeu_lam0_clo), heff_clo(g_heff_2evalue_2edecodeNeu_lam1, 1, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244})});
  }
  case TAG_Just: {
    V v_it1_249 = heff_field(v_decoded_246, 0);
    heff_take_n(v_decoded_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_Nom: {
      V v_dty_2410 = heff_field(v_it1_249, 0);
      heff_take_n(v_it1_249, 1ULL, 1);
      heff_drop(v_h_240);
      heff_drop(v_sp_241);
      heff_drop(v_ty_242);
      heff_drop(v_expansion_243);
      heff_drop(v_desc_244);
      heff_drop(v_u_245);
      return v_dty_2410;
    }
    case TAG_Describe: {
      V v_dty_2411 = heff_field(v_it1_249, 0);
      heff_take_n(v_it1_249, 1ULL, 1);
      return heff_tag(TAG_VDecode, 5, (V[]){heff_dup(v_h_240), heff_dup(v_sp_241), v_u_245, heff_clo(g_heff_2evalue_2edecodeNeu_lam2, 1, 1, (V[]){v_dty_2411}), heff_clo(g_heff_2evalue_2edecodeNeu_lam3, 1, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244})});
    }
    case TAG_Become: {
      V v_dty_2414 = heff_field(v_it1_249, 0);
      heff_take_n(v_it1_249, 1ULL, 1);
      heff_drop(v_h_240);
      heff_drop(v_sp_241);
      heff_drop(v_ty_242);
      heff_drop(v_expansion_243);
      heff_drop(v_desc_244);
      heff_drop(v_u_245);
      return v_dty_2414;
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  default: return heff_nomatch(v_decoded_246);
  }
}
V g_heff_2evalue_2edecodeNeu_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2edecodeNeu(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2evalue_2edecodeNeu_lam0(V self, V *args) {
  V v_x_247 = args[0];
  heff_drop(v_x_247);
  return NTAG(TAG_Nothing);
}
V g_heff_2evalue_2edecodeNeu_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_expansion_243 = heff_env(self)[3];
  V v_desc_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_248);
  return heff_tag(TAG_VNeu, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244});
}
V g_heff_2evalue_2edecodeNeu_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2412);
  return heff_tag(TAG_Just, 1, (V[]){v_dty_2411});
}
V g_heff_2evalue_2edecodeNeu_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_expansion_243 = heff_env(self)[3];
  V v_desc_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  return heff_tag(TAG_VNeu, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244});
}
Clo g_heff_2evalue_2edecodeN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2edecodeN_entry, 1, 0};

V g_heff_2evalue_2edecodeN(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VNeu: {
    V v_h_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ty_243 = heff_field(v_x1_240, 2);
    V v_expansion_244 = heff_field(v_x1_240, 3);
    V v_desc_245 = heff_field(v_x1_240, 4);
    V v_x1_246 = heff_tr(heff_apply(heff_dup(v_ty_243), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2423;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_VU: {
      V v_u_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_t_2423 = v_u_247;
      break;
    }
    case TAG_VDecode: {
      heff_take_n(v_x1_246, 0ULL, 5);
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_VFunction: {
      heff_take_n(v_x1_246, 0ULL, 4);
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_VRecord: {
      heff_take_n(v_x1_246, 0ULL, 4);
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_VSum: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_VPrimInt: {
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_VPrimString: {
      v_t_2423 = heff_abandon();
      break;
    }
    case TAG_VPrimArray: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_t_2423 = heff_abandon();
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_x2_2424 = heff_tr(heff_apply(heff_dup(v_desc_245), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2436;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_ru_24x2_2424_24Just = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
      V v_t_2435;
      switch (heff_tag_of(v_x_2425)) {
      case TAG_VNeu: {
        heff_take_n(v_x_2425, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_2424_24Just, 1);
        v_t_2435 = heff_abandon();
        break;
      }
      case TAG_VCode: {
        V v_a_2431 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2435 = heff_tag_at(v_ru_24x2_2424_24Just, TAG_Describe, 1, (V[]){v_a_2431});
        break;
      }
      case TAG_VLam: {
        heff_take_n(v_x_2425, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_2424_24Just, 1);
        v_t_2435 = heff_abandon();
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x_2425, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2424_24Just, 1);
        v_t_2435 = heff_abandon();
        break;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x2_2424_24Just, 1);
        v_t_2435 = heff_abandon();
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      v_t_2436 = heff_tag(TAG_Just, 1, (V[]){v_t_2435});
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    return (g_heff_2evalue_2edecodeNeu(heff_dup(v_h_241), heff_dup(v_sp_242), heff_dup(v_ty_243), heff_dup(v_expansion_244), heff_dup(v_desc_245), v_t_2423, v_t_2436));
  }
  case TAG_VCode: {
    V v_a_2437 = heff_field(v_x1_240, 0);
    return heff_dup(v_a_2437);
  }
  case TAG_VLam: {
    return heff_abandon();
  }
  case TAG_VCons: {
    return heff_abandon();
  }
  case TAG_VOpaque: {
    return heff_abandon();
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2evalue_2edecodeN_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2evalue_2edecodeN(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2evalue_2eneuAppTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eneuAppTy_entry, 3, 0};

V g_heff_2evalue_2eneuAppTy(V v_h_240, V v_t_241, V v_arg_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_HLocal: {
    V v_t_244 = (g_heff_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_244)) {
    case TAG_LikeU: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFunction: {
      V v_cod_248 = heff_field(v_t_244, 2);
      heff_take_n(v_t_244, 4ULL, 4);
      V v_x1_2414;
      switch (heff_tag_of(v_cod_248)) {
      case TAG_MkClo: {
        V v_vs_2411 = heff_field(v_cod_248, 1);
        V v_body_2412 = heff_field(v_cod_248, 2);
        heff_take_n(v_cod_248, 6ULL, 3);
        v_x1_2414 = heff_tr(heff_apply(v_body_2412, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2411, v_arg_242})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2413 = heff_field(v_cod_248, 0);
        heff_take_n(v_cod_248, 1ULL, 1);
        heff_drop(v_arg_242);
        v_x1_2414 = v_body_2413;
        break;
      }
      default: heff_nomatch(v_cod_248);
      }
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nom: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        return v_x_2415;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        return heff_abandon();
      }
      case TAG_Become: {
        V v_x_2417 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        return v_x_2417;
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_244, 0ULL, 3);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_HGlobal: {
    V v_t_2424 = (g_heff_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2424, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFunction: {
      V v_cod_2428 = heff_field(v_t_2424, 2);
      heff_take_n(v_t_2424, 4ULL, 4);
      V v_x1_2434;
      switch (heff_tag_of(v_cod_2428)) {
      case TAG_MkClo: {
        V v_vs_2431 = heff_field(v_cod_2428, 1);
        V v_body_2432 = heff_field(v_cod_2428, 2);
        heff_take_n(v_cod_2428, 6ULL, 3);
        v_x1_2434 = heff_tr(heff_apply(v_body_2432, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2431, v_arg_242})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2433 = heff_field(v_cod_2428, 0);
        heff_take_n(v_cod_2428, 1ULL, 1);
        heff_drop(v_arg_242);
        v_x1_2434 = v_body_2433;
        break;
      }
      default: heff_nomatch(v_cod_2428);
      }
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_Nom: {
        V v_x_2435 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        return v_x_2435;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2434, 0ULL, 1);
        return heff_abandon();
      }
      case TAG_Become: {
        V v_x_2437 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        return v_x_2437;
      }
      default: return heff_nomatch(v_x1_2434);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2424, 0ULL, 3);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2424, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2424, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  case TAG_HMeta: {
    V v_t_2444 = (g_heff_2evalue_2ebehavior(heff_dup(v_t_241)));
    switch (heff_tag_of(v_t_2444)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2444, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2444, 0ULL, 4);
      V v_t_2450 = (g_heff_2evalue_2ebehavior(v_t_241));
      switch (heff_tag_of(v_t_2450)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2450, 0ULL, 1);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeFunction: {
        V v_cod_2454 = heff_field(v_t_2450, 2);
        heff_take_n(v_t_2450, 4ULL, 4);
        V v_x1_2460;
        switch (heff_tag_of(v_cod_2454)) {
        case TAG_MkClo: {
          V v_vs_2457 = heff_field(v_cod_2454, 1);
          V v_body_2458 = heff_field(v_cod_2454, 2);
          heff_take_n(v_cod_2454, 6ULL, 3);
          v_x1_2460 = heff_tr(heff_apply(v_body_2458, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2457, v_arg_242})}));
          break;
        }
        case TAG_CloConst: {
          V v_body_2459 = heff_field(v_cod_2454, 0);
          heff_take_n(v_cod_2454, 1ULL, 1);
          heff_drop(v_arg_242);
          v_x1_2460 = v_body_2459;
          break;
        }
        default: heff_nomatch(v_cod_2454);
        }
        switch (heff_tag_of(v_x1_2460)) {
        case TAG_Nom: {
          V v_x_2461 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          return v_x_2461;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2460, 0ULL, 1);
          return heff_abandon();
        }
        case TAG_Become: {
          V v_x_2463 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          return v_x_2463;
        }
        default: return heff_nomatch(v_x1_2460);
        }
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2450, 0ULL, 3);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2450, 0ULL, 1);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeInt: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeFloat: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeString: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2450, 0ULL, 1);
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      case TAG_NoRules: {
        heff_drop(v_arg_242);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2450);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2444, 0ULL, 3);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2444, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2444, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  case TAG_HError: {
    V v_t_2474 = (g_heff_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_2474)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2474, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFunction: {
      V v_cod_2478 = heff_field(v_t_2474, 2);
      heff_take_n(v_t_2474, 4ULL, 4);
      V v_x1_2484;
      switch (heff_tag_of(v_cod_2478)) {
      case TAG_MkClo: {
        V v_vs_2481 = heff_field(v_cod_2478, 1);
        V v_body_2482 = heff_field(v_cod_2478, 2);
        heff_take_n(v_cod_2478, 6ULL, 3);
        v_x1_2484 = heff_tr(heff_apply(v_body_2482, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2481, v_arg_242})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2483 = heff_field(v_cod_2478, 0);
        heff_take_n(v_cod_2478, 1ULL, 1);
        heff_drop(v_arg_242);
        v_x1_2484 = v_body_2483;
        break;
      }
      default: heff_nomatch(v_cod_2478);
      }
      switch (heff_tag_of(v_x1_2484)) {
      case TAG_Nom: {
        V v_x_2485 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        return v_x_2485;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2484, 0ULL, 1);
        return heff_abandon();
      }
      case TAG_Become: {
        V v_x_2487 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        return v_x_2487;
      }
      default: return heff_nomatch(v_x1_2484);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2474, 0ULL, 3);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2474, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2474, 0ULL, 1);
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_2474);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2evalue_2eneuAppTy_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2evalue_2eneuAppTy(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2evalue_2eapp_lam0(V self, V *args);
V g_heff_2evalue_2eapp_lam1(V self, V *args);
Clo g_heff_2evalue_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eapp_entry, 2, 0};

V g_heff_2evalue_2eapp(V v_f_240, V v_arg_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_f_240, 0);
    V v_sp_243 = heff_field(v_f_240, 1);
    V v_ty_244 = heff_field(v_f_240, 2);
    V v_desc_246 = heff_field(v_f_240, 4);
    heff_take_n(v_f_240, 23ULL, 5);
    V v_x2_247 = heff_tr(heff_apply(v_desc_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_edesc_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_edesc_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_ru_24x2_247_24Just = heff_take_reuse_n(v_x2_247, 1ULL, 1);
      v_edesc_249 = heff_tag_at(v_ru_24x2_247_24Just, TAG_Just, 1, (V[]){heff_tr(g_heff_2evalue_2eapp(v_x_248, heff_dup(v_arg_241)))});
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2420;
    switch (heff_tag_of(v_edesc_249)) {
    case TAG_Nothing: {
      V v_t_2410 = heff_tr(heff_apply(heff_dup(v_arg_241), 1, (V[]){NTAG(TAG_MkUnit)}));
      v_t_2420 = (g_heff_2evalue_2emkNeu_24s10(heff_dup(v_h_242), heff_tag(TAG_SpApp, 2, (V[]){v_sp_243, v_t_2410}), heff_clo(g_heff_2evalue_2eapp_lam0, 1, 3, (V[]){v_ty_244, v_h_242, v_arg_241}), NTAG(TAG_Nothing)));
      break;
    }
    case TAG_Just: {
      V v_it1_2413 = heff_field(v_edesc_249, 0);
      V v_ru_24edesc_249_24Just = heff_take_reuse_n(v_edesc_249, 1ULL, 1);
      switch (heff_tag_of(v_it1_2413)) {
      case TAG_Nom: {
        V v_v_2414 = heff_field(v_it1_2413, 0);
        heff_take_n(v_it1_2413, 1ULL, 1);
        heff_drop(v_arg_241);
        heff_drop(v_h_242);
        heff_drop(v_sp_243);
        heff_drop(v_ty_244);
        heff_drop_cell(v_ru_24edesc_249_24Just, 1);
        v_t_2420 = v_v_2414;
        break;
      }
      case TAG_Describe: {
        V v_desc_2415 = heff_field(v_it1_2413, 0);
        heff_take_n(v_it1_2413, 1ULL, 1);
        V v_t_2416 = heff_tr(heff_apply(heff_dup(v_arg_241), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_t_2420 = (g_heff_2evalue_2emkNeu_24s10(heff_dup(v_h_242), heff_tag(TAG_SpApp, 2, (V[]){v_sp_243, v_t_2416}), heff_clo(g_heff_2evalue_2eapp_lam1, 1, 3, (V[]){v_ty_244, v_h_242, v_arg_241}), heff_tag_at(v_ru_24edesc_249_24Just, TAG_Just, 1, (V[]){v_desc_2415})));
        break;
      }
      case TAG_Become: {
        V v_v_2419 = heff_field(v_it1_2413, 0);
        heff_take_n(v_it1_2413, 1ULL, 1);
        heff_drop(v_arg_241);
        heff_drop(v_h_242);
        heff_drop(v_sp_243);
        heff_drop(v_ty_244);
        heff_drop_cell(v_ru_24edesc_249_24Just, 1);
        v_t_2420 = v_v_2419;
        break;
      }
      default: heff_nomatch(v_it1_2413);
      }
      break;
    }
    default: heff_nomatch(v_edesc_249);
    }
    return heff_tag(TAG_Nom, 1, (V[]){v_t_2420});
  }
  case TAG_VCode: {
    heff_take_n(v_f_240, 0ULL, 1);
    heff_drop(v_arg_241);
    return heff_abandon();
  }
  case TAG_VLam: {
    V v_clo_2423 = heff_field(v_f_240, 1);
    heff_take_n(v_f_240, 2ULL, 2);
    switch (heff_tag_of(v_clo_2423)) {
    case TAG_MkClo: {
      V v_vs_2425 = heff_field(v_clo_2423, 1);
      V v_body_2426 = heff_field(v_clo_2423, 2);
      heff_take_n(v_clo_2423, 6ULL, 3);
      return heff_tail(v_body_2426, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2425, v_arg_241})});
    }
    case TAG_CloConst: {
      V v_body_2427 = heff_field(v_clo_2423, 0);
      heff_take_n(v_clo_2423, 1ULL, 1);
      heff_drop(v_arg_241);
      return v_body_2427;
    }
    default: return heff_nomatch(v_clo_2423);
    }
  }
  case TAG_VCons: {
    heff_take_n(v_f_240, 0ULL, 1);
    heff_drop(v_arg_241);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop(v_arg_241);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2evalue_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2eapp(a[0], a[1]);
}
V g_heff_2evalue_2eapp_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_arg_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2411);
  V v_t_2412 = heff_tr(heff_apply(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2412; V a_2 = v_arg_241; V r_ = (g_heff_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2evalue_2eapp_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_arg_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2417);
  V v_t_2418 = heff_tr(heff_apply(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2418; V a_2 = v_arg_241; V r_ = (g_heff_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2evalue_2eaddSpecialization_lam0(V self, V *args);
Clo g_heff_2evalue_2eaddSpecialization_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eaddSpecialization_entry, 6, 0};

V g_heff_2evalue_2eaddSpecialization(V v_level_240, V v_capture_241, V v_fieldTypes_242, V v_defaults_243, V v_x_244, V v_v_245) {
top: ;
  V v_t_246 = ({ V a_0 = v_x_244; V b_1 = heff_get(heff_dup(v_fieldTypes_242), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2414;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_v_245);
    v_t_2414 = v_fieldTypes_242;
    break;
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_field_248 = heff_arrayIndex(heff_get(heff_dup(v_fieldTypes_242), LBL_values), heff_dup(v_i_247));
    V v_t_2413 = heff_arraySet(heff_get(heff_dup(v_fieldTypes_242), LBL_values), v_i_247, heff_clo(g_heff_2evalue_2eaddSpecialization_lam0, 1, 2, (V[]){v_field_248, v_v_245}));
    v_t_2414 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_242), LBL_keys), heff_get(v_fieldTypes_242, LBL_byName), v_t_2413});
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_tag(TAG_VRecord, 4, (V[]){v_level_240, v_capture_241, v_t_2414, v_defaults_243});
}
V g_heff_2evalue_2eaddSpecialization_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2eaddSpecialization(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2evalue_2eaddSpecialization_lam0(V self, V *args) {
  V v_vs_249 = args[0];
  V v_field_248 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tr(heff_apply(v_field_248, 1, (V[]){v_vs_249}));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_MkField: {
    V v_ty_2411 = heff_field(v_t_2410, 0);
    V v_ru_24t_2410_24MkField = heff_take_reuse_n(v_t_2410, 1ULL, 2);
    return heff_tag_at(v_ru_24t_2410_24MkField, TAG_MkField, 2, (V[]){v_ty_2411, heff_tag(TAG_Just, 1, (V[]){v_v_245})});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2evalue_2especialize_lam0(V self, V *args);
Clo g_heff_2evalue_2especialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2especialize_entry, 3, 0};

V g_heff_2evalue_2especialize(V v_v_240, V v_x_241, V v_f_242) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_v_240, 0);
    V v_sp_244 = heff_field(v_v_240, 1);
    V v_ty_245 = heff_field(v_v_240, 2);
    V v_expansion_246 = heff_field(v_v_240, 3);
    V v_desc_247 = heff_field(v_v_240, 4);
    V v_ru_24v_240_24VNeu = heff_take_reuse_n(v_v_240, 31ULL, 5);
    V v_it_248 = heff_tr(heff_apply(v_desc_247, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_it_248)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      heff_drop(v_f_242);
      heff_drop(v_h_243);
      heff_drop(v_sp_244);
      heff_drop(v_ty_245);
      heff_drop(v_expansion_246);
      heff_drop_cell(v_ru_24v_240_24VNeu, 5);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_it1_249 = heff_field(v_it_248, 0);
      heff_take_n(v_it_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_VNeu: {
        heff_take_n(v_it1_249, 0ULL, 5);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_it11_2415 = heff_field(v_it1_249, 0);
        heff_take_n(v_it1_249, 1ULL, 1);
        switch (heff_tag_of(v_it11_2415)) {
        case TAG_VU: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VDecode: {
          heff_take_n(v_it11_2415, 0ULL, 5);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VFunction: {
          heff_take_n(v_it11_2415, 0ULL, 4);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VRecord: {
          V v_level_2426 = heff_field(v_it11_2415, 0);
          V v_capture_2427 = heff_field(v_it11_2415, 1);
          V v_fieldTypes_2428 = heff_field(v_it11_2415, 2);
          V v_defaults_2429 = heff_field(v_it11_2415, 3);
          heff_take_n(v_it11_2415, 15ULL, 4);
          return heff_tag_at(v_ru_24v_240_24VNeu, TAG_VNeu, 5, (V[]){v_h_243, heff_tag(TAG_SpSpec, 3, (V[]){v_sp_244, heff_dup(v_x_241), heff_dup(v_f_242)}), v_ty_245, v_expansion_246, heff_clo(g_heff_2evalue_2especialize_lam0, 1, 6, (V[]){v_level_2426, v_capture_2427, v_fieldTypes_2428, v_defaults_2429, v_x_241, v_f_242})});
        }
        case TAG_VSum: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimInt: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimFloat: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimString: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimArray: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_it11_2415);
        }
      }
      case TAG_VLam: {
        heff_take_n(v_it1_249, 0ULL, 2);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_it1_249, 0ULL, 1);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      default: return heff_nomatch(v_it1_249);
      }
    }
    default: return heff_nomatch(v_it_248);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_v_240, 0ULL, 1);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VLam: {
    heff_take_n(v_v_240, 0ULL, 2);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VCons: {
    heff_take_n(v_v_240, 0ULL, 1);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2evalue_2especialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2especialize(a[0], a[1], a[2]);
}
V g_heff_2evalue_2especialize_lam0(V self, V *args) {
  V v_u_2430 = args[0];
  V v_level_2426 = heff_env(self)[0];
  V v_capture_2427 = heff_env(self)[1];
  V v_fieldTypes_2428 = heff_env(self)[2];
  V v_defaults_2429 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_f_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2430);
  V v_t_2431 = heff_tag(TAG_VCode, 1, (V[]){(g_heff_2evalue_2eaddSpecialization(v_level_2426, v_capture_2427, v_fieldTypes_2428, v_defaults_2429, v_x_241, v_f_242))});
  return heff_tag(TAG_Just, 1, (V[]){v_t_2431});
}
Clo g_heff_2evalue_2edefaultsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2edefaultsOf_entry, 1, 0};

V g_heff_2evalue_2edefaultsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2edict_2eempty_get());
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_apply(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return heff_dup(g_heff_2edict_2eempty_get());
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return heff_dup(g_heff_2edict_2eempty_get());
  }
  case TAG_VRecord: {
    V v_defaults_2416 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_defaults_2416;
  }
  case TAG_VSum: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2edict_2eempty_get());
  }
  case TAG_VPrimInt: {
    return heff_dup(g_heff_2edict_2eempty_get());
  }
  case TAG_VPrimFloat: {
    return heff_dup(g_heff_2edict_2eempty_get());
  }
  case TAG_VPrimString: {
    return heff_dup(g_heff_2edict_2eempty_get());
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2edict_2eempty_get());
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2evalue_2edefaultsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2edefaultsOf(a[0]);
}
V g_heff_2evalue_2ereplay_lam0(V self, V *args);
Clo g_heff_2evalue_2ereplay_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2ereplay_entry, 2, 0};

V g_heff_2evalue_2ereplay(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    return v_v_240;
  }
  case TAG_SpApp: {
    V v_sp_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2evalue_2ereplay(v_v_240, v_sp_242));
    V v_x1_246 = heff_tr(g_heff_2evalue_2eapp(v_t_244, heff_clo(g_heff_2evalue_2ereplay_lam0, 1, 1, (V[]){heff_dup(v_a_243)})));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return v_x_247;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_246, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_249 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return v_x_249;
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_SpProj: {
    V v_sp_2410 = heff_field(v_x2_241, 0);
    V v_l_2411 = heff_field(v_x2_241, 1);
    V v_t_2412 = (g_heff_2evalue_2ereplay(v_v_240, v_sp_2410));
    V v_x1_2413 = (g_heff_2evalue_2eproj(v_t_2412, heff_dup(v_l_2411)));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nom: {
      V v_x_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      return v_x_2414;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2413, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_2416 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      return v_x_2416;
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  case TAG_SpSpec: {
    V v_sp_2417 = heff_field(v_x2_241, 0);
    V v_l_2418 = heff_field(v_x2_241, 1);
    V v_f_2419 = heff_field(v_x2_241, 2);
    V v_t_2420 = (g_heff_2evalue_2ereplay(v_v_240, v_sp_2417));
    return (g_heff_2evalue_2especialize(v_t_2420, heff_dup(v_l_2418), heff_dup(v_f_2419)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2evalue_2ereplay_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2evalue_2ereplay(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2evalue_2ereplay_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_245);
  return v_a_243;
}
Clo g_heff_2evalue_2eforceEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eforceEl_entry, 2, 0};

V g_heff_2evalue_2eforceEl(V v_mc_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VNeu: {
    V v_it1_242 = heff_dup(heff_field(v_v_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_v_241, 1));
    switch (heff_tag_of(v_it1_242)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return v_v_241;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return v_v_241;
    }
    case TAG_HMeta: {
      V v_m_249 = heff_field(v_it1_242, 0);
      heff_take_n(v_it1_242, 1ULL, 1);
      V v_t_2410 = (g_map_2elookup_24s12(v_m_249, v_mc_240));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_sp_243);
        return v_v_241;
      }
      case TAG_Just: {
        V v_e_2411 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        V v_t_2412 = heff_get(v_e_2411, LBL_sol);
        switch (heff_tag_of(v_t_2412)) {
        case TAG_Nothing: {
          heff_drop(v_sp_243);
          return v_v_241;
        }
        case TAG_Just: {
          V v_sol_2413 = heff_field(v_t_2412, 0);
          heff_take_n(v_t_2412, 1ULL, 1);
          heff_drop_tag(v_v_241, 5);
          V v_t_2414 = ({ V a_0 = v_sol_2413; V a_1 = v_sp_243; V r_ = (g_heff_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_243); r_; });
          V t_0 = v_mc_240;
          V t_1 = v_t_2414;
          v_mc_240 = t_0;
          v_v_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_HError: {
      heff_drop(v_sp_243);
      return v_v_241;
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  case TAG_VCode: {
    return v_v_241;
  }
  case TAG_VLam: {
    return v_v_241;
  }
  case TAG_VCons: {
    return v_v_241;
  }
  case TAG_VOpaque: {
    return v_v_241;
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2evalue_2eforceEl_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2evalue_2eforceEl(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2evalue_2eforceTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eforceTy_entry, 2, 0};

V g_heff_2evalue_2eforceTy(V v_mc_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    return v_t_241;
  }
  case TAG_VDecode: {
    V v_it1_243 = heff_dup(heff_field(v_t_241, 0));
    V v_sp_244 = heff_dup(heff_field(v_t_241, 1));
    switch (heff_tag_of(v_it1_243)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      return v_t_241;
    }
    case TAG_HGlobal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      return v_t_241;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      V v_t_2411 = (g_map_2elookup_24s12(v_m_2410, v_mc_240));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_sp_244);
        return v_t_241;
      }
      case TAG_Just: {
        V v_e_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        V v_t_2413 = heff_get(v_e_2412, LBL_sol);
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Nothing: {
          heff_drop(v_sp_244);
          return v_t_241;
        }
        case TAG_Just: {
          V v_sol_2414 = heff_field(v_t_2413, 0);
          heff_take_n(v_t_2413, 1ULL, 1);
          heff_drop_tag(v_t_241, 5);
          V v_t_2415 = ({ V a_0 = v_sol_2414; V a_1 = v_sp_244; V r_ = (g_heff_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
          V v_t_2416 = (g_heff_2evalue_2eforceEl(v_mc_240, v_t_2415));
          V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_t_2416); r_; });
          V t_0 = v_mc_240;
          V t_1 = v_t_2417;
          v_mc_240 = t_0;
          v_t_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_HError: {
      heff_drop(v_sp_244);
      return v_t_241;
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  case TAG_VFunction: {
    return v_t_241;
  }
  case TAG_VRecord: {
    return v_t_241;
  }
  case TAG_VSum: {
    return v_t_241;
  }
  case TAG_VPrimInt: {
    return v_t_241;
  }
  case TAG_VPrimFloat: {
    return v_t_241;
  }
  case TAG_VPrimString: {
    return v_t_241;
  }
  case TAG_VPrimArray: {
    return v_t_241;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2evalue_2eforceTy_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2evalue_2eforceTy(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2evalue_2etypeForProjection_lam0(V self, V *args);
Clo g_heff_2evalue_2etypeForProjection_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2etypeForProjection_entry, 4, 0};

V g_heff_2evalue_2etypeForProjection(V v_capture_240, V v_fieldTypes_241, V v_x_242, V v_fields_243) {
top: ;
  V v_t_244 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_fieldTypes_241), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_i_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_i_246 = heff_abandon();
    break;
  }
  case TAG_Just: {
    V v_i_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_i_246 = v_i_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_247 = heff_arrayIndex(heff_get(heff_dup(v_fieldTypes_241), LBL_values), v_i_246);
  V v_t_248 = ({ V a_0 = v_x_242; V b_1 = heff_get(v_fieldTypes_241, LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2410;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    v_t_2410 = heff_abandon();
    break;
  }
  case TAG_Just: {
    V v_i_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    v_t_2410 = v_i_249;
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2412 = heff_arrayGenerate(v_t_2410, heff_clo(g_heff_2evalue_2etypeForProjection_lam0, 1, 1, (V[]){v_fields_243}));
  return heff_tail(v_t_247, 1, (V[]){heff_tag(TAG_LChunkSnoc, 2, (V[]){v_capture_240, v_t_2412})});
}
V g_heff_2evalue_2etypeForProjection_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2etypeForProjection(a[0], a[1], a[2], a[3]);
}
V g_heff_2evalue_2etypeForProjection_lam0(V self, V *args) {
  V v_j_2411 = args[0];
  V v_fields_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_arrayIndex(heff_get(v_fields_243, LBL_values), v_j_2411);
}
V g_heff_2evalue_2eprojTyWith_lam0(V self, V *args);
Clo g_heff_2evalue_2eprojTyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2eprojTyWith_entry, 3, 0};

V g_heff_2evalue_2eprojTyWith(V v_t_240, V v_mf_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2evalue_2ebehavior(v_t_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_LikeU: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_243, 0ULL, 4);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeRecord: {
    V v_capture_2410 = heff_field(v_t_243, 1);
    V v_fieldTypes_2411 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    switch (heff_tag_of(v_mf_241)) {
    case TAG_Nothing: {
      heff_drop(v_x_242);
      heff_drop(v_capture_2410);
      heff_drop(v_fieldTypes_2411);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_fields_2412 = heff_field(v_mf_241, 0);
      V v_ru_24mf_241_24Just = heff_take_reuse_n(v_mf_241, 1ULL, 1);
      V v_xs_2413 = heff_get(heff_dup(v_fields_2412), LBL_values);
      V v_t_2419 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2413)), heff_clo(g_heff_2evalue_2eprojTyWith_lam0, 1, 1, (V[]){v_xs_2413}));
      V v_t_2420 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fields_2412), LBL_keys), heff_get(v_fields_2412, LBL_byName), v_t_2419});
      V v_x1_2421 = heff_tr(g_heff_2evalue_2etypeForProjection(v_capture_2410, v_fieldTypes_2411, v_x_242, v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_MkField: {
        V v_ty_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 2);
        v_t_2424 = v_ty_2422;
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      return heff_tag_at(v_ru_24mf_241_24Just, TAG_Just, 1, (V[]){v_t_2424});
    }
    default: return heff_nomatch(v_mf_241);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeInt: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeFloat: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeString: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_NoRules: {
    heff_drop(v_mf_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2evalue_2eprojTyWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2eprojTyWith(a[0], a[1], a[2]);
}
V g_heff_2evalue_2eprojTyWith_lam0(V self, V *args) {
  V v_i_2414 = args[0];
  V v_xs_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2415 = heff_arrayIndex(v_xs_2413, v_i_2414);
  switch (heff_tag_of(v_e_2415)) {
  case TAG_Nom: {
    V v_x_2416 = heff_field(v_e_2415, 0);
    heff_take_n(v_e_2415, 1ULL, 1);
    return v_x_2416;
  }
  case TAG_Describe: {
    heff_take_n(v_e_2415, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2418 = heff_field(v_e_2415, 0);
    heff_take_n(v_e_2415, 1ULL, 1);
    return v_x_2418;
  }
  default: return heff_nomatch(v_e_2415);
  }
}
V g_heff_2evalue_2emkNeu_24s10_24s425_lam0(V self, V *args); static Clo g_heff_2evalue_2emkNeu_24s10_24s425_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2emkNeu_24s10_24s425_lam0, 1, 0};
V g_heff_2evalue_2emkNeu_24s10_24s425_lam1(V self, V *args);
V g_heff_2evalue_2emkNeu_24s10_24s425_lam2(V self, V *args);
Clo g_heff_2evalue_2emkNeu_24s10_24s425_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2emkNeu_24s10_24s425_entry, 3, 0};

V g_heff_2evalue_2emkNeu_24s10_24s425(V v_h_240, V v_spine_241, V v_desc_242) {
top: ;
  return heff_tag(TAG_VNeu, 5, (V[]){heff_dup(v_h_240), heff_dup(v_spine_241), ((V)&g_heff_2evalue_2emkNeu_24s10_24s425_lam0_clo), heff_clo(g_heff_2evalue_2emkNeu_24s10_24s425_lam1, 1, 3, (V[]){v_h_240, v_spine_241, heff_dup(v_desc_242)}), heff_clo(g_heff_2evalue_2emkNeu_24s10_24s425_lam2, 1, 1, (V[]){v_desc_242})});
}
V g_heff_2evalue_2emkNeu_24s10_24s425_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2emkNeu_24s10_24s425(a[0], a[1], a[2]);
}
V g_heff_2evalue_2emkNeu_24s10_24s425_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  return heff_tag(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
}
V g_heff_2evalue_2emkNeu_24s10_24s425_lam1(V self, V *args) {
  V v_u_244 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_spine_241 = heff_env(self)[1];
  V v_desc_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  V v_t_245 = heff_tag(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
  V v_t_246 = (g_heff_2evalue_2ebehavior(v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_LikeU: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_246, 0ULL, 4);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRecord: {
    V v_capture_2413 = heff_field(v_t_246, 1);
    V v_fieldTypes_2414 = heff_field(v_t_246, 2);
    heff_take_n(v_t_246, 6ULL, 3);
    V v_t_2415 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2414), LBL_keys));
    V v_t_2416 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2414), LBL_values));
    V v_t_2417 = (g_heff_2edict_2ezipKV(v_t_2415, v_t_2416));
    V v_xs_2418 = (g_heff_2evalue_2egoER_24s11(v_capture_2413, v_h_240, v_spine_241, v_desc_242, v_t_2417, NTAG(TAG_Nil)));
    V v_t_2419 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_2414), LBL_keys), heff_get(v_fieldTypes_2414, LBL_byName), heff_arrayFromList(v_t_2419)});
    return heff_tag(TAG_IntoCons, 1, (V[]){v_t_2420});
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeInt: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFloat: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeString: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_NoRules: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_242);
    return NTAG(TAG_NotApplicable);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2evalue_2emkNeu_24s10_24s425_lam2(V self, V *args) {
  V v_u_2423 = args[0];
  V v_desc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return v_desc_242;
}
V g_heff_2evalue_2egoER_24s429_lam0(V self, V *args);
V g_heff_2evalue_2egoER_24s429_lam1(V self, V *args);
V g_heff_2evalue_2egoER_24s429_lam2(V self, V *args);
Clo g_heff_2evalue_2egoER_24s429_clo = {{0x80000000u, K_CLO, 0}, g_heff_2evalue_2egoER_24s429_entry, 6, 0};

V g_heff_2evalue_2egoER_24s429(V v_vs_240, V v_h_241, V v_sp_242, V v_desc_243, V v_x6_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_vs_240);
    heff_drop(v_h_241);
    heff_drop(v_sp_242);
    heff_drop(v_desc_243);
    return v_acc_245;
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_f_249 = heff_field(v_x61_246, 1);
      V v_ru_24x61_246_24MkPair = heff_take_reuse_n(v_x61_246, 3ULL, 2);
      V v_x6_2410 = heff_tr(heff_apply(v_f_249, 1, (V[]){heff_dup(v_vs_240)}));
      V v_v_2422;
      switch (heff_tag_of(v_x6_2410)) {
      case TAG_MkField: {
        V v_fty_2411 = heff_field(v_x6_2410, 0);
        V v_x62_2412 = heff_field(v_x6_2410, 1);
        heff_take_n(v_x6_2410, 3ULL, 2);
        switch (heff_tag_of(v_x62_2412)) {
        case TAG_Nothing: {
          V v_d2_2414;
          switch (heff_tag_of(v_desc_243)) {
          case TAG_Nothing: {
            v_d2_2414 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x_2413 = heff_dup(heff_field(v_desc_243, 0));
            v_d2_2414 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2evalue_2eproj(v_x_2413, heff_dup(v_x_248)))});
            break;
          }
          default: heff_nomatch(v_desc_243);
          }
          switch (heff_tag_of(v_d2_2414)) {
          case TAG_Nothing: {
            v_v_2422 = (g_heff_2evalue_2emkNeu_24s10(heff_dup(v_h_241), heff_tag_at(v_ru_24x6_244_24Cons, TAG_SpProj, 2, (V[]){heff_dup(v_sp_242), v_x_248}), heff_clo(g_heff_2evalue_2egoER_24s429_lam0, 1, 1, (V[]){v_fty_2411}), NTAG(TAG_Nothing)));
            break;
          }
          case TAG_Just: {
            V v_it1_2416 = heff_field(v_d2_2414, 0);
            V v_ru_24d2_2414_24Just = heff_take_reuse_n(v_d2_2414, 1ULL, 1);
            switch (heff_tag_of(v_it1_2416)) {
            case TAG_Nom: {
              V v_v_2417 = heff_field(v_it1_2416, 0);
              heff_take_n(v_it1_2416, 1ULL, 1);
              heff_drop_cell(v_ru_24x6_244_24Cons, 2);
              heff_drop(v_x_248);
              heff_drop(v_fty_2411);
              heff_drop_cell(v_ru_24d2_2414_24Just, 1);
              v_v_2422 = v_v_2417;
              break;
            }
            case TAG_Describe: {
              V v_desc_2418 = heff_field(v_it1_2416, 0);
              heff_take_n(v_it1_2416, 1ULL, 1);
              v_v_2422 = (g_heff_2evalue_2emkNeu_24s10(heff_dup(v_h_241), heff_tag_at(v_ru_24x6_244_24Cons, TAG_SpProj, 2, (V[]){heff_dup(v_sp_242), v_x_248}), heff_clo(g_heff_2evalue_2egoER_24s429_lam1, 1, 1, (V[]){v_fty_2411}), heff_tag_at(v_ru_24d2_2414_24Just, TAG_Just, 1, (V[]){v_desc_2418})));
              break;
            }
            case TAG_Become: {
              V v_v_2420 = heff_field(v_it1_2416, 0);
              heff_take_n(v_it1_2416, 1ULL, 1);
              heff_drop_cell(v_ru_24x6_244_24Cons, 2);
              heff_drop(v_x_248);
              heff_drop(v_fty_2411);
              heff_drop_cell(v_ru_24d2_2414_24Just, 1);
              v_v_2422 = v_v_2420;
              break;
            }
            default: heff_nomatch(v_it1_2416);
            }
            break;
          }
          default: heff_nomatch(v_d2_2414);
          }
          break;
        }
        case TAG_Just: {
          V v_v_2421 = heff_field(v_x62_2412, 0);
          heff_take_n(v_x62_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          heff_drop(v_x_248);
          heff_drop(v_fty_2411);
          v_v_2422 = v_v_2421;
          break;
        }
        default: heff_nomatch(v_x62_2412);
        }
        break;
      }
      default: heff_nomatch(v_x6_2410);
      }
      V t_0 = heff_tag_at(v_ru_24x61_246_24MkPair, TAG_LSnoc, 2, (V[]){v_vs_240, heff_clo(g_heff_2evalue_2egoER_24s429_lam2, 1, 1, (V[]){heff_dup(v_v_2422)})});
      V t_1 = v_h_241;
      V t_2 = v_sp_242;
      V t_3 = v_desc_243;
      V t_4 = v_rest_247;
      V t_5 = heff_tag(TAG_Cons, 2, (V[]){v_v_2422, v_acc_245});
      v_vs_240 = t_0;
      v_h_241 = t_1;
      v_sp_242 = t_2;
      v_desc_243 = t_3;
      v_x6_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2evalue_2egoER_24s429_entry(V self, V *a) {
  (void)self;
  return g_heff_2evalue_2egoER_24s429(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2evalue_2egoER_24s429_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_fty_2411;
}
V g_heff_2evalue_2egoER_24s429_lam1(V self, V *args) {
  V v_u_2419 = args[0];
  V v_fty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_fty_2411;
}
V g_heff_2evalue_2egoER_24s429_lam2(V self, V *args) {
  V v_u_2423 = args[0];
  V v_v_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return v_v_2422;
}