// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_MkArm 55352
#define LBL_m 327
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
HeffT2 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo;
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdMap_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2econdMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_24dps_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdRels(V);
V g_heff_2ecompile_2eir_2econdRels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdRels_clo;
V g_heff_2ecompile_2eir_2econdShaped(V);
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdShaped_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI_24dps(V, V);
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_24dps_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushArms_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V);
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2esubstGo_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24dps_clo;
V g_heff_2ecompile_2eir_2esurelyBool(V);
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esurelyBool_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str2, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str3, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str4, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str5, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str6, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str7, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str8, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str9, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str10, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str11, 7, "Float32");

HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str0), 2)) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtFloat)}});
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str1), 2)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtOther)}});
    } else {
      if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str2), 2)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtAny)}});
      } else {
        HeffT2 v_t_241 = (g_list_2efind_24s1896676244x1358329894_24cpr(((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str3), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str4), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str5), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str6), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str7), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str8), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str9), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str10), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str11), v_x_240, heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
        {
          V v_field_243 = v_t_241.f[1];
          int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
          if ((v_tag_242 == ((int64_t)0ULL))) {
            V v_x_244 = v_field_243;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_FtFixed, 1, (V[]){v_x_244})}});
          } else {
            heff_drop(v_field_243);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2eir_2econdMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdMap_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdMap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return NTAG(TAG_CTrue);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return NTAG(TAG_CFalse);
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_y_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CRel = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    V v_t_246 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_244}));
    return heff_tag_at_n(v_ru_24x2_241_24CRel, TAG_CRel, 3, (V[]){v_p_242, v_t_245, v_t_246});
  }
  case TAG_CTest: {
    V v_x_247 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CTest = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_248 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_247}));
    return heff_tag_at_n(v_ru_24x2_241_24CTest, TAG_CTest, 1, (V[]){v_t_248});
  }
  case TAG_CNot: {
    V v_c_249 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    V v_u_2411 = (g_heff_2ecompile_2eir_2econdMap_24dps(v_f_240, v_c_249, heff_dup(v_cell_2410), MK_INT(0LL)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_CIf: {
    V v_a_2412 = heff_field(v_x2_241, 0);
    V v_b_2413 = heff_field(v_x2_241, 1);
    V v_c_2414 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2415 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_a_2412));
    V v_t_2416 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_b_2413));
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24CIf, TAG_CIf, 3, (V[]){v_t_2415, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2eir_2econdMap_24dps(v_f_240, v_c_2414, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdMap(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2econdOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdOnto_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdOnto(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return v_rest_241;
  }
  case TAG_CFalse: {
    return v_rest_241;
  }
  case TAG_CRel: {
    V v_x_243 = heff_field(v_x1_240, 1);
    V v_y_244 = heff_field(v_x1_240, 2);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_244), v_rest_241})});
  }
  case TAG_CTest: {
    V v_x_245 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_rest_241});
  }
  case TAG_CNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    V t_0 = v_c_246;
    V t_1 = v_rest_241;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_b_248 = heff_field(v_x1_240, 1);
    V v_c_249 = heff_field(v_x1_240, 2);
    V v_t_2410 = (g_heff_2ecompile_2eir_2econdOnto(v_c_249, v_rest_241));
    V v_t_2411 = (g_heff_2ecompile_2eir_2econdOnto(v_b_248, v_t_2410));
    V t_0 = v_a_247;
    V t_1 = v_t_2411;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdOnto(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econdRels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdRels_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdRels(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_CFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_p_241), NTAG(TAG_Nil)});
  }
  case TAG_CTest: {
    return NTAG(TAG_Nil);
  }
  case TAG_CNot: {
    V v_c_245 = heff_field(v_x1_240, 0);
    V t_0 = v_c_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_CIf: {
    V v_a_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_c_248 = heff_field(v_x1_240, 2);
    V v_t_249 = (g_heff_2ecompile_2eir_2econdRels(v_a_246));
    V v_t_2410 = (g_heff_2ecompile_2eir_2econdRels(v_b_247));
    V v_t_2411 = (g_heff_2ecompile_2eir_2econdRels(v_c_248));
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return (g_prelude_2e_2b_2b(v_t_249, v_t_2412));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdRels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdRels(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2ebaseGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ebaseGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2ebaseGo(V v_x_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return v_x_240;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)) == ((int64_t)36ULL))) {
      return heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_i_241));
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ebaseGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2eappendI_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2enubI_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_24dps_entry, 2, 0};

V g_heff_2ecompile_2eir_2enubI_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI_24dps(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_e_27_248 = v_field_246;
      V v_n1_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n1_249, v_rest_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_es_2413 = v_field_2411;
        V v_n_2414 = v_field_2412;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e_27_248, v_es_2413}), v_n_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x41_243, 0);
      V v_e_246 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_246));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_e_27_2410 = v_field_248;
        V v_n1_2411 = v_field_249;
        HeffT2 v_t_2412 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(v_m_240, v_n1_2411, v_rest_244));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_fs_2415 = v_field_2413;
          V v_n_2416 = v_field_2414;
          V v_t_2417 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_e_27_2410}), v_fs_2415});
          return ((HeffT2){{v_t_2417, v_n_2416}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkArm: {
      V v_tag_245 = heff_field(v_x41_243, 0);
      V v_vars_246 = heff_field(v_x41_243, 1);
      V v_body_247 = heff_field(v_x41_243, 2);
      V v_ru_24x41_243_24MkArm = heff_take_reuse_n(v_x41_243, 7ULL, 3);
      V v_t_248 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(v_m_240), v_n_241, NTAG(TAG_Nil)});
      V v_v_249 = ({ V a_0 = v_t_248; V a_1 = v_vars_246; V r_ = (g_list_2efoldl_24s690313412x1307839513(a_0, a_1)); heff_drop(v_vars_246); r_; });
      V v_m_2410 = heff_take_field(v_v_249, 0);
      V v_n_2411 = heff_take_field(v_v_249, 1);
      V v_xs_2412 = heff_get_n(v_v_249, 2, 3);
      HeffT2 v_t_2413 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2410, v_n_2411, v_body_247));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_b_27_2416 = v_field_2414;
        V v_n1_2417 = v_field_2415;
        V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
        V v_a_2419 = heff_tag_at_n(v_ru_24x41_243_24MkArm, TAG_MkArm, 3, (V[]){v_tag_245, v_t_2418, v_b_27_2416});
        HeffT2 v_t_2420 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(v_m_240, v_n1_2417, v_rest_244));
        {
          V v_field_2421 = v_t_2420.f[0];
          V v_field_2422 = v_t_2420.f[1];
          V v_args_2423 = v_field_2421;
          V v_n_2424 = v_field_2422;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_a_2419, v_args_2423}), v_n_2424}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_m_240; V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_240); r_; });
    V v_t_248;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        V v_y_247 = v_field_246;
        v_t_248 = v_y_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = v_x_243;
      }
    }
    V v_f_249 = heff_tag_at_n(v_ru_24e_242_24EVar, TAG_EVar, 1, (V[]){v_t_248});
    return ((HeffT2){{v_f_249, v_n_241}});
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_ELam: {
    V v_xs_2411 = heff_field(v_e_242, 0);
    V v_b_2412 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2413 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n_241, NTAG(TAG_Nil)});
    V v_v_2414 = ({ V a_0 = v_t_2413; V a_1 = v_xs_2411; V r_ = (g_list_2efoldl_24s690313412x1307839513(a_0, a_1)); heff_drop(v_xs_2411); r_; });
    V v_m_2415 = heff_take_field(v_v_2414, 0);
    V v_n_2416 = heff_take_field(v_v_2414, 1);
    V v_xs_2417 = heff_get_n(v_v_2414, 2, 3);
    HeffT2 v_t_2418 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2415, v_n_2416, v_b_2412));
    {
      V v_field_2419 = v_t_2418.f[0];
      V v_field_2420 = v_t_2418.f[1];
      V v_b_27_2421 = v_field_2419;
      V v_n_27_2422 = v_field_2420;
      V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
      V v_f_2424 = heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_t_2423, v_b_27_2421});
      return ((HeffT2){{v_f_2424, v_n_27_2422}});
    }
  }
  case TAG_EApp: {
    V v_f_2425 = heff_field(v_e_242, 0);
    V v_args_2426 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2427 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_f_2425));
    {
      V v_field_2428 = v_t_2427.f[0];
      V v_field_2429 = v_t_2427.f[1];
      V v_f_27_2430 = v_field_2428;
      V v_n1_2431 = v_field_2429;
      HeffT2 v_t_2432 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n1_2431, v_args_2426));
      {
        V v_field_2433 = v_t_2432.f[0];
        V v_field_2434 = v_t_2432.f[1];
        V v_args_27_2435 = v_field_2433;
        V v_n2_2436 = v_field_2434;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_f_27_2430, v_args_27_2435}), v_n2_2436}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2437 = heff_field(v_e_242, 0);
    V v_a_2438 = heff_field(v_e_242, 1);
    V v_b_2439 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2440 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_a_2438));
    {
      V v_field_2441 = v_t_2440.f[0];
      V v_field_2442 = v_t_2440.f[1];
      V v_a_27_2443 = v_field_2441;
      V v_n1_2444 = v_field_2442;
      V v_base_2445 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2437), MK_INT(0LL)));
      V v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr_str0), heff_intShow(heff_dup(v_n1_2444)));
      V v_x_27_2447 = heff_strAppend(v_base_2445, v_t_2446);
      V v_m_2448 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_x_2437, heff_dup(v_x_27_2447)));
      HeffT2 v_t_2449 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2448, heff_intAdd(v_n1_2444, MK_INT(1LL)), v_b_2439));
      {
        V v_field_2450 = v_t_2449.f[0];
        V v_field_2451 = v_t_2449.f[1];
        V v_b_27_2452 = v_field_2450;
        V v_n3_2453 = v_field_2451;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_27_2447, v_a_27_2443, v_b_27_2452}), v_n3_2453}});
      }
    }
  }
  case TAG_ERecord: {
    V v_fs_2454 = heff_field(v_e_242, 0);
    V v_ts_2455 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2456 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(v_m_240, v_n_241, v_fs_2454));
    {
      V v_field_2457 = v_t_2456.f[0];
      V v_field_2458 = v_t_2456.f[1];
      V v_fs_27_2459 = v_field_2457;
      V v_n1_2460 = v_field_2458;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_fs_27_2459, v_ts_2455}), v_n1_2460}});
    }
  }
  case TAG_EProj: {
    V v_e2_2461 = heff_field(v_e_242, 0);
    V v_l_2462 = heff_field(v_e_242, 1);
    V v_sh_2463 = heff_field(v_e_242, 2);
    V v_t_2464 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    HeffT2 v_t_2465 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_e2_2461));
    {
      V v_field_2466 = v_t_2465.f[0];
      V v_field_2467 = v_t_2465.f[1];
      V v_e_27_2468 = v_field_2466;
      V v_n1_2469 = v_field_2467;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_e_27_2468, v_l_2462, v_sh_2463, v_t_2464}), v_n1_2469}});
    }
  }
  case TAG_ETag: {
    V v_t_2470 = heff_field(v_e_242, 0);
    V v_args_2471 = heff_field(v_e_242, 1);
    V v_ts_2472 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2473 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2471));
    {
      V v_field_2474 = v_t_2473.f[0];
      V v_field_2475 = v_t_2473.f[1];
      V v_args_27_2476 = v_field_2474;
      V v_n1_2477 = v_field_2475;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2470, v_args_27_2476, v_ts_2472}), v_n1_2477}});
    }
  }
  case TAG_EMatch: {
    V v_s_2478 = heff_field(v_e_242, 0);
    V v_arms_2479 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2480 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_s_2478));
    {
      V v_field_2481 = v_t_2480.f[0];
      V v_field_2482 = v_t_2480.f[1];
      V v_s_27_2483 = v_field_2481;
      V v_n1_2484 = v_field_2482;
      HeffT2 v_t_2485 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(v_m_240, v_n1_2484, v_arms_2479));
      {
        V v_field_2486 = v_t_2485.f[0];
        V v_field_2487 = v_t_2485.f[1];
        V v_arms_27_2488 = v_field_2486;
        V v_n2_2489 = v_field_2487;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_27_2483, v_arms_27_2488}), v_n2_2489}});
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EPrimCall: {
    V v_p_2491 = heff_field(v_e_242, 0);
    V v_args_2492 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2493 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2492));
    {
      V v_field_2494 = v_t_2493.f[0];
      V v_field_2495 = v_t_2493.f[1];
      V v_args_27_2496 = v_field_2494;
      V v_n1_2497 = v_field_2495;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2491, v_args_27_2496}), v_n1_2497}});
    }
  }
  case TAG_ECall: {
    V v_g_2498 = heff_field(v_e_242, 0);
    V v_args_2499 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_24100 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2499));
    {
      V v_field_24101 = v_t_24100.f[0];
      V v_field_24102 = v_t_24100.f[1];
      V v_args_27_24103 = v_field_24101;
      V v_n1_24104 = v_field_24102;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2498, v_args_27_24103}), v_n1_24104}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EBool: {
    V v_c_24112 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EBool = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_24113 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_241, v_c_24112));
    {
      V v_field_24114 = v_t_24113.f[0];
      V v_field_24115 = v_t_24113.f[1];
      V v_c_27_24116 = v_field_24114;
      V v_n1_24117 = v_field_24115;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EBool, TAG_EBool, 1, (V[]){v_c_27_24116}), v_n1_24117}});
    }
  }
  case TAG_ESet: {
    V v_xs_24118 = heff_field(v_e_242, 0);
    V v_a_24119 = heff_field(v_e_242, 1);
    V v_b_24120 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_24121 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_a_24119));
    {
      V v_field_24122 = v_t_24121.f[0];
      V v_field_24123 = v_t_24121.f[1];
      V v_a_27_24124 = v_field_24122;
      V v_n1_24125 = v_field_24123;
      V v_t_24126 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n1_24125, NTAG(TAG_Nil)});
      V v_v_24127 = ({ V a_0 = v_t_24126; V a_1 = v_xs_24118; V r_ = (g_list_2efoldl_24s690313412x1307839513(a_0, a_1)); heff_drop(v_xs_24118); r_; });
      V v_m_24128 = heff_take_field(v_v_24127, 0);
      V v_n_24129 = heff_take_field(v_v_24127, 1);
      V v_xs_24130 = heff_get_n(v_v_24127, 2, 3);
      HeffT2 v_t_24131 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_24128, v_n_24129, v_b_24120));
      {
        V v_field_24132 = v_t_24131.f[0];
        V v_field_24133 = v_t_24131.f[1];
        V v_b_27_24134 = v_field_24132;
        V v_n2_24135 = v_field_24133;
        V v_t_24136 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24130));
        V v_f_24137 = heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_t_24136, v_a_27_24124, v_b_27_24134});
        return ((HeffT2){{v_f_24137, v_n2_24135}});
      }
    }
  }
  case TAG_EValues: {
    V v_es_24138 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EValues = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_24139 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_es_24138));
    {
      V v_field_24140 = v_t_24139.f[0];
      V v_field_24141 = v_t_24139.f[1];
      V v_es_27_24142 = v_field_24140;
      V v_n1_24143 = v_field_24141;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EValues, TAG_EValues, 1, (V[]){v_es_27_24142}), v_n1_24143}});
    }
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry, 3, 0};

V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2esubstGo(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_m_240, v_x_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24e_241_24EVar, 1);
        V v_e2_246 = v_field_245;
        return v_e2_246;
      } else {
        heff_drop(v_field_245);
        return heff_tag_at_n(v_ru_24e_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
      }
    }
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_241, 0);
    V v_b_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_2410 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_248, heff_hole()});
    V v_u_2411 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_249, heff_dup(v_cell_2410), MK_INT(1LL)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_args_2413 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_f_2412));
    V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2413));
    return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2414, v_t_2416});
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_241, 0);
    V v_a_2418 = heff_field(v_e_241, 1);
    V v_b_2419 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2420 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2418));
    V v_cell_2421 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2417, v_t_2420, heff_hole()});
    V v_u_2422 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_2419, heff_dup(v_cell_2421), MK_INT(2LL)));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_e_241, 0);
    V v_ts_2424 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2423));
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2429, v_ts_2424});
  }
  case TAG_EProj: {
    V v_e2_2430 = heff_field(v_e_241, 0);
    V v_l_2431 = heff_field(v_e_241, 1);
    V v_sh_2432 = heff_field(v_e_241, 2);
    V v_t_2433 = heff_field(v_e_241, 3);
    V v_ru_24e_241_24EProj = heff_take_reuse_n(v_e_241, 15ULL, 4);
    V v_t_2434 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_e2_2430));
    return heff_tag_at_n(v_ru_24e_241_24EProj, TAG_EProj, 4, (V[]){v_t_2434, v_l_2431, v_sh_2432, v_t_2433});
  }
  case TAG_ETag: {
    V v_t_2435 = heff_field(v_e_241, 0);
    V v_args_2436 = heff_field(v_e_241, 1);
    V v_ts_2437 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2436));
    return heff_tag_at_n(v_ru_24e_241_24ETag, TAG_ETag, 3, (V[]){v_t_2435, v_t_2439, v_ts_2437});
  }
  case TAG_EMatch: {
    V v_s_2440 = heff_field(v_e_241, 0);
    V v_arms_2441 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2442 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_s_2440));
    V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2441));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2442, v_t_2448});
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    V v_p_2450 = heff_field(v_e_241, 0);
    V v_args_2451 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2453 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2451));
    return heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2450, v_t_2453});
  }
  case TAG_ECall: {
    V v_g_2454 = heff_field(v_e_241, 0);
    V v_args_2455 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2457 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2455));
    return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_2454, v_t_2457});
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EBool: {
    V v_c_2465 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EBool = heff_take_reuse_n(v_e_241, 1ULL, 1);
    V v_t_2467 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam6, 1, 1, (V[]){heff_dup(v_m_240)}), v_c_2465));
    return heff_tag_at_n(v_ru_24e_241_24EBool, TAG_EBool, 1, (V[]){v_t_2467});
  }
  case TAG_ESet: {
    V v_xs_2468 = heff_field(v_e_241, 0);
    V v_a_2469 = heff_field(v_e_241, 1);
    V v_b_2470 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2471 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2469));
    V v_cell_2472 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2468, v_t_2471, heff_hole()});
    V v_u_2473 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_2470, heff_dup(v_cell_2472), MK_INT(2LL)));
    heff_drop(v_u_2473);
    return v_cell_2472;
  }
  case TAG_EValues: {
    V v_es_2474 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EValues = heff_take_reuse_n(v_e_241, 1ULL, 1);
    V v_t_2476 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam7, 1, 1, (V[]){heff_dup(v_m_240)}), v_es_2474));
    return heff_tag_at_n(v_ru_24e_241_24EValues, TAG_EValues, 1, (V[]){v_t_2476});
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2esubstGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args) {
  V v_p_2425 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2425)) {
  case TAG_MkPair: {
    V v_l_2426 = heff_field(v_p_2425, 0);
    V v_e2_2427 = heff_field(v_p_2425, 1);
    V v_ru_24p_2425_24MkPair = heff_take_reuse_n(v_p_2425, 3ULL, 2);
    V v_t_2428 = ({ V a_0 = v_m_240; V a_1 = v_e2_2427; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24p_2425_24MkPair, TAG_MkPair, 2, (V[]){v_l_2426, v_t_2428});
  }
  default: return heff_nomatch(v_p_2425);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args) {
  V v_a_2438 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2438; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args) {
  V v_a_2443 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2443)) {
  case TAG_MkArm: {
    V v_t_2444 = heff_field(v_a_2443, 0);
    V v_vs_2445 = heff_field(v_a_2443, 1);
    V v_b_2446 = heff_field(v_a_2443, 2);
    V v_ru_24a_2443_24MkArm = heff_take_reuse_n(v_a_2443, 7ULL, 3);
    V v_t_2447 = ({ V a_0 = v_m_240; V a_1 = v_b_2446; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24a_2443_24MkArm, TAG_MkArm, 3, (V[]){v_t_2444, v_vs_2445, v_t_2447});
  }
  default: return heff_nomatch(v_a_2443);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args) {
  V v_a_2452 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2452; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args) {
  V v_a_2456 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2456; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam6(V self, V *args) {
  V v_a_2466 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2466; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam7(V self, V *args) {
  V v_a_2475 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2475; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2eir_2esubstGo_24dps(V v_m_240, V v_e_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_m_240, v_x_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_244);
        V v_e2_248 = v_field_247;
        return heff_setField(v_d_242, v_i_243, v_e2_248);
      } else {
        heff_drop(v_field_247);
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EVar, 1, (V[]){v_x_244}));
      }
    }
  }
  case TAG_EGlobal: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ELam: {
    V v_xs_2410 = heff_field(v_e_241, 0);
    V v_b_2411 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_2412 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2410, heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_m_240;
    V t_1 = v_b_2411;
    V t_2 = v_cell_2412;
    V t_3 = MK_INT(1LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_e_241, 0);
    V v_args_2415 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_f_2414));
    V v_t_2418 = (g_list_2emap_24tok2(v_ru_24e_241_24EApp, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2415));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2416, v_t_2418}));
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_e_241, 0);
    V v_a_2420 = heff_field(v_e_241, 1);
    V v_b_2421 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2422 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2420));
    V v_cell_2423 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_t_2422, heff_hole()});
    V v_u_2424 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2423));
    heff_drop(v_u_2424);
    V t_0 = v_m_240;
    V t_1 = v_b_2421;
    V t_2 = v_cell_2423;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_e_241, 0);
    V v_ts_2426 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2431 = (g_list_2emap_24tok2(v_ru_24e_241_24ERecord, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2425));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2426}));
  }
  case TAG_EProj: {
    V v_e2_2432 = heff_field(v_e_241, 0);
    V v_l_2433 = heff_field(v_e_241, 1);
    V v_sh_2434 = heff_field(v_e_241, 2);
    V v_t_2435 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_t_2436 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_e2_2432));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2436, v_l_2433, v_sh_2434, v_t_2435}));
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_e_241, 0);
    V v_args_2438 = heff_field(v_e_241, 1);
    V v_ts_2439 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2438));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2437, v_t_2441, v_ts_2439}));
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_e_241, 0);
    V v_arms_2443 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_s_2442));
    V v_t_2450 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2443));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2444, v_t_2450}));
  }
  case TAG_EPrim: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EPrimCall: {
    V v_p_2452 = heff_field(v_e_241, 0);
    V v_args_2453 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2455 = (g_list_2emap_24tok2(v_ru_24e_241_24EPrimCall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2453));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2452, v_t_2455}));
  }
  case TAG_ECall: {
    V v_g_2456 = heff_field(v_e_241, 0);
    V v_args_2457 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2459 = (g_list_2emap_24tok2(v_ru_24e_241_24ECall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2457));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2456, v_t_2459}));
  }
  case TAG_EInt: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EStr: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBytes: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFixed: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat32: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBool: {
    V v_c_2467 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_2469 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam6, 1, 1, (V[]){heff_dup(v_m_240)}), v_c_2467));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EBool, 1, (V[]){v_t_2469}));
  }
  case TAG_ESet: {
    V v_xs_2470 = heff_field(v_e_241, 0);
    V v_a_2471 = heff_field(v_e_241, 1);
    V v_b_2472 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2473 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2471));
    V v_cell_2474 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2470, v_t_2473, heff_hole()});
    V v_u_2475 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2474));
    heff_drop(v_u_2475);
    V t_0 = v_m_240;
    V t_1 = v_b_2472;
    V t_2 = v_cell_2474;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2476 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_2478 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam7, 1, 1, (V[]){heff_dup(v_m_240)}), v_es_2476));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EValues, 1, (V[]){v_t_2478}));
  }
  case TAG_EFix: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2esubstGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2417; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam1(V self, V *args) {
  V v_p_2427 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_l_2428 = heff_field(v_p_2427, 0);
    V v_e2_2429 = heff_field(v_p_2427, 1);
    V v_ru_24p_2427_24MkPair = heff_take_reuse_n(v_p_2427, 3ULL, 2);
    V v_t_2430 = ({ V a_0 = v_m_240; V a_1 = v_e2_2429; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24p_2427_24MkPair, TAG_MkPair, 2, (V[]){v_l_2428, v_t_2430});
  }
  default: return heff_nomatch(v_p_2427);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam2(V self, V *args) {
  V v_a_2440 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2440; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam3(V self, V *args) {
  V v_a_2445 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2445)) {
  case TAG_MkArm: {
    V v_t_2446 = heff_field(v_a_2445, 0);
    V v_vs_2447 = heff_field(v_a_2445, 1);
    V v_b_2448 = heff_field(v_a_2445, 2);
    V v_ru_24a_2445_24MkArm = heff_take_reuse_n(v_a_2445, 7ULL, 3);
    V v_t_2449 = ({ V a_0 = v_m_240; V a_1 = v_b_2448; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24a_2445_24MkArm, TAG_MkArm, 3, (V[]){v_t_2446, v_vs_2447, v_t_2449});
  }
  default: return heff_nomatch(v_a_2445);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam4(V self, V *args) {
  V v_a_2454 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2454; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam5(V self, V *args) {
  V v_a_2458 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2458; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam6(V self, V *args) {
  V v_a_2468 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2468; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam7(V self, V *args) {
  V v_a_2477 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2477; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
Clo g_heff_2ecompile_2eir_2epushArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushArms(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_args_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_a_242, 2);
      heff_take_n(v_a_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2eir_2epushArms_24dps(v_args_243, v_rest_241, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushArms_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_args_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArm: {
      V v_b_247 = heff_field(v_a_243, 2);
      heff_take_n(v_a_243, 4ULL, 3);
      v_t_248 = v_b_247;
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_args_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_249;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushFields_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_e2_246 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_247 = v_e2_246;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_fs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_248;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2elamW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2elamW_entry, 2, 0};

V g_heff_2ecompile_2eir_2elamW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
      V v_x_249 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_248));
      if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
        heff_drop(v_rest_243);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x21_242, 0);
      V v_args_2411 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_args_2411, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2412});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2414 = heff_field(v_x21_242, 1);
      V v_b_2415 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2416;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2417, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2419;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2425 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2427 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2425, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2427;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2428 = heff_field(v_x21_242, 0);
      V v_arms_2429 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2430 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2429, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_t_2430});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2433 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2433, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2434;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2436 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2436, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2437;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2445 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2446 = ({ V a_0 = v_c_2445; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2445); r_; });
      V t_0 = v_x_240;
      V t_1 = v_t_2446;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2448 = heff_field(v_x21_242, 1);
      V v_b_2449 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2450 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2448, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2449, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2450;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2451 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2452 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2451, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2452;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2elamW(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2esizeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeW_entry, 2, 0};

V g_heff_2ecompile_2eir_2esizeW(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_n_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_args_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_args_249, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2414;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2417;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2423 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2423, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2425;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2426 = heff_field(v_x21_242, 0);
      V v_arms_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2426, v_t_2428});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2431, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2432;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2434, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2435;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2443 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2444 = ({ V a_0 = v_c_2443; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2443); r_; });
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2444;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2446 = heff_field(v_x21_242, 1);
      V v_b_2447 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2448 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2446, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2447, v_rest_243})});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2448;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2449 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2450 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2449, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2450;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esizeW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eglobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eglobalsGo_entry, 1, 0};

V g_heff_2ecompile_2eir_2eglobalsGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_f_245));
    V v_t_248 = ({ V a_0 = v_args_246; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_246); r_; });
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EApp, v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2410));
    V v_t_2413 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2411));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a_0)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e2_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 4);
    V t_0 = v_e2_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2421 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_args_2421; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x1_240, 0);
    V v_arms_2424 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2425 = (g_heff_2ecompile_2eir_2eglobalsGo(v_s_2423));
    V v_t_2426 = ({ V a_0 = v_arms_2424; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a_0)); heff_drop(v_arms_2424); r_; });
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EMatch, v_t_2425, v_t_2426));
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_args_2429 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return ({ V a_0 = v_args_2429; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2429); r_; });
  }
  case TAG_ECall: {
    V v_g_2430 = heff_field(v_x1_240, 0);
    V v_args_2431 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2432 = ({ V a_0 = v_args_2431; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2431); r_; });
    return heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){v_g_2430, v_t_2432});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    V v_c_2440 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2441 = ({ V a_0 = v_c_2440; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2440); r_; });
    return ({ V a_0 = v_t_2441; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_t_2441); r_; });
  }
  case TAG_ESet: {
    V v_a_2443 = heff_field(v_x1_240, 1);
    V v_b_2444 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2445 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2443));
    V v_t_2446 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2444));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2445, v_t_2446));
  }
  case TAG_EValues: {
    V v_es_2447 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_es_2447; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_es_2447); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eglobalsGo(a[0]);
}

HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_args_246 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_245));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_h_2410 = v_field_248;
      V v_bs_2411 = v_field_249;
      V v_f_2412 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24e_240_24EApp, v_bs_2411, v_args_246));
      return ((HeffT2){{v_h_2410, v_f_2412}});
    }
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EProj: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ETag: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECall: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EInt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EStr: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EBool: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ESet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EValues: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFix: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2earmNamed_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 1)) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          heff_drop(v_rest_243);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_b_246}});
        }
        case TAG_Cons: {
          heff_take_n(v_vs_245, 0ULL, 2);
          heff_drop(v_b_246);
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_vs_245)}});
        }
      } else {
        heff_drop(v_vs_245);
        heff_drop(v_b_246);
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2eboolArms_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2eboolArms_24cpr_str1, 5, "False");

HeffT2 g_heff_2ecompile_2eir_2eboolArms_24cpr(V v_arms_240) {
top: ;
  switch (heff_tag_of(v_arms_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_241 = heff_field(v_arms_240, 0);
    V v_arms2_242 = heff_field(v_arms_240, 1);
    V v_ru_24arms_240_24Cons = heff_take_reuse_n(v_arms_240, 3ULL, 2);
    switch (heff_tag_of(v_arms2_242)) {
    case TAG_Nil: {
      heff_drop(v_a_241);
      heff_drop_cell(v_ru_24arms_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_arms2_242, 0);
      V v_arms22_244 = heff_field(v_arms2_242, 1);
      V v_ru_24arms2_242_24Cons = heff_take_reuse_n(v_arms2_242, 3ULL, 2);
      switch (heff_tag_of(v_arms22_244)) {
      case TAG_Nil: {
        V v_t_245 = heff_tag_at_n(v_ru_24arms_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
        HeffT2 v_t_246 = ({ V b_0 = ((V)&g_heff_2ecompile_2eir_2eboolArms_24cpr_str0); V a_1 = heff_tag_at_n(v_ru_24arms2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_241), v_t_245}); HeffT2 r_ = (g_heff_2ecompile_2eir_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_248 = v_t_246.f[1];
          int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_t_249 = v_field_248;
            V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
            HeffT2 v_t_2411 = ({ V b_0 = ((V)&g_heff_2ecompile_2eir_2eboolArms_24cpr_str1); V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_241, v_t_2410}); HeffT2 r_ = (g_heff_2ecompile_2eir_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                V v_f_2414 = v_field_2413;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_f_2414})}});
              } else {
                heff_drop(v_t_249);
                heff_drop(v_field_2413);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_a_241);
            heff_drop(v_b_243);
            heff_drop(v_field_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_arms22_244, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop_cell(v_ru_24arms_240_24Cons, 2);
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24arms2_242_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_arms22_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_arms2_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_arms_240)}});
  }
}
Clo g_heff_2ecompile_2eir_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eir_2econdIf(V v_x1_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_CFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_CRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CFalse: {
        return v_x1_240;
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        switch (heff_tag_of(v_x1_240)) {
        case TAG_CTrue: {
          return NTAG(TAG_CFalse);
        }
        case TAG_CFalse: {
          return NTAG(TAG_CTrue);
        }
        case TAG_CRel: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CTest: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CNot: {
          V v_c_2418 = heff_field(v_x1_240, 0);
          heff_take_n(v_x1_240, 1ULL, 1);
          return v_c_2418;
        }
        case TAG_CIf: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        default: return heff_nomatch(v_x1_240);
        }
      }
      case TAG_CFalse: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CRel: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CTest: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CNot: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CIf: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_CTest: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CFalse: {
        return v_x1_240;
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        switch (heff_tag_of(v_x1_240)) {
        case TAG_CTrue: {
          return NTAG(TAG_CFalse);
        }
        case TAG_CFalse: {
          return NTAG(TAG_CTrue);
        }
        case TAG_CRel: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CTest: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CNot: {
          V v_c_2451 = heff_field(v_x1_240, 0);
          heff_take_n(v_x1_240, 1ULL, 1);
          return v_c_2451;
        }
        case TAG_CIf: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        default: return heff_nomatch(v_x1_240);
        }
      }
      case TAG_CFalse: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CRel: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CTest: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CNot: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CIf: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_CNot: {
    V v_c_2471 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_c_2471;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2472 = heff_field(v_x1_240, 0);
    V v_b_2473 = heff_field(v_x1_240, 1);
    V v_c_2474 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2499;
    switch (heff_tag_of(v_t_241)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        v_t_2499 = NTAG(TAG_True);
        break;
      }
      case TAG_CFalse: {
        v_t_2499 = NTAG(TAG_True);
        break;
      }
      case TAG_CRel: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      case TAG_CTest: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      case TAG_CNot: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      case TAG_CIf: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_CFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        v_t_2499 = NTAG(TAG_True);
        break;
      }
      case TAG_CFalse: {
        v_t_2499 = NTAG(TAG_True);
        break;
      }
      case TAG_CRel: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      case TAG_CTest: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      case TAG_CNot: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      case TAG_CIf: {
        v_t_2499 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_CRel: {
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CTest: {
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CNot: {
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    case TAG_CIf: {
      v_t_2499 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2499) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x1_240_24CIf, 3);
      heff_drop(v_t_2499);
      V v_t_24100 = (g_heff_2ecompile_2eir_2econdIf(v_b_2473, heff_dup(v_t_241), heff_dup(v_e_242)));
      V v_t_24101 = (g_heff_2ecompile_2eir_2econdIf(v_c_2474, v_t_241, v_e_242));
      V t_0 = v_a_2472;
      V t_1 = v_t_24100;
      V t_2 = v_t_24101;
      v_x1_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2499);
      return heff_tag_at_n(v_ru_24x1_240_24CIf, TAG_CIf, 3, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_a_2472, v_b_2473, v_c_2474}), v_t_241, v_e_242});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdIf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdShaped_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdShaped_str1, 5, "False");
Clo g_heff_2ecompile_2eir_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdShaped_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 3);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2econdShaped_str0), 2) || heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2econdShaped_str1), 2)));
      heff_drop(v_t_2416);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    HeffT2 v_t_2423 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(v_arms_2422));
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_it1_2426 = v_field_2425;
        switch (heff_tag_of(v_it1_2426)) {
        case TAG_MkPair: {
          V v_t_2427 = heff_field(v_it1_2426, 0);
          V v_f_2428 = heff_field(v_it1_2426, 1);
          heff_take_n(v_it1_2426, 3ULL, 2);
          V v_t_2429 = (g_heff_2ecompile_2eir_2econdShaped(v_t_2427));
          if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
            heff_drop(v_t_2429);
            V t_0 = v_f_2428;
            v_e_240 = t_0;
            goto top;
          } else {
            heff_drop(v_f_2428);
            heff_drop(v_t_2429);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_it1_2426);
        }
      } else {
        heff_drop(v_field_2425);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2431 = heff_field(v_e_240, 0);
    V v_e2_2432 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2432)) {
    case TAG_Nil: {
      heff_drop(v_p_2431);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2434 = heff_field(v_e2_2432, 1);
      heff_take_n(v_e2_2432, 2ULL, 2);
      switch (heff_tag_of(v_e22_2434)) {
      case TAG_Nil: {
        heff_drop(v_p_2431);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2436 = heff_field(v_e22_2434, 1);
        heff_take_n(v_e22_2434, 2ULL, 2);
        switch (heff_tag_of(v_e222_2436)) {
        case TAG_Nil: {
          return ({ V a_0 = v_p_2431; V r_ = (g_heff_2ecompile_2eir_2eisRel(a_0)); heff_drop(v_p_2431); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2436, 0ULL, 2);
          heff_drop(v_p_2431);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2436);
        }
      }
      default: return heff_nomatch(v_e22_2434);
      }
    }
    default: return heff_nomatch(v_e2_2432);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdShaped(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2esurelyBool_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2esurelyBool_str1, 5, "False");
Clo g_heff_2ecompile_2eir_2esurelyBool_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esurelyBool_entry, 1, 0};

V g_heff_2ecompile_2eir_2esurelyBool(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 3);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2esurelyBool_str0), 2) || heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2esurelyBool_str1), 2)));
      heff_drop(v_t_2416);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    HeffT2 v_t_2423 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(v_arms_2422));
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_it1_2426 = v_field_2425;
        switch (heff_tag_of(v_it1_2426)) {
        case TAG_MkPair: {
          V v_t_2427 = heff_field(v_it1_2426, 0);
          V v_f_2428 = heff_field(v_it1_2426, 1);
          heff_take_n(v_it1_2426, 3ULL, 2);
          V v_t_2429 = (g_heff_2ecompile_2eir_2esurelyBool(v_t_2427));
          if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
            heff_drop(v_f_2428);
            heff_drop(v_t_2429);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2429);
            V t_0 = v_f_2428;
            v_e_240 = t_0;
            goto top;
          }
        }
        default: return heff_nomatch(v_it1_2426);
        }
      } else {
        heff_drop(v_field_2425);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2431 = heff_field(v_e_240, 0);
    V v_e2_2432 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2432)) {
    case TAG_Nil: {
      heff_drop(v_p_2431);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2434 = heff_field(v_e2_2432, 1);
      heff_take_n(v_e2_2432, 2ULL, 2);
      switch (heff_tag_of(v_e22_2434)) {
      case TAG_Nil: {
        heff_drop(v_p_2431);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2436 = heff_field(v_e22_2434, 1);
        heff_take_n(v_e22_2434, 2ULL, 2);
        switch (heff_tag_of(v_e222_2436)) {
        case TAG_Nil: {
          return ({ V a_0 = v_p_2431; V r_ = (g_heff_2ecompile_2eir_2eisRel(a_0)); heff_drop(v_p_2431); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2436, 0ULL, 2);
          heff_drop(v_p_2431);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2436);
        }
      }
      default: return heff_nomatch(v_e22_2434);
      }
    }
    default: return heff_nomatch(v_e2_2432);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esurelyBool(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdOf_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdOf_str1, 5, "False");
Clo g_heff_2ecompile_2eir_2econdOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdOf_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ETag: {
    V v_e2_2417 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_ETag: {
        V v_t_2419 = heff_field(v_e_240, 0);
        V v_ts_2421 = heff_field(v_e_240, 2);
        V v_ru_24e_240_24ETag = heff_take_reuse_n(v_e_240, 5ULL, 3);
        if (heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ecompile_2eir_2econdOf_str0), 2)) {
          heff_drop(v_t_2419);
          heff_drop(v_ts_2421);
          heff_drop_cell(v_ru_24e_240_24ETag, 3);
          return NTAG(TAG_CTrue);
        } else {
          if (heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ecompile_2eir_2econdOf_str1), 2)) {
            heff_drop(v_t_2419);
            heff_drop(v_ts_2421);
            heff_drop_cell(v_ru_24e_240_24ETag, 3);
            return NTAG(TAG_CFalse);
          } else {
            V v_t_2422 = heff_tag_at_n(v_ru_24e_240_24ETag, TAG_ETag, 3, (V[]){v_t_2419, NTAG(TAG_Nil), v_ts_2421});
            return heff_tag_n(TAG_CTest, 1, (V[]){v_t_2422});
          }
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_240, 0);
    V v_arms_2426 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    HeffT2 v_t_2427 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(heff_dup(v_arms_2426)));
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        V v_it1_2430 = v_field_2429;
        switch (heff_tag_of(v_it1_2430)) {
        case TAG_MkPair: {
          V v_t_2431 = heff_field(v_it1_2430, 0);
          V v_f_2432 = heff_field(v_it1_2430, 1);
          heff_take_n(v_it1_2430, 3ULL, 2);
          V v_t_2433 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_t_2431)));
          if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
            heff_drop(v_t_2433);
            V v_t_2434 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_f_2432)));
            if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
              heff_drop(v_t_2434);
              V v_t_2435 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_t_2431)));
              if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
                heff_drop(v_arms_2426);
                heff_drop_cell(v_ru_24e_240_24EMatch, 2);
                heff_drop(v_t_2435);
                V v_t_2436 = (g_heff_2ecompile_2eir_2econdOf(v_s_2425));
                V v_t_2437 = (g_heff_2ecompile_2eir_2econdOf(v_t_2431));
                V v_t_2438 = (g_heff_2ecompile_2eir_2econdOf(v_f_2432));
                return (g_heff_2ecompile_2eir_2econdIf(v_t_2436, v_t_2437, v_t_2438));
              } else {
                heff_drop(v_t_2435);
                V v_t_2439 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_f_2432)));
                if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                  heff_drop(v_arms_2426);
                  heff_drop_cell(v_ru_24e_240_24EMatch, 2);
                  heff_drop(v_t_2439);
                  V v_t_2440 = (g_heff_2ecompile_2eir_2econdOf(v_s_2425));
                  V v_t_2441 = (g_heff_2ecompile_2eir_2econdOf(v_t_2431));
                  V v_t_2442 = (g_heff_2ecompile_2eir_2econdOf(v_f_2432));
                  return (g_heff_2ecompile_2eir_2econdIf(v_t_2440, v_t_2441, v_t_2442));
                } else {
                  heff_drop(v_t_2431);
                  heff_drop(v_f_2432);
                  heff_drop(v_t_2439);
                  return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
                }
              }
            } else {
              heff_drop(v_t_2431);
              heff_drop(v_f_2432);
              heff_drop(v_t_2434);
              return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
            }
          } else {
            heff_drop(v_t_2431);
            heff_drop(v_f_2432);
            heff_drop(v_t_2433);
            return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
          }
        }
        default: return heff_nomatch(v_it1_2430);
        }
      } else {
        heff_drop(v_field_2429);
        return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
      }
    }
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EPrimCall: {
    V v_p_2444 = heff_dup(heff_field(v_e_240, 0));
    V v_e2_2445 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e2_2445)) {
    case TAG_Nil: {
      heff_drop(v_p_2444);
      return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
    }
    case TAG_Cons: {
      V v_a_2446 = heff_field(v_e2_2445, 0);
      V v_e22_2447 = heff_field(v_e2_2445, 1);
      V v_ru_24e2_2445_24Cons = heff_take_reuse_n(v_e2_2445, 3ULL, 2);
      switch (heff_tag_of(v_e22_2447)) {
      case TAG_Nil: {
        heff_drop(v_p_2444);
        heff_drop(v_a_2446);
        heff_drop_cell(v_ru_24e2_2445_24Cons, 2);
        return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
      }
      case TAG_Cons: {
        V v_b_2448 = heff_field(v_e22_2447, 0);
        V v_e222_2449 = heff_field(v_e22_2447, 1);
        V v_ru_24e22_2447_24Cons = heff_take_reuse_n(v_e22_2447, 3ULL, 2);
        switch (heff_tag_of(v_e222_2449)) {
        case TAG_Nil: {
          heff_drop_tag(v_e_240, 2);
          V v_t_2450 = (g_heff_2ecompile_2eir_2eisRel(v_p_2444));
          if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24e2_2445_24Cons, 2);
            heff_drop_cell(v_ru_24e22_2447_24Cons, 2);
            heff_drop(v_t_2450);
            return heff_tag_n(TAG_CRel, 3, (V[]){v_p_2444, v_a_2446, v_b_2448});
          } else {
            heff_drop(v_t_2450);
            V v_t_2451 = heff_tag_at_n(v_ru_24e2_2445_24Cons, TAG_Cons, 2, (V[]){v_b_2448, NTAG(TAG_Nil)});
            V v_t_2452 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2444, heff_tag_at_n(v_ru_24e22_2447_24Cons, TAG_Cons, 2, (V[]){v_a_2446, v_t_2451})});
            return heff_tag_n(TAG_CTest, 1, (V[]){v_t_2452});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2449, 0ULL, 2);
          heff_drop(v_p_2444);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24e2_2445_24Cons, 2);
          heff_drop(v_b_2448);
          heff_drop_cell(v_ru_24e22_2447_24Cons, 2);
          return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
        }
        default: return heff_nomatch(v_e222_2449);
        }
      }
      default: return heff_nomatch(v_e22_2447);
      }
    }
    default: return heff_nomatch(v_e2_2445);
    }
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EBool: {
    V v_c_2464 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return v_c_2464;
  }
  case TAG_ESet: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EValues: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdOf(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s1757197295x1613025671(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s2059933241x1984514560(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_s_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_s_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s872831299x1497405508(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eir_2eappendI_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eir_2eappendI_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI_24tok2(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushFields_24tok2(V v_tok_240, V v_x1_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x1_241, 0);
    V v_fs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_e2_246 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_247 = v_e2_246;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2eir_2epushFields_24dps(v_fs_244, v_rest_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields_24tok2(a[0], a[1], a[2]);
}