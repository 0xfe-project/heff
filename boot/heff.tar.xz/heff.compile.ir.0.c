// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
V g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746(V);
V g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746_clo;
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(V);
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_clo;
V g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(V);
V g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724_clo;
V g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012(V);
V g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2earmFor(V, V);
V g_heff_2ecompile_2eir_2earmFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2earmFor_clo;
HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V, V);
HeffT3 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_clo;
V g_heff_2ecompile_2eir_2efoldArms(V, V, V);
V g_heff_2ecompile_2eir_2efoldArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldArms_clo;
V g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349(V, V);
V g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349_clo;
V g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884(V, V);
V g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884_clo;
V g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(V, V);
V g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24dps_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ehasDefault(V);
V g_heff_2ecompile_2eir_2ehasDefault_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ehasDefault_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2esubstGo_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24dps_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_clo;
V g_heff_2ecompile_2eir_2esurelyBool(V);
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esurelyBool_clo;
HeffT2 g_heff_2ecompile_2eir_2etraversePartsM_24s1049679562x279661776_24cpr(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_clo;
V g_heff_2ecompile_2eonce_2emoved(V, V);
V g_heff_2ecompile_2eonce_2emoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2emoved_clo;
V g_heff_2ecompile_2erunes_2ereads(V);
V g_heff_2ecompile_2erunes_2ereads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereads_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_heff_2ecompile_2eworlds_2eworldsIn(V, V);
V g_heff_2ecompile_2eworlds_2eworldsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eworldsIn_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1159166259x948777116_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s119460564x671287541_24cpr(V, V);
V g_prelude_2etraverse_24s1259852701x334693366(V);
V g_prelude_2etraverse_24s1259852701x334693366_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1259852701x334693366_clo;
HeffT2 g_prelude_2etraverse_24s1776038734x825611929_24cpr(V, V);
V g_prelude_2etraverse_24s259655739x790043950(V);
V g_prelude_2etraverse_24s259655739x790043950_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s259655739x790043950_clo;
HeffT2 g_prelude_2etraverse_24s76089383x258265534_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eir_2earmFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2earmFor_entry, 2, 0};

V g_heff_2ecompile_2eir_2earmFor(V v_t_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eir_2earmFor_24cpr(v_t_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eir_2earmFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eir_2earmFor(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2eappendI_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eir_2eappendI_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eir_2emapParts_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2emapParts_lam1(V self, V *args);
Clo g_heff_2ecompile_2eir_2emapParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2emapParts_entry, 2, 0};

V g_heff_2ecompile_2eir_2emapParts(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_244), v_b_245}));
    return heff_tag_re_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_244, v_t_246});
  }
  case TAG_EApp: {
    V v_g_247 = heff_field(v_x2_241, 0);
    V v_args_248 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_247}));
    V v_t_2410 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2411 = (g_list_2emap(v_t_2410, v_args_248));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_249, v_t_2411});
  }
  case TAG_ELet: {
    V v_x_2412 = heff_field(v_x2_241, 0);
    V v_a_2413 = heff_field(v_x2_241, 1);
    V v_b_2414 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2415 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2413}));
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), NTAG(TAG_Nil)});
    V v_t_2417 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2416, v_b_2414}));
    return heff_tag_re_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2412, v_t_2415, v_t_2417});
  }
  case TAG_ERecord: {
    V v_fs_2418 = heff_field(v_x2_241, 0);
    V v_ts_2419 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2emapParts_lam0, 1, 1, (V[]){v_f_240}), v_fs_2418));
    return heff_tag_re_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_t_2424, v_ts_2419});
  }
  case TAG_EProj: {
    V v_e_2425 = heff_field(v_x2_241, 0);
    V v_l_2426 = heff_field(v_x2_241, 1);
    V v_sh_2427 = heff_field(v_x2_241, 2);
    V v_t_2428 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2429 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2425}));
    return heff_tag_re_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_t_2429, v_l_2426, v_sh_2427, v_t_2428});
  }
  case TAG_ETag: {
    V v_t_2430 = heff_field(v_x2_241, 0);
    V v_args_2431 = heff_field(v_x2_241, 1);
    V v_ts_2432 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2433 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2434 = (g_list_2emap(v_t_2433, v_args_2431));
    return heff_tag_re_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2430, v_t_2434, v_ts_2432});
  }
  case TAG_EMatch: {
    V v_s_2435 = heff_field(v_x2_241, 0);
    V v_arms_2436 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2437 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2435}));
    V v_t_2443 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2emapParts_lam1, 1, 1, (V[]){v_f_240}), v_arms_2436));
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2437, v_t_2443});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_2445 = heff_field(v_x2_241, 0);
    V v_args_2446 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2447 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2448 = (g_list_2emap(v_t_2447, v_args_2446));
    return heff_tag_re_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_p_2445, v_t_2448});
  }
  case TAG_ECall: {
    V v_g_2449 = heff_field(v_x2_241, 0);
    V v_args_2450 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2451 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2452 = (g_list_2emap(v_t_2451, v_args_2450));
    return heff_tag_re_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2449, v_t_2452});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_EBool: {
    V v_c_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EBool = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2461 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2462 = (g_heff_2ecompile_2eir_2econdMap(v_t_2461, v_c_2460));
    return heff_tag_at_n(v_ru_24x2_241_24EBool, TAG_EBool, 1, (V[]){v_t_2462});
  }
  case TAG_ESet: {
    V v_xs_2463 = heff_field(v_x2_241, 0);
    V v_a_2464 = heff_field(v_x2_241, 1);
    V v_b_2465 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ESet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2466 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2464}));
    V v_t_2467 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_2463), v_b_2465}));
    return heff_tag_re_n(v_ru_24x2_241_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_2463, v_t_2466, v_t_2467});
  }
  case TAG_EValues: {
    V v_es_2468 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EValues = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2469 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2470 = (g_list_2emap(v_t_2469, v_es_2468));
    return heff_tag_at_n(v_ru_24x2_241_24EValues, TAG_EValues, 1, (V[]){v_t_2470});
  }
  case TAG_EFix: {
    V v_x_2471 = heff_field(v_x2_241, 0);
    V v_b_2472 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2471), NTAG(TAG_Nil)});
    V v_t_2474 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2473, v_b_2472}));
    return heff_tag_re_n(v_ru_24x2_241_24EFix, TAG_EFix, 2, 1ULL, (V[]){v_x_2471, v_t_2474});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2emapParts(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2emapParts_lam0(V self, V *args) {
  V v_x2_2420 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_l_2421 = heff_field(v_x2_2420, 0);
    V v_e_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_t_2423 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2422}));
    return heff_tag_re_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_2421, v_t_2423});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eir_2emapParts_lam1(V self, V *args) {
  V v_x2_2438 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkArm: {
    V v_t_2439 = heff_field(v_x2_2438, 0);
    V v_vs_2440 = heff_field(v_x2_2438, 1);
    V v_b_2441 = heff_field(v_x2_2438, 2);
    V v_ru_24x2_2438_24MkArm = heff_take_reuse_n(v_x2_2438, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2442 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2440), v_b_2441}));
    return heff_tag_re_n(v_ru_24x2_2438_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2439, v_vs_2440, v_t_2442});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
Clo g_heff_2ecompile_2eir_2efoldArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldArms_entry, 3, 0};

V g_heff_2ecompile_2eir_2efoldArms(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_arms_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkArm: {
      V v_vs_246 = heff_field(v_x21_243, 1);
      V v_b_247 = heff_field(v_x21_243, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 3, (V[]){heff_dup(v_vs_246), heff_dup(v_b_247), v_acc_242}));
      V t_0 = v_f_240;
      V t_1 = v_arms_244;
      V t_2 = v_t_248;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2efoldArms_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2efoldArms(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_e_241 = heff_field(v_x2_240, 0);
    V v_es_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_e_241)));
    if (!(heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_a_243);
      V t_0 = v_es_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x2_240, 1);
    V v_a_245 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_b_244)));
    V v_ret_24bool = heff_bool(!(heff_dup(v_a_245) == NTAG(TAG_True)));
    heff_drop(v_a_245);
    return v_ret_24bool;
  }
  case TAG_EApp: {
    V v_g_246 = heff_field(v_x2_240, 0);
    V v_args_247 = heff_field(v_x2_240, 1);
    V v_a_248 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_g_246)));
    if (!(heff_dup(v_a_248) == NTAG(TAG_True))) {
      heff_drop(v_a_248);
      HEFF_LAST return g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(v_args_247);
    } else {
      heff_drop(v_a_248);
      return NTAG(TAG_False);
    }
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x2_240, 1);
    V v_b_2411 = heff_field(v_x2_240, 2);
    V v_a_2412 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_a_2410)));
    if (!(heff_dup(v_a_2412) == NTAG(TAG_True))) {
      heff_drop(v_a_2412);
      V v_a_2413 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_b_2411)));
      V v_ret_24bool = heff_bool(!(heff_dup(v_a_2413) == NTAG(TAG_True)));
      heff_drop(v_a_2413);
      return v_ret_24bool;
    } else {
      heff_drop(v_a_2412);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(v_fs_2414);
  }
  case TAG_EProj: {
    V v_e_2416 = heff_field(v_x2_240, 0);
    V v_a_2420 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_e_2416)));
    V v_ret_24bool = heff_bool(!(heff_dup(v_a_2420) == NTAG(TAG_True)));
    heff_drop(v_a_2420);
    return v_ret_24bool;
  }
  case TAG_ETag: {
    V v_args_2422 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(v_args_2422);
  }
  case TAG_EMatch: {
    V v_s_2424 = heff_field(v_x2_240, 0);
    V v_arms_2425 = heff_field(v_x2_240, 1);
    V v_a_2426 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_s_2424)));
    if (!(heff_dup(v_a_2426) == NTAG(TAG_True))) {
      heff_drop(v_a_2426);
      HEFF_LAST return g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746(v_arms_2425);
    } else {
      heff_drop(v_a_2426);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_args_2429 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(v_args_2429);
  }
  case TAG_ECall: {
    V v_args_2431 = heff_field(v_x2_240, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(v_args_2431);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_2439 = heff_field(v_x2_240, 0);
    V v_t_2440 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2439, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_2440; V r_ = (g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(a_0)); heff_drop(v_t_2440); r_; });
  }
  case TAG_ESet: {
    V v_a_2442 = heff_field(v_x2_240, 1);
    V v_b_2443 = heff_field(v_x2_240, 2);
    V v_a_2444 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_a_2442)));
    if (!(heff_dup(v_a_2444) == NTAG(TAG_True))) {
      heff_drop(v_a_2444);
      V v_a_2445 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_b_2443)));
      V v_ret_24bool = heff_bool(!(heff_dup(v_a_2445) == NTAG(TAG_True)));
      heff_drop(v_a_2445);
      return v_ret_24bool;
    } else {
      heff_drop(v_a_2444);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_2446 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eir_2eallList_24s382064364x1569129724(v_es_2446);
  }
  case TAG_EFix: {
    V v_b_2448 = heff_field(v_x2_240, 1);
    V v_a_2449 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_b_2448)));
    V v_ret_24bool = heff_bool(!(heff_dup(v_a_2449) == NTAG(TAG_True)));
    heff_drop(v_a_2449);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x41_243, 0);
      V v_e_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_246));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_e_27_2410 = v_field_248;
        V v_n1_2411 = v_field_249;
        V v_cell_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_245, v_e_27_2410}), heff_hole()});
        HeffT2 v_t_2413 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24dps_24cpr(v_m_240, v_n1_2411, v_rest_244, v_cell_2412));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v__5f_2416 = v_field_2414;
          heff_drop(v__5f_2416);
          V v_n_2417 = v_field_2415;
          return ((HeffT2){{v_cell_2412, v_n_2417}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2esubstGo(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_240, v_x_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24e_241_24EVar, 1);
        V v_e2_246 = v_field_245;
        return v_e2_246;
      } else {
        heff_drop(v_field_245);
        return heff_tag_re_n(v_ru_24e_241_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_242});
      }
    }
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_241, 0);
    V v_b_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_2410 = heff_tag_re_n(v_ru_24e_241_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_248, heff_hole()});
    V v_u_2411 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_249, v_cell_2410, MK_INT(1LL)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_args_2413 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_f_2412));
    V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2413));
    return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2414, v_t_2416});
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_241, 0);
    V v_a_2418 = heff_field(v_e_241, 1);
    V v_b_2419 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2420 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2418));
    V v_cell_2421 = heff_tag_re_n(v_ru_24e_241_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2417, v_t_2420, heff_hole()});
    V v_u_2422 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_2419, v_cell_2421, MK_INT(2LL)));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_e_241, 0);
    V v_ts_2424 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2423));
    return heff_tag_re_n(v_ru_24e_241_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_t_2429, v_ts_2424});
  }
  case TAG_EProj: {
    V v_e2_2430 = heff_field(v_e_241, 0);
    V v_l_2431 = heff_field(v_e_241, 1);
    V v_sh_2432 = heff_field(v_e_241, 2);
    V v_t_2433 = heff_field(v_e_241, 3);
    V v_ru_24e_241_24EProj = heff_take_reuse_n(v_e_241, 15ULL, 4);
    V v_t_2434 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_e2_2430));
    return heff_tag_re_n(v_ru_24e_241_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_t_2434, v_l_2431, v_sh_2432, v_t_2433});
  }
  case TAG_ETag: {
    V v_t_2435 = heff_field(v_e_241, 0);
    V v_args_2436 = heff_field(v_e_241, 1);
    V v_ts_2437 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2436));
    return heff_tag_re_n(v_ru_24e_241_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2435, v_t_2439, v_ts_2437});
  }
  case TAG_EMatch: {
    V v_s_2440 = heff_field(v_e_241, 0);
    V v_arms_2441 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2442 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_s_2440));
    V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2441));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2442, v_t_2448});
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    V v_p_2450 = heff_field(v_e_241, 0);
    V v_args_2451 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2453 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2451));
    return heff_tag_re_n(v_ru_24e_241_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_p_2450, v_t_2453});
  }
  case TAG_ECall: {
    V v_g_2454 = heff_field(v_e_241, 0);
    V v_args_2455 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2457 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2455));
    return heff_tag_re_n(v_ru_24e_241_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2454, v_t_2457});
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EBool: {
    V v_c_2465 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EBool = heff_take_reuse_n(v_e_241, 1ULL, 1);
    V v_t_2467 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam6, 1, 1, (V[]){heff_dup(v_m_240)}), v_c_2465));
    return heff_tag_at_n(v_ru_24e_241_24EBool, TAG_EBool, 1, (V[]){v_t_2467});
  }
  case TAG_ESet: {
    V v_xs_2468 = heff_field(v_e_241, 0);
    V v_a_2469 = heff_field(v_e_241, 1);
    V v_b_2470 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2471 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2469));
    V v_cell_2472 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_2468, v_t_2471, heff_hole()});
    V v_u_2473 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_2470, v_cell_2472, MK_INT(2LL)));
    heff_drop(v_u_2473);
    return v_cell_2472;
  }
  case TAG_EValues: {
    V v_es_2474 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EValues = heff_take_reuse_n(v_e_241, 1ULL, 1);
    V v_t_2476 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam7, 1, 1, (V[]){heff_dup(v_m_240)}), v_es_2474));
    return heff_tag_at_n(v_ru_24e_241_24EValues, TAG_EValues, 1, (V[]){v_t_2476});
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2esubstGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args) {
  V v_p_2425 = args[0];
  V v_m_240 = heff_env(self)[0];
  switch (heff_tag_of(v_p_2425)) {
  case TAG_MkPair: {
    V v_l_2426 = heff_field(v_p_2425, 0);
    V v_e2_2427 = heff_field(v_p_2425, 1);
    V v_ru_24p_2425_24MkPair = heff_take_reuse_n(v_p_2425, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_t_2428 = ({ V a_0 = v_m_240; V a_1 = v_e2_2427; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_re_n(v_ru_24p_2425_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_2426, v_t_2428});
  }
  default: return heff_nomatch(v_p_2425);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args) {
  V v_a_2438 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2438; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args) {
  V v_a_2443 = args[0];
  V v_m_240 = heff_env(self)[0];
  switch (heff_tag_of(v_a_2443)) {
  case TAG_MkArm: {
    V v_t_2444 = heff_field(v_a_2443, 0);
    V v_vs_2445 = heff_field(v_a_2443, 1);
    V v_b_2446 = heff_field(v_a_2443, 2);
    V v_ru_24a_2443_24MkArm = heff_take_reuse_n(v_a_2443, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2447 = ({ V a_0 = v_m_240; V a_1 = v_b_2446; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_re_n(v_ru_24a_2443_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2444, v_vs_2445, v_t_2447});
  }
  default: return heff_nomatch(v_a_2443);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args) {
  V v_a_2452 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2452; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args) {
  V v_a_2456 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2456; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam6(V self, V *args) {
  V v_a_2466 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2466; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam7(V self, V *args) {
  V v_a_2475 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2475; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
Clo g_heff_2ecompile_2eir_2esizeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeW_entry, 2, 0};

V g_heff_2ecompile_2eir_2esizeW(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_n_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ELam: {
      V v_b_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_b_245, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_246 = heff_field(v_x21_242, 0);
      V v_args_247 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_args_247, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_246, v_t_248});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2410 = heff_field(v_x21_242, 1);
      V v_b_2411 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, v_rest_243})});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2412;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2413 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2413, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2415;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2416 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_e_2416, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2421 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2423 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2421, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2423;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2424 = heff_field(v_x21_242, 0);
      V v_arms_2425 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2426 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2425, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2424, v_t_2426});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2428 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2428, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2429;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2431, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2432;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2433 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2434 = ({ V a_0 = v_c_2433; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2433); r_; });
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2434;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2436 = heff_field(v_x21_242, 1);
      V v_b_2437 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2438 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2436, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2437, v_rest_243})});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2438;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2439 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2440 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2439, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2440;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: {
      heff_drop(v_x21_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esizeW(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2esurelyBool_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2esurelyBool_str1, 5, "False");
Clo g_heff_2ecompile_2eir_2esurelyBool_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esurelyBool_entry, 1, 0};

V g_heff_2ecompile_2eir_2esurelyBool(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 3);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2esurelyBool_str0), 2) || heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2esurelyBool_str1), 2)));
      heff_drop(v_t_2416);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    HeffT3 v_t_2423 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(v_arms_2422));
    {
      V v_field_2425 = v_t_2423.f[1];
      V v_field_2426 = v_t_2423.f[2];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_t_2427 = v_field_2425;
        V v_f_2428 = v_field_2426;
        V v_t_2429 = (g_heff_2ecompile_2eir_2esurelyBool(v_t_2427));
        if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
          heff_drop(v_f_2428);
          heff_drop(v_t_2429);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2429);
          V t_0 = v_f_2428;
          v_e_240 = t_0;
          goto top;
        }
      } else {
        heff_drop(v_field_2425);
        heff_drop(v_field_2426);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2431 = heff_field(v_e_240, 0);
    V v_e2_2432 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2432)) {
    case TAG_Nil: {
      heff_drop(v_p_2431);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2434 = heff_field(v_e2_2432, 1);
      heff_take_n(v_e2_2432, 2ULL, 2);
      switch (heff_tag_of(v_e22_2434)) {
      case TAG_Nil: {
        heff_drop(v_p_2431);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2436 = heff_field(v_e22_2434, 1);
        heff_take_n(v_e22_2434, 2ULL, 2);
        switch (heff_tag_of(v_e222_2436)) {
        case TAG_Nil: {
          return ({ V a_0 = v_p_2431; V r_ = (g_heff_2ecompile_2eir_2eisRel(a_0)); heff_drop(v_p_2431); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2436, 0ULL, 2);
          heff_drop(v_p_2431);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2436);
        }
      }
      default: return heff_nomatch(v_e22_2434);
      }
    }
    default: return heff_nomatch(v_e2_2432);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esurelyBool(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam2, 1, 3, (V[]){v_x_244, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2417 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam3, 1, 1, (V[]){v_x_2417});
  }
  case TAG_CNot: {
    V v_c_2424 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2425 = (g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(v_c_2424));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam4, 1, 1, (V[]){v_m_2425});
  }
  case TAG_CIf: {
    V v_a_2430 = heff_field(v_x2_27_240, 0);
    V v_b_2431 = heff_field(v_x2_27_240, 1);
    V v_c_2432 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2433 = (g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(v_a_2430));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam5, 1, 3, (V[]){v_m_2433, v_b_2431, v_c_2432});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam0(V self, V *args) {
  V v_st_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_st_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam1(V self, V *args) {
  V v_st_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_st_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam2(V self, V *args) {
  V v_st_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_247 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_x_244, v_st_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    HeffT2 v_t_2412 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_y_245, v_st_2411));
    {
      V v_field_2413 = v_t_2412.f[0];
      V v_field_2414 = v_t_2412.f[1];
      V v_x_2415 = v_field_2413;
      V v_st_2416 = v_field_2414;
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_2410, v_x_2415}), v_st_2416});
    }
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam3(V self, V *args) {
  V v_st_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_x_2417, v_st_2418));
  {
    V v_field_2420 = v_t_2419.f[0];
    V v_field_2421 = v_t_2419.f[1];
    V v_x_2422 = v_field_2420;
    V v_st_2423 = v_field_2421;
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2422}), v_st_2423});
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam4(V self, V *args) {
  V v_st_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_st_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2428}), v_st_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749_lam5(V self, V *args) {
  V v_st_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_b_2431 = heff_env(self)[1];
  V v_c_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_st_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_st_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2438 = (g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(v_b_2431));
    V v_x2_2439 = heff_tr(heff_call(v_t_2438, 1, (V[]){v_st_2437}));
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_MkPair: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_st_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      V v_t_2442 = (g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(v_c_2432));
      V v_x2_2443 = heff_tr(heff_call(v_t_2442, 1, (V[]){v_st_2441}));
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_MkPair: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_st_2445 = heff_field(v_x2_2443, 1);
        heff_take_n(v_x2_2443, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2436, v_x_2440, v_x_2444}), v_st_2445});
      }
      default: return heff_nomatch(v_x2_2443);
      }
    }
    default: return heff_nomatch(v_x2_2439);
    }
  }
  default: return heff_nomatch(v_x2_2435);
  }
}

HeffT2 g_heff_2ecompile_2eir_2etraversePartsM_24s1049679562x279661776_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_240, 0);
    V v_b_245 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_246 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_b_245, v_z_241));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_249 = v_field_247;
      V v_st_2410 = v_field_248;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_244, v_x_249}), v_st_2410}});
    }
  }
  case TAG_EApp: {
    V v_g_2411 = heff_field(v_x2_240, 0);
    V v_args_2412 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_2413 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_g_2411, v_z_241));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      V v_st_2417 = v_field_2415;
      HeffT2 v_t_2418 = (g_prelude_2etraverse_24s1159166259x948777116_24cpr(v_args_2412, v_st_2417));
      {
        V v_field_2419 = v_t_2418.f[0];
        V v_field_2420 = v_t_2418.f[1];
        V v_x_2421 = v_field_2419;
        V v_st_2422 = v_field_2420;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_EApp, 2, (V[]){v_x_2416, v_x_2421}), v_st_2422}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_a_2424 = heff_field(v_x2_240, 1);
    V v_b_2425 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24ELet = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT2 v_t_2426 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_2424, v_z_241));
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_x_2429 = v_field_2427;
      V v_st_2430 = v_field_2428;
      HeffT2 v_t_2431 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_b_2425, v_st_2430));
      {
        V v_field_2432 = v_t_2431.f[0];
        V v_field_2433 = v_t_2431.f[1];
        V v_x_2434 = v_field_2432;
        V v_st_2435 = v_field_2433;
        return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2423, v_x_2429, v_x_2434}), v_st_2435}});
      }
    }
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_x2_240, 0);
    V v_ts_2437 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_2438 = (g_prelude_2etraverse_24s119460564x671287541_24cpr(v_fs_2436, v_z_241));
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_x_2441 = v_field_2439;
      V v_st_2442 = v_field_2440;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_x_2441, v_ts_2437}), v_st_2442}});
    }
  }
  case TAG_EProj: {
    V v_e_2443 = heff_field(v_x2_240, 0);
    V v_l_2444 = heff_field(v_x2_240, 1);
    V v_sh_2445 = heff_field(v_x2_240, 2);
    V v_t_2446 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24EProj = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    HeffT2 v_t_2447 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_e_2443, v_z_241));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_x_2450 = v_field_2448;
      V v_st_2451 = v_field_2449;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_x_2450, v_l_2444, v_sh_2445, v_t_2446}), v_st_2451}});
    }
  }
  case TAG_ETag: {
    V v_t_2452 = heff_field(v_x2_240, 0);
    V v_args_2453 = heff_field(v_x2_240, 1);
    V v_ts_2454 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24ETag = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT2 v_t_2455 = (g_prelude_2etraverse_24s1159166259x948777116_24cpr(v_args_2453, v_z_241));
    {
      V v_field_2456 = v_t_2455.f[0];
      V v_field_2457 = v_t_2455.f[1];
      V v_x_2458 = v_field_2456;
      V v_st_2459 = v_field_2457;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2452, v_x_2458, v_ts_2454}), v_st_2459}});
    }
  }
  case TAG_EMatch: {
    V v_s_2460 = heff_field(v_x2_240, 0);
    V v_arms_2461 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_2462 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_s_2460, v_z_241));
    {
      V v_field_2463 = v_t_2462.f[0];
      V v_field_2464 = v_t_2462.f[1];
      V v_x_2465 = v_field_2463;
      V v_st_2466 = v_field_2464;
      HeffT2 v_t_2467 = (g_prelude_2etraverse_24s76089383x258265534_24cpr(v_arms_2461, v_st_2466));
      {
        V v_field_2468 = v_t_2467.f[0];
        V v_field_2469 = v_t_2467.f[1];
        V v_x_2470 = v_field_2468;
        V v_st_2471 = v_field_2469;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_EMatch, 2, (V[]){v_x_2465, v_x_2470}), v_st_2471}});
      }
    }
  }
  case TAG_EPrim: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EPrimCall: {
    V v_p_2473 = heff_field(v_x2_240, 0);
    V v_args_2474 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_2475 = (g_prelude_2etraverse_24s1159166259x948777116_24cpr(v_args_2474, v_z_241));
    {
      V v_field_2476 = v_t_2475.f[0];
      V v_field_2477 = v_t_2475.f[1];
      V v_x_2478 = v_field_2476;
      V v_st_2479 = v_field_2477;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_p_2473, v_x_2478}), v_st_2479}});
    }
  }
  case TAG_ECall: {
    V v_g_2480 = heff_field(v_x2_240, 0);
    V v_args_2481 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_2482 = (g_prelude_2etraverse_24s1159166259x948777116_24cpr(v_args_2481, v_z_241));
    {
      V v_field_2483 = v_t_2482.f[0];
      V v_field_2484 = v_t_2482.f[1];
      V v_x_2485 = v_field_2483;
      V v_st_2486 = v_field_2484;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2480, v_x_2485}), v_st_2486}});
    }
  }
  case TAG_EInt: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EStr: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{v_x2_240, v_z_241}});
  }
  case TAG_EBool: {
    V v_c_2494 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24EBool = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_m_2495 = (g_heff_2ecompile_2eir_2econdTraverse_24s533773987x2101976749(v_c_2494));
    V v_x2_2496 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2496)) {
    case TAG_MkPair: {
      V v_x_2497 = heff_field(v_x2_2496, 0);
      V v_st_2498 = heff_field(v_x2_2496, 1);
      heff_take_n(v_x2_2496, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24EBool, TAG_EBool, 1, (V[]){v_x_2497}), v_st_2498}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2496)}});
    }
  }
  case TAG_ESet: {
    V v_xs_2499 = heff_field(v_x2_240, 0);
    V v_a_24100 = heff_field(v_x2_240, 1);
    V v_b_24101 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24ESet = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT2 v_t_24102 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_24100, v_z_241));
    {
      V v_field_24103 = v_t_24102.f[0];
      V v_field_24104 = v_t_24102.f[1];
      V v_x_24105 = v_field_24103;
      V v_st_24106 = v_field_24104;
      HeffT2 v_t_24107 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_b_24101, v_st_24106));
      {
        V v_field_24108 = v_t_24107.f[0];
        V v_field_24109 = v_t_24107.f[1];
        V v_x_24110 = v_field_24108;
        V v_st_24111 = v_field_24109;
        return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_2499, v_x_24105, v_x_24110}), v_st_24111}});
      }
    }
  }
  case TAG_EValues: {
    V v_es_24112 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24EValues = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    HeffT2 v_t_24113 = (g_prelude_2etraverse_24s1159166259x948777116_24cpr(v_es_24112, v_z_241));
    {
      V v_field_24114 = v_t_24113.f[0];
      V v_field_24115 = v_t_24113.f[1];
      V v_x_24116 = v_field_24114;
      V v_st_24117 = v_field_24115;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_240_24EValues, TAG_EValues, 1, (V[]){v_x_24116}), v_st_24117}});
    }
  }
  case TAG_EFix: {
    V v_x_24118 = heff_field(v_x2_240, 0);
    V v_b_24119 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_24120 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_b_24119, v_z_241));
    {
      V v_field_24121 = v_t_24120.f[0];
      V v_field_24122 = v_t_24120.f[1];
      V v_x_24123 = v_field_24121;
      V v_st_24124 = v_field_24122;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_240_24EFix, TAG_EFix, 2, 1ULL, (V[]){v_x_24118, v_x_24123}), v_st_24124}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_entry, 4, 0};

V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EVar = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_a_245 = heff_strCompare_lent(v_x_244, v_lit_241, 0);
    if (heff_intLt_c_lent(v_a_245, MK_INT(0LL), 2)) {
      heff_drop(v_lit_242);
      heff_drop(v_a_245);
      return heff_tag_re_n(v_ru_24e_243_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_244});
    } else {
      if (heff_intEq_c(v_a_245, MK_INT(0LL))) {
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24e_243_24EVar, 1);
        return v_lit_242;
      } else {
        heff_drop(v_lit_242);
        return heff_tag_re_n(v_ru_24e_243_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_244});
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_243, 0);
    V v_b_248 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_cell_249 = heff_tag_re_n(v_ru_24e_243_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_247, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_248, v_cell_249, MK_INT(1LL)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_243, 0);
    V v_args_2412 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2413 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_f_2411));
    V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam0, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2412));
    return heff_tag_at_n(v_ru_24e_243_24EApp, TAG_EApp, 2, (V[]){v_t_2413, v_t_2415});
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_e_243, 0);
    V v_a_2417 = heff_field(v_e_243, 1);
    V v_b_2418 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2419 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2417));
    V v_cell_2420 = heff_tag_re_n(v_ru_24e_243_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2416, v_t_2419, heff_hole()});
    V v_u_2421 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_2418, v_cell_2420, MK_INT(2LL)));
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  case TAG_ERecord: {
    V v_fs_2422 = heff_field(v_e_243, 0);
    V v_ts_2423 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam1, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_fs_2422));
    return heff_tag_re_n(v_ru_24e_243_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_t_2428, v_ts_2423});
  }
  case TAG_EProj: {
    V v_e2_2429 = heff_field(v_e_243, 0);
    V v_l_2430 = heff_field(v_e_243, 1);
    V v_sh_2431 = heff_field(v_e_243, 2);
    V v_t_2432 = heff_field(v_e_243, 3);
    V v_ru_24e_243_24EProj = heff_take_reuse_n(v_e_243, 15ULL, 4);
    V v_t_2433 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, v_lit_242, v_e2_2429));
    return heff_tag_re_n(v_ru_24e_243_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_t_2433, v_l_2430, v_sh_2431, v_t_2432});
  }
  case TAG_ETag: {
    V v_t_2434 = heff_field(v_e_243, 0);
    V v_args_2435 = heff_field(v_e_243, 1);
    V v_ts_2436 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ETag = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam2, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2435));
    return heff_tag_re_n(v_ru_24e_243_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2434, v_t_2438, v_ts_2436});
  }
  case TAG_EMatch: {
    V v_s_2439 = heff_field(v_e_243, 0);
    V v_arms_2440 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2441 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_s_2439));
    V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam3, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_arms_2440));
    return heff_tag_at_n(v_ru_24e_243_24EMatch, TAG_EMatch, 2, (V[]){v_t_2441, v_t_2447});
  }
  case TAG_EPrim: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EPrimCall: {
    V v_p_2449 = heff_field(v_e_243, 0);
    V v_args_2450 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam4, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2450));
    return heff_tag_re_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_p_2449, v_t_2452});
  }
  case TAG_ECall: {
    V v_g_2453 = heff_field(v_e_243, 0);
    V v_args_2454 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam5, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2454));
    return heff_tag_re_n(v_ru_24e_243_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2453, v_t_2456});
  }
  case TAG_EInt: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EFloat: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EStr: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EBytes: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EFixed: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EFloat32: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EAbandon: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EBool: {
    V v_c_2464 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EBool = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_t_2466 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam6, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_c_2464));
    return heff_tag_at_n(v_ru_24e_243_24EBool, TAG_EBool, 1, (V[]){v_t_2466});
  }
  case TAG_ESet: {
    V v_xs_2467 = heff_field(v_e_243, 0);
    V v_a_2468 = heff_field(v_e_243, 1);
    V v_b_2469 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ESet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2470 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2468));
    V v_cell_2471 = heff_tag_re_n(v_ru_24e_243_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_2467, v_t_2470, heff_hole()});
    V v_u_2472 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_2469, v_cell_2471, MK_INT(2LL)));
    heff_drop(v_u_2472);
    return v_cell_2471;
  }
  case TAG_EValues: {
    V v_es_2473 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EValues = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_t_2475 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam7, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_es_2473));
    return heff_tag_at_n(v_ru_24e_243_24EValues, TAG_EValues, 1, (V[]){v_t_2475});
  }
  case TAG_EFix: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam0(V self, V *args) {
  V v_a_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam1(V self, V *args) {
  V v_p_2424 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_p_2424)) {
  case TAG_MkPair: {
    V v_l_2425 = heff_field(v_p_2424, 0);
    V v_e2_2426 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24MkPair = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    heff_clo_take(self, 3);
    V v_t_2427 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_e2_2426; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_re_n(v_ru_24p_2424_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_2425, v_t_2427});
  }
  default: return heff_nomatch(v_p_2424);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam2(V self, V *args) {
  V v_a_2437 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2437; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam3(V self, V *args) {
  V v_a_2442 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_a_2442)) {
  case TAG_MkArm: {
    V v_t_2443 = heff_field(v_a_2442, 0);
    V v_vs_2444 = heff_field(v_a_2442, 1);
    V v_b_2445 = heff_field(v_a_2442, 2);
    V v_ru_24a_2442_24MkArm = heff_take_reuse_n(v_a_2442, 7ULL, 3);
    heff_clo_take(self, 3);
    V v_t_2446 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_b_2445; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_re_n(v_ru_24a_2442_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2443, v_vs_2444, v_t_2446});
  }
  default: return heff_nomatch(v_a_2442);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam4(V self, V *args) {
  V v_a_2451 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2451; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam5(V self, V *args) {
  V v_a_2455 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2455; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam6(V self, V *args) {
  V v_a_2465 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2465; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_lam7(V self, V *args) {
  V v_a_2474 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2474; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_entry, 6, 0};

V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243, V v_d_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_246 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_a_247 = heff_strCompare_lent(v_x_246, v_lit_241, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_lit_242);
      heff_drop(v_a_247);
      return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EVar, 1, (V[]){v_x_246}));
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_x_246);
        return heff_setField(heff_dup(v_d_244), v_i_245, v_lit_242);
      } else {
        heff_drop(v_lit_242);
        return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EVar, 1, (V[]){v_x_246}));
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_243, 0);
    V v_b_2410 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_cell_2411 = heff_tag_re_n(v_ru_24e_243_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_249, heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_244, v_i_245, v_cell_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2410;
    V t_4 = v_u_2412;
    V t_5 = MK_INT(1LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_243, 0);
    V v_args_2414 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2415 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_f_2413));
    V v_t_2417 = (g_list_2emap_24tok2(v_ru_24e_243_24EApp, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam0, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2414));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2415, v_t_2417}));
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_e_243, 0);
    V v_a_2419 = heff_field(v_e_243, 1);
    V v_b_2420 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2419));
    V v_cell_2422 = heff_tag_re_n(v_ru_24e_243_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2418, v_t_2421, heff_hole()});
    V v_u_2423 = heff_setFieldPeek(v_d_244, v_i_245, v_cell_2422);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2420;
    V t_4 = v_u_2423;
    V t_5 = MK_INT(2LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_e_243, 0);
    V v_ts_2425 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24tok2(v_ru_24e_243_24ERecord, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam1, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_fs_2424));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2430, v_ts_2425}));
  }
  case TAG_EProj: {
    V v_e2_2431 = heff_field(v_e_243, 0);
    V v_l_2432 = heff_field(v_e_243, 1);
    V v_sh_2433 = heff_field(v_e_243, 2);
    V v_t_2434 = heff_field(v_e_243, 3);
    heff_take_n(v_e_243, 15ULL, 4);
    V v_t_2435 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, v_lit_242, v_e2_2431));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2435, v_l_2432, v_sh_2433, v_t_2434}));
  }
  case TAG_ETag: {
    V v_t_2436 = heff_field(v_e_243, 0);
    V v_args_2437 = heff_field(v_e_243, 1);
    V v_ts_2438 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam2, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2437));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2436, v_t_2440, v_ts_2438}));
  }
  case TAG_EMatch: {
    V v_s_2441 = heff_field(v_e_243, 0);
    V v_arms_2442 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2443 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_s_2441));
    V v_t_2449 = (g_list_2emap_24tok2(v_ru_24e_243_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam3, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_arms_2442));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2443, v_t_2449}));
  }
  case TAG_EPrim: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EPrimCall: {
    V v_p_2451 = heff_field(v_e_243, 0);
    V v_args_2452 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2454 = (g_list_2emap_24tok2(v_ru_24e_243_24EPrimCall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam4, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2452));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2451, v_t_2454}));
  }
  case TAG_ECall: {
    V v_g_2455 = heff_field(v_e_243, 0);
    V v_args_2456 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2458 = (g_list_2emap_24tok2(v_ru_24e_243_24ECall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam5, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2456));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2455, v_t_2458}));
  }
  case TAG_EInt: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EFloat: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EStr: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EBytes: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EFixed: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EFloat32: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EAbandon: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  case TAG_EBool: {
    V v_c_2466 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2468 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam6, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_c_2466));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EBool, 1, (V[]){v_t_2468}));
  }
  case TAG_ESet: {
    V v_xs_2469 = heff_field(v_e_243, 0);
    V v_a_2470 = heff_field(v_e_243, 1);
    V v_b_2471 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ESet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2472 = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2470));
    V v_cell_2473 = heff_tag_re_n(v_ru_24e_243_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_2469, v_t_2472, heff_hole()});
    V v_u_2474 = heff_setFieldPeek(v_d_244, v_i_245, v_cell_2473);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2471;
    V t_4 = v_u_2474;
    V t_5 = MK_INT(2LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2475 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam7, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_es_2475));
    return heff_setField(heff_dup(v_d_244), v_i_245, heff_tag_n(TAG_EValues, 1, (V[]){v_t_2477}));
  }
  case TAG_EFix: {
    heff_drop(v_lit_242);
    return heff_setField(heff_dup(v_d_244), v_i_245, v_e_243);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps(a0, a1, a[2], a[3], a4, a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam0(V self, V *args) {
  V v_a_2416 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2416; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_p_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_p_2426, 0);
    V v_e2_2428 = heff_field(v_p_2426, 1);
    V v_ru_24p_2426_24MkPair = heff_take_reuse_n(v_p_2426, 3ULL, 2);
    heff_clo_take(self, 3);
    V v_t_2429 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_e2_2428; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_re_n(v_ru_24p_2426_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_2427, v_t_2429});
  }
  default: return heff_nomatch(v_p_2426);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2439; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam3(V self, V *args) {
  V v_a_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_field(v_a_2444, 0);
    V v_vs_2446 = heff_field(v_a_2444, 1);
    V v_b_2447 = heff_field(v_a_2444, 2);
    V v_ru_24a_2444_24MkArm = heff_take_reuse_n(v_a_2444, 7ULL, 3);
    heff_clo_take(self, 3);
    V v_t_2448 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_b_2447; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_re_n(v_ru_24a_2444_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2445, v_vs_2446, v_t_2448});
  }
  default: return heff_nomatch(v_a_2444);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam4(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2453; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam5(V self, V *args) {
  V v_a_2457 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2457; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam6(V self, V *args) {
  V v_a_2467 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2467; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_24dps_lam7(V self, V *args) {
  V v_a_2476 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2476; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam22(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_entry, 1, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_240, 0);
    V v_b_246 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_247 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_g_2412 = heff_field(v_x2_240, 0);
    V v_args_2413 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2414 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_g_2412));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam3, 1, 2, (V[]){v_m_2414, v_args_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_a_2424 = heff_field(v_x2_240, 1);
    V v_b_2425 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2426 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_a_2424));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam4, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2435 = heff_field(v_x2_240, 0);
    V v_ts_2436 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s1259852701x334693366(v_fs_2435));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam5, 1, 2, (V[]){v_m_2437, v_ts_2436});
  }
  case TAG_EProj: {
    V v_e_2442 = heff_field(v_x2_240, 0);
    V v_l_2443 = heff_field(v_x2_240, 1);
    V v_sh_2444 = heff_field(v_x2_240, 2);
    V v_t_2445 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_m_2446 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_e_2442));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam6, 1, 4, (V[]){v_m_2446, v_l_2443, v_sh_2444, v_t_2445});
  }
  case TAG_ETag: {
    V v_t_2451 = heff_field(v_x2_240, 0);
    V v_args_2452 = heff_field(v_x2_240, 1);
    V v_ts_2453 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2454 = (g_prelude_2etraverse_24s259655739x790043950(v_args_2452));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam7, 1, 3, (V[]){v_m_2454, v_t_2451, v_ts_2453});
  }
  case TAG_EMatch: {
    V v_s_2459 = heff_field(v_x2_240, 0);
    V v_arms_2460 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2461 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_s_2459));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam8, 1, 2, (V[]){v_m_2461, v_arms_2460});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EPrimCall: {
    V v_p_2473 = heff_field(v_x2_240, 0);
    V v_args_2474 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2475 = (g_prelude_2etraverse_24s259655739x790043950(v_args_2474));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam10, 1, 2, (V[]){v_m_2475, v_p_2473});
  }
  case TAG_ECall: {
    V v_g_2480 = heff_field(v_x2_240, 0);
    V v_args_2481 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2482 = (g_prelude_2etraverse_24s259655739x790043950(v_args_2481));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam11, 1, 2, (V[]){v_m_2482, v_g_2480});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam12, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBool: {
    V v_c_24101 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24102 = (g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(v_c_24101));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam19, 1, 1, (V[]){v_m_24102});
  }
  case TAG_ESet: {
    V v_xs_24107 = heff_field(v_x2_240, 0);
    V v_a_24108 = heff_field(v_x2_240, 1);
    V v_b_24109 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_24110 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_a_24108));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam20, 1, 3, (V[]){v_m_24110, v_b_24109, v_xs_24107});
  }
  case TAG_EValues: {
    V v_es_24119 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24120 = (g_prelude_2etraverse_24s259655739x790043950(v_es_24119));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam21, 1, 1, (V[]){v_m_24120});
  }
  case TAG_EFix: {
    V v_x_24125 = heff_field(v_x2_240, 0);
    V v_b_24126 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24127 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_b_24126));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam22, 1, 2, (V[]){v_m_24127, v_x_24125});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849(a[0]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_242});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_244});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_args_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = (g_prelude_2etraverse_24s259655739x790043950(v_args_2413));
    V v_x2_2420 = heff_tr(heff_call(v_t_2419, 1, (V[]){v_n_2418}));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_n_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_EApp, 2, (V[]){v_x_2417, v_x_2421}), v_n_2422});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam4(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_t_2431 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_b_2425));
    V v_x2_2432 = heff_tr(heff_call(v_t_2431, 1, (V[]){v_n_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_n_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, v_x_2429, v_x_2433}), v_n_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam5(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_ts_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2440, v_ts_2436}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam6(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_l_2443 = heff_env(self)[1];
  V v_sh_2444 = heff_env(self)[2];
  V v_t_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2449, v_l_2443, v_sh_2444, v_t_2445}), v_n_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam7(V self, V *args) {
  V v_n_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_t_2451 = heff_env(self)[1];
  V v_ts_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2456 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_n_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2451, v_x_2457, v_ts_2453}), v_n_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam8(V self, V *args) {
  V v_n_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_arms_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_n_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    HeffT2 v_t_2466 = (g_prelude_2etraverse_24s1776038734x825611929_24cpr(v_arms_2460, v_n_2465));
    {
      V v_field_2467 = v_t_2466.f[0];
      V v_field_2468 = v_t_2466.f[1];
      V v_x_2469 = v_field_2467;
      V v_n_2470 = v_field_2468;
      return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2464, v_x_2469}), v_n_2470});
    }
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam9(V self, V *args) {
  V v_n_2472 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2472});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam10(V self, V *args) {
  V v_n_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_p_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2477 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_n_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_n_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2477_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2473, v_x_2478}), v_n_2479});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam11(V self, V *args) {
  V v_n_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_g_2480 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_n_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2480, v_x_2485}), v_n_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam12(V self, V *args) {
  V v_n_2488 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2488});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam13(V self, V *args) {
  V v_n_2490 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2490});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam14(V self, V *args) {
  V v_n_2492 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam15(V self, V *args) {
  V v_n_2494 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2494});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam16(V self, V *args) {
  V v_n_2497 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2497});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam17(V self, V *args) {
  V v_n_2499 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2499});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam18(V self, V *args) {
  V v_n_24100 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24100});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam19(V self, V *args) {
  V v_n_24103 = args[0];
  V v_m_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24104 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_n_24103}));
  switch (heff_tag_of(v_x2_24104)) {
  case TAG_MkPair: {
    V v_x_24105 = heff_field(v_x2_24104, 0);
    V v_n_24106 = heff_field(v_x2_24104, 1);
    V v_ru_24x2_24104_24MkPair = heff_take_reuse_n(v_x2_24104, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24104_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24105}), v_n_24106});
  }
  default: return heff_nomatch(v_x2_24104);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam20(V self, V *args) {
  V v_n_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  V v_b_24109 = heff_env(self)[1];
  V v_xs_24107 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_n_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_n_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    V v_t_24115 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_b_24109));
    V v_x2_24116 = heff_tr(heff_call(v_t_24115, 1, (V[]){v_n_24114}));
    switch (heff_tag_of(v_x2_24116)) {
    case TAG_MkPair: {
      V v_x_24117 = heff_field(v_x2_24116, 0);
      V v_n_24118 = heff_field(v_x2_24116, 1);
      heff_take_n(v_x2_24116, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24107, v_x_24113, v_x_24117}), v_n_24118});
    }
    default: return heff_nomatch(v_x2_24116);
    }
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam21(V self, V *args) {
  V v_n_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_n_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_n_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24123}), v_n_24124});
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s710960789x476183849_lam22(V self, V *args) {
  V v_n_24128 = args[0];
  V v_m_24127 = heff_env(self)[0];
  V v_x_24125 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24129 = heff_tr(heff_call(v_m_24127, 1, (V[]){v_n_24128}));
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_n_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24129_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24125, v_x_24130}), v_n_24131});
  }
  default: return heff_nomatch(v_x2_24129);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps(V v_lit_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_244 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_244);
  }
  case TAG_EGlobal: {
    V v_t_246 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_246);
  }
  case TAG_ELam: {
    V v_t_249 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_249);
  }
  case TAG_EApp: {
    V v_t_2412 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2412);
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_e_241, 0);
    V v_a_2414 = heff_field(v_e_241, 1);
    V v_b_2415 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2416 = heff_tag_re_n(v_ru_24e_241_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_x_2413, v_a_2414, heff_hole()});
    V v_u_2417 = heff_setFieldPeek(v_d_242, MK_INT(2LL), v_cell_2416);
    V t_0 = v_lit_240;
    V t_1 = v_b_2415;
    V t_2 = v_u_2417;
    v_lit_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2420 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2420);
  }
  case TAG_EProj: {
    V v_t_2425 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2425);
  }
  case TAG_ETag: {
    V v_t_2429 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2429);
  }
  case TAG_EMatch: {
    V v_s_2430 = heff_field(v_e_241, 0);
    V v_arms_2431 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2437 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_lam0, 1, 1, (V[]){heff_dup(v_lit_240)}), v_arms_2431));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2430, v_t_2437}));
  }
  case TAG_EPrim: {
    V v_t_2439 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2439);
  }
  case TAG_EPrimCall: {
    V v_t_2442 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2442);
  }
  case TAG_ECall: {
    V v_t_2445 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2445);
  }
  case TAG_EInt: {
    V v_t_2447 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2447);
  }
  case TAG_EFloat: {
    V v_t_2449 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2449);
  }
  case TAG_EStr: {
    V v_t_2451 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2451);
  }
  case TAG_EBytes: {
    V v_t_2453 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2453);
  }
  case TAG_EFixed: {
    V v_t_2456 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2456);
  }
  case TAG_EFloat32: {
    V v_t_2458 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2458);
  }
  case TAG_EAbandon: {
    V v_t_2459 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2459);
  }
  case TAG_EBool: {
    V v_t_2461 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2461);
  }
  case TAG_ESet: {
    V v_xs_2462 = heff_field(v_e_241, 0);
    V v_a_2463 = heff_field(v_e_241, 1);
    V v_b_2464 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2465 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2462, v_a_2463, heff_hole()});
    V v_u_2466 = heff_setFieldPeek(v_d_242, MK_INT(2LL), v_cell_2465);
    V t_0 = v_lit_240;
    V t_1 = v_b_2464;
    V t_2 = v_u_2466;
    v_lit_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_EValues: {
    V v_t_2468 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2468);
  }
  case TAG_EFix: {
    V v_t_2471 = (g_heff_2ecompile_2eonce_2emoved(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2471);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198_24dps_lam0(V self, V *args) {
  V v_x2_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkArm: {
    V v_t_2433 = heff_field(v_x2_2432, 0);
    V v_vs_2434 = heff_field(v_x2_2432, 1);
    V v_b_2435 = heff_field(v_x2_2432, 2);
    V v_ru_24x2_2432_24MkArm = heff_take_reuse_n(v_x2_2432, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2436 = ({ V a_0 = v_lit_240; V a_1 = v_b_2435; V r_ = (g_heff_2ecompile_2eir_2ewaysMap_24s852347399x1686019198(a_0, a_1)); heff_drop(v_lit_240); r_; });
    return heff_tag_re_n(v_ru_24x2_2432_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2433, v_vs_2434, v_t_2436});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
Clo g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884_entry, 2, 0};

V g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_arms_243 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x21_242, 2);
      V v_t_247;
      if ((heff_dup(v_acc_241) == NTAG(TAG_True))) {
        heff_drop(v_acc_241);
        v_t_247 = NTAG(TAG_True);
      } else {
        heff_drop(v_acc_241);
        v_t_247 = (g_heff_2ecompile_2erunes_2ereads(heff_dup(v_b_246)));
      }
      V t_0 = v_arms_243;
      V t_1 = v_t_247;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699_entry, 2, 0};

V g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ecompile_2eworlds_2eworldsIn(heff_dup(v_e_242), v_acc_241));
    V t_0 = v_es_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349_entry, 2, 0};

V g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_arms_243 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x21_242, 2);
      V v_t_247 = (g_heff_2ecompile_2eworlds_2eworldsIn(heff_dup(v_b_246), v_acc_241));
      V t_0 = v_arms_243;
      V t_1 = v_t_247;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349(a0, a[1]); heff_drop(a0); return r;
}