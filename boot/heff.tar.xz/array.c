// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_array_2eempty_lam0(V self, V *args); static Clo g_array_2eempty_lam0_clo = {{0x80000000u, K_CLO, 0}, g_array_2eempty_lam0, 1, 0};

static V g_array_2eempty_val;
static int g_array_2eempty_st;
static V g_array_2eempty_init(void) {
  return heff_arrayGenerate(MK_INT(0LL), ((V)&g_array_2eempty_lam0_clo));
}
V g_array_2eempty_get(void) {
  if (g_array_2eempty_st == 2) return g_array_2eempty_val;
  if (g_array_2eempty_st == 1) heff_fail("defined by itself");
  g_array_2eempty_st = 1;
  g_array_2eempty_val = heff_tr(g_array_2eempty_init());
  g_array_2eempty_st = 2;
  return g_array_2eempty_val;
}
V g_array_2eempty_lam0(V self, V *args) {
  V v_x_240 = args[0];
  heff_drop(self);
  heff_drop(v_x_240);
  return heff_abandon();
}
Clo g_array_2efoldlFrom_clo = {{0x80000000u, K_CLO, 0}, g_array_2efoldlFrom_entry, 4, 0};

V g_array_2efoldlFrom(V v_f_240, V v_i_241, V v_acc_242, V v_xs_243) {
top: ;
  V v_t_244 = heff_intLt(heff_dup(v_i_241), heff_arrayLength(heff_dup(v_xs_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    V v_t_245 = heff_arrayIndex(heff_dup(v_xs_243), heff_dup(v_i_241));
    V v_t_246 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_acc_242, v_t_245}));
    V t_0 = v_f_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_246;
    V t_3 = v_xs_243;
    v_f_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    v_xs_243 = t_3;
    goto top;
  }
  case TAG_False: {
    heff_drop(v_f_240);
    heff_drop(v_i_241);
    heff_drop(v_xs_243);
    heff_drop(v_t_244);
    return v_acc_242;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_array_2efoldlFrom_entry(V self, V *a) {
  (void)self;
  return g_array_2efoldlFrom(a[0], a[1], a[2], a[3]);
}