// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_array_2eempty_get(void);
V g_array_2efoldlFrom(V, V, V, V);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_array_2efoldlFrom_24s2074357832x1065736523(V, V, V, V, V);
V g_array_2efoldlFrom_24s2074357832x1065736523_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_24s2074357832x1065736523_clo;
V g_heff_2esyntax_2efmt_2etokens_2estep(V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estep_clo;
V g_array_2eempty_lam0(V self, V *args); static Clo g_array_2eempty_lam0_clo = {{0x80000000u, K_CLO, 0}, g_array_2eempty_lam0, 1, 0};

static V g_array_2eempty_val;
static HEFF_ONCE g_array_2eempty_st;
static V g_array_2eempty_init(void) {
  return heff_arrayGenerate(MK_INT(0LL), ((V)&g_array_2eempty_lam0_clo));
}
V g_array_2eempty_get(void) {
  if (HEFF_DONE(g_array_2eempty_st)) return g_array_2eempty_val;
  return heff_global(&g_array_2eempty_val, &g_array_2eempty_st, g_array_2eempty_init);
}
V g_array_2eempty_lam0(V self, V *args) {
  V v_x_240 = args[0];
  heff_drop(v_x_240);
  return heff_abandon();
}
Clo g_array_2efoldlFrom_clo = {{0x80000000u, K_CLO, 0}, g_array_2efoldlFrom_entry, 4, 0};

V g_array_2efoldlFrom(V v_f_240, V v_box_24i_241, V v_acc_242, V v_xs_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_xs_243, 0)))) {
    V v_t_245 = heff_arrayIndex_lent(v_xs_243, heff_box_word(v_i_241), 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_acc_242, v_t_245}));
    V t_0 = v_f_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_246;
    V t_3 = v_xs_243;
    v_f_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    v_xs_243 = t_3;
    goto top;
  } else {
    heff_drop(v_f_240);
    return v_acc_242;
  }
}
V g_array_2efoldlFrom_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_array_2efoldlFrom(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_array_2efoldlFrom_24s2074357832x1065736523_clo = {{0x80000000u, K_CLO, 0}, g_array_2efoldlFrom_24s2074357832x1065736523_entry, 5, 0};

V g_array_2efoldlFrom_24s2074357832x1065736523(V v_lit_240, V v_lit_241, V v_box_24i_242, V v_acc_243, V v_xs_244) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_xs_244, 0)))) {
    V v_a_246 = heff_arrayIndex_lent(v_xs_244, heff_box_word(v_i_242), 2);
    V v_t_247 = (g_heff_2esyntax_2efmt_2etokens_2estep(v_lit_240, v_lit_241, v_acc_243, v_a_246));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = v_t_247;
    V t_4 = v_xs_244;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    v_xs_244 = t_4;
    goto top;
  } else {
    return v_acc_243;
  }
}
V g_array_2efoldlFrom_24s2074357832x1065736523_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_array_2efoldlFrom_24s2074357832x1065736523(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}