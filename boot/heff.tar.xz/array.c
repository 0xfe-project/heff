// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_prevEnd 2061122539
#define LBL_startLine 1642416498
#define LBL_tok 324554
V g_array_2eempty_get(void);
V g_array_2efoldlFrom(V, V, V, V);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_array_2efoldlFrom_24s2074357832x1065736523(V, V, V, V, V);
V g_array_2efoldlFrom_24s2074357832x1065736523_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_24s2074357832x1065736523_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepCmt(V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepCmt_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepTok(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_clo;
V g_array_2eempty_lam0(V self, V *args); static Clo g_array_2eempty_lam0_clo = {{0x80000000u, K_CLO, 0}, g_array_2eempty_lam0, 1, 0};

static V g_array_2eempty_val;
static HEFF_ONCE g_array_2eempty_st;
static V g_array_2eempty_init(void) {
  return heff_arrayGenerate(MK_INT(0LL), ((V)&g_array_2eempty_lam0_clo));
}
V g_array_2eempty_get(void) {
  if (HEFF_DONE(g_array_2eempty_st)) return g_array_2eempty_val;
  return heff_global(&g_array_2eempty_val, &g_array_2eempty_st, g_array_2eempty_init);
}
V g_array_2eempty_lam0(V self, V *args) {
  V v_x_240 = args[0];
  heff_drop(v_x_240);
  return heff_abandon();
}
Clo g_array_2efoldlFrom_clo = {{0x80000000u, K_CLO, 0}, g_array_2efoldlFrom_entry, 4, 0};

V g_array_2efoldlFrom(V v_f_240, V v_box_24i_241, V v_acc_242, V v_xs_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_xs_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_xs_243, heff_box_word(v_i_241), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_acc_242, v_t_244}));
      V t_0 = v_f_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_245;
      V t_3 = v_xs_243;
      v_f_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_xs_243 = t_3;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_f_240);
      return v_acc_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_xs_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_xs_243, heff_box_word(v_i_241), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_acc_242, v_t_244}));
    V t_0 = v_f_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_245;
    V t_3 = v_xs_243;
    v_f_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    v_xs_243 = t_3;
    goto top;
  } else {
    heff_drop(v_f_240);
    return v_acc_242;
  }
}
V g_array_2efoldlFrom_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_array_2efoldlFrom(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_array_2efoldlFrom_24s2074357832x1065736523_clo = {{0x80000000u, K_CLO, 0}, g_array_2efoldlFrom_24s2074357832x1065736523_entry, 5, 0};

V g_array_2efoldlFrom_24s2074357832x1065736523(V v_lit_240, V v_lit_241, V v_box_24i_242, V v_acc_243, V v_xs_244) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_xs_244, 0)))) {
      V v_a_245 = heff_arrayIndexIn_lent(v_xs_244, heff_box_word(v_i_242), 2);
      V v_src_246 = heff_dup(v_lit_240);
      V v_elems_247 = heff_dup(v_lit_241);
      V v_st_248 = v_acc_243;
      V v_e_249 = v_a_245;
      V v_t_2410 = heff_dup(heff_rfield(v_e_249, 2));
      V v_t_2414;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_src_246);
        V v_t_2411 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
        v_t_2414 = (g_heff_2esyntax_2efmt_2etokens_2estepCmt(v_elems_247, v_st_248, v_e_249, v_t_2411));
        break;
      }
      case TAG_Just: {
        V v_t_2412 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        heff_drop(v_elems_247);
        V v_t_2413 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
        v_t_2414 = ({ V a_0 = v_src_246; V a_1 = v_st_248; V a_2 = v_e_249; V a_3 = v_t_2413; V a_4 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2etokens_2estepTok(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_246); r_; });
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_2414;
      V t_4 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      v_xs_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return v_acc_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_xs_244, 0)))) {
    V v_a_245 = heff_arrayIndex_lent(v_xs_244, heff_box_word(v_i_242), 2);
    V v_src_246 = heff_dup(v_lit_240);
    V v_elems_247 = heff_dup(v_lit_241);
    V v_st_248 = v_acc_243;
    V v_e_249 = v_a_245;
    V v_t_2410 = heff_dup(heff_rfield(v_e_249, 2));
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop(v_src_246);
      V v_t_2411 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
      v_t_2414 = (g_heff_2esyntax_2efmt_2etokens_2estepCmt(v_elems_247, v_st_248, v_e_249, v_t_2411));
      break;
    }
    case TAG_Just: {
      V v_t_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      heff_drop(v_elems_247);
      V v_t_2413 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
      v_t_2414 = ({ V a_0 = v_src_246; V a_1 = v_st_248; V a_2 = v_e_249; V a_3 = v_t_2413; V a_4 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2etokens_2estepTok(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_246); r_; });
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = v_t_2414;
    V t_4 = v_xs_244;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    v_xs_244 = t_4;
    goto top;
  } else {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_acc_243;
  }
}
V g_array_2efoldlFrom_24s2074357832x1065736523_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_array_2efoldlFrom_24s2074357832x1065736523(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}