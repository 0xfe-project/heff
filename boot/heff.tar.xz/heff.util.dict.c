// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2eempty_get(void);
V g_heff_2eutil_2edict_2eempty_get(void);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;

static V g_heff_2eutil_2edict_2eempty_val;
static int g_heff_2eutil_2edict_2eempty_st;
static V g_heff_2eutil_2edict_2eempty_init(void) {
  return heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(g_array_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_array_2eempty_get())});
}
V g_heff_2eutil_2edict_2eempty_get(void) {
  if (g_heff_2eutil_2edict_2eempty_st == 2) return g_heff_2eutil_2edict_2eempty_val;
  if (g_heff_2eutil_2edict_2eempty_st == 1) heff_fail("defined by itself");
  g_heff_2eutil_2edict_2eempty_st = 1;
  g_heff_2eutil_2edict_2eempty_val = heff_tr(g_heff_2eutil_2edict_2eempty_init());
  g_heff_2eutil_2edict_2eempty_st = 2;
  return g_heff_2eutil_2edict_2eempty_val;
}
Clo g_heff_2eutil_2edict_2eindexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2edict_2eindexed_entry, 2, 0};

V g_heff_2eutil_2edict_2eindexed(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = (g_heff_2eutil_2edict_2eindexed(heff_intAdd(heff_dup(v_i_240), MK_INT(1LL)), v_rest_243));
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_244), v_i_240, v_t_246));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eutil_2edict_2eindexed(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eutil_2edict_2ezipKV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2edict_2ezipKV_entry, 2, 0};

V g_heff_2eutil_2edict_2ezipKV(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ks_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_k_242);
      heff_drop(v_ks_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_x2_241, 0);
      V v_vs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_v_244}), (g_heff_2eutil_2edict_2ezipKV(v_ks_243, v_vs_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2edict_2ezipKV(a[0], a[1]);
}