// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2eempty_get(void);
V g_heff_2eutil_2edict_2eempty_get(void);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2edict_2ezipKV_24dps(V, V, V);
V g_heff_2eutil_2edict_2ezipKV_24dps_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_24dps_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;

static V g_heff_2eutil_2edict_2eempty_val;
static HEFF_ONCE g_heff_2eutil_2edict_2eempty_st;
static V g_heff_2eutil_2edict_2eempty_init(void) {
  return heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(g_array_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_array_2eempty_get())});
}
V g_heff_2eutil_2edict_2eempty_get(void) {
  if (HEFF_DONE(g_heff_2eutil_2edict_2eempty_st)) return g_heff_2eutil_2edict_2eempty_val;
  return heff_global(&g_heff_2eutil_2edict_2eempty_val, &g_heff_2eutil_2edict_2eempty_st, g_heff_2eutil_2edict_2eempty_init);
}
Clo g_heff_2eutil_2edict_2eindexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2edict_2eindexed_entry, 2, 0};

V g_heff_2eutil_2edict_2eindexed(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = (g_heff_2eutil_2edict_2eindexed(heff_intAdd_lent(v_i_240, MK_INT(1LL), 2), v_rest_243));
      return ({ V a_0 = v_t_246; V a_1 = v_x_244; V a_2 = v_i_240; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_i_240); r_; });
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eutil_2edict_2eindexed(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eutil_2edict_2ezipKV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2edict_2ezipKV_entry, 2, 0};

V g_heff_2eutil_2edict_2ezipKV(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ks_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_k_242);
      heff_drop(v_ks_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_x2_241, 0);
      V v_vs_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_k_242, v_v_244}), heff_hole()});
      V v_u_247 = (g_heff_2eutil_2edict_2ezipKV_24dps(v_ks_243, v_vs_245, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2edict_2ezipKV(a[0], a[1]);
}
Clo g_heff_2eutil_2edict_2ezipKV_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2edict_2ezipKV_24dps_entry, 3, 0};

V g_heff_2eutil_2edict_2ezipKV_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x1_240, 0);
    V v_ks_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_k_243);
      heff_drop(v_ks_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x2_241, 0);
      V v_vs_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_k_243, v_v_245}), heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_ks_244;
      V t_1 = v_vs_246;
      V t_2 = v_u_248;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eutil_2edict_2ezipKV_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eutil_2edict_2ezipKV_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}