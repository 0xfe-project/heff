// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Catch 6517
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DTest 4640
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkDAlts 45152
#define TAG_MkSep 6724
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_POp 26877
#define TAG_PSeg 50182
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_patAtom 1586746071
#define LBL_patHead 1586939750
#define LBL_pattern 1588251091
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eanonymousSumF(V, V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase(V, V);
V g_heff_2esyntax_2ecst_2eatomBase_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_clo;
V g_heff_2esyntax_2ecst_2ebracesF(V, V, V);
V g_heff_2esyntax_2ecst_2ebracesF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edataAlternative(V, V);
V g_heff_2esyntax_2ecst_2edataAlternative_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataAlternative_clo;
V g_heff_2esyntax_2ecst_2edataDecl(V, V, V);
V g_heff_2esyntax_2ecst_2edataDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataDecl_clo;
V g_heff_2esyntax_2ecst_2edataLast(V, V, V, V);
V g_heff_2esyntax_2ecst_2edataLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataLast_clo;
V g_heff_2esyntax_2ecst_2edeclAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2edeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclAt_clo;
V g_heff_2esyntax_2ecst_2edefaultedF(V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2efirstP(V);
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstP_clo;
V g_heff_2esyntax_2ecst_2efixityRest(V, V, V);
V g_heff_2esyntax_2ecst_2efixityRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efixityRest_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2einstanceDecl(V, V, V);
V g_heff_2esyntax_2ecst_2einstanceDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einstanceDecl_clo;
V g_heff_2esyntax_2ecst_2elamBinderF(V, V, V);
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinderF_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eletStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletStmtF_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eparensF(V, V, V);
V g_heff_2esyntax_2ecst_2eparensF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo;
V g_heff_2esyntax_2ecst_2epatSegmentF(V, V, V);
V g_heff_2esyntax_2ecst_2epatSegmentF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatSegmentF_clo;
V g_heff_2esyntax_2ecst_2epatternF(V, V, V);
V g_heff_2esyntax_2ecst_2epatternF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatternF_clo;
V g_heff_2esyntax_2ecst_2eprimitiveDecl(V, V, V);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprimitiveDecl_clo;
V g_heff_2esyntax_2ecst_2ereadSumAlg(V, V);
V g_heff_2esyntax_2ecst_2ereadSumAlg_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ereadSumAlg_clo;
V g_heff_2esyntax_2ecst_2esegmentF(V, V, V);
V g_heff_2esyntax_2ecst_2esegmentF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2estatementF(V, V, V);
V g_heff_2esyntax_2ecst_2estatementF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estatementF_clo;
V g_heff_2esyntax_2ecst_2etheoryDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etheoryDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryDecl_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2etypeDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etypeDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etypeDecl_clo;
V g_heff_2esyntax_2ecst_2eupdateF(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eupdateF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateF_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF(V, V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efind_24s1236173780x2048419812(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efind_24s1236173780x2048419812_entry(V self, V *a);
extern Clo g_list_2efind_24s1236173780x2048419812_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2esyntax_2ecst_2ereadSumAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadSumAlg_entry, 2, 0};

V g_heff_2esyntax_2ecst_2ereadSumAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_s2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_s2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_d_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_d_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_c_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      heff_take_n(v_q_247, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24InR, 1);
      V v_r_2411 = heff_tr(heff_call(v_c_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_r_2411)) {
      case TAG_MkPair: {
        V v_r1_2412 = heff_dup(heff_field(v_r_2411, 0));
        V v_st_2413 = heff_dup(heff_field(v_r_2411, 1));
        switch (heff_tag_of(v_r1_2412)) {
        case TAG_Left: {
          V v_d_2414 = heff_field(v_r1_2412, 0);
          heff_take_n(v_r1_2412, 1ULL, 1);
          heff_drop_tag(v_r_2411, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_d_2414, v_st_2413});
        }
        case TAG_Right: {
          heff_take_n(v_r1_2412, 0ULL, 1);
          heff_drop(v_h_2410);
          heff_drop(v_st_2413);
          return v_r_2411;
        }
        default: return heff_nomatch(v_r1_2412);
        }
      }
      default: return heff_nomatch(v_r_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2ereadSumAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ereadSumAlg(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2einBrackets_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einBrackets_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einBrackets_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2einBrackets_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einBrackets_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einBrackets_lam4, 1, 0};
V g_heff_2esyntax_2ecst_2einBrackets_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2einBrackets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einBrackets_entry, 3, 0};

V g_heff_2esyntax_2ecst_2einBrackets(V v_p_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einBrackets_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam1, 1, 3, (V[]){v_hd_241, v_p_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2einBrackets(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2einBrackets_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(-1LL), heff_take_field(v_s_243, 3)});
  return ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_243, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2einBrackets_lam4(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2413 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2412, 3)));
  return ({ V rv_3 = v_k_2413; V rr_ = heff_rec_reuse_nf(v_s_2412, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2einBrackets_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V f_ = v_k_242;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2einBrackets_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam6, 1, 2, (V[]){v_k_242, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einBrackets_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einBrackets_lam4_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam5, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einBrackets_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  V f_ = v_p_240;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam3, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einBrackets_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_p_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam2, 1, 3, (V[]){v_p_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_str0, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_str1, 1, "}");
V g_heff_2esyntax_2ecst_2eupdateF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateF_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eupdateF(V v_g_240, V v_o_241, V v_r_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_lam0, 1, 5, (V[]){v_g_240, v_hd_243, v_o_241, v_r_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eupdateF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eupdateF_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_o_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSep: {
    V v_items_2411 = heff_field(v_x_249, 0);
    V v_seps_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    v_t_2413 = heff_tag_n(TAG_Update, 6, (V[]){v_o_241, v_r_242, v_x_245, v_items_2411, v_seps_2412, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_244;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateF_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_o_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eupdateF_str1), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_lam3, 1, 5, (V[]){v_x_249, v_o_241, v_r_242, v_x_245, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eupdateF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_o_241 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eupdateF_str0), v_p_246, v_t_248, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_lam2, 1, 5, (V[]){v_hd_243, v_o_241, v_r_242, v_x_245, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eupdateF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_o_241 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_p_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_clo), 1, (V[]){v_g_240}));
  V f_ = heff_dup(v_p_246);
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_lam1, 1, 6, (V[]){v_p_246, v_hd_243, v_o_241, v_r_242, v_x_245, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str1, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str2, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str3, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str6, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str7, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str8, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str9, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str10, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str11, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str12, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str13, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str14, 1, "}");
V g_heff_2esyntax_2ecst_2ebracesF_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ebracesF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2ebracesF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam20(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam22(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam21(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebracesF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ebracesF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ebracesF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebracesF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam3(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam8(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_InstB, 5, (V[]){v_x_243, v_x_2416, v_x_2417, v_x_2418, v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str3), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam8, 1, 5, (V[]){v_k_245, v_x_243, v_x_2416, v_x_2417, v_x_2418})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str2), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam7, 1, 5, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_get_n(v_g_240, 0, 13), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam6, 1, 4, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_243, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2421});
  V f_ = v_k_245;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam13(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_EFSet, 3, (V[]){v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam12(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam13, 1, 3, (V[]){v_k_2425, v_x_2426, v_x_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_lam11(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ebracesF_str6), heff_dup(v_hd_2424), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam12, 1, 4, (V[]){v_g_240, v_hd_2424, v_k_2425, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam10(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2424), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam11, 1, 3, (V[]){v_hd_2424, v_g_240, v_k_2425})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam16(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2436;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_MkSep: {
    V v_items_2434 = heff_field(v_x_2432, 0);
    V v_seps_2435 = heff_field(v_x_2432, 1);
    heff_take_n(v_x_2432, 3ULL, 2);
    v_t_2436 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_243, v_items_2434, v_seps_2435, v_x_2433});
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  V f_ = v_k_245;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam15(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str8), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam16, 1, 3, (V[]){v_x_2432, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam14(V self, V *args) {
  V v_x_2430 = args[0];
  V v_p_2429 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2ebracesF_str7), v_p_2429, v_t_2431, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam15, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam20(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2448;
  switch (heff_tag_of(v_x_2444)) {
  case TAG_MkSep: {
    V v_items_2446 = heff_field(v_x_2444, 0);
    V v_seps_2447 = heff_field(v_x_2444, 1);
    heff_take_n(v_x_2444, 3ULL, 2);
    v_t_2448 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_243, v_items_2446, v_seps_2447, v_x_2445});
    break;
  }
  default: heff_nomatch(v_x_2444);
  }
  V f_ = v_k_245;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam19(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str12), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam20, 1, 3, (V[]){v_x_2444, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam22(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2450 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2454;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkSep: {
    V v_items_2452 = heff_field(v_x_2450, 0);
    V v_seps_2453 = heff_field(v_x_2450, 1);
    heff_take_n(v_x_2450, 3ULL, 2);
    v_t_2454 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_243, v_items_2452, v_seps_2453, v_x_2451});
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V f_ = v_k_245;
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam21(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str14), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam22, 1, 3, (V[]){v_x_2450, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam18(V self, V *args) {
  V v_x_2440 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2440, 0)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str9))) {
    if (heff_strEq_c(heff_get_n(v_x_2440, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str10))) {
      return (g_heff_2esyntax_2ecst_2eupdateF(v_g_240, v_x_243, v_x_2437, v_hd_244, v_k_245));
    } else {
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2437, NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(v_g_240, ((V)&g_heff_2esyntax_2ecst_2ebracesF_str11), v_t_2443, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam19, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
    }
  } else {
    heff_drop_rec(v_x_2440, 9);
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2437, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(v_g_240, ((V)&g_heff_2esyntax_2ecst_2ebracesF_str13), v_t_2449, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam21, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_lam17(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2438}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2439;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam18, 1, 5, (V[]){v_g_240, v_x_243, v_x_2437, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_248, 1)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str1))));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2413, 9);
    heff_drop_rec(v_x_248, 9);
    heff_drop(v_t_2415);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam5, 1, 4, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243})));
  } else {
    heff_drop(v_t_2415);
    if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str4))) {
      heff_drop_rec(v_x_2413, 9);
      heff_drop_rec(v_g_240, 13);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam9, 1, 2, (V[]){v_x_243, v_k_245})));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2413, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str5))) {
        V v_p_2429 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam10, 2, 1, (V[]){v_g_240});
        V f_ = heff_dup(v_p_2429);
        heff_room[0] = heff_dup(v_hd_244);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam14, 1, 4, (V[]){v_p_2429, v_hd_244, v_x_243, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        return (g_heff_2esyntax_2ecst_2edefaultedF(heff_dup(v_g_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam17, 1, 4, (V[]){v_hd_244, v_g_240, v_x_243, v_k_245})));
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ebracesF_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam4, 1, 5, (V[]){v_x_248, v_hd_244, v_g_240, v_k_245, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam2, 1, 4, (V[]){v_hd_244, v_g_240, v_k_245, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam1, 2, 2, (V[]){v_g_240, v_x_243}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str3, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str4, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str7, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str8, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str9, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str10, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str11, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str12, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str14, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str15, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str16, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str17, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str18, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str19, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str20, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str21, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str22, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str24, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str25, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str26, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str27, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str28, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str29, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str30, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str31, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str32, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str33, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str34, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str35, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str37, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str38, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str39, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str40, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str41, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str43, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomBase_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_lam6(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomBase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomBase(V v_g_240, V v_t_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_241, 0))}));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str2), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str4), v_t_244})});
  V v_t_246 = ({ V a_0 = v_t_242; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str5), v_t_245}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2416;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_2416 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_246);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str6))) {
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_241, 1))}));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str7), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str9), v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str11), v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str13), v_t_2411})});
      V v_t_2413 = ({ V a_0 = v_t_248; V a_1 = v_t_2412; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2412, 2); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        v_t_2416 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2413);
        V v_x3_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str14); V a_1 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str15); V a_2 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str16); V a_3 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str17); V a_4 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str18); V a_5 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str19); V a_6 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str20); V a_7 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str21); V a_8 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str22); V a_9 = heff_dup(heff_rfield(v_t_241, 1)); V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind_24s1236173780x2048419812(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
        switch (heff_tag_of(v_x3_2414)) {
        case TAG_Nothing: {
          v_t_2416 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2414, 0ULL, 1);
          v_t_2416 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_2414);
        }
      }
    } else {
      v_t_2416 = NTAG(TAG_False);
    }
  }
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop_rec(v_g_240, 13);
    heff_drop_rec(v_t_241, 9);
    heff_drop(v_t_2416);
    return ((V)&g_heff_2esyntax_2ecst_2eatomBase_lam0_clo);
  } else {
    heff_drop(v_t_2416);
    V v_t_2421 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str23)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str24))));
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_241, 9);
      heff_drop(v_t_2421);
      return heff_tail(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_clo), 1, (V[]){v_g_240});
    } else {
      heff_drop(v_t_2421);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str25))) {
        heff_drop_rec(v_t_241, 9);
        return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam2, 2, 1, (V[]){v_g_240});
      } else {
        V v_t_2428 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str26)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str27))));
        if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
          heff_drop_rec(v_t_241, 9);
          heff_drop(v_t_2428);
          return heff_tail(((V)&g_heff_2esyntax_2ecst_2eparensF_clo), 1, (V[]){v_g_240});
        } else {
          heff_drop(v_t_2428);
          V v_t_2430 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str28)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str29))));
          if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_241, 9);
            heff_drop(v_t_2430);
            return heff_tail(((V)&g_heff_2esyntax_2ecst_2ebracesF_clo), 1, (V[]){v_g_240});
          } else {
            heff_drop(v_t_2430);
            V v_t_2432 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str30)) && heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str31))));
            if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
              heff_drop_rec(v_t_241, 9);
              heff_drop(v_t_2432);
              return heff_tail(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo), 1, (V[]){heff_get_n(v_g_240, 0, 13)});
            } else {
              heff_drop(v_t_2432);
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str32))) {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str33))) {
                  heff_drop_rec(v_t_241, 9);
                  V v_t_2435 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2esegmentF_clo), 1, (V[]){v_g_240}));
                  return heff_tail(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo), 1, (V[]){v_t_2435});
                } else {
                  heff_drop_rec(v_g_240, 13);
                  return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam5, 2, 1, (V[]){v_t_241});
                }
              } else {
                heff_drop_rec(v_g_240, 13);
                return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam6, 2, 1, (V[]){v_t_241});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomBase_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomBase(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomBase_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2417, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam1, 1, 1, (V[]){v_k_2418})));
}
V g_heff_2esyntax_2ecst_2eatomBase_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_ENeg, 2, (V[]){v_x_2425, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_g_240, 4, 13);
  heff_room[0] = v_hd_2423;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam4, 1, 2, (V[]){v_k_2424, v_x_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eatomBase_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2423), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam3, 1, 3, (V[]){v_g_240, v_hd_2423, v_k_2424})));
}
V g_heff_2esyntax_2ecst_2eatomBase_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str34))) {
    v_t_2440 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str35);
  } else {
    V v_t_2439 = heff_strAppend(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str36));
    v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_str37), v_t_2439);
  }
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_str38), v_t_2440), v_t_2441, NTAG(TAG_Nothing)});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){v_t_2443}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2444;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_lam6(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k2_2446 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str39))) {
    v_t_2449 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str40);
  } else {
    V v_t_2448 = heff_strAppend(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str41));
    v_t_2449 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_str42), v_t_2448);
  }
  V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_str43), v_t_2449), v_t_2450, NTAG(TAG_Nothing)});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(heff_take_field(v_hd_2445, 2), 1, (V[]){v_t_2452}));
  V f_ = heff_get_n(v_hd_2445, 1, 3);
  args[0] = v_t_2453;
  args[1] = v_k2_2446;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str2, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str5, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str6, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str8, 36, "expected an implicit argument's name");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str9, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str11, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str12, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str13, 41, "expected a binder's name: `\\(x : T) -> e`");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str15, 50, "a lambda binds names: `\\x y -> e`, `\\(x : T) -> e`");
V g_heff_2esyntax_2ecst_2elamBinderF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elamBinderF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elamBinderF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elamBinderF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elamBinderF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_BVar, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_BImp, 3, (V[]){v_x_2411, v_x_2416, v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elamBinderF_str5), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam5, 1, 3, (V[]){v_k_242, v_x_2411, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_BImp, 3, (V[]){v_x_2411, v_x_2419, v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elamBinderF_str7), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam7, 1, 3, (V[]){v_k_242, v_x_2411, v_x_2419})));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2414, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str4))) {
    heff_drop_rec(v_x_2414, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam4, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411})));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2414, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str6))) {
      heff_drop_rec(v_x_2414, 9);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam6, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411})));
    } else {
      heff_drop(v_x_2411);
      V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2414, 3), heff_get_n(v_x_2414, 4, 9)});
      V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str8), v_t_2421, NTAG(TAG_Nothing)});
      V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2423}));
      V f_ = heff_get_n(v_hd_241, 1, 3);
      heff_room[0] = v_t_2424;
      heff_room[1] = v_k_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam3, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam14(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  V v_x_2441 = heff_env(self)[3];
  V v_x_2442 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_BAnn, 5, (V[]){v_x_2427, v_x_2440, v_x_2441, v_x_2442, v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam13(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_2428 = heff_env(self)[0];
  V v_k_2429 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_x_2440 = heff_env(self)[3];
  V v_x_2441 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elamBinderF_str14), v_hd_2428, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam14, 1, 5, (V[]){v_k_2429, v_x_2427, v_x_2440, v_x_2441, v_x_2442})));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam12(V self, V *args) {
  V v_x_2441 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_x_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = heff_dup(v_hd_2428);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam13, 1, 5, (V[]){v_hd_2428, v_k_2429, v_x_2427, v_x_2440, v_x_2441});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam11(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2428 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_2428), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam12, 1, 5, (V[]){v_g_240, v_hd_2428, v_k_2429, v_x_2427, v_x_2440})));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam10(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2428 = heff_env(self)[0];
  V v_k_2429 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_2432, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str11)) ? 0 : !heff_strEq_c(heff_dup(heff_rfield(v_x_2432, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str12))));
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_x_2427);
    heff_drop(v_t_2435);
    V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2432, 3), heff_get_n(v_x_2432, 4, 9)});
    V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str13), v_t_2436, NTAG(TAG_Nothing)});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_2428, 2), 1, (V[]){v_t_2438}));
    V f_ = heff_get_n(v_hd_2428, 1, 3);
    heff_room[0] = v_t_2439;
    heff_room[1] = v_k_2429;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop_rec(v_x_2432, 9);
    heff_drop(v_t_2435);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2428), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam11, 1, 4, (V[]){v_hd_2428, v_g_240, v_k_2429, v_x_2427})));
  }
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam9(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2428, 2)), 1, (V[]){v_t_2430}));
  V f_ = heff_dup(heff_rfield(v_hd_2428, 1));
  args[0] = v_t_2431;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam10, 1, 4, (V[]){v_hd_2428, v_k_2429, v_g_240, v_x_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam9, 2, 2, (V[]){v_g_240, v_x_2427}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str0)) || heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str1))));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_t_247);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam1, 1, 1, (V[]){v_k_242})));
  } else {
    heff_drop(v_t_247);
    V v_t_2410 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str3))));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_245, 9);
      heff_drop_rec(v_g_240, 13);
      heff_drop(v_t_2410);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      heff_drop(v_t_2410);
      V v_t_2426 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str9)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str10))));
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_245, 9);
        heff_drop(v_t_2426);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam8, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
      } else {
        heff_drop_rec(v_g_240, 13);
        heff_drop(v_t_2426);
        V v_t_2444 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
        V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str15), v_t_2444, NTAG(TAG_Nothing)});
        V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
        V v_t_2447 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2446}));
        V f_ = heff_get_n(v_hd_241, 1, 3);
        heff_room[0] = v_t_2447;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str1, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str3, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str5, 2, "<-");
V g_heff_2esyntax_2ecst_2estatementF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2estatementF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estatementF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2estatementF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2estatementF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estatementF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2estatementF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2estatementF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2estatementF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2estatementF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2estatementF_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ESBind, 3, (V[]){v_x_2415, v_x_2416, v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estatementF_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam5, 1, 3, (V[]){v_k_242, v_x_2415, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estatementF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2415})));
}
V g_heff_2esyntax_2ecst_2estatementF_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ESBind, 3, (V[]){v_x_2420, v_x_2421, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estatementF_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam8, 1, 3, (V[]){v_k_242, v_x_2420, v_x_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estatementF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam7, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2420})));
}
V g_heff_2esyntax_2ecst_2estatementF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2estatementF_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2estatementF_str1))) {
      heff_drop_rec(v_x_2410, 9);
      heff_drop_rec(v_x_245, 9);
      return (g_heff_2esyntax_2ecst_2eletStmtF(v_g_240, v_hd_241, v_k_242));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str2))) {
        if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str3))) {
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam3, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
        } else {
          V f_ = heff_get_n(v_g_240, 0, 13);
          heff_room[0] = v_hd_241;
          heff_room[1] = v_k_242;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop_rec(v_x_2410, 9);
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  } else {
    if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str4))) {
      if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str5))) {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam6, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
      } else {
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop_rec(v_x_2410, 9);
      V f_ = heff_get_n(v_g_240, 0, 13);
      heff_room[0] = v_hd_241;
      heff_room[1] = v_k_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2estatementF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2estatementF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam2, 1, 4, (V[]){v_x_245, v_g_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatternF_str0, 3, "sym");
V g_heff_2esyntax_2ecst_2epatternF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatternF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatternF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatternF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_dup(heff_rfield(v_g_240, 6)), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2epatternF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatternF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatternF_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_POp, 3, (V[]){v_x_243, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatternF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 5, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam4, 1, 3, (V[]){v_k_242, v_x_243, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2epatternF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2epatternF_str0))) {
    V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_246, 1, 9)}));
    V v_x1_2410 = ({ V a_0 = v_t_249; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
      heff_drop(v_x_247);
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 13);
      heff_drop(v_x1_2410);
      V f_ = v_k_242;
      args[0] = v_x_243;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_x1_2410);
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 13);
        V f_ = v_k_242;
        args[0] = v_x_243;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_247);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam3, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})));
      }
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 13);
    V f_ = v_k_242;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2epatternF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam2, 1, 5, (V[]){v_x_246, v_k_242, v_x_243, v_hd_241, v_g_240})));
}
V g_heff_2esyntax_2ecst_2epatternF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam1, 1, 4, (V[]){v_hd_241, v_k_242, v_x_243, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatSegmentF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatSegmentF_str1, 2, "::");
V g_heff_2esyntax_2ecst_2epatSegmentF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2epatSegmentF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatSegmentF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2epatSegmentF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatSegmentF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatSegmentF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatSegmentF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_get_n(v_g_240, 7, 13), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatSegmentF_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2epatSegmentF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatSegmentF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatSegmentF_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PSeg, 3, (V[]){v_x_243, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatSegmentF_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(NTAG(TAG_Nil), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2epatSegmentF_lam3, 1, 3, (V[]){v_k_242, v_x_243, v_x_249})));
}
V g_heff_2esyntax_2ecst_2epatSegmentF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2epatSegmentF_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2epatSegmentF_str1))) {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatSegmentF_lam2, 1, 3, (V[]){v_hd_241, v_k_242, v_x_243})));
    } else {
      heff_drop_rec(v_hd_241, 3);
      V f_ = v_k_242;
      args[0] = v_x_243;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2epatSegmentF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatSegmentF_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam5, 1, 3, (V[]){v_k_241, v_x_246, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_249, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_249, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str1))) {
      if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
        heff_drop(v_x_2410);
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_246;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_2410);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})));
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_246;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_249, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam3, 1, 4, (V[]){v_x_249, v_k_241, v_x_246, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245 = (g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(v_x_244));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam1, 1, 2, (V[]){v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str4, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str5, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str6, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str7, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str9, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str10, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str12, 1, ")");
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, heff_tag_n(TAG_Atom, 1, (V[]){v_x_2417}), v_x_2418});
  V f_ = v_k_244;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam6, 1, 3, (V[]){v_x_242, v_x_2417, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Named, 5, (V[]){v_x_242, v_x_2425, v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str8), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam10, 1, 5, (V[]){v_k_244, v_x_242, v_x_2425, v_x_2426, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam9, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam8, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam14(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkSep: {
    V v_items_2437 = heff_field(v_x_2435, 0);
    V v_seps_2438 = heff_field(v_x_2435, 1);
    heff_take_n(v_x_2435, 3ULL, 2);
    v_t_2439 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, v_items_2437, v_seps_2438, v_x_2436});
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_k_244;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam13(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str11), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam14, 1, 3, (V[]){v_x_2435, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam15(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, v_x_2429, v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam12(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get_n(v_x_2432, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str9))) {
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str10), heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0)), v_t_2434, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam13, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  } else {
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str12), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam15, 1, 3, (V[]){v_k_244, v_x_242, v_x_2429})));
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam11(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2430}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam12, 1, 4, (V[]){v_x_2429, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str0)) && ({ V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_247, 1))})); int c_ = ({ V v_x1_2415 = ({ V a_0 = heff_dup(v_t_2414); V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; }); int c_ = ((heff_dup(v_x1_2415) == NTAG(TAG_True)) ? 0 : heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str1))); heff_drop(v_x1_2415); c_; }); heff_drop(v_t_2414); c_; })));
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2412, 9);
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_t_2416);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam5, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  } else {
    heff_drop(v_t_2416);
    V v_t_2424 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str2)) ? (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str3)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str4))) : (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str5)) && (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str6)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str7))))));
    heff_drop_rec(v_x_2412, 9);
    heff_drop_rec(v_x_247, 9);
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_t_2424);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam7, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
    } else {
      heff_drop(v_t_2424);
      return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam11, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
    }
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081(v_sep_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s554043111x1559103081_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_244;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edataAlternative_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataAlternative_str1, 35, "a constructor starts with a capital");
V g_heff_2esyntax_2ecst_2edataAlternative_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edataAlternative_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edataAlternative_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataAlternative_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edataAlternative(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataAlternative_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2edataAlternative_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edataAlternative(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edataAlternative_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_ECon, 2, (V[]){v_x_242, v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataAlternative_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2ecst_2edataAlternative_str0))) {
    return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edataAlternative_lam1, 1, 2, (V[]){v_k_241, v_x_242})));
  } else {
    V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_get_n(v_x_242, 4, 9)});
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2edataAlternative_str1), v_t_245, NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_247}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_248;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(v_sep_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edataAlternative(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_244;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str0, 6, "import");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str2, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str4, 4, "type");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str5, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str6, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str7, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str8, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str9, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str10, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str11, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str12, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str13, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str14, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str15, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str16, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str17, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str18, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str19, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str20, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str21, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str22, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str24, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str25, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str26, 4, "test");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str27, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str28, 13, "a test's name");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str29, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str30, 7, "doctest");
V g_heff_2esyntax_2ecst_2edeclAt_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam7(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edeclAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclAt_entry, 4, 0};

V g_heff_2esyntax_2ecst_2edeclAt(V v_t_240, V v_z_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str0))) {
    heff_drop_rec(v_t_240, 9);
    V v_t_246 = heff_tr(g_heff_2esyntax_2ecst_2enext(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam0, 1, 1, (V[]){v_z_242})));
    return heff_tail(v_t_246, 1, (V[]){v_z_243});
  } else {
    V v_t_248 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str1)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str2))));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_t_248);
      return (g_heff_2esyntax_2ecst_2edataDecl(v_z_241, v_z_242, v_z_243));
    } else {
      heff_drop(v_t_248);
      V v_t_2410 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str3)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str4))));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_240, 9);
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2ecst_2etypeDecl(v_z_241, v_z_242, v_z_243));
      } else {
        heff_drop(v_t_2410);
        V v_t_2412 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str5)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str6))));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop_rec(v_t_240, 9);
          heff_drop(v_t_2412);
          return (g_heff_2esyntax_2ecst_2etheoryDecl(v_z_241, v_z_242, v_z_243));
        } else {
          heff_drop(v_t_2412);
          V v_t_2414 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str7)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str8))));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 9);
            heff_drop(v_t_2414);
            return (g_heff_2esyntax_2ecst_2eprimitiveDecl(v_z_241, v_z_242, v_z_243));
          } else {
            heff_drop(v_t_2414);
            V v_t_2416 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str9)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str10))));
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop_rec(v_t_240, 9);
              heff_drop(v_t_2416);
              return (g_heff_2esyntax_2ecst_2einstanceDecl(v_z_241, v_z_242, v_z_243));
            } else {
              heff_drop(v_t_2416);
              V v_t_2427 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str11)) ? (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str12)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str13)) ? (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str14)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str15)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str16)))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str17)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str18))))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str19)) ? (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str20)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str21)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str22)))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str23)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str24))))));
              if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
                heff_drop_rec(v_t_240, 9);
                heff_drop(v_t_2427);
                V v_t_2430 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam1, 1, 2, (V[]){v_z_241, v_z_242})));
                return heff_tail(v_t_2430, 1, (V[]){v_z_243});
              } else {
                heff_drop(v_t_2427);
                V v_t_2432 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str25)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str26))));
                if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
                  heff_drop_rec(v_t_240, 9);
                  heff_drop(v_t_2432);
                  V v_t_2435 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam3, 1, 2, (V[]){v_z_241, v_z_242})));
                  return heff_tail(v_t_2435, 1, (V[]){v_z_243});
                } else {
                  heff_drop(v_t_2432);
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str29))) {
                    heff_drop_rec(v_t_240, 9);
                    V v_t_2439 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam5, 1, 2, (V[]){v_z_241, v_z_242})));
                    return heff_tail(v_t_2439, 1, (V[]){v_z_243});
                  } else {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str30))) {
                      heff_drop_rec(v_t_240, 9);
                      V v_t_2443 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam7, 1, 2, (V[]){v_z_241, v_z_242})));
                      return heff_tail(v_t_2443, 1, (V[]){v_z_243});
                    } else {
                      HEFF_LAST return g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(v_t_240, v_z_241, v_z_242, v_z_243);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DImport, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DFixity, 2, (V[]){v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efixityRest(NTAG(TAG_Nil), v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam2, 1, 2, (V[]){v_z_242, v_x_2428})));
}
V g_heff_2esyntax_2ecst_2edeclAt_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DTest, 2, (V[]){v_x_2433, v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2edeclAt_str27), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str28), v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam4, 1, 2, (V[]){v_z_242, v_x_2433})));
}
V g_heff_2esyntax_2ecst_2edeclAt_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DWatch, 2, (V[]){v_x_2437, v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam6, 1, 2, (V[]){v_z_242, v_x_2437})));
}
V g_heff_2esyntax_2ecst_2edeclAt_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DWatch, 2, (V[]){v_x_2441, v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam8, 1, 2, (V[]){v_z_242, v_x_2441})));
}
Clo g_heff_2esyntax_2ecst_2efirstE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstE_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_EParen: {
    V v_o_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_242);
  }
  case TAG_Named: {
    V v_o_245 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_245);
  }
  case TAG_Tup: {
    V v_o_2410 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2410);
  }
  case TAG_Seg: {
    V v_v_2414 = heff_field(v_x1_240, 0);
    V t_0 = v_v_2414;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Braces: {
    V v_o_2417 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2417);
  }
  case TAG_Update: {
    V v_o_2421 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2421);
  }
  case TAG_EUSet: {
    V v_x_2427 = heff_field(v_x1_240, 0);
    V t_0 = v_x_2427;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_InstB: {
    V v_o_2430 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2430);
  }
  case TAG_EFSet: {
    V v_x_2435 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2435);
  }
  case TAG_EFDefault: {
    V v_e_2438 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2438;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Sum: {
    V v_kw_2441 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2441);
  }
  case TAG_ECon: {
    V v_c_2446 = heff_field(v_x1_240, 0);
    return heff_dup(v_c_2446);
  }
  case TAG_EField: {
    V v_e_2448 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2448;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ENeg: {
    V v_m_2450 = heff_field(v_x1_240, 0);
    return heff_dup(v_m_2450);
  }
  case TAG_App: {
    V v_h_2452 = heff_field(v_x1_240, 0);
    V t_0 = v_h_2452;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Op: {
    V v_a_2454 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2454;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ops: {
    V v_a_2457 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2457;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_OpRhs: {
    V v_op_2459 = heff_field(v_x1_240, 0);
    return heff_dup(v_op_2459);
  }
  case TAG_Ann: {
    V v_e_2461 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2461;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_BVar: {
    V v_t_2464 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_2464);
  }
  case TAG_BImp: {
    V v_o_2465 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2465);
  }
  case TAG_BAnn: {
    V v_o_2468 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2468);
  }
  case TAG_Lam: {
    V v_bs_2473 = heff_field(v_x1_240, 0);
    return heff_dup(v_bs_2473);
  }
  case TAG_Case: {
    V v_kw_2477 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2477);
  }
  case TAG_EAlt: {
    V v_p_2481 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_heff_2esyntax_2ecst_2efirstP(v_p_2481);
  }
  case TAG_If: {
    V v_kw_2484 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2484);
  }
  case TAG_Do: {
    V v_kw_2490 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2490);
  }
  case TAG_ESBind: {
    V v_x_2492 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2492);
  }
  case TAG_ELet: {
    V v_kw_2495 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2495);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstE(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastE_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_EParen: {
    V v_c_244 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_244;
  }
  case TAG_Named: {
    V v_c_249 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_249;
  }
  case TAG_Tup: {
    V v_c_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2413;
  }
  case TAG_Seg: {
    V v_cc_2415 = heff_field(v_x1_240, 1);
    V v_spec_2416 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_x1_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_spec_2416));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      return v_cc_2415;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 2);
      heff_drop(v_cc_2415);
      return v_x_2418;
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  case TAG_Braces: {
    V v_c_2423 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2423;
  }
  case TAG_Update: {
    V v_c_2429 = heff_field(v_x1_240, 5);
    heff_take_n(v_x1_240, 32ULL, 6);
    return v_c_2429;
  }
  case TAG_EUSet: {
    V v_e_2432 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_e_2432;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_InstB: {
    V v_c_2437 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2437;
  }
  case TAG_EFSet: {
    V v_e_2440 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_e_2440;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EFDefault: {
    V v_d_2443 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_d_2443;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Sum: {
    V v_c_2448 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2448;
  }
  case TAG_ECon: {
    V v_c_2449 = heff_field(v_x1_240, 0);
    V v_args_2450 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2450));
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nil: {
      return v_c_2449;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 2);
      heff_drop(v_c_2449);
      V t_0 = v_x_2452;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2451);
    }
  }
  case TAG_EField: {
    V v_f_2455 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_f_2455;
  }
  case TAG_ENeg: {
    V v_e_2457 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_e_2457;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_App: {
    V v_h_2458 = heff_field(v_x1_240, 0);
    V v_args_2459 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2460 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2459));
    switch (heff_tag_of(v_x1_2460)) {
    case TAG_Nil: {
      V t_0 = v_h_2458;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_x_2461 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 2);
      heff_drop(v_h_2458);
      V t_0 = v_x_2461;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2460);
    }
  }
  case TAG_Op: {
    V v_b_2465 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_b_2465;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ops: {
    V v_a_2466 = heff_field(v_x1_240, 0);
    V v_rest_2467 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_2467));
    switch (heff_tag_of(v_x1_2468)) {
    case TAG_Nil: {
      V t_0 = v_a_2466;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_x_2469 = heff_field(v_x1_2468, 0);
      heff_take_n(v_x1_2468, 1ULL, 2);
      heff_drop(v_a_2466);
      V t_0 = v_x_2469;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2468);
    }
  }
  case TAG_OpRhs: {
    V v_e_2472 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_e_2472;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ann: {
    V v_ty_2475 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_ty_2475;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_BVar: {
    V v_t_2476 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_2476;
  }
  case TAG_BImp: {
    V v_c_2479 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_2479;
  }
  case TAG_BAnn: {
    V v_c_2484 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2484;
  }
  case TAG_Lam: {
    V v_body_2488 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    V t_0 = v_body_2488;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    V v_of2_2491 = heff_field(v_x1_240, 2);
    V v_alts_2492 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 12ULL, 4);
    V v_x1_2493 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_alts_2492));
    switch (heff_tag_of(v_x1_2493)) {
    case TAG_Nil: {
      return v_of2_2491;
    }
    case TAG_Cons: {
      V v_x_2494 = heff_field(v_x1_2493, 0);
      heff_take_n(v_x1_2493, 1ULL, 2);
      heff_drop(v_of2_2491);
      V t_0 = v_x_2494;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2493);
    }
  }
  case TAG_EAlt: {
    V v_body_2498 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_body_2498;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_If: {
    V v_b_24104 = heff_field(v_x1_240, 5);
    heff_take_n(v_x1_240, 32ULL, 6);
    V t_0 = v_b_24104;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Do: {
    V v_kw_24105 = heff_field(v_x1_240, 0);
    V v_stmts_24106 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_24107 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_24106));
    switch (heff_tag_of(v_x1_24107)) {
    case TAG_Nil: {
      return v_kw_24105;
    }
    case TAG_Cons: {
      V v_x_24108 = heff_field(v_x1_24107, 0);
      heff_take_n(v_x1_24107, 1ULL, 2);
      heff_drop(v_kw_24105);
      V t_0 = v_x_24108;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_24107);
    }
  }
  case TAG_ESBind: {
    V v_e_24112 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_e_24112;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ELet: {
    V v_e_24117 = heff_field(v_x1_240, 4);
    V v_body_24118 = heff_field(v_x1_240, 5);
    heff_take_n(v_x1_240, 48ULL, 6);
    switch (heff_tag_of(v_body_24118)) {
    case TAG_Nothing: {
      V t_0 = v_e_24117;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_it1_24119 = heff_field(v_body_24118, 0);
      heff_take_n(v_body_24118, 1ULL, 1);
      heff_drop(v_e_24117);
      switch (heff_tag_of(v_it1_24119)) {
      case TAG_MkPair: {
        V v_b_24121 = heff_field(v_it1_24119, 1);
        heff_take_n(v_it1_24119, 2ULL, 2);
        V t_0 = v_b_24121;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_it1_24119);
      }
    }
    default: return heff_nomatch(v_body_24118);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastE(a[0]);
}
Clo g_heff_2esyntax_2ecst_2edataLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataLast_entry, 4, 0};

V g_heff_2esyntax_2ecst_2edataLast(V v_name_240, V v_params_241, V v_universe_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_universe_242)) {
    case TAG_Nothing: {
      V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_241));
      switch (heff_tag_of(v_x1_244)) {
      case TAG_Nil: {
        return v_name_240;
      }
      case TAG_Cons: {
        V v_x_245 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 2);
        heff_drop(v_name_240);
        return (g_heff_2esyntax_2ecst_2elastE(v_x_245));
      }
      default: return heff_nomatch(v_x1_244);
      }
    }
    case TAG_Just: {
      V v_x31_247 = heff_field(v_universe_242, 0);
      heff_drop(v_name_240);
      heff_drop(v_params_241);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_u_249 = heff_field(v_x31_247, 1);
        return (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_u_249)));
      }
      default: return heff_nomatch(v_x31_247);
      }
    }
    default: return heff_nomatch(v_universe_242);
    }
  }
  case TAG_Just: {
    V v_x41_2410 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_2410)) {
    case TAG_MkDAlts: {
      V v_alts_2412 = heff_field(v_x41_2410, 1);
      V v_t_2420;
      switch (heff_tag_of(v_universe_242)) {
      case TAG_Nothing: {
        V v_x1_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_241));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nil: {
          v_t_2420 = v_name_240;
          break;
        }
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 2);
          heff_drop(v_name_240);
          v_t_2420 = (g_heff_2esyntax_2ecst_2elastE(v_x_2415));
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
        break;
      }
      case TAG_Just: {
        V v_x31_2417 = heff_field(v_universe_242, 0);
        heff_drop(v_name_240);
        heff_drop(v_params_241);
        switch (heff_tag_of(v_x31_2417)) {
        case TAG_MkPair: {
          V v_u_2419 = heff_field(v_x31_2417, 1);
          v_t_2420 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_u_2419)));
          break;
        }
        default: heff_nomatch(v_x31_2417);
        }
        break;
      }
      default: heff_nomatch(v_universe_242);
      }
      V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_alts_2412)));
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_Nil: {
        return v_t_2420;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 2);
        heff_drop(v_t_2420);
        return (g_heff_2esyntax_2ecst_2elastE(v_x_2422));
      }
      default: return heff_nomatch(v_x1_2421);
      }
    }
    default: return heff_nomatch(v_x41_2410);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2ecst_2edataLast_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2esyntax_2ecst_2edataLast(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}