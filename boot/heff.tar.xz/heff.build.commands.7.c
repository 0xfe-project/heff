// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Holds 53574
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_diff 9578700
#define LBL_discarded 1490202606
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_files 298792593
#define LBL_goldens 436112074
#define LBL_got 312070
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_labels 836724522
#define LBL_line 9817275
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_owner 307523277
#define LBL_paths 307797256
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_watch 314261737
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s1067007848x1099704198(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1067007848x1099704198_entry(V self, V *a);
extern Clo g_co_2eop_24s1067007848x1099704198_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_clo;
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo;
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(V);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_clo;
V g_heff_2ebuild_2ecommands_2erevSaid(V);
V g_heff_2ebuild_2ecommands_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevSaid_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_clo;
V g_heff_2ebuild_2ecommands_2etestsHeld(V, V, V);
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V, V);
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
V g_list_2efoldl_24f1564248594x622634626(V, V, V);
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1564248594x622634626_clo;
V g_list_2efoldl_24f319030394x1380151895(V, V, V);
V g_list_2efoldl_24f319030394x1380151895_entry(V self, V *a);
extern Clo g_list_2efoldl_24f319030394x1380151895_clo;
V g_list_2efoldl_24f496521120x176206934(V, V, V);
V g_list_2efoldl_24f496521120x176206934_entry(V self, V *a);
extern Clo g_list_2efoldl_24f496521120x176206934_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s458067099x815639923(V);
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_clo;
V g_list_2ekeepIf_24s741838803x941779121(V);
V g_list_2ekeepIf_24s741838803x941779121_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s741838803x941779121_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0, 0, "");
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V v_sources_240, V v_only_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    heff_drop(v_seen_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_244)));
    V v_m_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_m_249 = ((V)&g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_m_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_seen_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_m_249);
      heff_drop(v_t_2410);
      V t_0 = v_sources_240;
      V t_1 = v_only_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_sources_240 = t_0;
      v_only_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_only_241));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_sources_240);
        heff_drop(v_seen_242);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_m_249);
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_path_244}});
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_list_2efind_24s1218501002x1291750665_24cpr(v_m_249, heff_dup(v_sources_240)));
        V v_t_2423;
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2414;
            V v_renames_2416 = heff_take_field(v_x_2415, 5);
            V v_implicit_2417 = heff_take_field(v_x_2415, 6);
            V v_source_2418 = heff_get_n(v_x_2415, 4, 8);
            V v_t_2419 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_2417, v_source_2418));
            V v_t_2420 = ({ V a_0 = v_renames_2416; V a_1 = v_t_2419; V r_ = (g_heff_2esyntax_2eimport_2erenamed(a_0, a_1)); heff_drop(v_renames_2416); r_; });
            V v_imps_2421 = heff_get_n(v_t_2420, 0, 4);
            V v_t_2422 = (g_list_2emap_24s1817208647x1282894070(v_imps_2421));
            v_t_2423 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2422));
          } else {
            heff_drop(v_field_2414);
            v_t_2423 = NTAG(TAG_Nil);
          }
        }
        V v_t_2426 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0, 1, 1, (V[]){v_path_244}), v_t_2423));
        V t_0 = v_sources_240;
        V t_1 = v_only_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_m_249, v_seen_242});
        V t_3 = v_t_2426;
        v_sources_240 = t_0;
        v_only_241 = t_1;
        v_seen_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_2424, NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_path_244, v_t_2425));
}

static V g_heff_2ebuild_2ecommands_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectedRes_st;
static V g_heff_2ebuild_2ecommands_2eexpectedRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectedRes_st)) return g_heff_2ebuild_2ecommands_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectedRes_val, &g_heff_2ebuild_2ecommands_2eexpectedRes_st, g_heff_2ebuild_2ecommands_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str2, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str3, 12, "\012  diff     ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str4, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str5, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str8, 5, "FAIL ");
Clo g_heff_2ebuild_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_expected_243 = heff_take_field(v_m_242, 0);
  V v_got_244 = heff_take_field(v_m_242, 1);
  V v_diff_245 = heff_get_n(v_m_242, 2, 3);
  V v_line_246 = heff_take_field(v_r_241, 1);
  V v_owner_247 = heff_take_field(v_r_241, 0);
  V v_watch_248 = heff_get_n(v_r_241, 2, 3);
  V v_t_2410;
  switch (heff_tag_of(v_owner_247)) {
  case TAG_Nothing: {
    v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_249 = heff_field(v_owner_247, 0);
    heff_take_n(v_owner_247, 1ULL, 1);
    v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str1), heff_strAppend(v_n_249, ((V)&g_heff_2ebuild_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_owner_247);
  }
  V v_t_2411 = heff_strAppend(v_got_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str3), v_diff_245));
  V v_t_2412 = heff_strAppend(v_expected_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str4), v_t_2411));
  V v_t_2413 = heff_strAppend(heff_get_n(v_watch_248, 2, 10), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str5), v_t_2412));
  V v_t_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str6), v_t_2413));
  V v_t_2415 = heff_strAppend(heff_intShow(v_line_246), v_t_2414);
  V v_t_2416 = heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str7), v_t_2415));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str8), v_t_2416);
}
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efailLine(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationMainName_str0, 20, "heffTestIntegrations");

static V g_heff_2ebuild_2ecommands_2eintegrationMainName_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eintegrationMainName_st;
static V g_heff_2ebuild_2ecommands_2eintegrationMainName_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eintegrationMainName_str0);
}
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eintegrationMainName_st)) return g_heff_2ebuild_2ecommands_2eintegrationMainName_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eintegrationMainName_val, &g_heff_2ebuild_2ecommands_2eintegrationMainName_st, g_heff_2ebuild_2ecommands_2eintegrationMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str2, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str4, 11, " tests hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str6, 2, ", ");
Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsHeld_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etestsHeld(V v_tests_240, V v_failed_241, V v_skipped_242) {
top: ;
  if (heff_intEq_c_lent(v_tests_240, MK_INT(0LL), 2)) {
    heff_drop(v_tests_240);
    heff_drop(v_failed_241);
    heff_drop(v_skipped_242);
    return ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str0);
  } else {
    V v_t_243 = heff_intSub(heff_intSub(heff_dup(v_tests_240), v_failed_241), heff_dup(v_skipped_242));
    V v_t_245;
    if (heff_intEq_c_lent(v_skipped_242, MK_INT(0LL), 2)) {
      heff_drop(v_skipped_242);
      v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str1);
    } else {
      V v_t_244 = heff_strAppend(heff_intShow(v_skipped_242), ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str2));
      v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str3), v_t_244);
    }
    V v_t_246 = heff_strAppend(heff_intShow(v_tests_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str4), v_t_245));
    V v_t_247 = heff_strAppend(heff_intShow(v_t_243), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str5), v_t_246));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str6), v_t_247);
  }
}
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestsHeld(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevSaid_str0, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevSaid_str1, 28, "commit on the default branch");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevSaid_str2, 7, "commit ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevSaid_str3, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevSaid_str4, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erevSaid_str5, 7, "branch ");
Clo g_heff_2ebuild_2ecommands_2erevSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erevSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2erevSaid(V v_rev_240) {
top: ;
  if (heff_strEq_c_lent(v_rev_240, ((V)&g_heff_2ebuild_2ecommands_2erevSaid_str0), 2)) {
    heff_drop(v_rev_240);
    return ((V)&g_heff_2ebuild_2ecommands_2erevSaid_str1);
  } else {
    if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_240, 0)))) {
      if ((heff_unbox_word(heff_strLength_lent(v_rev_240, 0)) <= ((int64_t)40ULL))) {
        V v_t_241 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_240, 0)));
        V v_t_242 = ({ V a_0 = v_rev_240; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_241; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_241); r_; });
        if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevSaid_str2), v_rev_240);
        } else {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevSaid_str3), v_rev_240);
        }
      } else {
        return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevSaid_str4), v_rev_240);
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erevSaid_str5), v_rev_240);
    }
  }
}
V g_heff_2ebuild_2ecommands_2erevSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erevSaid(a[0]);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(heff_dup(v_sources_240), v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam1, 2, 3, (V[]){v_c_246, v_sources_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(v_sources_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_str0, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(V v_update_240, V v_f_241, V v_o_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam0, 2, 1, (V[]){v_o_242});
  }
  case TAG_Cons: {
    V v_g_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = (g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(v_update_240, heff_dup(v_f_241), v_g_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam1, 2, 5, (V[]){v_c_248, heff_dup(v_update_240), v_f_241, v_o_242, v_rest_247});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_o_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Holds: {
    V v_t_2412 = ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_o_242; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(a_0, a_1, a_2, a_3)); heff_drop(v_update_240); r_; });
    V f_ = v_t_2412;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrote: {
    V v_path_2413 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Wrote = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_str0), v_path_2413), ((V)&g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_str1));
    V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2411_24Wrote, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_o_242; V a_3 = v_rest_247; V a_4 = heff_dup(v_hd_249); V a_5 = v_k_2410; V a_6 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}); V a_7 = v_hd_249; V r_ = (g_co_2eop_24s1067007848x1099704198(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_update_240); r_; });
  }
  case TAG_Wrong: {
    V v_note_2422 = heff_field(v_x_2411, 0);
    V v_why_2423 = heff_field(v_x_2411, 1);
    V v_ru_24x_2411_24Wrong = heff_take_reuse_n(v_x_2411, 3ULL, 2);
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    heff_drop(v_rest_247);
    heff_drop(v_hd_249);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2411_24Wrong, TAG_Cons, 2, (V[]){v_note_2422, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_o_242, 8), v_t_2424));
    V v_x_2426 = ({ V rv_1 = NTAG(TAG_False); V rv_2 = NTAG(TAG_Nothing); V rv_8 = v_t_2425; V rv_9 = heff_tag_n(TAG_Just, 1, (V[]){v_why_2423}); V rr_ = heff_rec_reuse_nf(v_o_242, 3321ULL, 12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, 15794115u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    V f_ = v_k_2410;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_o_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_lam2, 1, 6, (V[]){v_update_240, v_f_241, v_o_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str1, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str5, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(V v_rep_240, V v_f_241, V v_wrong_242, V v_ts_243, V v_os_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_248 = heff_tr(heff_call(v_rep_240, 1, (V[]){heff_tag_n(TAG_UseColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam0_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_248, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam1, 1, 6, (V[]){v_ts_243, v_f_241, v_z_245, v_os_244, v_wrong_242, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam0(V self, V *args) {
  V v_b_247 = args[0];
  return v_b_247;
}
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_wrong_242 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2441);
  V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_243; V r_ = (g_list_2efoldl_24f319030394x1380151895(a_0, a_1, a_2)); heff_drop(v_ts_243); r_; });
  V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_244));
  V v_t_2445 = (g_list_2efoldl_24f1564248594x622634626(MK_INT(1LL), MK_INT(0LL), v_os_244));
  V v_t_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_244; V r_ = (g_list_2efoldl_24f496521120x176206934(a_0, a_1, a_2)); heff_drop(v_os_244); r_; });
  V v_x_2447 = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), v_t_2442, v_t_2443, v_wrong_242, v_t_2444, v_t_2445, v_t_2446});
  V f_ = v_z_246;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_wrong_242 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  V v_x1_2415 = (g_list_2ekeepIf_24s741838803x941779121(heff_dup(v_ts_243)));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nil: {
    V v_x1_2416 = (g_list_2ekeepIf_24s458067099x815639923(heff_dup(v_os_244)));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_wrong_242)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str0);
        break;
      }
      case TAG_Cons: {
        v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str1);
        break;
      }
      default: heff_nomatch(v_wrong_242);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2416, 0ULL, 2);
      v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str2);
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2415, 0ULL, 2);
    v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str3);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2425 = (g_list_2efoldl_24f319030394x1380151895(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2426 = heff_intShow(heff_intSub(v_t_2424, v_t_2425));
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2428 = (g_heff_2ebuild_2ecommands_2etestsSaid(v_os_244));
  V v_t_2429 = heff_strAppend(heff_intShow(v_t_2427), v_t_2428);
  V v_t_2430 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str4), v_t_2429));
  V v_t_2431 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str5), v_t_2430));
  V v_str_2432 = heff_strAppend(v_t_2423, v_t_2431);
  V v_t_2433 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2432, ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_str6)), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tr(heff_call(heff_take_field(v_z_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
  V f_ = heff_get_n(v_z_245, 1, 3);
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam4, 1, 4, (V[]){v_ts_243, v_os_244, v_wrong_242, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_ts_243 = heff_env(self)[3];
  V v_wrong_242 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_c_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_os_244); V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam3, 1, 6, (V[]){v_ts_243, v_os_244, v_wrong_242, v_f_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_os_244 = heff_env(self)[3];
  V v_wrong_242 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2410 = (g_list_2ekeepIf_24s741838803x941779121(heff_dup(v_ts_243)));
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(heff_dup(v_f_241), v_x_249, v_t_2410));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_lam2, 1, 7, (V[]){v_x_249, v_os_244, v_z_245, v_ts_243, v_wrong_242, v_f_241, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(V v_checkOnly_240, V v_x2_241, V v_bad_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam0, 2, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(v_checkOnly_240, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_bad_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_bad_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_2410); V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(a_0, a_1, a_2)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_checkOnly_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_bad_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam2, 1, 5, (V[]){v_checkOnly_240, v_rest_246, v_bad_242, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 0))));
    V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
    V v_t_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_c_2411 = (g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(v_t_2410));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam1, 2, 5, (V[]){v_c_2411, heff_dup(v_st_240), v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417;
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop(v_n_245);
    v_t_2417 = v_x_2416;
  } else {
    heff_drop(v_x_2414);
    v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, v_x_2416});
  }
  V f_ = v_k_2413;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V f_ = v_c_2415;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam3, 1, 3, (V[]){v_x_2414, v_n_245, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_2412, v_n_245, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908(V v_rep_240, V v_prog_241, V v_st_242, V v_cmd_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_244, 0))));
  V v_t_248 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str0)));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_t_2410 = ({ V a_0 = v_st_242; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2411, NTAG(TAG_Nil)));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam0, 1, 7, (V[]){v_prog_241, v_z_245, v_rep_240, v_cmd_243, v_z_246, heff_dup(v_st_242), v_t_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam1(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam8(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2468);
  V f_ = v_k_2469;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam7(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_2467 = (g_list_2emap_24s219049803x1458391381(v_x_2466));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam8, 2, 1, (V[]){v_x_2467});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam10(V self, V *args) {
  V v_t_2478 = args[0];
  return v_t_2478;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam14(V self, V *args) {
  V v_x_24104 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24104);
  V v_t_24105 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24111}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam13(V self, V *args) {
  V v_x_2490 = args[0];
  V v_bad_2486 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_apps_2487 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_st_242 = heff_env(self)[7];
  V v_t_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2490);
  if (heff_intLt_c_lent(MK_INT(0LL), v_bad_2486, 1)) {
    heff_drop(v_apps_2487);
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    V v_n_2491 = v_bad_2486;
    V v_t_2492;
    if (heff_intEq_c_lent(v_n_2491, MK_INT(1LL), 2)) {
      heff_drop(v_n_2491);
      v_t_2492 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str17);
    } else {
      v_t_2492 = heff_strAppend(heff_intShow(v_n_2491), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str18));
    }
    V v_what_2493 = heff_strAppend(v_t_2492, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str19));
    V v_t_2494 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str20), heff_strAppend(v_what_2493, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str21)));
    V v_t_2495 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str22), heff_strAppend(v_cmd_243, v_t_2494));
    V v_t_2496 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2495, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str23)), NTAG(TAG_MkUnit)});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24103;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam14, 1, 2, (V[]){v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_bad_2486);
    heff_drop(v_cmd_243);
    switch (heff_tag_of(v_apps_2487)) {
    case TAG_Nil: {
      heff_drop_rec(v_z_245, 3);
      heff_drop(v_rep_240);
      heff_drop(v_prog_241);
      heff_drop(v_st_242);
      heff_drop_rec(v_t_244, 6);
      V f_ = v_z_246;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      return ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_242; V a_3 = v_t_244; V a_4 = v_apps_2487; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_242); r_; });
    }
    default: return heff_nomatch(v_apps_2487);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam12(V self, V *args) {
  V v_x_2485 = args[0];
  V v_x_2480 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_bad_2486 = heff_take_field(v_x_2485, 1);
  V v_apps_2487 = heff_get_n(v_x_2485, 0, 2);
  V v_t_2488 = heff_tag_n(TAG_End, 2, (V[]){v_x_2480, NTAG(TAG_MkUnit)});
  V v_t_2489 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2488}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2489, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam13, 1, 9, (V[]){v_bad_2486, v_cmd_243, v_z_245, v_z_246, v_apps_2487, v_rep_240, v_prog_241, v_st_242, v_t_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam11(V self, V *args) {
  V v_x_2480 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_cmd_243 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2481 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2483;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_Nothing: {
    v_t_2483 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2482 = heff_field(v_x_2474, 0);
    heff_take_n(v_x_2474, 1ULL, 1);
    v_t_2483 = v_x_2482;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_c_2484 = (g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_244), heff_dup(v_x_2480), v_t_2481, v_t_2483));
  V f_ = v_c_2484;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam12, 1, 8, (V[]){v_x_2480, v_prog_241, v_z_245, v_cmd_243, v_z_246, v_rep_240, v_st_242, v_t_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam9(V self, V *args) {
  V v_x_2471 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_t_244 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2474;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_Left: {
    heff_take_n(v_x_2471, 0ULL, 1);
    v_x_2474 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2473 = heff_field(v_x_2471, 0);
    V v_ru_24x_2471_24Right = heff_take_reuse_n(v_x_2471, 1ULL, 1);
    v_x_2474 = heff_tag_at_n(v_ru_24x_2471_24Right, TAG_Just, 1, (V[]){v_y_2473});
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2476;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_Nothing: {
    v_t_2476 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2475 = heff_dup(heff_field(v_x_2474, 0));
    v_t_2476 = v_x_2475;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_total_2477 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2476; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2476); r_; });
  V v_t_2479 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str16), v_total_2477, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam10_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2479, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam11, 1, 8, (V[]){v_x_2474, v_prog_241, v_st_242, v_t_244, v_z_245, v_cmd_243, v_z_246, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam6(V self, V *args) {
  V v_x_2459 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2459);
  V v_t_2460 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_244, 0))));
  V v_t_2461 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str15)));
  V v_t_2462 = (g_std_2epath_2ejoin(v_t_2460, v_t_2461));
  V v_s_2463 = ({ V a_0 = v_st_242; V a_1 = v_t_2462; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2462); r_; });
  V v_path_2464 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2463; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2465 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_2464));
  V v_c_2470 = heff_tr(heff_call(v_c_2465, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam7_clo)}));
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam9, 1, 7, (V[]){v_prog_241, v_z_245, v_st_242, v_t_244, v_cmd_243, v_z_246, v_rep_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_errors_2421 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_seen_2422 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_prog_241 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2425);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2421, 1)) {
    heff_drop(v_seen_2422);
    heff_drop(v_st_242);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_prog_241);
    heff_drop(v_rep_240);
    V v_n_2426 = v_errors_2421;
    V v_t_2427;
    if (heff_intEq_c_lent(v_n_2426, MK_INT(1LL), 2)) {
      heff_drop(v_n_2426);
      v_t_2427 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str2);
    } else {
      v_t_2427 = heff_strAppend(heff_intShow(v_n_2426), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str3));
    }
    V v_what_2428 = heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str4));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str5), heff_strAppend(v_what_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str6)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str7), heff_strAppend(v_cmd_243, v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str8)), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2438;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam5, 1, 2, (V[]){v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_errors_2421);
    V v_n_2447 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2422; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2422); r_; });
    V v_t_2448;
    if (heff_intEq_c_lent(v_n_2447, MK_INT(1LL), 2)) {
      heff_drop(v_n_2447);
      v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str9);
    } else {
      v_t_2448 = heff_strAppend(heff_intShow(v_n_2447), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str10));
    }
    V v_t_2449 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str11), heff_strAppend(v_t_2448, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str12)));
    V v_str_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str13), heff_strAppend(heff_dup(v_cmd_243), v_t_2449));
    V v_t_2451 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str14)), NTAG(TAG_MkUnit)});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2458;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam6, 1, 7, (V[]){v_st_242, v_t_244, v_z_245, v_prog_241, v_cmd_243, v_z_246, v_rep_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_errors_2421 = heff_take_field(v_x_2420, 1);
  V v_seen_2422 = heff_get_n(v_x_2420, 0, 2);
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2423}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2424, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam4, 1, 9, (V[]){v_errors_2421, v_cmd_243, v_z_245, v_z_246, v_seen_2422, v_st_242, v_t_244, v_prog_241, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_st_242 = heff_env(self)[6];
  V v_t_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2419 = ({ V a_0 = heff_dup(v_rep_240); V a_1 = heff_dup(v_prog_241); V a_2 = heff_dup(v_x_2417); V a_3 = v_t_2418; V a_4 = v_x_2413; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam3, 1, 8, (V[]){v_x_2417, v_prog_241, v_z_245, v_cmd_243, v_z_246, v_st_242, v_t_244, v_rep_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_cmd_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_st_242 = heff_env(self)[5];
  V v_t_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2413));
  V v_t_2416 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_str1), v_total_2414, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam1_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2416, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1752361573x842560908_lam2, 1, 8, (V[]){v_rep_240, v_prog_241, v_x_2413, v_z_245, v_cmd_243, v_z_246, v_st_242, v_t_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str6, 3, "src");
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372(V v_rep_240, V v_v_241, V v_l_242, V v_pk_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(heff_rfield(v_pk_243, 0)), heff_dup(v_v_241)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_rep_240);
      heff_drop(v_v_241);
      heff_drop_rec(v_l_242, 5);
      V v_why_249 = v_field_248;
      V v_t_2410 = heff_strAppend(heff_get_n(v_pk_243, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str0), v_why_249));
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str1), v_t_2410), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str2));
      V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
      return heff_tail(heff_dup(heff_rfield(v_z_244, 1)), 2, (V[]){v_t_2419, heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam0, 1, 2, (V[]){v_z_244, v_z_245})});
    } else {
      heff_drop(v_field_248);
      V v_st_2428 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
      V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 0, 6);
      V v_t_2430 = (g_std_2epath_2eparse(v_st_2428, v_t_2429));
      V v_t_2431 = (g_std_2epath_2eparse(v_st_2428, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str3)));
      V v_t_2432 = (g_std_2epath_2ejoin(v_t_2430, v_t_2431));
      V v_t_2433 = ({ V a_0 = v_st_2428; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2428); heff_drop(v_t_2432); r_; });
      V v_c_2434 = (g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(heff_dup(heff_rfield(v_l_242, 2)), v_t_2433));
      return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam1, 1, 6, (V[]){v_z_244, v_z_245, v_l_242, v_rep_240, v_v_241, v_pk_243})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam2(V self, V *args) {
  V v_x_2446 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam1(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_l_242 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_pk_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_why_2436 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_pk_243, 4);
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str4), v_why_2436), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str5));
    V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
    V f_ = heff_dup(heff_rfield(v_z_244, 1));
    heff_room[0] = v_t_2445;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_lam2, 1, 2, (V[]){v_z_244, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2435, 0ULL, 1);
    V v_st_2455 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
    V v_t_2456 = heff_get_n(heff_get_n(v_l_242, 2, 5), 0, 6);
    V v_t_2457 = (g_std_2epath_2eparse(v_st_2455, v_t_2456));
    V v_t_2458 = (g_std_2epath_2eparse(v_st_2455, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_str6)));
    V v_t_2459 = (g_std_2epath_2ejoin(v_t_2457, v_t_2458));
    V v_t_2460 = ({ V a_0 = v_st_2455; V a_1 = v_t_2459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2455); heff_drop(v_t_2459); r_; });
    return (g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(v_rep_240, v_v_241, v_pk_243, v_t_2460, v_z_244, v_z_245));
  }
  default: return heff_nomatch(v_x_2435);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str0, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_246 = args[1];
  V v_k_247 = args[2];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    heff_take_n(v_x_249, 0ULL, 1);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2411 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Right = heff_take_reuse_n(v_x_249, 1ULL, 1);
    v_t_2412 = heff_tag_at_n(v_ru_24x_249_24Right, TAG_Just, 1, (V[]){v_y_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  HeffT2 v_t_2413 = ({ V a_0 = v_x_242; V a_1 = v_t_2412; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_why_2416 = v_field_2415;
      V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str0), v_why_2416), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str1));
      V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
      V f_ = heff_dup(heff_rfield(v_hd_240, 1));
      heff_room[0] = v_t_2425;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam3, 1, 2, (V[]){v_hd_240, v_k_241});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_line_2434 = v_field_2415;
      V v_t_2435 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2434, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str2)), NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2442;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_244 = ({ V a_0 = v_path_243; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_243); r_; });
  V v_c_248 = heff_tr(heff_call(v_c_244, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1_clo)}));
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str1, 6, "=body ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str2, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str3, 5, "=def ");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 14);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_240), v_k_244));
    V v_t_247 = heff_strAppend(heff_dup(v_k_244), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str0), v_t_246));
    V v_t_248 = (g_heff_2eelab_2etoplevel_2etyDump(heff_dup(heff_rfield(v_c_240, 5)), v_k_244));
    V v_t_249 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 5)); V a_1 = v_k_244; V r_ = (g_heff_2eelab_2etoplevel_2ebodyDump(a_0, a_1)); heff_drop(v_k_244); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str1), v_t_249), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str2), v_t_248), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str3), v_t_247), v_t_2411});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam1, 2, 3, (V[]){v_t_2412, v_c_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(v_c_240, v_rest_245));
  V f_ = v_t_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_2413, v_k_2414})));
}