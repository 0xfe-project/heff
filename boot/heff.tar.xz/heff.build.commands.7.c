// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_diff 9578700
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_goldens 436112074
#define LBL_got 312070
#define LBL_hash 9690581
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_ok 10307
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_source 1050636102
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688(V, V, V);
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_clo;
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349(V, V, V);
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_clo;
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446(V);
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_clo;
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261(V, V);
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_clo;
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551(V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315(V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_clo;
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269(V, V, V);
V g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269_clo;
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761(V, V);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_clo;
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736(V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_clo;
V g_heff_2ebuild_2ecommands_2etestsHeld(V, V, V);
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
HeffT2 g_list_2efind_24s41451459x2069155315_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0, 0, "");
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V v_sources_240, V v_only_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    heff_drop(v_seen_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_244)));
    V v_m_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_m_249 = ((V)&g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_m_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = (g_list_2eany_24s2065989517x1307020881(v_m_249, v_seen_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_m_249);
      heff_drop(v_t_2410);
      V t_0 = v_sources_240;
      V t_1 = v_only_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_sources_240 = t_0;
      v_only_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2eany_24s2065989517x1307020881(v_m_249, v_only_241));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_sources_240);
        heff_drop(v_seen_242);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_m_249);
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_path_244}});
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_list_2efind_24s41451459x2069155315_24cpr(v_m_249, heff_dup(v_sources_240)));
        V v_t_2421;
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_x_2416, 6), heff_take_field(v_x_2416, 4)));
            V v_t_2418 = ({ V b_0 = heff_get_n(v_x_2416, 5, 8); V a_1 = v_t_2417; V r_ = (g_heff_2esyntax_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
            V v_imps_2419 = heff_get_n(v_t_2418, 0, 4);
            V v_t_2420 = (g_list_2emap_24s1817208647x1282894070(v_imps_2419));
            v_t_2421 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2420));
          } else {
            heff_drop(v_field_2414);
            v_t_2421 = NTAG(TAG_Nil);
          }
        }
        V v_t_2424 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0, 1, 1, (V[]){v_path_244}), v_t_2421));
        V t_0 = v_sources_240;
        V t_1 = v_only_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_m_249, v_seen_242});
        V t_3 = v_t_2424;
        v_sources_240 = t_0;
        v_only_241 = t_1;
        v_seen_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args) {
  V v_i_2422 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_2422, NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_path_244, v_t_2423));
}

static V g_heff_2ebuild_2ecommands_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectedRes_st;
static V g_heff_2ebuild_2ecommands_2eexpectedRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectedRes_st)) return g_heff_2ebuild_2ecommands_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectedRes_val, &g_heff_2ebuild_2ecommands_2eexpectedRes_st, g_heff_2ebuild_2ecommands_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str2, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str3, 12, "\012  diff     ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str4, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str5, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str8, 5, "FAIL ");
Clo g_heff_2ebuild_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_intShow(heff_take_field(v_r_241, 1));
  V v_t_244 = heff_take_field(v_r_241, 0);
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str1), heff_strAppend(v_n_245, ((V)&g_heff_2ebuild_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_247 = heff_get_n(heff_get_n(v_r_241, 2, 3), 2, 10);
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str3), heff_take_field(v_m_242, 2));
  V v_t_249 = heff_strAppend(heff_take_field(v_m_242, 1), v_t_248);
  V v_t_2410 = heff_strAppend(heff_get_n(v_m_242, 0, 3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str4), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str5), v_t_2410));
  V v_t_2412 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str6), v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str7), heff_strAppend(v_t_243, v_t_2412));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str8), heff_strAppend(v_f_240, v_t_2413));
}
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efailLine(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationMainName_str0, 20, "heffTestIntegrations");

static V g_heff_2ebuild_2ecommands_2eintegrationMainName_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eintegrationMainName_st;
static V g_heff_2ebuild_2ecommands_2eintegrationMainName_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eintegrationMainName_str0);
}
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eintegrationMainName_st)) return g_heff_2ebuild_2ecommands_2eintegrationMainName_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eintegrationMainName_val, &g_heff_2ebuild_2ecommands_2eintegrationMainName_st, g_heff_2ebuild_2ecommands_2eintegrationMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str2, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str4, 11, " tests hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str6, 2, ", ");
Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsHeld_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etestsHeld(V v_tests_240, V v_failed_241, V v_skipped_242) {
top: ;
  if (heff_intEq_c_lent(v_tests_240, MK_INT(0LL), 2)) {
    heff_drop(v_tests_240);
    heff_drop(v_failed_241);
    heff_drop(v_skipped_242);
    return ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str0);
  } else {
    V v_t_244 = heff_intSub(heff_intSub(heff_dup(v_tests_240), v_failed_241), heff_dup(v_skipped_242));
    V v_t_247;
    if (heff_intEq_c_lent(v_skipped_242, MK_INT(0LL), 2)) {
      heff_drop(v_skipped_242);
      v_t_247 = ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str1);
    } else {
      V v_t_246 = heff_strAppend(heff_intShow(v_skipped_242), ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str2));
      v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str3), v_t_246);
    }
    V v_t_248 = heff_strAppend(heff_intShow(v_tests_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str4), v_t_247));
    V v_t_249 = heff_strAppend(heff_intShow(v_t_244), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str5), v_t_248));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str6), v_t_249);
  }
}
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestsHeld(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_o_245, 1));
    V v_c_2410;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_c_2410 = (g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(v_update_240, heff_dup(v_f_241), heff_dup(v_o_245), heff_get_n(v_o_245, 11, 12)));
    } else {
      heff_drop(v_t_247);
      v_c_2410 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam1, 2, 1, (V[]){v_o_245});
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam2, 2, 4, (V[]){v_c_2410, heff_dup(v_update_240), v_f_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_o_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_o_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2414 = ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871(a_0, a_1, a_2)); heff_drop(v_update_240); r_; });
  V f_ = v_c_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam4, 1, 2, (V[]){v_k_2412, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s869741503x573171871_lam3, 1, 5, (V[]){v_update_240, v_f_241, v_rest_246, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551(V v_checkOnly_240, V v_x2_241, V v_bad_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam0, 2, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315(v_checkOnly_240, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_bad_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_bad_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_2410); V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551(a_0, a_1, a_2)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_checkOnly_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_bad_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s824114724x1318586551_lam2, 1, 5, (V[]){v_checkOnly_240, v_rest_246, v_bad_242, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_str1, 68, "heff doc: no src/ here: run it at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_str2, 3, "src");
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_241); r_; });
    V v_a_244 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam0_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam1, 2, 1, (V[]){v_a_244});
  }
  case TAG_Cons: {
    V v_t_2436 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2436, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446(a[0]);
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam4, 1, 1, (V[]){v_k_246})));
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_str1), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam3, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2413, 0ULL, 1);
    V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_str2)});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    V v_t_2433 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2432, NTAG(TAG_Nil)));
    V f_ = v_t_2433;
    heff_room[0] = v_hd_245;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446_lam2, 1, 2, (V[]){v_hd_245, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349(V v_rep_240, V v_out_241, V v_given_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2edocFiles_24s12292622x777984446(v_given_242));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam0, 2, 3, (V[]){v_c_243, v_rep_240, v_out_241});
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_248); r_; });
  V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
  if (heff_intLt_c(v_t_2411, v_t_2412)) {
    V v_t_2414 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_244, v_k_245));
  } else {
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_out_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_249 = heff_tr(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261(v_out_241, heff_dup(v_x_248)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam3, 1, 4, (V[]){v_x_248, v_x_246, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_out_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_247 = (g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688(v_rep_240, heff_dup(v_x_246), NTAG(TAG_Nil)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam2, 1, 4, (V[]){v_out_241, v_hd_244, v_x_246, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_out_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s704709273x300361349_lam1, 1, 4, (V[]){v_rep_240, v_hd_244, v_out_241, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam2(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2434;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2433, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2434});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam4, 1, 3, (V[]){v_x_2433, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
  V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam2_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(v_t_2432, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s175226857x1740822193_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_str0, 5, ".hash");
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop_rec(v_root_241, 4);
    return ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam3(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2424 = (g_list_2efilter_24s2128134357x1680551385(heff_rfield(v_x_245, 0), heff_take_field(v_root_241, 2)));
  V v_x_2442;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_245, 3);
      v_x_2442 = v_x_2410;
      break;
    }
    case TAG_Just: {
      V v_t_2425 = heff_field(v_x_2423, 0);
      heff_take_n(v_x_2423, 1ULL, 1);
      V v_t_2426 = (g_prelude_2eskipSpaces(v_t_2425, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2427 = (heff_unbox_word(heff_strLength_lent(v_t_2425, 0)) - ((int64_t)1ULL));
      V v_t_2428 = (g_prelude_2eskipSpaces(v_t_2425, heff_box_word(v_t_2427), MK_INT(-1LL)));
      V v_t_2429 = heff_strSlice(v_t_2425, v_t_2426, heff_intAdd(v_t_2428, MK_INT(1LL)));
      V v_t_2430 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2429});
      v_x_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_x_2410});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    break;
  }
  case TAG_Cons: {
    V v_r_2431 = heff_field(v_t_2424, 0);
    V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 1ULL, 2);
    V v_t_2433 = (g_list_2efilter_24s50027113x1989932102(v_r_2431, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x_2423)) {
      case TAG_Nothing: {
        heff_drop_rec(v_x_245, 3);
        heff_drop_cell(v_ru_24t_2424_24Cons, 2);
        v_x_2442 = v_x_2410;
        break;
      }
      case TAG_Just: {
        V v_t_2434 = heff_field(v_x_2423, 0);
        heff_take_n(v_x_2423, 1ULL, 1);
        V v_t_2435 = (g_prelude_2eskipSpaces(v_t_2434, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_t_2434, 0)) - ((int64_t)1ULL));
        V v_t_2437 = (g_prelude_2eskipSpaces(v_t_2434, heff_box_word(v_t_2436), MK_INT(-1LL)));
        V v_t_2438 = heff_strSlice(v_t_2434, v_t_2435, heff_intAdd(v_t_2437, MK_INT(1LL)));
        V v_t_2439 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2438});
        v_x_2442 = heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_Cons, 2, (V[]){v_t_2439, v_x_2410});
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2433, 0ULL, 2);
      heff_drop(v_x_2423);
      heff_drop_rec(v_x_245, 3);
      heff_drop_cell(v_ru_24t_2424_24Cons, 2);
      v_x_2442 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V f_ = v_k_249;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(heff_rfield(v_x_245, 0)), heff_dup(heff_rfield(v_x_245, 1))));
  V v_s_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_str0));
  V v_path_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2412; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2413; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2413); r_; });
  V v_a_2416 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam3_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s495635622x733177935(v_t_2422, v_hd_248, heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam4, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s2110822909x2117320183_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str1, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str3, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str7, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str9, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str10, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str11, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str12, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761(V v_prog_240, V v_spec_241) {
top: ;
  V v_path_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_242); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_243, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam1, 2, 3, (V[]){v_a_245, v_spec_241, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam4(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam5(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2464);
  V v_t_2465 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam6(V self, V *args) {
  V v_x_2489 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2489);
  V v_t_2490 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2495})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2496}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam9(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k_24114 = args[1];
  V v_v_24112 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24113);
  V f_ = v_k_24114;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_24112});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam11(V self, V *args) {
  V v_x_24126 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24126);
  V v_t_24127 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
  V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
  V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
  V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24132})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24133}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam12(V self, V *args) {
  V v_x_24147 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24147) == NTAG(TAG_True))) {
    heff_drop(v_x_24147);
    return (g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269(v_prog_240, v_hd_246, v_k_247));
  } else {
    heff_drop(v_x_24147);
    heff_drop(v_prog_240);
    heff_drop(v_hd_246);
    V f_ = v_k_247;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam13(V self, V *args) {
  V v_x_24157 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24157);
  V v_t_24158 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24158})});
  V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
  V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
  V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
  V v_t_24163 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24162})});
  V v_t_24164 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24164}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam10(V self, V *args) {
  V v_x_24116 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_s_2473 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_24100 = heff_env(self)[4];
  V v_t_2430 = heff_env(self)[5];
  V v_pk_2472 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_24116)) {
  case TAG_Left: {
    V v_why_24117 = heff_field(v_x_24116, 0);
    V v_ru_24x_24116_24Left = heff_take_reuse_n(v_x_24116, 1ULL, 1);
    heff_drop(v_s_2473);
    heff_drop(v_prog_240);
    heff_drop(v_x_24100);
    heff_drop(v_t_2430);
    heff_drop(v_pk_2472);
    V v_t_24118 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str7), v_why_24117), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str8));
    V v_t_24119 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24118, NTAG(TAG_MkUnit)});
    V v_t_24120 = heff_tag_at_n(v_ru_24x_24116_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24125}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam11, 1, 2, (V[]){v_hd_246, v_k_247})));
  }
  case TAG_Right: {
    V v_ver_24134 = heff_field(v_x_24116, 0);
    V v_ru_24x_24116_24Right = heff_take_reuse_n(v_x_24116, 1ULL, 1);
    HeffT2 v_t_24135 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_ver_24134));
    {
      V v_field_24137 = v_t_24135.f[1];
      int64_t v_tag_24136 = ((int64_t)v_t_24135.f[0]);
      if ((v_tag_24136 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_24116_24Right, 1);
        V v_x_24139 = v_field_24137;
        heff_drop(v_x_24139);
        HeffT2 v_t_24140 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(v_s_2473));
        V v_t_24145;
        {
          V v_field_24141 = v_t_24140.f[0];
          V v_field_24142 = v_t_24140.f[1];
          V v_x_24143 = v_field_24141;
          V v_y_24144 = v_field_24142;
          heff_drop(v_y_24144);
          v_t_24145 = v_x_24143;
        }
        V v_c_24146 = (g_heff_2ebuild_2ecommands_2egetRequire_24s1834840764x1628104837(heff_dup(v_prog_240), v_x_24100, v_t_2430, v_pk_2472, v_t_24145, v_ver_24134));
        V f_ = v_c_24146;
        heff_room[0] = heff_dup(v_hd_246);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam12, 1, 3, (V[]){v_prog_240, v_hd_246, v_k_247});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_s_2473);
        heff_drop(v_prog_240);
        heff_drop(v_x_24100);
        heff_drop(v_t_2430);
        heff_drop(v_pk_2472);
        heff_drop(v_field_24137);
        V v_t_24148 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str9), heff_strAppend(v_ver_24134, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str10)));
        V v_t_24149 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str11), v_t_24148), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str12));
        V v_t_24150 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24149, NTAG(TAG_MkUnit)});
        V v_t_24151 = heff_tag_at_n(v_ru_24x_24116_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
        V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
        V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
        V v_t_24154 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
        V v_t_24155 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24154})});
        V v_t_24156 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24155})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24156}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam13, 1, 2, (V[]){v_hd_246, v_k_247})));
      }
    }
  }
  default: return heff_nomatch(v_x_24116);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam8(V self, V *args) {
  V v_x_24100 = args[0];
  V v_s_2473 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_t_2430 = heff_env(self)[4];
  V v_pk_2472 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_24101 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2473)));
  {
    V v_field_24102 = v_t_24101.f[0];
    V v_field_24103 = v_t_24101.f[1];
    V v_x_24104 = v_field_24102;
    heff_drop(v_x_24104);
    V v_y_24105 = v_field_24103;
    V v_c_24115;
    switch (heff_tag_of(v_y_24105)) {
    case TAG_Nothing: {
      HeffT2 v_t_24106 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2473)));
      V v_t_24111;
      {
        V v_field_24107 = v_t_24106.f[0];
        V v_field_24108 = v_t_24106.f[1];
        V v_x_24109 = v_field_24107;
        V v_y_24110 = v_field_24108;
        heff_drop(v_y_24110);
        v_t_24111 = v_x_24109;
      }
      v_c_24115 = (g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736(heff_dup(v_prog_240), v_t_24111));
      break;
    }
    case TAG_Just: {
      V v_v_24112 = heff_field(v_y_24105, 0);
      heff_take_n(v_y_24105, 1ULL, 1);
      v_c_24115 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam9, 2, 1, (V[]){v_v_24112});
      break;
    }
    default: heff_nomatch(v_y_24105);
    }
    V f_ = v_c_24115;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam10, 1, 7, (V[]){v_hd_246, v_k_247, v_s_2473, v_prog_240, v_x_24100, v_t_2430, v_pk_2472});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam7(V self, V *args) {
  V v_x_2498 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_s_2473 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_t_2430 = heff_env(self)[4];
  V v_pk_2472 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2499 = (g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(v_x_2498, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str6)));
  V f_ = v_c_2499;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam8, 1, 6, (V[]){v_s_2473, v_prog_240, v_hd_246, v_k_247, v_t_2430, v_pk_2472});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_spec_241 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    heff_drop(v_spec_241);
    heff_drop(v_prog_240);
    V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str1), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam3, 1, 2, (V[]){v_hd_246, v_k_247})));
  }
  case TAG_Just: {
    V v_t_2430 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Just = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    HeffT2 v_t_2431 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_t_2430));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        heff_drop(v_spec_241);
        heff_drop(v_prog_240);
        heff_drop(v_t_2430);
        V v_p_2435 = v_field_2433;
        heff_drop(v_p_2435);
        V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str2), NTAG(TAG_MkUnit)});
        V v_t_2437 = heff_tag_at_n(v_ru_24x_2414_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
        V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
        V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
        V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam4, 1, 2, (V[]){v_hd_246, v_k_247})));
      } else {
        V v_x_2451 = v_field_2433;
        HeffT2 v_t_2452 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2451));
        {
          V v_field_2454 = v_t_2452.f[1];
          int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
          if ((v_tag_2453 == ((int64_t)0ULL))) {
            heff_drop(v_spec_241);
            heff_drop(v_prog_240);
            heff_drop(v_t_2430);
            V v_x_2456 = v_field_2454;
            heff_drop(v_x_2456);
            V v_t_2457 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str3), NTAG(TAG_MkUnit)});
            V v_t_2458 = heff_tag_at_n(v_ru_24x_2414_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
            V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
            V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
            V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
            V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
            V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
            return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam5, 1, 2, (V[]){v_hd_246, v_k_247})));
          } else {
            V v_pk_2472 = v_field_2454;
            switch (heff_tag_of(v_spec_241)) {
            case TAG_Nothing: {
              heff_drop(v_t_2430);
              heff_drop_cell(v_ru_24x_2414_24Just, 1);
              heff_drop(v_pk_2472);
              return (g_heff_2ebuild_2ecommands_2egetAll_24s141547484x1063422269(v_prog_240, v_hd_246, v_k_247));
            }
            case TAG_Just: {
              V v_s_2473 = heff_field(v_spec_241, 0);
              V v_ru_24spec_241_24Just = heff_take_reuse_n(v_spec_241, 1ULL, 1);
              HeffT2 v_t_2474 = (g_heff_2ebuild_2ecommands_2especOf_24cpr(heff_dup(v_s_2473)));
              V v_t_2479;
              {
                V v_field_2475 = v_t_2474.f[0];
                V v_field_2476 = v_t_2474.f[1];
                V v_x_2477 = v_field_2475;
                V v_y_2478 = v_field_2476;
                heff_drop(v_y_2478);
                v_t_2479 = v_x_2477;
              }
              if (heff_strEq_c(v_t_2479, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                heff_drop(v_prog_240);
                heff_drop(v_t_2430);
                heff_drop(v_pk_2472);
                heff_drop(v_s_2473);
                V v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str4), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_str5));
                V v_t_2482 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2481, NTAG(TAG_MkUnit)});
                V v_t_2483 = heff_tag_at_n(v_ru_24x_2414_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
                V v_t_2484 = heff_tag_at_n(v_ru_24spec_241_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
                V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
                V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
                V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
                V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})});
                return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2488}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam6, 1, 2, (V[]){v_hd_246, v_k_247})));
              } else {
                heff_drop_cell(v_ru_24x_2414_24Just, 1);
                heff_drop_cell(v_ru_24spec_241_24Just, 1);
                V v_c_2497 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo);
                V f_ = v_c_2497;
                heff_room[0] = heff_dup(v_hd_246);
                heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam7, 1, 6, (V[]){v_hd_246, v_s_2473, v_prog_240, v_k_247, v_t_2430, v_pk_2472});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
            default: return heff_nomatch(v_spec_241);
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_spec_241 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s993222917x1117620761_lam2, 1, 4, (V[]){v_hd_246, v_k_247, v_spec_241, v_prog_240})));
}