// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_NoCustody 24110
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Reading 19214
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_copies 592412158
#define LBL_defs 9574869
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_fuel 9649789
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_implicit 319715269
#define LBL_info 9732469
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_line 9817275
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_output 941629484
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_units 312791945
#define LBL_zig 330130
static uint32_t shape_info[] = {LBL_info};
static uint32_t shape_output__groups__copies__jss[] = {LBL_output, LBL_groups, LBL_copies, LBL_jss};
static uint32_t shape_paths__hashes__modules__fuel[] = {LBL_paths, LBL_hashes, LBL_modules, LBL_fuel};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032(V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526_clo;
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(V, V, V, V);
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_clo;
V g_heff_2ebuild_2ecommands_2elinkOf(V);
V g_heff_2ebuild_2ecommands_2elinkOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkOf_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249(V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_2ek_24l1(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_2ek_24l1_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
HeffT2 g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
HeffT2 g_heff_2ecompile_2eglue_2elinksIn_24cpr(V);
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2efusedWith(V, V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_clo;
HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2eshared(V, V, V, V);
V g_heff_2ecompile_2elower_2eshared_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eshared_clo;
V g_heff_2ecompile_2elower_2esharedLowered(V, V);
V g_heff_2ecompile_2elower_2esharedLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2esharedLowered_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2elsp_2erender_2elineStartFrom(V, V, V);
V g_heff_2elsp_2erender_2elineStartFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineStartFrom_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2eoneLineIn(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2erender_2eoneLineIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eoneLineIn_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2erender_2espanLines(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2espanLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2espanLines_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1246062630x1975509602(V, V);
V g_list_2efoldl_24s1246062630x1975509602_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1246062630x1975509602_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1707192740x1747748619(V, V);
V g_list_2efoldl_24s1707192740x1747748619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1707192740x1747748619_clo;
V g_list_2efoldl_24s552376067x1255995125(V, V);
V g_list_2efoldl_24s552376067x1255995125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s552376067x1255995125_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s107931167x1978109134(V);
V g_list_2emap_24s107931167x1978109134_entry(V self, V *a);
extern Clo g_list_2emap_24s107931167x1978109134_clo;
V g_list_2emap_24s1127556009x863725781(V, V, V, V, V, V);
V g_list_2emap_24s1127556009x863725781_entry(V self, V *a);
extern Clo g_list_2emap_24s1127556009x863725781_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s456574265x331130481(V, V, V, V, V);
V g_list_2emap_24s456574265x331130481_entry(V self, V *a);
extern Clo g_list_2emap_24s456574265x331130481_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(heff_dup(v_text_241), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0, 0, "");
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V v_sources_240, V v_only_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_seen_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_244)));
    V v_m_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_m_249 = ((V)&g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_m_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_seen_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_m_249);
      heff_drop(v_t_2410);
      V t_0 = v_sources_240;
      V t_1 = v_only_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_sources_240 = t_0;
      v_only_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_only_241));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_seen_242);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_m_249);
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_path_244}});
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_list_2efind_24s1218501002x1291750665_24cpr(v_m_249, v_sources_240));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          V v_t_2427;
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2414;
            V v_implicit_2416 = heff_take_field(v_x_2415, 6);
            V v_source_2417 = heff_take_field(v_x_2415, 4);
            V v_renames_2418 = heff_get_n(v_x_2415, 5, 8);
            V v_t_2419 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_2416, v_source_2417));
            HeffT4 v_t_2420 = ({ V a_0 = v_renames_2418; V a_1 = v_t_2419; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(a_0, a_1)); heff_drop(v_renames_2418); r_; });
            {
              V v_field_2421 = v_t_2420.f[0];
              heff_drop(v_t_2420.f[1]);
              heff_drop(v_t_2420.f[2]);
              heff_drop(v_t_2420.f[3]);
              V v_imps_2425 = v_field_2421;
              V v_t_2426 = (g_list_2emap_24s1817208647x1282894070(v_imps_2425));
              v_t_2427 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2426));
            }
          } else {
            heff_drop(v_field_2414);
            v_t_2427 = NTAG(TAG_Nil);
          }
          V v_t_2430 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0, 1, 1, (V[]){v_path_244}), v_t_2427));
          V t_0 = v_sources_240;
          V t_1 = v_only_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_m_249, v_seen_242});
          V t_3 = v_t_2430;
          v_sources_240 = t_0;
          v_only_241 = t_1;
          v_seen_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_2428, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  return (g_prelude_2e_2b_2b(v_path_244, v_t_2429));
}
Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efirstErrorOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efirstErrorOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efirstErrorOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkOf_str1, 9, "heff.link");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkOf_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkOf_str3, 5, ".link");
Clo g_heff_2ebuild_2ecommands_2elinkOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2elinkOf(V v_outPath_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = heff_strSlice_lent(v_outPath_240, heff_box_word(v_t_241), heff_strLength_lent(v_outPath_240, 0), 6);
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2ecommands_2elinkOf_str0))) {
    return heff_strAppend(v_outPath_240, ((V)&g_heff_2ebuild_2ecommands_2elinkOf_str1));
  } else {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_244 = heff_strSlice_lent(v_outPath_240, heff_box_word(v_t_243), heff_strLength_lent(v_outPath_240, 0), 6);
    V v_t_246;
    if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2elinkOf_str2))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_246 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_245));
    } else {
      v_t_246 = v_outPath_240;
    }
    return heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2elinkOf_str3));
  }
}
V g_heff_2ebuild_2ecommands_2elinkOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elinkOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_p_242, 0));
    V v_text_245 = heff_dup(heff_rfield(v_p_242, 1));
    V v_t_246 = ({ V a_0 = v_k_241; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_247 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if (heff_strEq_c(v_module_244, v_t_2410)) {
      V v_t_2411 = ({ V a_0 = v_k_241; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_t_2412 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_text_2413 = v_text_245;
      V v_t_2414 = ({ V a_0 = v_text_2413; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7), v_text_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_text_2413); heff_drop(b_1); r_; });
      V v_t_2415 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9); V b_3 = MK_INT(23LL); V a_4 = MK_INT(23LL); V a_5 = v_t_2414; V r_ = (g_list_2emap_24s1127556009x863725781(b_0, b_1, b_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2416 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2415));
      V v_t_2417 = ({ V a_0 = v_t_2412; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2417);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2417);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_text_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s535099379x685970669(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_2410 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_a_2412 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2410), v_x_2411));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2410), v_a_2412));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2410), ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_str1)));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  heff_clo_take(self, 2);
  V v_x_2416 = ({ V a_0 = v_st_2410; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2415); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_st_2410;
  if (heff_strEq_c(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_str0))) {
    v_st_2410 = NTAG(TAG_Windows);
  } else {
    v_st_2410 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_lam2, 1, 2, (V[]){v_st_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str0, 4, "1;31");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str1, 4, "1;33");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str2, 4, "1;36");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str3, 2, "\033[");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str4, 1, "m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str5, 4, "\033[0m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str6, 4, "1;31");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str7, 4, "1;33");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str8, 4, "1;36");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str14, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str17, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str19, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_diags_245 = heff_take_field(v_c_243, 6);
    V v_path_246 = heff_take_field(v_c_243, 1);
    V v_source_247 = heff_get_n(v_c_243, 3, 14);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    HEFF_LAST return g_co_2eop_24s535099379x685970669(v_t_2413, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam1, 1, 6, (V[]){v_diags_245, v_path_246, v_source_247, v_p_241, v_rest_244, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam0(V self, V *args) {
  V v_b_248 = args[0];
  return v_b_248;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam3(V self, V *args) {
  V v_d_2424 = args[0];
  V v_path_2421 = heff_env(self)[0];
  V v_src_2422 = heff_env(self)[1];
  V v_color_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425 = (g_heff_2elsp_2erender_2ediagWhere(v_path_2421, v_src_2422, heff_dup(v_d_2424)));
  V v_color_2426 = v_color_2420;
  V v_src_2427 = v_src_2422;
  V v_d_2428 = v_d_2424;
  V v_s_2429 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_2428)));
  V v_t_2433;
  if ((heff_dup(v_color_2426) == NTAG(TAG_True))) {
    V v_t_2430 = heff_dup(heff_rfield(v_d_2428, 1));
    V v_t_2431;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_SError: {
      v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str0);
      break;
    }
    case TAG_SWarning: {
      v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str1);
      break;
    }
    case TAG_SDebug: {
      v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str2);
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str3), v_t_2431), ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str4));
    v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_s_2429), ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str5));
  } else {
    v_t_2433 = v_s_2429;
  }
  V v_color_2434 = v_color_2426;
  V v_t_2435 = heff_take_field(v_d_2428, 1);
  V v_code_2436;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_SError: {
    v_code_2436 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str6);
    break;
  }
  case TAG_SWarning: {
    v_code_2436 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str7);
    break;
  }
  case TAG_SDebug: {
    v_code_2436 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str8);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  V v_src_2437 = v_src_2427;
  V v_sp_2438 = heff_take_field(v_d_2428, 3);
  V v_color_2439 = v_color_2434;
  V v_code_2440 = v_code_2436;
  V v_src_2441 = heff_dup(v_src_2437);
  V v_sp_2442 = heff_dup(v_sp_2438);
  V v_j_2443 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str9), v_src_2437, MK_INT(0LL), 5);
  V v_t_2444;
  if (heff_intLt_c_lent(v_j_2443, MK_INT(0LL), 2)) {
    heff_drop(v_j_2443);
    v_t_2444 = NTAG(TAG_Nothing);
  } else {
    v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2443});
  }
  V v_s_2445 = (g_heff_2elsp_2erender_2elineColAt(v_src_2437, heff_dup(heff_rfield(v_sp_2438, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2444));
  V v_x_2446 = heff_take_field(v_sp_2438, 0);
  V v_y_2447 = heff_intSub(heff_get_n(v_sp_2438, 1, 2), MK_INT(1LL));
  V v_t_2448;
  if (heff_intLe_c_lent(v_x_2446, v_y_2447, 0)) {
    heff_drop(v_x_2446);
    v_t_2448 = v_y_2447;
  } else {
    heff_drop(v_y_2447);
    v_t_2448 = v_x_2446;
  }
  V v_j_2449 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str10), v_src_2437, MK_INT(0LL), 5);
  V v_t_2450;
  if (heff_intLt_c_lent(v_j_2449, MK_INT(0LL), 2)) {
    heff_drop(v_j_2449);
    v_t_2450 = NTAG(TAG_Nothing);
  } else {
    v_t_2450 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2449});
  }
  V v_e_2451 = ({ V a_0 = v_src_2437; V a_1 = v_t_2448; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2450; V r_ = (g_heff_2elsp_2erender_2elineColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2437); r_; });
  V v_t_2472;
  if (heff_intEq_c(heff_dup(heff_rfield(v_s_2445, 0)), heff_dup(heff_rfield(v_e_2451, 0)))) {
    heff_drop_rec(v_e_2451, 3);
    V v_color_2452 = v_color_2439;
    V v_code_2453 = v_code_2440;
    V v_src_2454 = v_src_2441;
    V v_sp_2455 = v_sp_2442;
    V v_start_2456 = heff_take_field(v_sp_2455, 0);
    V v_end_2457 = heff_get_n(v_sp_2455, 1, 2);
    V v_t_2458 = heff_intAdd(heff_dup(heff_rfield(v_s_2445, 0)), MK_INT(1LL));
    V v_w_2459 = (g_heff_2elsp_2erender_2enumDigits(v_t_2458));
    V v_l_2460 = heff_get_n(v_s_2445, 0, 3);
    V v_t_2461;
    if (heff_intEq_c_lent(v_l_2460, MK_INT(0LL), 2)) {
      v_t_2461 = MK_INT(0LL);
    } else {
      v_t_2461 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2454, heff_dup(v_l_2460), MK_INT(0LL)));
    }
    V v_x_2462;
    if (heff_intEq_c_lent(v_l_2460, MK_INT(0LL), 2)) {
      v_x_2462 = MK_INT(0LL);
    } else {
      v_x_2462 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2454, heff_dup(v_l_2460), MK_INT(0LL)));
    }
    V v_y_2463 = v_start_2456;
    V v_t_2464;
    if (heff_intLe_c_lent(v_x_2462, v_y_2463, 0)) {
      heff_drop(v_x_2462);
      v_t_2464 = v_y_2463;
    } else {
      heff_drop(v_y_2463);
      v_t_2464 = v_x_2462;
    }
    V v_start_2465;
    if (heff_intEq_c_lent(v_l_2460, MK_INT(0LL), 2)) {
      v_start_2465 = MK_INT(0LL);
    } else {
      v_start_2465 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2454, heff_dup(v_l_2460), MK_INT(0LL)));
    }
    V v_j_2466 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str11), v_src_2454, v_start_2465, 5);
    V v_x_2467;
    if (heff_intLt_c_lent(v_j_2466, MK_INT(0LL), 2)) {
      heff_drop(v_j_2466);
      v_x_2467 = heff_strLength_lent(v_src_2454, 0);
    } else {
      v_x_2467 = v_j_2466;
    }
    V v_y_2468 = v_end_2457;
    V v_t_2469;
    if (heff_intLe_c_lent(v_x_2467, v_y_2468, 0)) {
      heff_drop(v_y_2468);
      v_t_2469 = v_x_2467;
    } else {
      heff_drop(v_x_2467);
      v_t_2469 = v_y_2468;
    }
    v_t_2472 = ({ V a_0 = v_color_2452; V a_1 = v_code_2453; V a_2 = v_src_2454; V a_3 = v_w_2459; V a_4 = v_l_2460; V a_5 = v_t_2461; V a_6 = v_t_2464; V a_7 = v_t_2469; V r_ = (g_heff_2elsp_2erender_2eoneLineIn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_color_2452); heff_drop(v_src_2454); r_; });
  } else {
    heff_drop(v_sp_2442);
    V v_t_2470 = heff_intAdd(heff_dup(heff_rfield(v_e_2451, 0)), MK_INT(1LL));
    V v_t_2471 = (g_heff_2elsp_2erender_2enumDigits(v_t_2470));
    v_t_2472 = (g_heff_2elsp_2erender_2espanLines(v_color_2439, v_code_2440, v_src_2441, v_t_2471, v_s_2445, v_e_2451));
  }
  V v_t_2473 = heff_take_field(v_d_2428, 4);
  V v_t_2475;
  switch (heff_tag_of(v_t_2473)) {
  case TAG_Nothing: {
    v_t_2475 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str12);
    break;
  }
  case TAG_Just: {
    V v_n_2474 = heff_field(v_t_2473, 0);
    heff_take_n(v_t_2473, 1ULL, 1);
    v_t_2475 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str13), v_n_2474);
    break;
  }
  default: heff_nomatch(v_t_2473);
  }
  V v_t_2476 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str14)), heff_get_n(v_d_2428, 2, 5));
  V v_t_2477 = heff_strAppend(heff_strAppend(v_t_2476, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str15)), v_t_2472);
  V v_t_2478 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str16)), heff_strAppend(v_t_2477, v_t_2475));
  return heff_strAppend(v_t_2478, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str17));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam4(V self, V *args) {
  V v_x_2490 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_drop(v_x_2490);
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_diags_245 = heff_env(self)[0];
  V v_path_246 = heff_env(self)[1];
  V v_source_247 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_rest_244 = heff_env(self)[4];
  V v_p_242 = heff_env(self)[5];
  V v_t_2415 = heff_dup(v_diags_245);
  V v_c_2489;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nil: {
    heff_drop(v_x_2414);
    heff_drop(v_diags_245);
    heff_drop(v_path_246);
    heff_drop(v_source_247);
    v_c_2489 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam2_clo);
    break;
  }
  case TAG_Cons: {
    V v_ru_24t_2415_24Cons = heff_take_reuse_n(v_t_2415, 0ULL, 2);
    V v_color_2420 = v_x_2414;
    V v_path_2421 = v_path_246;
    V v_src_2422 = v_source_247;
    V v_ds_2423 = v_diags_245;
    V v_x2_2479 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam3, 1, 3, (V[]){v_path_2421, v_src_2422, v_color_2420}), v_ds_2423));
    V v_str_2482;
    switch (heff_tag_of(v_x2_2479)) {
    case TAG_Nil: {
      v_str_2482 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2480 = heff_field(v_x2_2479, 0);
      V v_xs_2481 = heff_field(v_x2_2479, 1);
      heff_take_n(v_x2_2479, 3ULL, 2);
      v_str_2482 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_str19); V a_1 = v_x_2480; V a_2 = v_xs_2481; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2481); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2479);
    }
    V v_t_2483 = heff_tag_at_n(v_ru_24t_2415_24Cons, TAG_WriteErr, 2, (V[]){v_str_2482, NTAG(TAG_MkUnit)});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})});
    v_c_2489 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})}));
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V f_ = v_c_2489;
  heff_room[0] = heff_dup(v_p_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_lam4, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str2, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str4, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(V v_ps_240, V v_b_241, V v_id_242, V v_z_243, V v_z_244) {
top: ;
  V v_s_245 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_245));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam0_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam1, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_z_243, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_drop(v_x_2425);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_drop(v_x_2436);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam4(V self, V *args) {
  V v_x_2446 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_drop(v_x_2446);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    heff_take_n(v_x_2415, 0ULL, 1);
    V v_d_2417 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    heff_clo_take(self, 5);
    V v_st_2418 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_d_2417));
    V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str0)));
    V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
    V v_t_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
    V v_t_2423 = heff_strAppend(heff_strAppend(heff_dup(v_id_242), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str1)), v_b_241);
    V v_t_2424 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(v_t_2422, v_t_2423));
    V f_ = v_t_2424;
    heff_room[0] = v_z_243;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam2, 1, 2, (V[]){v_z_244, v_id_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2426 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2426)) {
    case TAG_Left: {
      heff_take_n(v_y_2426, 0ULL, 1);
      V v_d_2428 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
      heff_clo_take(self, 5);
      V v_st_2429 = heff_get_n(v_ps_240, 5, 6);
      V v_t_2430 = (g_std_2epath_2eparse(heff_dup(v_st_2429), v_d_2428));
      V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2429), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str2)));
      V v_t_2432 = (g_std_2epath_2ejoin(v_t_2430, v_t_2431));
      V v_t_2433 = ({ V a_0 = v_st_2429; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2429); heff_drop(v_t_2432); r_; });
      V v_t_2434 = heff_strAppend(heff_strAppend(heff_dup(v_id_242), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str3)), v_b_241);
      V v_t_2435 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(v_t_2433, v_t_2434));
      V f_ = v_t_2435;
      heff_room[0] = v_z_243;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam3, 1, 2, (V[]){v_z_244, v_id_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Right: {
      heff_take_n(v_y_2426, 0ULL, 1);
      V v_d_2438 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
      heff_clo_take(self, 5);
      V v_st_2439 = heff_get_n(v_ps_240, 5, 6);
      V v_t_2440 = (g_std_2epath_2eparse(heff_dup(v_st_2439), v_d_2438));
      V v_t_2441 = (g_std_2epath_2eparse(heff_dup(v_st_2439), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str4)));
      V v_t_2442 = (g_std_2epath_2ejoin(v_t_2440, v_t_2441));
      V v_t_2443 = ({ V a_0 = v_st_2439; V a_1 = v_t_2442; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2439); heff_drop(v_t_2442); r_; });
      V v_t_2444 = heff_strAppend(heff_strAppend(heff_dup(v_id_242), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_str5)), v_b_241);
      V v_t_2445 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(v_t_2443, v_t_2444));
      V f_ = v_t_2445;
      heff_room[0] = v_z_243;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_lam4, 1, 2, (V[]){v_z_244, v_id_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_y_2426);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str10, 9, "custodian");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str11, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str12, 1, ".");
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052(V v_bi_240, V v_outPath_241, V v_done_242, V v_c_243, V v_available_244, V v_r_245, V v_hd_246, V v_k_247) {
top: ;
  V v_key_248 = heff_take_field(v_r_245, 0);
  V v_effect_249 = heff_get_n(v_r_245, 1, 2);
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam0, 1, 9, (V[]){v_bi_240, v_hd_246, v_available_244, v_c_243, v_key_248, v_effect_249, v_outPath_241, v_done_242, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam3(V self, V *args) {
  V v_roots_2453 = args[0];
  V v_supply_2454 = args[1];
  V v_kept_2455 = args[2];
  V v_errors_2456 = args[3];
  V v_fuel_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = (g_heff_2ecompile_2elower_2eshared(v_fuel_2433, v_roots_2453, v_supply_2454, v_kept_2455));
  return (g_heff_2ecompile_2elower_2esharedLowered(v_errors_2456, v_t_2457));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam4(V self, V *args) {
  V v_acc_2468 = args[0];
  V v_k_2469 = args[1];
  V v_shorts_2467 = heff_env(self)[0];
  V v_facts_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2eemit_2einfoOne(v_shorts_2467, v_facts_2462, v_acc_2468, v_k_2469));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_available_244 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_key_248 = heff_env(self)[4];
  V v_effect_249 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_242 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_fuel_2417 = heff_dup(heff_rfield(v_bi_240, 3));
  heff_clo_take(self, 10);
  V v_available_2418 = v_available_244;
  V v_g_2419 = heff_get_n(heff_get_n(v_c_243, 5, 14), 0, 10);
  V v_key_2420 = v_key_248;
  V v_eff_2421 = v_effect_249;
  V v_vers_2422 = heff_dup(heff_rfield(v_bi_240, 1));
  V v_m_2423 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_t_2424 = ({ V a_0 = v_m_2423; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2423); r_; });
  V v_bs_2425 = (g_list_2emap_24s1173914895x100384474(v_t_2424));
  V v_t_2426 = (g_list_2efoldl_24s1707192740x1747748619(heff_dup(g_std_2eordmap_2eempty_get()), v_bs_2425));
  V v_t_2427 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2425; V r_ = (g_list_2efoldl_24s552376067x1255995125(a_0, a_1)); heff_drop(v_bs_2425); r_; });
  V v_ks_2428 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2426, v_t_2427});
  V v_m_2429 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_t_2430 = ({ V a_0 = v_m_2429; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2429); r_; });
  V v_bs_2431 = (g_list_2emap_24s1173914895x100384474(v_t_2430));
  V v_kept_2432 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2431; V r_ = (g_list_2efoldl_24s1246062630x1975509602(a_0, a_1)); heff_drop(v_bs_2431); r_; });
  V v_fuel_2433 = v_fuel_2417;
  V v_t_2434 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_2421));
  V v_xs_2435 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str2); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str3); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str4); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str5); V a_6 = v_t_2434; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
  V v_t_2436 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_2435));
  V v_provs_2437 = ({ V a_0 = v_available_2418; V a_1 = v_t_2436; V r_ = (g_heff_2ecompile_2eemit_2eprovsForGo(a_0, a_1)); heff_drop(v_available_2418); r_; });
  V v_eff_2438 = heff_dup(v_eff_2421);
  V v_key_2439 = heff_dup(v_key_2420);
  V v_kept_2440 = v_kept_2432;
  V v_t_2441 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_2421));
  V v_ms_2442 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str6); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str7); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str8); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str9); V a_6 = v_t_2441; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
  V v_t_2443 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str10); V a_1 = v_ms_2442; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); heff_drop(v_ms_2442); r_; });
  V v_t_2444;
  if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
    heff_drop(v_t_2443);
    v_t_2444 = NTAG(TAG_Reading);
  } else {
    heff_drop(v_t_2443);
    v_t_2444 = NTAG(TAG_NoCustody);
  }
  HeffT4 v_t_2445 = (g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(v_t_2444, heff_tag_n(TAG_Just, 1, (V[]){v_eff_2421}), v_g_2419, v_key_2420, v_vers_2422, v_ks_2428));
  {
    V v_field_2446 = v_t_2445.f[0];
    V v_field_2447 = v_t_2445.f[1];
    V v_field_2448 = v_t_2445.f[2];
    V v_field_2449 = v_t_2445.f[3];
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_t_2451 = (g_heff_2ecompile_2elower_2efusedOf(v_t_2450, v_field_2446));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_l_2458 = heff_tr(g_heff_2ecompile_2elower_2efusedWith(heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam3, 4, 1, (V[]){v_fuel_2433}), v_t_2452, v_field_2447, v_t_2451));
    V v_facts_2459 = heff_take_field(v_l_2458, 1);
    V v_defs_2460 = heff_take_field(v_l_2458, 0);
    V v_errors_2461 = heff_get_n(v_l_2458, 2, 3);
    V v_facts_2462 = v_facts_2459;
    V v_defs_2463 = v_defs_2460;
    V v_roots_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_kept_2465 = v_kept_2440;
    V v_keys_2466 = (g_list_2emap_24s1835183789x486277886(heff_dup(v_defs_2463)));
    V v_shorts_2467 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str11); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str12); V b_3 = MK_INT(0LL); V a_4 = heff_dup(v_keys_2466); V r_ = (g_list_2emap_24s456574265x331130481(b_0, a_1, b_2, b_3, a_4)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
    V v_t_2470 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam4, 2, 2, (V[]){v_shorts_2467, v_facts_2462}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_keys_2466; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_keys_2466); r_; });
    HeffT2 v_t_2471 = ({ V a_0 = heff_rec_n(1, shape_info, (V[]){v_t_2470}); V a_1 = v_defs_2463; V a_2 = v_roots_2464; V a_3 = v_kept_2465; HeffT2 r_ = (g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_defs_2463); r_; });
    {
      V v_field_2472 = v_t_2471.f[0];
      V v_field_2473 = v_t_2471.f[1];
      V v_t_2474 = ({ V a_0 = v_provs_2437; V a_1 = v_eff_2438; V a_2 = v_key_2439; V a_3 = v_field_2472; V r_ = (g_heff_2ecompile_2eemit_2erunSource(a_0, a_1, a_2, a_3)); heff_drop(v_key_2439); r_; });
      V v_t_2475 = heff_rec_n(4, shape_output__groups__copies__jss, (V[]){heff_rec_n(2, shape_source__errors, (V[]){v_t_2474, v_errors_2461}), v_field_2448, v_field_2449, v_field_2473});
      return ({ V a_0 = v_bi_240; V a_1 = v_outPath_241; V a_2 = v_x_2410; V a_3 = v_x_2415; V a_4 = v_t_2416; V a_5 = v_done_242; V a_6 = v_t_2475; V a_7 = v_hd_246; V a_8 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1831805074x1412368526(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2415); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_available_244 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_key_248 = heff_env(self)[4];
  V v_effect_249 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_242 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  heff_clo_take(self, 9);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_lam2, 1, 10, (V[]){v_x_2410, v_bi_240, v_available_244, v_c_243, v_key_248, v_effect_249, v_outPath_241, v_done_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436(V v_chk_240, V v_acc_241, V v_f_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam0, 2, 4, (V[]){v_c_243, v_f_242, v_acc_241, v_chk_240});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  heff_drop(v_x_2413);
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam4(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam11(V self, V *args) {
  V v_c_2428 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_path_2429 = heff_take_field(v_c_2428, 1);
  V v_module_2430 = heff_get_n(v_c_2428, 0, 14);
  V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_x_2424, 2)), 1, 6);
  heff_clo_take(self, 4);
  V v_t_2432 = (g_heff_2ebuild_2eload_2einside(heff_get_n(v_x_2424, 2, 5), v_t_2431, v_path_2429));
  if (((heff_dup(v_t_2432) == NTAG(TAG_True)) || ({ V v_t_2443 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242))); int c_ = heff_strEq_c_lent(v_module_2430, v_t_2443, 0); heff_drop(v_t_2443); c_; }))) {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop(v_t_2432);
    V v_x1_2433 = ({ V a_0 = v_module_2430; V b_1 = heff_get_n(v_acc_241, 0, 2); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(v_module_2430); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2433) == NTAG(TAG_True)));
    heff_drop(v_x1_2433);
    return v_ret_24bool;
  } else {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop_rec(v_acc_241, 2);
    heff_drop(v_module_2430);
    heff_drop(v_t_2432);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam13(V self, V *args) {
  V v_x_2438 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_drop(v_x_2438);
  heff_clo_take(self, 4);
  V v_t_2439 = (g_prelude_2e_2b_2b_24f427551988x255400191(heff_take_field(v_acc_241, 0), heff_dup(v_x_2434)));
  V v_t_2440 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2434; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_x_2434); r_; });
  V v_t_2441 = heff_intAdd(heff_take_field(v_acc_241, 1), v_x_2425);
  V v_x_2442 = ({ V rv_0 = v_t_2439; V rv_1 = heff_intAdd(v_t_2441, v_t_2440); V rr_ = heff_rec_reuse_nf(v_acc_241, 0ULL, 2, shape_seen__errors, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_245;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam12(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_drop(v_x_2435);
  heff_clo_take(self, 6);
  V v_t_2436 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam13, 1, 4, (V[]){v_acc_241, v_x_2434, v_x_2425, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam10(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_x_2418 = heff_env(self)[5];
  V v_x_2425 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2434 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam11, 1, 4, (V[]){v_x_2424, v_x_248, v_f_242, heff_dup(v_acc_241)}), heff_get_n(v_x_2427, 0, 2)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_x_2434), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam12, 1, 6, (V[]){v_x_2418, v_hd_244, v_acc_241, v_x_2434, v_x_2425, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam9(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_acc_241 = heff_env(self)[4];
  V v_x_2418 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_t_2426 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_x_2424)));
  heff_clo_take(self, 7);
  V f_ = v_t_2426;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam10, 1, 8, (V[]){v_x_2424, v_x_248, v_f_242, v_acc_241, v_hd_244, v_x_2418, v_x_2425, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_acc_241 = heff_env(self)[4];
  V v_x_2418 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_t_2423 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2422, heff_dup(heff_rfield(v_x_2421, 4))));
  heff_clo_take(self, 7);
  V v_x_2424 = (g_list_2efoldl_24s571074576x1179600767(v_x_2421, v_t_2423));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_str0), heff_dup(heff_rfield(v_x_2424, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam9, 1, 7, (V[]){v_x_2424, v_hd_244, v_x_248, v_f_242, v_acc_241, v_x_2418, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam8, 1, 7, (V[]){v_x_2421, v_hd_244, v_x_248, v_f_242, v_acc_241, v_x_2418, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2420, heff_dup(v_f_242), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam7, 1, 6, (V[]){v_hd_244, v_x_248, v_f_242, v_acc_241, v_x_2418, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_c_2419 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam6, 1, 6, (V[]){v_f_242, v_hd_244, v_x_248, v_acc_241, v_x_2418, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_chk_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_249 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = heff_rfield(v_acc_241, 0); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_249); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    heff_clo_take(self, 5);
    heff_drop(v_f_242);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_tag_n(TAG_Complete, 2, (V[]){v_chk_240, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam3, 1, 2, (V[]){v_k_245, v_acc_241})));
  } else {
    heff_drop(v_t_2410);
    V v_name_2414 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
    heff_clo_take(self, 5);
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_240, v_name_2414, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam4_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s535099379x685970669(v_t_2417, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam5, 1, 5, (V[]){v_hd_244, v_f_242, v_x_248, v_acc_241, v_k_245})));
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_247 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(v_x_246, heff_dup(v_f_242)));
  heff_clo_take(self, 5);
  V f_ = v_t_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam2, 1, 5, (V[]){v_f_242, v_acc_241, v_chk_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_lam1, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_chk_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587(V v_lit_240, V v_who_241, V v_st_242, V v_flags_243, V v_p_244, V v_dir_245, V v_out_246, V v_next_247) {
top: ;
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_245)));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam1, 2, 10, (V[]){v_a_2411, v_st_242, v_dir_245, v_p_244, v_flags_243, v_out_246, v_next_247, v_who_241, v_lit_240, v_path_248});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam3(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_248, v_t_2425));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_flags_243 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  V v_who_241 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  V v_path_248 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 11);
    heff_drop(v_path_248);
    return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_2ek_24l1(v_st_242, v_dir_245, v_p_244, v_hd_2412, v_flags_243, v_out_246, v_next_247, v_k_2413, v_who_241, v_lit_240, heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420})));
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 11);
      heff_drop(v_path_248);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_2ek_24l1(v_st_242, v_dir_245, v_p_244, v_hd_2412, v_flags_243, v_out_246, v_next_247, v_k_2413, v_who_241, v_lit_240, heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422})));
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 11);
      V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam3, 1, 1, (V[]){v_path_248}), v_x_2423));
      V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_2ek_24l1(v_st_242, v_dir_245, v_p_244, v_hd_2412, v_flags_243, v_out_246, v_next_247, v_k_2413, v_who_241, v_lit_240, heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2427})));
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_dir_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_flags_243 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_who_241 = heff_env(self)[7];
  V v_lit_240 = heff_env(self)[8];
  V v_path_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_lam2, 1, 11, (V[]){v_st_242, v_dir_245, v_p_244, v_hd_2412, v_flags_243, v_out_246, v_next_247, v_k_2413, v_who_241, v_lit_240, v_path_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s535099379x685970669(v_t_249, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam3(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_st_2411 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_x_2427 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Left = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0(v_dir_240, v_st_2411, v_x_2412, v_hd_241, v_k_242, heff_tag_re_n(v_ru_24x_2426_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2427})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      V v_err_2429 = heff_field(v_y_2428, 0);
      V v_ru_24y_2428_24Left = heff_take_reuse_n(v_y_2428, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2426_24Right, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0(v_dir_240, v_st_2411, v_x_2412, v_hd_241, v_k_242, heff_tag_re_n(v_ru_24y_2428_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2429})));
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_2ek_24l0(v_dir_240, v_st_2411, v_x_2412, v_hd_241, v_k_242, heff_tag_at_n(v_ru_24x_2426_24Right, TAG_Right, 1, (V[]){v_x_2430})));
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_2411 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2411), heff_dup(v_dir_240)));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2411), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_str1)));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  V v_s_2416 = ({ V a_0 = v_st_2411; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_path_2417 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2416));
  V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2417; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2417); r_; });
  V v_a_2420 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam3_clo)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2425, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam4, 1, 5, (V[]){v_dir_240, v_st_2411, v_x_2412, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_st_2411;
  if (heff_strEq_c(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_str0))) {
    v_st_2411 = NTAG(TAG_Windows);
  } else {
    v_st_2411 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_lam2, 1, 4, (V[]){v_st_2411, v_dir_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str4, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str5, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str9, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str14, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str16, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str17, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str19, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str21, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam10(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_failed_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2412 = v_field_2411;
      V v_t_2413 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2412)));
      V v_t_2414 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2413); r_; });
      V v_t_2415 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2414));
      V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str3); V a_6 = v_t_2415; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2417 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2416));
      V v_c_2418 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(v_sources_241, v_t_2417));
      return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam0, 1, 8, (V[]){v_z_247, v_name_243, v_outPath_244, v_c_2412, v_z_248, v_file_242, v_failed_245, v_bi_240})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_field_2411);
      V v_t_24102 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str21), NTAG(TAG_MkUnit)});
      V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
      V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
      V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
      V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
      V v_t_24107 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24107}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam10, 1, 2, (V[]){v_z_247, v_z_248})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8]); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam2(V self, V *args) {
  V v_r_2427 = args[0];
  return v_r_2427;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam3(V self, V *args) {
  V v_x_2434 = args[0];
  V v_outPath_244 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_c_2412 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    V v_x_2435 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Left = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0(v_outPath_244, v_z_247, v_c_2412, v_x_2420, v_z_248, heff_tag_re_n(v_ru_24x_2434_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2435})));
  }
  case TAG_Right: {
    V v_y_2436 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Right = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    switch (heff_tag_of(v_y_2436)) {
    case TAG_Left: {
      V v_err_2437 = heff_field(v_y_2436, 0);
      V v_ru_24y_2436_24Left = heff_take_reuse_n(v_y_2436, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2434_24Right, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0(v_outPath_244, v_z_247, v_c_2412, v_x_2420, v_z_248, heff_tag_re_n(v_ru_24y_2436_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2437})));
    }
    case TAG_Right: {
      V v_x_2438 = heff_field(v_y_2436, 0);
      heff_take_n(v_y_2436, 1ULL, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0(v_outPath_244, v_z_247, v_c_2412, v_x_2420, v_z_248, heff_tag_at_n(v_ru_24x_2434_24Right, TAG_Right, 1, (V[]){v_x_2438})));
    }
    default: return heff_nomatch(v_y_2436);
    }
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam4(V self, V *args) {
  V v_x_2458 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2449 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_drop(v_x_2458);
  heff_clo_take(self, 5);
  V v_t_2459 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str9), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str10));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2459, v_why_2449);
  heff_room[1] = v_z_247;
  heff_room[2] = v_z_248;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam5(V self, V *args) {
  V v_x_2475 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2466 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_drop(v_x_2475);
  heff_clo_take(self, 5);
  V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str14), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str15));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2476, v_why_2466);
  heff_room[1] = v_z_247;
  heff_room[2] = v_z_248;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam6(V self, V *args) {
  V v_s_2478 = args[0];
  return v_s_2478;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam9(V self, V *args) {
  V v_x_2496 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2487 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_drop(v_x_2496);
  heff_clo_take(self, 5);
  V v_t_2497 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str19), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str20));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2497, v_why_2487);
  heff_room[1] = v_z_247;
  heff_room[2] = v_z_248;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam8(V self, V *args) {
  V v_x_2486 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_outPath_244 = heff_env(self)[4];
  V v_glues_2461 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_bi_240 = heff_env(self)[7];
  V v_name_243 = heff_env(self)[8];
  V v_x_2420 = heff_env(self)[9];
  V v_c_2412 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Left: {
    V v_why_2487 = heff_field(v_x_2486, 0);
    V v_ru_24x_2486_24Left = heff_take_reuse_n(v_x_2486, 1ULL, 1);
    heff_clo_take(self, 11);
    heff_drop(v_outPath_244);
    heff_drop(v_glues_2461);
    heff_drop(v_x_2419);
    heff_drop(v_bi_240);
    heff_drop_tag(v_name_243, 1);
    heff_drop_rec(v_x_2420, 4);
    heff_drop_rec(v_c_2412, 14);
    V v_t_2488 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str16), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str17));
    V v_t_2489 = heff_strAppend(heff_strAppend(v_t_2488, heff_dup(v_why_2487)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str18));
    V v_t_2490 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2489, NTAG(TAG_MkUnit)});
    V v_t_2491 = heff_tag_at_n(v_ru_24x_2486_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam9, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2487, v_z_247, v_z_248})));
  }
  case TAG_Right: {
    V v_fs_2498 = heff_field(v_x_2486, 0);
    V v_ru_24x_2486_24Right = heff_take_reuse_n(v_x_2486, 1ULL, 1);
    V v_t_2499 = (g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249(heff_dup(v_outPath_244), v_fs_2498));
    heff_clo_take(self, 11);
    V v_t_24100 = (g_list_2emap_24s1435185561x202019164(v_glues_2461));
    V v_t_24101 = (g_prelude_2e_2b_2b(v_x_2419, v_t_24100));
    return ({ V a_0 = v_ru_24x_2486_24Right; V a_1 = v_bi_240; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_x_2420; V a_6 = v_failed_245; V a_7 = v_t_2499; V a_8 = v_c_2412; V a_9 = v_t_24101; V a_10 = v_z_247; V a_11 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop_tag(v_name_243, 1); r_; });
  }
  default: return heff_nomatch(v_x_2486);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam7(V self, V *args) {
  V v_x_2485 = args[0];
  V v_links_2477 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_failed_245 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_outPath_244 = heff_env(self)[5];
  V v_glues_2461 = heff_env(self)[6];
  V v_x_2419 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  V v_name_243 = heff_env(self)[9];
  V v_x_2420 = heff_env(self)[10];
  V v_c_2412 = heff_env(self)[11];
  heff_clo_take(self, 12);
  return ({ V a_0 = v_x_2485; V a_1 = v_links_2477; V a_2 = heff_dup(v_z_247); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam8, 1, 11, (V[]){v_file_242, v_z_247, v_failed_245, v_z_248, v_outPath_244, v_glues_2461, v_x_2419, v_bi_240, v_name_243, v_x_2420, v_c_2412}); V r_ = (g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(a_0, a_1, a_2, a_3)); heff_drop(v_x_2485); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_outPath_244 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_c_2412 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_x_2419 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_failed_245 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_x_2419);
    heff_drop(v_file_242);
    heff_drop(v_failed_245);
    heff_drop(v_bi_240);
    int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
    V v_t_2422 = heff_strSlice_lent(v_outPath_244, heff_box_word(v_t_2421), heff_strLength_lent(v_outPath_244, 0), 6);
    V v_t_2424;
    if (heff_strEq_c(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str4))) {
      int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
      v_t_2424 = heff_strSlice_lent(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2423), 6);
    } else {
      v_t_2424 = heff_dup(v_outPath_244);
    }
    V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str5))));
    V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2425; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2425); r_; });
    V v_a_2428 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2426, heff_dup(heff_rfield(v_x_2420, 1)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam2_clo)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2433, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam3, 1, 5, (V[]){v_outPath_244, v_z_247, v_c_2412, v_x_2420, v_z_248})));
  }
  case TAG_Just: {
    V v_t_2440 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2412)));
    V v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2440); r_; });
    V v_leaves_2442 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2441));
    V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2419)}));
    V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 0, 10);
    V v_t_2445 = (g_list_2emap_24s164225955x66209884(v_t_2444, v_t_2443, v_leaves_2442));
    HeffT2 v_t_2446 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2445));
    {
      V v_field_2448 = v_t_2446.f[1];
      int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
      if ((v_tag_2447 == ((int64_t)0ULL))) {
        heff_drop_rec(v_x_2420, 4);
        heff_drop_tag(v_name_243, 1);
        heff_drop(v_outPath_244);
        heff_drop_rec(v_c_2412, 14);
        heff_drop(v_x_2419);
        heff_drop(v_bi_240);
        V v_why_2449 = v_field_2448;
        V v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str6), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str7));
        V v_t_2451 = heff_strAppend(heff_strAppend(v_t_2450, heff_dup(v_why_2449)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str8));
        V v_t_2452 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2451, NTAG(TAG_MkUnit)});
        V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
        V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
        V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
        V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
        V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam4, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2449, v_z_247, v_z_248})));
      } else {
        V v_ms_2460 = v_field_2448;
        V v_glues_2461 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2460));
        V v_t_2462 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 0, 10);
        HeffT2 v_t_2463 = (g_heff_2ecompile_2eglue_2elinksIn_24cpr(v_t_2462));
        {
          V v_field_2465 = v_t_2463.f[1];
          int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
          if ((v_tag_2464 == ((int64_t)0ULL))) {
            heff_drop_rec(v_x_2420, 4);
            heff_drop_tag(v_name_243, 1);
            heff_drop(v_outPath_244);
            heff_drop_rec(v_c_2412, 14);
            heff_drop(v_x_2419);
            heff_drop(v_bi_240);
            heff_drop(v_glues_2461);
            V v_why_2466 = v_field_2465;
            V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str11), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str12));
            V v_t_2468 = heff_strAppend(heff_strAppend(v_t_2467, heff_dup(v_why_2466)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_str13));
            V v_t_2469 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2468, NTAG(TAG_MkUnit)});
            V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
            V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
            V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
            V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
            V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
            return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam5, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2466, v_z_247, v_z_248})));
          } else {
            V v_links_2477 = v_field_2465;
            V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam6_clo)})});
            V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
            V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
            V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
            V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
            V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
            return (g_co_2eop_24s535099379x685970669(v_t_2484, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam7, 1, 12, (V[]){v_links_2477, v_z_247, v_file_242, v_failed_245, v_z_248, v_outPath_244, v_glues_2461, v_x_2419, v_bi_240, v_name_243, v_x_2420, v_c_2412})));
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2412 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_failed_245 = heff_env(self)[6];
  V v_bi_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam1, 1, 9, (V[]){v_name_243, v_outPath_244, v_z_247, v_c_2412, v_z_248, v_x_2419, v_file_242, v_failed_245, v_bi_240})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_lam10(V self, V *args) {
  V v_x_24108 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_drop(v_x_24108);
  V v_t_24109 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24113})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24114}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996(V v_lit_240, V v_fuel_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam0, 1, 8, (V[]){v_l_242, v_hd_246, v_fuel_241, v_lit_240, v_k_247, v_file_245, v_name_243, v_outPath_244})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam2(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_c_2415); V a_1 = v_sources_2413; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2413); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2418;
      V v_t_2420 = ({ V a_0 = v_x_2414; V a_1 = v_s_2419; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2414); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2420));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam4(V self, V *args) {
  V v_a_2441 = args[0];
  V v_z_2442 = args[1];
  V v_z_2443 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2441);
  heff_clo_take(self, 1);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_z_2442, v_z_2443));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_cs_2422 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_done_2411 = heff_env(self)[5];
  V v_l_242 = heff_env(self)[6];
  V v_hashes_2412 = heff_env(self)[7];
  V v_fuel_241 = heff_env(self)[8];
  V v_file_245 = heff_env(self)[9];
  V v_name_243 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  heff_drop(v_x_2423);
  heff_clo_take(self, 12);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop(v_done_2411);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_hashes_2412);
    heff_drop(v_fuel_241);
    heff_drop(v_file_245);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    V v_x2_2424 = ({ V a_0 = v_cs_2422; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2422); r_; });
    heff_drop(v_x2_2424);
    V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_hd_246, v_k_247));
  } else {
    V v_t_2431 = (g_list_2eany_24s1740858080x874135214(v_cs_2422));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_done_2411);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_hashes_2412);
      heff_drop(v_fuel_241);
      heff_drop(v_file_245);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_t_2431);
      V v_x2_2432 = ({ V a_0 = v_cs_2422; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2422); r_; });
      heff_drop(v_x2_2432);
      V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_246, v_k_247));
    } else {
      heff_drop(v_t_2431);
      V v_t_2439 = (g_list_2emap_24s1698496827x1884878103(v_done_2411));
      V v_t_2440 = heff_rec_n(4, shape_paths__hashes__modules__fuel, (V[]){heff_take_field(v_l_242, 2), v_hashes_2412, v_t_2439, v_fuel_241});
      return ({ V a_0 = v_t_2440; V a_1 = heff_get_n(v_l_242, 0, 5); V a_2 = v_file_245; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam4, 3, 1, (V[]){v_lit_240}); V a_6 = v_cs_2422; V a_7 = v_hd_246; V a_8 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_cs_2422); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_file_245 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_2411 = heff_take_field(v_x_2410, 0);
  V v_hashes_2412 = heff_get_n(v_x_2410, 1, 2);
  V v_sources_2413 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2414 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_str2), heff_dup(v_sources_2413)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam2, 1, 2, (V[]){v_sources_2413, v_x_2414}), heff_dup(v_done_2411)));
  V v_cs_2422;
  if ((heff_dup(v_fuel_241) == NTAG(TAG_True))) {
    v_cs_2422 = v_x_2421;
  } else {
    v_cs_2422 = (g_list_2emap_24s107931167x1978109134(v_x_2421));
  }
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2422), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam3, 1, 12, (V[]){v_x_248, v_cs_2422, v_lit_240, v_hd_246, v_k_247, v_done_2411, v_l_242, v_hashes_2412, v_fuel_241, v_file_245, v_name_243, v_outPath_244})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_file_245 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_t_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_l_242)));
  heff_clo_take(self, 8);
  V f_ = v_t_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s213033435x1952929996_lam1, 1, 9, (V[]){v_l_242, v_fuel_241, v_hd_246, v_x_248, v_lit_240, v_k_247, v_file_245, v_name_243, v_outPath_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}