// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_arity 294440695
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_build 295453320
#define LBL_copies 592412158
#define LBL_defs 9574869
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_emitted 749050271
#define LBL_ended 298010324
#define LBL_entries 787768015
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_file 9638467
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_info 9732469
#define LBL_js 10160
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_message 1186782793
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_order 307364712
#define LBL_outPath 1272254166
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_seen 10021698
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_text 10052084
#define LBL_top 324559
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_info[] = {LBL_info};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508(V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_clo;
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136(V, V, V, V);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ecompile_2eemit_2eemitKeptIn(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKeptIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKeptIn_clo;
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587(V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eany_24s130813166x1111413304(V, V);
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a);
extern Clo g_list_2eany_24s130813166x1111413304_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s331724893x1262243254(V);
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a);
extern Clo g_list_2eany_24s331724893x1262243254_clo;
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s650566757x317183241(V, V, V);
V g_list_2efoldl_24s650566757x317183241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s650566757x317183241_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24f2124896334x71745266(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_clo;
V g_list_2emap_24s1127556009x863725781(V, V, V, V, V, V);
V g_list_2emap_24s1127556009x863725781_entry(V self, V *a);
extern Clo g_list_2emap_24s1127556009x863725781_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s456574265x331130481(V, V, V, V, V);
V g_list_2emap_24s456574265x331130481_entry(V self, V *a);
extern Clo g_list_2emap_24s456574265x331130481_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(heff_dup(v_text_241), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0, 0, "");
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V v_sources_240, V v_only_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_seen_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_244)));
    V v_m_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_m_249 = ((V)&g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_m_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_seen_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_m_249);
      heff_drop(v_t_2410);
      V t_0 = v_sources_240;
      V t_1 = v_only_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_sources_240 = t_0;
      v_only_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_only_241));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_seen_242);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_m_249);
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_path_244}});
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_list_2efind_24s1218501002x1291750665_24cpr(v_m_249, v_sources_240));
        V v_t_2423;
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2414;
            V v_renames_2416 = heff_take_field(v_x_2415, 5);
            V v_implicit_2417 = heff_take_field(v_x_2415, 6);
            V v_source_2418 = heff_get_n(v_x_2415, 4, 8);
            V v_t_2419 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_2417, v_source_2418));
            V v_t_2420 = ({ V a_0 = v_renames_2416; V a_1 = v_t_2419; V r_ = (g_heff_2esyntax_2eimport_2erenamed(a_0, a_1)); heff_drop(v_renames_2416); r_; });
            V v_imps_2421 = heff_get_n(v_t_2420, 0, 4);
            V v_t_2422 = (g_list_2emap_24s1817208647x1282894070(v_imps_2421));
            v_t_2423 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2422));
          } else {
            heff_drop(v_field_2414);
            v_t_2423 = NTAG(TAG_Nil);
          }
        }
        V v_t_2426 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0, 1, 1, (V[]){v_path_244}), v_t_2423));
        V t_0 = v_sources_240;
        V t_1 = v_only_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_m_249, v_seen_242});
        V t_3 = v_t_2426;
        v_sources_240 = t_0;
        v_only_241 = t_1;
        v_seen_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_2424, NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_path_244, v_t_2425));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_p_242, 0));
    V v_text_245 = heff_dup(heff_rfield(v_p_242, 1));
    V v_t_246 = ({ V a_0 = v_k_241; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_247 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if (heff_strEq_c(v_module_244, v_t_2410)) {
      V v_t_2411 = ({ V a_0 = v_k_241; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_t_2412 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_text_2413 = v_text_245;
      V v_t_2414 = ({ V a_0 = v_text_2413; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7), v_text_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_text_2413); heff_drop(b_1); r_; });
      V v_t_2415 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9); V b_3 = MK_INT(23LL); V a_4 = MK_INT(23LL); V a_5 = v_t_2414; V r_ = (g_list_2emap_24s1127556009x863725781(b_0, b_1, b_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2416 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2415));
      V v_t_2417 = ({ V a_0 = v_t_2412; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2417);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2417);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_text_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773(V v_e_240, V v_badLoad_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_cs_242), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_lam0, 1, 5, (V[]){v_cs_242, v_e_240, v_hd_243, heff_dup(v_badLoad_241), v_k_244})));
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_badLoad_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_cs_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2418);
  if ((heff_dup(v_badLoad_241) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_241);
    heff_drop(v_cs_242);
    V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_243, v_k_244));
  } else {
    heff_drop(v_badLoad_241);
    V v_t_2426 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_242); r_; });
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_243, v_k_244));
    } else {
      heff_drop(v_e_240);
      heff_drop(v_hd_243);
      heff_drop(v_t_2426);
      V f_ = v_k_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_badLoad_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  HeffT2 v_t_246 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_242));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_248;
      V v_str_2410 = (g_heff_2ebuild_2edriver_2einterface(v_c_249));
      V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2410, NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_lam1, 1, 5, (V[]){v_badLoad_241, v_e_240, v_hd_243, v_k_244, v_cs_242})));
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badLoad_241);
      heff_drop(v_field_248);
      V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_hd_243, v_k_244));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str0, 2, ".o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str1, 11, "-femit-bin=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str2, 2, "-O");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str3, 9, "build-obj");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193(V v_e_240, V v_z_241, V v_mode_242, V v_x3_243, V v_made_244) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_made_244));
    V v_x_246 = heff_tag_n(TAG_Right, 1, (V[]){v_t_245});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_f_249 = heff_field(v_x3_243, 0);
    V v_rest_2410 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam1, 2, 6, (V[]){v_f_249, v_mode_242, v_z_241, v_e_240, v_rest_2410, v_made_244});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam2(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_mode_242 = heff_env(self)[2];
  V v_rest_2410 = heff_env(self)[3];
  V v_o_2414 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2422 = heff_dup(heff_rfield(v_x_2421, 0));
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Exited: {
    V v_n_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    if (heff_intEq_c(v_n_2423, MK_INT(0LL))) {
      heff_drop_rec(v_x_2421, 3);
      V v_t_2424 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193(v_e_240, v_z_241, v_mode_242, v_rest_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_o_2414, v_made_244})));
      V f_ = v_t_2424;
      heff_room[0] = v_hd_2411;
      heff_room[1] = v_k_2412;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_e_240);
      heff_drop(v_z_241);
      heff_drop(v_mode_242);
      heff_drop(v_rest_2410);
      heff_drop(v_o_2414);
      heff_drop(v_made_244);
      heff_drop(v_hd_2411);
      V f_ = v_k_2412;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2421});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2422, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    heff_drop(v_rest_2410);
    heff_drop(v_o_2414);
    heff_drop(v_made_244);
    heff_drop(v_hd_2411);
    V f_ = v_k_2412;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_TimedOut: {
    heff_drop(v_e_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    heff_drop(v_rest_2410);
    heff_drop(v_o_2414);
    heff_drop(v_made_244);
    heff_drop(v_hd_2411);
    V f_ = v_k_2412;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2422, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    heff_drop(v_rest_2410);
    heff_drop(v_o_2414);
    heff_drop(v_made_244);
    heff_drop(v_hd_2411);
    V f_ = v_k_2412;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2422);
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_f_249 = heff_env(self)[0];
  V v_mode_242 = heff_env(self)[1];
  V v_z_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_f_249, 0)) - ((int64_t)4ULL));
  V v_o_2414 = heff_strAppend(heff_strSlice_lent(v_f_249, MK_INT(0LL), heff_box_word(v_t_2413), 6), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str0));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str1), heff_dup(v_o_2414)), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str2), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_mode_242), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_f_249, v_t_2416})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_z_241), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_str4), v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam2_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2420, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193_lam3, 1, 8, (V[]){v_e_240, v_z_241, v_mode_242, v_rest_2410, v_o_2414, v_made_244, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(V v_e_240, V v_sources_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_sources_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_e_247 = heff_dup(v_e_240);
    V v_sources_248 = heff_dup(v_sources_241);
    V v_m_249 = v_m_245;
    HeffT2 v_t_2410 = ({ V a_0 = v_sources_248; V a_1 = v_m_249; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(a_0, a_1)); heff_drop(v_sources_248); r_; });
    V v_c_2433;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_path_2413 = v_field_2412;
        int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_path_2413, 0)) - ((int64_t)3ULL));
        V v_t_2415 = heff_strSlice(heff_dup(v_path_2413), heff_box_word(v_t_2414), heff_strLength_lent(v_path_2413, 0));
        V v_t_2417;
        if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_str0))) {
          int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_path_2413, 0)) - ((int64_t)3ULL));
          v_t_2417 = heff_strSlice(v_path_2413, MK_INT(0LL), heff_box_word(v_t_2416));
        } else {
          v_t_2417 = v_path_2413;
        }
        V v_path_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_str1))));
        V v_c_2419 = ({ V a_0 = heff_dup(v_e_247); V a_1 = v_path_2418; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2418); r_; });
        V v_t_2420 = (g_exception_2eattempted(v_e_247));
        V v_c_2424 = heff_tr(heff_call(v_c_2419, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam1_clo)}));
        v_c_2433 = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam2, 2, 2, (V[]){v_c_2424, v_m_249});
      } else {
        heff_drop(v_e_247);
        heff_drop(v_m_249);
        heff_drop(v_field_2412);
        v_c_2433 = ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam4_clo);
      }
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam5, 2, 4, (V[]){v_c_2433, v_e_240, v_sources_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    heff_drop(v_m_249);
    V f_ = v_k_2426;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    V v_t_2430 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_249, v_y_2429})});
    V f_ = v_k_2426;
    args[0] = v_t_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam3, 1, 2, (V[]){v_k_2426, v_m_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Nothing: {
    v_t_2440 = v_x_2438;
    break;
  }
  case TAG_Just: {
    V v_pr_2439 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2439, v_x_2438});
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V f_ = v_k_2435;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sources_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2434 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2437 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(v_e_240, v_sources_241, v_rest_246));
  V f_ = v_c_2437;
  heff_room[0] = v_hd_2434;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam7, 1, 2, (V[]){v_x_2436, v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sources_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_lam6, 1, 5, (V[]){v_e_240, v_sources_241, v_rest_246, v_hd_2434, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158(V v_e_240, V v_dir_241, V v_parts_242, V v_x3_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_dir_241);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2415, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam1, 1, 7, (V[]){heff_dup(v_n_246), heff_dup(v_parts_242), v_dir_241, v_e_240, v_p_244, heff_dup(v_rest_247), v_p_245})));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158(a[0], a[1], a2, a3, a[4], a[5]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2429 = args[1];
  V v_k_2430 = args[2];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    heff_take_n(v_x_2434, 0ULL, 1);
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2434, 0ULL, 1);
    v_t_2437 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_k_2433;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2431;
  args[0] = v_hd_2432;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam5, 1, 1, (V[]){v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_parts_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2439);
  return ({ V a_0 = v_e_240; V a_1 = v_dir_241; V a_2 = v_parts_242; V a_3 = v_rest_247; V a_4 = v_p_244; V a_5 = v_p_245; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_parts_242); heff_drop(v_rest_247); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_246 = heff_env(self)[0];
  V v_parts_242 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2417;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_t_2418 = (g_list_2eany_24s130813166x1111413304(v_n_246, v_parts_242));
  V v_c_2438;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_n_246);
    heff_drop(v_st_2417);
    heff_drop(v_t_2418);
    v_c_2438 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam2_clo);
  } else {
    heff_drop(v_t_2418);
    V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_dir_241)));
    V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_n_246));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    V v_s_2424 = ({ V a_0 = v_st_2417; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2423); r_; });
    V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2424));
    V v_c_2426 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2425; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2425); r_; });
    V v_t_2427 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2431 = heff_tr(heff_call(v_c_2426, 2, (V[]){v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam3_clo)}));
    v_c_2438 = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam4, 2, 1, (V[]){v_c_2431});
  }
  V f_ = v_c_2438;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158_lam6, 1, 6, (V[]){v_e_240, v_dir_241, v_parts_242, v_rest_247, v_p_244, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str2, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909(V v_e_240, V v_dir_241, V v_done_242, V v_x3_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_parts_246 = heff_field(v_x3_243, 0);
    V v_errors_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(heff_dup(v_e_240), heff_dup(v_errors_247), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam0, 1, 7, (V[]){v_errors_247, v_dir_241, v_e_240, v_p_244, v_parts_246, v_done_242, v_p_245})));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2421 = (g_list_2emap_24s219049803x1458391381(v_x_2420));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam4, 2, 1, (V[]){v_x_2421});
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_p_244, v_p_245));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_dir_241 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2427) == NTAG(TAG_True))) {
    heff_drop(v_x_2427);
    heff_drop(v_dir_241);
    heff_drop(v_e_240);
    V f_ = v_done_242;
    heff_room[0] = v_p_244;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2427);
    heff_drop(v_done_242);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str0), v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str1));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam7, 1, 3, (V[]){v_e_240, v_p_244, v_p_245})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam10(V self, V *args) {
  V v_x_2455 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2455);
  V v_t_2456 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), v_p_244, v_p_245));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_dir_241 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2446) == NTAG(TAG_True))) {
    heff_drop(v_x_2446);
    heff_drop(v_dir_241);
    heff_drop(v_e_240);
    V f_ = v_done_242;
    heff_room[0] = v_p_244;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2446);
    heff_drop(v_done_242);
    V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str2), v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_str3));
    V v_t_2448 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2447, NTAG(TAG_MkUnit)});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam10, 1, 3, (V[]){v_e_240, v_p_244, v_p_245})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam8(V self, V *args) {
  V v_x_2445 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_parts_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2445);
  return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_dir_241); V a_2 = v_parts_246; V a_3 = heff_dup(v_p_244); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam9, 1, 5, (V[]){v_done_242, v_p_244, v_p_245, v_dir_241, v_e_240}); V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_parts_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    heff_take_n(v_x_2425, 0ULL, 1);
    return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_dir_241); V a_2 = v_parts_246; V a_3 = heff_dup(v_p_244); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam6, 1, 5, (V[]){v_done_242, v_p_244, v_p_245, v_dir_241, v_e_240}); V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_246); r_; });
  }
  case TAG_Right: {
    V v_y_2444 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_dir_241); V a_2 = v_parts_246; V a_3 = v_y_2444; V a_4 = heff_dup(v_p_244); V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam8, 1, 6, (V[]){v_e_240, v_dir_241, heff_dup(v_parts_246), v_p_244, v_done_242, v_p_245}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1177010932x97184158(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_parts_246); heff_drop(v_y_2444); r_; });
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_parts_246 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2416);
  V v_path_2417 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_241)));
  V v_c_2418 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2417));
  V v_t_2419 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2424 = heff_tr(heff_call(v_c_2418, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam3_clo)}));
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam5, 1, 6, (V[]){v_e_240, v_dir_241, v_parts_246, v_p_244, v_done_242, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_errors_247 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_parts_246 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  switch (heff_tag_of(v_errors_247)) {
  case TAG_Nil: {
    V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_241)));
    V v_c_2410 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_249; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_249); r_; });
    V v_t_2411 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam1_clo)}));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_p_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_lam2, 1, 6, (V[]){v_dir_241, v_e_240, v_p_244, v_parts_246, v_done_242, v_p_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_ru_24errors_247_24Cons = heff_take_reuse_n(v_errors_247, 0ULL, 2);
    heff_drop(v_dir_241);
    heff_drop(v_parts_246);
    heff_drop(v_done_242);
    V v_t_2465 = heff_tag_at_n(v_ru_24errors_247_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_p_244, v_p_245));
  }
  default: return heff_nomatch(v_errors_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547(V v_lit_240, V v_e_241, V v_failed_242, V v_l_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_241), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str0), heff_dup(heff_rfield(v_l_243, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam0, 1, 9, (V[]){v_e_241, v_l_243, v_hd_247, v_file_245, v_failed_242, v_k_248, v_lit_240, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  V v_sources_2414 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = ({ V a_0 = heff_dup(v_c_2416); V a_1 = v_sources_2414; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2414); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      V v_t_2421 = ({ V a_0 = v_x_2415; V a_1 = v_s_2420; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2415); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2416, v_t_2421));
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_field_2419);
      return v_c_2416;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_file_245 = heff_env(self)[2];
  V v_failed_242 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_done_2412 = heff_env(self)[6];
  V v_l_243 = heff_env(self)[7];
  V v_hashes_2413 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  V v_e_241 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  V v_done_246 = heff_env(self)[12];
  heff_clo_take(self, 13);
  heff_drop(v_x_2423);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop(v_done_2412);
    heff_drop_rec(v_l_243, 5);
    heff_drop(v_hashes_2413);
    heff_drop(v_lit_240);
    heff_drop(v_e_241);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    HeffT2 v_t_2424 = ({ V a_0 = v_x_2422; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2422); r_; });
    V v_t_2428;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        heff_drop(v_file_245);
        V v_x_2427 = v_field_2426;
        v_t_2428 = v_x_2427;
      } else {
        heff_drop(v_field_2426);
        v_t_2428 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str3));
      }
    }
    V f_ = v_failed_242;
    heff_room[0] = v_t_2428;
    heff_room[1] = v_hd_247;
    heff_room[2] = v_k_248;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    V v_t_2429 = (g_list_2eany_24s1740858080x874135214(v_x_2422));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_done_2412);
      heff_drop_rec(v_l_243, 5);
      heff_drop(v_hashes_2413);
      heff_drop(v_lit_240);
      heff_drop(v_e_241);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2429);
      HeffT2 v_t_2430 = ({ V a_0 = v_x_2422; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2422); r_; });
      V v_t_2434;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          heff_drop(v_file_245);
          V v_x_2433 = v_field_2432;
          v_t_2434 = v_x_2433;
        } else {
          heff_drop(v_field_2432);
          v_t_2434 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str4));
        }
      }
      V f_ = v_failed_242;
      heff_room[0] = v_t_2434;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_t_2429);
      V v_t_2435 = (g_list_2emap_24s1698496827x1884878103(v_done_2412));
      V v_t_2436 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_243, 2), v_hashes_2413, v_t_2435});
      return ({ V a_0 = v_lit_240; V a_1 = v_e_241; V a_2 = v_t_2436; V a_3 = heff_get_n(v_l_243, 0, 5); V a_4 = v_file_245; V a_5 = v_outPath_244; V a_6 = v_failed_242; V a_7 = v_done_246; V a_8 = v_x_2422; V a_9 = v_hd_247; V a_10 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_x_2422); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_file_245 = heff_env(self)[4];
  V v_failed_242 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_done_2412 = heff_take_field(v_x_2411, 0);
  V v_hashes_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_sources_2414 = heff_dup(heff_rfield(v_l_243, 0));
  V v_x_2415 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_str2), heff_dup(v_sources_2414)));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam2, 1, 2, (V[]){v_sources_2414, v_x_2415}), heff_dup(v_done_2412)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_241), heff_dup(v_x_2422), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam3, 1, 13, (V[]){v_x_249, v_x_2422, v_file_245, v_failed_242, v_hd_247, v_k_248, v_done_2412, v_l_243, v_hashes_2413, v_lit_240, v_e_241, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_file_245 = heff_env(self)[3];
  V v_failed_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_241), heff_dup(v_l_243)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_lam1, 1, 10, (V[]){v_l_243, v_e_241, v_hd_247, v_x_249, v_file_245, v_failed_242, v_k_248, v_lit_240, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str4, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str5, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str6, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str7, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str8, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str9, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str10, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str11, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str12, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str13, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str14, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str15, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str16, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str17, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str18, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str19, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str20, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str21, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str22, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str23, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str27, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str28, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str29, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str30, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str31, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str32, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487(V v_lit_240, V v_lit_241, V v_e_242, V v_failed_243, V v_who_244, V v_st_245, V v_p_246, V v_dir_247, V v_out_248, V v_next_249) {
top: ;
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_247)));
  V v_c_2411 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_242), v_path_2410));
  V v_t_2412 = (g_exception_2eattempted(heff_dup(v_e_242)));
  V v_c_2417 = heff_tr(heff_call(v_c_2411, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam2, 2, 11, (V[]){v_c_2417, v_st_245, v_dir_247, v_p_246, v_e_242, v_lit_240, v_lit_241, v_out_248, v_next_249, v_who_244, v_failed_243});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2414 = (g_list_2emap_24s219049803x1458391381(v_x_2413));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam1, 2, 1, (V[]){v_x_2414});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam4(V self, V *args) {
  V v_n_2427 = args[0];
  V v_st_245 = heff_env(self)[0];
  V v_dir_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_dir_247));
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_n_2427));
  V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
  return ({ V a_0 = v_st_245; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_2430); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam5(V self, V *args) {
  V v_n_2435 = args[0];
  V v_st_245 = heff_env(self)[0];
  V v_dir_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_dir_247));
  V v_t_2437 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_n_2435));
  V v_t_2438 = (g_std_2epath_2ejoin(v_t_2436, v_t_2437));
  return ({ V a_0 = v_st_245; V a_1 = v_t_2438; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_2438); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam6(V self, V *args) {
  V v_t_2443 = args[0];
  return v_t_2443;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam9(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_r_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = v_r_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam10(V self, V *args) {
  V v_r_2468 = args[0];
  return v_r_2468;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam14(V self, V *args) {
  V v_x_24107 = args[0];
  V v_who_244 = heff_env(self)[0];
  V v_out_248 = heff_env(self)[1];
  V v_failed_243 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24107);
  V v_t_24108 = heff_strAppend(heff_strAppend(v_who_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str32)), v_out_248);
  V f_ = v_failed_243;
  heff_room[0] = v_t_24108;
  heff_room[1] = v_hd_2418;
  heff_room[2] = v_k_2419;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam13(V self, V *args) {
  V v_x_2498 = args[0];
  V v_who_244 = heff_env(self)[0];
  V v_out_248 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_failed_243 = heff_env(self)[4];
  V v_k_2419 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2498);
  V v_t_2499 = heff_strAppend(heff_strAppend(heff_dup(v_who_244), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str30)), heff_dup(v_out_248));
  V v_t_24100 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2499, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str31)), NTAG(TAG_MkUnit)});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
  return (g_co_2eop_24s310169282x2049378029(v_e_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_24106}), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam14, 1, 5, (V[]){v_who_244, v_out_248, v_failed_243, v_hd_2418, v_k_2419})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam12(V self, V *args) {
  V v_x_2477 = args[0];
  V v_ended_2473 = heff_env(self)[0];
  V v_next_249 = heff_env(self)[1];
  V v_hd_2418 = heff_env(self)[2];
  V v_k_2419 = heff_env(self)[3];
  V v_err_2474 = heff_env(self)[4];
  V v_e_242 = heff_env(self)[5];
  V v_who_244 = heff_env(self)[6];
  V v_out_248 = heff_env(self)[7];
  V v_failed_243 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2477);
  V v_t_2481;
  switch (heff_tag_of(v_ended_2473)) {
  case TAG_Exited: {
    V v_n_2478 = heff_dup(heff_field(v_ended_2473, 0));
    v_t_2481 = heff_bool(heff_intEq_c_lent(v_n_2478, MK_INT(0LL), 2));
    heff_drop(v_n_2478);
    break;
  }
  case TAG_Signalled: {
    v_t_2481 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2481 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2481 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2473);
  }
  if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
    heff_drop(v_ended_2473);
    heff_drop(v_err_2474);
    heff_drop(v_e_242);
    heff_drop(v_who_244);
    heff_drop(v_out_248);
    heff_drop(v_failed_243);
    heff_drop(v_t_2481);
    V f_ = v_next_249;
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_249);
    heff_drop(v_t_2481);
    V v_t_2490;
    switch (heff_tag_of(v_ended_2473)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2473, 0ULL, 1);
      v_t_2490 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str24);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2473, 0ULL, 1);
      v_t_2490 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str25);
      break;
    }
    case TAG_TimedOut: {
      v_t_2490 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str26);
      break;
    }
    case TAG_NotRun: {
      V v_err_2484 = heff_field(v_ended_2473, 0);
      heff_take_n(v_ended_2473, 1ULL, 1);
      V v_path_2485 = heff_take_field(v_err_2484, 3);
      V v_name_2486 = heff_take_field(v_err_2484, 1);
      V v_message_2487 = heff_get_n(v_err_2484, 2, 4);
      V v_t_2488 = heff_strAppend(heff_strAppend(v_path_2485, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str27)), v_name_2486);
      V v_t_2489 = heff_strAppend(heff_strAppend(v_t_2488, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str28)), v_message_2487);
      v_t_2490 = heff_strAppend(v_t_2489, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str29));
      break;
    }
    default: heff_nomatch(v_ended_2473);
    }
    V v_t_2491 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2490, v_err_2474), NTAG(TAG_MkUnit)});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_242), heff_tag_n(TAG_InR, 1, (V[]){v_t_2497}), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam13, 1, 6, (V[]){v_who_244, v_out_248, v_e_242, v_hd_2418, v_failed_243, v_k_2419})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam11(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_2418 = heff_env(self)[2];
  V v_next_249 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  V v_who_244 = heff_env(self)[5];
  V v_out_248 = heff_env(self)[6];
  V v_failed_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_ended_2473 = heff_take_field(v_x_2472, 0);
  V v_err_2474 = heff_get_n(v_x_2472, 2, 3);
  V v_t_2475 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_242), heff_tag_n(TAG_InR, 1, (V[]){v_t_2476}), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam12, 1, 9, (V[]){v_ended_2473, v_next_249, v_hd_2418, v_k_2419, v_err_2474, v_e_242, v_who_244, v_out_248, v_failed_243})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_x_2446 = heff_env(self)[3];
  V v_x_2431 = heff_env(self)[4];
  V v_out_248 = heff_env(self)[5];
  V v_hd_2418 = heff_env(self)[6];
  V v_next_249 = heff_env(self)[7];
  V v_k_2419 = heff_env(self)[8];
  V v_who_244 = heff_env(self)[9];
  V v_failed_243 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_lit_2450 = v_lit_240;
  V v_lit_2451 = v_lit_241;
  V v_e_2452 = heff_dup(v_e_242);
  V v_z_2453 = heff_dup(v_x_2446);
  V v_files_2454 = v_x_2431;
  V v_out_2455 = heff_dup(v_out_248);
  V v_x5_2456 = v_x_2449;
  V v_c_2471;
  switch (heff_tag_of(v_x5_2456)) {
  case TAG_Left: {
    V v_r_2457 = heff_field(v_x5_2456, 0);
    heff_take_n(v_x5_2456, 1ULL, 1);
    heff_drop(v_lit_2450);
    heff_drop(v_lit_2451);
    heff_drop(v_e_2452);
    heff_drop(v_z_2453);
    heff_drop(v_files_2454);
    heff_drop(v_out_2455);
    v_c_2471 = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam9, 2, 1, (V[]){v_r_2457});
    break;
  }
  case TAG_Right: {
    V v_os_2460 = heff_field(v_x5_2456, 0);
    V v_ru_24x5_2456_24Right = heff_take_reuse_n(v_x5_2456, 1ULL, 1);
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str19), NTAG(TAG_Nil)});
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str20), heff_tag_n(TAG_Cons, 2, (V[]){v_out_2455, v_t_2461})});
    V v_t_2463 = (g_prelude_2e_2b_2b(v_os_2460, v_t_2462));
    V v_t_2464 = (g_prelude_2e_2b_2b(v_files_2454, v_t_2463));
    V v_ys_2465 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str21), v_t_2464});
    V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_2450, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_2451, v_ys_2465})});
    V v_argv_2467 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str22), v_t_2466});
    V v_t_2469 = heff_tag_at_n(v_ru_24x5_2456_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){v_z_2453, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str23), v_argv_2467, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam10_clo)})});
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
    v_c_2471 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_2452, v_t_2470}));
    break;
  }
  default: heff_nomatch(v_x5_2456);
  }
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_2418);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam11, 1, 8, (V[]){v_x_2446, v_e_242, v_hd_2418, v_next_249, v_k_2419, v_who_244, v_out_248, v_failed_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam7(V self, V *args) {
  V v_x_2446 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_hd_2418 = heff_env(self)[4];
  V v_x_2431 = heff_env(self)[5];
  V v_out_248 = heff_env(self)[6];
  V v_next_249 = heff_env(self)[7];
  V v_k_2419 = heff_env(self)[8];
  V v_who_244 = heff_env(self)[9];
  V v_failed_243 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2447;
  if ((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str3), 2) || heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str4), 2))) {
    v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str5);
  } else {
    if ((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str6), 2) || heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str7), 2))) {
      v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str8);
    } else {
      if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str9), 2)) {
        v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str10);
      } else {
        if (heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str11), 2)) {
          v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str12);
        } else {
          if (((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str13), 2) || heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str14), 2)) || (heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str15), 2) || heff_strEq_c_lent(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str16), 2)))) {
            v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str17);
          } else {
            v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str18);
          }
        }
      }
    }
  }
  V v_c_2448 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1316562641x508495193(heff_dup(v_e_242), heff_dup(v_x_2446), v_t_2447, v_x_2439, NTAG(TAG_Nil)));
  V f_ = v_c_2448;
  heff_room[0] = heff_dup(v_hd_2418);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam8, 1, 11, (V[]){v_lit_240, v_lit_241, v_e_242, v_x_2446, v_x_2431, v_out_248, v_hd_2418, v_next_249, v_k_2419, v_who_244, v_failed_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_245 = heff_env(self)[0];
  V v_dir_247 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_hd_2418 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_out_248 = heff_env(self)[7];
  V v_next_249 = heff_env(self)[8];
  V v_k_2419 = heff_env(self)[9];
  V v_who_244 = heff_env(self)[10];
  V v_failed_243 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_x_2423;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    heff_take_n(v_x_2420, 0ULL, 1);
    v_x_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    v_x_2423 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_Just, 1, (V[]){v_y_2422});
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_t_2425;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2424 = heff_dup(heff_field(v_x_2423, 0));
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V v_t_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str0); V a_1 = v_t_2425; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2431 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam4, 1, 2, (V[]){heff_dup(v_st_245), heff_dup(v_dir_247)}), v_t_2426));
  V v_t_2433;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2432 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    v_t_2433 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V v_t_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str1); V a_1 = v_t_2433; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2439 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam5, 1, 2, (V[]){v_st_245, v_dir_247}), v_t_2434));
  V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2431));
  V v_t_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2439));
  V v_total_2442 = heff_intAdd(heff_intAdd(v_t_2440, v_t_2441), MK_INT(1LL));
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_246, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_str2), v_total_2442, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam6_clo)})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_242), v_t_2445, heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam7, 1, 11, (V[]){v_lit_240, v_lit_241, v_e_242, v_x_2439, v_hd_2418, v_x_2431, v_out_248, v_next_249, v_k_2419, v_who_244, v_failed_243})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  V v_dir_247 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_e_242 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_out_248 = heff_env(self)[7];
  V v_next_249 = heff_env(self)[8];
  V v_who_244 = heff_env(self)[9];
  V v_failed_243 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1018819695x1904439487_lam3, 1, 12, (V[]){v_st_245, v_dir_247, v_p_246, v_e_242, v_hd_2418, v_lit_240, v_lit_241, v_out_248, v_next_249, v_k_2419, v_who_244, v_failed_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236(V v_e_240, V v_bi_241, V v_outPath_242, V v_id_243, V v_texts_244, V v_backs_245, V v_done_246, V v_out_247, V v_z_248, V v_z_249) {
top: ;
  V v_groups_2410 = heff_take_field(v_out_247, 1);
  V v_copies_2411 = heff_take_field(v_out_247, 2);
  V v_jss_2412 = heff_take_field(v_out_247, 3);
  V v_output_2413 = heff_get_n(v_out_247, 0, 4);
  V v_paths_2414 = heff_take_field(v_bi_241, 0);
  V v_modules_2415 = heff_get_n(v_bi_241, 2, 3);
  V v_t_2434;
  if (heff_strEq_c_lent(v_id_243, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_str0), 2)) {
    heff_drop(v_id_243);
    heff_drop(v_backs_245);
    heff_drop(v_groups_2410);
    heff_drop(v_copies_2411);
    heff_drop(v_jss_2412);
    heff_drop(v_paths_2414);
    heff_drop(v_modules_2415);
    v_t_2434 = v_done_246;
  } else {
    V v_s_2416 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2414)));
    V v_path_2417 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2416));
    V v_c_2418 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2417; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2417); r_; });
    V v_t_2419 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2423 = heff_tr(heff_call(v_c_2418, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam0_clo)}));
    v_t_2434 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam1, 2, 11, (V[]){v_c_2423, heff_dup(v_texts_244), v_modules_2415, v_groups_2410, v_copies_2411, v_jss_2412, v_id_243, v_backs_245, heff_dup(v_e_240), v_paths_2414, v_done_246});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(v_e_240, v_outPath_242, v_t_2434, v_output_2413, v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2421 = args[1];
  V v_k_2422 = args[2];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2433);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2424;
  heff_room[1] = v_k_2425;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_texts_244 = heff_env(self)[0];
  V v_modules_2415 = heff_env(self)[1];
  V v_groups_2410 = heff_env(self)[2];
  V v_copies_2411 = heff_env(self)[3];
  V v_jss_2412 = heff_env(self)[4];
  V v_id_243 = heff_env(self)[5];
  V v_backs_245 = heff_env(self)[6];
  V v_e_240 = heff_env(self)[7];
  V v_paths_2414 = heff_env(self)[8];
  V v_hd_2424 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  V v_k_2425 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2426);
  V v_t_2427 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_244); r_; });
  V v_t_2428 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_str1), NTAG(TAG_MkUnit)));
  V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_modules_2415; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2415); r_; });
  V v_t_2430 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2410, v_copies_2411, NTAG(TAG_Nil), v_jss_2412});
  V v_t_2431 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2429, v_backs_245}), v_t_2430));
  V v_c_2432 = ({ V a_0 = v_e_240; V a_1 = v_paths_2414; V a_2 = v_t_2427; V a_3 = v_t_2431; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(a_0, a_1, a_2, a_3)); heff_drop(v_t_2427); heff_drop(v_t_2431); r_; });
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam3, 1, 3, (V[]){v_done_246, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam1(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_texts_244 = heff_env(self)[1];
  V v_modules_2415 = heff_env(self)[2];
  V v_groups_2410 = heff_env(self)[3];
  V v_copies_2411 = heff_env(self)[4];
  V v_jss_2412 = heff_env(self)[5];
  V v_id_243 = heff_env(self)[6];
  V v_backs_245 = heff_env(self)[7];
  V v_e_240 = heff_env(self)[8];
  V v_paths_2414 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_lam2, 1, 12, (V[]){v_texts_244, v_modules_2415, v_groups_2410, v_copies_2411, v_jss_2412, v_id_243, v_backs_245, v_e_240, v_paths_2414, v_hd_2424, v_done_246, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str0, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str1, 46, ": build it with `zig build-obj -O ReleaseFast ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str3, 8, "heff.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str4, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str5, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str6, 39, " -femit-bin=runtime.o` and `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str8, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str9, 26, " runtime.o -o PROGRAM -lm`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568(V v_e_240, V v_name_241, V v_outPath_242, V v_file_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str0), heff_dup(v_outPath_242)), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str1));
  V v_outPath_247 = heff_dup(v_outPath_242);
  int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_outPath_247, 0)) - ((int64_t)1ULL));
  V v_t_249 = heff_strSlice(heff_dup(v_outPath_247), heff_box_word(v_t_248), heff_strLength_lent(v_outPath_247, 0));
  V v_t_2414;
  if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str2))) {
    v_t_2414 = heff_strAppend(v_outPath_247, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str3));
  } else {
    int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_outPath_247, 0)) - ((int64_t)2ULL));
    V v_t_2411 = heff_strSlice(heff_dup(v_outPath_247), heff_box_word(v_t_2410), heff_strLength_lent(v_outPath_247, 0));
    V v_t_2413;
    if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str4))) {
      int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_outPath_247, 0)) - ((int64_t)2ULL));
      v_t_2413 = heff_strSlice(v_outPath_247, MK_INT(0LL), heff_box_word(v_t_2412));
    } else {
      v_t_2413 = v_outPath_247;
    }
    v_t_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str5));
  }
  V v_t_2415 = heff_strAppend(heff_strAppend(v_t_246, v_t_2414), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str6));
  int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_outPath_242, 0)) - ((int64_t)1ULL));
  V v_t_2417 = heff_strSlice(heff_dup(v_outPath_242), heff_box_word(v_t_2416), heff_strLength_lent(v_outPath_242, 0));
  V v_t_2418;
  if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str7))) {
    v_t_2418 = heff_strAppend(heff_dup(v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str8));
  } else {
    v_t_2418 = heff_dup(v_outPath_242);
  }
  V v_str_2419 = heff_strAppend(heff_strAppend(v_t_2415, v_t_2418), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str9));
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_file_243), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_lam0, 1, 7, (V[]){v_str_2419, v_e_240, v_name_241, v_outPath_242, v_file_243, v_z_244, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_lam1(V self, V *args) {
  V v_why_2429 = args[0];
  V v_z_2430 = args[1];
  V v_z_2431 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_why_2429);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_z_2430, v_z_2431));
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_str_2419 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  V v_file_243 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2421 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2419, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_str10)), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(heff_dup(v_e_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568_lam1, 3, 1, (V[]){v_e_240}), v_x_2420, v_name_241, v_outPath_242, v_file_243, v_t_2428, v_z_244, v_z_245));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str1, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str2, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str3, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str5, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str7, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str10, 16, "export default {");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str14, 2, "};");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str17, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str18, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str19, 6, "  get ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str20, 17, "() { return $ext(");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str21, 2, "$c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str22, 2, "()");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str23, 9, "undefined");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str24, 5, "); },");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str25, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str26, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str27, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str28, 14, "heff compile: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str29, 19, ": no such directory");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str30, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897(V v_e_240, V v_o_241, V v_hd_242, V v_k_243) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136(heff_dup(v_e_240), heff_dup(v_o_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam0, 1, 4, (V[]){v_o_241, v_e_240, v_hd_242, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam5(V self, V *args) {
  V v_acc_2445 = args[0];
  V v_k_2446 = args[1];
  V v_g_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2447 = ({ V b_0 = heff_get_n(v_g_2443, 1, 8); V a_1 = v_k_2446; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      V v_e_2450 = v_field_2449;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2446, v_e_2450}), v_acc_2445});
    } else {
      heff_drop(v_k_2446);
      heff_drop(v_field_2449);
      return v_acc_2445;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam6(V self, V *args) {
  V v_d_2465 = args[0];
  V v_reached_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2466 = ({ V a_0 = v_reached_2464; V b_1 = heff_get_n(v_d_2465, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_2464); heff_drop(b_1); r_; });
  {
    V v_field_2468 = v_t_2466.f[1];
    int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2467 == ((int64_t)0ULL)) && ({ V v_x_2469 = heff_dup(v_field_2468); int c_ = 1; heff_drop(v_x_2469); c_; })));
    heff_drop(v_field_2468);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam7(V self, V *args) {
  V v_acc_2483 = args[0];
  V v_k_2484 = args[1];
  V v_shorts_2482 = heff_env(self)[0];
  V v_facts_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2eemit_2einfoOne(v_shorts_2482, v_facts_2478, v_acc_2483, v_k_2484));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam8(V self, V *args) {
  V v_o_2496 = args[0];
  V v_globals_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2497 = ({ V a_0 = v_globals_2489; V b_1 = heff_get_n(v_o_2496, 1, 2); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_globals_2489); heff_drop(b_1); r_; });
  {
    V v_field_2499 = v_t_2497.f[1];
    int64_t v_tag_2498 = ((int64_t)v_t_2497.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2498 == ((int64_t)0ULL)) && ({ V v_x_24100 = heff_dup(v_field_2499); int c_ = 1; heff_drop(v_x_24100); c_; })));
    heff_drop(v_field_2499);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam9(V self, V *args) {
  V v_o_24102 = args[0];
  V v_globals_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_gs_24103 = v_globals_2489;
  V v_o_24104 = v_o_24102;
  V v_name_24105 = heff_take_field(v_o_24104, 0);
  V v_key_24106 = heff_get_n(v_o_24104, 1, 2);
  V v_x_24107 = v_name_24105;
  V v_t_24109;
  if ((heff_strEq_c_lent(v_x_24107, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str15), 2) ? 0 : ({ V v_t_24149 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_x_24107))); int c_ = heff_strEq_c_lent(v_t_24149, v_x_24107, 0); heff_drop(v_t_24149); c_; }))) {
    v_t_24109 = v_x_24107;
  } else {
    V v_t_24108 = (g_heff_2ecompile_2eemit_2equoteGo(v_x_24107, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str16)));
    v_t_24109 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str17), v_t_24108), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str18));
  }
  V v_t_24110 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str19), v_t_24109), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str20));
  HeffT2 v_t_24111 = ({ V a_0 = v_gs_24103; V a_1 = v_key_24106; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_gs_24103); heff_drop(v_key_24106); r_; });
  V v_t_24118;
  {
    V v_field_24113 = v_t_24111.f[1];
    int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
    if ((v_tag_24112 == ((int64_t)0ULL))) {
      V v_i_24114 = v_field_24113;
      V v_arity_24115 = heff_take_field(v_i_24114, 1);
      V v_js_24116 = heff_take_field(v_i_24114, 0);
      V v_lazy_24117 = heff_get_n(v_i_24114, 2, 4);
      if (heff_intLe_c(MK_INT(2LL), v_arity_24115)) {
        heff_drop(v_lazy_24117);
        v_t_24118 = heff_strAppend(v_js_24116, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str21));
      } else {
        if ((heff_dup(v_lazy_24117) == NTAG(TAG_True))) {
          heff_drop(v_lazy_24117);
          v_t_24118 = heff_strAppend(v_js_24116, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str22));
        } else {
          heff_drop(v_lazy_24117);
          v_t_24118 = v_js_24116;
        }
      }
    } else {
      heff_drop(v_field_24113);
      v_t_24118 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str23);
    }
  }
  return heff_strAppend(heff_strAppend(v_t_24110, v_t_24118), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str24));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_cs_2432 = heff_env(self)[0];
  V v_badL_2431 = heff_env(self)[1];
  V v_e_2428 = heff_env(self)[2];
  V v_outPath_2430 = heff_env(self)[3];
  V v_hd_2433 = heff_env(self)[4];
  V v_k_2434 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2435);
  HeffT2 v_t_2436 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2432));
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    if ((v_tag_2437 == ((int64_t)0ULL))) {
      V v_c_2439 = v_field_2438;
      V v_top_2440 = heff_take_field(v_c_2439, 5);
      V v_own_2441 = heff_get_n(v_c_2439, 7, 14);
      V v_t_2442;
      if ((heff_dup(v_badL_2431) == NTAG(TAG_True))) {
        heff_drop(v_cs_2432);
        heff_drop(v_badL_2431);
        v_t_2442 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_2431);
        v_t_2442 = ({ V a_0 = v_cs_2432; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2432); r_; });
      }
      V v_g_2443 = heff_get_n(v_top_2440, 0, 10);
      V v_exports0_2444 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str7); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_2441; V r_ = (g_list_2emap_24f2124896334x71745266(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
      V v_exports_2454;
      switch (heff_tag_of(v_exports0_2444)) {
      case TAG_Nil: {
        V v_t_2451 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam5, 2, 1, (V[]){heff_dup(v_g_2443)}), NTAG(TAG_Nil), heff_rfield(v_g_2443, 0)));
        v_exports_2454 = (g_list_2emap_24s129316455x2072694707(v_t_2451));
        break;
      }
      case TAG_Cons: {
        v_exports_2454 = v_exports0_2444;
        break;
      }
      default: heff_nomatch(v_exports0_2444);
      }
      V v_roots_2455 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_2454)));
      V v_roots_2456 = v_roots_2455;
      HeffT3 v_t_2457 = (g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(v_g_2443));
      V v_l_2473;
      {
        V v_field_2458 = v_t_2457.f[0];
        V v_field_2459 = v_t_2457.f[1];
        V v_field_2460 = v_t_2457.f[2];
        V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2458));
        V v_defs_2462 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2461; V r_ = (g_list_2efoldl_24s650566757x317183241(a_0, a_1, a_2)); heff_drop(v_t_2461); r_; });
        V v_t_2463 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2462));
        V v_reached_2464 = ({ V a_0 = v_t_2463; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_2456); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
        V v_t_2470 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam6, 1, 1, (V[]){v_reached_2464}), v_defs_2462));
        V v_si_2471 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(v_field_2460, v_t_2470));
        V v_t_2472 = (g_heff_2ecompile_2elower_2efusedOf(heff_dup(v_roots_2456), v_si_2471));
        v_l_2473 = (g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587(v_roots_2456, v_field_2459, v_t_2472));
      }
      V v_facts_2474 = heff_take_field(v_l_2473, 1);
      V v_defs_2475 = heff_take_field(v_l_2473, 0);
      V v_errors_2476 = heff_get_n(v_l_2473, 2, 3);
      V v_exports_2477 = heff_dup(v_exports_2454);
      V v_facts_2478 = v_facts_2474;
      V v_defs_2479 = v_defs_2475;
      V v_roots_2480 = (g_list_2emap_24s152505078x225062837(v_exports_2454));
      V v_keys_2481 = (g_list_2emap_24s1835183789x486277886(heff_dup(v_defs_2479)));
      V v_shorts_2482 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str8); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str9); V b_3 = MK_INT(0LL); V a_4 = heff_dup(v_keys_2481); V r_ = (g_list_2emap_24s456574265x331130481(b_0, a_1, b_2, b_3, a_4)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2485 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam7, 2, 2, (V[]){v_shorts_2482, v_facts_2478}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_keys_2481; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_keys_2481); r_; });
      V v_t_2486 = ({ V a_0 = heff_rec_n(1, shape_info, (V[]){v_t_2485}); V a_1 = v_defs_2479; V a_2 = v_roots_2480; V a_3 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemit_2eemitKeptIn(a_0, a_1, a_2, a_3)); heff_drop(v_defs_2479); r_; });
      V v_m_2487 = heff_get_n(v_t_2486, 0, 2);
      V v_lines_2488 = heff_take_field(v_m_2487, 0);
      V v_globals_2489 = heff_get_n(v_m_2487, 1, 2);
      V v_t_2490 = (g_list_2eany_24s331724893x1262243254(v_lines_2488));
      V v_t_2491;
      if ((heff_dup(v_t_2490) == NTAG(TAG_True))) {
        heff_drop(v_t_2490);
        v_t_2491 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2490);
        v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
      }
      V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str10), NTAG(TAG_Nil)});
      V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eextStr_get()), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str11), v_t_2492})});
      V v_t_2494 = (g_prelude_2e_2b_2b(v_t_2491, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str12), v_t_2493})));
      V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str13), NTAG(TAG_Nil)});
      V v_t_24101 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam8, 1, 1, (V[]){heff_dup(v_globals_2489)}), v_exports_2477));
      V v_t_24119 = (g_prelude_2e_2b_2b_24f58476578x2140998212(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str14), v_t_2495}), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam9, 1, 1, (V[]){v_globals_2489}), v_t_24101));
      V v_t_24120 = (g_prelude_2e_2b_2b(v_t_2494, v_t_24119));
      V v_t_24121 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str25); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str26); V a_2 = v_lines_2488; V a_3 = v_t_24120; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_lines_2488); heff_drop(v_t_24120); r_; });
      return ({ V a_0 = v_e_2428; V a_1 = v_outPath_2430; V a_2 = v_t_2442; V a_3 = heff_rec_n(2, shape_source__errors, (V[]){v_t_24121, v_errors_2476}); V a_4 = v_hd_2433; V a_5 = v_k_2434; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2442); r_; });
    } else {
      heff_drop(v_cs_2432);
      heff_drop(v_badL_2431);
      heff_drop(v_outPath_2430);
      heff_drop(v_field_2438);
      V v_t_24122 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
      V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
      V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
      V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
      V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
      V v_t_24128 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})});
      return (g_co_2eop_24s310169282x2049378029(v_e_2428, heff_tag_n(TAG_InR, 1, (V[]){v_t_24128}), v_hd_2433, v_k_2434));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_e_2419 = heff_env(self)[0];
  V v_file_2420 = heff_env(self)[1];
  V v_outPath_2421 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_hd_2422 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_e_2428 = v_e_2419;
  V v_file_2429 = v_file_2420;
  heff_drop(v_file_2429);
  V v_outPath_2430 = v_outPath_2421;
  V v_badL_2431 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2425, 1));
  heff_drop(v_x_2425);
  V v_cs_2432 = heff_get_n(v_x_2427, 0, 2);
  V v_hd_2433 = v_hd_2422;
  V v_k_2434 = v_k_2423;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_2428), heff_dup(v_cs_2432), heff_dup(v_hd_2433), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam4, 1, 6, (V[]){v_cs_2432, v_badL_2431, v_e_2428, v_outPath_2430, v_hd_2433, v_k_2434})));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_e_2419 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_hd_2422 = heff_env(self)[2];
  V v_file_2420 = heff_env(self)[3];
  V v_outPath_2421 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2426 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_2419), v_x_2424));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2422);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam3, 1, 6, (V[]){v_e_2419, v_file_2420, v_outPath_2421, v_x_2425, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_e_2419 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_file_2420 = heff_env(self)[2];
  V v_outPath_2421 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_2419), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str6), heff_dup(heff_rfield(v_x_2424, 1)), MK_INT(0LL), heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam2, 1, 6, (V[]){v_e_2419, v_x_2424, v_hd_2422, v_file_2420, v_outPath_2421, v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam10(V self, V *args) {
  V v_x_24141 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24141);
  V v_t_24142 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24142})});
  V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
  V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
  V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
  V v_t_24148 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24147})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24148}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_o_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_244)) {
  case TAG_Nothing: {
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str0))) {
      V v_outPath_245 = heff_take_field(v_o_241, 1);
      V v_file_246 = heff_take_field(v_o_241, 0);
      V v_t_247 = heff_get_n(v_o_241, 2, 4);
      V v_t_249;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str1);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str2), heff_dup(v_outPath_245)), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str3));
      V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str4)), NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
      return ({ V a_0 = v_e_240; V b_1 = heff_tag_n(TAG_Just, 1, (V[]){v_t_249}); V a_2 = v_outPath_245; V a_3 = v_file_246; V a_4 = v_t_2418; V a_5 = v_hd_242; V a_6 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str5))) {
        V v_e_2419 = v_e_240;
        V v_file_2420 = heff_take_field(v_o_241, 0);
        V v_outPath_2421 = heff_get_n(v_o_241, 1, 4);
        V v_hd_2422 = v_hd_242;
        V v_k_2423 = v_k_243;
        return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_2419), heff_dup(v_file_2420), heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam1, 1, 5, (V[]){v_e_2419, v_hd_2422, v_file_2420, v_outPath_2421, v_k_2423})));
      } else {
        V v_t_24129 = heff_take_field(v_o_241, 2);
        V v_t_24131;
        switch (heff_tag_of(v_t_24129)) {
        case TAG_Nothing: {
          v_t_24131 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str27);
          break;
        }
        case TAG_Just: {
          V v_x_24130 = heff_field(v_t_24129, 0);
          heff_take_n(v_t_24129, 1ULL, 1);
          v_t_24131 = v_x_24130;
          break;
        }
        default: heff_nomatch(v_t_24129);
        }
        return (g_heff_2ebuild_2ecommands_2ecCmd_24s1829956924x1619472568(v_e_240, heff_tag_n(TAG_Just, 1, (V[]){v_t_24131}), heff_dup(heff_rfield(v_o_241, 1)), heff_get_n(v_o_241, 0, 4), v_hd_242, v_k_243));
      }
    }
  }
  case TAG_Just: {
    V v_dir_24132 = heff_field(v_x_244, 0);
    V v_ru_24x_244_24Just = heff_take_reuse_n(v_x_244, 1ULL, 1);
    heff_drop_rec(v_o_241, 4);
    V v_t_24133 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str28), v_dir_24132), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str29));
    V v_t_24134 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24133, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_str30)), NTAG(TAG_MkUnit)});
    V v_t_24135 = heff_tag_at_n(v_ru_24x_244_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
    V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
    V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24140}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_lam10, 1, 3, (V[]){v_e_240, v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_244);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_str1, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962(V v_e_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_pl_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_245, 0);
    V v_rest_247 = heff_field(v_x5_245, 1);
    V v_name_248 = heff_dup(heff_rfield(v_a_246, 0));
    V v_build_249 = heff_dup(heff_rfield(v_a_246, 1));
    V v_t_2410 = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_pl_243), v_next_244, v_rest_247));
    V v_t_2412;
    if (heff_strEq_c(heff_get_n(v_build_249, 0, 3), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_str0))) {
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_name_248)});
    } else {
      V v_t_2411 = heff_dup(heff_rfield(v_t_242, 3));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(heff_dup(v_name_248), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_str1))});
      } else {
        heff_drop(v_t_2411);
        v_t_2412 = NTAG(TAG_Nothing);
      }
    }
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1218651407x1410291522_clo), 7, (V[]){v_e_240, v_st_241, v_t_242, v_pl_243, v_t_2410, v_name_248, v_t_2412});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079(V v_e_240, V v_st_241, V v_t_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_progs_243);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam0_clo);
  }
  case TAG_Just: {
    V v_home_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_total_2410 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_249));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_str0), heff_dup(v_home_247));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam1, 2, 7, (V[]){v_t_2411, v_total_2410, v_e_240, v_progs_243, v_st_241, v_t_242, v_home_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  heff_drop(v_a_245);
  V f_ = v_a_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2425);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_2421, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam5, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_247 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2419));
  V v_t_2426 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_247; V a_4 = heff_dup(v_x_2417); V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam4, 2, 2, (V[]){v_x_2417, v_e_240}); V a_6 = v_t_2420; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2420); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_total_2410 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_home_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2411, v_total_2410, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2416, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079_lam3, 1, 7, (V[]){v_progs_243, v_e_240, v_st_241, v_t_242, v_home_247, v_hd_2412, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245(V v_e_240, V v_st_241, V v_t_242, V v_progs_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_str0)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_str1)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_p_249 = ({ V a_0 = v_st_241; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_p_249));
  V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
  V v_s_2413 = ({ V a_0 = v_st_241; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2413));
  V v_c_2415 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2414; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2414); r_; });
  V v_t_2416 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2420 = heff_tr(heff_call(v_c_2415, 2, (V[]){v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam0_clo)}));
  return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam1, 1, 6, (V[]){v_progs_243, v_e_240, v_z_244, v_st_241, v_t_242, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam2(V self, V *args) {
  V v_t_2423 = args[0];
  return v_t_2423;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_next_2428 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2433);
  V f_ = v_next_2428;
  heff_room[0] = v_hd_2429;
  heff_room[1] = v_k_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_x_2426 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431 = heff_tag_n(TAG_End, 2, (V[]){v_x_2426, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(v_hd_2429), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam5, 1, 3, (V[]){v_next_2428, v_hd_2429, v_k_2430})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1312155541x1362894079(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_progs_243), heff_dup(heff_rfield(v_t_242, 4))));
  V v_next_2428 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), v_t_2427, v_progs_243));
  V v_t_2434 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = heff_dup(v_x_2426); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam4, 2, 3, (V[]){v_x_2426, v_e_240, v_next_2428}); V a_5 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s1911015366x1072844102(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2434;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2421);
  V v_total_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_str2), v_total_2422, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam2_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2425, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245_lam3, 1, 6, (V[]){v_e_240, v_st_241, v_t_242, v_progs_243, v_z_244, v_z_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str9, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str11, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str12, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str20, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str21, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str22, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187(V v_e_240, V v_st_241, V v_cmd_242, V v_t_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_243, 0))));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str0)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_241; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(heff_dup(v_e_240), v_t_2410, NTAG(TAG_Nil)));
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam0, 1, 6, (V[]){v_e_240, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam8(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_x_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2466);
  V f_ = v_k_2467;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2465});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam7(V self, V *args) {
  V v_x_2464 = args[0];
  V v_x_2465 = (g_list_2emap_24s219049803x1458391381(v_x_2464));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam8, 2, 1, (V[]){v_x_2465});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam10(V self, V *args) {
  V v_t_2476 = args[0];
  return v_t_2476;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam14(V self, V *args) {
  V v_x_24102 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24102);
  V v_t_24103 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24109}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam13(V self, V *args) {
  V v_x_2489 = args[0];
  V v_bad_2485 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_apps_2486 = heff_env(self)[5];
  V v_st_241 = heff_env(self)[6];
  V v_t_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2489);
  if (heff_intLt_c_lent(MK_INT(0LL), v_bad_2485, 1)) {
    heff_drop(v_apps_2486);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    V v_n_2490 = v_bad_2485;
    V v_t_2491;
    if (heff_intEq_c_lent(v_n_2490, MK_INT(1LL), 2)) {
      heff_drop(v_n_2490);
      v_t_2491 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str17);
    } else {
      v_t_2491 = heff_strAppend(heff_intShow(v_n_2490), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str18));
    }
    V v_what_2492 = heff_strAppend(v_t_2491, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str19));
    V v_t_2493 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str20), v_cmd_242), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str21));
    V v_t_2494 = heff_strAppend(heff_strAppend(v_t_2493, v_what_2492), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str22));
    V v_t_2495 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2494, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str23)), NTAG(TAG_MkUnit)});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam14, 1, 3, (V[]){v_e_240, v_z_244, v_z_245})));
  } else {
    heff_drop(v_bad_2485);
    heff_drop(v_cmd_242);
    switch (heff_tag_of(v_apps_2486)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_z_244);
      heff_drop(v_st_241);
      heff_drop_rec(v_t_243, 6);
      V f_ = v_z_245;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s745467952x29766245(v_e_240, v_st_241, v_t_243, v_apps_2486, v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_apps_2486);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam12(V self, V *args) {
  V v_x_2484 = args[0];
  V v_x_2479 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_bad_2485 = heff_take_field(v_x_2484, 1);
  V v_apps_2486 = heff_get_n(v_x_2484, 0, 2);
  V v_t_2487 = heff_tag_n(TAG_End, 2, (V[]){v_x_2479, NTAG(TAG_MkUnit)});
  V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2488}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam13, 1, 8, (V[]){v_bad_2485, v_cmd_242, v_e_240, v_z_244, v_z_245, v_apps_2486, v_st_241, v_t_243})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam11(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_2472 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_cmd_242 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2480 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2482;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_Nothing: {
    v_t_2482 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2481 = heff_field(v_x_2472, 0);
    heff_take_n(v_x_2472, 1ULL, 1);
    v_t_2482 = v_x_2481;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_c_2483 = (g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_243), heff_dup(v_x_2479), v_t_2480, v_t_2482));
  V f_ = v_c_2483;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam12, 1, 7, (V[]){v_x_2479, v_e_240, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam9(V self, V *args) {
  V v_x_2469 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2472;
  switch (heff_tag_of(v_x_2469)) {
  case TAG_Left: {
    heff_take_n(v_x_2469, 0ULL, 1);
    v_x_2472 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2471 = heff_field(v_x_2469, 0);
    V v_ru_24x_2469_24Right = heff_take_reuse_n(v_x_2469, 1ULL, 1);
    v_x_2472 = heff_tag_at_n(v_ru_24x_2469_24Right, TAG_Just, 1, (V[]){v_y_2471});
    break;
  }
  default: heff_nomatch(v_x_2469);
  }
  V v_t_2474;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_Nothing: {
    v_t_2474 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2474 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_total_2475 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2474; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2474); r_; });
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str16), v_total_2475, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam10_clo)})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2478, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam11, 1, 7, (V[]){v_x_2472, v_e_240, v_st_241, v_t_243, v_z_244, v_cmd_242, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2456);
  V v_t_2457 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_243, 0))));
  V v_t_2458 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str15)));
  V v_t_2459 = (g_std_2epath_2ejoin(v_t_2457, v_t_2458));
  V v_s_2460 = ({ V a_0 = v_st_241; V a_1 = v_t_2459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2459); r_; });
  V v_path_2461 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2460));
  V v_c_2462 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2461));
  V v_t_2463 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2468 = heff_tr(heff_call(v_c_2462, 2, (V[]){v_t_2463, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam7_clo)}));
  V f_ = v_c_2468;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam9, 1, 6, (V[]){v_e_240, v_z_244, v_st_241, v_t_243, v_cmd_242, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_errors_2420 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_seen_2421 = heff_env(self)[5];
  V v_st_241 = heff_env(self)[6];
  V v_t_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2424);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2420, 1)) {
    heff_drop(v_seen_2421);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    V v_n_2425 = v_errors_2420;
    V v_t_2426;
    if (heff_intEq_c_lent(v_n_2425, MK_INT(1LL), 2)) {
      heff_drop(v_n_2425);
      v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str2);
    } else {
      v_t_2426 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str3));
    }
    V v_what_2427 = heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str4));
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str5), v_cmd_242), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str6));
    V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_what_2427), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str7));
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str8)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam5, 1, 3, (V[]){v_e_240, v_z_244, v_z_245})));
  } else {
    heff_drop(v_errors_2420);
    V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str9), heff_dup(v_cmd_242)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str10));
    V v_n_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2421; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2421); r_; });
    V v_t_2447;
    if (heff_intEq_c_lent(v_n_2446, MK_INT(1LL), 2)) {
      heff_drop(v_n_2446);
      v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str11);
    } else {
      v_t_2447 = heff_strAppend(heff_intShow(v_n_2446), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str12));
    }
    V v_str_2448 = heff_strAppend(heff_strAppend(v_t_2445, v_t_2447), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str13));
    V v_t_2449 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2448, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str14)), NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam6, 1, 6, (V[]){v_st_241, v_t_243, v_e_240, v_z_244, v_cmd_242, v_z_245})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_errors_2420 = heff_take_field(v_x_2419, 1);
  V v_seen_2421 = heff_get_n(v_x_2419, 0, 2);
  V v_t_2422 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam4, 1, 8, (V[]){v_errors_2420, v_cmd_242, v_e_240, v_z_244, v_z_245, v_seen_2421, v_st_241, v_t_243})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_x_2417); V a_2 = v_t_2418; V a_3 = v_x_2412; V a_4 = heff_dup(v_z_244); V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam3, 1, 7, (V[]){v_x_2417, v_e_240, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243}); V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2412); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_cmd_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_total_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2412));
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_str1), v_total_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam1_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2416, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187_lam2, 1, 7, (V[]){v_e_240, v_x_2412, v_z_244, v_cmd_242, v_z_245, v_st_241, v_t_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str1, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str4, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508(V v_e_240) {
top: ;
  V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str0)));
  V v_c_242 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_241; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_241); r_; });
  V v_t_243 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_247 = heff_tr(heff_call(v_c_242, 2, (V[]){v_t_243, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam1, 2, 2, (V[]){v_c_247, v_e_240});
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508(a[0]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_245 = args[1];
  V v_k_246 = args[2];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_248, v_k_249));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str1), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam5, 1, 3, (V[]){v_e_240, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam6(V self, V *args) {
  V v_s_2437 = args[0];
  return v_s_2437;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_2446;
  if (heff_strEq_c(v_x_2445, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str2))) {
    v_st_2446 = NTAG(TAG_Windows);
  } else {
    v_st_2446 = NTAG(TAG_Posix);
  }
  V v_t_2447 = (g_heff_2ebuild_2ecommands_2ebuildTarget(heff_dup(v_st_2446), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str3)));
  return (g_heff_2ebuild_2ecommands_2ebuildProject_24s866448812x1193500187(v_e_240, v_st_2446, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_str4), v_t_2447, v_hd_248, v_k_249));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 0ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam3_clo)})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2419, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam4, 1, 3, (V[]){v_e_240, v_hd_248, v_k_249})));
  }
  case TAG_Right: {
    V v_ru_24x_2410_24Right = heff_take_reuse_n(v_x_2410, 0ULL, 1);
    V v_t_2438 = heff_tag_at_n(v_ru_24x_2410_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam6_clo)})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2444, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam7, 1, 3, (V[]){v_e_240, v_hd_248, v_k_249})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_lam2, 1, 3, (V[]){v_e_240, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}