// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_Holds 53574
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Settled 45257
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_diff 9578700
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_files 298792593
#define LBL_goldens 436112074
#define LBL_got 312070
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_line 9817275
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_watch 314261737
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
V g_co_2eop_24s161437114x968393689(V, V, V, V, V, V, V, V);
V g_co_2eop_24s161437114x968393689_entry(V self, V *a);
extern Clo g_co_2eop_24s161437114x968393689_clo;
V g_co_2eop_24s901899803x1656620254(V, V, V, V, V, V, V, V);
V g_co_2eop_24s901899803x1656620254_entry(V self, V *a);
extern Clo g_co_2eop_24s901899803x1656620254_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012(V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_clo;
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_clo;
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872(V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_clo;
V g_heff_2ebuild_2ecommands_2etestsHeld(V, V, V);
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1875062608x222844981(V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_clo;
HeffT2 g_list_2efind_24s1250280863x1570195177_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0, 0, "");
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V v_sources_240, V v_only_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    heff_drop(v_seen_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_244)));
    V v_m_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_m_249 = ((V)&g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_m_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = (g_list_2eany_24s2065989517x1307020881(v_m_249, v_seen_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_m_249);
      heff_drop(v_t_2410);
      V t_0 = v_sources_240;
      V t_1 = v_only_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_sources_240 = t_0;
      v_only_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2eany_24s2065989517x1307020881(v_m_249, v_only_241));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_sources_240);
        heff_drop(v_seen_242);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_m_249);
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_path_244}});
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_list_2efind_24s1250280863x1570195177_24cpr(v_m_249, heff_dup(v_sources_240)));
        V v_t_2421;
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_x_2416, 5), heff_take_field(v_x_2416, 3)));
            V v_t_2418 = ({ V b_0 = heff_get_n(v_x_2416, 4, 7); V a_1 = v_t_2417; V r_ = (g_heff_2esyntax_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
            V v_imps_2419 = heff_get_n(v_t_2418, 0, 4);
            V v_t_2420 = (g_list_2emap_24s1817208647x1282894070(v_imps_2419));
            v_t_2421 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2420));
          } else {
            heff_drop(v_field_2414);
            v_t_2421 = NTAG(TAG_Nil);
          }
        }
        V v_t_2424 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0, 1, 1, (V[]){v_path_244}), v_t_2421));
        V t_0 = v_sources_240;
        V t_1 = v_only_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_m_249, v_seen_242});
        V t_3 = v_t_2424;
        v_sources_240 = t_0;
        v_only_241 = t_1;
        v_seen_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args) {
  V v_i_2422 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_2422, NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_path_244, v_t_2423));
}

static V g_heff_2ebuild_2ecommands_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectedRes_st;
static V g_heff_2ebuild_2ecommands_2eexpectedRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectedRes_st)) return g_heff_2ebuild_2ecommands_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectedRes_val, &g_heff_2ebuild_2ecommands_2eexpectedRes_st, g_heff_2ebuild_2ecommands_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str2, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str3, 12, "\012  diff     ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str4, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str5, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str8, 5, "FAIL ");
Clo g_heff_2ebuild_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_intShow(heff_take_field(v_r_241, 1));
  V v_t_244 = heff_take_field(v_r_241, 0);
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str1), heff_strAppend(v_n_245, ((V)&g_heff_2ebuild_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_247 = heff_get_n(heff_get_n(v_r_241, 2, 3), 2, 10);
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str3), heff_take_field(v_m_242, 2));
  V v_t_249 = heff_strAppend(heff_take_field(v_m_242, 1), v_t_248);
  V v_t_2410 = heff_strAppend(heff_get_n(v_m_242, 0, 3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str4), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str5), v_t_2410));
  V v_t_2412 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str6), v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str7), heff_strAppend(v_t_243, v_t_2412));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str8), heff_strAppend(v_f_240, v_t_2413));
}
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efailLine(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationMainName_str0, 20, "heffTestIntegrations");

static V g_heff_2ebuild_2ecommands_2eintegrationMainName_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eintegrationMainName_st;
static V g_heff_2ebuild_2ecommands_2eintegrationMainName_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eintegrationMainName_str0);
}
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eintegrationMainName_st)) return g_heff_2ebuild_2ecommands_2eintegrationMainName_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eintegrationMainName_val, &g_heff_2ebuild_2ecommands_2eintegrationMainName_st, g_heff_2ebuild_2ecommands_2eintegrationMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str2, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str4, 11, " tests hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsHeld_str6, 2, ", ");
Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsHeld_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etestsHeld(V v_tests_240, V v_failed_241, V v_skipped_242) {
top: ;
  if (heff_intEq_c_lent(v_tests_240, MK_INT(0LL), 2)) {
    heff_drop(v_tests_240);
    heff_drop(v_failed_241);
    heff_drop(v_skipped_242);
    return ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str0);
  } else {
    V v_t_244 = heff_intSub(heff_intSub(heff_dup(v_tests_240), v_failed_241), heff_dup(v_skipped_242));
    V v_t_247;
    if (heff_intEq_c_lent(v_skipped_242, MK_INT(0LL), 2)) {
      heff_drop(v_skipped_242);
      v_t_247 = ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str1);
    } else {
      V v_t_246 = heff_strAppend(heff_intShow(v_skipped_242), ((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str2));
      v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str3), v_t_246);
    }
    V v_t_248 = heff_strAppend(heff_intShow(v_tests_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str4), v_t_247));
    V v_t_249 = heff_strAppend(heff_intShow(v_t_244), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str5), v_t_248));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsHeld_str6), v_t_249);
  }
}
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestsHeld(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_str0), v_l_245));
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s901899803x1656620254(v_m_240, v_rest_246, v_n_242, MK_INT(1LL), heff_dup(v_p_243), v_p_244, heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_p_243));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str2, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str3, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str5, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451(V v_name_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam0, 1, 3, (V[]){v_hd_241, v_name_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam1(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam3(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2439);
  V f_ = v_k_242;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str5);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam6, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    V v_t_2423 = (g_std_2epath_2ejoin(v_st_2413, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str2)));
    V v_t_2424 = ({ V a_0 = v_st_2413; V a_1 = v_t_2423; V a_2 = v_name_240; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2413); r_; });
    V v_str_2425 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str3), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2425, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str4)), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_t_2440 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    heff_drop(v_st_2413);
    heff_drop(v_x_243);
    heff_drop(v_name_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = v_t_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str0))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  V v_t_2414 = (g_std_2epath_2ejoin(v_st_2413, heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_str1)));
  V v_path_2415 = (g_std_2epath_2ejoin(v_st_2413, v_t_2414, heff_dup(v_name_240)));
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2415, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam4, 1, 5, (V[]){v_st_2413, v_x_243, v_name_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s94900133x232571340(v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s97317757x1540439451_lam2, 1, 4, (V[]){v_x_243, v_name_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_249, v_x_2415));
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_rt_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2415; V a_9 = v_t_2416; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s816500649x2146495695(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s810431517x2056352750_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str0, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str2, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str3, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str4, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str5, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str6, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str7, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str8, 8, "heff run");
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872(V v_prog_240, V v_file_241, V v_progArgs_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam0, 2, 4, (V[]){v_c_243, v_prog_240, v_file_241, v_progArgs_242});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam2(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam4(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_cmd_2425 = heff_env(self)[0];
  V v_progArgs_242 = heff_env(self)[1];
  V v_hd_2435 = heff_env(self)[2];
  V v_k_2436 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exec, 3, (V[]){v_cmd_2425, v_progArgs_242, NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_hd_2435, v_k_2436));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_cmd_2425 = heff_env(self)[1];
  V v_progArgs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s94900133x232571340(v_t_2427, heff_dup(v_hd_2435), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam9, 1, 4, (V[]){v_cmd_2425, v_progArgs_242, v_hd_2435, v_k_2436})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_dir_2415 = heff_env(self)[3];
  V v_out_2420 = heff_env(self)[4];
  V v_t_2427 = heff_env(self)[5];
  V v_cmd_2425 = heff_env(self)[6];
  V v_progArgs_242 = heff_env(self)[7];
  V v_hd_2430 = heff_env(self)[8];
  V v_k_2431 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_get_n(heff_get_n(v_x_246, 2, 5), 5, 6);
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str7), NTAG(TAG_Nil)});
  return ({ V a_0 = MK_INT(1LL); V a_1 = v_prog_240; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str8); V a_3 = v_t_2433; V a_4 = v_t_2434; V a_5 = v_x_249; V a_6 = v_dir_2415; V a_7 = v_out_2420; V a_8 = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam8, 2, 3, (V[]){v_t_2427, v_cmd_2425, v_progArgs_242}); V a_9 = v_hd_2430; V a_10 = v_k_2431; V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_t_2433); r_; });
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam6(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_t_2429 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_dir_2415 = heff_env(self)[4];
  V v_out_2420 = heff_env(self)[5];
  V v_t_2427 = heff_env(self)[6];
  V v_cmd_2425 = heff_env(self)[7];
  V v_progArgs_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_co_2eop_24s94900133x232571340(v_t_2429, heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam7, 1, 10, (V[]){v_x_246, v_prog_240, v_x_249, v_dir_2415, v_out_2420, v_t_2427, v_cmd_2425, v_progArgs_242, v_hd_2430, v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_progArgs_242 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_246, 2)), heff_dup(v_file_241)));
  V v_outPath_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str1));
  V v_dir_2415 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_246, 2)), heff_dup(v_file_241)));
  V v_paths_2416 = heff_dup(heff_rfield(v_x_246, 2));
  V v_d_2417 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2416), heff_dup(v_file_241)));
  V v_t_2418 = heff_dup(heff_rfield(v_paths_2416, 5));
  V v_t_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Posix: {
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str2);
    break;
  }
  case TAG_Windows: {
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str3);
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_out_2420 = ({ V b_0 = heff_get_n(v_paths_2416, 5, 6); V a_1 = v_d_2417; V a_2 = v_t_2419; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_paths_2421 = heff_dup(heff_rfield(v_x_246, 2));
  V v_d_2422 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2421), heff_dup(v_file_241)));
  V v_t_2423 = heff_dup(heff_rfield(v_paths_2421, 5));
  V v_t_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Posix: {
    v_t_2424 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str4);
    break;
  }
  case TAG_Windows: {
    v_t_2424 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str5);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_cmd_2425 = ({ V b_0 = heff_get_n(v_paths_2421, 5, 6); V a_1 = v_d_2422; V a_2 = v_t_2424; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2426 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_249), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2426}));
  V v_t_2428 = heff_tag_n(TAG_End, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2428}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(MK_INT(1LL), heff_dup(v_x_246), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str6)}), v_outPath_2414, v_file_241, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam6, 2, 9, (V[]){v_t_2429, v_x_246, v_prog_240, v_x_249, v_dir_2415, v_out_2420, v_t_2427, v_cmd_2425, v_progArgs_242}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_progArgs_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam4_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2411, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam5, 1, 7, (V[]){v_x_246, v_file_241, v_x_249, v_prog_240, v_progArgs_242, v_hd_244, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_progArgs_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_dup(v_file_241), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_248, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam3, 1, 6, (V[]){v_prog_240, v_hd_244, v_x_246, v_file_241, v_progArgs_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_progArgs_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s69622896x1766838872_lam1, 1, 5, (V[]){v_prog_240, v_file_241, v_hd_244, v_progArgs_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_str0, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(V v_update_240, V v_f_241, V v_o_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam0, 2, 1, (V[]){v_o_242});
  }
  case TAG_Cons: {
    V v_g_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = (g_heff_2ebuild_2ecommands_2egoldenSaid_24s178321910x756634869(v_update_240, heff_dup(v_f_241), v_g_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam1, 2, 5, (V[]){v_c_248, heff_dup(v_update_240), v_f_241, v_o_242, v_rest_247});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_o_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Holds: {
    V v_t_2412 = ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_o_242; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(a_0, a_1, a_2, a_3)); heff_drop(v_update_240); r_; });
    V f_ = v_t_2412;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrote: {
    V v_path_2413 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Wrote = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_str0), v_path_2413), ((V)&g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_str1));
    V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2411_24Wrote, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_o_242; V a_3 = v_rest_247; V a_4 = heff_dup(v_hd_249); V a_5 = v_k_2410; V a_6 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}); V a_7 = v_hd_249; V r_ = (g_co_2eop_24s161437114x968393689(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_update_240); r_; });
  }
  case TAG_Wrong: {
    V v_note_2421 = heff_field(v_x_2411, 0);
    V v_why_2422 = heff_field(v_x_2411, 1);
    V v_ru_24x_2411_24Wrong = heff_take_reuse_n(v_x_2411, 3ULL, 2);
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    heff_drop(v_rest_247);
    heff_drop(v_hd_249);
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2411_24Wrong, TAG_Cons, 2, (V[]){v_note_2421, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(heff_take_field(v_o_242, 8), v_t_2423));
    V v_x_2425 = ({ V rv_1 = NTAG(TAG_False); V rv_2 = NTAG(TAG_Nothing); V rv_8 = v_t_2424; V rv_9 = heff_tag_n(TAG_Just, 1, (V[]){v_why_2422}); V rr_ = heff_rec_reuse_nf(v_o_242, 3321ULL, 12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, 15794115u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    V f_ = v_k_2410;
    args[0] = v_x_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_o_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_lam2, 1, 6, (V[]){v_update_240, v_f_241, v_o_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_str1, 4, "heff");
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430(V v_opts_240, V v_f_241, V v_x3_242, V v_l_243, V v_z_244, V v_z_245) {
top: ;
  if ((heff_dup(v_x3_242) == NTAG(TAG_True))) {
    if (heff_strEq_c(heff_get_n(v_opts_240, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_str0))) {
      V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_l_243)));
      return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam0, 1, 4, (V[]){v_l_243, v_f_241, v_z_244, v_z_245})});
    } else {
      heff_drop(v_f_241);
      heff_drop_rec(v_l_243, 5);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())})});
    }
  } else {
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_str1), heff_dup(heff_rfield(v_l_243, 1)), MK_INT(0LL), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam2, 1, 5, (V[]){v_l_243, v_z_244, v_opts_240, v_f_241, v_z_245})));
  }
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = heff_tag_n(TAG_Settled, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_get_n(v_l_243, 1, 5);
  V v_t_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    v_t_2412 = ({ V b_0 = heff_get_n(v_x_248, 0, 2); V r_ = (g_list_2eany_24s469495312x865582084(b_0)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_249, 0ULL, 2);
    heff_drop_rec(v_x_248, 2);
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  return ({ V a_0 = v_f_241; V a_1 = v_t_2412; V a_2 = v_z_244; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam1, 1, 1, (V[]){v_z_245}); V r_ = (g_heff_2ebuild_2ecommands_2etestExpecting_24s946594088x661322119(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_l_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260(v_opts_240, v_f_241, v_l_243, heff_get_n(v_x_2416, 0, 2), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_c_2415 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_l_243)));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_lam3, 1, 5, (V[]){v_opts_240, v_f_241, v_l_243, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(heff_rfield(v_c_245, 7))));
  V v_t_2417 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2416));
  V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2418));
  V v_t_2421 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam1, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_2419));
  HeffT2 v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop(v_done_244);
      heff_drop_rec(v_c_245, 14);
      heff_drop(v_available_246);
      V v_why_2426 = v_field_2424;
      V v_t_2427 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_str0), v_why_2426));
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_str1), v_t_2427), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_str2));
      V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
    } else {
      heff_drop(v_file_241);
      V v_r_2442 = v_field_2424;
      return (g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965(v_bi_240, v_outPath_243, v_done_244, v_c_245, v_available_246, v_r_2442, v_z_247, v_z_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam0(V self, V *args) {
  V v_o_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_245, heff_rfield(v_o_249, 1)));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_eff_2414 = v_field_2412;
      V v_t_2415 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_249, 0), heff_get_n(v_o_249, 1, 2), v_eff_2414});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop_rec(v_o_249, 2);
      heff_drop(v_field_2412);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam1(V self, V *args) {
  V v_k_2420 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2420; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528_lam2(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str7, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2411;
      V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam0, 1, 1, (V[]){heff_dup(v_c_2413)}), heff_dup(heff_rfield(v_c_2413, 7))));
      V v_t_2422 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2421));
      V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2422); r_; });
      V v_t_2424 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2423));
      V v_xs_2425 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str3); V a_6 = v_t_2424; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2426 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2425));
      V v_c_2427 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816(v_sources_241, v_t_2426));
      return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam1, 1, 8, (V[]){v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245, v_c_2413, v_z_247, v_z_248})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_field_2411);
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str7), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam0(V self, V *args) {
  V v_o_2414 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2413, heff_rfield(v_o_2414, 1)));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_eff_2419 = v_field_2417;
      V v_t_2420 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2414, 0), heff_get_n(v_o_2414, 1, 2), v_eff_2419});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
    } else {
      heff_drop_rec(v_o_2414, 2);
      heff_drop(v_field_2417);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2413 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str4); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str5); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_str6); V a_5 = v_x_2428; V r_ = (g_list_2efilter_24s1875062608x222844981(b_0, a_1, b_2, b_3, b_4, a_5)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2413; V a_6 = v_t_2429; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s1694849184x201828528(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_lam2(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012(V v_file_240, V v_outPath_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_outPath_241});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_file_240; V a_1 = v_outPath_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_246); V a_3 = heff_get_n(v_x_248, 0, 2); V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(v_file_240); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam3, 1, 5, (V[]){v_file_240, v_outPath_241, v_x_246, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_file_240, v_outPath_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_lam1, 1, 4, (V[]){v_hd_243, v_file_240, v_outPath_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str0, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_243, heff_dup(v_src_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_src_242);
      V v_why_2410 = v_field_248;
      V v_t_2411 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str0), v_why_2410));
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str1), v_t_2411), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str2));
      V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam0, 1, 1, (V[]){v_z_245})));
    } else {
      V v_out_2420 = v_field_248;
      if (heff_strEq_c_lent(v_out_2420, v_src_242, 2)) {
        heff_drop(v_f_241);
        heff_drop(v_z_244);
        heff_drop(v_out_2420);
        return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
      } else {
        if ((heff_dup(v_checkOnly_240) == NTAG(TAG_True))) {
          heff_drop(v_out_2420);
          V v_t_2422 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_str3)), NTAG(TAG_MkUnit)});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
          V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
          return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam1, 1, 1, (V[]){v_z_245})));
        } else {
          V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2420, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam2_clo)})});
          V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
          V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
          V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
          V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
          return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam3, 1, 1, (V[]){v_z_245})));
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2419);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2428);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam2(V self, V *args) {
  V v_ok_2429 = args[0];
  return v_ok_2429;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1105284514x998237223_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2435);
  V f_ = v_z_245;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(V v_prog_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_x6_246) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_home_243);
    heff_drop(v_sh_244);
    return v_next_245;
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x6_246, 0);
    V v_rest_248 = heff_field(v_x6_246, 1);
    V v_t_249 = (g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), heff_dup(v_home_243), heff_dup(v_sh_244), v_next_245, v_rest_248));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eshipOne_24s2118525458x1755181515(v_prog_240, v_st_241, v_t_242, v_home_243, v_sh_244, v_t_249, heff_dup(v_n_247));
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(a[0], a1, a[2], a[3], a[4], a[5], a6); heff_drop(a1); heff_drop(a6); return r;
}