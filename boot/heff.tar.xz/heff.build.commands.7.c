// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_aliases 1464806715
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_done 9584713
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_opt 319789
#define LBL_pages 307784670
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_seen 10021698
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_syntax 1059664654
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_tySyntax 1405311289
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1686961086x581293358(V, V, V, V, V, V);
V g_co_2eop_24s1686961086x581293358_entry(V self, V *a);
extern Clo g_co_2eop_24s1686961086x581293358_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s321980040x1154251472(V, V, V, V, V);
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a);
extern Clo g_co_2eop_24s321980040x1154251472_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_get(void);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938(V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(V);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979(V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462(V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunProgram(V, V);
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunProgram_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s1127556009x863725781(V, V, V, V, V, V);
V g_list_2emap_24s1127556009x863725781_entry(V self, V *a);
extern Clo g_list_2emap_24s1127556009x863725781_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_text_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_text_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(heff_dup(v_text_241), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0, 0, "");
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V v_sources_240, V v_only_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_seen_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_244)));
    V v_m_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_m_249 = ((V)&g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_m_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_seen_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_m_249);
      heff_drop(v_t_2410);
      V t_0 = v_sources_240;
      V t_1 = v_only_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_sources_240 = t_0;
      v_only_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2eany_24s1477604419x1568736711(v_m_249, v_only_241));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_seen_242);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_m_249);
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_path_244}});
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_list_2efind_24s1218501002x1291750665_24cpr(v_m_249, v_sources_240));
        V v_t_2423;
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2414;
            V v_renames_2416 = heff_take_field(v_x_2415, 5);
            V v_implicit_2417 = heff_take_field(v_x_2415, 6);
            V v_source_2418 = heff_get_n(v_x_2415, 4, 8);
            V v_t_2419 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_2417, v_source_2418));
            V v_t_2420 = ({ V a_0 = v_renames_2416; V a_1 = v_t_2419; V r_ = (g_heff_2esyntax_2eimport_2erenamed(a_0, a_1)); heff_drop(v_renames_2416); r_; });
            V v_imps_2421 = heff_get_n(v_t_2420, 0, 4);
            V v_t_2422 = (g_list_2emap_24s1817208647x1282894070(v_imps_2421));
            v_t_2423 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2422));
          } else {
            heff_drop(v_field_2414);
            v_t_2423 = NTAG(TAG_Nil);
          }
        }
        V v_t_2426 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0, 1, 1, (V[]){v_path_244}), v_t_2423));
        V t_0 = v_sources_240;
        V t_1 = v_only_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_m_249, v_seen_242});
        V t_3 = v_t_2426;
        v_sources_240 = t_0;
        v_only_241 = t_1;
        v_seen_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_2424, NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_path_244, v_t_2425));
}
Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efirstErrorOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efirstErrorOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efirstErrorOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_p_242, 0));
    V v_text_245 = heff_dup(heff_rfield(v_p_242, 1));
    V v_t_246 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_247 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if (heff_strEq_c(v_module_244, v_t_2410)) {
      V v_t_2411 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2412 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_text_2413 = v_text_245;
      V v_t_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6); V a_1 = v_text_2413; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7), v_text_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2413); r_; });
      V v_t_2415 = ({ V b_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9); V b_3 = MK_INT(23LL); V a_4 = MK_INT(23LL); V a_5 = v_t_2414; V r_ = (g_list_2emap_24s1127556009x863725781(b_0, b_1, b_2, b_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2416 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2415));
      V v_t_2417 = ({ V a_0 = v_t_2412; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2417);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2417);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_text_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam0(V self, V *args) {
  V v_v_244 = args[0];
  return v_v_244;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4(V self, V *args) {
  V v_v_2424 = args[0];
  return v_v_2424;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6(V self, V *args) {
  V v_s_2434 = args[0];
  return v_s_2434;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2444;
  if (heff_strEq_c(v_x_2443, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str3))) {
    v_st_2444 = NTAG(TAG_Windows);
  } else {
    v_st_2444 = NTAG(TAG_Posix);
  }
  V v_x_2452;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    V v_t_2447;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2433)) {
      case TAG_Nothing: {
        v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2445 = heff_field(v_x_2433, 0);
        heff_take_n(v_x_2433, 1ULL, 1);
        v_t_2447 = v_x_2445;
        break;
      }
      default: heff_nomatch(v_x_2433);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2446 = heff_field(v_x_2423, 0);
      heff_take_n(v_x_2423, 1ULL, 1);
      heff_drop(v_x_2433);
      v_t_2447 = v_x_2446;
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    V v_t_2448 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_t_2447));
    V v_t_2449 = (g_std_2epath_2eparse(heff_dup(v_st_2444), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str5)));
    V v_t_2450 = (g_std_2epath_2ejoin(v_t_2448, v_t_2449));
    v_x_2452 = ({ V a_0 = v_st_2444; V a_1 = v_t_2450; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2450); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2451 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    heff_drop(v_x_2423);
    heff_drop(v_x_2433);
    heff_drop(v_st_2444);
    v_x_2452 = v_d_2451;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_241;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam6_clo)})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2441}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam7, 1, 4, (V[]){v_x_2413, v_x_2423, v_x_2433, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam4_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2431}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam5, 1, 5, (V[]){v_malg_243, v_bind_242, v_x_2413, v_x_2423, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_lam3, 1, 4, (V[]){v_malg_243, v_bind_242, v_x_2413, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderC_24s1118839966x682304030(v_sources_240, v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(a_0, a_1)); heff_drop(v_sources_240); r_; });
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str2, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str3, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str5, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(V v_name_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam0, 1, 3, (V[]){v_hd_241, v_name_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_err_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2434})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2435));
  }
  case TAG_Right: {
    V v_x_2436 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam5, 2, 1, (V[]){v_x_2436});
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2468);
  V f_ = v_k_242;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str5);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam7(V self, V *args) {
  V v_x_2459 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2459);
  V v_t_2460 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_2467;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam8, 1, 1, (V[]){v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    V v_ru_24x_2440_24Left = heff_take_reuse_n(v_x_2440, 0ULL, 1);
    V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_x_243));
    V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2414), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str2)));
    V v_t_2444 = (g_std_2epath_2ejoin(v_t_2442, v_t_2443));
    V v_a_2445 = ({ V a_0 = v_st_2414; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2444); r_; });
    V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_a_2445));
    V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_name_240));
    V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
    V v_t_2449 = ({ V a_0 = v_st_2414; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2448); r_; });
    V v_str_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str3), v_t_2449);
    V v_t_2451 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str4)), NTAG(TAG_MkUnit)});
    V v_t_2452 = heff_tag_at_n(v_ru_24x_2440_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2458;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam7, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2469 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    heff_drop(v_st_2414);
    heff_drop(v_x_243);
    heff_drop(v_name_240);
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = v_y_2469;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2414), heff_dup(v_x_243)));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2414), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_a_2418 = ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_a_2418));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2414), heff_dup(v_name_240)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2414; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam3_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_c_2439 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam4_clo)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam6, 1, 5, (V[]){v_st_2414, v_x_243, v_name_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_lam2, 1, 4, (V[]){v_x_243, v_name_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop_rec(v_p_242, 3);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){v_t_2415}));
      return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam1, 1, 6, (V[]){v_dir_240, v_name_246, v_p_242, v_text_247, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam4(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_err_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2434})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2435));
  }
  case TAG_Right: {
    V v_x_2436 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam4, 2, 1, (V[]){v_x_2436});
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam6(V self, V *args) {
  V v_r_2448 = args[0];
  return v_r_2448;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam8(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_x_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2460);
  V f_ = v_k_2461;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2459});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  switch (heff_tag_of(v_x_2456)) {
  case TAG_Left: {
    V v_err_2457 = heff_field(v_x_2456, 0);
    V v_ru_24x_2456_24Left = heff_take_reuse_n(v_x_2456, 1ULL, 1);
    V v_t_2458 = heff_tag_at_n(v_ru_24x_2456_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2457})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2458));
  }
  case TAG_Right: {
    V v_x_2459 = heff_field(v_x_2456, 0);
    heff_take_n(v_x_2456, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam8, 2, 1, (V[]){v_x_2459});
  }
  default: return heff_nomatch(v_x_2456);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468;
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    heff_take_n(v_x_2465, 0ULL, 1);
    v_t_2468 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2465, 0ULL, 1);
    v_t_2468 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2465);
  }
  V f_ = v_k_2464;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam9(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_c_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2462;
  args[0] = v_hd_2463;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam10, 1, 1, (V[]){v_k_2464});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam11(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  heff_drop(v_hd_2470);
  V f_ = v_k_2471;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam12(V self, V *args) {
  V v_r_2474 = args[0];
  return v_r_2474;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam14(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  V v_x_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2486);
  V f_ = v_k_2487;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2485});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam13(V self, V *args) {
  V v_x_2482 = args[0];
  switch (heff_tag_of(v_x_2482)) {
  case TAG_Left: {
    V v_err_2483 = heff_field(v_x_2482, 0);
    V v_ru_24x_2482_24Left = heff_take_reuse_n(v_x_2482, 1ULL, 1);
    V v_t_2484 = heff_tag_at_n(v_ru_24x_2482_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2483})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2484));
  }
  case TAG_Right: {
    V v_x_2485 = heff_field(v_x_2482, 0);
    heff_take_n(v_x_2482, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam14, 2, 1, (V[]){v_x_2485});
  }
  default: return heff_nomatch(v_x_2482);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam16(V self, V *args) {
  V v_x_2491 = args[0];
  V v_k_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2494;
  switch (heff_tag_of(v_x_2491)) {
  case TAG_Left: {
    heff_take_n(v_x_2491, 0ULL, 1);
    v_t_2494 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2491, 0ULL, 1);
    v_t_2494 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2491);
  }
  V f_ = v_k_2490;
  args[0] = v_t_2494;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam15(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  V v_c_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2488;
  args[0] = v_hd_2489;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam16, 1, 1, (V[]){v_k_2490});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam17(V self, V *args) {
  V v_x_2496 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2496) == NTAG(TAG_True))) {
    heff_drop(v_x_2496);
    return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(v_dir_240, v_rest_245, v_p_242, v_p_243));
  } else {
    heff_drop(v_x_2496);
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop_rec(v_p_242, 3);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2441 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_240)));
  V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_name_246));
  V v_t_2443 = (g_std_2epath_2ejoin(v_t_2441, v_t_2442));
  V v_path_2444 = ({ V a_0 = v_st_2418; V a_1 = v_t_2443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2443); r_; });
  V v_c_2495;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    V v_ru_24x_2440_24Left = heff_take_reuse_n(v_x_2440, 0ULL, 1);
    V v_path_2446 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_2444));
    V v_t_2447 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2446; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2446); r_; });
    V v_a_2449 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2447, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam6_clo)});
    V v_t_2450 = heff_tag_at_n(v_ru_24x_2440_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
    V v_c_2462 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam7_clo)));
    v_c_2495 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam9, 2, 1, (V[]){v_c_2462});
    break;
  }
  case TAG_Right: {
    V v_y_2469 = heff_field(v_x_2440, 0);
    V v_ru_24x_2440_24Right = heff_take_reuse_n(v_x_2440, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_2469, v_text_247, 1)) {
      heff_drop(v_text_247);
      heff_drop(v_path_2444);
      heff_drop_cell(v_ru_24x_2440_24Right, 1);
      v_c_2495 = ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam11_clo);
    } else {
      V v_path_2472 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_2444));
      V v_t_2473 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2472; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2472); r_; });
      V v_a_2475 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2473, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam12_clo)});
      V v_t_2476 = heff_tag_at_n(v_ru_24x_2440_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2475})});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
      V v_c_2488 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam13_clo)));
      v_c_2495 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam15, 2, 1, (V[]){v_c_2488});
    }
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V f_ = v_c_2495;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam17, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_name_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam2_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_c_2439 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam3_clo)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_lam5, 1, 7, (V[]){v_st_2418, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_249, v_x_2414));
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_rt_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2414; V a_9 = v_t_2415; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2413;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str0), 2)) {
    v_c_2413 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam1_clo);
  } else {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2413 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2412));
  }
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str0, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str2, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str3, 8, "heff run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str4, 4, "main");
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462(V v_file_240, V v_progArgs_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_progArgs_241});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam2(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam4(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_cmd_2420 = heff_env(self)[0];
  V v_progArgs_241 = heff_env(self)[1];
  V v_hd_2422 = heff_env(self)[2];
  V v_k_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2424);
  V v_lit_2425 = v_cmd_2420;
  V v_lit_2426 = v_progArgs_241;
  V v_hd_2427 = v_hd_2422;
  V v_bind_2428 = heff_take_field(v_hd_2427, 1);
  V v_malg_2429 = heff_get_n(v_hd_2427, 2, 3);
  V v_k2_2430 = v_k_2423;
  V v_t_2431 = heff_tag_n(TAG_Exec, 3, (V[]){v_lit_2425, v_lit_2426, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(v_malg_2429, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
  V f_ = v_bind_2428;
  heff_room[0] = v_t_2438;
  heff_room[1] = v_k2_2430;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam6(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2410 = heff_env(self)[0];
  V v_cmd_2420 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s1531911654x724325922(v_x_2410, heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam7, 1, 4, (V[]){v_cmd_2420, v_progArgs_241, v_hd_2422, v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_next_2439 = heff_env(self)[0];
  V v_hd_2440 = heff_env(self)[1];
  V v_k_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2442);
  V f_ = v_next_2439;
  heff_room[0] = v_hd_2440;
  heff_room[1] = v_k_2441;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam8(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_next_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2415, heff_dup(v_hd_2440), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam9, 1, 3, (V[]){v_next_2439, v_hd_2440, v_k_2441})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_240)));
  V v_outPath_2417 = heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str1));
  V v_dir_2418 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_240)));
  V v_out_2419 = (g_heff_2ebuild_2ecommands_2erunProgram(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_240)));
  V v_cmd_2420 = (g_heff_2ebuild_2ecommands_2erunProgram(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_240)));
  V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_x_245, 2)), 5, 6);
  V v_next_2439 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918(MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str2), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str3), v_t_2421, heff_dup(v_x_2410), v_dir_2418, v_out_2419, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam6, 2, 3, (V[]){v_x_2410, v_cmd_2420, v_progArgs_241})));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555(MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str4), v_x_245, v_outPath_2417, v_file_240, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam8, 2, 2, (V[]){v_x_2415, v_next_2439}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam4_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam5, 1, 6, (V[]){v_x_245, v_file_240, v_x_2410, v_progArgs_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_dup(v_file_240), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam2_clo)})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam3, 1, 5, (V[]){v_hd_243, v_x_245, v_file_240, v_progArgs_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1285964048x1360558462_lam1, 1, 4, (V[]){v_file_240, v_hd_243, v_progArgs_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532(V v_failed_240, V v_l_241, V v_name_242, V v_outPath_243, V v_file_244, V v_done_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str0), heff_dup(heff_rfield(v_l_241, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam0, 1, 8, (V[]){v_l_241, v_hd_246, v_file_244, v_failed_240, v_k_247, v_name_242, v_outPath_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam2(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_c_2415); V a_1 = v_sources_2413; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2413); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2418;
      V v_t_2420 = ({ V a_0 = v_x_2414; V a_1 = v_s_2419; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2414); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2420));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_file_244 = heff_env(self)[2];
  V v_failed_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_done_2411 = heff_env(self)[6];
  V v_l_241 = heff_env(self)[7];
  V v_hashes_2412 = heff_env(self)[8];
  V v_name_242 = heff_env(self)[9];
  V v_outPath_243 = heff_env(self)[10];
  V v_done_245 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2422);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop(v_done_2411);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_hashes_2412);
    heff_drop(v_name_242);
    heff_drop(v_outPath_243);
    heff_drop(v_done_245);
    HeffT2 v_t_2423 = ({ V a_0 = v_x_2421; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2421); r_; });
    V v_t_2427;
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        heff_drop(v_file_244);
        V v_x_2426 = v_field_2425;
        v_t_2427 = v_x_2426;
      } else {
        heff_drop(v_field_2425);
        v_t_2427 = heff_strAppend(v_file_244, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str3));
      }
    }
    V f_ = v_failed_240;
    heff_room[0] = v_t_2427;
    heff_room[1] = v_hd_246;
    heff_room[2] = v_k_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    V v_t_2428 = (g_list_2eany_24s1740858080x874135214(v_x_2421));
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_done_2411);
      heff_drop_rec(v_l_241, 5);
      heff_drop(v_hashes_2412);
      heff_drop(v_name_242);
      heff_drop(v_outPath_243);
      heff_drop(v_done_245);
      heff_drop(v_t_2428);
      HeffT2 v_t_2429 = ({ V a_0 = v_x_2421; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2421); r_; });
      V v_t_2433;
      {
        V v_field_2431 = v_t_2429.f[1];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          heff_drop(v_file_244);
          V v_x_2432 = v_field_2431;
          v_t_2433 = v_x_2432;
        } else {
          heff_drop(v_field_2431);
          v_t_2433 = heff_strAppend(v_file_244, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str4));
        }
      }
      V f_ = v_failed_240;
      heff_room[0] = v_t_2433;
      heff_room[1] = v_hd_246;
      heff_room[2] = v_k_247;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_t_2428);
      V v_t_2434 = (g_list_2emap_24s1698496827x1884878103(v_done_2411));
      V v_t_2435 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_241, 2), v_hashes_2412, v_t_2434});
      return ({ V a_0 = v_t_2435; V b_1 = heff_get_n(v_l_241, 0, 5); V a_2 = v_file_244; V a_3 = v_name_242; V a_4 = v_outPath_243; V a_5 = v_failed_240; V a_6 = v_done_245; V a_7 = v_x_2421; V a_8 = v_hd_246; V a_9 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(a_0, b_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(b_1); heff_drop(v_x_2421); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_file_244 = heff_env(self)[3];
  V v_failed_240 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_name_242 = heff_env(self)[6];
  V v_outPath_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_done_2411 = heff_take_field(v_x_2410, 0);
  V v_hashes_2412 = heff_get_n(v_x_2410, 1, 2);
  V v_sources_2413 = heff_dup(heff_rfield(v_l_241, 0));
  V v_x_2414 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_str2), heff_dup(v_sources_2413)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam2, 1, 2, (V[]){v_sources_2413, v_x_2414}), heff_dup(v_done_2411)));
  return ({ V a_0 = v_x_2421; V a_1 = heff_dup(v_hd_246); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam3, 1, 12, (V[]){v_x_248, heff_dup(v_x_2421), v_file_244, v_failed_240, v_hd_246, v_k_247, v_done_2411, v_l_241, v_hashes_2412, v_name_242, v_outPath_243, v_done_245}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_x_2421); r_; });
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_file_244 = heff_env(self)[2];
  V v_failed_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_name_242 = heff_env(self)[5];
  V v_outPath_243 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_241)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s335117949x1180564532_lam1, 1, 9, (V[]){v_l_241, v_hd_246, v_x_248, v_file_244, v_failed_240, v_k_247, v_name_242, v_outPath_243, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979(a[0]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_245, 1));
  heff_drop(v_x_245);
  return ({ V a_0 = v_file_240; V a_1 = v_t_248; V b_2 = heff_get_n(v_x_247, 0, 2); V a_3 = v_hd_242; V a_4 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297(a_0, a_1, b_2, a_3, a_4)); heff_drop(v_t_248); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam3, 1, 4, (V[]){v_x_245, v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam2, 1, 4, (V[]){v_x_244, v_hd_242, v_file_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s327349013x930074979_lam1, 1, 3, (V[]){v_hd_242, v_file_240, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_str1, 4, "page");
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_checked_247, V v_z_248, V v_z_249) {
top: ;
  V v_c_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_str0); V a_1 = heff_dup(v_sources_241); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s2061381882x394225993(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam0, 1, 10, (V[]){v_sources_241, v_checked_247, v_z_248, heff_dup(v_badL_246), v_z_249, v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245})});
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778(a[0], a[1], a[2], a3, a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a3); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam1(V self, V *args) {
  V v_c_2414 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2415 = ({ V a_0 = heff_dup(v_c_2414); V a_1 = v_sources_241; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_241); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_s_2418 = v_field_2417;
      V v_t_2419 = ({ V a_0 = v_x_2413; V a_1 = v_s_2418; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2413); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2414, v_t_2419));
    } else {
      heff_drop(v_x_2413);
      heff_drop(v_field_2417);
      return v_c_2414;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_badL_246 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_bi_240 = heff_env(self)[4];
  V v_sources_241 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2421);
  if ((heff_dup(v_badL_246) == NTAG(TAG_True))) {
    heff_drop(v_badL_246);
    heff_drop(v_x_2420);
    heff_drop(v_bi_240);
    heff_drop(v_sources_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_248, v_z_249));
  } else {
    heff_drop(v_badL_246);
    V v_t_2422 = (g_list_2eany_24s1740858080x874135214(v_x_2420));
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_x_2420);
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_t_2422);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_248, v_z_249));
    } else {
      heff_drop(v_t_2422);
      return ({ V a_0 = v_bi_240; V a_1 = v_sources_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_x_2420; V a_7 = v_z_248; V a_8 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_sources_241); heff_drop(v_name_243); heff_drop(v_x_2420); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_checked_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_badL_246 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2412 = (g_list_2emap_24s159228909x554161698(((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_str1), heff_dup(v_sources_241), v_x_2411, heff_dup(v_sources_241)));
  V v_x_2413 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2412));
  V v_x_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam1, 1, 2, (V[]){heff_dup(v_sources_241), v_x_2413}), v_checked_247));
  return ({ V a_0 = v_x_2420; V a_1 = heff_dup(v_z_248); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_lam2, 1, 10, (V[]){v_badL_246, v_z_248, v_z_249, heff_dup(v_x_2420), v_bi_240, v_sources_241, v_file_242, v_name_243, v_outPath_244, v_done_245}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_x_2420); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(V v_checkOnly_240, V v_x2_241, V v_bad_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam0, 2, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2efmtOne_24s1553607721x611894475(v_checkOnly_240, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_bad_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_bad_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_2410); V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449(a_0, a_1, a_2)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_checkOnly_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_bad_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1282022268x1000983449_lam2, 1, 5, (V[]){v_checkOnly_240, v_rest_246, v_bad_242, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_245)));
    V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
    V v_t_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_c_2411 = (g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(v_t_2410));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam1, 2, 5, (V[]){v_c_2411, v_st_240, v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417;
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop(v_n_245);
    v_t_2417 = v_x_2416;
  } else {
    heff_drop(v_x_2414);
    v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, v_x_2416});
  }
  V f_ = v_k_2413;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = (g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(v_st_240, v_t_241, v_rest_246));
  V f_ = v_c_2415;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam3, 1, 3, (V[]){v_x_2414, v_n_245, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_2412, v_n_245, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_home_242);
    heff_drop(v_sh_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_t_248 = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_home_242), heff_dup(v_sh_243), v_next_244, v_rest_247));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s793631636x119352989_clo), 6, (V[]){v_st_240, v_t_241, v_home_242, v_sh_243, v_t_248, heff_dup(v_n_246)});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str9, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str11, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str12, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str20, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str21, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str22, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567(V v_st_240, V v_cmd_241, V v_t_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_t_248 = ({ V a_0 = v_st_240; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_249, NTAG(TAG_Nil)));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam0, 1, 5, (V[]){v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam1(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam7(V self, V *args) {
  V v_r_2457 = args[0];
  return v_r_2457;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam10(V self, V *args) {
  V v_n_2473 = args[0];
  V v_path_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2473));
  return (g_std_2epath_2ejoin(v_path_2455, v_t_2474));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam9(V self, V *args) {
  V v_x_2470 = args[0];
  V v_z_2471 = args[1];
  V v_z_2472 = args[2];
  V v_path_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2471);
  V v_x_2475 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam10, 1, 1, (V[]){v_path_2455}), v_x_2470));
  V v_x_2476 = (g_list_2emap_24s219049803x1458391381(v_x_2475));
  V f_ = v_z_2472;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2476});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam11(V self, V *args) {
  V v_n_2478 = args[0];
  V v_path_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2478));
  return (g_std_2epath_2ejoin(v_path_2455, v_t_2479));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_z_2466 = args[1];
  V v_z_2467 = args[2];
  V v_path_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    V v_err_2468 = heff_field(v_x_2465, 0);
    V v_ru_24x_2465_24Left = heff_take_reuse_n(v_x_2465, 1ULL, 1);
    V v_t_2469 = heff_tag_at_n(v_ru_24x_2465_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2468})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2469, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam9, 3, 1, (V[]){v_path_2455}), v_z_2466, v_z_2467));
  }
  case TAG_Right: {
    V v_x_2477 = heff_field(v_x_2465, 0);
    heff_take_n(v_x_2465, 1ULL, 1);
    heff_drop(v_z_2466);
    V v_x_2480 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam11, 1, 1, (V[]){v_path_2455}), v_x_2477));
    V v_x_2481 = (g_list_2emap_24s219049803x1458391381(v_x_2480));
    V f_ = v_z_2467;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2481});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2465);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam13(V self, V *args) {
  V v_t_2490 = args[0];
  return v_t_2490;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam17(V self, V *args) {
  V v_x_24119 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24119);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam16(V self, V *args) {
  V v_x_24105 = args[0];
  V v_bad_24100 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_apps_24101 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24105);
  if (heff_intLt_c_lent(MK_INT(0LL), v_bad_24100, 1)) {
    heff_drop(v_apps_24101);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    V v_n_24106 = v_bad_24100;
    V v_t_24107;
    if (heff_intEq_c_lent(v_n_24106, MK_INT(1LL), 2)) {
      heff_drop(v_n_24106);
      v_t_24107 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str17);
    } else {
      v_t_24107 = heff_strAppend(heff_intShow(v_n_24106), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str18));
    }
    V v_what_24108 = heff_strAppend(v_t_24107, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str19));
    V v_t_24109 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str20), v_cmd_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str21));
    V v_t_24110 = heff_strAppend(heff_strAppend(v_t_24109, v_what_24108), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str22));
    V v_t_24111 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24110, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str23)), NTAG(TAG_MkUnit)});
    V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
    V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
    V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24117})}));
    V f_ = heff_dup(heff_rfield(v_z_243, 1));
    heff_room[0] = v_t_24118;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam17, 1, 2, (V[]){v_z_243, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_bad_24100);
    heff_drop(v_cmd_241);
    switch (heff_tag_of(v_apps_24101)) {
    case TAG_Nil: {
      heff_drop_rec(v_z_243, 3);
      heff_drop(v_st_240);
      heff_drop_rec(v_t_242, 6);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233(v_st_240, v_t_242, v_apps_24101, v_z_243, v_z_244));
    }
    default: return heff_nomatch(v_apps_24101);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam15(V self, V *args) {
  V v_x_2499 = args[0];
  V v_x_2494 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_bad_24100 = heff_take_field(v_x_2499, 1);
  V v_apps_24101 = heff_get_n(v_x_2499, 0, 2);
  V v_t_24102 = heff_tag_n(TAG_End, 2, (V[]){v_x_2494, NTAG(TAG_MkUnit)});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})}));
  V f_ = heff_dup(heff_rfield(v_z_243, 1));
  heff_room[0] = v_t_24104;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam16, 1, 7, (V[]){v_bad_24100, v_cmd_241, v_z_243, v_z_244, v_apps_24101, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam14(V self, V *args) {
  V v_x_2494 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2495 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2497;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Nothing: {
    v_t_2497 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2496 = heff_field(v_x_2486, 0);
    heff_take_n(v_x_2486, 1ULL, 1);
    v_t_2497 = v_x_2496;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V v_c_2498 = (g_heff_2ebuild_2ecommands_2eappsIn_24s472957219x906754093(heff_dup(v_st_240), heff_dup(v_t_242), heff_dup(v_x_2494), v_t_2495, v_t_2497));
  V f_ = v_c_2498;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam15, 1, 6, (V[]){v_x_2494, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam12(V self, V *args) {
  V v_x_2483 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2486;
  switch (heff_tag_of(v_x_2483)) {
  case TAG_Left: {
    heff_take_n(v_x_2483, 0ULL, 1);
    v_x_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2485 = heff_field(v_x_2483, 0);
    V v_ru_24x_2483_24Right = heff_take_reuse_n(v_x_2483, 1ULL, 1);
    v_x_2486 = heff_tag_at_n(v_ru_24x_2483_24Right, TAG_Just, 1, (V[]){v_y_2485});
    break;
  }
  default: heff_nomatch(v_x_2483);
  }
  V v_t_2488;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Nothing: {
    v_t_2488 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2487 = heff_dup(heff_field(v_x_2486, 0));
    v_t_2488 = v_x_2487;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V v_total_2489 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2488; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2488); r_; });
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str16), v_total_2489, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam13_clo)})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){v_t_2492}));
  V f_ = heff_dup(heff_rfield(v_z_243, 1));
  heff_room[0] = v_t_2493;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam14, 1, 6, (V[]){v_x_2486, v_st_240, v_t_242, v_z_243, v_cmd_241, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2450);
  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str15)));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  V v_s_2454 = ({ V a_0 = v_st_240; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2453); r_; });
  V v_path_2455 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2454));
  V v_t_2456 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2455; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2458 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2456, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam7_clo)});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  V v_c_2482 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam8, 3, 1, (V[]){v_path_2455})));
  V f_ = v_c_2482;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam12, 1, 5, (V[]){v_z_243, v_st_240, v_t_242, v_cmd_241, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_errors_2421 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_seen_2422 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2423);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2421, 1)) {
    heff_drop(v_seen_2422);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    V v_n_2424 = v_errors_2421;
    V v_t_2425;
    if (heff_intEq_c_lent(v_n_2424, MK_INT(1LL), 2)) {
      heff_drop(v_n_2424);
      v_t_2425 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str2);
    } else {
      v_t_2425 = heff_strAppend(heff_intShow(v_n_2424), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str3));
    }
    V v_what_2426 = heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str4));
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str5), v_cmd_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str6));
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, v_what_2426), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str7));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str8)), NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
    V f_ = heff_dup(heff_rfield(v_z_243, 1));
    heff_room[0] = v_t_2436;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam5, 1, 2, (V[]){v_z_243, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_errors_2421);
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str9), heff_dup(v_cmd_241)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str10));
    V v_n_2439 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2422; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2422); r_; });
    V v_t_2440;
    if (heff_intEq_c_lent(v_n_2439, MK_INT(1LL), 2)) {
      heff_drop(v_n_2439);
      v_t_2440 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str11);
    } else {
      v_t_2440 = heff_strAppend(heff_intShow(v_n_2439), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str12));
    }
    V v_str_2441 = heff_strAppend(heff_strAppend(v_t_2438, v_t_2440), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str13));
    V v_t_2442 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2441, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str14)), NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
    V f_ = heff_dup(heff_rfield(v_z_243, 1));
    heff_room[0] = v_t_2449;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam6, 1, 5, (V[]){v_st_240, v_t_242, v_z_243, v_cmd_241, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_errors_2421 = heff_take_field(v_x_2420, 1);
  V v_seen_2422 = heff_get_n(v_x_2420, 0, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2417, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam4, 1, 7, (V[]){v_errors_2421, v_cmd_241, v_z_243, v_z_244, v_seen_2422, v_st_240, v_t_242})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2419 = ({ V a_0 = heff_dup(v_x_2417); V a_1 = v_t_2418; V a_2 = v_x_2411; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam3, 1, 6, (V[]){v_x_2417, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_total_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2411));
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_str1), v_total_2412, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam1_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){v_t_2415}));
  V f_ = heff_dup(heff_rfield(v_z_243, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567_lam2, 1, 6, (V[]){v_x_2411, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str1, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str4, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam3(V self, V *args);

static V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_st;
static V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_init(void) {
  V v_path_240 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str0)));
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_240); r_; });
  V v_a_243 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam0_clo)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_c_2416 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam3, 2, 1, (V[]){v_c_2416});
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_st)) return g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_val, &g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_st, g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_init);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_err_2411 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_t_2412 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2411})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2412));
  }
  case TAG_Right: {
    V v_x_2413 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam2, 2, 1, (V[]){v_x_2413});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam5(V self, V *args) {
  V v_s_2421 = args[0];
  return v_s_2421;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str1), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
  V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam7, 1, 2, (V[]){v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam8(V self, V *args) {
  V v_s_2441 = args[0];
  return v_s_2441;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam9(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2451;
  if (heff_strEq_c(v_x_2450, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str2))) {
    v_st_2451 = NTAG(TAG_Windows);
  } else {
    v_st_2451 = NTAG(TAG_Posix);
  }
  V v_t_2452 = (g_heff_2ebuild_2ecommands_2ebuildTarget(heff_dup(v_st_2451), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str3)));
  return (g_heff_2ebuild_2ecommands_2ebuildProject_24s39381744x459433567(v_st_2451, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_str4), v_t_2452, v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 0ULL, 1);
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam5_clo)})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2428}));
    V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
    heff_room[0] = v_t_2429;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam6, 1, 2, (V[]){v_hd_2417, v_k_2418});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 0ULL, 1);
    V v_t_2442 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam8_clo)})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2448}));
    V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
    heff_room[0] = v_t_2449;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam9, 1, 2, (V[]){v_hd_2417, v_k_2418});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s807229145x796263163_lam4, 1, 2, (V[]){v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str2, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str3, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str4, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str5, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str7, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str8, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str9, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam3(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_x_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    V v_err_2430 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Left = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    V v_t_2431 = heff_tag_at_n(v_ru_24x_2429_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2430})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2431));
  }
  case TAG_Right: {
    V v_x_2432 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam5, 2, 1, (V[]){v_x_2432});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam7(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2454);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam9(V self, V *args) {
  V v_x_2480 = args[0];
  V v_hd_2469 = heff_env(self)[0];
  V v_k_2470 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2480);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2469, v_k_2470));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam8(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_dir_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str8), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str9));
  V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str10)), NTAG(TAG_MkUnit)});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2469, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})}));
  V f_ = heff_dup(heff_rfield(v_hd_2469, 1));
  args[0] = v_t_2479;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam9, 1, 2, (V[]){v_hd_2469, v_k_2470});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2439;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    heff_take_n(v_x_2436, 0ULL, 1);
    v_x_2439 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2438 = heff_field(v_x_2436, 0);
    V v_ru_24x_2436_24Right = heff_take_reuse_n(v_x_2436, 1ULL, 1);
    v_x_2439 = heff_tag_at_n(v_ru_24x_2436_24Right, TAG_Just, 1, (V[]){v_y_2438});
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V v_t_2440 = (g_std_2epath_2eparse(heff_dup(v_st_2413), heff_dup(v_x_2414)));
  V v_t_2441 = (g_std_2epath_2eparse(heff_dup(v_st_2413), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str2)));
  V v_t_2442 = (g_std_2epath_2ejoin(v_t_2440, v_t_2441));
  V v_t_2443 = ({ V a_0 = v_st_2413; V a_1 = v_t_2442; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2442); r_; });
  V v_x_2444 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_240), v_t_2443, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str3), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2414)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str4)});
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Nothing: {
    heff_drop(v_st_2413);
    heff_drop(v_x_2414);
    heff_drop_rec(v_x_2444, 6);
    V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str5), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str6));
    V v_t_2446 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2445, NTAG(TAG_MkUnit)});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2453;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam7, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_2468;
    switch (heff_tag_of(v_x_2439)) {
    case TAG_Nothing: {
      heff_drop(v_x_2414);
      v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2444, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2456 = heff_field(v_x_2439, 0);
      heff_take_n(v_x_2439, 1ULL, 1);
      HeffT2 v_t_2457 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_text_2456));
      {
        V v_field_2459 = v_t_2457.f[1];
        int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
        if ((v_tag_2458 == ((int64_t)0ULL))) {
          heff_drop(v_x_2414);
          V v_p_2460 = v_field_2459;
          heff_drop(v_p_2460);
          v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2444, 1))}));
        } else {
          V v_x_2461 = v_field_2459;
          HeffT2 v_t_2462 = ({ V a_0 = v_x_2461; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2461); r_; });
          {
            V v_field_2464 = v_t_2462.f[1];
            int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
            if ((v_tag_2463 == ((int64_t)0ULL))) {
              heff_drop(v_x_2414);
              V v_x11_2465 = v_field_2464;
              heff_drop(v_x11_2465);
              v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2444, 1))}));
            } else {
              V v_pk_2466 = v_field_2464;
              if (heff_strEq_c(heff_get_n(v_pk_2466, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2444, 1))}));
                v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo), 5, (V[]){heff_dup(v_st_2413), heff_dup(v_x_2444), v_x_2414, heff_dup(v_dir_240), v_t_2467}));
              } else {
                heff_drop(v_x_2414);
                v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2444, 1))}));
              }
            }
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x_2439);
    }
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s30631956x1758958295(v_st_2413, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str7), v_x_2444, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam8, 2, 1, (V[]){v_dir_240}), v_t_2468, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2439);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2413), heff_dup(v_dir_240)));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2413), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_s_2418 = ({ V a_0 = v_st_2413; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_path_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2418));
  V v_t_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2419; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2419); r_; });
  V v_a_2422 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam3_clo)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_c_2435 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam4_clo)));
  V f_ = v_c_2435;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam6, 1, 5, (V[]){v_st_2413, v_x_2414, v_dir_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_2413;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_str0))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1251173373x1550602938_lam2, 1, 4, (V[]){v_st_2413, v_dir_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str0, 23, "not known: there is no ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str1, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str2, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str3, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str4, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2415));
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam3, 2, 1, (V[]){v_x_2416});
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_2421 = v_x_242;
  V v_x2_2424;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    heff_take_n(v_x_2420, 0ULL, 1);
    v_x2_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    v_x2_2424 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_Just, 1, (V[]){v_y_2423});
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_t_2439;
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_Nothing: {
    v_t_2439 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str0), v_path_2421)});
    break;
  }
  case TAG_Just: {
    V v_src_2425 = heff_field(v_x2_2424, 0);
    V v_ru_24x2_2424_24Just = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
    HeffT2 v_t_2426 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_src_2425)));
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_p_2429 = v_field_2428;
        V v_t_2430 = ({ V a_0 = v_path_2421; V a_1 = v_src_2425; V a_2 = v_p_2429; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2425); r_; });
        v_t_2439 = heff_tag_at_n(v_ru_24x2_2424_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str1), v_t_2430)});
      } else {
        V v_x_2431 = v_field_2428;
        HeffT2 v_t_2432 = ({ V a_0 = v_x_2431; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2431); r_; });
        {
          V v_field_2434 = v_t_2432.f[1];
          int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
          if ((v_tag_2433 == ((int64_t)0ULL))) {
            V v_p_2435 = v_field_2434;
            V v_t_2436 = ({ V a_0 = v_path_2421; V a_1 = v_src_2425; V a_2 = v_p_2435; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2425); r_; });
            v_t_2439 = heff_tag_at_n(v_ru_24x2_2424_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str2), v_t_2436)});
          } else {
            heff_drop(v_path_2421);
            heff_drop(v_src_2425);
            V v_p_2437 = v_field_2434;
            V v_t_2438 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str3), heff_get_n(v_p_2437, 1, 4));
            v_t_2439 = heff_tag_at_n(v_ru_24x2_2424_24Just, TAG_Right, 1, (V[]){v_t_2438});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x2_2424);
  }
  switch (heff_tag_of(v_t_2439)) {
  case TAG_Left: {
    V v_why_2440 = heff_field(v_t_2439, 0);
    V v_ru_24t_2439_24Left = heff_take_reuse_n(v_t_2439, 1ULL, 1);
    V v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str4), v_why_2440), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str5));
    V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2441, NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_at_n(v_ru_24t_2439_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2449;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam5, 1, 2, (V[]){v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_line_2451 = heff_field(v_t_2439, 0);
    V v_ru_24t_2439_24Right = heff_take_reuse_n(v_t_2439, 1ULL, 1);
    V v_t_2452 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2451, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_str6)), NTAG(TAG_MkUnit)});
    V v_t_2453 = heff_tag_at_n(v_ru_24t_2439_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2459;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2439);
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_242)));
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam1_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_c_2419 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam2_clo)));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s859137458x511942371_lam4, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str0, 5, "=def ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str2, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str3, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str4, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str5, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str6, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str7, 6, "=body ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 14);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str0), heff_dup(v_k_244)), ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str1));
    V v_t_247 = (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_240), v_k_244));
    V v_t_248 = heff_strAppend(v_t_246, v_t_247);
    V v_t_249 = heff_dup(heff_rfield(v_c_240, 5));
    V v_k_2410 = heff_dup(v_k_244);
    V v_g_2411 = heff_get_n(v_t_249, 0, 10);
    V v_entries_2412 = heff_take_field(v_g_2411, 1);
    V v_aliases_2413 = heff_get_n(v_g_2411, 2, 8);
    HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2412, v_k_2410));
    V v_t_2426;
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_k_2410);
        heff_drop(v_entries_2412);
        heff_drop(v_aliases_2413);
        V v_e_2417 = v_field_2416;
        v_t_2426 = ({ V b_0 = heff_get_n(v_e_2417, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_field_2416);
        HeffT2 v_t_2418 = ({ V a_0 = v_aliases_2413; V a_1 = v_k_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2413); heff_drop(v_k_2410); r_; });
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_k2_2421 = v_field_2420;
            HeffT2 v_t_2422 = ({ V a_0 = v_entries_2412; V a_1 = v_k2_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2412); heff_drop(v_k2_2421); r_; });
            {
              V v_field_2424 = v_t_2422.f[1];
              int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
              if ((v_tag_2423 == ((int64_t)0ULL))) {
                V v_e_2425 = v_field_2424;
                v_t_2426 = ({ V b_0 = heff_get_n(v_e_2425, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
              } else {
                heff_drop(v_field_2424);
                v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str2);
              }
            }
          } else {
            heff_drop(v_entries_2412);
            heff_drop(v_field_2420);
            v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str3);
          }
        }
      }
    }
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str4), v_t_2426);
    V v_t_2428 = heff_dup(heff_rfield(v_c_240, 5));
    V v_k_2429 = v_k_244;
    V v_g_2430 = heff_get_n(v_t_2428, 0, 10);
    V v_entries_2431 = heff_take_field(v_g_2430, 1);
    V v_aliases_2432 = heff_get_n(v_g_2430, 2, 8);
    HeffT2 v_t_2433 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2431, v_k_2429));
    V v_t_2445;
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      if ((v_tag_2434 == ((int64_t)0ULL))) {
        heff_drop(v_k_2429);
        heff_drop(v_entries_2431);
        heff_drop(v_aliases_2432);
        V v_e_2436 = v_field_2435;
        v_t_2445 = ({ V b_0 = heff_get_n(v_e_2436, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_field_2435);
        HeffT2 v_t_2437 = ({ V a_0 = v_aliases_2432; V a_1 = v_k_2429; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2432); heff_drop(v_k_2429); r_; });
        {
          V v_field_2439 = v_t_2437.f[1];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            V v_k2_2440 = v_field_2439;
            HeffT2 v_t_2441 = ({ V a_0 = v_entries_2431; V a_1 = v_k2_2440; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2431); heff_drop(v_k2_2440); r_; });
            {
              V v_field_2443 = v_t_2441.f[1];
              int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
              if ((v_tag_2442 == ((int64_t)0ULL))) {
                V v_e_2444 = v_field_2443;
                v_t_2445 = ({ V b_0 = heff_get_n(v_e_2444, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
              } else {
                heff_drop(v_field_2443);
                v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str5);
              }
            }
          } else {
            heff_drop(v_entries_2431);
            heff_drop(v_field_2439);
            v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str6);
          }
        }
      }
    }
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str7), v_t_2445);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam1, 2, 5, (V[]){v_t_248, v_t_2427, v_t_2446, v_c_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam2(V self, V *args) {
  V v_x_2456 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2447 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2456);
  V v_t_2457 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250(v_c_240, v_rest_245));
  V f_ = v_t_2457;
  heff_room[0] = v_hd_2447;
  heff_room[1] = v_k_2448;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam1(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_t_2427 = heff_env(self)[1];
  V v_t_2446 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2449 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_str8)), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s1686961086x581293358(v_t_2427, v_t_2446, heff_dup(v_hd_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1295587504x1994792250_lam2, 1, 4, (V[]){v_c_240, v_rest_245, heff_dup(v_hd_2447), v_k_2448}), heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_hd_2447));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V v_tok_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_str0), v_e_244), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_str1));
    V v_t_247 = heff_tag_at_n(v_tok_240, TAG_WriteErr, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s321980040x1154251472(v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_p_242));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(a[0], a[1], a[2], a[3]);
}