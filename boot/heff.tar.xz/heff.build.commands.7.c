// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Move 53768
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_backend 2032133329
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_diags 296935042
#define LBL_diff 9578700
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_effect 641056956
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_got 312070
#define LBL_heff 9694020
#define LBL_key 315609
#define LBL_line 9817275
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_segments 1801007612
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_value 313331083
#define LBL_version 583465758
#define LBL_watch 314261737
#define LBL_watches 1357821955
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ebackcache_2ebackD(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackD_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ebuiltAt(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuiltAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuiltAt_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_clo;
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726_clo;
V g_heff_2ebuild_2ecommands_2ekeptId(V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptId_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptId_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2epathOfModule(V, V);
V g_heff_2ebuild_2ecommands_2epathOfModule_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epathOfModule_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_clo;
V g_heff_2ebuild_2ecommands_2erequiring(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erequiring_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erequiring_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo;
V g_heff_2ebuild_2edecoder_2erun(V, V);
V g_heff_2ebuild_2edecoder_2erun_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2erun_clo;
V g_heff_2ebuild_2edecoder_2ewhole(V, V, V);
V g_heff_2ebuild_2edecoder_2ewhole_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewhole_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2eeffectOfKey(V, V);
V g_heff_2ebuild_2edriver_2eeffectOfKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eeffectOfKey_clo;
V g_heff_2ebuild_2edriver_2efindRunnable(V, V, V);
V g_heff_2ebuild_2edriver_2efindRunnable_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efindRunnable_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erunTests(V, V);
V g_heff_2ebuild_2edriver_2erunTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erunTests_clo;
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo;
V g_heff_2ebuild_2eload_2eunder(V, V, V);
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eunder_clo;
V g_heff_2ebuild_2eproject_2emajorMismatch(V, V);
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1717515461x1947736435(V, V, V, V);
V g_list_2efoldl_24f1717515461x1947736435_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1717515461x1947736435_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1665123230x1905625068(V, V, V, V, V, V);
V g_list_2emap_24s1665123230x1905625068_entry(V self, V *a);
extern Clo g_list_2emap_24s1665123230x1905625068_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), MK_INT(0LL), MK_INT(1LL)));
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_text_241)), MK_INT(1LL));
    V v_t_244 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), v_t_243, MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), MK_INT(0LL), MK_INT(1LL)));
      V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_text_241)), MK_INT(1LL));
      V v_t_249 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), v_t_248, MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(heff_dup(v_text_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ecommands_2ekeptId_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptId_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ekeptId(V v_b_240, V v_x2_241, V v_kept_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_b_240);
    heff_drop(v_kept_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_at_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_kept_242)), heff_dup(v_at_243));
    if (heff_intEq_c(heff_intSub(v_t_244, MK_INT(1LL)), heff_strLength(heff_dup(v_b_240)))) {
      V v_t_246 = heff_strSlice(heff_dup(v_kept_242), heff_intAdd(heff_dup(v_at_243), MK_INT(1LL)), heff_strLength(heff_dup(v_kept_242)));
      if (heff_strEq_c(v_t_246, v_b_240)) {
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_strSlice(v_kept_242, MK_INT(0LL), v_at_243)});
      } else {
        heff_drop(v_kept_242);
        heff_drop(v_at_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_b_240);
      heff_drop(v_kept_242);
      heff_drop(v_at_243);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ekeptId_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptId(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4), heff_dup(heff_rfield(v_p_242, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_list_2emap_24s1665123230x1905625068(MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6), MK_INT(23LL), MK_INT(23LL), v_t_2412));
      V v_t_2414 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2413));
      V v_t_2415 = ({ V a_0 = v_t_2411; V a_1 = v_t_2414; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2414); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2415);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2415);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2ebuild_2ecommands_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectedRes_st;
static V g_heff_2ebuild_2ecommands_2eexpectedRes_init(void) {
  return heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectedRes_st)) return g_heff_2ebuild_2ecommands_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectedRes_val, &g_heff_2ebuild_2ecommands_2eexpectedRes_st, g_heff_2ebuild_2ecommands_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str2, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str3, 12, "\012  diff     ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str4, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str5, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str8, 5, "FAIL ");
Clo g_heff_2ebuild_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_intShow(heff_take_field(v_r_241, 1));
  V v_t_244 = heff_take_field(v_r_241, 0);
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str1), heff_strAppend(v_n_245, ((V)&g_heff_2ebuild_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_247 = heff_get_n(heff_get_n(v_r_241, 2, 3), 2, 10);
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str3), heff_take_field(v_m_242, 2));
  V v_t_249 = heff_strAppend(heff_take_field(v_m_242, 1), v_t_248);
  V v_t_2410 = heff_strAppend(heff_get_n(v_m_242, 0, 3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str4), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str5), v_t_2410));
  V v_t_2412 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str6), v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str7), heff_strAppend(v_t_243, v_t_2412));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str8), heff_strAppend(v_f_240, v_t_2413));
}
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efailLine(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_str1, 2, ": ");
Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efirstErrorOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efirstErrorOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_x2_243 = (g_list_2efilter_24s1064353769x1815078842(heff_dup(heff_rfield(v_c_241, 6))));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 2);
      V v_t_246 = (g_heff_2elsp_2erender_2ediagWhere(heff_dup(heff_rfield(v_c_241, 1)), heff_dup(heff_rfield(v_c_241, 3)), heff_dup(v_d_244)));
      V v_t_247 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_244)));
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_str0), heff_get_n(v_d_244, 2, 5));
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_str1), heff_strAppend(v_t_247, v_t_248));
      V v_why_2410 = heff_strAppend(v_t_246, v_t_249);
      return heff_tag_n(TAG_Just, 1, (V[]){v_why_2410});
    }
    default: return heff_nomatch(v_x2_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efirstErrorOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str0, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str1, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str2, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str4, 17, "package : Package");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str6, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str10, 6, ".heff/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str11, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str12, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str13, 18, "-- `heff test src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str14, 14, "/greeting.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str16, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str17, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str18, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str19, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str21, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str22, 59, "-- checks them all, and this one's doc tests are checked by");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str24, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str25, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str26, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str27, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str28, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str29, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str30, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str32, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str33, 75, "  unit \"greeting\" (assertEqual showString (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str35, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str36, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str37, 66, "-- of type `Test` (lib/check.hf), after the watches and doc tests.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str39, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str40, 69, "-- `heff test` runs the tests of every file of test/: the definitions");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str41, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str42, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str43, 10, "package.hf");
Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str0), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str2), heff_strAppend(heff_dup(v_name_240), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str5); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str7), v_t_245}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str8), NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str10); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str11), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str12)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str14)));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str15), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str17), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str19), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str20), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str21), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2414})});
  V v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str23); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str24); V a_2 = v_t_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2415, 2); r_; });
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str25), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str26)));
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2eprogramText(heff_dup(v_name_240)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str27), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str28)));
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str29), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str30)));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str31), NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str33), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str34), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str35), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str38), v_t_2424})});
  V v_t_2426 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str39); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str40); V a_2 = v_t_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2425, 2); r_; });
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str41), v_t_2426}), NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, heff_dup(g_heff_2ebuild_2ecommands_2ebuildText_get())}), v_t_2427});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_t_2418}), v_t_2428});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2416}), v_t_2429});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str42), v_t_248}), v_t_2430});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str43), v_t_246}), v_t_2431});
}
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprojectFiles(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2erequiring_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erequiring_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erequiring_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erequiring_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erequiring(V v_pk_240, V v_name_241, V v_path_242, V v_v_243) {
top: ;
  V v_t_245 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2ecommands_2erequiring_lam0, 1, 1, (V[]){heff_dup(v_path_242)}), heff_rfield(v_pk_240, 2)));
  V v_t_249;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_name_241);
    heff_drop(v_t_245);
    v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2erequiring_lam1, 1, 2, (V[]){v_path_242, v_v_243}), heff_dup(heff_rfield(v_pk_240, 2))));
  } else {
    heff_drop(v_t_245);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_241, v_path_242, v_v_243}), NTAG(TAG_Nil)});
    v_t_249 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_240, 2)), v_t_248));
  }
  return ({ V rv_2 = v_t_249; V rr_ = heff_rec_reuse_nf(v_pk_240, 11ULL, 4, shape_module__heff__require__replace, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ebuild_2ecommands_2erequiring_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erequiring(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2erequiring_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_244, 1, 3), v_path_242);
}
V g_heff_2ebuild_2ecommands_2erequiring_lam1(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_r_246, 1)), heff_dup(v_path_242))) {
    return ({ V rv_1 = v_path_242; V rv_2 = v_v_243; V rr_ = heff_rec_reuse_nf(v_r_246, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  } else {
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    return v_r_246;
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2(V self, V *args) {
  V v_v_247 = args[0];
  return v_v_247;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2423;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str3))) {
    v_x_2423 = NTAG(TAG_Windows);
  } else {
    v_x_2423 = NTAG(TAG_Posix);
  }
  V v_x_2434;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_d_2425;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      v_d_2425 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str4);
      break;
    }
    case TAG_Just: {
      V v_x_2424 = heff_field(v_x_2416, 0);
      heff_take_n(v_x_2416, 1ULL, 1);
      v_d_2425 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    V v_a_2427;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      v_a_2427 = v_d_2425;
      break;
    }
    case TAG_Just: {
      V v_x_2426 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop(v_d_2425);
      v_a_2427 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_2428 = (g_std_2epath_2eparse(v_x_2423, v_a_2427));
    V v_t_2429 = (g_std_2epath_2eparse(v_x_2423, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str5)));
    V v_p_2430 = (g_std_2epath_2ejoin_2eonto_240(v_t_2428, v_t_2429));
    V v_t_2431 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2430, 1)), heff_rfield(v_p_2430, 2)));
    V v_t_2432 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_p_2430, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_x_2434 = ({ V a_0 = v_x_2423; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2423); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2433 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    heff_drop(v_x_2416);
    heff_drop(v_x_2411);
    heff_drop(v_x_2423);
    v_x_2434 = v_d_2433;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V f_ = v_k_241;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7, 1, 4, (V[]){v_x_246, v_x_2416, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5, 1, 4, (V[]){v_hd_240, v_x_246, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3, 1, 3, (V[]){v_hd_240, v_x_246, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_2410;
    if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str0))) {
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
    } else {
      v_t_2410 = v_path_245;
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str1));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1, 2, 2, (V[]){v_path_2411, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    v_x_2420 = heff_tag_at_n(v_ru_24x_2418_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2419})});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, v_hd_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3, 1, 2, (V[]){v_m_241, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_intShow(heff_strLength(heff_dup(v_text_241)));
  V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str1)));
  V v_t_247 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_245), heff_dup(v_text_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1, 1, 4, (V[]){v_text_241, v_path_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_text_241 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    V v_t_2411 = heff_intShow(heff_strLength(v_text_241));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str2), heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str3)));
    V v_t_2414 = heff_tag_n(TAG_Replace, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_2412), v_path_240, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2_clo)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), v_hd_242, v_k_243));
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_text_241);
    heff_drop(v_path_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V v_ps_240, V v_olds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      V v_x2_249 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_m_247), v_olds_241));
      V v_t_2411;
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str0);
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
      V v_c_2417;
      if (heff_strEq_c(heff_dup(v_text_248), v_t_2411)) {
        v_c_2417 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1_clo);
      } else {
        V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
        V v_t_2416 = (g_heff_2ebuild_2eload_2eunder(heff_dup(v_ps_240), v_t_2415, heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str1))));
        v_c_2417 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo), 2, (V[]){v_t_2416, heff_dup(v_text_248)}));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2, 2, 4, (V[]){v_c_2417, v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2420);
  V v_t_2421 = ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a_0, a_1, a_2)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2418;
  heff_room[1] = v_k_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_olds_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3, 1, 5, (V[]){v_ps_240, v_olds_241, v_rest_246, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442(V v_bi_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_c_246, V v_available_247, V v_z_248, V v_z_249) {
top: ;
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam0, 1, 1, (V[]){heff_dup(v_c_246)}), heff_dup(heff_rfield(v_c_246, 7))));
  V v_t_2415 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2414));
  V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2416));
  V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam1, 1, 1, (V[]){heff_dup(v_available_247)}), v_t_2417));
  V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = heff_dup(v_c_246); V a_2 = v_name_243; V r_ = (g_heff_2ebuild_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Left: {
    V v_why_2421 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Left = heff_take_reuse_n(v_t_2420, 1ULL, 1);
    heff_drop(v_bi_240);
    heff_drop(v_host_241);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    heff_drop_rec(v_c_246, 13);
    V v_t_2422 = heff_strAppend(v_file_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_str0), v_why_2421));
    V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_str1), v_t_2422), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_str2));
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_at_n(v_ru_24t_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s954557541x749476273(v_t_2427, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam2, 1, 2, (V[]){v_z_248, v_z_249})));
  }
  case TAG_Right: {
    V v_r_2433 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 1);
    heff_drop(v_file_242);
    return (g_heff_2ebuild_2ecommands_2ejsKept_24s1722279445x1592094726(v_bi_240, v_host_241, v_outPath_244, v_done_245, v_c_246, v_available_247, v_r_2433, v_z_248, v_z_249));
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam0(V self, V *args) {
  V v_o_2410 = args[0];
  V v_c_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_246, heff_dup(heff_rfield(v_o_2410, 1))));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_2410, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2412 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 1ULL, 1);
    V v_t_2413 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2410, 0), heff_get_n(v_o_2410, 1, 2), v_eff_2412});
    return heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam1(V self, V *args) {
  V v_k_2418 = args[0];
  V v_available_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_247; V a_1 = v_k_2418; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_247); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1483112971x1417366442_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s954557541x749476273(v_t_2432, v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 4, 10);
    V v_t_2411 = (g_heff_2elsp_2ereport_2emismatch(v_color_241, v_t_249, v_t_2410));
    V v_str_2412 = (g_heff_2ebuild_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1, 2, 4, (V[]){v_str_2412, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_color_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2419);
  V v_t_2420 = ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(a_0, a_1, a_2)); heff_drop(v_color_241); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam2, 1, 5, (V[]){v_f_240, v_color_241, v_rest_246, v_hd_2413, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str0, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str1, 5, "  0/0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str3, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str4, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str5, 13, ": not checked");
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(V v_seed_240, V v_f_241, V v_loadErrs_242, V v_cs_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = (g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(v_cs_243));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0, 1, 6, (V[]){heff_dup(v_cs_243), v_f_241, v_z_244, v_loadErrs_242, v_z_245, v_seed_240})});
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_loadErrs_242 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_why_2419;
  switch (heff_tag_of(v_loadErrs_242)) {
  case TAG_Nil: {
    V v_x2_2415 = ({ V a_0 = v_cs_243; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_243); r_; });
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nothing: {
      v_why_2419 = heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str3));
      break;
    }
    case TAG_Just: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      heff_take_n(v_x2_2415, 1ULL, 1);
      heff_drop(v_f_241);
      v_why_2419 = v_x_2416;
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2417 = heff_field(v_loadErrs_242, 0);
    heff_take_n(v_loadErrs_242, 1ULL, 2);
    heff_drop(v_cs_243);
    heff_drop(v_f_241);
    v_why_2419 = v_why_2417;
    break;
  }
  default: heff_nomatch(v_loadErrs_242);
  }
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
  V f_ = v_z_245;
  args[0] = heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2420, MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2(V self, V *args) {
  V v_w_2438 = args[0];
  V v_c_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2421, v_w_2438));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_loadErrs_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_seed_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_243));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    heff_drop(v_seed_240);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str0), heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str1)));
    V v_t_2410 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str2)), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(v_t_2413, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1, 1, 4, (V[]){v_loadErrs_242, v_cs_243, v_f_241, v_z_245})));
  }
  case TAG_Just: {
    V v_c_2421 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_t_2435;
    switch (heff_tag_of(v_loadErrs_242)) {
    case TAG_Nil: {
      if (heff_intEq_c(heff_dup(v_x_247), MK_INT(0LL))) {
        heff_drop(v_cs_243);
        v_t_2435 = NTAG(TAG_Nil);
      } else {
        V v_t_2427;
        switch (heff_tag_of(v_loadErrs_242)) {
        case TAG_Nil: {
          V v_x2_2423 = ({ V a_0 = v_cs_243; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_243); r_; });
          switch (heff_tag_of(v_x2_2423)) {
          case TAG_Nothing: {
            v_t_2427 = heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str4));
            break;
          }
          case TAG_Just: {
            V v_x_2424 = heff_field(v_x2_2423, 0);
            heff_take_n(v_x2_2423, 1ULL, 1);
            v_t_2427 = v_x_2424;
            break;
          }
          default: heff_nomatch(v_x2_2423);
          }
          break;
        }
        case TAG_Cons: {
          V v_why_2425 = heff_dup(heff_field(v_loadErrs_242, 0));
          heff_drop(v_cs_243);
          v_t_2427 = v_why_2425;
          break;
        }
        default: heff_nomatch(v_loadErrs_242);
        }
        v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      }
      break;
    }
    case TAG_Cons: {
      V v_t_2434;
      switch (heff_tag_of(v_loadErrs_242)) {
      case TAG_Nil: {
        V v_x2_2430 = ({ V a_0 = v_cs_243; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_243); r_; });
        switch (heff_tag_of(v_x2_2430)) {
        case TAG_Nothing: {
          v_t_2434 = heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str5));
          break;
        }
        case TAG_Just: {
          V v_x_2431 = heff_field(v_x2_2430, 0);
          heff_take_n(v_x2_2430, 1ULL, 1);
          v_t_2434 = v_x_2431;
          break;
        }
        default: heff_nomatch(v_x2_2430);
        }
        break;
      }
      case TAG_Cons: {
        V v_why_2432 = heff_dup(heff_field(v_loadErrs_242, 0));
        heff_drop(v_cs_243);
        v_t_2434 = v_why_2432;
        break;
      }
      default: heff_nomatch(v_loadErrs_242);
      }
      v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_loadErrs_242);
    }
    V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_c_2421, 5)), 4, 9);
    V v_t_2437 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2421), v_t_2436));
    V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2, 1, 1, (V[]){heff_dup(v_c_2421)}), v_t_2437));
    V v_t_2440 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2439));
    V v_t_2444;
    switch (heff_tag_of(v_loadErrs_242)) {
    case TAG_Nil: {
      if (heff_intEq_c(v_x_247, MK_INT(0LL))) {
        v_t_2444 = (g_heff_2ebuild_2edriver_2erunTests(v_seed_240, v_c_2421));
      } else {
        heff_drop(v_seed_240);
        heff_drop_rec(v_c_2421, 13);
        v_t_2444 = NTAG(TAG_Nil);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_loadErrs_242, 0ULL, 2);
      heff_drop(v_x_247);
      heff_drop(v_seed_240);
      heff_drop_rec(v_c_2421, 13);
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_loadErrs_242);
    }
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(v_f_241, v_t_2435, v_t_2440, v_t_2444, v_z_244, v_z_245));
  }
  default: return heff_nomatch(v_t_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(V v_file_240, V v_outPath_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_outPath_241});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_file_240; V a_1 = v_outPath_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_246); V a_3 = heff_get_n(v_x_248, 0, 2); V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(v_file_240); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3, 1, 5, (V[]){v_file_240, v_outPath_241, v_x_246, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_file_240, v_outPath_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1, 1, 4, (V[]){v_hd_243, v_file_240, v_outPath_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(V v_bi_240, V v_dir_241, V v_runtime_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_runtime_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_p_2417 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_dup(heff_field(v_p_2417, 0));
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_text_2423;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2422 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_text_2423 = v_y_2422;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2ebackD_clo), 1, (V[]){v_x_249}));
  V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2ewhole_clo), 1, (V[]){v_t_2424}));
  V v_x2_2426 = (g_heff_2ebuild_2edecoder_2erun(v_t_2425, v_text_2423));
  V v_t_2428;
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Nothing: {
    v_t_2428 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    break;
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    heff_take_n(v_x2_2426, 1ULL, 1);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x2_2426);
  }
  return (g_map_2einsert_24s1341440536x470972936(v_t_2420, v_t_2428, v_m_2416));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_runtime_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2429 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam3, 2, 1, (V[]){heff_dup(v_x_249)}), heff_dup(g_map_2eempty_get()), v_x_2415));
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_runtime_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2415; V a_9 = v_t_2429; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_runtime_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c(heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str0))) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_runtime_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str0, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_242)));
  V v_t_2413;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Left: {
    V v_why_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Left = heff_take_reuse_n(v_t_246, 1ULL, 1);
    v_t_2413 = heff_tag_at_n(v_ru_24t_246_24Left, TAG_Left, 1, (V[]){v_why_247});
    break;
  }
  case TAG_Right: {
    V v_out_248 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2410 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_249));
    V v_t_2411 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_248), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2412 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2411));
    v_t_2413 = (g_heff_2esyntax_2eformat_2esameMeaning(heff_dup(v_src_242), v_out_248, v_t_2410, v_t_2412));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Left: {
    V v_why_2414 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Left = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    heff_drop(v_src_242);
    V v_t_2415 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str0), v_why_2414));
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str1), v_t_2415), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str2));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24t_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s954557541x749476273(v_t_2420, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0, 1, 1, (V[]){v_z_245})));
  }
  case TAG_Right: {
    V v_out_2422 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Right = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_out_2422), v_src_242)) {
      heff_drop(v_f_241);
      heff_drop(v_z_244);
      heff_drop(v_out_2422);
      heff_drop_cell(v_ru_24t_2413_24Right, 1);
      return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
    } else {
      if ((heff_dup(v_checkOnly_240) == NTAG(TAG_True))) {
        heff_drop(v_out_2422);
        V v_t_2424 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str3)), NTAG(TAG_MkUnit)});
        V v_t_2425 = heff_tag_at_n(v_ru_24t_2413_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        return (g_co_2eop_24s954557541x749476273(v_t_2427, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1, 1, 1, (V[]){v_z_245})));
      } else {
        V v_t_2430 = heff_tag_at_n(v_ru_24t_2413_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2422, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2_clo)})});
        V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
        return (g_co_2eop_24s954557541x749476273(v_t_2432, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3, 1, 1, (V[]){v_z_245})));
      }
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2428);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2(V self, V *args) {
  V v_ok_2429 = args[0];
  return v_ok_2429;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  V f_ = v_z_245;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(v_checkOnly_240, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0, 1, 5, (V[]){heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_247); V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str4, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str5, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_n_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_243, heff_dup(v_n_245), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_n_245, v_hd_246, v_t_241, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4(V self, V *args) {
  V v_ok_2430 = args[0];
  return v_ok_2430;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6(V self, V *args) {
  V v_ok_2441 = args[0];
  return v_ok_2441;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8(V self, V *args) {
  V v_ok_2452 = args[0];
  return v_ok_2452;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10(V self, V *args) {
  V v_ok_2463 = args[0];
  return v_ok_2463;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13(V self, V *args) {
  V v_x_2477 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2474 = heff_env(self)[1];
  V v_k_2475 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2477);
  V f_ = v_next_244;
  heff_room[0] = v_hd_2474;
  heff_room[1] = v_k_2475;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_x_2410 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476 = heff_tag_n(TAG_End, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2476}), heff_dup(v_hd_2474), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13, 1, 3, (V[]){v_next_244, v_hd_2474, v_k_2475})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11(V self, V *args) {
  V v_x_2467 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  V v_x_2410 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2468 = (g_std_2epath_2eparse(v_st_240, v_home_242));
  V v_t_2469 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_2470 = (g_std_2epath_2ejoin_2eonto_240(v_t_2468, v_t_2469));
  V v_t_2471 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2470, 1)), heff_rfield(v_p_2470, 2)));
  V v_t_2472 = ({ V rv_2 = v_t_2471; V rr_ = heff_rec_reuse_nf(v_p_2470, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2473 = ({ V a_0 = v_st_240; V a_1 = v_t_2472; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  return ({ V a_0 = v_t_241; V a_1 = v_x_2417; V a_2 = v_x_2424; V a_3 = v_t_2473; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12, 2, 2, (V[]){v_x_2410, v_next_244}); V a_5 = v_x_2467; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2467); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_2424 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2456);
  V v_t_2457 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2458 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2459 = (g_std_2epath_2ejoin_2eonto_240(v_t_2457, v_t_2458));
  V v_t_2460 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2459, 1)), heff_rfield(v_p_2459, 2)));
  V v_t_2461 = ({ V rv_2 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_p_2459, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_to_2462 = (g_std_2epath_2erender(v_st_240, v_t_2461));
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){heff_dup(v_x_2417), v_to_2462, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10_clo)})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  return (g_co_2eop_24s954557541x749476273(v_t_2466, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_t_241, v_x_2417, v_x_2424, v_x_2410, v_next_244, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14(V self, V *args) {
  V v_ok_2478 = args[0];
  return v_ok_2478;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16(V self, V *args) {
  V v_x_2496 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2496);
  V v_t_2497 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  return (g_co_2eop_24s954557541x749476273(v_t_24100, v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15(V self, V *args) {
  V v_x_2482 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2482);
  V v_t_2483 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2484 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_2485 = (g_std_2epath_2ejoin_2eonto_240(v_t_2483, v_t_2484));
  V v_t_2486 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2485, 1)), heff_rfield(v_p_2485, 2)));
  V v_t_2487 = ({ V rv_2 = v_t_2486; V rr_ = heff_rec_reuse_nf(v_p_2485, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2488 = ({ V a_0 = v_st_240; V a_1 = v_t_2487; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_2489 = heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str4), v_x_2417));
  V v_why_2490 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str5), v_t_2489);
  V v_t_2491 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str6), v_why_2490), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str7));
  V v_t_2492 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2491, NTAG(TAG_MkUnit)});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s954557541x749476273(v_t_2495, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_t_241 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
    heff_drop(v_x_2445);
    V v_t_2446 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
    V v_t_2447 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
    V v_t_2449 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2448, 1)), heff_rfield(v_p_2448, 2)));
    V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_p_2448, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_path_2451 = (g_std_2epath_2erender(v_st_240, v_t_2450));
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_path_2451, heff_dup(v_x_2424), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8_clo)})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    return (g_co_2eop_24s954557541x749476273(v_t_2455, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2417, v_hd_246, v_t_241, v_x_2424, v_x_2410, v_next_244, v_k_247})));
  } else {
    heff_drop(v_x_2445);
    heff_drop(v_home_242);
    heff_drop(v_x_2424);
    heff_drop(v_x_2410);
    heff_drop(v_next_244);
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2417), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14_clo)})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    return (g_co_2eop_24s954557541x749476273(v_t_2481, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15, 1, 6, (V[]){v_st_240, v_t_241, v_n_245, v_x_2417, v_hd_246, v_k_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_home_242 = heff_env(self)[5];
  V v_x_2424 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2434);
  V v_t_2435 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2436 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2437 = (g_std_2epath_2ejoin_2eonto_240(v_t_2435, v_t_2436));
  V v_t_2438 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2437, 1)), heff_rfield(v_p_2437, 2)));
  V v_t_2439 = ({ V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_p_2437, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2440 = (g_std_2epath_2erender(v_st_240, v_t_2439));
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2440, heff_dup(v_x_2417), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s954557541x749476273(v_t_2444, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2424, v_hd_246, v_x_2417, v_t_241, v_x_2410, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_home_242 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2429);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2424), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s954557541x749476273(v_t_2433, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5, 1, 10, (V[]){v_st_240, v_t_241, v_n_245, v_x_2417, v_hd_246, v_home_242, v_x_2424, v_x_2410, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str0), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str1)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, v_t_2412));
  V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2413));
  V v_t_2415 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2414, 1)), heff_rfield(v_p_2414, 2)));
  V v_t_2416 = ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_p_2414, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str2), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str3)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_240, v_t_2419));
  V v_p_2421 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2420));
  V v_t_2422 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2421, 1)), heff_rfield(v_p_2421, 2)));
  V v_t_2423 = ({ V rv_2 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_p_2421, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2424 = (g_std_2epath_2erender(v_st_240, v_t_2423));
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2417), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3, 1, 10, (V[]){v_x_2424, v_hd_246, v_st_240, v_t_241, v_n_245, v_x_2417, v_home_242, v_x_2410, v_next_244, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(V v_st_240, V v_t_241, V v_progs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_242);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0_clo);
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_242)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_total_249 = (g_list_2efoldl_24f1717515461x1947736435(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_248));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1, 2, 5, (V[]){v_home_246, v_total_249, v_progs_242, v_st_240, v_t_241});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  heff_drop(v_a_244);
  V f_ = v_a_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_2419;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2420}), v_hd_2418, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5, 1, 1, (V[]){v_k_2419})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_246 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_242));
  V v_xs_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2416));
  V v_t_2422 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_246; V a_3 = heff_dup(v_x_2414); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4, 2, 1, (V[]){v_x_2414}); V a_5 = v_t_2417; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2417); r_; });
  V f_ = v_t_2422;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_home_246 = heff_env(self)[0];
  V v_total_249 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_str0), heff_dup(v_home_246)), v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2_clo)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2413}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3, 1, 6, (V[]){v_progs_242, v_st_240, v_t_241, v_home_246, v_hd_2410, v_k_2411})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str4, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str5, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_244);
    V v_t_248 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_242, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_248}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
  }
  case TAG_Just: {
    V v_n_2410 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2412 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_242, heff_dup(v_n_2410), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2, 1, 7, (V[]){heff_dup(v_st_240), v_t_241, v_n_2410, v_p_246, v_x_244, v_next_243, v_p_247})));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3(V self, V *args) {
  V v_ok_2421 = args[0];
  return v_ok_2421;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7(V self, V *args) {
  V v_ok_2438 = args[0];
  return v_ok_2438;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11(V self, V *args) {
  V v_x_2459 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2459);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2458}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12(V self, V *args) {
  V v_ok_2460 = args[0];
  return v_ok_2460;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14(V self, V *args) {
  V v_x_2479 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2479);
  V v_t_2480 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  return (g_co_2eop_24s954557541x749476273(v_t_2483, v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13(V self, V *args) {
  V v_x_2464 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_n_2410 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2464);
  V v_t_2465 = (g_heff_2ebuild_2ecommands_2ebuiltAt(v_st_240, heff_dup(v_t_241), v_x_244, heff_dup(v_n_2410)));
  V v_t_2466 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 1, 6)));
  V v_t_2467 = (g_std_2epath_2eparse(v_st_240, v_n_2410));
  V v_p_2468 = (g_std_2epath_2ejoin_2eonto_240(v_t_2466, v_t_2467));
  V v_t_2469 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2468, 1)), heff_rfield(v_p_2468, 2)));
  V v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_p_2468, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2471 = ({ V a_0 = v_st_240; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_2472 = heff_strAppend(v_t_2465, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str4), v_t_2471));
  V v_why_2473 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str5), v_t_2472);
  V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str6), v_why_2473), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str7));
  V v_t_2475 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2474, NTAG(TAG_MkUnit)});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s954557541x749476273(v_t_2478, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14, 1, 2, (V[]){v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_x_2420 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
    heff_drop(v_x_2445);
    heff_drop(v_x_2420);
    heff_drop(v_x_244);
    V v_t_2446 = (g_std_2epath_2eparse(v_st_240, heff_take_field(v_t_241, 1)));
    V v_t_2447 = (g_std_2epath_2eparse(v_st_240, v_n_2410));
    V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
    V v_t_2449 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2448, 1)), heff_rfield(v_p_2448, 2)));
    V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_p_2448, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_path_2451 = ({ V a_0 = v_st_240; V a_1 = v_t_2450; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
    V v_t_2452 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str2), v_path_2451));
    V v_t_2453 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2452, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str3)), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    return (g_co_2eop_24s954557541x749476273(v_t_2456, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10, 1, 4, (V[]){v_x_2413, v_p_246, v_next_243, v_p_247})));
  } else {
    heff_drop(v_x_2445);
    heff_drop(v_x_2413);
    heff_drop(v_next_243);
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_2420, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12_clo)})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    return (g_co_2eop_24s954557541x749476273(v_t_2463, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13, 1, 6, (V[]){v_st_240, v_t_241, v_x_244, v_n_2410, v_p_246, v_p_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_next_243 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2444;
  if ((heff_dup(v_x_2431) == NTAG(TAG_True))) {
    heff_drop(v_x_2431);
    V v_t_2432 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 1))));
    V v_t_2433 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_2410)));
    V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
    V v_t_2435 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2434, 1)), heff_rfield(v_p_2434, 2)));
    V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_p_2434, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_to_2437 = (g_std_2epath_2erender(v_st_240, v_t_2436));
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Replace, 3, (V[]){heff_dup(v_x_2420), v_to_2437, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7_clo)})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    v_c_2444 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2441}));
  } else {
    heff_drop(v_x_2431);
    v_c_2444 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8_clo);
  }
  V f_ = v_c_2444;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9, 1, 9, (V[]){v_st_240, v_t_241, v_n_2410, v_p_246, v_x_2413, v_next_243, v_p_247, v_x_2420, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_n_2410 = heff_env(self)[3];
  V v_x_2420 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_next_243 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2425);
  V v_path_2426 = (g_heff_2ebuild_2ecommands_2ebuiltAt(v_st_240, heff_dup(v_t_241), heff_dup(v_x_244), heff_dup(v_n_2410)));
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2426, heff_dup(v_x_2420), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5_clo)})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s954557541x749476273(v_t_2430, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6, 1, 9, (V[]){v_st_240, v_t_241, v_n_2410, v_x_2420, v_p_246, v_x_2413, v_next_243, v_p_247, v_x_244})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 1))));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str0), heff_strAppend(heff_dup(v_n_2410), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str1)));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, v_t_2415));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2414, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_p_2417, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2420 = (g_std_2epath_2erender(v_st_240, v_t_2419));
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2420), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4, 1, 9, (V[]){v_st_240, v_t_241, v_x_244, v_n_2410, v_x_2420, v_p_246, v_x_2413, v_next_243, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str1, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str2, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_pl_242);
    return v_next_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_pl_242), v_next_243, v_rest_246));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_a_245, 1)), 0, 3);
    V v_t_2414;
    if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str0))) {
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_245, 0))});
    } else {
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_a_245, 1)), 0, 3);
      if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str1))) {
        v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_245, 0))});
      } else {
        V v_t_2412 = heff_dup(heff_rfield(v_t_241, 3));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_t_2413 = heff_strAppend(heff_dup(heff_rfield(v_a_245, 0)), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str2));
          v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
        } else {
          heff_drop(v_t_2412);
          v_t_2414 = NTAG(TAG_Nothing);
        }
      }
    }
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo), 6, (V[]){v_st_240, v_t_241, v_pl_242, v_t_247, heff_dup(heff_rfield(v_a_245, 0)), v_t_2414});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(V v_st_240, V v_t_241, V v_next_242, V v_progs_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_MkDir, 2, (V[]){heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1, 1, 6, (V[]){heff_dup(v_progs_243), v_t_241, v_hd_244, v_st_240, v_next_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_next_242 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V f_ = v_next_242;
  heff_room[0] = v_hd_2416;
  heff_room[1] = v_k_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_next_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2418}), heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5, 1, 3, (V[]){v_next_242, v_hd_2416, v_k_2417})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_next_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2415); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4, 2, 2, (V[]){v_x_2415, v_next_242}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_next_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2410);
  V v_total_2411 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_str0), heff_dup(heff_rfield(v_t_241, 1)));
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2412, v_total_2411, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_next_242, v_progs_243, v_hd_244, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str2, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str4, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(v_t_245, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s954557541x749476273(v_t_2422, v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str1))) {
    v_x_2413 = NTAG(TAG_Windows);
  } else {
    v_x_2413 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_x_2413);
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str2), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    heff_take_n(v_x_246, 0ULL, 1);
    V v_t_2424 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str3)));
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str4), v_t_2424, v_hd_240, v_k_241));
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str10, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str12, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str4), v_t_245})});
  HEFF_LAST return g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str5), v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str10), v_v_240));
    V v_t_2412 = heff_strAppend(heff_get_n(v_pk_241, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str11), v_t_2411));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str12), v_t_2412), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str13));
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s954557541x749476273(v_t_2417, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_why_2418 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str14), v_why_2418), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str15));
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(v_t_2423, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s954557541x749476273(v_t_2439, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str8), v_t_248})});
    return (g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str9), v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2429 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str16), v_why_2429), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str17));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s954557541x749476273(v_t_2434, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str5, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(V v_v_240, V v_l_241, V v_pk_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch(heff_dup(heff_rfield(v_pk_242, 0)), heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_st_246 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 0, 6);
    V v_t_248 = (g_std_2epath_2eparse(v_st_246, v_t_247));
    V v_t_249 = (g_std_2epath_2eparse(v_st_246, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str0)));
    V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
    V v_t_2411 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2410, 1)), heff_rfield(v_p_2410, 2)));
    V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_p_2410, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2413 = ({ V a_0 = v_st_246; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); r_; });
    return (g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(heff_dup(heff_rfield(v_l_241, 2)), v_t_2413, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0, 1, 5, (V[]){v_z_243, v_z_244, v_l_241, v_v_240, v_pk_242})));
  }
  case TAG_Just: {
    V v_why_2435 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_l_241, 5);
    V v_t_2436 = heff_strAppend(heff_get_n(v_pk_242, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str4), v_why_2435));
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str5), v_t_2436), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str6));
    V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s954557541x749476273(v_t_2441, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s954557541x749476273(v_t_2425, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_242, 4);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str1), v_why_2415), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str2));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_st_2427 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    V v_t_2428 = heff_get_n(heff_get_n(v_l_241, 2, 5), 0, 6);
    V v_t_2429 = (g_std_2epath_2eparse(v_st_2427, v_t_2428));
    V v_t_2430 = (g_std_2epath_2eparse(v_st_2427, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str3)));
    V v_p_2431 = (g_std_2epath_2ejoin_2eonto_240(v_t_2429, v_t_2430));
    V v_t_2432 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2431, 1)), heff_rfield(v_p_2431, 2)));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_p_2431, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2434 = ({ V a_0 = v_st_2427; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); r_; });
    return (g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(v_v_240, v_pk_242, v_t_2434, v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2(V self, V *args) {
  V v_x_2442 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2442);
  V v_t_2443 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s954557541x749476273(v_t_2446, v_z_243, v_z_244));
}