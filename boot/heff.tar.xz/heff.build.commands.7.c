// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Move 53768
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_backend 2032133329
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_code 9554612
#define LBL_diff 9578700
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_got 312070
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_opt 319789
#define LBL_owner 307523277
#define LBL_pages 307784670
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_value 313331083
#define LBL_watch 314261737
#define LBL_watches 1357821955
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s1516699062x983575957(V, V, V, V, V, V, V);
V g_co_2eop_24s1516699062x983575957_entry(V self, V *a);
extern Clo g_co_2eop_24s1516699062x983575957_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_clo;
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_clo;
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118(V, V);
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erunTests(V, V);
V g_heff_2ebuild_2edriver_2erunTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erunTests_clo;
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_24cpr(V, V);
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
HeffT2 g_list_2efind_24s1250280863x1570195177_24cpr(V, V);
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1819215186x476901667(V, V, V, V);
V g_list_2emap_24f1819215186x476901667_entry(V self, V *a);
extern Clo g_list_2emap_24f1819215186x476901667_clo;
V g_list_2emap_24s131934541x153143574(V, V, V, V, V, V);
V g_list_2emap_24s131934541x153143574_entry(V self, V *a);
extern Clo g_list_2emap_24s131934541x153143574_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_text_241, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(heff_dup(v_text_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str0, 89, "` is the system's (lib/std/), for C: it imports an effect with no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str1, 2, "` ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str2, 19, "` is that effect: `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachingRefused_str4, 1, "`");
Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereachingRefused_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereachingRefused(V v_host_240, V v_s_241, V v_path_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str0), v_host_240));
  V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_242)));
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    v_t_247 = heff_dup(heff_rfield(v_s_241, 0));
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = (g_heff_2ebuild_2ecommands_2eimportsOn(v_path_242));
  V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str1), v_t_248));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str2), v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str3), v_t_2410)});
  return heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_241, 0, 7), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereachingRefused_str4), v_t_243), v_t_2411});
}
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereachingRefused(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0, 0, "");
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V v_sources_240, V v_only_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    heff_drop(v_seen_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_244)));
    V v_m_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_m_249 = ((V)&g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_m_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = (g_list_2eany_24s2065989517x1307020881(heff_dup(v_m_249), v_seen_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_path_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_m_249);
      heff_drop(v_t_2410);
      V t_0 = v_sources_240;
      V t_1 = v_only_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_sources_240 = t_0;
      v_only_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2411 = (g_list_2eany_24s2065989517x1307020881(heff_dup(v_m_249), v_only_241));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_sources_240);
        heff_drop(v_seen_242);
        heff_drop(v_rest_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_m_249);
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_path_244}});
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_list_2efind_24s1250280863x1570195177_24cpr(heff_dup(v_m_249), heff_dup(v_sources_240)));
        V v_t_2421;
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_x_2416, 5), heff_take_field(v_x_2416, 3)));
            V v_t_2418 = ({ V b_0 = heff_get_n(v_x_2416, 4, 7); V a_1 = v_t_2417; V r_ = (g_heff_2esyntax_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
            V v_imps_2419 = heff_get_n(v_t_2418, 0, 3);
            V v_t_2420 = (g_list_2emap_24s1817208647x1282894070(v_imps_2419));
            v_t_2421 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2420));
          } else {
            heff_drop(v_field_2414);
            v_t_2421 = NTAG(TAG_Nil);
          }
        }
        V v_t_2424 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0, 1, 1, (V[]){v_path_244}), v_t_2421));
        V t_0 = v_sources_240;
        V t_1 = v_only_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_m_249, v_seen_242});
        V t_3 = v_t_2424;
        v_sources_240 = t_0;
        v_only_241 = t_1;
        v_seen_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereachOnly_24cpr_lam0(V self, V *args) {
  V v_i_2422 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_2422, NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_path_244, v_t_2423));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0), heff_dup(v_k_241), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1), v_k_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4), heff_dup(v_k_241), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), v_k_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_text_2412 = heff_dup(heff_rfield(v_p_242, 1));
      V v_t_2413 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6), heff_dup(v_text_2412), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str7), v_text_2412, MK_INT(0LL)), NTAG(TAG_Nil)));
      V v_t_2414 = (g_list_2emap_24s131934541x153143574(MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str8), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str9), MK_INT(23LL), MK_INT(23LL), v_t_2413));
      V v_t_2415 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2415); r_; });
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2ebuild_2ecommands_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eexpectedRes_st;
static V g_heff_2ebuild_2ecommands_2eexpectedRes_init(void) {
  return heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eexpectedRes_st)) return g_heff_2ebuild_2ecommands_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eexpectedRes_val, &g_heff_2ebuild_2ecommands_2eexpectedRes_st, g_heff_2ebuild_2ecommands_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str2, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str3, 12, "\012  diff     ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str4, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str5, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str8, 5, "FAIL ");
Clo g_heff_2ebuild_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_intShow(heff_take_field(v_r_241, 1));
  V v_t_244 = heff_take_field(v_r_241, 0);
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str1), heff_strAppend(v_n_245, ((V)&g_heff_2ebuild_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_247 = heff_get_n(heff_get_n(v_r_241, 2, 3), 2, 10);
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str3), heff_take_field(v_m_242, 2));
  V v_t_249 = heff_strAppend(heff_take_field(v_m_242, 1), v_t_248);
  V v_t_2410 = heff_strAppend(heff_get_n(v_m_242, 0, 3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str4), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str5), v_t_2410));
  V v_t_2412 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str6), v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str7), heff_strAppend(v_t_243, v_t_2412));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str8), heff_strAppend(v_f_240, v_t_2413));
}
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efailLine(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str0, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str1, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str2, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str4, 17, "package : Package");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str6, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str10, 6, ".heff/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str11, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str12, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str13, 18, "-- `heff test src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str14, 14, "/greeting.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str16, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str17, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str18, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str19, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str21, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str22, 59, "-- checks them all, and this one's doc tests are checked by");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str24, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str25, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str26, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str27, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str28, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str29, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str30, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str32, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str33, 64, "  unit \"greeting\" (assertEqual (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str35, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str36, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str37, 66, "-- of type `Test` (lib/check.hf), after the watches and doc tests.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str39, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str40, 69, "-- `heff test` runs the tests of every file of test/: the definitions");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str41, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str42, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str43, 10, "package.hf");
Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str0), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str2), heff_strAppend(heff_dup(v_name_240), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str5); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str6); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str7), v_t_245}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str8), NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str10); V a_2 = v_t_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str11), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str12)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str14)));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str15), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str17), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str19), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str20), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str21), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2414})});
  V v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str23); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str24); V a_2 = v_t_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2415, 2); r_; });
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str25), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str26)));
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2eprogramText(heff_dup(v_name_240)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str27), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str28)));
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str29), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str30)));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str31), NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str33), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str34), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str35), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str38), v_t_2424})});
  V v_t_2426 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str39); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str40); V a_2 = v_t_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2425, 2); r_; });
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str41), v_t_2426}), NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, heff_dup(g_heff_2ebuild_2ecommands_2ebuildText_get())}), v_t_2427});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_t_2418}), v_t_2428});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2416}), v_t_2429});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str42), v_t_248}), v_t_2430});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str43), v_t_246}), v_t_2431});
}
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprojectFiles(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2(V self, V *args) {
  V v_v_247 = args[0];
  return v_v_247;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2428;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_2423;
    if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str3))) {
      v_t_2423 = NTAG(TAG_Windows);
    } else {
      v_t_2423 = NTAG(TAG_Posix);
    }
    V v_t_2426;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2416)) {
      case TAG_Nothing: {
        v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2424 = heff_field(v_x_2416, 0);
        heff_take_n(v_x_2416, 1ULL, 1);
        v_t_2426 = v_x_2424;
        break;
      }
      default: heff_nomatch(v_x_2416);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop(v_x_2416);
      v_t_2426 = v_x_2425;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    v_x_2428 = ({ V a_0 = v_t_2423; V a_1 = v_t_2426; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str5); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2427 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    heff_drop(v_x_2421);
    heff_drop(v_x_2411);
    heff_drop(v_x_2416);
    v_x_2428 = v_d_2427;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V f_ = v_k_241;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7, 1, 4, (V[]){v_x_246, v_x_2411, v_x_2416, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5, 1, 4, (V[]){v_hd_240, v_x_246, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3, 1, 3, (V[]){v_hd_240, v_x_246, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_intShow(heff_strLength_lent(v_text_241, 0));
  V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str1)));
  V v_t_247 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_245), heff_dup(v_text_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1, 1, 4, (V[]){v_text_241, v_path_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_text_241 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    V v_t_2411 = heff_intShow(heff_strLength(v_text_241));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str2), heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str3)));
    V v_t_2414 = heff_tag_n(TAG_Replace, 3, (V[]){heff_strAppend(heff_dup(v_path_240), v_t_2412), v_path_240, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2_clo)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), v_hd_242, v_k_243));
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_text_241);
    heff_drop(v_path_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str2, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V v_ps_240, V v_olds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      HeffT2 v_t_249 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_m_247), v_olds_241));
      V v_t_2414;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          v_t_2414 = v_x_2413;
        } else {
          heff_drop(v_field_2411);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str0);
        }
      }
      V v_c_2421;
      if (heff_strEq_c_lent(v_text_248, v_t_2414, 2)) {
        v_c_2421 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1_clo);
      } else {
        V v_d_2418 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str1)));
        V v_d_2419 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2418, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
        V v_t_2420 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2419, heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str2))));
        v_c_2421 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo), 2, (V[]){v_t_2420, heff_dup(v_text_248)}));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2, 2, 4, (V[]){v_c_2421, v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2422 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2424);
  V v_t_2425 = ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a_0, a_1, a_2)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_olds_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3, 1, 5, (V[]){v_ps_240, v_olds_241, v_rest_246, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(V v_bi_240, V v_dir_241, V v_runtime_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_runtime_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_runtime_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(heff_dup(v_x_249), v_x_2415));
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_runtime_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2415; V a_9 = v_t_2416; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_runtime_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_runtime_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 4, 10);
    V v_t_2411 = (g_heff_2elsp_2ereport_2emismatch(v_color_241, v_t_249, v_t_2410));
    V v_str_2412 = (g_heff_2ebuild_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1, 2, 4, (V[]){v_str_2412, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V a_3 = heff_dup(v_hd_2413); V a_4 = v_k_2414; V a_5 = v_t_2418; V a_6 = v_hd_2413; V r_ = (g_co_2eop_24s1516699062x983575957(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_color_241); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str0, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str1, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str3, 5, "  0/0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str5, 13, ": not checked");
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(V v_seed_240, V v_f_241, V v_loadErrs_242, V v_cs_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = (g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(v_cs_243));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0, 1, 6, (V[]){v_cs_243, v_loadErrs_242, v_f_241, v_seed_240, v_z_244, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1(V self, V *args) {
  V v_w_2435 = args[0];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2412, v_w_2435));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2(V self, V *args) {
  V v_x_2447 = args[0];
  V v_loadErrs_242 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2447);
  V v_why_2455;
  switch (heff_tag_of(v_loadErrs_242)) {
  case TAG_Nil: {
    HeffT2 v_t_2448 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_243));
    {
      V v_field_2450 = v_t_2448.f[1];
      int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
      if ((v_tag_2449 == ((int64_t)0ULL))) {
        heff_drop(v_f_241);
        V v_x_2452 = v_field_2450;
        v_why_2455 = v_x_2452;
      } else {
        heff_drop(v_field_2450);
        v_why_2455 = heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str5));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2453 = heff_field(v_loadErrs_242, 0);
    heff_take_n(v_loadErrs_242, 1ULL, 2);
    heff_drop(v_cs_243);
    heff_drop(v_f_241);
    v_why_2455 = v_why_2453;
    break;
  }
  default: heff_nomatch(v_loadErrs_242);
  }
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2455, NTAG(TAG_Nil)});
  V f_ = v_z_245;
  args[0] = heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2456, MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_loadErrs_242 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_seed_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_248 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_243)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_c_2412 = v_field_2410;
      V v_t_2432;
      switch (heff_tag_of(v_loadErrs_242)) {
      case TAG_Nil: {
        if (heff_intEq_c(heff_dup(v_x_247), MK_INT(0LL))) {
          heff_drop(v_cs_243);
          v_t_2432 = NTAG(TAG_Nil);
        } else {
          V v_t_2421;
          switch (heff_tag_of(v_loadErrs_242)) {
          case TAG_Nil: {
            HeffT2 v_t_2414 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_243));
            {
              V v_field_2416 = v_t_2414.f[1];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                V v_x_2418 = v_field_2416;
                v_t_2421 = v_x_2418;
              } else {
                heff_drop(v_field_2416);
                v_t_2421 = heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str0));
              }
            }
            break;
          }
          case TAG_Cons: {
            V v_why_2419 = heff_dup(heff_field(v_loadErrs_242, 0));
            heff_drop(v_cs_243);
            v_t_2421 = v_why_2419;
            break;
          }
          default: heff_nomatch(v_loadErrs_242);
          }
          v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_Cons: {
        V v_t_2431;
        switch (heff_tag_of(v_loadErrs_242)) {
        case TAG_Nil: {
          HeffT2 v_t_2424 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_243));
          {
            V v_field_2426 = v_t_2424.f[1];
            int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
            if ((v_tag_2425 == ((int64_t)0ULL))) {
              V v_x_2428 = v_field_2426;
              v_t_2431 = v_x_2428;
            } else {
              heff_drop(v_field_2426);
              v_t_2431 = heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str1));
            }
          }
          break;
        }
        case TAG_Cons: {
          V v_why_2429 = heff_dup(heff_field(v_loadErrs_242, 0));
          heff_drop(v_cs_243);
          v_t_2431 = v_why_2429;
          break;
        }
        default: heff_nomatch(v_loadErrs_242);
        }
        v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_loadErrs_242);
      }
      V v_t_2433 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 4, 9);
      V v_t_2434 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2412), v_t_2433));
      V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1, 1, 1, (V[]){heff_dup(v_c_2412)}), v_t_2434));
      V v_t_2437 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2436));
      V v_t_2441;
      switch (heff_tag_of(v_loadErrs_242)) {
      case TAG_Nil: {
        if (heff_intEq_c(v_x_247, MK_INT(0LL))) {
          v_t_2441 = (g_heff_2ebuild_2edriver_2erunTests(v_seed_240, v_c_2412));
        } else {
          heff_drop(v_seed_240);
          heff_drop_rec(v_c_2412, 13);
          v_t_2441 = NTAG(TAG_Nil);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_loadErrs_242, 0ULL, 2);
        heff_drop(v_x_247);
        heff_drop(v_seed_240);
        heff_drop_rec(v_c_2412, 13);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_loadErrs_242);
      }
      return (g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(v_f_241, v_t_2432, v_t_2437, v_t_2441, v_z_244, v_z_245));
    } else {
      heff_drop(v_x_247);
      heff_drop(v_seed_240);
      heff_drop(v_field_2410);
      V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str2), heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str3)));
      V v_t_2443 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str4)), NTAG(TAG_MkUnit)});
      V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      return (g_co_2eop_24s954557541x749476273(v_t_2446, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2, 1, 4, (V[]){v_loadErrs_242, v_cs_243, v_f_241, v_z_245})));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118(V v_host_240, V v_sources_241) {
top: ;
  if (heff_strEq_c_lent(v_host_240, ((V)&g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_str0), 2)) {
    heff_drop(v_host_240);
    V v_x_243 = (g_list_2emap_24f1819215186x476901667(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_str1), ((V)&g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_str2), v_sources_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam0, 2, 1, (V[]){v_x_243});
  } else {
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1457929413x1017691320(heff_dup(v_host_240), heff_dup(v_sources_241)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam1, 2, 3, (V[]){v_c_246, v_host_240, v_sources_241});
  }
}
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_host_240 = heff_env(self)[0];
  V v_sources_241 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = ({ V a_0 = v_host_240; V a_1 = heff_dup(v_sources_241); V a_2 = v_x_249; V a_3 = v_sources_241; V r_ = (g_list_2emap_24s159228909x554161698(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
  V v_x_2411 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2410));
  V f_ = v_k_248;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_sources_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_lam2, 1, 3, (V[]){v_host_240, v_sources_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, heff_dup(v_m_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_246 = v_field_244;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0, 2, 2, (V[]){v_path_246, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2419})});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_248;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_path_246 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
  V v_t_2410 = heff_strSlice(heff_dup(v_path_246), heff_box_word(v_t_249), heff_strLength_lent(v_path_246, 0));
  V v_t_2413;
  if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str0))) {
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
    v_t_2413 = heff_strSlice(v_path_246, MK_INT(0LL), heff_box_word(v_t_2412));
  } else {
    v_t_2413 = v_path_246;
  }
  V v_t_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str1)), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2, 1, 2, (V[]){v_m_241, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(V v_file_240, V v_outPath_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_outPath_241});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_file_240; V a_1 = v_outPath_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_246); V a_3 = heff_get_n(v_x_248, 0, 2); V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(v_file_240); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3, 1, 5, (V[]){v_file_240, v_outPath_241, v_x_246, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_file_240, v_outPath_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1, 1, 4, (V[]){v_hd_243, v_file_240, v_outPath_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str0, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_24cpr(v_fix_243, heff_dup(v_src_242)));
  V v_t_2416;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_why_2410 = v_field_248;
      v_t_2416 = heff_tag_n(TAG_Left, 1, (V[]){v_why_2410});
    } else {
      V v_out_2411 = v_field_248;
      V v_t_2412 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_242), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2412));
      V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_2411), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2415 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2414));
      v_t_2416 = (g_heff_2esyntax_2eformat_2esameMeaning(heff_dup(v_src_242), v_out_2411, v_t_2413, v_t_2415));
    }
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_t_2416, 0);
    V v_ru_24t_2416_24Left = heff_take_reuse_n(v_t_2416, 1ULL, 1);
    heff_drop(v_src_242);
    V v_t_2418 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str0), v_why_2417));
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str1), v_t_2418), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str2));
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_at_n(v_ru_24t_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(v_t_2423, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0, 1, 1, (V[]){v_z_245})));
  }
  case TAG_Right: {
    V v_out_2425 = heff_field(v_t_2416, 0);
    V v_ru_24t_2416_24Right = heff_take_reuse_n(v_t_2416, 1ULL, 1);
    if (heff_strEq_c_lent(v_out_2425, v_src_242, 2)) {
      heff_drop(v_f_241);
      heff_drop(v_z_244);
      heff_drop(v_out_2425);
      heff_drop_cell(v_ru_24t_2416_24Right, 1);
      return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
    } else {
      if ((heff_dup(v_checkOnly_240) == NTAG(TAG_True))) {
        heff_drop(v_out_2425);
        V v_t_2427 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str3)), NTAG(TAG_MkUnit)});
        V v_t_2428 = heff_tag_at_n(v_ru_24t_2416_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        return (g_co_2eop_24s954557541x749476273(v_t_2430, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1, 1, 1, (V[]){v_z_245})));
      } else {
        V v_t_2433 = heff_tag_at_n(v_ru_24t_2416_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2425, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2_clo)})});
        V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
        return (g_co_2eop_24s954557541x749476273(v_t_2435, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3, 1, 1, (V[]){v_z_245})));
      }
    }
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2431);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2436);
  V f_ = v_z_245;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(v_checkOnly_240, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0, 1, 5, (V[]){heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_247); V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str4, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str5, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_n_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_243, heff_dup(v_n_245), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1, 1, 7, (V[]){v_n_245, heff_dup(v_st_240), v_home_242, v_hd_246, v_t_241, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2(V self, V *args) {
  V v_ok_2415 = args[0];
  return v_ok_2415;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4(V self, V *args) {
  V v_ok_2420 = args[0];
  return v_ok_2420;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6(V self, V *args) {
  V v_ok_2426 = args[0];
  return v_ok_2426;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10(V self, V *args) {
  V v_ok_2438 = args[0];
  return v_ok_2438;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13(V self, V *args) {
  V v_x_2447 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2444 = heff_env(self)[1];
  V v_k_2445 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2447);
  V f_ = v_next_244;
  heff_room[0] = v_hd_2444;
  heff_room[1] = v_k_2445;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_x_2410 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tag_n(TAG_End, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2446}), heff_dup(v_hd_2444), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13, 1, 3, (V[]){v_next_244, v_hd_2444, v_k_2445})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_x_2410 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2443 = ({ V a_0 = v_st_240; V a_1 = v_home_242; V a_2 = v_n_245; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  return ({ V a_0 = v_t_241; V a_1 = v_x_2412; V a_2 = v_x_2414; V a_3 = v_t_2443; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12, 2, 2, (V[]){v_x_2410, v_next_244}); V a_5 = v_x_2442; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2442); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_2414 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2436);
  V v_to_2437 = (g_std_2epath_2ejoin(v_st_240, heff_dup(v_home_242), heff_dup(v_n_245)));
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){heff_dup(v_x_2412), v_to_2437, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10_clo)})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s954557541x749476273(v_t_2441, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_t_241, v_x_2412, v_x_2414, v_x_2410, v_next_244, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14(V self, V *args) {
  V v_ok_2448 = args[0];
  return v_ok_2448;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  return (g_co_2eop_24s954557541x749476273(v_t_2465, v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2452);
  V v_t_2453 = ({ V a_0 = v_st_240; V a_1 = heff_get_n(v_t_241, 0, 6); V a_2 = v_n_245; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_2454 = heff_strAppend(v_t_2453, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str4), v_x_2412));
  V v_why_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str5), v_t_2454);
  V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str6), v_why_2455), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str7));
  V v_t_2457 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2456, NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s954557541x749476273(v_t_2460, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_t_241 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  if ((heff_dup(v_x_2430) == NTAG(TAG_True))) {
    heff_drop(v_x_2430);
    V v_path_2431 = (g_std_2epath_2ejoin(v_st_240, heff_dup(v_home_242), heff_dup(v_n_245)));
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_path_2431, heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8_clo)})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s954557541x749476273(v_t_2435, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2412, v_hd_246, v_t_241, v_x_2414, v_x_2410, v_next_244, v_k_247})));
  } else {
    heff_drop(v_x_2430);
    heff_drop(v_home_242);
    heff_drop(v_x_2414);
    heff_drop(v_x_2410);
    heff_drop(v_next_244);
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2412), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14_clo)})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    return (g_co_2eop_24s954557541x749476273(v_t_2451, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15, 1, 6, (V[]){v_st_240, v_t_241, v_n_245, v_x_2412, v_hd_246, v_k_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_home_242 = heff_env(self)[5];
  V v_x_2414 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2424);
  V v_path_2425 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), heff_dup(v_n_245)));
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2425, heff_dup(v_x_2412), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s954557541x749476273(v_t_2429, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2414, v_hd_246, v_x_2412, v_t_241, v_x_2410, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_home_242 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2419);
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s954557541x749476273(v_t_2423, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5, 1, 10, (V[]){v_st_240, v_t_241, v_n_245, v_x_2412, v_hd_246, v_home_242, v_x_2414, v_x_2410, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_home_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str0), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str1)));
  V v_x_2412 = (g_std_2epath_2ejoin(v_st_240, heff_dup(v_home_242), v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str2), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str3)));
  V v_x_2414 = (g_std_2epath_2ejoin(v_st_240, heff_dup(v_home_242), v_t_2413));
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2412), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3, 1, 10, (V[]){v_x_2414, v_hd_246, v_st_240, v_t_241, v_n_245, v_x_2412, v_home_242, v_x_2410, v_next_244, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(V v_st_240, V v_t_241, V v_progs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_242);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0_clo);
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_242)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_total_249 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_248));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1, 2, 5, (V[]){v_home_246, v_total_249, v_progs_242, v_st_240, v_t_241});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  heff_drop(v_a_244);
  V f_ = v_a_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_2419;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2420}), v_hd_2418, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5, 1, 1, (V[]){v_k_2419})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_246 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_242));
  V v_xs_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2416));
  V v_t_2422 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_246; V a_3 = heff_dup(v_x_2414); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4, 2, 1, (V[]){v_x_2414}); V a_5 = v_t_2417; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2417); r_; });
  V f_ = v_t_2422;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_home_246 = heff_env(self)[0];
  V v_total_249 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_str0), heff_dup(v_home_246)), v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2_clo)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2413}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3, 1, 6, (V[]){v_progs_242, v_st_240, v_t_241, v_home_246, v_hd_2410, v_k_2411})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str3, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str6, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str7, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str8, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str9, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str10, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str11, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_244);
    V v_t_248 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_242, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_248}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
  }
  case TAG_Just: {
    V v_n_2410 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2412 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_242, heff_dup(v_n_2410), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2, 1, 7, (V[]){v_n_2410, heff_dup(v_st_240), v_t_241, v_p_246, v_x_244, v_next_243, v_p_247})));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11(V self, V *args) {
  V v_x_2447 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2447);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2446}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12(V self, V *args) {
  V v_ok_2448 = args[0];
  return v_ok_2448;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14(V self, V *args) {
  V v_x_2465 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2465);
  V v_t_2466 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  return (g_co_2eop_24s954557541x749476273(v_t_2469, v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_n_2410 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2452);
  V v_t_2453 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str6), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str7)));
  V v_p_2454 = (g_std_2epath_2ejoin(v_st_240, v_t_2453, v_x_244));
  V v_t_2455 = (g_std_2epath_2ejoin(v_st_240, heff_take_field(v_t_241, 0), v_p_2454));
  V v_t_2456 = (g_std_2epath_2ejoin(v_st_240, v_t_2455, heff_dup(v_n_2410)));
  V v_t_2457 = ({ V a_0 = v_st_240; V a_1 = heff_get_n(v_t_241, 1, 6); V a_2 = v_n_2410; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_2458 = heff_strAppend(v_t_2456, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str8), v_t_2457));
  V v_why_2459 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str9), v_t_2458);
  V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str10), v_why_2459), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str11));
  V v_t_2461 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2460, NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s954557541x749476273(v_t_2464, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14, 1, 2, (V[]){v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_x_2415 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2438) == NTAG(TAG_True))) {
    heff_drop(v_x_2438);
    heff_drop(v_x_2415);
    heff_drop(v_x_244);
    V v_path_2439 = ({ V a_0 = v_st_240; V a_1 = heff_take_field(v_t_241, 1); V a_2 = v_n_2410; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V v_t_2440 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str4), v_path_2439));
    V v_t_2441 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str5)), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s954557541x749476273(v_t_2444, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10, 1, 4, (V[]){v_x_2413, v_p_246, v_next_243, v_p_247})));
  } else {
    heff_drop(v_x_2438);
    heff_drop(v_x_2413);
    heff_drop(v_next_243);
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12_clo)})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    return (g_co_2eop_24s954557541x749476273(v_t_2451, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13, 1, 6, (V[]){v_st_240, v_x_244, v_t_241, v_n_2410, v_p_246, v_p_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_next_243 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2437;
  if ((heff_dup(v_x_2429) == NTAG(TAG_True))) {
    heff_drop(v_x_2429);
    V v_to_2430 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 1)), heff_dup(v_n_2410)));
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Replace, 3, (V[]){heff_dup(v_x_2415), v_to_2430, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7_clo)})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    v_c_2437 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2434}));
  } else {
    heff_drop(v_x_2429);
    v_c_2437 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8_clo);
  }
  V f_ = v_c_2437;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9, 1, 9, (V[]){v_st_240, v_t_241, v_n_2410, v_p_246, v_x_2413, v_next_243, v_p_247, v_x_2415, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_n_2410 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_next_243 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2420);
  V v_t_2421 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str2), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str3)));
  V v_p_2422 = (g_std_2epath_2ejoin(v_st_240, v_t_2421, heff_dup(v_x_244)));
  V v_t_2423 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_2422));
  V v_path_2424 = (g_std_2epath_2ejoin(v_st_240, v_t_2423, heff_dup(v_n_2410)));
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2424, heff_dup(v_x_2415), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6, 1, 9, (V[]){v_st_240, v_t_241, v_n_2410, v_x_2415, v_p_246, v_x_2413, v_next_243, v_p_247, v_x_244})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_n_2410 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str0), heff_strAppend(heff_dup(v_n_2410), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str1)));
  V v_x_2415 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 1)), v_t_2414));
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2415), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4, 1, 9, (V[]){v_st_240, v_x_244, v_t_241, v_n_2410, v_x_2415, v_p_246, v_x_2413, v_next_243, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str1, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_pl_242);
    return v_next_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_pl_242), v_next_243, v_rest_246));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_a_245, 1)), 0, 3);
    V v_t_2412;
    if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str0))) {
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_245, 0))});
    } else {
      V v_t_2410 = heff_dup(heff_rfield(v_t_241, 3));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_t_2411 = heff_strAppend(heff_dup(heff_rfield(v_a_245, 0)), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str1));
        v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
      } else {
        heff_drop(v_t_2410);
        v_t_2412 = NTAG(TAG_Nothing);
      }
    }
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo), 6, (V[]){v_st_240, v_t_241, v_pl_242, v_t_247, heff_dup(heff_rfield(v_a_245, 0)), v_t_2412});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(V v_st_240, V v_t_241, V v_next_242, V v_progs_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_MkDir, 2, (V[]){heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1, 1, 6, (V[]){heff_dup(v_progs_243), v_t_241, v_hd_244, v_st_240, v_next_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_next_242 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V f_ = v_next_242;
  heff_room[0] = v_hd_2416;
  heff_room[1] = v_k_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_next_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2418}), heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5, 1, 3, (V[]){v_next_242, v_hd_2416, v_k_2417})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_next_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2415); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4, 2, 2, (V[]){v_x_2415, v_next_242}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_next_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2410);
  V v_total_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_str0), heff_dup(heff_rfield(v_t_241, 1)));
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2412, v_total_2411, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_next_242, v_progs_243, v_hd_244, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str2, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str4, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str7, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str8, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str9, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(v_t_245, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s954557541x749476273(v_t_2422, v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str1))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_st_2413);
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str2), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    heff_take_n(v_x_246, 0ULL, 1);
    V v_t_2424 = (g_std_2epath_2ejoin(v_st_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str3), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str4)));
    V v_t_2425 = (g_std_2epath_2ejoin(v_st_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str5), v_t_2424));
    V v_t_2426 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str6), v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str7), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str8)});
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(v_st_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str9), v_t_2426, v_hd_240, v_k_241));
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str10, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str12, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str4), v_t_245})});
  HEFF_LAST return g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str5), v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str10), v_v_240));
    V v_t_2412 = heff_strAppend(heff_get_n(v_pk_241, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str11), v_t_2411));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str12), v_t_2412), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str13));
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s954557541x749476273(v_t_2417, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_why_2418 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str14), v_why_2418), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str15));
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(v_t_2423, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s954557541x749476273(v_t_2439, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str8), v_t_248})});
    return (g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str9), v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2429 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str16), v_why_2429), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str17));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s954557541x749476273(v_t_2434, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str6, 3, "src");
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(V v_v_240, V v_l_241, V v_pk_242, V v_z_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(heff_rfield(v_pk_242, 0)), heff_dup(v_v_240)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_v_240);
      heff_drop_rec(v_l_241, 5);
      V v_why_249 = v_field_247;
      V v_t_2410 = heff_strAppend(heff_get_n(v_pk_242, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str0), v_why_249));
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str1), v_t_2410), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str2));
      V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0, 1, 2, (V[]){v_z_243, v_z_244})));
    } else {
      heff_drop(v_field_247);
      V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
      V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 0, 6);
      V v_t_2423 = ({ V a_0 = v_t_2421; V a_1 = v_t_2422; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str3); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
      return (g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(heff_dup(heff_rfield(v_l_241, 2)), v_t_2423, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1, 1, 5, (V[]){v_z_243, v_z_244, v_l_241, v_v_240, v_pk_242})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s954557541x749476273(v_t_2435, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_why_2425 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Left = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_242, 4);
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str4), v_why_2425), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str5));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_at_n(v_ru_24x_2424_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s954557541x749476273(v_t_2430, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    V v_t_2437 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    V v_t_2438 = heff_get_n(heff_get_n(v_l_241, 2, 5), 0, 6);
    V v_t_2439 = ({ V a_0 = v_t_2437; V a_1 = v_t_2438; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str6); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2437); r_; });
    return (g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(v_v_240, v_pk_242, v_t_2439, v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x_2424);
  }
}