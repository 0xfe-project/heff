// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_PathUri 23459
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_docs 9584386
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_uri 325606
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144(V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eany_24s1836353438x580818415(V, V);
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a);
extern Clo g_list_2eany_24s1836353438x580818415_clo;
V g_list_2eany_24s257543591x25063085(V, V);
V g_list_2eany_24s257543591x25063085_entry(V self, V *a);
extern Clo g_list_2eany_24s257543591x25063085_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s198101905x967505038(V, V, V, V);
V g_list_2efoldl_24s198101905x967505038_entry(V self, V *a);
extern Clo g_list_2efoldl_24s198101905x967505038_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str1, 5, "start");
Clo g_heff_2elsp_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_start_242 = heff_take_field(v_sp_241, 0);
  V v_end_243 = heff_get_n(v_sp_241, 1, 2);
  V v_t_244 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_start_242)));
  V v_x_245 = v_start_242;
  V v_y_246 = v_end_243;
  V v_t_247;
  if (heff_intLe_c_lent(v_x_245, v_y_246, 0)) {
    heff_drop(v_x_245);
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = v_x_245;
  }
  V v_t_248 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_247));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str0), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str1), v_t_244}), v_t_249});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410});
}
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2erange(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ecatMaybesL_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str2, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str3, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str4, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str5, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2edeclsGo(V v_x1_240, V v_key_241, V v_above_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_above_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_245 = heff_take_field(v_l_243, 1);
    V v_at_246 = heff_get_n(v_l_243, 0, 2);
    V v_l_247 = heff_dup(v_text_245);
    if ((heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str0)) || heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str1)))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_text_245);
      heff_drop(v_l_247);
      V v_t_249;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_249 = v_at_246;
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop(v_at_246);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_244;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      goto top;
    } else {
      heff_drop(v_l_247);
      V v_l_2410 = heff_dup(v_text_245);
      V v_t_2414;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_2410, 0)))) {
        if (((heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : !(heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)13ULL))))) {
          if ((heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str2)) ? 0 : !heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str3)))) {
            V v_t_2411 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2410, MK_INT(0LL)));
            V v_x1_2413 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), v_t_2411, 2), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str4)) || ({ V v_t_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2410, MK_INT(0LL))); int c_ = ({ V v_t_2427 = heff_strSlice_lent(v_l_2410, MK_INT(0LL), v_t_2412, 2); int c_ = heff_strEq_c_lent(v_t_2427, ((V)&g_heff_2elsp_2elsp_2edeclsGo_str5), 2); heff_drop(v_t_2427); c_; }); heff_drop(v_t_2412); c_; })));
            heff_drop(v_l_2410);
            heff_drop(v_t_2411);
            v_t_2414 = heff_bool(!(heff_dup(v_x1_2413) == NTAG(TAG_True)));
            heff_drop(v_x1_2413);
          } else {
            heff_drop(v_l_2410);
            v_t_2414 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l_2410);
          v_t_2414 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_l_2410);
        v_t_2414 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_heff_2elsp_2elsp_2ekeyOf(v_text_245));
        V v_x1_2416 = heff_bool(heff_strEq_c_lent(v_t_2415, v_key_241, 0));
        heff_drop(v_t_2415);
        if (!(heff_dup(v_x1_2416) == NTAG(TAG_True))) {
          heff_drop(v_x1_2416);
          V v_cut_2418;
          switch (heff_tag_of(v_above_242)) {
          case TAG_Nothing: {
            v_cut_2418 = heff_dup(v_at_246);
            break;
          }
          case TAG_Just: {
            V v_x_2417 = heff_field(v_above_242, 0);
            heff_take_n(v_above_242, 1ULL, 1);
            v_cut_2418 = v_x_2417;
            break;
          }
          default: heff_nomatch(v_above_242);
          }
          V v_n_2419 = v_at_246;
          HeffT2 v_t_2420 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_text_245));
          {
            V v_field_2421 = v_t_2420.f[0];
            V v_field_2422 = v_t_2420.f[1];
            V v_t_2423 = ({ V a_0 = v_text_245; V r_ = (g_heff_2elsp_2elsp_2ekeyOf(a_0)); heff_drop(v_text_245); r_; });
            V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd_lent(v_field_2421, v_n_2419, 1), heff_intAdd(v_field_2422, v_n_2419)});
            V v_cell_2425 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_cut__name, (V[]){v_cut_2418, v_t_2424}), heff_hole()});
            V v_u_2426 = (g_heff_2elsp_2elsp_2edeclsGo_24dps(v_rest_244, v_t_2423, NTAG(TAG_Nothing), v_cell_2425));
            heff_drop(v_u_2426);
            return v_cell_2425;
          }
        } else {
          heff_drop(v_above_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_text_245);
          heff_drop(v_at_246);
          heff_drop(v_x1_2416);
          V t_0 = v_rest_244;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_above_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_text_245);
        heff_drop(v_at_246);
        heff_drop(v_t_2414);
        V t_0 = v_rest_244;
        V t_1 = v_key_241;
        V t_2 = NTAG(TAG_Nothing);
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2edeclsGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str0, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str1, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str2, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str3, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str4, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str5, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str6, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str7, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str9, 8, "children");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str10, 14, "selectionRange");
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_span_242 = heff_take_field(v_y_241, 2);
  V v_selection_243 = heff_take_field(v_y_241, 3);
  V v_children_244 = heff_take_field(v_y_241, 4);
  V v_name_245 = heff_take_field(v_y_241, 0);
  V v_kind_246 = heff_get_n(v_y_241, 1, 5);
  V v_s_247 = heff_take_field(v_span_242, 0);
  V v_x_248 = heff_get_n(v_span_242, 1, 2);
  V v_y_249 = heff_dup(heff_rfield(v_selection_243, 1));
  V v_t_2410;
  if (heff_intLe_c_lent(v_x_248, v_y_249, 0)) {
    heff_drop(v_x_248);
    v_t_2410 = v_y_249;
  } else {
    heff_drop(v_y_249);
    v_t_2410 = v_x_248;
  }
  V v_t_2411 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_s_247)));
  V v_t_2412;
  if (heff_intLe_c_lent(v_s_247, v_t_2410, 0)) {
    heff_drop(v_s_247);
    v_t_2412 = v_t_2410;
  } else {
    heff_drop(v_t_2410);
    v_t_2412 = v_s_247;
  }
  V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_2412));
  V v_t_2414 = (g_heff_2elsp_2elsp_2erange(v_src_240, v_selection_243));
  V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2edocSymbol_lam0, 1, 1, (V[]){v_src_240}), v_children_244));
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str4), heff_tag_n(TAG_JString, 1, (V[]){v_name_245})});
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str5), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_246})});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str6), v_t_2413}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str7), v_t_2411}), v_t_2431});
  V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str8), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str9), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2428})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str10), v_t_2414}), v_t_2435});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2436})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2437})});
}
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocSymbol(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2415 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_src_2416 = v_src_240;
  V v_m_2417 = v_m_2415;
  V v_span_2418 = heff_take_field(v_m_2417, 2);
  V v_name_2419 = heff_take_field(v_m_2417, 0);
  V v_kind_2420 = heff_get_n(v_m_2417, 1, 3);
  V v_t_2421 = (g_heff_2elsp_2elsp_2erange(v_src_2416, heff_dup(v_span_2418)));
  V v_t_2422 = ({ V a_0 = v_src_2416; V a_1 = v_span_2418; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_src_2416); r_; });
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str0), heff_tag_n(TAG_JString, 1, (V[]){v_name_2419})});
  V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_2420})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str2), v_t_2422}), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str3), v_t_2421}), v_t_2425});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2426})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2427});
}
Clo g_heff_2elsp_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244;
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL)))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) + ((int64_t)32ULL));
      v_t_244 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_243))));
    } else {
      v_t_244 = heff_strSlice_lent(v_s_240, v_i_241, heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))), 4);
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elowerGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str0, 31, "Write the module claim `module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str1, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str2, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str4, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str6, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str7, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str9, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str10, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str11, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str12, 11, "isPreferred");
Clo g_heff_2elsp_2elsp_2eclaimAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimAction_entry, 5, 0};

V g_heff_2elsp_2elsp_2eclaimAction(V v_uri_240, V v_src_241, V v_n_242, V v_ds_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_text_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_start_247 = heff_take_field(v_sp_245, 0);
    V v_end_248 = heff_get_n(v_sp_245, 1, 2);
    V v_t_249 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(v_start_247)));
    V v_x_2410 = v_start_247;
    V v_y_2411 = v_end_248;
    V v_t_2412;
    if (heff_intLe_c_lent(v_x_2410, v_y_2411, 0)) {
      heff_drop(v_x_2410);
      v_t_2412 = v_y_2411;
    } else {
      heff_drop(v_y_2411);
      v_t_2412 = v_x_2410;
    }
    V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_2412));
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimAction_str0), v_n_242), ((V)&g_heff_2elsp_2elsp_2eclaimAction_str1));
    V v_t_2415 = heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str2), heff_tag_n(TAG_JString, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str4)})});
    V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_243})});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str6), v_t_2413}), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str7), v_t_249}), v_t_2418});
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str8), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str9), heff_tag_n(TAG_JString, 1, (V[]){v_text_246})});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    V v_t_2423 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str11), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str12), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2430});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2431})});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2432})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclaimAction(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_entry, 5, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167(V v_read_240, V v_lib_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_lam0, 1, 5, (V[]){v_read_240, v_lib_241, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = (g_prelude_2e_2b_2b(heff_get_n(v_x_248, 0, 5), v_x_249));
  V f_ = v_z_244;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_lam1, 1, 2, (V[]){v_x_248, v_z_244}); V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str1, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str3, 36, "` would make heff fail elaborating (");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str4, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str5, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str6, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str7, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str8, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str9, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str10, 60, "` is already a name some of these occurrences would refer to");
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam11(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam11, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam17(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam17, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_entry, 3, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993(V v_st_240, V v_t_241, V v_new_242) {
top: ;
  V v_st_243 = heff_dup(v_st_240);
  V v_t_244 = heff_dup(v_t_241);
  V v_target_245 = heff_take_field(v_t_244, 1);
  V v_name_246 = heff_take_field(v_t_244, 2);
  V v_path_247 = heff_get_n(v_t_244, 0, 4);
  V v_new_248 = heff_dup(v_new_242);
  V v_t_249 = heff_get_n(v_target_245, 2, 3);
  V v_c_2424;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    V v_t_2410 = v_name_246;
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_new_248, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2411})});
    v_c_2424 = (g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(v_st_243, v_path_247, v_t_2412));
    break;
  }
  case TAG_Just: {
    V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 0ULL, 1);
    HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_243, 1), v_path_247));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_name_246);
        heff_drop(v_path_247);
        heff_drop(v_new_248);
        heff_drop_cell(v_ru_24t_249_24Just, 1);
        V v_e_2417 = v_field_2416;
        v_c_2424 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam0, 2, 2, (V[]){v_st_243, v_e_2417});
      } else {
        heff_drop(v_field_2416);
        V v_t_2421 = v_name_246;
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_new_248, NTAG(TAG_Nil)});
        V v_t_2423 = heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2422})});
        v_c_2424 = (g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(v_st_243, v_path_247, v_t_2423));
      }
    }
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam1, 2, 4, (V[]){v_c_2424, v_t_241, v_st_240, v_new_242});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam0(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_st_243 = heff_env(self)[0];
  V v_e_2417 = heff_env(self)[1];
  heff_drop(v_hd_2418);
  heff_clo_take(self, 2);
  V v_t_2420 = heff_rec_n(2, shape_st__program, (V[]){v_st_243, heff_get_n(v_e_2417, 1, 2)});
  V f_ = v_k_2419;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam3(V self, V *args) {
  V v_p_2431 = args[0];
  V v_os_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2432 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2431, v_os_2428));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2431, v_os_2432});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam7(V self, V *args) {
  V v_p_2446 = args[0];
  V v_os_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2447 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2446, v_os_2443));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2446, v_os_2447});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam8(V self, V *args) {
  V v_b_2449 = args[0];
  V v_new_242 = heff_env(self)[0];
  V v_occurrences_2450 = heff_take_field(v_b_2449, 1);
  V v_path_2451 = heff_get_n(v_b_2449, 0, 2);
  V v_os_2452 = v_occurrences_2450;
  V v_t_2455;
  switch (heff_tag_of(v_os_2452)) {
  case TAG_Nil: {
    v_t_2455 = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2453 = heff_dup(heff_field(v_os_2452, 0));
    v_t_2455 = heff_get_n(v_x_2453, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_2452);
  }
  V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_2452));
  heff_clo_take(self, 1);
  V v_t_2457 = ({ V b_0 = MK_INT(0LL); V a_1 = v_new_242; V a_2 = v_t_2455; V a_3 = v_t_2456; V r_ = (g_list_2efoldl_24s198101905x967505038(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2456); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2451, v_t_2457});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam9(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_q_2462 = heff_env(self)[0];
  heff_drop(v_hd_2463);
  V v_t_2467;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_q_2462)) {
  case TAG_MkPair: {
    V v_y_2466 = heff_field(v_q_2462, 1);
    heff_take_n(v_q_2462, 2ULL, 2);
    v_t_2467 = v_y_2466;
    break;
  }
  default: heff_nomatch(v_q_2462);
  }
  V f_ = v_k_2464;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam10(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_d_2471 = heff_env(self)[0];
  heff_drop(v_hd_2472);
  heff_clo_take(self, 1);
  V v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2471, 1, 2)});
  V f_ = v_k_2473;
  args[0] = v_t_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam11(V self, V *args) {
  V v_r_2477 = args[0];
  return v_r_2477;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam13(V self, V *args) {
  V v_x_2486 = args[0];
  V v_k_2480 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Left: {
    heff_take_n(v_x_2486, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2480;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2488 = heff_field(v_x_2486, 0);
    heff_take_n(v_x_2486, 1ULL, 1);
    switch (heff_tag_of(v_y_2488)) {
    case TAG_Left: {
      heff_take_n(v_y_2488, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2480;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2490 = heff_field(v_y_2488, 0);
      heff_take_n(v_y_2488, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2480;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2490});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2488);
    }
  }
  default: return heff_nomatch(v_x_2486);
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam12(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_a_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2478})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2485, v_hd_2479, heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam13, 1, 1, (V[]){v_k_2480})));
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam6(V self, V *args) {
  V v_p_2442 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2443 = heff_get_n(v_t_241, 3, 4);
  V v_t_2444 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2443)));
  V v_t_2445 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2444));
  V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam7, 1, 1, (V[]){v_os_2443}), v_t_2445));
  V v_texts_2458 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam8, 1, 1, (V[]){v_new_242}), v_t_2448));
  HeffT2 v_t_2459 = ({ V a_0 = v_p_2442; V a_1 = v_texts_2458; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_texts_2458); r_; });
  {
    V v_field_2461 = v_t_2459.f[1];
    int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
    if ((v_tag_2460 == ((int64_t)0ULL))) {
      heff_drop(v_p_2442);
      heff_drop_rec(v_st_240, 7);
      V v_q_2462 = v_field_2461;
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam9, 2, 1, (V[]){v_q_2462});
    } else {
      heff_drop(v_field_2461);
      HeffT2 v_t_2468 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_2442; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2470 = v_t_2468.f[1];
        int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
        if ((v_tag_2469 == ((int64_t)0ULL))) {
          heff_drop(v_p_2442);
          V v_d_2471 = v_field_2470;
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam10, 2, 1, (V[]){v_d_2471});
        } else {
          heff_drop(v_field_2470);
          V v_path_2475 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_2442));
          V v_t_2476 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2475; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2475); r_; });
          V v_a_2478 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2476, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam11_clo)});
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam12, 2, 1, (V[]){v_a_2478});
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam16(V self, V *args) {
  V v_s_2495 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_s_2495; V a_1 = v_x_2435; V r_ = (g_list_2eany_24s257543591x25063085(a_0, a_1)); heff_drop(v_x_2435); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam15(V self, V *args) {
  V v_x_2493 = args[0];
  V v_x_2491 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2494 = (g_heff_2elsp_2elsp_2enubSources(v_x_2491));
  return (g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam16, 1, 1, (V[]){v_x_2435}), heff_dup(g_std_2eordmap_2eempty_get()), v_x_2493, v_t_2494, v_hd_2437, v_k_2438));
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam14(V self, V *args) {
  V v_x_2491 = args[0];
  V v_lib_2439 = heff_env(self)[0];
  V v_f_2440 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2492 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(v_lib_2439, v_f_2440));
  V f_ = v_t_2492;
  heff_room[0] = heff_dup(v_hd_2437);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam15, 1, 4, (V[]){v_x_2491, v_x_2435, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_lib_2439 = heff_dup(heff_rfield(v_st_240, 6));
  V v_f_2440 = heff_dup(heff_rfield(v_t_241, 0));
  V v_t_2441 = (g_heff_2elsp_2elsp_2enubPaths(heff_dup(v_x_2435)));
  heff_clo_take(self, 4);
  return ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam6, 1, 3, (V[]){v_t_241, v_new_242, v_st_240}); V a_1 = heff_dup(v_lib_2439); V a_2 = v_t_2441; V a_3 = heff_dup(v_hd_2437); V a_4 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam14, 1, 5, (V[]){v_lib_2439, v_f_2440, v_hd_2437, v_x_2435, v_k_2438}); V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2441); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam17(V self, V *args) {
  V v_r_2496 = args[0];
  return v_r_2496;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam4(V self, V *args) {
  V v_use_2436 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_use_2436;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam5, 2, 4, (V[]){v_st_240, v_t_241, v_x_2435, v_new_242});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam17_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam19(V self, V *args) {
  V v_c_24111 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_c_24111; V a_1 = v_x_2435; V r_ = (g_list_2eany_24s1836353438x580818415(a_0, a_1)); heff_drop(v_x_2435); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam20(V self, V *args) {
  V v_c_24115 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_c_24115; V a_1 = v_x_2435; V r_ = (g_list_2eany_24s1836353438x580818415(a_0, a_1)); heff_drop(v_x_2435); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam18(V self, V *args) {
  V v_x_24101 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_k_2426 = heff_env(self)[4];
  V v_x_24130;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_24101)) {
  case TAG_Left: {
    V v_x_24102 = heff_field(v_x_24101, 0);
    V v_ru_24x_24101_24Left = heff_take_reuse_n(v_x_24101, 1ULL, 1);
    heff_drop(v_x_2435);
    V v_t_24103 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str1), heff_get_n(v_t_241, 2, 4));
    V v_t_24104 = heff_strAppend(heff_strAppend(v_t_24103, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str2)), v_new_242);
    V v_t_24105 = heff_strAppend(heff_strAppend(v_t_24104, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str3)), v_x_24102);
    V v_t_24106 = heff_tag_at_n(v_ru_24x_24101_24Left, TAG_Just, 1, (V[]){heff_strAppend(v_t_24105, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str4))});
    v_x_24130 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_2427, 0, 2), v_t_24106});
    break;
  }
  case TAG_Right: {
    V v_y_24107 = heff_field(v_x_24101, 0);
    V v_ru_24x_24101_24Right = heff_take_reuse_n(v_x_24101, 1ULL, 1);
    V v_before_24108 = heff_dup(v_x_2427);
    V v_t_24109 = v_t_241;
    V v_new_24110 = v_new_242;
    V v_program_24112 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam19, 1, 1, (V[]){heff_dup(v_x_2435)}), heff_get_n(v_x_2427, 1, 2)));
    V v_t_24113 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24112));
    V v_errorsBefore_24114 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_24113; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_24113); r_; });
    V v_program_24116 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam20, 1, 1, (V[]){v_x_2435}), heff_dup(heff_rfield(v_y_24107, 0))));
    V v_t_24117 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24116));
    V v_errorsAfter_24118 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_24117; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_24117); r_; });
    V v_after_24119 = heff_get_n(v_y_24107, 0, 2);
    V v_t_24129;
    if (heff_intLt_c_lent(v_errorsBefore_24114, v_errorsAfter_24118, 0)) {
      heff_drop(v_after_24119);
      V v_t_24120 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str5), heff_get_n(v_t_24109, 2, 4));
      V v_t_24121 = heff_strAppend(heff_strAppend(v_t_24120, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str6)), v_new_24110);
      V v_t_24122 = heff_intShow(heff_intSub(v_errorsAfter_24118, v_errorsBefore_24114));
      V v_t_24123 = heff_strAppend(heff_strAppend(v_t_24121, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str7)), v_t_24122);
      v_t_24129 = heff_tag_at_n(v_ru_24x_24101_24Right, TAG_Just, 1, (V[]){heff_strAppend(v_t_24123, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str8))});
    } else {
      heff_drop(v_errorsBefore_24114);
      heff_drop(v_errorsAfter_24118);
      V v_t_24124 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_24109), heff_dup(v_new_24110)));
      V v_xs_24125 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_24119, v_t_24124, heff_dup(v_new_24110)));
      V v_x_24126 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24125; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_24125); r_; });
      V v_y_24127 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_24109, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (!heff_intEq_c_lent(v_x_24126, v_y_24127, 0)) {
        heff_drop(v_x_24126);
        heff_drop(v_y_24127);
        V v_t_24128 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str9), v_new_24110), ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_str10));
        v_t_24129 = heff_tag_at_n(v_ru_24x_24101_24Right, TAG_Just, 1, (V[]){v_t_24128});
      } else {
        heff_drop_cell(v_ru_24x_24101_24Right, 1);
        heff_drop(v_new_24110);
        heff_drop(v_x_24126);
        heff_drop(v_y_24127);
        v_t_24129 = NTAG(TAG_Nothing);
      }
    }
    v_x_24130 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_24108, 0, 2), v_t_24129});
    break;
  }
  default: heff_nomatch(v_x_24101);
  }
  V f_ = v_k_2426;
  args[0] = v_x_24130;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_hd_2425 = heff_env(self)[3];
  V v_k_2426 = heff_env(self)[4];
  V v_os_2428 = heff_dup(heff_rfield(v_t_241, 3));
  V v_t_2429 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2428)));
  V v_t_2430 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2429));
  V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam3, 1, 1, (V[]){v_os_2428}), v_t_2430));
  V v_t_2434 = (g_list_2emap_24s582709368x2113456071(v_t_2433));
  V v_x_2435 = ({ V a_0 = v_t_2434; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_2427, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
  heff_clo_take(self, 5);
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam4, 1, 4, (V[]){v_st_240, heff_dup(v_t_241), heff_dup(v_x_2435), heff_dup(v_new_242)})})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24100}), v_hd_2425, heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam18, 1, 5, (V[]){v_t_241, v_new_242, v_x_2427, v_x_2435, v_k_2426})));
}
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam1(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_lam2, 1, 5, (V[]){v_t_241, v_st_240, v_new_242, v_hd_2425, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_str0, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_str1, 5, "range");
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam1, 1, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_entry, 5, 0};

V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741(V v_st_240, V v_new_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_new_241);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_b_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_path_247 = heff_take_field(v_b_245, 0);
    V v_occurrences_248 = heff_get_n(v_b_245, 1, 2);
    V v_p_249 = v_path_247;
    HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_p_249));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_c_2421;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_p_249);
        V v_d_2413 = v_field_2412;
        v_c_2421 = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam0, 2, 1, (V[]){v_d_2413});
      } else {
        heff_drop(v_field_2412);
        V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_PathUri, 2, (V[]){v_p_249, ((V)&g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam1_clo)})});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
        v_c_2421 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
      }
      return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam2, 1, 6, (V[]){v_st_240, v_new_241, v_rest_246, v_z_243, v_occurrences_248, v_z_244})});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  heff_drop(v_hd_2414);
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = heff_get_n(v_d_2413, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  return v_u_2416;
}
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam4(V self, V *args) {
  V v_o_2424 = args[0];
  V v_new_241 = heff_env(self)[0];
  V v_source_2425 = heff_take_field(v_o_2424, 1);
  V v_span_2426 = heff_get_n(v_o_2424, 2, 4);
  V v_t_2427 = ({ V a_0 = v_source_2425; V a_1 = v_span_2426; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_2425); r_; });
  heff_clo_take(self, 1);
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_str0), heff_tag_n(TAG_JString, 1, (V[]){v_new_241})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_str1), v_t_2427}), v_t_2429});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430});
}
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_new_241 = heff_env(self)[0];
  V v_occurrences_248 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam4, 1, 1, (V[]){v_new_241}), v_occurrences_248));
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2422, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2431})});
  V v_x_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_x_2423});
  V f_ = v_z_244;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_occurrences_248 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741(v_st_240, heff_dup(v_new_241), v_rest_246, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_lam3, 1, 4, (V[]){v_new_241, v_occurrences_248, v_x_2422, v_z_244})));
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_str0, 1, " ");
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam10, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam6(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199(V v_st_240, V v_f_241, V v_program_242, V v_c_243, V v_s_244) {
top: ;
  V v_docs_245 = heff_take_field(v_st_240, 0);
  V v_lib_246 = heff_get_n(v_st_240, 6, 7);
  V v_c_2438 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam0, 1, 4, (V[]){heff_dup(v_f_241), v_c_243, heff_dup(v_s_244), v_docs_245}), v_lib_246, v_f_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam6, 2, 3, (V[]){v_c_2438, v_program_242, v_s_244});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  heff_drop(v_hd_248);
  heff_clo_take(self, 2);
  V v_src_2410 = heff_get_n(v_c_243, 3, 14);
  V v_t_2411 = heff_strSlice(heff_dup(v_src_2410), MK_INT(0LL), heff_take_field(v_s_244, 3));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_str0)), heff_take_field(v_s_244, 0));
  V v_t_2413 = heff_strSlice(heff_dup(v_src_2410), heff_get_n(v_s_244, 4, 5), heff_strLength(v_src_2410));
  V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_t_2412, v_t_2413)});
  V f_ = v_k_249;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_d_2418 = heff_env(self)[0];
  heff_drop(v_hd_2419);
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2418, 1, 2)});
  V f_ = v_k_2420;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam3(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2427 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    heff_take_n(v_x_2433, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2427;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    switch (heff_tag_of(v_y_2435)) {
    case TAG_Left: {
      heff_take_n(v_y_2435, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2427;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2437 = heff_field(v_y_2435, 0);
      heff_take_n(v_y_2435, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2427;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2437});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2435);
    }
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_a_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2432, v_hd_2426, heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam5, 1, 1, (V[]){v_k_2427})));
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam0(V self, V *args) {
  V v_q_247 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  V v_docs_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_q_247, v_f_241, 2)) {
    heff_drop(v_q_247);
    heff_drop(v_docs_245);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam1, 2, 2, (V[]){v_c_243, v_s_244});
  } else {
    heff_drop_rec(v_c_243, 14);
    heff_drop_rec(v_s_244, 5);
    HeffT2 v_t_2415 = ({ V a_0 = v_docs_245; V a_1 = v_q_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_245); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_q_247);
        V v_d_2418 = v_field_2417;
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam2, 2, 1, (V[]){v_d_2418});
      } else {
        heff_drop(v_field_2417);
        V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_q_247));
        V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
        V v_a_2425 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2423, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam3_clo)});
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam4, 2, 1, (V[]){v_a_2425});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam9(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_program_242 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  heff_drop(v_hd_2443);
  heff_clo_take(self, 3);
  V v_program_2445 = v_program_242;
  V v_s_2446 = v_s_244;
  V v_equals_2447 = heff_take_field(v_s_2446, 3);
  V v_name_2448 = heff_get_n(v_s_2446, 0, 5);
  V v_x1_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_2441, 0, 5)));
  V v_x3_2452;
  switch (heff_tag_of(v_x1_2449)) {
  case TAG_Nil: {
    v_x3_2452 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2450 = heff_field(v_x1_2449, 0);
    heff_take_n(v_x1_2449, 1ULL, 2);
    v_x3_2452 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2450});
    break;
  }
  default: heff_nomatch(v_x1_2449);
  }
  V v_x_2468;
  switch (heff_tag_of(v_x3_2452)) {
  case TAG_Nothing: {
    heff_drop(v_program_2445);
    heff_drop(v_equals_2447);
    heff_drop(v_name_2448);
    v_x_2468 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_source_2453 = heff_field(v_x3_2452, 0);
    V v_ru_24x3_2452_24Just = heff_take_reuse_n(v_x3_2452, 1ULL, 1);
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_2445));
    V v_xs_2455 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2454; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2454); r_; });
    V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2455));
    V v_c_2457 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2456, v_source_2453, NTAG(TAG_Nothing)));
    HeffT2 v_t_2458 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2457, heff_intAdd(v_equals_2447, MK_INT(1LL))));
    {
      V v_field_2460 = v_t_2458.f[1];
      int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
      if ((v_tag_2459 == ((int64_t)0ULL))) {
        V v_i_2461 = v_field_2460;
        V v_name_2462 = heff_take_field(v_i_2461, 1);
        V v_key_2463 = heff_take_field(v_i_2461, 2);
        V v_ty_2464 = heff_get_n(v_i_2461, 4, 5);
        if (heff_strEq_c(v_name_2462, v_name_2448)) {
          V v_t_2465 = v_key_2463;
          switch (heff_tag_of(v_t_2465)) {
          case TAG_Nothing: {
            V v_t_2466 = heff_tr(heff_call(v_ty_2464, 1, (V[]){NTAG(TAG_MkUnit)}));
            v_x_2468 = heff_tag_at_n(v_ru_24x3_2452_24Just, TAG_Just, 1, (V[]){v_t_2466});
            break;
          }
          case TAG_Just: {
            heff_take_n(v_t_2465, 0ULL, 1);
            heff_drop_cell(v_ru_24x3_2452_24Just, 1);
            heff_drop(v_ty_2464);
            v_x_2468 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_2465);
          }
        } else {
          heff_drop_cell(v_ru_24x3_2452_24Just, 1);
          heff_drop(v_key_2463);
          heff_drop(v_ty_2464);
          v_x_2468 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_name_2448);
        heff_drop_cell(v_ru_24x3_2452_24Just, 1);
        heff_drop(v_field_2460);
        v_x_2468 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_x3_2452);
  }
  V f_ = v_k_2444;
  args[0] = v_x_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam10(V self, V *args) {
  V v_r_2469 = args[0];
  return v_r_2469;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam8(V self, V *args) {
  V v_use_2442 = args[0];
  V v_program_242 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2442;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam9, 2, 3, (V[]){v_program_242, v_s_244, v_x_2441});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam10_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam11(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_t_2477;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_Left: {
    heff_take_n(v_x_2474, 0ULL, 1);
    v_t_2477 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_t_2476 = heff_field(v_x_2474, 0);
    heff_take_n(v_x_2474, 1ULL, 1);
    v_t_2477 = v_t_2476;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  heff_clo_take(self, 1);
  V f_ = v_k_2440;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_program_242 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_hd_2439 = heff_env(self)[2];
  V v_k_2440 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam8, 1, 3, (V[]){v_program_242, v_s_244, v_x_2441})})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), v_hd_2439, heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam11, 1, 1, (V[]){v_k_2440})));
}
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam6(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  V v_program_242 = heff_env(self)[1];
  V v_s_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2438;
  args[0] = heff_dup(v_hd_2439);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_lam7, 1, 4, (V[]){v_program_242, v_s_244, v_hd_2439, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10, 5, "range");
Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V v_tok_240, V v_src_241, V v_d_242) {
top: ;
  V v_span_243 = heff_take_field(v_d_242, 3);
  V v_severity_244 = heff_take_field(v_d_242, 1);
  V v_note_245 = heff_take_field(v_d_242, 4);
  V v_msg_246 = heff_take_field(v_d_242, 2);
  V v_code_247 = heff_get_n(v_d_242, 0, 5);
  V v_t_248 = (g_heff_2elsp_2elsp_2erange(v_src_241, v_span_243));
  V v_t_249 = heff_dup(v_severity_244);
  V v_t_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_SError: {
    v_t_2410 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_2410 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_2410 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2411 = v_note_245;
  V v_t_2413;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2413 = v_msg_246;
    break;
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    v_t_2413 = heff_strAppend(heff_strAppend(v_msg_246, ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0)), v_n_2412);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_ys_2420;
  if (heff_intEq_c_lent(v_code_247, MK_INT(0LL), 2)) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_severity_244);
    heff_drop(v_code_247);
    v_ys_2420 = NTAG(TAG_Nil);
  } else {
    V v_t_2414 = v_severity_244;
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_SError: {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1);
      break;
    }
    case TAG_SWarning: {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2);
      break;
    }
    case TAG_SDebug: {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2416 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_247)));
    V v_t_2417 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2416), ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4)));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2415, v_t_2417), heff_intShow(v_code_247));
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5), heff_tag_at_n(v_tok_240, TAG_JString, 1, (V[]){v_t_2418})});
    v_ys_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  }
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_t_2410})});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8)})});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9), heff_tag_n(TAG_JString, 1, (V[]){v_t_2413})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_ys_2420})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10), v_t_248}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2424})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2425});
}
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ediagnostic_24tok1(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str5, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str6, 0, "");
Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_entry, 4, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(V v_tok_240, V v_id_241, V v_code_242, V v_msg_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str0), heff_tag_at_n(v_tok_240, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str1)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_242})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_243})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str4), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str5), v_id_241}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2410})});
  V v_t_2412 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_str6); V a_1 = v_t_2411; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_2411, 1); r_; });
  V v_a_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return heff_tail(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){v_t_2417});
}
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(a[0], a[1], a[2], a[3]);
}