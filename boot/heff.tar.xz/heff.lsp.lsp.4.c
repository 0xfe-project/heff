// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_PathUri 23459
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_at 9882
#define LBL_children 257181584
#define LBL_claim 296100950
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_docs 9584386
#define LBL_end 310101
#define LBL_error 298143266
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_root 10001833
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V, V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746(V, V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287(V, V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843(V, V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955(V, V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955_clo;
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503(V, V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str1, 5, "start");
Clo g_heff_2elsp_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_start_242 = heff_take_field(v_sp_241, 0);
  V v_end_243 = heff_get_n(v_sp_241, 1, 2);
  V v_t_244 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_start_242)));
  V v_x_245 = v_start_242;
  V v_y_246 = v_end_243;
  V v_t_247;
  if (heff_intLe_c_lent(v_x_245, v_y_246, 0)) {
    heff_drop(v_x_245);
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = v_x_245;
  }
  V v_t_248 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_247));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str0), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str1), v_t_244}), v_t_249});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410});
}
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2erange(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str2, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str3, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str4, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str5, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2edeclsGo(V v_x1_240, V v_key_241, V v_above_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_above_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_245 = heff_take_field(v_l_243, 1);
    V v_at_246 = heff_get_n(v_l_243, 0, 2);
    V v_l_247 = heff_dup(v_text_245);
    if ((heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str0)) || heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str1)))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_text_245);
      heff_drop(v_l_247);
      V v_t_249;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_249 = v_at_246;
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop(v_at_246);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_244;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      goto top;
    } else {
      heff_drop(v_l_247);
      V v_l_2410 = heff_dup(v_text_245);
      V v_t_2414;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_2410, 0)))) {
        if (((heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : !(heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)13ULL))))) {
          if ((heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str2)) ? 0 : !heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str3)))) {
            V v_t_2411 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2410, MK_INT(0LL)));
            V v_x1_2413 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), v_t_2411, 2), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str4)) || ({ V v_t_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2410, MK_INT(0LL))); int c_ = ({ V v_t_2428 = heff_strSlice_lent(v_l_2410, MK_INT(0LL), v_t_2412, 2); int c_ = heff_strEq_c_lent(v_t_2428, ((V)&g_heff_2elsp_2elsp_2edeclsGo_str5), 2); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2412); c_; })));
            heff_drop(v_l_2410);
            heff_drop(v_t_2411);
            v_t_2414 = heff_bool(!(heff_dup(v_x1_2413) == NTAG(TAG_True)));
            heff_drop(v_x1_2413);
          } else {
            heff_drop(v_l_2410);
            v_t_2414 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l_2410);
          v_t_2414 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_l_2410);
        v_t_2414 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_heff_2elsp_2elsp_2ekeyOf(v_text_245));
        V v_x1_2416 = heff_bool(heff_strEq_c_lent(v_t_2415, v_key_241, 0));
        heff_drop(v_t_2415);
        if (!(heff_dup(v_x1_2416) == NTAG(TAG_True))) {
          heff_drop(v_x1_2416);
          V v_cut_2418;
          switch (heff_tag_of(v_above_242)) {
          case TAG_Nothing: {
            v_cut_2418 = heff_dup(v_at_246);
            break;
          }
          case TAG_Just: {
            V v_x_2417 = heff_field(v_above_242, 0);
            heff_take_n(v_above_242, 1ULL, 1);
            v_cut_2418 = v_x_2417;
            break;
          }
          default: heff_nomatch(v_above_242);
          }
          V v_n_2419 = v_at_246;
          HeffT2 v_t_2420 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_text_245));
          V v_t_2424;
          {
            V v_field_2421 = v_t_2420.f[0];
            V v_field_2422 = v_t_2420.f[1];
            V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_field_2421, heff_dup(v_n_2419)), heff_intAdd(v_field_2422, v_n_2419)});
            v_t_2424 = heff_rec_n(2, shape_cut__name, (V[]){v_cut_2418, v_t_2423});
          }
          V v_cell_2425 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
          V v_t_2426 = ({ V a_0 = v_text_245; V r_ = (g_heff_2elsp_2elsp_2ekeyOf(a_0)); heff_drop(v_text_245); r_; });
          V v_u_2427 = (g_heff_2elsp_2elsp_2edeclsGo_24dps(v_rest_244, v_t_2426, NTAG(TAG_Nothing), heff_dup(v_cell_2425)));
          heff_drop(v_u_2427);
          return v_cell_2425;
        } else {
          heff_drop(v_above_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_text_245);
          heff_drop(v_at_246);
          heff_drop(v_x1_2416);
          V t_0 = v_rest_244;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_above_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_text_245);
        heff_drop(v_at_246);
        heff_drop(v_t_2414);
        V t_0 = v_rest_244;
        V t_1 = v_key_241;
        V t_2 = NTAG(TAG_Nothing);
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2edeclsGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str0, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str1, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str2, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str3, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str5, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str6, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str7, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str9, 8, "children");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str10, 14, "selectionRange");
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_name_242 = heff_take_field(v_y_241, 0);
  V v_kind_243 = heff_take_field(v_y_241, 1);
  V v_span_244 = heff_take_field(v_y_241, 2);
  V v_selection_245 = heff_take_field(v_y_241, 3);
  V v_children_246 = heff_get_n(v_y_241, 4, 5);
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str0), heff_tag_n(TAG_JString, 1, (V[]){v_name_242})});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_243})});
  V v_s_249 = heff_take_field(v_span_244, 0);
  V v_x_2410 = heff_get_n(v_span_244, 1, 2);
  V v_y_2411 = heff_dup(heff_rfield(v_selection_245, 1));
  V v_t_2412;
  if (heff_intLe_c_lent(v_x_2410, v_y_2411, 0)) {
    heff_drop(v_x_2410);
    v_t_2412 = v_y_2411;
  } else {
    heff_drop(v_y_2411);
    v_t_2412 = v_x_2410;
  }
  V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_s_249)));
  V v_t_2414;
  if (heff_intLe_c_lent(v_s_249, v_t_2412, 0)) {
    heff_drop(v_s_249);
    v_t_2414 = v_t_2412;
  } else {
    heff_drop(v_t_2412);
    v_t_2414 = v_s_249;
  }
  V v_t_2415 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str2), v_t_2415}), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str3), v_t_2413}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2417})});
  V v_t_2419 = (g_heff_2elsp_2elsp_2erange(v_src_240, v_selection_245));
  V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2edocSymbol_lam0, 1, 1, (V[]){v_src_240}), v_children_246));
  V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str9), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str10), v_t_2419}), v_t_2435});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2436})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2437})});
}
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocSymbol(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2420 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_src_2421 = v_src_240;
  V v_m_2422 = v_m_2420;
  V v_name_2423 = heff_take_field(v_m_2422, 0);
  V v_kind_2424 = heff_take_field(v_m_2422, 1);
  V v_span_2425 = heff_get_n(v_m_2422, 2, 3);
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str5), heff_tag_n(TAG_JString, 1, (V[]){v_name_2423})});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_2424})});
  V v_t_2428 = (g_heff_2elsp_2elsp_2erange(v_src_2421, heff_dup(v_span_2425)));
  V v_t_2429 = ({ V a_0 = v_src_2421; V a_1 = v_span_2425; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_src_2421); r_; });
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str7), v_t_2429}), NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str8), v_t_2428}), v_t_2430});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2431})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2432});
}
Clo g_heff_2elsp_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244;
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL)))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) + ((int64_t)32ULL));
      v_t_244 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_243))));
    } else {
      v_t_244 = heff_strSlice_lent(v_s_240, v_i_241, heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))), 4);
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elowerGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str0, 31, "Write the module claim `module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str1, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str2, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str4, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str6, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str7, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str9, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str10, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str11, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str12, 11, "isPreferred");
Clo g_heff_2elsp_2elsp_2eclaimAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimAction_entry, 5, 0};

V g_heff_2elsp_2elsp_2eclaimAction(V v_uri_240, V v_src_241, V v_n_242, V v_ds_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_text_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_start_247 = heff_take_field(v_sp_245, 0);
    V v_end_248 = heff_get_n(v_sp_245, 1, 2);
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimAction_str0), v_n_242), ((V)&g_heff_2elsp_2elsp_2eclaimAction_str1));
    V v_t_2410 = heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str2), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str4)})});
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_243})});
    V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(v_start_247)));
    V v_x_2414 = v_start_247;
    V v_y_2415 = v_end_248;
    V v_t_2416;
    if (heff_intLe_c_lent(v_x_2414, v_y_2415, 0)) {
      heff_drop(v_x_2414);
      v_t_2416 = v_y_2415;
    } else {
      heff_drop(v_y_2415);
      v_t_2416 = v_x_2414;
    }
    V v_t_2417 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_2416));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str6), v_t_2417}), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str7), v_t_2413}), v_t_2418});
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str8), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str9), heff_tag_n(TAG_JString, 1, (V[]){v_text_246})});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    V v_t_2423 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str11), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str12), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2430});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2431})});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2432})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclaimAction(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam0, 2, 0};
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_entry, 3, 0};

V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503(V v_e_240, V v_st_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_st_241, 7);
    return ((V)&g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), heff_dup(heff_rfield(v_st_241, 6)), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam1, 2, 5, (V[]){v_c_247, v_e_240, v_st_241, v_rest_246, v_f_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_f_245 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_2410, 0, 6), v_f_245});
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_f_245 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = (g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503(v_e_240, v_st_241, v_rest_246));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam3, 1, 3, (V[]){v_x_2410, v_f_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_f_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_lam2, 1, 6, (V[]){v_e_240, v_st_241, v_rest_246, v_hd_248, v_f_245, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_str0, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_str1, 5, "range");
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam0, 2, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_entry, 4, 0};

V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746(V v_e_240, V v_st_241, V v_new_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_new_242);
    return ((V)&g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_path_248 = heff_take_field(v_b_246, 0);
    V v_occurrences_249 = heff_get_n(v_b_246, 1, 2);
    V v_p_2410 = v_path_248;
    HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_p_2410));
    V v_c_2423;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop(v_p_2410);
        V v_d_2414 = v_field_2413;
        v_c_2423 = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam1, 2, 1, (V[]){v_d_2414});
      } else {
        heff_drop(v_field_2413);
        V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_PathUri, 2, (V[]){v_p_2410, ((V)&g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam2_clo)})});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
        v_c_2423 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
      }
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam3, 2, 6, (V[]){v_c_2423, v_e_240, v_st_241, v_new_242, v_rest_247, v_occurrences_249});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_d_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_get_n(v_d_2414, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam2(V self, V *args) {
  V v_u_2417 = args[0];
  return v_u_2417;
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam6(V self, V *args) {
  V v_o_2429 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_source_2430 = heff_take_field(v_o_2429, 1);
  V v_span_2431 = heff_get_n(v_o_2429, 2, 4);
  V v_t_2432 = ({ V a_0 = v_source_2430; V a_1 = v_span_2431; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_2430); r_; });
  V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_str0), heff_tag_n(TAG_JString, 1, (V[]){v_new_242})});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_str1), v_t_2432}), v_t_2434});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2435});
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_new_242 = heff_env(self)[0];
  V v_occurrences_249 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_k_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam6, 1, 1, (V[]){v_new_242}), v_occurrences_249));
  V v_t_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2436})});
  V v_x_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_x_2428});
  V f_ = v_k_2425;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_occurrences_249 = heff_env(self)[5];
  V v_k_2425 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2427 = (g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746(v_e_240, v_st_241, heff_dup(v_new_242), v_rest_247));
  V f_ = v_c_2427;
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam5, 1, 4, (V[]){v_new_242, v_occurrences_249, v_x_2426, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_occurrences_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746_lam4, 1, 7, (V[]){v_e_240, v_st_241, v_new_242, v_rest_247, v_hd_2424, v_occurrences_249, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str17, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str19, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str20, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str21, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str22, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str23, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str24, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str25, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str26, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str27, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str28, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str29, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str30, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str31, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str32, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str34, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str35, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str36, 1, "{");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str37, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str38, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str39, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str40, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str41, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str42, 1, "}");
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341(V v_e_240, V v_id_241, V v_new_242, V v_tg_243, V v_z_244, V v_z_245) {
top: ;
  V v_target_246 = heff_take_field(v_tg_243, 2);
  V v_st_247 = heff_get_n(v_tg_243, 0, 3);
  switch (heff_tag_of(v_target_246)) {
  case TAG_Nothing: {
    heff_drop(v_new_242);
    V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str0), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str1), MK_INT(0LL)));
    V v_acc_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str2)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str3));
    V v_t_2410 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str4), heff_strAppend(v_acc_249, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str5)), MK_INT(0LL)));
    V v_acc_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str6));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_acc_2411, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str7)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str8));
    V v_t_2413 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str9), v_t_2412, MK_INT(0LL)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str10)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str11));
    V v_acc_2415 = ({ V a_0 = v_t_2414; V a_1 = v_id_241; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_241); r_; });
    V v_t_2416 = heff_strAppend(heff_strAppend(v_acc_2415, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str12)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str13));
    V v_t_2417 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str14), v_t_2416, MK_INT(0LL)));
    V v_acc_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str15)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str16));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_acc_2418, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str17)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str18));
    V v_a_2420 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2425, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam0, 1, 2, (V[]){v_z_245, v_st_247})));
  }
  case TAG_Just: {
    V v_t_2427 = heff_field(v_target_246, 0);
    V v_ru_24target_246_24Just = heff_take_reuse_n(v_target_246, 1ULL, 1);
    HeffT2 v_t_2428 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2427, 1)), heff_dup(heff_rfield(v_t_2427, 2)), heff_dup(v_new_242)));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        heff_drop(v_new_242);
        heff_drop_rec(v_t_2427, 4);
        V v_why_2431 = v_field_2430;
        V v_c_2432 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(v_ru_24target_246_24Just, v_e_240, v_id_241, MK_INT(-32803LL), v_why_2431));
        return heff_tail(v_c_2432, 2, (V[]){v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam1, 1, 2, (V[]){v_z_245, v_st_247})});
      } else {
        heff_drop_cell(v_ru_24target_246_24Just, 1);
        heff_drop(v_field_2430);
        V v_c_2434 = (g_heff_2elsp_2elsp_2erenameChecked_24s166595298x1820332955(heff_dup(v_e_240), v_st_247, heff_dup(v_t_2427), heff_dup(v_new_242)));
        return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam2, 1, 6, (V[]){v_t_2427, v_e_240, v_new_242, v_z_244, v_id_241, v_z_245})});
      }
    }
  }
  default: return heff_nomatch(v_target_246);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_z_245;
  args[0] = v_st_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V f_ = v_z_245;
  args[0] = v_st_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam3(V self, V *args) {
  V v_p_2445 = args[0];
  V v_os_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2446 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2445, v_os_2442));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2445, v_os_2446});
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam5(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2472);
  V v_t_2475;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 2);
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_z_245;
  args[0] = v_t_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam4(V self, V *args) {
  V v_x_2449 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2450 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str19), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str20), MK_INT(0LL)));
  V v_acc_2451 = heff_strAppend(heff_strAppend(v_t_2450, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str21)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str22));
  V v_t_2452 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str23), heff_strAppend(v_acc_2451, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str24)), MK_INT(0LL)));
  V v_acc_2453 = heff_strAppend(v_t_2452, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str25));
  V v_t_2454 = heff_strAppend(heff_strAppend(v_acc_2453, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str26)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str27));
  V v_t_2455 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str28), v_t_2454, MK_INT(0LL)));
  V v_t_2456 = heff_strAppend(heff_strAppend(v_t_2455, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str29)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str30));
  V v_acc_2457 = ({ V a_0 = v_t_2456; V a_1 = v_id_241; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_241); r_; });
  V v_t_2458 = heff_strAppend(heff_strAppend(v_acc_2457, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str31)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str32));
  V v_t_2459 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str33), v_t_2458, MK_INT(0LL)));
  V v_acc_2460 = heff_strAppend(heff_strAppend(v_t_2459, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str34)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str35));
  V v_t_2461 = heff_strAppend(heff_strAppend(v_acc_2460, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str36)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str37));
  V v_t_2462 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str38), v_t_2461, MK_INT(0LL)));
  V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2462, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str39)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str40));
  V v_acc_2464 = ({ V a_0 = v_t_2463; V b_1 = heff_tag_n(TAG_JObject, 1, (V[]){v_x_2449}); V r_ = (g_json_2estringify_2ewriteInto_240(a_0, b_1)); heff_drop(b_1); r_; });
  V v_acc_2465 = heff_strAppend(v_acc_2464, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str41));
  V v_a_2466 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2465, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_str42)), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2471, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam5, 1, 2, (V[]){v_x_2435, v_z_245})));
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam6(V self, V *args) {
  V v_x_2478 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2478);
  V v_t_2481;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 2);
    v_t_2481 = v_x_2479;
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_z_245;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam2(V self, V *args) {
  V v_x_2435 = args[0];
  V v_t_2427 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_id_241 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2438;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkPair: {
    V v_y_2437 = heff_dup(heff_field(v_x_2435, 1));
    v_t_2438 = v_y_2437;
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  switch (heff_tag_of(v_t_2438)) {
  case TAG_Nothing: {
    V v_t_2441;
    switch (heff_tag_of(v_x_2435)) {
    case TAG_MkPair: {
      V v_x_2439 = heff_dup(heff_field(v_x_2435, 0));
      v_t_2441 = v_x_2439;
      break;
    }
    default: heff_nomatch(v_x_2435);
    }
    V v_os_2442 = heff_get_n(v_t_2427, 3, 4);
    V v_t_2443 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2442)));
    V v_t_2444 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2443));
    V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam3, 1, 1, (V[]){v_os_2442}), v_t_2444));
    V v_c_2448 = (g_heff_2elsp_2elsp_2echangesOf_24s620061298x494032746(heff_dup(v_e_240), v_t_2441, v_new_242, v_t_2447));
    V f_ = v_c_2448;
    heff_room[0] = heff_dup(v_z_244);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam4, 1, 5, (V[]){v_id_241, v_e_240, v_z_244, v_x_2435, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2476 = heff_field(v_t_2438, 0);
    V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 1ULL, 1);
    heff_drop_rec(v_t_2427, 4);
    heff_drop(v_new_242);
    V v_c_2477 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(v_ru_24t_2438_24Just, v_e_240, v_id_241, MK_INT(-32803LL), v_why_2476));
    V f_ = v_c_2477;
    heff_room[0] = v_z_244;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_lam6, 1, 2, (V[]){v_x_2435, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2438);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str17, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str18, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str19, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str20, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str21, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str22, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str23, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str24, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str25, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str27, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str28, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str31, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str32, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str33, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str34, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str35, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str36, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str37, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str38, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str39, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str40, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str41, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str42, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str43, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str44, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str45, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str46, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str47, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str48, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str49, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str50, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str51, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str52, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str54, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str55, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str56, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str57, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str58, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str59, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str60, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str61, 1, "}");
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_entry, 7, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760(V v_e_240, V v_st_241, V v_id_242, V v_d_243, V v_fix_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_244, heff_dup(heff_rfield(v_d_243, 1))));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_243, 2);
      V v_x_2410 = v_field_249;
      heff_drop(v_x_2410);
      V v_t_2411 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str0), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str1), MK_INT(0LL)));
      V v_acc_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str2)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str3));
      V v_t_2413 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str4), heff_strAppend(v_acc_2412, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str5)), MK_INT(0LL)));
      V v_acc_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str6));
      V v_t_2415 = heff_strAppend(heff_strAppend(v_acc_2414, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str7)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str8));
      V v_t_2416 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str9), v_t_2415, MK_INT(0LL)));
      V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str10)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str11));
      V v_acc_2418 = (g_json_2estringify_2ewriteInto_240(v_t_2417, v_id_242));
      V v_t_2419 = heff_strAppend(heff_strAppend(v_acc_2418, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str12)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str13));
      V v_t_2420 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str14), v_t_2419, MK_INT(0LL)));
      V v_acc_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str15)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str16));
      V v_t_2422 = heff_strAppend(heff_strAppend(v_acc_2421, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str17)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str18));
      V v_a_2423 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str19)), NTAG(TAG_MkUnit)});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2428, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam0, 1, 2, (V[]){v_z_246, v_st_241})));
    } else {
      V v_t_2430 = v_field_249;
      if (heff_strEq_c(heff_dup(v_t_2430), heff_dup(heff_rfield(v_d_243, 1)))) {
        heff_drop_rec(v_d_243, 2);
        heff_drop(v_t_2430);
        V v_t_2431 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str20), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str21), MK_INT(0LL)));
        V v_acc_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str22)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str23));
        V v_t_2433 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str24), heff_strAppend(v_acc_2432, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str25)), MK_INT(0LL)));
        V v_acc_2434 = heff_strAppend(v_t_2433, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str26));
        V v_t_2435 = heff_strAppend(heff_strAppend(v_acc_2434, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str27)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str28));
        V v_t_2436 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str29), v_t_2435, MK_INT(0LL)));
        V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str30)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str31));
        V v_acc_2438 = (g_json_2estringify_2ewriteInto_240(v_t_2437, v_id_242));
        V v_t_2439 = heff_strAppend(heff_strAppend(v_acc_2438, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str32)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str33));
        V v_t_2440 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str34), v_t_2439, MK_INT(0LL)));
        V v_acc_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str35)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str36));
        V v_t_2442 = heff_strAppend(heff_strAppend(v_acc_2441, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str37)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str38));
        V v_a_2443 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str39)), NTAG(TAG_MkUnit)});
        V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2443})});
        V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
        V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
        V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
        V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2448, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam1, 1, 2, (V[]){v_z_246, v_st_241})));
      } else {
        V v_src_2450 = heff_dup(heff_rfield(v_d_243, 1));
        V v_t_2451 = heff_strLength(heff_get_n(v_d_243, 1, 2));
        V v_t_2452 = (g_heff_2elsp_2elsp_2eposition(v_src_2450, MK_INT(0LL)));
        V v_t_2453;
        if ((((int64_t)0ULL) <= heff_peek_word(v_t_2451))) {
          v_t_2453 = v_t_2451;
        } else {
          heff_drop(v_t_2451);
          v_t_2453 = MK_INT(0LL);
        }
        V v_t_2454 = ({ V a_0 = v_src_2450; V a_1 = v_t_2453; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_2450); r_; });
        V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str40), v_t_2454}), NTAG(TAG_Nil)});
        V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str41), v_t_2452}), v_t_2455});
        V v_t_2457 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str42), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2456})});
        V v_t_2458 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str43), heff_tag_n(TAG_JString, 1, (V[]){v_t_2430})});
        V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
        V v_t_2460 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_t_2459})});
        V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
        V v_result_2462 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2461});
        V v_t_2463 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str44), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str45), MK_INT(0LL)));
        V v_acc_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str46)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str47));
        V v_t_2465 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str48), heff_strAppend(v_acc_2464, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str49)), MK_INT(0LL)));
        V v_acc_2466 = heff_strAppend(v_t_2465, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str50));
        V v_t_2467 = heff_strAppend(heff_strAppend(v_acc_2466, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str51)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str52));
        V v_t_2468 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str53), v_t_2467, MK_INT(0LL)));
        V v_t_2469 = heff_strAppend(heff_strAppend(v_t_2468, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str54)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str55));
        V v_acc_2470 = (g_json_2estringify_2ewriteInto_240(v_t_2469, v_id_242));
        V v_t_2471 = heff_strAppend(heff_strAppend(v_acc_2470, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str56)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str57));
        V v_t_2472 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str58), v_t_2471, MK_INT(0LL)));
        V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2472, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str59)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str60));
        V v_acc_2474 = ({ V a_0 = v_t_2473; V a_1 = v_result_2462; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_result_2462, 1); r_; });
        V v_a_2475 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2474, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_str61)), NTAG(TAG_MkUnit)});
        V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2475})});
        V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2480, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam2, 1, 2, (V[]){v_z_246, v_st_241})));
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam1(V self, V *args) {
  V v_x_2449 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2449);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1421520439x1164630760_lam2(V self, V *args) {
  V v_x_2481 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2481);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str0, 10, "package.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str1, 11, "/package.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str2, 8, "build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str3, 9, "/build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str4, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str5, 1, "\012");
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_entry, 3, 0};

V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843(V v_e_240, V v_st_241, V v_f_242) {
top: ;
  if ((heff_strEq_c_lent(v_f_242, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str0), 2) || ({ int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_f_242, 0)) - ((int64_t)11ULL)); int c_ = ({ V v_t_2421 = heff_strSlice(heff_dup(v_f_242), heff_box_word(v_t_243), heff_strLength_lent(v_f_242, 0)); int c_ = (heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str1), 2) || (heff_strEq_c_lent(v_f_242, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str2), 2) || ({ int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_f_242, 0)) - ((int64_t)9ULL)); int c_ = ({ V v_t_2422 = heff_strSlice(heff_dup(v_f_242), heff_box_word(v_t_244), heff_strLength_lent(v_f_242, 0)); int c_ = heff_strEq_c_lent(v_t_2422, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str3), 2); heff_drop(v_t_2422); c_; }); c_; }))); heff_drop(v_t_2421); c_; }); c_; }))) {
    heff_drop(v_e_240);
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_f_242);
    return ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam0_clo);
  } else {
    V v_c_247 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(v_e_240, heff_get_n(v_st_241, 6, 7), heff_dup(v_f_242)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam1, 2, 2, (V[]){v_c_247, v_f_242});
  }
}
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_2411 = (g_heff_2ebuild_2eload_2emoduleOf(v_x_2410, v_f_242));
  V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str4), heff_dup(v_n_2411)), ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_str5));
  V v_t_2413 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_t_2412, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_x2_2414 = heff_get_n(v_t_2413, 2, 4);
  V v_x_2420;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    heff_drop(v_n_2411);
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2415 = heff_field(v_x2_2414, 0);
    V v_ru_24x2_2414_24Just = heff_take_reuse_n(v_x2_2414, 1ULL, 1);
    V v_name_2416 = heff_take_field(v_h_2415, 0);
    V v_error_2417 = heff_get_n(v_h_2415, 4, 5);
    switch (heff_tag_of(v_name_2416)) {
    case TAG_Nothing: {
      heff_drop(v_n_2411);
      heff_drop_cell(v_ru_24x2_2414_24Just, 1);
      heff_drop(v_error_2417);
      v_x_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_m_2418 = heff_field(v_name_2416, 0);
      heff_take_n(v_name_2416, 1ULL, 1);
      switch (heff_tag_of(v_error_2417)) {
      case TAG_Nothing: {
        if (heff_strEq_c_lent(v_m_2418, v_n_2411, 1)) {
          v_x_2420 = heff_tag_at_n(v_ru_24x2_2414_24Just, TAG_Just, 1, (V[]){v_n_2411});
        } else {
          heff_drop(v_n_2411);
          heff_drop_cell(v_ru_24x2_2414_24Just, 1);
          v_x_2420 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_Just: {
        heff_take_n(v_error_2417, 0ULL, 1);
        heff_drop(v_n_2411);
        heff_drop_cell(v_ru_24x2_2414_24Just, 1);
        heff_drop(v_m_2418);
        v_x_2420 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_error_2417);
      }
      break;
    }
    default: heff_nomatch(v_name_2416);
    }
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V f_ = v_k_249;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_lam2, 1, 2, (V[]){v_f_242, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_entry, 5, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139(V v_e_240, V v_st_241, V v_x2_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_c_247 = (g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287(heff_dup(v_e_240), v_st_241, heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_lam0, 1, 4, (V[]){v_e_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_e_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10, 5, "range");
Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V v_tok_240, V v_src_241, V v_d_242) {
top: ;
  V v_span_243 = heff_take_field(v_d_242, 3);
  V v_severity_244 = heff_take_field(v_d_242, 1);
  V v_note_245 = heff_take_field(v_d_242, 4);
  V v_msg_246 = heff_take_field(v_d_242, 2);
  V v_code_247 = heff_get_n(v_d_242, 0, 5);
  V v_t_248 = (g_heff_2elsp_2elsp_2erange(v_src_241, v_span_243));
  V v_t_249;
  switch (heff_tag_of(v_severity_244)) {
  case TAG_SError: {
    v_t_249 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_249 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_249 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_severity_244);
  }
  V v_t_2411;
  switch (heff_tag_of(v_note_245)) {
  case TAG_Nothing: {
    v_t_2411 = v_msg_246;
    break;
  }
  case TAG_Just: {
    V v_n_2410 = heff_field(v_note_245, 0);
    heff_take_n(v_note_245, 1ULL, 1);
    v_t_2411 = heff_strAppend(heff_strAppend(v_msg_246, ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0)), v_n_2410);
    break;
  }
  default: heff_nomatch(v_note_245);
  }
  V v_ys_2417;
  if (heff_intEq_c_lent(v_code_247, MK_INT(0LL), 2)) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_severity_244);
    heff_drop(v_code_247);
    v_ys_2417 = NTAG(TAG_Nil);
  } else {
    V v_t_2412;
    switch (heff_tag_of(v_severity_244)) {
    case TAG_SError: {
      v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1);
      break;
    }
    case TAG_SWarning: {
      v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2);
      break;
    }
    case TAG_SDebug: {
      v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3);
      break;
    }
    default: heff_nomatch(v_severity_244);
    }
    V v_t_2413 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_247)));
    V v_t_2414 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2413), ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4)));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2414), heff_intShow(v_code_247));
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5), heff_tag_at_n(v_tok_240, TAG_JString, 1, (V[]){v_t_2415})});
    v_ys_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  }
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_t_249})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8)})});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9), heff_tag_n(TAG_JString, 1, (V[]){v_t_2411})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_ys_2417})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10), v_t_248}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2421})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2422});
}
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ediagnostic_24tok1(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str5, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str6, 0, "");
Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_entry, 5, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(V v_tok_240, V v_e_241, V v_id_242, V v_code_243, V v_msg_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str0), heff_tag_at_n(v_tok_240, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str1)})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_243})});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_244})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str4), v_t_249}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str5), v_id_242}), v_t_2410});
  V v_t_2412 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2411})});
  V v_t_2413 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_str6); V a_1 = v_t_2412; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_2412, 1); r_; });
  V v_a_2414 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_241, v_t_2419});
}
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(a[0], a[1], a[2], a[3], a[4]);
}