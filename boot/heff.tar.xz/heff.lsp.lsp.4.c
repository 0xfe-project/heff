// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define TAG_Throw 56084
#define LBL_at 9882
#define LBL_children 257181584
#define LBL_claim 296100950
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_hashes 722717031
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_uri 325606
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1554102946x910234624(V, V, V);
V g_co_2eop_24s1554102946x910234624_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_clo;
V g_co_2eop_24s1554102946x910234624_24tok1(V, V, V, V);
V g_co_2eop_24s1554102946x910234624_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_24tok1_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220(V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260(V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(V);
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465(V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078(V, V);
V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2eescapeInto(V, V, V);
V g_json_2eescapeInto_entry(V self, V *a);
extern Clo g_json_2eescapeInto_clo;
V g_json_2erestInto_24s1422122160x502273793(V, V, V, V, V, V, V);
V g_json_2erestInto_24s1422122160x502273793_entry(V self, V *a);
extern Clo g_json_2erestInto_24s1422122160x502273793_clo;
V g_json_2ewriteInto(V, V);
V g_json_2ewriteInto_entry(V self, V *a);
extern Clo g_json_2ewriteInto_clo;
V g_list_2eany_24s1032636598x1013662416(V);
V g_list_2eany_24s1032636598x1013662416_entry(V self, V *a);
extern Clo g_list_2eany_24s1032636598x1013662416_clo;
V g_list_2ekeepIf_24s735270044x1288664053(V, V, V, V);
V g_list_2ekeepIf_24s735270044x1288664053_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s735270044x1288664053_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str1, 5, "start");
Clo g_heff_2elsp_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_start_242 = heff_take_field(v_sp_241, 0);
  V v_end_243 = heff_get_n(v_sp_241, 1, 2);
  V v_t_244 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_start_242)));
  V v_x_245 = v_start_242;
  V v_y_246 = v_end_243;
  V v_t_247;
  if (heff_intLe_c_lent(v_x_245, v_y_246, 0)) {
    heff_drop(v_x_245);
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = v_x_245;
  }
  V v_t_248 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_247));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str0), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str1), v_t_244}), v_t_249});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410});
}
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2erange(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str2, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str3, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str4, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str5, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2edeclsGo(V v_x1_240, V v_key_241, V v_above_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_above_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_245 = heff_take_field(v_l_243, 1);
    V v_at_246 = heff_get_n(v_l_243, 0, 2);
    V v_l_247 = heff_dup(v_text_245);
    if ((heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str0)) || heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str1)))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_text_245);
      heff_drop(v_l_247);
      V v_t_249;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_249 = v_at_246;
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop(v_at_246);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_244;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      goto top;
    } else {
      heff_drop(v_l_247);
      V v_l_2410 = heff_dup(v_text_245);
      V v_t_2414;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_2410, 0)))) {
        if (((heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : !(heff_unbox_word(heff_strByteAt_lent(v_l_2410, MK_INT(0LL), 2)) == ((int64_t)13ULL))))) {
          if ((heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str2)) ? 0 : !heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str3)))) {
            V v_t_2411 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2410, MK_INT(0LL)));
            V v_x1_2413 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_l_2410, MK_INT(0LL), v_t_2411, 2), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str4)) || ({ V v_t_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2410, MK_INT(0LL))); int c_ = ({ V v_t_2428 = heff_strSlice_lent(v_l_2410, MK_INT(0LL), v_t_2412, 2); int c_ = heff_strEq_c_lent(v_t_2428, ((V)&g_heff_2elsp_2elsp_2edeclsGo_str5), 2); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2412); c_; })));
            heff_drop(v_l_2410);
            heff_drop(v_t_2411);
            v_t_2414 = heff_bool(!(heff_dup(v_x1_2413) == NTAG(TAG_True)));
            heff_drop(v_x1_2413);
          } else {
            heff_drop(v_l_2410);
            v_t_2414 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l_2410);
          v_t_2414 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_l_2410);
        v_t_2414 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_heff_2elsp_2elsp_2ekeyOf(v_text_245));
        V v_x1_2416 = heff_bool(heff_strEq_c_lent(v_t_2415, v_key_241, 0));
        heff_drop(v_t_2415);
        if (!(heff_dup(v_x1_2416) == NTAG(TAG_True))) {
          heff_drop(v_x1_2416);
          V v_cut_2418;
          switch (heff_tag_of(v_above_242)) {
          case TAG_Nothing: {
            v_cut_2418 = heff_dup(v_at_246);
            break;
          }
          case TAG_Just: {
            V v_x_2417 = heff_field(v_above_242, 0);
            heff_take_n(v_above_242, 1ULL, 1);
            v_cut_2418 = v_x_2417;
            break;
          }
          default: heff_nomatch(v_above_242);
          }
          V v_n_2419 = v_at_246;
          HeffT2 v_t_2420 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_text_245));
          V v_t_2424;
          {
            V v_field_2421 = v_t_2420.f[0];
            V v_field_2422 = v_t_2420.f[1];
            V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_field_2421, heff_dup(v_n_2419)), heff_intAdd(v_field_2422, v_n_2419)});
            v_t_2424 = heff_rec_n(2, shape_cut__name, (V[]){v_cut_2418, v_t_2423});
          }
          V v_cell_2425 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
          V v_t_2426 = ({ V a_0 = v_text_245; V r_ = (g_heff_2elsp_2elsp_2ekeyOf(a_0)); heff_drop(v_text_245); r_; });
          V v_u_2427 = (g_heff_2elsp_2elsp_2edeclsGo_24dps(v_rest_244, v_t_2426, NTAG(TAG_Nothing), heff_dup(v_cell_2425)));
          heff_drop(v_u_2427);
          return v_cell_2425;
        } else {
          heff_drop(v_above_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_text_245);
          heff_drop(v_at_246);
          heff_drop(v_x1_2416);
          V t_0 = v_rest_244;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_above_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_text_245);
        heff_drop(v_at_246);
        heff_drop(v_t_2414);
        V t_0 = v_rest_244;
        V t_1 = v_key_241;
        V t_2 = NTAG(TAG_Nothing);
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2edeclsGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str0, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str1, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str2, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str3, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str5, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str6, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str7, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str9, 8, "children");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str10, 14, "selectionRange");
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_name_242 = heff_take_field(v_y_241, 0);
  V v_kind_243 = heff_take_field(v_y_241, 1);
  V v_span_244 = heff_take_field(v_y_241, 2);
  V v_selection_245 = heff_take_field(v_y_241, 3);
  V v_children_246 = heff_get_n(v_y_241, 4, 5);
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str0), heff_tag_n(TAG_JString, 1, (V[]){v_name_242})});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_243})});
  V v_s_249 = heff_take_field(v_span_244, 0);
  V v_x_2410 = heff_get_n(v_span_244, 1, 2);
  V v_y_2411 = heff_dup(heff_rfield(v_selection_245, 1));
  V v_t_2412;
  if (heff_intLe_c_lent(v_x_2410, v_y_2411, 0)) {
    heff_drop(v_x_2410);
    v_t_2412 = v_y_2411;
  } else {
    heff_drop(v_y_2411);
    v_t_2412 = v_x_2410;
  }
  V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_s_249)));
  V v_t_2414;
  if (heff_intLe_c_lent(v_s_249, v_t_2412, 0)) {
    heff_drop(v_s_249);
    v_t_2414 = v_t_2412;
  } else {
    heff_drop(v_t_2412);
    v_t_2414 = v_s_249;
  }
  V v_t_2415 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str2), v_t_2415}), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str3), v_t_2413}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2417})});
  V v_t_2419 = (g_heff_2elsp_2elsp_2erange(v_src_240, v_selection_245));
  V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2edocSymbol_lam0, 1, 1, (V[]){v_src_240}), v_children_246));
  V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str9), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str10), v_t_2419}), v_t_2435});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2436})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2437})});
}
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocSymbol(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2420 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_src_2421 = v_src_240;
  V v_m_2422 = v_m_2420;
  V v_name_2423 = heff_take_field(v_m_2422, 0);
  V v_kind_2424 = heff_take_field(v_m_2422, 1);
  V v_span_2425 = heff_get_n(v_m_2422, 2, 3);
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str5), heff_tag_n(TAG_JString, 1, (V[]){v_name_2423})});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_2424})});
  V v_t_2428 = (g_heff_2elsp_2elsp_2erange(v_src_2421, heff_dup(v_span_2425)));
  V v_t_2429 = ({ V a_0 = v_src_2421; V a_1 = v_span_2425; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_src_2421); r_; });
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str7), v_t_2429}), NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str8), v_t_2428}), v_t_2430});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2431})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2432});
}
Clo g_heff_2elsp_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244;
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL)))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) + ((int64_t)32ULL));
      v_t_244 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_243))));
    } else {
      v_t_244 = heff_strSlice_lent(v_s_240, v_i_241, heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))), 4);
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elowerGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str0, 31, "Write the module claim `module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str1, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str2, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str4, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str6, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str7, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str9, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str10, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str11, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str12, 11, "isPreferred");
Clo g_heff_2elsp_2elsp_2eclaimAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimAction_entry, 5, 0};

V g_heff_2elsp_2elsp_2eclaimAction(V v_uri_240, V v_src_241, V v_n_242, V v_ds_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_text_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_start_247 = heff_take_field(v_sp_245, 0);
    V v_end_248 = heff_get_n(v_sp_245, 1, 2);
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimAction_str0), v_n_242), ((V)&g_heff_2elsp_2elsp_2eclaimAction_str1));
    V v_t_2410 = heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str2), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str4)})});
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_243})});
    V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(v_start_247)));
    V v_x_2414 = v_start_247;
    V v_y_2415 = v_end_248;
    V v_t_2416;
    if (heff_intLe_c_lent(v_x_2414, v_y_2415, 0)) {
      heff_drop(v_x_2414);
      v_t_2416 = v_y_2415;
    } else {
      heff_drop(v_y_2415);
      v_t_2416 = v_x_2414;
    }
    V v_t_2417 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_2416));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str6), v_t_2417}), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str7), v_t_2413}), v_t_2418});
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str8), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str9), heff_tag_n(TAG_JString, 1, (V[]){v_text_246})});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    V v_t_2423 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str11), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str12), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2430});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2431})});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2432})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclaimAction(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4, 1, 0};
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam8(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry, 6, 0};

V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(V v_st_240, V v_f_241, V v_d_242, V v_cut_243, V v_z_244, V v_z_245) {
top: ;
  V v_docs_246 = heff_take_field(v_st_240, 0);
  V v_lib_247 = heff_get_n(v_st_240, 6, 7);
  V v_c_2442 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam0, 1, 4, (V[]){heff_dup(v_f_241), heff_dup(v_d_242), heff_dup(v_cut_243), v_docs_246}), v_lib_247, v_f_241));
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam8, 1, 3, (V[]){v_z_244, v_d_242, v_z_245})});
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_242 = heff_env(self)[0];
  V v_cut_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V v_t_2411 = heff_strSlice(heff_get_n(v_d_242, 1, 2), MK_INT(0LL), v_cut_243);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2415, 1, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_x_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    V v_err_2430 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Left = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    V v_t_2431 = heff_tag_at_n(v_ru_24x_2429_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2430})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2431));
  }
  case TAG_Right: {
    V v_x_2432 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam5, 2, 1, (V[]){v_x_2432});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2438, 0);
    V v_ru_24x_2438_24Right = heff_take_reuse_n(v_x_2438, 1ULL, 1);
    v_t_2441 = heff_tag_at_n(v_ru_24x_2438_24Right, TAG_Just, 1, (V[]){v_y_2440});
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V f_ = v_k_2437;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam6(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam7, 1, 1, (V[]){v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_cut_243 = heff_env(self)[2];
  V v_docs_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_p_248, v_f_241, 2)) {
    heff_drop(v_p_248);
    heff_drop(v_docs_246);
    return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam1, 2, 2, (V[]){v_d_242, v_cut_243});
  } else {
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_cut_243);
    HeffT2 v_t_2412 = ({ V a_0 = v_docs_246; V a_1 = v_p_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_246); r_; });
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop(v_p_248);
        V v_d_2415 = v_field_2414;
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam2, 2, 1, (V[]){v_d_2415});
      } else {
        heff_drop(v_field_2414);
        V v_path_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_248));
        V v_t_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2419; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2419); r_; });
        V v_a_2422 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2420, ((V)&g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3_clo)});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
        V v_c_2435 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4_clo)));
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam6, 2, 1, (V[]){v_c_2435});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_x_2454; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_errors_2446 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_full_2450 = heff_get_n(v_x_2449, 0, 2);
  V v_program_2451 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2450)));
  V v_t_2452 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2450));
  V v_t_2453 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_242, 1)), v_t_2452, v_errors_2446));
  V v_diags_2455 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam10, 1, 1, (V[]){v_d_242}), v_t_2453));
  V f_ = v_z_245;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2451, v_diags_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_paths_2444 = heff_take_field(v_x_2443, 2);
  V v_sources_2445 = heff_take_field(v_x_2443, 0);
  V v_errors_2446 = heff_get_n(v_x_2443, 1, 5);
  V v_t_2447 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_c_2448 = (g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(v_paths_2444, v_sources_2445, v_t_2447));
  V f_ = v_c_2448;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam9, 1, 3, (V[]){v_d_242, v_errors_2446, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str0, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str4, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str6, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str7, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str9, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str10, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str11, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str12, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str13, 1, "}");
Clo g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_entry, 2, 0};

V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078(V v_method_240, V v_params_241) {
top: ;
  V v_t_242 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str0), ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str1), MK_INT(0LL)));
  V v_acc_243 = heff_strAppend(heff_strAppend(v_t_242, ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str2)), ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str3));
  V v_t_244 = (g_json_2eescapeInto(heff_strAppend(v_acc_243, ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str4)), ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str5), MK_INT(0LL)));
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str6), heff_tag_n(TAG_JString, 1, (V[]){v_method_240})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str7), v_params_241}), NTAG(TAG_Nil)});
  V v_t_247 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str8); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str9); V a_3 = ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str10); V a_4 = ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str11); V a_5 = heff_strAppend(v_t_244, ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str12)); V b_6 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_246}); V r_ = (g_json_2erestInto_24s1422122160x502273793(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  V v_a_248 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_str13)), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2413});
}
V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry, 3, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2410, 0, 5), v_x_2412));
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam3, 1, 2, (V[]){v_x_2410, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_entry, 3, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465(V v_st_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989(heff_dup(v_st_240), heff_dup(v_c_241), v_y_245));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam1, 2, 4, (V[]){v_c_247, v_st_240, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465(v_st_240, v_c_241, v_rest_246));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam3, 1, 2, (V[]){v_k_249, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_lam2, 1, 5, (V[]){v_st_240, v_c_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str0, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str4, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str17, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str18, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str19, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str20, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str21, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str22, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str23, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str24, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str25, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str27, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str28, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str31, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str32, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str33, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str34, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str35, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str36, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str37, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str38, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str39, 1, "}");
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam6, 1, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_entry, 3, 0};

V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353(V v_st_240, V v_id_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam0, 2, 3, (V[]){v_c_243, heff_dup(v_id_241), v_st_240});
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_d_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2430, 1, 2)});
  V f_ = v_k_2432;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam5(V self, V *args) {
  V v_r_2436 = args[0];
  return v_r_2436;
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam7(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_x_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2448);
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    V v_err_2445 = heff_field(v_x_2444, 0);
    V v_ru_24x_2444_24Left = heff_take_reuse_n(v_x_2444, 1ULL, 1);
    V v_t_2446 = heff_tag_at_n(v_ru_24x_2444_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2445})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2446));
  }
  case TAG_Right: {
    V v_x_2447 = heff_field(v_x_2444, 0);
    heff_take_n(v_x_2444, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam7, 2, 1, (V[]){v_x_2447});
  }
  default: return heff_nomatch(v_x_2444);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456;
  switch (heff_tag_of(v_x_2453)) {
  case TAG_Left: {
    heff_take_n(v_x_2453, 0ULL, 1);
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2455 = heff_field(v_x_2453, 0);
    V v_ru_24x_2453_24Right = heff_take_reuse_n(v_x_2453, 1ULL, 1);
    v_t_2456 = heff_tag_at_n(v_ru_24x_2453_24Right, TAG_Just, 1, (V[]){v_y_2455});
    break;
  }
  default: heff_nomatch(v_x_2453);
  }
  V f_ = v_k_2452;
  args[0] = v_t_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam8(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_c_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2450;
  args[0] = v_hd_2451;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam9, 1, 1, (V[]){v_k_2452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam3(V self, V *args) {
  V v_q_2426 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2427 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_q_2426; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      heff_drop(v_q_2426);
      V v_d_2430 = v_field_2429;
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam4, 2, 1, (V[]){v_d_2430});
    } else {
      heff_drop(v_field_2429);
      V v_path_2434 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_q_2426));
      V v_t_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2434; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2434); r_; });
      V v_a_2437 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2435, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam5_clo)});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
      V v_c_2450 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam6_clo)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam8, 2, 1, (V[]){v_c_2450});
    }
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_d_2425 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2459 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2458, 0, 5)));
  return ({ V a_0 = v_st_240; V a_1 = v_id_241; V a_2 = v_d_2425; V a_3 = v_t_2459; V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_id_241); r_; });
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam11(V self, V *args) {
  V v_x_2473 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2473);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str0), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str1), MK_INT(0LL)));
    V v_acc_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str2)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str3));
    V v_t_249 = (g_json_2eescapeInto(heff_strAppend(v_acc_248, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str4)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str5), MK_INT(0LL)));
    V v_acc_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str6));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_acc_2410, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str7)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str8));
    V v_t_2412 = (g_json_2eescapeInto(v_t_2411, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str9), MK_INT(0LL)));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str10)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str11));
    V v_acc_2414 = ({ V a_0 = v_t_2413; V a_1 = v_id_241; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_241); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(v_acc_2414, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str12)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str13));
    V v_t_2416 = (g_json_2eescapeInto(v_t_2415, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str14), MK_INT(0LL)));
    V v_acc_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str15)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str16));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str17)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str18));
    V v_a_2419 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str19)), NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s1554102946x910234624(v_a_2419, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
  }
  case TAG_Just: {
    V v_f_2421 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_2422 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_2421));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_246_24Just, 1);
        V v_d_2425 = v_field_2424;
        V v_c_2457 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam3, 1, 1, (V[]){heff_dup(v_st_240)}), heff_dup(heff_rfield(v_st_240, 6)), v_f_2421));
        V f_ = v_c_2457;
        heff_room[0] = heff_dup(v_hd_244);
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam10, 1, 5, (V[]){v_st_240, v_id_241, v_d_2425, v_hd_244, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_f_2421);
        heff_drop(v_field_2424);
        V v_t_2460 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str20), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str21), MK_INT(0LL)));
        V v_acc_2461 = heff_strAppend(heff_strAppend(v_t_2460, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str22)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str23));
        V v_t_2462 = (g_json_2eescapeInto(heff_strAppend(v_acc_2461, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str24)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str25), MK_INT(0LL)));
        V v_acc_2463 = heff_strAppend(v_t_2462, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str26));
        V v_t_2464 = heff_strAppend(heff_strAppend(v_acc_2463, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str27)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str28));
        V v_t_2465 = (g_json_2eescapeInto(v_t_2464, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str29), MK_INT(0LL)));
        V v_t_2466 = heff_strAppend(heff_strAppend(v_t_2465, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str30)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str31));
        V v_acc_2467 = ({ V a_0 = v_t_2466; V a_1 = v_id_241; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_241); r_; });
        V v_t_2468 = heff_strAppend(heff_strAppend(v_acc_2467, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str32)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str33));
        V v_t_2469 = (g_json_2eescapeInto(v_t_2468, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str34), MK_INT(0LL)));
        V v_acc_2470 = heff_strAppend(heff_strAppend(v_t_2469, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str35)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str36));
        V v_t_2471 = heff_strAppend(heff_strAppend(v_acc_2470, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str37)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str38));
        V v_a_2472 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_str39)), NTAG(TAG_MkUnit)});
        return (g_co_2eop_24s1554102946x910234624_24tok1(v_ru_24x_246_24Just, v_a_2472, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam11, 1, 2, (V[]){v_k_245, v_st_240})));
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_lam1, 1, 4, (V[]){v_id_241, v_hd_244, v_k_245, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str2, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str3, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str4, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str5, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str6, 5, "E0157");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str7, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str8, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str9, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str10, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str11, 5, "E0157");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str13, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str14, 2, "\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str15, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str16, 1, " ");
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_entry, 2, 0};

V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_p_241});
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam2(V self, V *args) {
  V v_x_2439 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_d_2440 = v_d_2410;
  V v_text_2441 = heff_take_field(v_d_2440, 1);
  V v_uri_2442 = heff_get_n(v_d_2440, 0, 2);
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str7), NTAG(TAG_Nil)});
  HeffT2 v_t_2444 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str8), v_t_2443}); V a_1 = v_p_241; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2454;
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_it1_2447 = v_field_2446;
      switch (heff_tag_of(v_it1_2447)) {
      case TAG_JNull: {
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2447, 0ULL, 1);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2447, 0ULL, 1);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2447, 0ULL, 1);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2447, 0ULL, 1);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2452 = heff_field(v_it1_2447, 0);
        heff_take_n(v_it1_2447, 1ULL, 1);
        v_t_2454 = v_xs_2452;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2447, 0ULL, 1);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2447);
      }
    } else {
      heff_drop(v_field_2446);
      v_t_2454 = NTAG(TAG_Nil);
    }
  }
  V v_ds_2455 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str9); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str10); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str11); V a_3 = v_t_2454; V r_ = (g_list_2ekeepIf_24s735270044x1288664053(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_x3_2456 = v_x_2439;
  V v_x_2485;
  switch (heff_tag_of(v_x3_2456)) {
  case TAG_Nothing: {
    heff_drop(v_text_2441);
    heff_drop(v_uri_2442);
    heff_drop(v_ds_2455);
    v_x_2485 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_n_2457 = heff_field(v_x3_2456, 0);
    V v_ru_24x3_2456_24Just = heff_take_reuse_n(v_x3_2456, 1ULL, 1);
    V v_src_2458 = heff_dup(v_text_2441);
    V v_n_2459 = heff_dup(v_n_2457);
    V v_t_2460 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_text_2441), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_x3_2461 = heff_get_n(v_t_2460, 2, 4);
    V v_t_2482;
    switch (heff_tag_of(v_x3_2461)) {
    case TAG_Nothing: {
      V v_t_2462;
      if (heff_strEq_c(v_src_2458, ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str12))) {
        v_t_2462 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str13);
      } else {
        v_t_2462 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str14);
      }
      V v_t_2463 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str15), v_n_2459), v_t_2462);
      v_t_2482 = heff_tag_at_n(v_ru_24x3_2456_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), v_t_2463})});
      break;
    }
    case TAG_Just: {
      V v_h_2464 = heff_field(v_x3_2461, 0);
      heff_take_n(v_x3_2461, 1ULL, 1);
      V v_t_2465 = heff_dup(heff_rfield(v_h_2464, 0));
      switch (heff_tag_of(v_t_2465)) {
      case TAG_Nothing: {
        heff_drop(v_src_2458);
        V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_h_2464, 3)), 0, 2);
        V v_t_2467 = heff_get_n(heff_get_n(v_h_2464, 3, 5), 0, 2);
        V v_t_2468 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_t_2466, MK_INT(6LL)), heff_intAdd(v_t_2467, MK_INT(6LL))});
        V v_t_2469 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str16), v_n_2459)});
        v_t_2482 = heff_tag_at_n(v_ru_24x3_2456_24Just, TAG_Just, 1, (V[]){v_t_2469});
        break;
      }
      case TAG_Just: {
        V v_m_2470 = heff_field(v_t_2465, 0);
        heff_take_n(v_t_2465, 1ULL, 1);
        if (heff_strEq_c_lent(v_m_2470, v_n_2459, 0)) {
          heff_drop_cell(v_ru_24x3_2456_24Just, 1);
          heff_drop(v_src_2458);
          heff_drop(v_n_2459);
          heff_drop_rec(v_h_2464, 5);
          heff_drop(v_m_2470);
          v_t_2482 = NTAG(TAG_Nothing);
        } else {
          V v_src_2471 = v_src_2458;
          V v_h_2472 = v_h_2464;
          V v_m_2473 = v_m_2470;
          V v_t_2474 = heff_get_n(heff_dup(heff_rfield(v_h_2472, 3)), 0, 2);
          V v_from_2475 = heff_intAdd(v_t_2474, MK_INT(6LL));
          V v_t_2476 = heff_get_n(heff_get_n(v_h_2472, 3, 5), 1, 2);
          V v_j_2477 = heff_strFind(heff_dup(v_m_2473), heff_strSlice_lent(v_src_2471, v_from_2475, v_t_2476, 5), MK_INT(0LL));
          V v_t_2478;
          if (heff_intLt_c_lent(v_j_2477, MK_INT(0LL), 2)) {
            heff_drop(v_j_2477);
            v_t_2478 = MK_INT(1LL);
          } else {
            v_t_2478 = v_j_2477;
          }
          V v_at_2479 = heff_intAdd(v_from_2475, v_t_2478);
          V v_e_2480 = heff_intAdd(heff_dup(v_at_2479), heff_strLength(v_m_2473));
          V v_t_2481 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_at_2479, v_e_2480}), v_n_2459});
          v_t_2482 = heff_tag_at_n(v_ru_24x3_2456_24Just, TAG_Just, 1, (V[]){v_t_2481});
        }
        break;
      }
      default: heff_nomatch(v_t_2465);
      }
      break;
    }
    default: heff_nomatch(v_x3_2461);
    }
    switch (heff_tag_of(v_t_2482)) {
    case TAG_Nothing: {
      heff_drop(v_text_2441);
      heff_drop(v_uri_2442);
      heff_drop(v_ds_2455);
      heff_drop(v_n_2457);
      v_x_2485 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2483 = heff_field(v_t_2482, 0);
      heff_take_n(v_t_2482, 1ULL, 1);
      V v_t_2484 = ({ V a_0 = v_uri_2442; V a_1 = v_text_2441; V a_2 = v_n_2457; V a_3 = v_ds_2455; V a_4 = v_x_2483; V r_ = (g_heff_2elsp_2elsp_2eclaimAction(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_2441); r_; });
      v_x_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2482);
    }
    break;
  }
  default: heff_nomatch(v_x3_2456);
  }
  V f_ = v_k_244;
  args[0] = v_x_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_p_241);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_d_2410 = v_field_249;
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str0), NTAG(TAG_Nil)});
        HeffT2 v_t_2412 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str1), v_t_2411}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          V v_t_2422;
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_it1_2415 = v_field_2414;
            switch (heff_tag_of(v_it1_2415)) {
            case TAG_JNull: {
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            case TAG_JArray: {
              V v_xs_2420 = heff_field(v_it1_2415, 0);
              heff_take_n(v_it1_2415, 1ULL, 1);
              v_t_2422 = ({ V a_0 = v_xs_2420; V r_ = (g_list_2eany_24s1032636598x1013662416(a_0)); heff_drop(v_xs_2420); r_; });
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2415, 0ULL, 1);
              v_t_2422 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_it1_2415);
            }
          } else {
            heff_drop(v_field_2414);
            v_t_2422 = NTAG(TAG_True);
          }
          if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
            heff_drop(v_t_2422);
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str2), NTAG(TAG_Nil)});
            HeffT2 v_t_2424 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str3), v_t_2423}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2434;
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              if ((v_tag_2425 == ((int64_t)0ULL))) {
                V v_it1_2427 = v_field_2426;
                switch (heff_tag_of(v_it1_2427)) {
                case TAG_JNull: {
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JArray: {
                  V v_xs_2432 = heff_field(v_it1_2427, 0);
                  heff_take_n(v_it1_2427, 1ULL, 1);
                  v_t_2434 = v_xs_2432;
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2427, 0ULL, 1);
                  v_t_2434 = NTAG(TAG_Nil);
                  break;
                }
                default: heff_nomatch(v_it1_2427);
                }
              } else {
                heff_drop(v_field_2426);
                v_t_2434 = NTAG(TAG_Nil);
              }
            }
            V v_x1_2435 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str4); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str5); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_str6); V a_3 = v_t_2434; V r_ = (g_list_2ekeepIf_24s735270044x1288664053(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
            switch (heff_tag_of(v_x1_2435)) {
            case TAG_Nil: {
              heff_drop_rec(v_st_240, 7);
              heff_drop(v_p_241);
              heff_drop(v_hd_243);
              heff_drop(v_f_246);
              heff_drop(v_d_2410);
              V f_ = v_k_244;
              args[0] = NTAG(TAG_Nil);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            }
            case TAG_Cons: {
              heff_take_n(v_x1_2435, 0ULL, 2);
              V v_c_2438 = (g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260(v_st_240, v_f_246));
              V f_ = v_c_2438;
              heff_room[0] = v_hd_243;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam2, 1, 3, (V[]){v_d_2410, v_p_241, v_k_244});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
            default: return heff_nomatch(v_x1_2435);
            }
          } else {
            heff_drop_rec(v_st_240, 7);
            heff_drop(v_p_241);
            heff_drop(v_hd_243);
            heff_drop(v_f_246);
            heff_drop(v_d_2410);
            heff_drop(v_t_2422);
            V f_ = v_k_244;
            args[0] = NTAG(TAG_Nil);
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        }
      } else {
        heff_drop_rec(v_st_240, 7);
        heff_drop(v_p_241);
        heff_drop(v_hd_243);
        heff_drop(v_f_246);
        heff_drop(v_field_249);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_lam1, 1, 4, (V[]){v_k_244, v_st_240, v_p_241, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10, 5, "range");
Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V v_tok_240, V v_src_241, V v_d_242) {
top: ;
  V v_span_243 = heff_take_field(v_d_242, 3);
  V v_severity_244 = heff_take_field(v_d_242, 1);
  V v_note_245 = heff_take_field(v_d_242, 4);
  V v_msg_246 = heff_take_field(v_d_242, 2);
  V v_code_247 = heff_get_n(v_d_242, 0, 5);
  V v_t_248 = (g_heff_2elsp_2elsp_2erange(v_src_241, v_span_243));
  V v_t_249;
  switch (heff_tag_of(v_severity_244)) {
  case TAG_SError: {
    v_t_249 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_249 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_249 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_severity_244);
  }
  V v_t_2411;
  switch (heff_tag_of(v_note_245)) {
  case TAG_Nothing: {
    v_t_2411 = v_msg_246;
    break;
  }
  case TAG_Just: {
    V v_n_2410 = heff_field(v_note_245, 0);
    heff_take_n(v_note_245, 1ULL, 1);
    v_t_2411 = heff_strAppend(heff_strAppend(v_msg_246, ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0)), v_n_2410);
    break;
  }
  default: heff_nomatch(v_note_245);
  }
  V v_ys_2417;
  if (heff_intEq_c_lent(v_code_247, MK_INT(0LL), 2)) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_severity_244);
    heff_drop(v_code_247);
    v_ys_2417 = NTAG(TAG_Nil);
  } else {
    V v_t_2412;
    switch (heff_tag_of(v_severity_244)) {
    case TAG_SError: {
      v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1);
      break;
    }
    case TAG_SWarning: {
      v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2);
      break;
    }
    case TAG_SDebug: {
      v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3);
      break;
    }
    default: heff_nomatch(v_severity_244);
    }
    V v_t_2413 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_247)));
    V v_t_2414 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2413), ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4)));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2414), heff_intShow(v_code_247));
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5), heff_tag_at_n(v_tok_240, TAG_JString, 1, (V[]){v_t_2415})});
    v_ys_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  }
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_t_249})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8)})});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9), heff_tag_n(TAG_JString, 1, (V[]){v_t_2411})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_ys_2417})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10), v_t_248}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2421})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2422});
}
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ediagnostic_24tok1(a[0], a1, a[2]); heff_drop(a1); return r;
}