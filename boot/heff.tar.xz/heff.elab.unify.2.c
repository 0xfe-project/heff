// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkField 62648
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_dom 309180
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_mty 317996
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_co_2eplus_24s973240257x441859337_get(void);
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V, V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_clo;
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo;
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_get(void);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany_24s1817246263x1083513945(V, V);
V g_list_2eany_24s1817246263x1083513945_entry(V self, V *a);
extern Clo g_list_2eany_24s1817246263x1083513945_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
Clo g_heff_2eelab_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eelab_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_243 = (g_list_2eany_24s1817246263x1083513945(heff_dup(v_x_241), v_xs_242));
    if ((heff_dup(v_x1_243) == NTAG(TAG_True))) {
      heff_drop(v_x1_243);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_243);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2edistinct(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry, 4, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V v_i_240, V v_f_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_i_240 = t_0;
    v_f_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eanyL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eunify_2eappendL_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eelab_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eunify_2econcatMapL(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eunify_2eappendL(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2econcatMapL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eelab_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return v_t_241;
  } else {
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_249 = heff_field(v_t_241, 1);
      heff_take_n(v_t_241, 2ULL, 2);
      switch (heff_tag_of(v_it2_249)) {
      case TAG_MkAbs: {
        V v_b_2411 = heff_field(v_it2_249, 1);
        heff_take_n(v_it2_249, 2ULL, 2);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2412 = heff_field(v_it2_249, 0);
        heff_take_n(v_it2_249, 1ULL, 1);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2412;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_249);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitBytes: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitRune: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFixed: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat32: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
}
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estripLams(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_a_245)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_245, 0);
        heff_take_n(v_a_245, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          V v_a_248 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          v_t_2410 = heff_intEq(v_a_247, v_a_248);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_247);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          heff_take_n(v_a_246, 0ULL, 1);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
      } else {
        heff_drop(v_t_2410);
        v_t_2411 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_2412;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam0, 2, 0};
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eelab_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam1, 2, 8, (V[]){v_g_240, v_m_241, v_pr_2413, v_ty_2411, v_pr_242, v_i_243, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam3(V self, V *args) {
  V v_u_2418 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_ty_2411;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_v_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  return v_v_2419;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), heff_dup(v_i_243));
  V v_v_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2417}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2421 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam4, 1, 1, (V[]){v_v_2419})}), v_rest_249));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam5, 1, 2, (V[]){v_k_2415, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_i_243 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411), heff_dup(v_hd_2414), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2414, v_k_2415})));
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})});
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  V f_ = v_t_2418;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2429));
  V f_ = v_t_2430;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2436, v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_fty_2433 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2434 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2437 = heff_tr(heff_call(v_fty_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2438 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2437)));
  V v_t_2450;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2441 = heff_field(v_t_2438, 1);
    heff_take_n(v_t_2438, 2ULL, 4);
    heff_drop(v_t_2437);
    v_t_2450 = v_dom_2441;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2438, 0ULL, 3);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeInt: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeString: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeRune: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_NoRules: {
    v_t_2450 = v_t_2437;
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_c_2451 = (g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120(v_g_240, v_m_241, v_pr_242, v_t_2450, v_body_2434));
  V f_ = v_c_2451;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam7, 1, 2, (V[]){v_k_245, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam11(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2466;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam10(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_240, v_m_241, v_pr_242, v_v_2464, v_hd_2465, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam11, 1, 1, (V[]){v_k_2466})));
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam12(V self, V *args) {
  V v_x_2469 = args[0];
  V v_k_2461 = heff_env(self)[0];
  V v_k_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2461;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2458, v_x_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam9(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_x_2459 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_k_2458 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2468;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nom: {
    V v_v_2462 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2462}));
    break;
  }
  case TAG_Describe: {
    V v_v_2463 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2463}));
    break;
  }
  case TAG_Become: {
    V v_v_2464 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam10, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2464});
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V f_ = v_t_2468;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam12, 1, 2, (V[]){v_k_2461, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam8(V self, V *args) {
  V v_p_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_p_2457, 0);
    V v_x_2459 = heff_field(v_p_2457, 1);
    heff_take_n(v_p_2457, 3ULL, 2);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam9, 2, 5, (V[]){v_x_2459, v_g_240, v_m_241, v_pr_242, v_k_2458});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam13(V self, V *args) {
  V v_x_2471 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2471)));
  V v_t_2473 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2471));
  V v_t_2474 = (g_list_2emap_24s1173914895x100384474(v_x_2471));
  V v_t_2475 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2472), v_t_2473, heff_arrayFromList(v_t_2474)});
  V v_x_2476 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2475});
  V f_ = v_k_245;
  args[0] = v_x_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2416;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2420 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2420;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2423 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2423, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2423);
        V v_t_2425 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2426 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2426}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2427;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(v_g_240, v_m_241, v_pr_242, v_m_27_2423, v_sp_2411, v_hd_244, v_k_245));
      }
    }
    case TAG_HError: {
      V v_c_2428 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2428;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2431 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(v_g_240, v_m_241, v_pr_242, v_t_2431, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2433 = heff_field(v_x_249, 0);
    V v_body_2434 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_call(heff_dup(v_fty_2433), 1, (V[]){NTAG(TAG_MkUnit)}));
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2435, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam6, 1, 7, (V[]){v_fty_2433, v_g_240, v_m_241, v_pr_242, v_body_2434, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2453 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2454 = heff_arrayToList(heff_take_field(v_d_2453, 0));
    V v_t_2455 = heff_arrayToList(heff_get_n(v_d_2453, 2, 3));
    V v_t_2456 = (g_heff_2eutil_2edict_2ezipKV(v_t_2454, v_t_2455));
    V v_c_2470 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2456));
    V f_ = v_c_2470;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_lam13, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 8); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam4(V self, V *args) {
  V v_c_2458 = args[0];
  return heff_get_n(v_c_2458, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam7(V self, V *args) {
  V v_c_2465 = args[0];
  return heff_get_n(v_c_2465, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2469 = ({ V a_0 = v_x_2468; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2468); r_; });
  V v_t_2470 = heff_tr(heff_call(heff_get_n(v_t_2469, 1, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
  return ({ V a_0 = v_t_2470; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(a_0, a_1, a_2)); heff_drop(v_t_2470); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam6(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2464);
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam7_clo)})});
  V v_t_2467 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2466}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2467;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam5(V self, V *args) {
  V v_x_2461 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2462 = ({ V a_0 = v_x_2461; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2461); r_; });
  V v_t_2463 = heff_tr(heff_call(heff_get_n(v_t_2462, 1, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
  return ({ V a_0 = v_t_2463; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2457;
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop(v_t_2435);
    v_t_2457 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2435);
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2437 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2437)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2457 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2437);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
  }
  if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_t_2457);
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam4_clo)})});
    V v_t_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2459}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2460;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2457);
    V v_t_2492;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2472 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2473 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_t1_2472)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2472, 0ULL, 1);
        heff_drop(v_sp_2473);
        v_t_2492 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2472, 0ULL, 1);
        heff_drop(v_sp_2473);
        v_t_2492 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2479 = heff_field(v_t1_2472, 0);
        V v_ru_24t1_2472_24HMeta = heff_take_reuse_n(v_t1_2472, 1ULL, 1);
        v_t_2492 = heff_tag_at_n(v_ru_24t1_2472_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2479, v_sp_2473})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2473);
        v_t_2492 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2472);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_t_2492)) {
    case TAG_Nothing: {
      V v_t_24114;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2494 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_2495 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_t1_2494)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2494, 0ULL, 1);
          heff_drop(v_sp_2495);
          v_t_24114 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2494, 0ULL, 1);
          heff_drop(v_sp_2495);
          v_t_24114 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_24101 = heff_field(v_t1_2494, 0);
          V v_ru_24t1_2494_24HMeta = heff_take_reuse_n(v_t1_2494, 1ULL, 1);
          v_t_24114 = heff_tag_at_n(v_ru_24t1_2494_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24101, v_sp_2495})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2495);
          v_t_24114 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_2494);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_t_24114)) {
      case TAG_Nothing: {
        return (g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842(v_g_240, v_cs_241, v_x_249, v_x_2413, v_hd_244, v_k_245));
      }
      case TAG_Just: {
        V v_it1_24115 = heff_field(v_t_24114, 0);
        V v_ru_24t_24114_24Just = heff_take_reuse_n(v_t_24114, 1ULL, 1);
        switch (heff_tag_of(v_it1_24115)) {
        case TAG_MkPair: {
          V v_m_24116 = heff_field(v_it1_24115, 0);
          V v_sp_24117 = heff_field(v_it1_24115, 1);
          heff_take_n(v_it1_24115, 3ULL, 2);
          V v_rhs_24136;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24123 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24t_24114_24Just, 1);
            v_rhs_24136 = heff_tr(heff_call(v_el_24123, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24155;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24142 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24155 = heff_tr(heff_call(v_el_24142, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VFixed: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return (g_heff_2eelab_2eunify_2esolveF_24s863089x19463346(v_g_240, v_cs_241, v_m_24116, v_sp_24117, v_rhs_24136, v_self_24155, v_hd_244, v_k_245));
        }
        default: return heff_nomatch(v_it1_24115);
        }
      }
      default: return heff_nomatch(v_t_24114);
      }
    }
    case TAG_Just: {
      V v_it1_24156 = heff_field(v_t_2492, 0);
      V v_ru_24t_2492_24Just = heff_take_reuse_n(v_t_2492, 1ULL, 1);
      switch (heff_tag_of(v_it1_24156)) {
      case TAG_MkPair: {
        V v_m_24157 = heff_field(v_it1_24156, 0);
        V v_sp_24158 = heff_field(v_it1_24156, 1);
        heff_take_n(v_it1_24156, 3ULL, 2);
        V v_rhs_24177;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24164 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24t_2492_24Just, 1);
          v_rhs_24177 = heff_tr(heff_call(v_el_24164, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24196;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24183 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24196 = heff_tr(heff_call(v_el_24183, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VFixed: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return (g_heff_2eelab_2eunify_2esolveF_24s863089x19463346(v_g_240, v_cs_241, v_m_24157, v_sp_24158, v_rhs_24177, v_self_24196, v_hd_244, v_k_245));
      }
      default: return heff_nomatch(v_it1_24156);
      }
    }
    default: return heff_nomatch(v_t_2492);
    }
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam21(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam21, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam22(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam23(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam20(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam19(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop(v_t_2418);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          heff_drop(v_t_2421);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam1_clo);
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam2, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
        }
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam3, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam4, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam5, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2447 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2448 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam6, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        V v_sq_27_2453 = heff_field(v_sp_27_245, 0);
        V v_v_27_2454 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2455 = (g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2447, v_h_27_244, v_sq_27_2453));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam7, 2, 5, (V[]){v_c_2455, v_g_240, v_cs_241, v_v_2448, v_v_27_2454});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam9, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam10, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2473 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2474 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam11, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam12, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        V v_sq_27_2485 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2486 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2487 = (g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2473, heff_dup(v_h_27_244), v_sq_27_2485));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam13, 2, 8, (V[]){v_c_2487, v_x_2474, v_x_27_2486, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam15, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24101 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_24102 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_24103 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam16, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam17, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam18, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        V v_sq_27_24120 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24121 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_24122 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_24123 = (g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_24101, heff_dup(v_h_27_244), v_sq_27_24120));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam19, 2, 11, (V[]){v_c_24123, v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_24103, v_v_27_24122});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_2430, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get_n(v_hd_2430, 1, 3);
  args[0] = v_t_2433;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2439;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2446 = heff_tr(heff_call(heff_take_field(v_hd_2443, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2446;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2451 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_2449, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})}));
  V f_ = heff_get_n(v_hd_2449, 1, 3);
  args[0] = v_t_2452;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2448 = heff_env(self)[2];
  V v_v_27_2454 = heff_env(self)[3];
  V v_hd_2456 = heff_env(self)[4];
  V v_k_2457 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s973240257x441859337_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_get()), v_g_240, v_cs_241, v_v_2448, v_v_27_2454));
  V f_ = v_t_2459;
  heff_room[0] = v_hd_2456;
  heff_room[1] = v_k_2457;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam7(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2448 = heff_env(self)[3];
  V v_v_27_2454 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2455;
  args[0] = heff_dup(v_hd_2456);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2448, v_v_27_2454, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2465 = heff_tr(heff_call(heff_take_field(v_hd_2462, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})}));
  V f_ = heff_get_n(v_hd_2462, 1, 3);
  args[0] = v_t_2465;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam10(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2471 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})}));
  V f_ = heff_get_n(v_hd_2469, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam11(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2477 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2478;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k2_2482 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_2481, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_get_n(v_hd_2481, 1, 3);
  args[0] = v_t_2484;
  args[1] = v_k2_2482;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam14(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_x_27_2486 = heff_env(self)[1];
  V v_k_2489 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_2488 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2490);
  if (heff_strEq_c(v_x_2474, v_x_27_2486)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop_rec(v_hd_2488, 3);
    V f_ = v_k_2489;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2492 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_2488, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})}));
    V f_ = heff_get_n(v_hd_2488, 1, 3);
    heff_room[0] = v_t_2493;
    heff_room[1] = v_k_2489;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam13(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_x_2474 = heff_env(self)[1];
  V v_x_27_2486 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2487;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam14, 1, 9, (V[]){v_x_2474, v_x_27_2486, v_k_2489, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam15(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_2497, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})}));
  V f_ = heff_get_n(v_hd_2497, 1, 3);
  args[0] = v_t_24100;
  args[1] = v_k2_2498;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam16(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k2_24105 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24106 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24107 = heff_tr(heff_call(heff_take_field(v_hd_24104, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})}));
  V f_ = heff_get_n(v_hd_24104, 1, 3);
  args[0] = v_t_24107;
  args[1] = v_k2_24105;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam17(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24112 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24113 = heff_tr(heff_call(heff_take_field(v_hd_24110, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})}));
  V f_ = heff_get_n(v_hd_24110, 1, 3);
  args[0] = v_t_24113;
  args[1] = v_k2_24111;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam18(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k2_24117 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24118 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24119 = heff_tr(heff_call(heff_take_field(v_hd_24116, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24118})}));
  V f_ = heff_get_n(v_hd_24116, 1, 3);
  args[0] = v_t_24119;
  args[1] = v_k2_24117;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam21(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  heff_drop(v_hd_24128);
  V f_ = v_k_24129;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam22(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24132 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24133 = heff_tr(heff_call(heff_take_field(v_hd_24130, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24132})}));
  V f_ = heff_get_n(v_hd_24130, 1, 3);
  args[0] = v_t_24133;
  args[1] = v_k2_24131;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam23(V self, V *args) {
  V v_x_24135 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24103 = heff_env(self)[2];
  V v_v_27_24122 = heff_env(self)[3];
  V v_hd_24124 = heff_env(self)[4];
  V v_k_24125 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24135);
  V v_t_24136 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s973240257x441859337_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_get()), v_g_240, v_cs_241, v_v_24103, v_v_27_24122));
  V f_ = v_t_24136;
  heff_room[0] = v_hd_24124;
  heff_room[1] = v_k_24125;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam20(V self, V *args) {
  V v_x_24126 = args[0];
  V v_x_24102 = heff_env(self)[0];
  V v_x_27_24121 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_24124 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  V v_k_24125 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_24126);
  V v_t_24134;
  if (heff_strEq_c(v_x_24102, v_x_27_24121)) {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_t_24134 = ((V)&g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam21_clo);
  } else {
    v_t_24134 = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam22, 2, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
  }
  V f_ = v_t_24134;
  heff_room[0] = heff_dup(v_hd_24124);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam23, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24103, v_v_27_24122, v_hd_24124, v_k_24125});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam19(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  V v_x_27_24121 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24123;
  args[0] = heff_dup(v_hd_24124);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_lam20, 1, 12, (V[]){v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24124, v_g_240, v_v_24103, v_v_27_24122, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}