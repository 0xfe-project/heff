// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VOpaque 37311
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ren 322325
#define LBL_selfKey 62480824
#define LBL_ty 10476
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
V g_heff_2eelab_2eunify_2eappendL_24tok2(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24tok2_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V, V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_clo;
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo;
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_list_2eany_24s781693278x668067139(V, V);
V g_list_2eany_24s781693278x668067139_entry(V self, V *a);
extern Clo g_list_2eany_24s781693278x668067139_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eelab_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_243 = (g_list_2eany_24s781693278x668067139(heff_dup(v_x_241), v_xs_242));
    if (!(heff_dup(v_x1_243) == NTAG(TAG_True))) {
      heff_drop(v_x1_243);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    } else {
      heff_drop(v_x1_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2edistinct(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry, 4, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V v_i_240, V v_f_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_i_240 = t_0;
    v_f_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eanyL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eunify_2eappendL_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eelab_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eunify_2econcatMapL(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eunify_2eappendL(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2econcatMapL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eelab_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return v_t_241;
  } else {
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_248 = heff_field(v_t_241, 1);
      heff_take_n(v_t_241, 2ULL, 2);
      switch (heff_tag_of(v_it2_248)) {
      case TAG_MkAbs: {
        V v_b_2410 = heff_field(v_it2_248, 1);
        heff_take_n(v_it2_248, 2ULL, 2);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2411 = heff_field(v_it2_248, 0);
        heff_take_n(v_it2_248, 1ULL, 1);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_248);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitBytes: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitRune: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFixed: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat32: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
}
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estripLams(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_dup(heff_rfield(v_entry_243, 3)), MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_dup(heff_rfield(v_entry_243, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V f_ = v_k_247;
  args[0] = v_v_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2421 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_storeM_242, v_t_2421, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam3, 1, 2, (V[]){v_k_247, v_v_2426})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = (g_list_2emap_24s1947501783x1475115781(heff_dup(v_n_244), MK_INT(1LL), v_kept_245));
  V v_t_2420 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2418, heff_arrayFromList(v_t_2419), v_x_249});
  V v_t_2421 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2420));
  V v_x1_2422 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2421), NTAG(TAG_LNil)));
  V v_v_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_v_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_v_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_v_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  return (g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(heff_dup(v_storeM_242), heff_dup(v_v_2426), heff_dup(v_t_2421), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam2, 1, 5, (V[]){v_storeM_242, v_t_2421, v_hd_246, v_k_247, v_v_2426})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_t_2417;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      v_t_2417 = v_x_2414;
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_x11_2415 = v_field_2413;
        heff_drop(v_x11_2415);
        v_t_2417 = heff_abandon();
      } else {
        V v_x_2416 = v_field_2413;
        v_t_2417 = v_x_2416;
      }
    }
    return (g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(v_entry_243, v_t_2410, v_t_2417, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_lam1, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})));
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_pr_242, 2), heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam2, 2, 5, (V[]){v_v_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_2411, v_v_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_v_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_v_2416)) {
  case TAG_Nom: {
    V v_v_2419 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419}));
    break;
  }
  case TAG_Describe: {
    V v_v_2420 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2420}));
    break;
  }
  case TAG_Become: {
    V v_v_2421 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2421});
    break;
  }
  default: heff_nomatch(v_v_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_v_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_v_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430}));
    break;
  }
  case TAG_Describe: {
    V v_v_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2431}));
    break;
  }
  case TAG_Become: {
    V v_v_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam14, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam15, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam17(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam17, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam1, 1, 7, (V[]){v_hd_245, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_k_246})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam4(V self, V *args) {
  V v_a_2422 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2422)) {
  case TAG_PVar: {
    V v_l_2423 = heff_field(v_a_2422, 0);
    heff_take_n(v_a_2422, 1ULL, 1);
    HeffT2 v_t_2424 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2423; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2425 == ((int64_t)0ULL)) ? ({ V v_x_2427 = heff_dup(v_field_2426); int c_ = 0; heff_drop(v_x_2427); c_; }) : 1));
      heff_drop(v_field_2426);
      return v_ret_24bool;
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_a_2422);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam6(V self, V *args) {
  V v_i_2431 = args[0];
  V v_a_2432 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2432)) {
  case TAG_PVar: {
    V v_l_2433 = heff_field(v_a_2432, 0);
    V v_ru_24a_2432_24PVar = heff_take_reuse_n(v_a_2432, 1ULL, 1);
    HeffT2 v_t_2434 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2433; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_x_2437 = v_field_2436;
        heff_drop(v_x_2437);
        return heff_tag_at_n(v_ru_24a_2432_24PVar, TAG_Just, 1, (V[]){v_i_2431});
      } else {
        heff_drop(v_i_2431);
        heff_drop_cell(v_ru_24a_2432_24PVar, 1);
        heff_drop(v_field_2436);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2431);
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2432);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2441 = ({ V a_0 = v_x_2440; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_242, v_v_2441, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_args_2421 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2421));
  V v_t_2438 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2421));
  V v_t_2439 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2438));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2429, v_t_2430, v_t_2439, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam8(V self, V *args) {
  V v_c_2443 = args[0];
  return heff_get_n(v_c_2443, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2447 = ({ V a_0 = v_x_2446; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2446); r_; });
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2450 = v_field_2449;
      V f_ = v_k_2442;
      args[0] = v_e_2450;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2449);
      V v_t_2451 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2452}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2453;
      heff_room[1] = v_k_2442;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam13(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2462);
  V v_t_2464 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2461);
  V f_ = v_k_2463;
  args[0] = heff_intSub(v_t_2464, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam14(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k2_2466 = args[1];
  V v_bind_2467 = heff_take_field(v_hd_2465, 1);
  V v_malg_2468 = heff_get_n(v_hd_2465, 2, 3);
  V v_t_2469 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tr(heff_call(v_malg_2468, 1, (V[]){v_t_2470}));
  V f_ = v_bind_2467;
  args[0] = v_t_2471;
  args[1] = v_k2_2466;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam15(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k2_2473 = args[1];
  V v_bind_2474 = heff_take_field(v_hd_2472, 1);
  V v_malg_2475 = heff_get_n(v_hd_2472, 2, 3);
  V v_t_2476 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_call(v_malg_2475, 1, (V[]){v_t_2477}));
  V f_ = v_bind_2474;
  args[0] = v_t_2478;
  args[1] = v_k2_2473;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam12(V self, V *args) {
  V v_a_2456 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2456)) {
  case TAG_PVar: {
    V v_l_2457 = heff_field(v_a_2456, 0);
    heff_take_n(v_a_2456, 1ULL, 1);
    HeffT2 v_t_2458 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_pr_242, 2), v_l_2457));
    {
      V v_field_2460 = v_t_2458.f[1];
      int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
      if ((v_tag_2459 == ((int64_t)0ULL))) {
        V v_l_27_2461 = v_field_2460;
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2461});
      } else {
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_field_2460);
        return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam14_clo);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam15_clo);
  }
  default: return heff_nomatch(v_a_2456);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam16(V self, V *args) {
  V v_x_2480 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2455 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2481 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2480), v_x_2455});
  V f_ = v_k_246;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2421 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2479 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam12, 1, 1, (V[]){v_pr_242}), v_args_2421));
  V f_ = v_c_2479;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam16, 1, 3, (V[]){v_m_27_243, v_x_2455, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2421 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get_n(v_x_2454, 0, 6), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam11, 1, 5, (V[]){v_pr_242, v_args_2421, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam17(V self, V *args) {
  V v_c_2483 = args[0];
  return heff_get_n(v_c_2483, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam18(V self, V *args) {
  V v_x_2486 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2482 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2487 = ({ V a_0 = v_x_2486; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2486); r_; });
  {
    V v_field_2489 = v_t_2487.f[1];
    int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
    if ((v_tag_2488 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2490 = v_field_2489;
      V f_ = v_k_2482;
      args[0] = v_e_2490;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2489);
      V v_t_2491 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2492}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2493;
      heff_room[1] = v_k_2482;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = heff_dup(v_sp_244); HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2414); heff_drop(v_x_2410); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_items_2418 = v_field_2417;
      V v_t_2419 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2418)));
      V v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2419); r_; });
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_args_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2418));
        V v_t_2428 = (g_heff_2eelab_2eunify_2eanyL(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2421));
        if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
          heff_drop(v_t_2428);
          V v_k_2442 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam5, 1, 8, (V[]){v_args_2421, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
          V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam8_clo)})});
          V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2444}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2445;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam9, 1, 3, (V[]){v_m_27_243, v_k_2442, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_sp_244);
          heff_drop(v_t_2428);
          V v_k_2482 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam10, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2421, heff_dup(v_m_27_243), v_k_246});
          V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam17_clo)})});
          V v_t_2485 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2484}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2485;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam18, 1, 3, (V[]){v_m_27_243, v_k_2482, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop(v_sp_244);
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_m_27_243);
        heff_drop(v_items_2418);
        heff_drop(v_t_2420);
        V v_t_2494 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2494})});
        V v_t_2496 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2495}));
        V f_ = heff_get_n(v_hd_245, 1, 3);
        heff_room[0] = v_t_2496;
        heff_room[1] = v_k_246;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop(v_sp_244);
      heff_drop_rec(v_pr_242, 3);
      heff_drop(v_g_240);
      heff_drop(v_m_241);
      heff_drop(v_m_27_243);
      heff_drop(v_field_2417);
      V v_t_2497 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2498}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2499;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}