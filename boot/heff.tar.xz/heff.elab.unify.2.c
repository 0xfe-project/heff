// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_metas 305145640
#define LBL_ren 322325
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_co_2eop_24s1802027244x918867378(V, V, V);
V g_co_2eop_24s1802027244x918867378_entry(V self, V *a);
extern Clo g_co_2eop_24s1802027244x918867378_clo;
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eforU(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V, V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_clo;
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(V, V);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_clo;
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_heff_2eelab_2eunify_2edistinct_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eelab_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_244 = (g_list_2eany(heff_clo_n(g_heff_2eelab_2eunify_2edistinct_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
      heff_drop(v_x1_244);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_244);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2edistinct(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2edistinct_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_x_241, v_b_243);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry, 4, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V v_i_240, V v_f_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_i_240 = t_0;
    v_f_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eanyL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eunify_2eappendL_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eelab_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eunify_2econcatMapL(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eunify_2eappendL(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2econcatMapL(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_entry, 7, 0};

V g_heff_2eelab_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_call(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2eforU_lam0, 1, 7, (V[]){heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244, v_z_245, v_z_246})});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2eforU(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_xs_248 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2410);
  return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
}
Clo g_heff_2eelab_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eelab_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return v_t_241;
  } else {
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_249 = heff_field(v_t_241, 1);
      heff_take_n(v_t_241, 2ULL, 2);
      switch (heff_tag_of(v_it2_249)) {
      case TAG_MkAbs: {
        V v_b_2411 = heff_field(v_it2_249, 1);
        heff_take_n(v_it2_249, 2ULL, 2);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2412 = heff_field(v_it2_249, 0);
        heff_take_n(v_it2_249, 1ULL, 1);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2412;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_249);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitBytes: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitRune: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFixed: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat32: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
}
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estripLams(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_244}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_dom_247}));
    V v_f_2412 = heff_take_field(v_r_240, 1);
    V v_t_2418;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2413 = heff_field(v_cod_248, 0);
      V v_b_2414 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2414}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2413, v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2416}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2421;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2419}));
      v_t_2421 = heff_tag_at_n(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2420});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, (V[]){v_level_246, v_t_2411, v_t_2418, v_implicit_249, v_t_2421});
  }
  case TAG_SRecord: {
    V v_level_2422 = heff_field(v_t_242, 0);
    V v_ft_2423 = heff_field(v_t_242, 1);
    V v_ds_2424 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2425 = heff_take_field(v_ft_2423, 2);
    V v_t_2428 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2425)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2425, heff_dup(v_r_240)}));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_ft_2423, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_xs_2430 = heff_take_field(v_ds_2424, 2);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_r_240}));
    V v_t_2434 = ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_ds_2424, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2422, v_t_2429, v_t_2434});
  }
  case TAG_SSum: {
    V v_vs_2435 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2436 = heff_take_field(v_vs_2435, 2);
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2436)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2436, v_r_240}));
    V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_vs_2435, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2442});
  }
  case TAG_SIsTy: {
    V v_a_2443 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_a_2443}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2444});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2437 = args[0];
  V v_xs_2436 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2438 = heff_arrayIndex(v_xs_2436, v_i_2437);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam3, 1, 2, (V[]){v_xs_2438, v_r_240}));
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eelab_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonker(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eelab_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_a_245)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_245, 0);
        heff_take_n(v_a_245, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          V v_a_248 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          v_t_2410 = heff_intEq(v_a_247, v_a_248);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_247);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          heff_take_n(v_a_246, 0ULL, 1);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
      } else {
        heff_drop(v_t_2410);
        v_t_2411 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_2412;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0, 2, 0};
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eelab_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1, 2, 8, (V[]){v_g_240, v_m_241, v_pr_2413, v_ty_2411, v_pr_242, v_i_243, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3(V self, V *args) {
  V v_u_2418 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_ty_2411;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_v_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  return v_v_2419;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), heff_dup(v_i_243));
  V v_v_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2417}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2421 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4, 1, 1, (V[]){v_v_2419})}), v_rest_249));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5, 1, 2, (V[]){v_k_2415, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_i_243 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411), heff_dup(v_hd_2414), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2414, v_k_2415})));
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0, 1, 1, (V[]){v_t0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})));
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2418 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  V f_ = v_c_2418;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2422));
  V f_ = v_c_2423;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2432 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2431));
  V f_ = v_c_2432;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2434 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_implicit_2437 = heff_env(self)[3];
  V v_dflt_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2434, v_x_2439, v_x_2441, v_implicit_2437, v_dflt_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2435 = heff_env(self)[3];
  V v_cod_2436 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2434 = heff_env(self)[7];
  V v_implicit_2437 = heff_env(self)[8];
  V v_dflt_2438 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2440 = (g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(v_g_240, v_m_241, v_pr_242, v_dom_2435, v_cod_2436));
  V f_ = v_c_2440;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10, 1, 5, (V[]){v_k_245, v_level_2434, v_x_2439, v_implicit_2437, v_dflt_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11(V self, V *args) {
  V v_x_2448 = args[0];
  V v_fieldTypes_2444 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2442 = heff_env(self)[2];
  V v_defaults_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449 = ({ V rv_2 = heff_arrayFromList(v_x_2448); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2444, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2442, v_t_2449, v_defaults_2445});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13(V self, V *args) {
  V v_a_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2458 = heff_tr(heff_call(v_a_2457, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_m_241;
  heff_room[2] = v_pr_242;
  heff_room[3] = v_t_2458;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2455 = heff_env(self)[0];
  V v_k_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2455, heff_arrayFromList(v_x_2462)});
  V f_ = v_k_2461;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_c_2459 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2459;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15, 1, 2, (V[]){v_k_2455, v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12(V self, V *args) {
  V v_p_2454 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2454)) {
  case TAG_MkPair: {
    V v_k_2455 = heff_field(v_p_2454, 0);
    V v_args_2456 = heff_field(v_p_2454, 1);
    heff_take_n(v_p_2454, 3ULL, 2);
    V v_c_2459 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2456)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14, 2, 2, (V[]){v_c_2459, v_k_2455});
  }
  default: return heff_nomatch(v_p_2454);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2465)));
  V v_t_2467 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2465));
  V v_t_2468 = (g_list_2emap_24s1173914895x100384474(v_x_2465));
  V v_t_2469 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2466), v_t_2467, heff_arrayFromList(v_t_2468)});
  V v_x_2470 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2469});
  V f_ = v_k_245;
  args[0] = v_x_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17(V self, V *args) {
  V v_x_2472 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2472});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_VU: {
    V v_u_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_249});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2410 = heff_field(v_x_248, 0);
    V v_sp_2411 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2416;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2421 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2421;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2425 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c(heff_dup(v_m_27_2425), heff_dup(v_m_241))) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2425);
        V v_t_2427 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2428 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
        return (g_co_2eop_24s1802027244x918867378(v_t_2428, v_hd_244, v_k_245));
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2425; V a_4 = v_sp_2411; V a_5 = v_hd_244; V a_6 = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6, 1, 1, (V[]){v_k_245}); V r_ = (g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2411); r_; });
      }
    }
    case TAG_HError: {
      V v_c_2430 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2430;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VFunction: {
    V v_level_2434 = heff_field(v_x_248, 0);
    V v_dom_2435 = heff_field(v_x_248, 1);
    V v_cod_2436 = heff_field(v_x_248, 2);
    V v_implicit_2437 = heff_field(v_x_248, 3);
    V v_dflt_2438 = heff_field(v_x_248, 4);
    heff_take_n(v_x_248, 31ULL, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2435), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2435, v_cod_2436, v_hd_244, v_k_245, v_level_2434, v_implicit_2437, v_dflt_2438})));
  }
  case TAG_VRecord: {
    V v_level_2442 = heff_field(v_x_248, 0);
    V v_capture_2443 = heff_field(v_x_248, 1);
    V v_fieldTypes_2444 = heff_field(v_x_248, 2);
    V v_defaults_2445 = heff_field(v_x_248, 3);
    heff_take_n(v_x_248, 15ULL, 4);
    V v_t_2446 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2444, 2)));
    V v_c_2447 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2443, v_t_2446));
    V f_ = v_c_2447;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11, 1, 4, (V[]){v_fieldTypes_2444, v_k_245, v_level_2442, v_defaults_2445});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_vs_2450 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2451 = heff_arrayToList(heff_take_field(v_vs_2450, 0));
    V v_t_2452 = heff_arrayToList(heff_get_n(v_vs_2450, 2, 3));
    V v_t_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
    V v_c_2464 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2453));
    V f_ = v_c_2464;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2471 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_a_2471, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2473 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2473});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1), heff_take_field(v_pr_242, 2)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2423;
    switch (heff_tag_of(v_v_2416)) {
    case TAG_Nom: {
      V v_v_2417 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2417}));
      break;
    }
    case TAG_Describe: {
      V v_v_2418 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2418}));
      break;
    }
    case TAG_Become: {
      V v_v_2419 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419});
      break;
    }
    default: heff_nomatch(v_v_2416);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4, 2, 2, (V[]){v_c_2423, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_v_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2428}));
      break;
    }
    case TAG_Describe: {
      V v_v_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2429}));
      break;
    }
    case TAG_Become: {
      V v_v_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8, 2, 1, (V[]){v_c_2434});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_2411, v_v_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5, 1, 2, (V[]){v_k_2425, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0, 1, 1, (V[]){v_v0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})));
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2416));
  V f_ = v_t_2417;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2427));
  V f_ = v_t_2428;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2434, v_x_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_fty_2431 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2432 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2435 = heff_tr(heff_call(v_fty_2431, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2436 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2435)));
  V v_t_2448;
  switch (heff_tag_of(v_t_2436)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2439 = heff_field(v_t_2436, 1);
    heff_take_n(v_t_2436, 2ULL, 4);
    heff_drop(v_t_2435);
    v_t_2448 = v_dom_2439;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2436, 0ULL, 3);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeInt: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeString: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeRune: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_NoRules: {
    v_t_2448 = v_t_2435;
    break;
  }
  default: heff_nomatch(v_t_2436);
  }
  V v_c_2449 = (g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(v_g_240, v_m_241, v_pr_242, v_t_2448, v_body_2432));
  V f_ = v_c_2449;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7, 1, 2, (V[]){v_k_245, v_x_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2462;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2463});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2460 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2460, v_hd_2461, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10, 1, 1, (V[]){v_k_2462})));
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_2466 = heff_env(self)[0];
  V v_k_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2466;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2456, v_x_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_c_2464 = heff_env(self)[0];
  V v_k_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2464;
  args[0] = v_hd_2465;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12, 1, 2, (V[]){v_k_2466, v_k_2456});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8(V self, V *args) {
  V v_p_2455 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2455)) {
  case TAG_MkPair: {
    V v_k_2456 = heff_field(v_p_2455, 0);
    V v_x_2457 = heff_field(v_p_2455, 1);
    heff_take_n(v_p_2455, 3ULL, 2);
    V v_c_2464;
    switch (heff_tag_of(v_x_2457)) {
    case TAG_Nom: {
      V v_v_2458 = heff_field(v_x_2457, 0);
      heff_take_n(v_x_2457, 1ULL, 1);
      v_c_2464 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2458}));
      break;
    }
    case TAG_Describe: {
      V v_v_2459 = heff_field(v_x_2457, 0);
      heff_take_n(v_x_2457, 1ULL, 1);
      v_c_2464 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2459}));
      break;
    }
    case TAG_Become: {
      V v_v_2460 = heff_field(v_x_2457, 0);
      heff_take_n(v_x_2457, 1ULL, 1);
      v_c_2464 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2460});
      break;
    }
    default: heff_nomatch(v_x_2457);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11, 2, 2, (V[]){v_c_2464, v_k_2456});
  }
  default: return heff_nomatch(v_p_2455);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13(V self, V *args) {
  V v_x_2469 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2469)));
  V v_t_2471 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2469));
  V v_t_2472 = (g_list_2emap_24s1173914895x100384474(v_x_2469));
  V v_t_2473 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2470), v_t_2471, heff_arrayFromList(v_t_2472)});
  V v_x_2474 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2473});
  V f_ = v_k_245;
  args[0] = v_x_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_VNeu: {
    V v_it1_249 = heff_field(v_x_248, 0);
    V v_sp_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 5);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_HLocal: {
      V v_c_2415 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      V f_ = v_c_2415;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2419 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      V f_ = v_c_2419;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2422 = heff_field(v_it1_249, 0);
      V v_ru_24it1_249_24HMeta = heff_take_reuse_n(v_it1_249, 1ULL, 1);
      if (heff_intEq_c(heff_dup(v_m_27_2422), heff_dup(v_m_241))) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2410);
        heff_drop(v_m_27_2422);
        V v_t_2424 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2425 = heff_tag_at_n(v_ru_24it1_249_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
        return (g_co_2eop_24s1802027244x918867378(v_t_2425, v_hd_244, v_k_245));
      } else {
        heff_drop_cell(v_ru_24it1_249_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2422; V a_4 = v_sp_2410; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2410); r_; });
      }
    }
    case TAG_HError: {
      V v_c_2426 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      V f_ = v_c_2426;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_VCode: {
    V v_t_2429 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_t_2429, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2431 = heff_field(v_x_248, 0);
    V v_body_2432 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2433 = heff_tr(heff_call(heff_dup(v_fty_2431), 1, (V[]){NTAG(TAG_MkUnit)}));
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2433, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6, 1, 7, (V[]){v_fty_2431, v_g_240, v_m_241, v_pr_242, v_body_2432, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2451 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2452 = heff_arrayToList(heff_take_field(v_d_2451, 0));
    V v_t_2453 = heff_arrayToList(heff_get_n(v_d_2451, 2, 3));
    V v_t_2454 = (g_heff_2eutil_2edict_2ezipKV(v_t_2452, v_t_2453));
    V v_c_2468 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2454));
    V f_ = v_c_2468;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}