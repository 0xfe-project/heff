// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eeval_2eevalTypeF_24s15_lam0(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam2(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam1(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam5(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam4(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam3(V self, V *args);
Clo g_heff_2eeval_2eevalTypeF_24s15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTypeF_24s15_entry, 4, 0};

V g_heff_2eeval_2eevalTypeF_24s15(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SU, TAG_Nom, 1, (V[]){heff_tag(TAG_VU, 1, (V[]){v_u_244})});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SDecode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_x1_246 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, v_c_241, v_t_245, v_vs_243));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Nom, 1, (V[]){({ V a_0 = v_x_247; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_247); r_; })});
    }
    case TAG_Describe: {
      V v_x_248 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_x_248)) {
      case TAG_VNeu: {
        heff_take_n(v_x_248, 0ULL, 5);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2414 = heff_field(v_x_248, 0);
        heff_take_n(v_x_248, 1ULL, 1);
        return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Describe, 1, (V[]){v_a_2414});
      }
      case TAG_VLam: {
        heff_take_n(v_x_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_248);
      }
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Become, 1, (V[]){({ V a_0 = v_x_2418; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_2418); r_; })});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_SFunction: {
    V v_level_2419 = heff_field(v_x4_242, 0);
    V v_dom_2420 = heff_field(v_x4_242, 1);
    V v_cod_2421 = heff_field(v_x4_242, 2);
    V v_implicit_2422 = heff_field(v_x4_242, 3);
    V v_ru_24x4_242_24SFunction = heff_take_reuse_n(v_x4_242, 15ULL, 4);
    heff_drop(v_c_241);
    V v_x1_2423 = (g_heff_2eeval_2eevalTypeF_24s15(heff_dup(v_g_240), NTAG(TAG_N), v_dom_2420, heff_dup(v_vs_243)));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nom: {
      V v_x_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      v_t_2427 = v_x_2424;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2423, 0ULL, 1);
      v_t_2427 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2426 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      v_t_2427 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    V v_t_2432;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkAbs: {
      V v_x_2428 = heff_field(v_cod_2421, 0);
      V v_t_2429 = heff_field(v_cod_2421, 1);
      heff_take_n(v_cod_2421, 3ULL, 2);
      v_t_2432 = heff_tag(TAG_MkClo, 3, (V[]){v_x_2428, v_vs_243, heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam0, 1, 2, (V[]){v_g_240, v_t_2429})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2431 = heff_field(v_cod_2421, 0);
      V v_ru_24cod_2421_24AbsConst = heff_take_reuse_n(v_cod_2421, 1ULL, 1);
      v_t_2432 = heff_tag_at(v_ru_24cod_2421_24AbsConst, TAG_CloConst, 1, (V[]){(g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2431, v_vs_243))});
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    return heff_tag(TAG_Nom, 1, (V[]){heff_tag_at(v_ru_24x4_242_24SFunction, TAG_VFunction, 4, (V[]){v_level_2419, v_t_2427, v_t_2432, v_implicit_2422})});
  }
  case TAG_SRecord: {
    V v_level_2433 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2434 = heff_field(v_x4_242, 1);
    V v_defaults_2435 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_xs_2436 = heff_get(heff_dup(v_fieldTypes_2434), LBL_values);
    V v_t_2445 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2436)), heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam1, 1, 2, (V[]){v_xs_2436, v_g_240}));
    V v_t_2446 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_2434), LBL_keys), heff_get(v_fieldTypes_2434, LBL_byName), v_t_2445});
    return heff_tag(TAG_Describe, 1, (V[]){heff_tag(TAG_VRecord, 4, (V[]){v_level_2433, v_vs_243, v_t_2446, v_defaults_2435})});
  }
  case TAG_SSum: {
    V v_st_2447 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_xs_2448 = heff_get(heff_dup(v_st_2447), LBL_values);
    V v_t_2458 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2448)), heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam3, 1, 3, (V[]){v_xs_2448, v_g_240, v_vs_243}));
    V v_t_2459 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_st_2447), LBL_keys), heff_get(v_st_2447, LBL_byName), v_t_2458});
    return heff_tag_at(v_ru_24x4_242_24SSum, TAG_Describe, 1, (V[]){heff_tag(TAG_VSum, 1, (V[]){v_t_2459})});
  }
  case TAG_SIsTy: {
    V v_t_2460 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIsTy = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2461 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2460, v_vs_243));
    V v_t_2465;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_Nom: {
      V v_x_2462 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2465 = v_x_2462;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2461, 0ULL, 1);
      v_t_2465 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2464 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2465 = v_x_2464;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_at(v_ru_24x4_242_24SIsTy, TAG_Become, 1, (V[]){v_t_2465});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimArray: {
    V v_a_2466 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2467 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_a_2466, v_vs_243));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2467)) {
    case TAG_Nom: {
      V v_x_2468 = heff_field(v_x1_2467, 0);
      heff_take_n(v_x1_2467, 1ULL, 1);
      v_t_2471 = v_x_2468;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2467, 0ULL, 1);
      v_t_2471 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2470 = heff_field(v_x1_2467, 0);
      heff_take_n(v_x1_2467, 1ULL, 1);
      v_t_2471 = v_x_2470;
      break;
    }
    default: heff_nomatch(v_x1_2467);
    }
    return heff_tag_at(v_ru_24x4_242_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag(TAG_VPrimArray, 1, (V[]){v_t_2471})});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eeval_2eevalTypeF_24s15_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeval_2eevalTypeF_24s15(a[0], a[1], a[2], a[3]);
}
V g_heff_2eeval_2eevalTypeF_24s15_lam0(V self, V *args) {
  V v_vs2_2430 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2429, v_vs2_2430));
}
V g_heff_2eeval_2eevalTypeF_24s15_lam2(V self, V *args) {
  V v_vs2_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2440 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2438, v_vs2_2439));
  V v_t_2444;
  switch (heff_tag_of(v_x1_2440)) {
  case TAG_Nom: {
    V v_x_2441 = heff_field(v_x1_2440, 0);
    heff_take_n(v_x1_2440, 1ULL, 1);
    v_t_2444 = v_x_2441;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2440, 0ULL, 1);
    v_t_2444 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2443 = heff_field(v_x1_2440, 0);
    heff_take_n(v_x1_2440, 1ULL, 1);
    v_t_2444 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_x1_2440);
  }
  return heff_tag(TAG_MkField, 2, (V[]){v_t_2444, NTAG(TAG_Nothing)});
}
V g_heff_2eeval_2eevalTypeF_24s15_lam1(V self, V *args) {
  V v_i_2437 = args[0];
  V v_xs_2436 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_arrayIndex(v_xs_2436, v_i_2437);
  return heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam2, 1, 2, (V[]){v_g_240, v_t_2438});
}
V g_heff_2eeval_2eevalTypeF_24s15_lam5(V self, V *args) {
  V v_u_2453 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2452 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2453);
  V v_x1_2454 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2452, v_vs_243));
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_Nom: {
    V v_x_2455 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    return v_x_2455;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2454, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2457 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    return v_x_2457;
  }
  default: return heff_nomatch(v_x1_2454);
  }
}
V g_heff_2eeval_2eevalTypeF_24s15_lam4(V self, V *args) {
  V v_i_2451 = args[0];
  V v_xs_2450 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2452 = heff_arrayIndex(v_xs_2450, v_i_2451);
  return heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam5, 1, 3, (V[]){v_g_240, v_t_2452, v_vs_243});
}
V g_heff_2eeval_2eevalTypeF_24s15_lam3(V self, V *args) {
  V v_i_2449 = args[0];
  V v_xs_2448 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2450 = heff_arrayIndex(v_xs_2448, v_i_2449);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2450)), heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam4, 1, 3, (V[]){v_xs_2450, v_g_240, v_vs_243}));
}
V g_heff_2eeval_2eevalTermF_24s14_lam0(V self, V *args); static Clo g_heff_2eeval_2eevalTermF_24s14_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTermF_24s14_lam0, 1, 0};
V g_heff_2eeval_2eevalTermF_24s14_lam2(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam1(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam3(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam4(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam5(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam6(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam7(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam8(V self, V *args);
Clo g_heff_2eeval_2eevalTermF_24s14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTermF_24s14_entry, 4, 0};

V g_heff_2eeval_2eevalTermF_24s14(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SLocal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    return heff_tag_at(v_ru_24x4_242_24SLocal, TAG_Nom, 1, (V[]){({ V a_0 = v_vs_243; V a_1 = v_i_244; V r_ = heff_tr(g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_243); r_; })});
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    V v_t_246 = ({ V a_0 = v_x_245; V b_1 = heff_get(v_g_240, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_t_248 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_e_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_248 = v_e_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at(v_ru_24x4_242_24SGlobal, TAG_Nom, 1, (V[]){heff_get(v_t_248, LBL_value)});
  }
  case TAG_SCode: {
    V v_a_249 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SCode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_f_2427 = ((V)&g_heff_2eeval_2eevalTermF_24s14_lam0_clo);
    V v_x2_2428 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, v_c_241, v_a_249, v_vs_243));
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nom: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      heff_take_n(v_x2_2428, 1ULL, 1);
      V v_t_2430 = heff_tr(heff_apply(v_f_2427, 1, (V[]){v_x_2429}));
      return heff_tag_at(v_ru_24x4_242_24SCode, TAG_Nom, 1, (V[]){v_t_2430});
    }
    case TAG_Describe: {
      V v_x_2431 = heff_field(v_x2_2428, 0);
      heff_take_n(v_x2_2428, 1ULL, 1);
      V v_t_2432 = heff_tr(heff_apply(v_f_2427, 1, (V[]){v_x_2431}));
      return heff_tag_at(v_ru_24x4_242_24SCode, TAG_Describe, 1, (V[]){v_t_2432});
    }
    case TAG_Become: {
      V v_x_2433 = heff_field(v_x2_2428, 0);
      heff_take_n(v_x2_2428, 1ULL, 1);
      V v_t_2434 = heff_tr(heff_apply(v_f_2427, 1, (V[]){v_x_2433}));
      return heff_tag_at(v_ru_24x4_242_24SCode, TAG_Become, 1, (V[]){v_t_2434});
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
  case TAG_SApp: {
    V v_t0_2435 = heff_field(v_x4_242, 0);
    V v_t1_2436 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    heff_drop(v_c_241);
    V v_f_2443 = heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam1, 1, 3, (V[]){heff_dup(v_g_240), v_t1_2436, heff_dup(v_vs_243)});
    V v_x2_2444 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t0_2435, v_vs_243));
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_Nom: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      heff_take_n(v_x2_2444, 1ULL, 1);
      return heff_tail(v_f_2443, 1, (V[]){v_x_2445});
    }
    case TAG_Describe: {
      V v_x_2446 = heff_field(v_x2_2444, 0);
      heff_take_n(v_x2_2444, 1ULL, 1);
      return heff_tail(v_f_2443, 1, (V[]){v_x_2446});
    }
    case TAG_Become: {
      V v_x_2447 = heff_field(v_x2_2444, 0);
      V v_ru_24x2_2444_24Become = heff_take_reuse_n(v_x2_2444, 1ULL, 1);
      V v_x1_2448 = heff_tr(heff_apply(v_f_2443, 1, (V[]){v_x_2447}));
      V v_t_2452;
      switch (heff_tag_of(v_x1_2448)) {
      case TAG_Nom: {
        V v_x_2449 = heff_field(v_x1_2448, 0);
        heff_take_n(v_x1_2448, 1ULL, 1);
        v_t_2452 = v_x_2449;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2448, 0ULL, 1);
        v_t_2452 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2451 = heff_field(v_x1_2448, 0);
        heff_take_n(v_x1_2448, 1ULL, 1);
        v_t_2452 = v_x_2451;
        break;
      }
      default: heff_nomatch(v_x1_2448);
      }
      return heff_tag_at(v_ru_24x2_2444_24Become, TAG_Become, 1, (V[]){v_t_2452});
    }
    default: return heff_nomatch(v_x2_2444);
    }
  }
  case TAG_SLam: {
    V v_dom_2453 = heff_field(v_x4_242, 0);
    V v_x42_2454 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SLam = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_2454)) {
    case TAG_MkAbs: {
      V v_x_2455 = heff_field(v_x42_2454, 0);
      V v_t_2456 = heff_field(v_x42_2454, 1);
      heff_take_n(v_x42_2454, 3ULL, 2);
      V v_x_2463 = heff_tag_at(v_ru_24x4_242_24SLam, TAG_VLam, 2, (V[]){heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam3, 1, 3, (V[]){heff_dup(v_g_240), v_dom_2453, heff_dup(v_vs_243)}), heff_tag(TAG_MkClo, 3, (V[]){v_x_2455, v_vs_243, heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam4, 1, 3, (V[]){v_g_240, heff_dup(v_c_241), v_t_2456})})});
      switch (heff_tag_of(v_c_241)) {
      case TAG_N: {
        return heff_tag(TAG_Nom, 1, (V[]){v_x_2463});
      }
      case TAG_De: {
        return heff_tag(TAG_Describe, 1, (V[]){v_x_2463});
      }
      default: return heff_nomatch(v_c_241);
      }
    }
    case TAG_AbsConst: {
      V v_t_2464 = heff_field(v_x42_2454, 0);
      V v_ru_24x42_2454_24AbsConst = heff_take_reuse_n(v_x42_2454, 1ULL, 1);
      V v_t_2465 = heff_tag_at(v_ru_24x42_2454_24AbsConst, TAG_CloConst, 1, (V[]){heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_dup(v_g_240), heff_dup(v_c_241), v_t_2464, heff_dup(v_vs_243)))});
      V v_x_2471 = heff_tag_at(v_ru_24x4_242_24SLam, TAG_VLam, 2, (V[]){heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam5, 1, 3, (V[]){v_g_240, v_dom_2453, v_vs_243}), v_t_2465});
      switch (heff_tag_of(v_c_241)) {
      case TAG_N: {
        return heff_tag(TAG_Nom, 1, (V[]){v_x_2471});
      }
      case TAG_De: {
        return heff_tag(TAG_Describe, 1, (V[]){v_x_2471});
      }
      default: return heff_nomatch(v_c_241);
      }
    }
    default: return heff_nomatch(v_x42_2454);
    }
  }
  case TAG_SCons: {
    V v_fields_2472 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SCons = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_xs_2473 = heff_get(heff_dup(v_fields_2472), LBL_values);
    V v_t_2476 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2473)), heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam6, 1, 4, (V[]){v_xs_2473, v_g_240, heff_dup(v_c_241), v_vs_243}));
    V v_t_2477 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fields_2472), LBL_keys), heff_get(v_fields_2472, LBL_byName), v_t_2476});
    V v_x_2478 = heff_tag_at(v_ru_24x4_242_24SCons, TAG_VCons, 1, (V[]){v_t_2477});
    switch (heff_tag_of(v_c_241)) {
    case TAG_N: {
      return heff_tag(TAG_Nom, 1, (V[]){v_x_2478});
    }
    case TAG_De: {
      return heff_tag(TAG_Describe, 1, (V[]){v_x_2478});
    }
    default: return heff_nomatch(v_c_241);
    }
  }
  case TAG_SProj: {
    V v_t_2479 = heff_field(v_x4_242, 0);
    V v_x_2480 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    heff_drop(v_c_241);
    V v_x2_2481 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t_2479, v_vs_243));
    switch (heff_tag_of(v_x2_2481)) {
    case TAG_Nom: {
      V v_x_2482 = heff_field(v_x2_2481, 0);
      heff_take_n(v_x2_2481, 1ULL, 1);
      return (g_heff_2evalue_2eproj(v_x_2482, v_x_2480));
    }
    case TAG_Describe: {
      V v_x_2483 = heff_field(v_x2_2481, 0);
      heff_take_n(v_x2_2481, 1ULL, 1);
      return (g_heff_2evalue_2eproj(v_x_2483, v_x_2480));
    }
    case TAG_Become: {
      V v_x_2484 = heff_field(v_x2_2481, 0);
      V v_ru_24x2_2481_24Become = heff_take_reuse_n(v_x2_2481, 1ULL, 1);
      V v_x1_2485 = (g_heff_2evalue_2eproj(v_x_2484, v_x_2480));
      V v_t_2489;
      switch (heff_tag_of(v_x1_2485)) {
      case TAG_Nom: {
        V v_x_2486 = heff_field(v_x1_2485, 0);
        heff_take_n(v_x1_2485, 1ULL, 1);
        v_t_2489 = v_x_2486;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2485, 0ULL, 1);
        v_t_2489 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2488 = heff_field(v_x1_2485, 0);
        heff_take_n(v_x1_2485, 1ULL, 1);
        v_t_2489 = v_x_2488;
        break;
      }
      default: heff_nomatch(v_x1_2485);
      }
      return heff_tag_at(v_ru_24x2_2481_24Become, TAG_Become, 1, (V[]){v_t_2489});
    }
    default: return heff_nomatch(v_x2_2481);
    }
  }
  case TAG_STag: {
    heff_take_n(v_x4_242, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take_n(v_x4_242, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_2494 = heff_field(v_x4_242, 0);
    V v_x_2495 = heff_field(v_x4_242, 1);
    V v_t_27_2496 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_x1_2497 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_dup(v_g_240), NTAG(TAG_N), v_t_2494, heff_dup(v_vs_243)));
    V v_t_24101;
    switch (heff_tag_of(v_x1_2497)) {
    case TAG_Nom: {
      V v_x_2498 = heff_field(v_x1_2497, 0);
      heff_take_n(v_x1_2497, 1ULL, 1);
      v_t_24101 = v_x_2498;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2497, 0ULL, 1);
      v_t_24101 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24100 = heff_field(v_x1_2497, 0);
      heff_take_n(v_x1_2497, 1ULL, 1);
      v_t_24101 = v_x_24100;
      break;
    }
    default: heff_nomatch(v_x1_2497);
    }
    V v_x1_24102 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t_27_2496, v_vs_243));
    V v_t_24106;
    switch (heff_tag_of(v_x1_24102)) {
    case TAG_Nom: {
      V v_x_24103 = heff_field(v_x1_24102, 0);
      heff_take_n(v_x1_24102, 1ULL, 1);
      v_t_24106 = v_x_24103;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24102, 0ULL, 1);
      v_t_24106 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24105 = heff_field(v_x1_24102, 0);
      heff_take_n(v_x1_24102, 1ULL, 1);
      v_t_24106 = v_x_24105;
      break;
    }
    default: heff_nomatch(v_x1_24102);
    }
    return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2especialize(v_t_24101, v_x_2495, v_t_24106))});
  }
  case TAG_SIs: {
    V v_t_24107 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIs = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_24108 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t_24107, v_vs_243));
    V v_t_24112;
    switch (heff_tag_of(v_x1_24108)) {
    case TAG_Nom: {
      V v_x_24109 = heff_field(v_x1_24108, 0);
      heff_take_n(v_x1_24108, 1ULL, 1);
      v_t_24112 = v_x_24109;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24108, 0ULL, 1);
      v_t_24112 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24111 = heff_field(v_x1_24108, 0);
      heff_take_n(v_x1_24108, 1ULL, 1);
      v_t_24112 = v_x_24111;
      break;
    }
    default: heff_nomatch(v_x1_24108);
    }
    return heff_tag_at(v_ru_24x4_242_24SIs, TAG_Become, 1, (V[]){v_t_24112});
  }
  case TAG_SOpaque: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_242_24SRec = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take_n(v_x4_242, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24117 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_c_241;
    V t_2 = v_e_24117;
    V t_3 = v_vs_243;
    v_g_240 = t_0;
    v_c_241 = t_1;
    v_x4_242 = t_2;
    v_vs_243 = t_3;
    goto top;
  }
  case TAG_SPrim: {
    V v_ru_24x4_242_24SPrim = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24119 = heff_field(v_x4_242, 0);
    V v_idxs_24120 = heff_field(v_x4_242, 1);
    V v_ty_24121 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_sp_24124 = (g_array_2efoldlFrom(heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam7, 2, 1, (V[]){heff_dup(v_vs_243)}), MK_INT(0LL), NTAG(TAG_SpId), v_idxs_24120));
    V v_x1_24125 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_ty_24121, v_vs_243));
    V v_ty_24129;
    switch (heff_tag_of(v_x1_24125)) {
    case TAG_Nom: {
      V v_x_24126 = heff_field(v_x1_24125, 0);
      heff_take_n(v_x1_24125, 1ULL, 1);
      v_ty_24129 = v_x_24126;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24125, 0ULL, 1);
      v_ty_24129 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24128 = heff_field(v_x1_24125, 0);
      heff_take_n(v_x1_24125, 1ULL, 1);
      v_ty_24129 = v_x_24128;
      break;
    }
    default: heff_nomatch(v_x1_24125);
    }
    V v_t_24131 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HMeta, 1, (V[]){v_m_24119}), v_sp_24124, heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam8, 1, 1, (V[]){v_ty_24129}), NTAG(TAG_Nothing)));
    return heff_tag(TAG_Nom, 1, (V[]){v_t_24131});
  }
  case TAG_SLitInt: {
    V v_ru_24x4_242_24SLitInt = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_242_24SLitFloat = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_242_24SLitString = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeval_2eevalTermF_24s14(a[0], a[1], a[2], a[3]);
}
V g_heff_2eeval_2eevalTermF_24s14_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  switch (heff_tag_of(v_t_2410)) {
  case TAG_VU: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VDecode: {
    V v_el_2416 = heff_field(v_t_2410, 4);
    heff_take_n(v_t_2410, 16ULL, 5);
    V f_ = v_el_2416;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VFunction: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VRecord: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VSum: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimInt: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimFloat: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimString: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimArray: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam2(V self, V *args) {
  V v_u_2438 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t1_2436 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2438);
  V v_x1_2439 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t1_2436, v_vs_243));
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    return v_x_2440;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    return v_x_2442;
  }
  default: return heff_nomatch(v_x1_2439);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam1(V self, V *args) {
  V v_f_2437 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t1_2436 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2evalue_2eapp(v_f_2437, heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam2, 1, 3, (V[]){v_g_240, v_t1_2436, v_vs_243})));
}
V g_heff_2eeval_2eevalTermF_24s14_lam3(V self, V *args) {
  V v_u_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_dom_2453 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2457);
  V v_x1_2458 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_dom_2453, v_vs_243));
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2459;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2461;
  }
  default: return heff_nomatch(v_x1_2458);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam4(V self, V *args) {
  V v_vs2_2462 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_t_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eeval_2eevalTermF_24s14(v_g_240, v_c_241, v_t_2456, v_vs2_2462));
}
V g_heff_2eeval_2eevalTermF_24s14_lam5(V self, V *args) {
  V v_u_2466 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_dom_2453 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2466);
  V v_x1_2467 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_dom_2453, v_vs_243));
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_Nom: {
    V v_x_2468 = heff_field(v_x1_2467, 0);
    heff_take_n(v_x1_2467, 1ULL, 1);
    return v_x_2468;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2467, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2470 = heff_field(v_x1_2467, 0);
    heff_take_n(v_x1_2467, 1ULL, 1);
    return v_x_2470;
  }
  default: return heff_nomatch(v_x1_2467);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam6(V self, V *args) {
  V v_i_2474 = args[0];
  V v_xs_2473 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_vs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2475 = heff_arrayIndex(v_xs_2473, v_i_2474);
  return (g_heff_2eeval_2eevalTermF_24s14(v_g_240, v_c_241, v_t_2475, v_vs_243));
}
V g_heff_2eeval_2eevalTermF_24s14_lam7(V self, V *args) {
  V v_sp_24122 = args[0];
  V v_i_24123 = args[1];
  V v_vs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_SpApp, 2, (V[]){v_sp_24122, ({ V a_0 = v_vs_243; V a_1 = v_i_24123; V r_ = heff_tr(g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_243); r_; })});
}
V g_heff_2eeval_2eevalTermF_24s14_lam8(V self, V *args) {
  V v_u_24130 = args[0];
  V v_ty_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24130);
  return v_ty_24129;
}