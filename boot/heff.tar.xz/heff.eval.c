// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eeval_2eevalTypeF_24s15_lam0(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam2(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam1(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam5(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam4(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s15_lam3(V self, V *args);
Clo g_heff_2eeval_2eevalTypeF_24s15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTypeF_24s15_entry, 4, 0};

V g_heff_2eeval_2eevalTypeF_24s15(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse(v_x4_242, 1ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SU, TAG_Nom, 1, (V[]){heff_tag(TAG_VU, 1, (V[]){v_u_244})});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SDecode = heff_take_reuse(v_x4_242, 1ULL);
    V v_x1_246 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, v_c_241, v_t_245, v_vs_243));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Nom, 1, (V[]){({ V a_0 = v_x_247; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_247); r_; })});
    }
    case TAG_Describe: {
      V v_x_248 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      switch (heff_tag_of(v_x_248)) {
      case TAG_VNeu: {
        heff_take(v_x_248, 0ULL);
        heff_drop(v_ru_24x4_242_24SDecode);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2414 = heff_field(v_x_248, 0);
        heff_take(v_x_248, 1ULL);
        return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Describe, 1, (V[]){v_a_2414});
      }
      case TAG_VLam: {
        heff_take(v_x_248, 0ULL);
        heff_drop(v_ru_24x4_242_24SDecode);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take(v_x_248, 0ULL);
        heff_drop(v_ru_24x4_242_24SDecode);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop(v_ru_24x4_242_24SDecode);
        heff_drop(v_x_248);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_248);
      }
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_246, 0);
      heff_take(v_x1_246, 1ULL);
      return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Become, 1, (V[]){({ V a_0 = v_x_2418; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_2418); r_; })});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_SFunction: {
    V v_level_2419 = heff_field(v_x4_242, 0);
    V v_dom_2420 = heff_field(v_x4_242, 1);
    V v_cod_2421 = heff_field(v_x4_242, 2);
    V v_implicit_2422 = heff_field(v_x4_242, 3);
    V v_ru_24x4_242_24SFunction = heff_take_reuse(v_x4_242, 15ULL);
    heff_drop(v_c_241);
    V v_x1_2423 = (g_heff_2eeval_2eevalTypeF_24s15(heff_dup(v_g_240), NTAG(TAG_N), v_dom_2420, heff_dup(v_vs_243)));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nom: {
      V v_x_2424 = heff_field(v_x1_2423, 0);
      heff_take(v_x1_2423, 1ULL);
      v_t_2427 = v_x_2424;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_2423, 0ULL);
      v_t_2427 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2426 = heff_field(v_x1_2423, 0);
      heff_take(v_x1_2423, 1ULL);
      v_t_2427 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    V v_t_2432;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkAbs: {
      V v_x_2428 = heff_field(v_cod_2421, 0);
      V v_t_2429 = heff_field(v_cod_2421, 1);
      heff_take(v_cod_2421, 3ULL);
      v_t_2432 = heff_tag(TAG_MkClo, 3, (V[]){v_x_2428, v_vs_243, heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam0, 1, 2, (V[]){v_g_240, v_t_2429})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2431 = heff_field(v_cod_2421, 0);
      V v_ru_24cod_2421_24AbsConst = heff_take_reuse(v_cod_2421, 1ULL);
      v_t_2432 = heff_tag_at(v_ru_24cod_2421_24AbsConst, TAG_CloConst, 1, (V[]){(g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2431, v_vs_243))});
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    return heff_tag(TAG_Nom, 1, (V[]){heff_tag_at(v_ru_24x4_242_24SFunction, TAG_VFunction, 4, (V[]){v_level_2419, v_t_2427, v_t_2432, v_implicit_2422})});
  }
  case TAG_SRecord: {
    V v_level_2433 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2434 = heff_field(v_x4_242, 1);
    heff_take(v_x4_242, 3ULL);
    heff_drop(v_c_241);
    V v_xs_2435 = heff_get(heff_dup(v_fieldTypes_2434), LBL_values);
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2435)), heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam1, 1, 2, (V[]){v_xs_2435, v_g_240}));
    V v_t_2445 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_fieldTypes_2434), LBL_keys), heff_get(v_fieldTypes_2434, LBL_byName), v_t_2444});
    return heff_tag(TAG_Describe, 1, (V[]){heff_tag(TAG_VRecord, 3, (V[]){v_level_2433, v_vs_243, v_t_2445})});
  }
  case TAG_SSum: {
    V v_st_2446 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse(v_x4_242, 1ULL);
    heff_drop(v_c_241);
    V v_xs_2447 = heff_get(heff_dup(v_st_2446), LBL_values);
    V v_t_2457 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2447)), heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam3, 1, 3, (V[]){v_xs_2447, v_g_240, v_vs_243}));
    V v_t_2458 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_st_2446), LBL_keys), heff_get(v_st_2446, LBL_byName), v_t_2457});
    return heff_tag_at(v_ru_24x4_242_24SSum, TAG_Describe, 1, (V[]){heff_tag(TAG_VSum, 1, (V[]){v_t_2458})});
  }
  case TAG_SIsTy: {
    V v_t_2459 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIsTy = heff_take_reuse(v_x4_242, 1ULL);
    heff_drop(v_c_241);
    V v_x1_2460 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2459, v_vs_243));
    V v_t_2464;
    switch (heff_tag_of(v_x1_2460)) {
    case TAG_Nom: {
      V v_x_2461 = heff_field(v_x1_2460, 0);
      heff_take(v_x1_2460, 1ULL);
      v_t_2464 = v_x_2461;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_2460, 0ULL);
      v_t_2464 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2463 = heff_field(v_x1_2460, 0);
      heff_take(v_x1_2460, 1ULL);
      v_t_2464 = v_x_2463;
      break;
    }
    default: heff_nomatch(v_x1_2460);
    }
    return heff_tag_at(v_ru_24x4_242_24SIsTy, TAG_Become, 1, (V[]){v_t_2464});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_x4_242);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_x4_242);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_x4_242);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimArray: {
    V v_a_2465 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse(v_x4_242, 1ULL);
    heff_drop(v_c_241);
    V v_x1_2466 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_a_2465, v_vs_243));
    V v_t_2470;
    switch (heff_tag_of(v_x1_2466)) {
    case TAG_Nom: {
      V v_x_2467 = heff_field(v_x1_2466, 0);
      heff_take(v_x1_2466, 1ULL);
      v_t_2470 = v_x_2467;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_2466, 0ULL);
      v_t_2470 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2469 = heff_field(v_x1_2466, 0);
      heff_take(v_x1_2466, 1ULL);
      v_t_2470 = v_x_2469;
      break;
    }
    default: heff_nomatch(v_x1_2466);
    }
    return heff_tag_at(v_ru_24x4_242_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag(TAG_VPrimArray, 1, (V[]){v_t_2470})});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eeval_2eevalTypeF_24s15_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeval_2eevalTypeF_24s15(a[0], a[1], a[2], a[3]);
}
V g_heff_2eeval_2eevalTypeF_24s15_lam0(V self, V *args) {
  V v_vs2_2430 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_t_2429 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2429, v_vs2_2430));
}
V g_heff_2eeval_2eevalTypeF_24s15_lam2(V self, V *args) {
  V v_vs2_2438 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_t_2437 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x1_2439 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2437, v_vs2_2438));
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take(v_x1_2439, 1ULL);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2439, 0ULL);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take(v_x1_2439, 1ULL);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  return heff_tag(TAG_MkField, 2, (V[]){v_t_2443, NTAG(TAG_Nothing)});
}
V g_heff_2eeval_2eevalTypeF_24s15_lam1(V self, V *args) {
  V v_i_2436 = args[0];
  V v_xs_2435 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2437 = heff_arrayIndex(v_xs_2435, v_i_2436);
  return heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam2, 1, 2, (V[]){v_g_240, v_t_2437});
}
V g_heff_2eeval_2eevalTypeF_24s15_lam5(V self, V *args) {
  V v_u_2452 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_t_2451 = heff_dup(heff_env(self)[1]);
  V v_vs_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_2452);
  V v_x1_2453 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_t_2451, v_vs_243));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_Nom: {
    V v_x_2454 = heff_field(v_x1_2453, 0);
    heff_take(v_x1_2453, 1ULL);
    return v_x_2454;
  }
  case TAG_Describe: {
    heff_take(v_x1_2453, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2456 = heff_field(v_x1_2453, 0);
    heff_take(v_x1_2453, 1ULL);
    return v_x_2456;
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2eeval_2eevalTypeF_24s15_lam4(V self, V *args) {
  V v_i_2450 = args[0];
  V v_xs_2449 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_vs_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2451 = heff_arrayIndex(v_xs_2449, v_i_2450);
  return heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam5, 1, 3, (V[]){v_g_240, v_t_2451, v_vs_243});
}
V g_heff_2eeval_2eevalTypeF_24s15_lam3(V self, V *args) {
  V v_i_2448 = args[0];
  V v_xs_2447 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_vs_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_xs_2449 = heff_arrayIndex(v_xs_2447, v_i_2448);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2449)), heff_clo(g_heff_2eeval_2eevalTypeF_24s15_lam4, 1, 3, (V[]){v_xs_2449, v_g_240, v_vs_243}));
}
V g_heff_2eeval_2eevalTermF_24s14_lam0(V self, V *args); static Clo g_heff_2eeval_2eevalTermF_24s14_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTermF_24s14_lam0, 1, 0};
V g_heff_2eeval_2eevalTermF_24s14_lam2(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam1(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam3(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam4(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam5(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam6(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam7(V self, V *args);
V g_heff_2eeval_2eevalTermF_24s14_lam8(V self, V *args);
Clo g_heff_2eeval_2eevalTermF_24s14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTermF_24s14_entry, 4, 0};

V g_heff_2eeval_2eevalTermF_24s14(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SLocal = heff_take_reuse(v_x4_242, 1ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    return heff_tag_at(v_ru_24x4_242_24SLocal, TAG_Nom, 1, (V[]){({ V a_0 = v_vs_243; V a_1 = v_i_244; V r_ = heff_tr(g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_243); r_; })});
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse(v_x4_242, 1ULL);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    V v_t_246 = ({ V a_0 = v_x_245; V b_1 = heff_get(v_g_240, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_t_246);
      v_t_248 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_e_247 = heff_field(v_t_246, 0);
      heff_take(v_t_246, 1ULL);
      v_t_248 = v_e_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at(v_ru_24x4_242_24SGlobal, TAG_Nom, 1, (V[]){heff_get(v_t_248, LBL_value)});
  }
  case TAG_SCode: {
    V v_a_249 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SCode = heff_take_reuse(v_x4_242, 1ULL);
    V v_f_2426 = ((V)&g_heff_2eeval_2eevalTermF_24s14_lam0_clo);
    V v_x2_2427 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, v_c_241, v_a_249, v_vs_243));
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nom: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      heff_take(v_x2_2427, 1ULL);
      V v_t_2429 = heff_tr(heff_apply(v_f_2426, 1, (V[]){v_x_2428}));
      return heff_tag_at(v_ru_24x4_242_24SCode, TAG_Nom, 1, (V[]){v_t_2429});
    }
    case TAG_Describe: {
      V v_x_2430 = heff_field(v_x2_2427, 0);
      heff_take(v_x2_2427, 1ULL);
      V v_t_2431 = heff_tr(heff_apply(v_f_2426, 1, (V[]){v_x_2430}));
      return heff_tag_at(v_ru_24x4_242_24SCode, TAG_Describe, 1, (V[]){v_t_2431});
    }
    case TAG_Become: {
      V v_x_2432 = heff_field(v_x2_2427, 0);
      heff_take(v_x2_2427, 1ULL);
      V v_t_2433 = heff_tr(heff_apply(v_f_2426, 1, (V[]){v_x_2432}));
      return heff_tag_at(v_ru_24x4_242_24SCode, TAG_Become, 1, (V[]){v_t_2433});
    }
    default: return heff_nomatch(v_x2_2427);
    }
  }
  case TAG_SApp: {
    V v_t0_2434 = heff_field(v_x4_242, 0);
    V v_t1_2435 = heff_field(v_x4_242, 1);
    heff_take(v_x4_242, 3ULL);
    heff_drop(v_c_241);
    V v_f_2442 = heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam1, 1, 3, (V[]){heff_dup(v_g_240), v_t1_2435, heff_dup(v_vs_243)});
    V v_x2_2443 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t0_2434, v_vs_243));
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nom: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      heff_take(v_x2_2443, 1ULL);
      return heff_tail(v_f_2442, 1, (V[]){v_x_2444});
    }
    case TAG_Describe: {
      V v_x_2445 = heff_field(v_x2_2443, 0);
      heff_take(v_x2_2443, 1ULL);
      return heff_tail(v_f_2442, 1, (V[]){v_x_2445});
    }
    case TAG_Become: {
      V v_x_2446 = heff_field(v_x2_2443, 0);
      V v_ru_24x2_2443_24Become = heff_take_reuse(v_x2_2443, 1ULL);
      V v_x1_2447 = heff_tr(heff_apply(v_f_2442, 1, (V[]){v_x_2446}));
      V v_t_2451;
      switch (heff_tag_of(v_x1_2447)) {
      case TAG_Nom: {
        V v_x_2448 = heff_field(v_x1_2447, 0);
        heff_take(v_x1_2447, 1ULL);
        v_t_2451 = v_x_2448;
        break;
      }
      case TAG_Describe: {
        heff_take(v_x1_2447, 0ULL);
        v_t_2451 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2450 = heff_field(v_x1_2447, 0);
        heff_take(v_x1_2447, 1ULL);
        v_t_2451 = v_x_2450;
        break;
      }
      default: heff_nomatch(v_x1_2447);
      }
      return heff_tag_at(v_ru_24x2_2443_24Become, TAG_Become, 1, (V[]){v_t_2451});
    }
    default: return heff_nomatch(v_x2_2443);
    }
  }
  case TAG_SLam: {
    V v_dom_2452 = heff_field(v_x4_242, 0);
    V v_x42_2453 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SLam = heff_take_reuse(v_x4_242, 3ULL);
    switch (heff_tag_of(v_x42_2453)) {
    case TAG_MkAbs: {
      V v_x_2454 = heff_field(v_x42_2453, 0);
      V v_t_2455 = heff_field(v_x42_2453, 1);
      heff_take(v_x42_2453, 3ULL);
      V v_x_2462 = heff_tag_at(v_ru_24x4_242_24SLam, TAG_VLam, 2, (V[]){heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam3, 1, 3, (V[]){heff_dup(v_g_240), v_dom_2452, heff_dup(v_vs_243)}), heff_tag(TAG_MkClo, 3, (V[]){v_x_2454, v_vs_243, heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam4, 1, 3, (V[]){v_g_240, heff_dup(v_c_241), v_t_2455})})});
      switch (heff_tag_of(v_c_241)) {
      case TAG_N: {
        heff_drop(v_c_241);
        return heff_tag(TAG_Nom, 1, (V[]){v_x_2462});
      }
      case TAG_De: {
        heff_drop(v_c_241);
        return heff_tag(TAG_Describe, 1, (V[]){v_x_2462});
      }
      default: return heff_nomatch(v_c_241);
      }
    }
    case TAG_AbsConst: {
      V v_t_2463 = heff_field(v_x42_2453, 0);
      V v_ru_24x42_2453_24AbsConst = heff_take_reuse(v_x42_2453, 1ULL);
      V v_t_2464 = heff_tag_at(v_ru_24x42_2453_24AbsConst, TAG_CloConst, 1, (V[]){heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_dup(v_g_240), heff_dup(v_c_241), v_t_2463, heff_dup(v_vs_243)))});
      V v_x_2470 = heff_tag_at(v_ru_24x4_242_24SLam, TAG_VLam, 2, (V[]){heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam5, 1, 3, (V[]){v_g_240, v_dom_2452, v_vs_243}), v_t_2464});
      switch (heff_tag_of(v_c_241)) {
      case TAG_N: {
        heff_drop(v_c_241);
        return heff_tag(TAG_Nom, 1, (V[]){v_x_2470});
      }
      case TAG_De: {
        heff_drop(v_c_241);
        return heff_tag(TAG_Describe, 1, (V[]){v_x_2470});
      }
      default: return heff_nomatch(v_c_241);
      }
    }
    default: return heff_nomatch(v_x42_2453);
    }
  }
  case TAG_SCons: {
    V v_fields_2471 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SCons = heff_take_reuse(v_x4_242, 1ULL);
    V v_xs_2472 = heff_get(heff_dup(v_fields_2471), LBL_values);
    V v_t_2475 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2472)), heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam6, 1, 4, (V[]){v_xs_2472, v_g_240, heff_dup(v_c_241), v_vs_243}));
    V v_t_2476 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_fields_2471), LBL_keys), heff_get(v_fields_2471, LBL_byName), v_t_2475});
    V v_x_2477 = heff_tag_at(v_ru_24x4_242_24SCons, TAG_VCons, 1, (V[]){v_t_2476});
    switch (heff_tag_of(v_c_241)) {
    case TAG_N: {
      heff_drop(v_c_241);
      return heff_tag(TAG_Nom, 1, (V[]){v_x_2477});
    }
    case TAG_De: {
      heff_drop(v_c_241);
      return heff_tag(TAG_Describe, 1, (V[]){v_x_2477});
    }
    default: return heff_nomatch(v_c_241);
    }
  }
  case TAG_SProj: {
    V v_t_2478 = heff_field(v_x4_242, 0);
    V v_x_2479 = heff_field(v_x4_242, 1);
    heff_take(v_x4_242, 3ULL);
    heff_drop(v_c_241);
    V v_x2_2480 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t_2478, v_vs_243));
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_Nom: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      heff_take(v_x2_2480, 1ULL);
      return (g_heff_2evalue_2eproj(v_x_2481, v_x_2479));
    }
    case TAG_Describe: {
      V v_x_2482 = heff_field(v_x2_2480, 0);
      heff_take(v_x2_2480, 1ULL);
      return (g_heff_2evalue_2eproj(v_x_2482, v_x_2479));
    }
    case TAG_Become: {
      V v_x_2483 = heff_field(v_x2_2480, 0);
      V v_ru_24x2_2480_24Become = heff_take_reuse(v_x2_2480, 1ULL);
      V v_x1_2484 = (g_heff_2evalue_2eproj(v_x_2483, v_x_2479));
      V v_t_2488;
      switch (heff_tag_of(v_x1_2484)) {
      case TAG_Nom: {
        V v_x_2485 = heff_field(v_x1_2484, 0);
        heff_take(v_x1_2484, 1ULL);
        v_t_2488 = v_x_2485;
        break;
      }
      case TAG_Describe: {
        heff_take(v_x1_2484, 0ULL);
        v_t_2488 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2487 = heff_field(v_x1_2484, 0);
        heff_take(v_x1_2484, 1ULL);
        v_t_2488 = v_x_2487;
        break;
      }
      default: heff_nomatch(v_x1_2484);
      }
      return heff_tag_at(v_ru_24x2_2480_24Become, TAG_Become, 1, (V[]){v_t_2488});
    }
    default: return heff_nomatch(v_x2_2480);
    }
  }
  case TAG_STag: {
    heff_take(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_2493 = heff_field(v_x4_242, 0);
    V v_x_2494 = heff_field(v_x4_242, 1);
    V v_t_27_2495 = heff_field(v_x4_242, 2);
    heff_take(v_x4_242, 7ULL);
    heff_drop(v_c_241);
    V v_x1_2496 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_dup(v_g_240), NTAG(TAG_N), v_t_2493, heff_dup(v_vs_243)));
    V v_t_24100;
    switch (heff_tag_of(v_x1_2496)) {
    case TAG_Nom: {
      V v_x_2497 = heff_field(v_x1_2496, 0);
      heff_take(v_x1_2496, 1ULL);
      v_t_24100 = v_x_2497;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_2496, 0ULL);
      v_t_24100 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2499 = heff_field(v_x1_2496, 0);
      heff_take(v_x1_2496, 1ULL);
      v_t_24100 = v_x_2499;
      break;
    }
    default: heff_nomatch(v_x1_2496);
    }
    V v_x1_24101 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t_27_2495, v_vs_243));
    V v_t_24105;
    switch (heff_tag_of(v_x1_24101)) {
    case TAG_Nom: {
      V v_x_24102 = heff_field(v_x1_24101, 0);
      heff_take(v_x1_24101, 1ULL);
      v_t_24105 = v_x_24102;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_24101, 0ULL);
      v_t_24105 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24104 = heff_field(v_x1_24101, 0);
      heff_take(v_x1_24101, 1ULL);
      v_t_24105 = v_x_24104;
      break;
    }
    default: heff_nomatch(v_x1_24101);
    }
    return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2especialize(v_t_24100, v_x_2494, v_t_24105))});
  }
  case TAG_SIs: {
    V v_t_24106 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIs = heff_take_reuse(v_x4_242, 1ULL);
    heff_drop(v_c_241);
    V v_x1_24107 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t_24106, v_vs_243));
    V v_t_24111;
    switch (heff_tag_of(v_x1_24107)) {
    case TAG_Nom: {
      V v_x_24108 = heff_field(v_x1_24107, 0);
      heff_take(v_x1_24107, 1ULL);
      v_t_24111 = v_x_24108;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_24107, 0ULL);
      v_t_24111 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24110 = heff_field(v_x1_24107, 0);
      heff_take(v_x1_24107, 1ULL);
      v_t_24111 = v_x_24110;
      break;
    }
    default: heff_nomatch(v_x1_24107);
    }
    return heff_tag_at(v_ru_24x4_242_24SIs, TAG_Become, 1, (V[]){v_t_24111});
  }
  case TAG_SOpaque: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_x4_242);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_x4_242);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_242_24SRec = heff_take_reuse(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24116 = heff_field(v_x4_242, 1);
    heff_take(v_x4_242, 2ULL);
    V t_0 = v_g_240;
    V t_1 = v_c_241;
    V t_2 = v_e_24116;
    V t_3 = v_vs_243;
    v_g_240 = t_0;
    v_c_241 = t_1;
    v_x4_242 = t_2;
    v_vs_243 = t_3;
    goto top;
  }
  case TAG_SPrim: {
    V v_ru_24x4_242_24SPrim = heff_take_reuse(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24118 = heff_field(v_x4_242, 0);
    V v_idxs_24119 = heff_field(v_x4_242, 1);
    V v_ty_24120 = heff_field(v_x4_242, 2);
    heff_take(v_x4_242, 7ULL);
    heff_drop(v_c_241);
    V v_sp_24123 = (g_array_2efoldlFrom(heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam7, 2, 1, (V[]){heff_dup(v_vs_243)}), MK_INT(0LL), NTAG(TAG_SpId), v_idxs_24119));
    V v_x1_24124 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_ty_24120, v_vs_243));
    V v_ty_24128;
    switch (heff_tag_of(v_x1_24124)) {
    case TAG_Nom: {
      V v_x_24125 = heff_field(v_x1_24124, 0);
      heff_take(v_x1_24124, 1ULL);
      v_ty_24128 = v_x_24125;
      break;
    }
    case TAG_Describe: {
      heff_take(v_x1_24124, 0ULL);
      v_ty_24128 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24127 = heff_field(v_x1_24124, 0);
      heff_take(v_x1_24124, 1ULL);
      v_ty_24128 = v_x_24127;
      break;
    }
    default: heff_nomatch(v_x1_24124);
    }
    V v_t_24130 = (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HMeta, 1, (V[]){v_m_24118}), v_sp_24123, heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam8, 1, 1, (V[]){v_ty_24128}), NTAG(TAG_Nothing)));
    return heff_tag(TAG_Nom, 1, (V[]){v_t_24130});
  }
  case TAG_SLitInt: {
    V v_ru_24x4_242_24SLitInt = heff_take_reuse(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_242_24SLitFloat = heff_take_reuse(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_242_24SLitString = heff_take_reuse(v_x4_242, 0ULL);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeval_2eevalTermF_24s14(a[0], a[1], a[2], a[3]);
}
V g_heff_2eeval_2eevalTermF_24s14_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  heff_drop(self);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_VU: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VDecode: {
    V v_el_2416 = heff_field(v_t_2410, 4);
    heff_take(v_t_2410, 16ULL);
    return heff_tail(v_el_2416, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VFunction: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VRecord: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VSum: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimInt: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimFloat: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimString: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  case TAG_VPrimArray: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2410});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam2(V self, V *args) {
  V v_u_2437 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_t1_2435 = heff_dup(heff_env(self)[1]);
  V v_vs_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_2437);
  V v_x1_2438 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(v_g_240, NTAG(TAG_N), v_t1_2435, v_vs_243));
  switch (heff_tag_of(v_x1_2438)) {
  case TAG_Nom: {
    V v_x_2439 = heff_field(v_x1_2438, 0);
    heff_take(v_x1_2438, 1ULL);
    return v_x_2439;
  }
  case TAG_Describe: {
    heff_take(v_x1_2438, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2441 = heff_field(v_x1_2438, 0);
    heff_take(v_x1_2438, 1ULL);
    return v_x_2441;
  }
  default: return heff_nomatch(v_x1_2438);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam1(V self, V *args) {
  V v_f_2436 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_t1_2435 = heff_dup(heff_env(self)[1]);
  V v_vs_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2evalue_2eapp(v_f_2436, heff_clo(g_heff_2eeval_2eevalTermF_24s14_lam2, 1, 3, (V[]){v_g_240, v_t1_2435, v_vs_243})));
}
V g_heff_2eeval_2eevalTermF_24s14_lam3(V self, V *args) {
  V v_u_2456 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_dom_2452 = heff_dup(heff_env(self)[1]);
  V v_vs_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_2456);
  V v_x1_2457 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_dom_2452, v_vs_243));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take(v_x1_2457, 1ULL);
    return v_x_2458;
  }
  case TAG_Describe: {
    heff_take(v_x1_2457, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take(v_x1_2457, 1ULL);
    return v_x_2460;
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam4(V self, V *args) {
  V v_vs2_2461 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_c_241 = heff_dup(heff_env(self)[1]);
  V v_t_2455 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2eeval_2eevalTermF_24s14(v_g_240, v_c_241, v_t_2455, v_vs2_2461));
}
V g_heff_2eeval_2eevalTermF_24s14_lam5(V self, V *args) {
  V v_u_2465 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  V v_dom_2452 = heff_dup(heff_env(self)[1]);
  V v_vs_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_u_2465);
  V v_x1_2466 = (g_heff_2eeval_2eevalTypeF_24s15(v_g_240, NTAG(TAG_N), v_dom_2452, v_vs_243));
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_Nom: {
    V v_x_2467 = heff_field(v_x1_2466, 0);
    heff_take(v_x1_2466, 1ULL);
    return v_x_2467;
  }
  case TAG_Describe: {
    heff_take(v_x1_2466, 0ULL);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2469 = heff_field(v_x1_2466, 0);
    heff_take(v_x1_2466, 1ULL);
    return v_x_2469;
  }
  default: return heff_nomatch(v_x1_2466);
  }
}
V g_heff_2eeval_2eevalTermF_24s14_lam6(V self, V *args) {
  V v_i_2473 = args[0];
  V v_xs_2472 = heff_dup(heff_env(self)[0]);
  V v_g_240 = heff_dup(heff_env(self)[1]);
  V v_c_241 = heff_dup(heff_env(self)[2]);
  V v_vs_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2474 = heff_arrayIndex(v_xs_2472, v_i_2473);
  return (g_heff_2eeval_2eevalTermF_24s14(v_g_240, v_c_241, v_t_2474, v_vs_243));
}
V g_heff_2eeval_2eevalTermF_24s14_lam7(V self, V *args) {
  V v_sp_24121 = args[0];
  V v_i_24122 = args[1];
  V v_vs_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_SpApp, 2, (V[]){v_sp_24121, ({ V a_0 = v_vs_243; V a_1 = v_i_24122; V r_ = heff_tr(g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_243); r_; })});
}
V g_heff_2eeval_2eevalTermF_24s14_lam8(V self, V *args) {
  V v_u_24129 = args[0];
  V v_ty_24128 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_u_24129);
  return v_ty_24128;
}