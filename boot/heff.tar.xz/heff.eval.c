// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2efoldlFrom(V, V, V, V);
V g_array_2efoldlFrom_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_clo;
V g_heff_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTermF_clo;
V g_heff_2eeval_2eevalTypeF(V, V, V, V, V);
V g_heff_2eeval_2eevalTypeF_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTypeF_clo;
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(V, V, V, V);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_clo;
V g_heff_2eeval_2eevaluator_get(void);
V g_heff_2evalue_2eapp(V, V);
V g_heff_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2evalue_2eapp_clo;
V g_heff_2evalue_2edecodeN(V);
V g_heff_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2evalue_2edecodeN_clo;
V g_heff_2evalue_2elocalsAt(V, V);
V g_heff_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2evalue_2elocalsAt_clo;
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694(V, V, V, V);
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694_entry(V self, V *a);
extern Clo g_heff_2evalue_2emkNeu_24s1912479565x1511825694_clo;
V g_heff_2evalue_2eproj(V, V);
V g_heff_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2evalue_2eproj_clo;
V g_heff_2evalue_2especialize(V, V, V);
V g_heff_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2evalue_2especialize_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2eeval_2eevalTermF_lam0(V self, V *args); static Clo g_heff_2eeval_2eevalTermF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTermF_lam0, 1, 0};
V g_heff_2eeval_2eevalTermF_lam2(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam1(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam4(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam3(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam6(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam5(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam8(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam7(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam9(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam11(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam10(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam13(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam12(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam15(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam14(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam17(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam16(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam19(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam18(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam21(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam20(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam23(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam22(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam25(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam24(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam27(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam26(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam29(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam28(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam31(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam30(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam33(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam32(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam35(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam34(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam37(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam36(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam39(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam38(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam41(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam40(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam43(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam42(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam45(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam44(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam47(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam46(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam49(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam48(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam50(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam51(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam52(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam53(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam54(V self, V *args);
V g_heff_2eeval_2eevalTermF_lam55(V self, V *args);
Clo g_heff_2eeval_2eevalTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTermF_entry, 5, 0};

V g_heff_2eeval_2eevalTermF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SLocal: {
    V v_i_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SLocal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    return heff_tag_at(v_ru_24x4_243_24SLocal, TAG_Nom, 1, (V[]){({ V a_0 = v_vs_244; V a_1 = v_i_245; V r_ = heff_tr(g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; })});
  }
  case TAG_SGlobal: {
    V v_x_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SGlobal = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    V v_t_247 = ({ V a_0 = v_x_246; V b_1 = heff_get(v_g_241, LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_e_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_e_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    return heff_tag_at(v_ru_24x4_243_24SGlobal, TAG_Nom, 1, (V[]){heff_get(v_t_249, LBL_value)});
  }
  case TAG_SCode: {
    V v_a_2410 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SCode = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_f_2430 = ((V)&g_heff_2eeval_2eevalTermF_lam0_clo);
    V v_x2_2431 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, v_c_242, v_a_2410, v_vs_244}));
    switch (heff_tag_of(v_x2_2431)) {
    case TAG_Nom: {
      V v_x_2432 = heff_field(v_x2_2431, 0);
      heff_take_n(v_x2_2431, 1ULL, 1);
      V v_t_2433 = heff_tr(heff_apply(v_f_2430, 1, (V[]){v_x_2432}));
      return heff_tag_at(v_ru_24x4_243_24SCode, TAG_Nom, 1, (V[]){v_t_2433});
    }
    case TAG_Describe: {
      V v_x_2434 = heff_field(v_x2_2431, 0);
      heff_take_n(v_x2_2431, 1ULL, 1);
      V v_t_2435 = heff_tr(heff_apply(v_f_2430, 1, (V[]){v_x_2434}));
      return heff_tag_at(v_ru_24x4_243_24SCode, TAG_Describe, 1, (V[]){v_t_2435});
    }
    case TAG_Become: {
      V v_x_2436 = heff_field(v_x2_2431, 0);
      heff_take_n(v_x2_2431, 1ULL, 1);
      V v_t_2437 = heff_tr(heff_apply(v_f_2430, 1, (V[]){v_x_2436}));
      return heff_tag_at(v_ru_24x4_243_24SCode, TAG_Become, 1, (V[]){v_t_2437});
    }
    default: return heff_nomatch(v_x2_2431);
    }
  }
  case TAG_SApp: {
    V v_x41_2438 = heff_field(v_x4_243, 0);
    V v_t1_2439 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_2438)) {
    case TAG_SLocal: {
      heff_drop(v_c_242);
      V v_f_2447 = heff_clo(g_heff_2eeval_2eevalTermF_lam1, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_2448 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_Nom: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        heff_take_n(v_x2_2448, 1ULL, 1);
        return heff_tail(v_f_2447, 1, (V[]){v_x_2449});
      }
      case TAG_Describe: {
        V v_x_2450 = heff_field(v_x2_2448, 0);
        heff_take_n(v_x2_2448, 1ULL, 1);
        return heff_tail(v_f_2447, 1, (V[]){v_x_2450});
      }
      case TAG_Become: {
        V v_x_2451 = heff_field(v_x2_2448, 0);
        V v_ru_24x2_2448_24Become = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
        V v_x1_2452 = heff_tr(heff_apply(v_f_2447, 1, (V[]){v_x_2451}));
        V v_t_2456;
        switch (heff_tag_of(v_x1_2452)) {
        case TAG_Nom: {
          V v_x_2453 = heff_field(v_x1_2452, 0);
          heff_take_n(v_x1_2452, 1ULL, 1);
          v_t_2456 = v_x_2453;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2452, 0ULL, 1);
          v_t_2456 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2455 = heff_field(v_x1_2452, 0);
          heff_take_n(v_x1_2452, 1ULL, 1);
          v_t_2456 = v_x_2455;
          break;
        }
        default: heff_nomatch(v_x1_2452);
        }
        return heff_tag_at(v_ru_24x2_2448_24Become, TAG_Become, 1, (V[]){v_t_2456});
      }
      default: return heff_nomatch(v_x2_2448);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_c_242);
      V v_f_2464 = heff_clo(g_heff_2eeval_2eevalTermF_lam3, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_2465 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_Nom: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        heff_take_n(v_x2_2465, 1ULL, 1);
        return heff_tail(v_f_2464, 1, (V[]){v_x_2466});
      }
      case TAG_Describe: {
        V v_x_2467 = heff_field(v_x2_2465, 0);
        heff_take_n(v_x2_2465, 1ULL, 1);
        return heff_tail(v_f_2464, 1, (V[]){v_x_2467});
      }
      case TAG_Become: {
        V v_x_2468 = heff_field(v_x2_2465, 0);
        V v_ru_24x2_2465_24Become = heff_take_reuse_n(v_x2_2465, 1ULL, 1);
        V v_x1_2469 = heff_tr(heff_apply(v_f_2464, 1, (V[]){v_x_2468}));
        V v_t_2473;
        switch (heff_tag_of(v_x1_2469)) {
        case TAG_Nom: {
          V v_x_2470 = heff_field(v_x1_2469, 0);
          heff_take_n(v_x1_2469, 1ULL, 1);
          v_t_2473 = v_x_2470;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2469, 0ULL, 1);
          v_t_2473 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2472 = heff_field(v_x1_2469, 0);
          heff_take_n(v_x1_2469, 1ULL, 1);
          v_t_2473 = v_x_2472;
          break;
        }
        default: heff_nomatch(v_x1_2469);
        }
        return heff_tag_at(v_ru_24x2_2465_24Become, TAG_Become, 1, (V[]){v_t_2473});
      }
      default: return heff_nomatch(v_x2_2465);
      }
    }
    case TAG_SCode: {
      heff_drop(v_c_242);
      V v_f_2481 = heff_clo(g_heff_2eeval_2eevalTermF_lam5, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_2482 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_2482)) {
      case TAG_Nom: {
        V v_x_2483 = heff_field(v_x2_2482, 0);
        heff_take_n(v_x2_2482, 1ULL, 1);
        return heff_tail(v_f_2481, 1, (V[]){v_x_2483});
      }
      case TAG_Describe: {
        V v_x_2484 = heff_field(v_x2_2482, 0);
        heff_take_n(v_x2_2482, 1ULL, 1);
        return heff_tail(v_f_2481, 1, (V[]){v_x_2484});
      }
      case TAG_Become: {
        V v_x_2485 = heff_field(v_x2_2482, 0);
        V v_ru_24x2_2482_24Become = heff_take_reuse_n(v_x2_2482, 1ULL, 1);
        V v_x1_2486 = heff_tr(heff_apply(v_f_2481, 1, (V[]){v_x_2485}));
        V v_t_2490;
        switch (heff_tag_of(v_x1_2486)) {
        case TAG_Nom: {
          V v_x_2487 = heff_field(v_x1_2486, 0);
          heff_take_n(v_x1_2486, 1ULL, 1);
          v_t_2490 = v_x_2487;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2486, 0ULL, 1);
          v_t_2490 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2489 = heff_field(v_x1_2486, 0);
          heff_take_n(v_x1_2486, 1ULL, 1);
          v_t_2490 = v_x_2489;
          break;
        }
        default: heff_nomatch(v_x1_2486);
        }
        return heff_tag_at(v_ru_24x2_2482_24Become, TAG_Become, 1, (V[]){v_t_2490});
      }
      default: return heff_nomatch(v_x2_2482);
      }
    }
    case TAG_SApp: {
      heff_drop(v_c_242);
      V v_f_2499 = heff_clo(g_heff_2eeval_2eevalTermF_lam7, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24100 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24100)) {
      case TAG_Nom: {
        V v_x_24101 = heff_field(v_x2_24100, 0);
        heff_take_n(v_x2_24100, 1ULL, 1);
        return heff_tail(v_f_2499, 1, (V[]){v_x_24101});
      }
      case TAG_Describe: {
        V v_x_24102 = heff_field(v_x2_24100, 0);
        heff_take_n(v_x2_24100, 1ULL, 1);
        return heff_tail(v_f_2499, 1, (V[]){v_x_24102});
      }
      case TAG_Become: {
        V v_x_24103 = heff_field(v_x2_24100, 0);
        V v_ru_24x2_24100_24Become = heff_take_reuse_n(v_x2_24100, 1ULL, 1);
        V v_x1_24104 = heff_tr(heff_apply(v_f_2499, 1, (V[]){v_x_24103}));
        V v_t_24108;
        switch (heff_tag_of(v_x1_24104)) {
        case TAG_Nom: {
          V v_x_24105 = heff_field(v_x1_24104, 0);
          heff_take_n(v_x1_24104, 1ULL, 1);
          v_t_24108 = v_x_24105;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24104, 0ULL, 1);
          v_t_24108 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24107 = heff_field(v_x1_24104, 0);
          heff_take_n(v_x1_24104, 1ULL, 1);
          v_t_24108 = v_x_24107;
          break;
        }
        default: heff_nomatch(v_x1_24104);
        }
        return heff_tag_at(v_ru_24x2_24100_24Become, TAG_Become, 1, (V[]){v_t_24108});
      }
      default: return heff_nomatch(v_x2_24100);
      }
    }
    case TAG_SLam: {
      V v_x412_24110 = heff_dup(heff_field(v_x41_2438, 1));
      switch (heff_tag_of(v_x412_24110)) {
      case TAG_MkAbs: {
        V v_t_24112 = heff_field(v_x412_24110, 1);
        heff_take_n(v_x412_24110, 2ULL, 2);
        heff_drop_tag(v_x41_2438, 2);
        return heff_tail(heff_get(heff_dup(v_r_240), LBL_el), 4, (V[]){heff_dup(v_g_241), v_c_242, v_t_24112, heff_tag(TAG_LSnoc, 2, (V[]){heff_dup(v_vs_244), heff_clo(g_heff_2eeval_2eevalTermF_lam9, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})})});
      }
      case TAG_AbsConst: {
        V v_ru_24x412_24110_24AbsConst = heff_take_reuse_n(v_x412_24110, 0ULL, 1);
        heff_drop(v_c_242);
        V v_f_24125 = heff_clo(g_heff_2eeval_2eevalTermF_lam10, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
        V v_x2_24126 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
        switch (heff_tag_of(v_x2_24126)) {
        case TAG_Nom: {
          V v_x_24127 = heff_field(v_x2_24126, 0);
          heff_take_n(v_x2_24126, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_24110_24AbsConst, 1);
          return heff_tail(v_f_24125, 1, (V[]){v_x_24127});
        }
        case TAG_Describe: {
          V v_x_24128 = heff_field(v_x2_24126, 0);
          heff_take_n(v_x2_24126, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_24110_24AbsConst, 1);
          return heff_tail(v_f_24125, 1, (V[]){v_x_24128});
        }
        case TAG_Become: {
          V v_x_24129 = heff_field(v_x2_24126, 0);
          heff_take_n(v_x2_24126, 1ULL, 1);
          V v_x1_24130 = heff_tr(heff_apply(v_f_24125, 1, (V[]){v_x_24129}));
          V v_t_24134;
          switch (heff_tag_of(v_x1_24130)) {
          case TAG_Nom: {
            V v_x_24131 = heff_field(v_x1_24130, 0);
            heff_take_n(v_x1_24130, 1ULL, 1);
            v_t_24134 = v_x_24131;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_24130, 0ULL, 1);
            v_t_24134 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_24133 = heff_field(v_x1_24130, 0);
            heff_take_n(v_x1_24130, 1ULL, 1);
            v_t_24134 = v_x_24133;
            break;
          }
          default: heff_nomatch(v_x1_24130);
          }
          return heff_tag_at(v_ru_24x412_24110_24AbsConst, TAG_Become, 1, (V[]){v_t_24134});
        }
        default: return heff_nomatch(v_x2_24126);
        }
      }
      default: return heff_nomatch(v_x412_24110);
      }
    }
    case TAG_SCons: {
      heff_drop(v_c_242);
      V v_f_24142 = heff_clo(g_heff_2eeval_2eevalTermF_lam12, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24143 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24143)) {
      case TAG_Nom: {
        V v_x_24144 = heff_field(v_x2_24143, 0);
        heff_take_n(v_x2_24143, 1ULL, 1);
        return heff_tail(v_f_24142, 1, (V[]){v_x_24144});
      }
      case TAG_Describe: {
        V v_x_24145 = heff_field(v_x2_24143, 0);
        heff_take_n(v_x2_24143, 1ULL, 1);
        return heff_tail(v_f_24142, 1, (V[]){v_x_24145});
      }
      case TAG_Become: {
        V v_x_24146 = heff_field(v_x2_24143, 0);
        V v_ru_24x2_24143_24Become = heff_take_reuse_n(v_x2_24143, 1ULL, 1);
        V v_x1_24147 = heff_tr(heff_apply(v_f_24142, 1, (V[]){v_x_24146}));
        V v_t_24151;
        switch (heff_tag_of(v_x1_24147)) {
        case TAG_Nom: {
          V v_x_24148 = heff_field(v_x1_24147, 0);
          heff_take_n(v_x1_24147, 1ULL, 1);
          v_t_24151 = v_x_24148;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24147, 0ULL, 1);
          v_t_24151 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24150 = heff_field(v_x1_24147, 0);
          heff_take_n(v_x1_24147, 1ULL, 1);
          v_t_24151 = v_x_24150;
          break;
        }
        default: heff_nomatch(v_x1_24147);
        }
        return heff_tag_at(v_ru_24x2_24143_24Become, TAG_Become, 1, (V[]){v_t_24151});
      }
      default: return heff_nomatch(v_x2_24143);
      }
    }
    case TAG_SProj: {
      heff_drop(v_c_242);
      V v_f_24160 = heff_clo(g_heff_2eeval_2eevalTermF_lam14, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24161 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24161)) {
      case TAG_Nom: {
        V v_x_24162 = heff_field(v_x2_24161, 0);
        heff_take_n(v_x2_24161, 1ULL, 1);
        return heff_tail(v_f_24160, 1, (V[]){v_x_24162});
      }
      case TAG_Describe: {
        V v_x_24163 = heff_field(v_x2_24161, 0);
        heff_take_n(v_x2_24161, 1ULL, 1);
        return heff_tail(v_f_24160, 1, (V[]){v_x_24163});
      }
      case TAG_Become: {
        V v_x_24164 = heff_field(v_x2_24161, 0);
        V v_ru_24x2_24161_24Become = heff_take_reuse_n(v_x2_24161, 1ULL, 1);
        V v_x1_24165 = heff_tr(heff_apply(v_f_24160, 1, (V[]){v_x_24164}));
        V v_t_24169;
        switch (heff_tag_of(v_x1_24165)) {
        case TAG_Nom: {
          V v_x_24166 = heff_field(v_x1_24165, 0);
          heff_take_n(v_x1_24165, 1ULL, 1);
          v_t_24169 = v_x_24166;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24165, 0ULL, 1);
          v_t_24169 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24168 = heff_field(v_x1_24165, 0);
          heff_take_n(v_x1_24165, 1ULL, 1);
          v_t_24169 = v_x_24168;
          break;
        }
        default: heff_nomatch(v_x1_24165);
        }
        return heff_tag_at(v_ru_24x2_24161_24Become, TAG_Become, 1, (V[]){v_t_24169});
      }
      default: return heff_nomatch(v_x2_24161);
      }
    }
    case TAG_STag: {
      heff_drop(v_c_242);
      V v_f_24178 = heff_clo(g_heff_2eeval_2eevalTermF_lam16, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24179 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24179)) {
      case TAG_Nom: {
        V v_x_24180 = heff_field(v_x2_24179, 0);
        heff_take_n(v_x2_24179, 1ULL, 1);
        return heff_tail(v_f_24178, 1, (V[]){v_x_24180});
      }
      case TAG_Describe: {
        V v_x_24181 = heff_field(v_x2_24179, 0);
        heff_take_n(v_x2_24179, 1ULL, 1);
        return heff_tail(v_f_24178, 1, (V[]){v_x_24181});
      }
      case TAG_Become: {
        V v_x_24182 = heff_field(v_x2_24179, 0);
        V v_ru_24x2_24179_24Become = heff_take_reuse_n(v_x2_24179, 1ULL, 1);
        V v_x1_24183 = heff_tr(heff_apply(v_f_24178, 1, (V[]){v_x_24182}));
        V v_t_24187;
        switch (heff_tag_of(v_x1_24183)) {
        case TAG_Nom: {
          V v_x_24184 = heff_field(v_x1_24183, 0);
          heff_take_n(v_x1_24183, 1ULL, 1);
          v_t_24187 = v_x_24184;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24183, 0ULL, 1);
          v_t_24187 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24186 = heff_field(v_x1_24183, 0);
          heff_take_n(v_x1_24183, 1ULL, 1);
          v_t_24187 = v_x_24186;
          break;
        }
        default: heff_nomatch(v_x1_24183);
        }
        return heff_tag_at(v_ru_24x2_24179_24Become, TAG_Become, 1, (V[]){v_t_24187});
      }
      default: return heff_nomatch(v_x2_24179);
      }
    }
    case TAG_SMatch: {
      heff_drop(v_c_242);
      V v_f_24196 = heff_clo(g_heff_2eeval_2eevalTermF_lam18, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24197 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24197)) {
      case TAG_Nom: {
        V v_x_24198 = heff_field(v_x2_24197, 0);
        heff_take_n(v_x2_24197, 1ULL, 1);
        return heff_tail(v_f_24196, 1, (V[]){v_x_24198});
      }
      case TAG_Describe: {
        V v_x_24199 = heff_field(v_x2_24197, 0);
        heff_take_n(v_x2_24197, 1ULL, 1);
        return heff_tail(v_f_24196, 1, (V[]){v_x_24199});
      }
      case TAG_Become: {
        V v_x_24200 = heff_field(v_x2_24197, 0);
        V v_ru_24x2_24197_24Become = heff_take_reuse_n(v_x2_24197, 1ULL, 1);
        V v_x1_24201 = heff_tr(heff_apply(v_f_24196, 1, (V[]){v_x_24200}));
        V v_t_24205;
        switch (heff_tag_of(v_x1_24201)) {
        case TAG_Nom: {
          V v_x_24202 = heff_field(v_x1_24201, 0);
          heff_take_n(v_x1_24201, 1ULL, 1);
          v_t_24205 = v_x_24202;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24201, 0ULL, 1);
          v_t_24205 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24204 = heff_field(v_x1_24201, 0);
          heff_take_n(v_x1_24201, 1ULL, 1);
          v_t_24205 = v_x_24204;
          break;
        }
        default: heff_nomatch(v_x1_24201);
        }
        return heff_tag_at(v_ru_24x2_24197_24Become, TAG_Become, 1, (V[]){v_t_24205});
      }
      default: return heff_nomatch(v_x2_24197);
      }
    }
    case TAG_SSpecialize: {
      heff_drop(v_c_242);
      V v_f_24215 = heff_clo(g_heff_2eeval_2eevalTermF_lam20, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24216 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24216)) {
      case TAG_Nom: {
        V v_x_24217 = heff_field(v_x2_24216, 0);
        heff_take_n(v_x2_24216, 1ULL, 1);
        return heff_tail(v_f_24215, 1, (V[]){v_x_24217});
      }
      case TAG_Describe: {
        V v_x_24218 = heff_field(v_x2_24216, 0);
        heff_take_n(v_x2_24216, 1ULL, 1);
        return heff_tail(v_f_24215, 1, (V[]){v_x_24218});
      }
      case TAG_Become: {
        V v_x_24219 = heff_field(v_x2_24216, 0);
        V v_ru_24x2_24216_24Become = heff_take_reuse_n(v_x2_24216, 1ULL, 1);
        V v_x1_24220 = heff_tr(heff_apply(v_f_24215, 1, (V[]){v_x_24219}));
        V v_t_24224;
        switch (heff_tag_of(v_x1_24220)) {
        case TAG_Nom: {
          V v_x_24221 = heff_field(v_x1_24220, 0);
          heff_take_n(v_x1_24220, 1ULL, 1);
          v_t_24224 = v_x_24221;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24220, 0ULL, 1);
          v_t_24224 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24223 = heff_field(v_x1_24220, 0);
          heff_take_n(v_x1_24220, 1ULL, 1);
          v_t_24224 = v_x_24223;
          break;
        }
        default: heff_nomatch(v_x1_24220);
        }
        return heff_tag_at(v_ru_24x2_24216_24Become, TAG_Become, 1, (V[]){v_t_24224});
      }
      default: return heff_nomatch(v_x2_24216);
      }
    }
    case TAG_SIs: {
      heff_drop(v_c_242);
      V v_f_24232 = heff_clo(g_heff_2eeval_2eevalTermF_lam22, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24233 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24233)) {
      case TAG_Nom: {
        V v_x_24234 = heff_field(v_x2_24233, 0);
        heff_take_n(v_x2_24233, 1ULL, 1);
        return heff_tail(v_f_24232, 1, (V[]){v_x_24234});
      }
      case TAG_Describe: {
        V v_x_24235 = heff_field(v_x2_24233, 0);
        heff_take_n(v_x2_24233, 1ULL, 1);
        return heff_tail(v_f_24232, 1, (V[]){v_x_24235});
      }
      case TAG_Become: {
        V v_x_24236 = heff_field(v_x2_24233, 0);
        V v_ru_24x2_24233_24Become = heff_take_reuse_n(v_x2_24233, 1ULL, 1);
        V v_x1_24237 = heff_tr(heff_apply(v_f_24232, 1, (V[]){v_x_24236}));
        V v_t_24241;
        switch (heff_tag_of(v_x1_24237)) {
        case TAG_Nom: {
          V v_x_24238 = heff_field(v_x1_24237, 0);
          heff_take_n(v_x1_24237, 1ULL, 1);
          v_t_24241 = v_x_24238;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24237, 0ULL, 1);
          v_t_24241 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24240 = heff_field(v_x1_24237, 0);
          heff_take_n(v_x1_24237, 1ULL, 1);
          v_t_24241 = v_x_24240;
          break;
        }
        default: heff_nomatch(v_x1_24237);
        }
        return heff_tag_at(v_ru_24x2_24233_24Become, TAG_Become, 1, (V[]){v_t_24241});
      }
      default: return heff_nomatch(v_x2_24233);
      }
    }
    case TAG_SOpaque: {
      heff_drop(v_c_242);
      V v_f_24248 = heff_clo(g_heff_2eeval_2eevalTermF_lam24, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24249 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24249)) {
      case TAG_Nom: {
        V v_x_24250 = heff_field(v_x2_24249, 0);
        heff_take_n(v_x2_24249, 1ULL, 1);
        return heff_tail(v_f_24248, 1, (V[]){v_x_24250});
      }
      case TAG_Describe: {
        V v_x_24251 = heff_field(v_x2_24249, 0);
        heff_take_n(v_x2_24249, 1ULL, 1);
        return heff_tail(v_f_24248, 1, (V[]){v_x_24251});
      }
      case TAG_Become: {
        V v_x_24252 = heff_field(v_x2_24249, 0);
        V v_ru_24x2_24249_24Become = heff_take_reuse_n(v_x2_24249, 1ULL, 1);
        V v_x1_24253 = heff_tr(heff_apply(v_f_24248, 1, (V[]){v_x_24252}));
        V v_t_24257;
        switch (heff_tag_of(v_x1_24253)) {
        case TAG_Nom: {
          V v_x_24254 = heff_field(v_x1_24253, 0);
          heff_take_n(v_x1_24253, 1ULL, 1);
          v_t_24257 = v_x_24254;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24253, 0ULL, 1);
          v_t_24257 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24256 = heff_field(v_x1_24253, 0);
          heff_take_n(v_x1_24253, 1ULL, 1);
          v_t_24257 = v_x_24256;
          break;
        }
        default: heff_nomatch(v_x1_24253);
        }
        return heff_tag_at(v_ru_24x2_24249_24Become, TAG_Become, 1, (V[]){v_t_24257});
      }
      default: return heff_nomatch(v_x2_24249);
      }
    }
    case TAG_SAbandon: {
      heff_drop(v_c_242);
      V v_f_24264 = heff_clo(g_heff_2eeval_2eevalTermF_lam26, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24265 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24265)) {
      case TAG_Nom: {
        V v_x_24266 = heff_field(v_x2_24265, 0);
        heff_take_n(v_x2_24265, 1ULL, 1);
        return heff_tail(v_f_24264, 1, (V[]){v_x_24266});
      }
      case TAG_Describe: {
        V v_x_24267 = heff_field(v_x2_24265, 0);
        heff_take_n(v_x2_24265, 1ULL, 1);
        return heff_tail(v_f_24264, 1, (V[]){v_x_24267});
      }
      case TAG_Become: {
        V v_x_24268 = heff_field(v_x2_24265, 0);
        V v_ru_24x2_24265_24Become = heff_take_reuse_n(v_x2_24265, 1ULL, 1);
        V v_x1_24269 = heff_tr(heff_apply(v_f_24264, 1, (V[]){v_x_24268}));
        V v_t_24273;
        switch (heff_tag_of(v_x1_24269)) {
        case TAG_Nom: {
          V v_x_24270 = heff_field(v_x1_24269, 0);
          heff_take_n(v_x1_24269, 1ULL, 1);
          v_t_24273 = v_x_24270;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24269, 0ULL, 1);
          v_t_24273 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24272 = heff_field(v_x1_24269, 0);
          heff_take_n(v_x1_24269, 1ULL, 1);
          v_t_24273 = v_x_24272;
          break;
        }
        default: heff_nomatch(v_x1_24269);
        }
        return heff_tag_at(v_ru_24x2_24265_24Become, TAG_Become, 1, (V[]){v_t_24273});
      }
      default: return heff_nomatch(v_x2_24265);
      }
    }
    case TAG_SRec: {
      heff_drop(v_c_242);
      V v_f_24281 = heff_clo(g_heff_2eeval_2eevalTermF_lam28, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24282 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24282)) {
      case TAG_Nom: {
        V v_x_24283 = heff_field(v_x2_24282, 0);
        heff_take_n(v_x2_24282, 1ULL, 1);
        return heff_tail(v_f_24281, 1, (V[]){v_x_24283});
      }
      case TAG_Describe: {
        V v_x_24284 = heff_field(v_x2_24282, 0);
        heff_take_n(v_x2_24282, 1ULL, 1);
        return heff_tail(v_f_24281, 1, (V[]){v_x_24284});
      }
      case TAG_Become: {
        V v_x_24285 = heff_field(v_x2_24282, 0);
        V v_ru_24x2_24282_24Become = heff_take_reuse_n(v_x2_24282, 1ULL, 1);
        V v_x1_24286 = heff_tr(heff_apply(v_f_24281, 1, (V[]){v_x_24285}));
        V v_t_24290;
        switch (heff_tag_of(v_x1_24286)) {
        case TAG_Nom: {
          V v_x_24287 = heff_field(v_x1_24286, 0);
          heff_take_n(v_x1_24286, 1ULL, 1);
          v_t_24290 = v_x_24287;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24286, 0ULL, 1);
          v_t_24290 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24289 = heff_field(v_x1_24286, 0);
          heff_take_n(v_x1_24286, 1ULL, 1);
          v_t_24290 = v_x_24289;
          break;
        }
        default: heff_nomatch(v_x1_24286);
        }
        return heff_tag_at(v_ru_24x2_24282_24Become, TAG_Become, 1, (V[]){v_t_24290});
      }
      default: return heff_nomatch(v_x2_24282);
      }
    }
    case TAG_SFix: {
      heff_drop(v_c_242);
      V v_f_24299 = heff_clo(g_heff_2eeval_2eevalTermF_lam30, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24300 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24300)) {
      case TAG_Nom: {
        V v_x_24301 = heff_field(v_x2_24300, 0);
        heff_take_n(v_x2_24300, 1ULL, 1);
        return heff_tail(v_f_24299, 1, (V[]){v_x_24301});
      }
      case TAG_Describe: {
        V v_x_24302 = heff_field(v_x2_24300, 0);
        heff_take_n(v_x2_24300, 1ULL, 1);
        return heff_tail(v_f_24299, 1, (V[]){v_x_24302});
      }
      case TAG_Become: {
        V v_x_24303 = heff_field(v_x2_24300, 0);
        V v_ru_24x2_24300_24Become = heff_take_reuse_n(v_x2_24300, 1ULL, 1);
        V v_x1_24304 = heff_tr(heff_apply(v_f_24299, 1, (V[]){v_x_24303}));
        V v_t_24308;
        switch (heff_tag_of(v_x1_24304)) {
        case TAG_Nom: {
          V v_x_24305 = heff_field(v_x1_24304, 0);
          heff_take_n(v_x1_24304, 1ULL, 1);
          v_t_24308 = v_x_24305;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24304, 0ULL, 1);
          v_t_24308 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24307 = heff_field(v_x1_24304, 0);
          heff_take_n(v_x1_24304, 1ULL, 1);
          v_t_24308 = v_x_24307;
          break;
        }
        default: heff_nomatch(v_x1_24304);
        }
        return heff_tag_at(v_ru_24x2_24300_24Become, TAG_Become, 1, (V[]){v_t_24308});
      }
      default: return heff_nomatch(v_x2_24300);
      }
    }
    case TAG_SImplicit: {
      heff_drop(v_c_242);
      V v_f_24317 = heff_clo(g_heff_2eeval_2eevalTermF_lam32, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24318 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24318)) {
      case TAG_Nom: {
        V v_x_24319 = heff_field(v_x2_24318, 0);
        heff_take_n(v_x2_24318, 1ULL, 1);
        return heff_tail(v_f_24317, 1, (V[]){v_x_24319});
      }
      case TAG_Describe: {
        V v_x_24320 = heff_field(v_x2_24318, 0);
        heff_take_n(v_x2_24318, 1ULL, 1);
        return heff_tail(v_f_24317, 1, (V[]){v_x_24320});
      }
      case TAG_Become: {
        V v_x_24321 = heff_field(v_x2_24318, 0);
        V v_ru_24x2_24318_24Become = heff_take_reuse_n(v_x2_24318, 1ULL, 1);
        V v_x1_24322 = heff_tr(heff_apply(v_f_24317, 1, (V[]){v_x_24321}));
        V v_t_24326;
        switch (heff_tag_of(v_x1_24322)) {
        case TAG_Nom: {
          V v_x_24323 = heff_field(v_x1_24322, 0);
          heff_take_n(v_x1_24322, 1ULL, 1);
          v_t_24326 = v_x_24323;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24322, 0ULL, 1);
          v_t_24326 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24325 = heff_field(v_x1_24322, 0);
          heff_take_n(v_x1_24322, 1ULL, 1);
          v_t_24326 = v_x_24325;
          break;
        }
        default: heff_nomatch(v_x1_24322);
        }
        return heff_tag_at(v_ru_24x2_24318_24Become, TAG_Become, 1, (V[]){v_t_24326});
      }
      default: return heff_nomatch(v_x2_24318);
      }
    }
    case TAG_SPrim: {
      heff_drop(v_c_242);
      V v_f_24334 = heff_clo(g_heff_2eeval_2eevalTermF_lam34, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24335 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24335)) {
      case TAG_Nom: {
        V v_x_24336 = heff_field(v_x2_24335, 0);
        heff_take_n(v_x2_24335, 1ULL, 1);
        return heff_tail(v_f_24334, 1, (V[]){v_x_24336});
      }
      case TAG_Describe: {
        V v_x_24337 = heff_field(v_x2_24335, 0);
        heff_take_n(v_x2_24335, 1ULL, 1);
        return heff_tail(v_f_24334, 1, (V[]){v_x_24337});
      }
      case TAG_Become: {
        V v_x_24338 = heff_field(v_x2_24335, 0);
        V v_ru_24x2_24335_24Become = heff_take_reuse_n(v_x2_24335, 1ULL, 1);
        V v_x1_24339 = heff_tr(heff_apply(v_f_24334, 1, (V[]){v_x_24338}));
        V v_t_24343;
        switch (heff_tag_of(v_x1_24339)) {
        case TAG_Nom: {
          V v_x_24340 = heff_field(v_x1_24339, 0);
          heff_take_n(v_x1_24339, 1ULL, 1);
          v_t_24343 = v_x_24340;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24339, 0ULL, 1);
          v_t_24343 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24342 = heff_field(v_x1_24339, 0);
          heff_take_n(v_x1_24339, 1ULL, 1);
          v_t_24343 = v_x_24342;
          break;
        }
        default: heff_nomatch(v_x1_24339);
        }
        return heff_tag_at(v_ru_24x2_24335_24Become, TAG_Become, 1, (V[]){v_t_24343});
      }
      default: return heff_nomatch(v_x2_24335);
      }
    }
    case TAG_SMetaApp: {
      heff_drop(v_c_242);
      V v_f_24353 = heff_clo(g_heff_2eeval_2eevalTermF_lam36, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24354 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24354)) {
      case TAG_Nom: {
        V v_x_24355 = heff_field(v_x2_24354, 0);
        heff_take_n(v_x2_24354, 1ULL, 1);
        return heff_tail(v_f_24353, 1, (V[]){v_x_24355});
      }
      case TAG_Describe: {
        V v_x_24356 = heff_field(v_x2_24354, 0);
        heff_take_n(v_x2_24354, 1ULL, 1);
        return heff_tail(v_f_24353, 1, (V[]){v_x_24356});
      }
      case TAG_Become: {
        V v_x_24357 = heff_field(v_x2_24354, 0);
        V v_ru_24x2_24354_24Become = heff_take_reuse_n(v_x2_24354, 1ULL, 1);
        V v_x1_24358 = heff_tr(heff_apply(v_f_24353, 1, (V[]){v_x_24357}));
        V v_t_24362;
        switch (heff_tag_of(v_x1_24358)) {
        case TAG_Nom: {
          V v_x_24359 = heff_field(v_x1_24358, 0);
          heff_take_n(v_x1_24358, 1ULL, 1);
          v_t_24362 = v_x_24359;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24358, 0ULL, 1);
          v_t_24362 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24361 = heff_field(v_x1_24358, 0);
          heff_take_n(v_x1_24358, 1ULL, 1);
          v_t_24362 = v_x_24361;
          break;
        }
        default: heff_nomatch(v_x1_24358);
        }
        return heff_tag_at(v_ru_24x2_24354_24Become, TAG_Become, 1, (V[]){v_t_24362});
      }
      default: return heff_nomatch(v_x2_24354);
      }
    }
    case TAG_SLitInt: {
      heff_drop(v_c_242);
      V v_f_24370 = heff_clo(g_heff_2eeval_2eevalTermF_lam38, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24371 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24371)) {
      case TAG_Nom: {
        V v_x_24372 = heff_field(v_x2_24371, 0);
        heff_take_n(v_x2_24371, 1ULL, 1);
        return heff_tail(v_f_24370, 1, (V[]){v_x_24372});
      }
      case TAG_Describe: {
        V v_x_24373 = heff_field(v_x2_24371, 0);
        heff_take_n(v_x2_24371, 1ULL, 1);
        return heff_tail(v_f_24370, 1, (V[]){v_x_24373});
      }
      case TAG_Become: {
        V v_x_24374 = heff_field(v_x2_24371, 0);
        V v_ru_24x2_24371_24Become = heff_take_reuse_n(v_x2_24371, 1ULL, 1);
        V v_x1_24375 = heff_tr(heff_apply(v_f_24370, 1, (V[]){v_x_24374}));
        V v_t_24379;
        switch (heff_tag_of(v_x1_24375)) {
        case TAG_Nom: {
          V v_x_24376 = heff_field(v_x1_24375, 0);
          heff_take_n(v_x1_24375, 1ULL, 1);
          v_t_24379 = v_x_24376;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24375, 0ULL, 1);
          v_t_24379 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24378 = heff_field(v_x1_24375, 0);
          heff_take_n(v_x1_24375, 1ULL, 1);
          v_t_24379 = v_x_24378;
          break;
        }
        default: heff_nomatch(v_x1_24375);
        }
        return heff_tag_at(v_ru_24x2_24371_24Become, TAG_Become, 1, (V[]){v_t_24379});
      }
      default: return heff_nomatch(v_x2_24371);
      }
    }
    case TAG_SLitFloat: {
      heff_drop(v_c_242);
      V v_f_24387 = heff_clo(g_heff_2eeval_2eevalTermF_lam40, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24388 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24388)) {
      case TAG_Nom: {
        V v_x_24389 = heff_field(v_x2_24388, 0);
        heff_take_n(v_x2_24388, 1ULL, 1);
        return heff_tail(v_f_24387, 1, (V[]){v_x_24389});
      }
      case TAG_Describe: {
        V v_x_24390 = heff_field(v_x2_24388, 0);
        heff_take_n(v_x2_24388, 1ULL, 1);
        return heff_tail(v_f_24387, 1, (V[]){v_x_24390});
      }
      case TAG_Become: {
        V v_x_24391 = heff_field(v_x2_24388, 0);
        V v_ru_24x2_24388_24Become = heff_take_reuse_n(v_x2_24388, 1ULL, 1);
        V v_x1_24392 = heff_tr(heff_apply(v_f_24387, 1, (V[]){v_x_24391}));
        V v_t_24396;
        switch (heff_tag_of(v_x1_24392)) {
        case TAG_Nom: {
          V v_x_24393 = heff_field(v_x1_24392, 0);
          heff_take_n(v_x1_24392, 1ULL, 1);
          v_t_24396 = v_x_24393;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24392, 0ULL, 1);
          v_t_24396 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24395 = heff_field(v_x1_24392, 0);
          heff_take_n(v_x1_24392, 1ULL, 1);
          v_t_24396 = v_x_24395;
          break;
        }
        default: heff_nomatch(v_x1_24392);
        }
        return heff_tag_at(v_ru_24x2_24388_24Become, TAG_Become, 1, (V[]){v_t_24396});
      }
      default: return heff_nomatch(v_x2_24388);
      }
    }
    case TAG_SLitString: {
      heff_drop(v_c_242);
      V v_f_24404 = heff_clo(g_heff_2eeval_2eevalTermF_lam42, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24405 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24405)) {
      case TAG_Nom: {
        V v_x_24406 = heff_field(v_x2_24405, 0);
        heff_take_n(v_x2_24405, 1ULL, 1);
        return heff_tail(v_f_24404, 1, (V[]){v_x_24406});
      }
      case TAG_Describe: {
        V v_x_24407 = heff_field(v_x2_24405, 0);
        heff_take_n(v_x2_24405, 1ULL, 1);
        return heff_tail(v_f_24404, 1, (V[]){v_x_24407});
      }
      case TAG_Become: {
        V v_x_24408 = heff_field(v_x2_24405, 0);
        V v_ru_24x2_24405_24Become = heff_take_reuse_n(v_x2_24405, 1ULL, 1);
        V v_x1_24409 = heff_tr(heff_apply(v_f_24404, 1, (V[]){v_x_24408}));
        V v_t_24413;
        switch (heff_tag_of(v_x1_24409)) {
        case TAG_Nom: {
          V v_x_24410 = heff_field(v_x1_24409, 0);
          heff_take_n(v_x1_24409, 1ULL, 1);
          v_t_24413 = v_x_24410;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24409, 0ULL, 1);
          v_t_24413 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24412 = heff_field(v_x1_24409, 0);
          heff_take_n(v_x1_24409, 1ULL, 1);
          v_t_24413 = v_x_24412;
          break;
        }
        default: heff_nomatch(v_x1_24409);
        }
        return heff_tag_at(v_ru_24x2_24405_24Become, TAG_Become, 1, (V[]){v_t_24413});
      }
      default: return heff_nomatch(v_x2_24405);
      }
    }
    case TAG_SLitRune: {
      heff_drop(v_c_242);
      V v_f_24421 = heff_clo(g_heff_2eeval_2eevalTermF_lam44, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24422)) {
      case TAG_Nom: {
        V v_x_24423 = heff_field(v_x2_24422, 0);
        heff_take_n(v_x2_24422, 1ULL, 1);
        return heff_tail(v_f_24421, 1, (V[]){v_x_24423});
      }
      case TAG_Describe: {
        V v_x_24424 = heff_field(v_x2_24422, 0);
        heff_take_n(v_x2_24422, 1ULL, 1);
        return heff_tail(v_f_24421, 1, (V[]){v_x_24424});
      }
      case TAG_Become: {
        V v_x_24425 = heff_field(v_x2_24422, 0);
        V v_ru_24x2_24422_24Become = heff_take_reuse_n(v_x2_24422, 1ULL, 1);
        V v_x1_24426 = heff_tr(heff_apply(v_f_24421, 1, (V[]){v_x_24425}));
        V v_t_24430;
        switch (heff_tag_of(v_x1_24426)) {
        case TAG_Nom: {
          V v_x_24427 = heff_field(v_x1_24426, 0);
          heff_take_n(v_x1_24426, 1ULL, 1);
          v_t_24430 = v_x_24427;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24426, 0ULL, 1);
          v_t_24430 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24429 = heff_field(v_x1_24426, 0);
          heff_take_n(v_x1_24426, 1ULL, 1);
          v_t_24430 = v_x_24429;
          break;
        }
        default: heff_nomatch(v_x1_24426);
        }
        return heff_tag_at(v_ru_24x2_24422_24Become, TAG_Become, 1, (V[]){v_t_24430});
      }
      default: return heff_nomatch(v_x2_24422);
      }
    }
    case TAG_SLitFixed: {
      heff_drop(v_c_242);
      V v_f_24439 = heff_clo(g_heff_2eeval_2eevalTermF_lam46, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24440 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24440)) {
      case TAG_Nom: {
        V v_x_24441 = heff_field(v_x2_24440, 0);
        heff_take_n(v_x2_24440, 1ULL, 1);
        return heff_tail(v_f_24439, 1, (V[]){v_x_24441});
      }
      case TAG_Describe: {
        V v_x_24442 = heff_field(v_x2_24440, 0);
        heff_take_n(v_x2_24440, 1ULL, 1);
        return heff_tail(v_f_24439, 1, (V[]){v_x_24442});
      }
      case TAG_Become: {
        V v_x_24443 = heff_field(v_x2_24440, 0);
        V v_ru_24x2_24440_24Become = heff_take_reuse_n(v_x2_24440, 1ULL, 1);
        V v_x1_24444 = heff_tr(heff_apply(v_f_24439, 1, (V[]){v_x_24443}));
        V v_t_24448;
        switch (heff_tag_of(v_x1_24444)) {
        case TAG_Nom: {
          V v_x_24445 = heff_field(v_x1_24444, 0);
          heff_take_n(v_x1_24444, 1ULL, 1);
          v_t_24448 = v_x_24445;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24444, 0ULL, 1);
          v_t_24448 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24447 = heff_field(v_x1_24444, 0);
          heff_take_n(v_x1_24444, 1ULL, 1);
          v_t_24448 = v_x_24447;
          break;
        }
        default: heff_nomatch(v_x1_24444);
        }
        return heff_tag_at(v_ru_24x2_24440_24Become, TAG_Become, 1, (V[]){v_t_24448});
      }
      default: return heff_nomatch(v_x2_24440);
      }
    }
    case TAG_SLitFloat32: {
      heff_drop(v_c_242);
      V v_f_24456 = heff_clo(g_heff_2eeval_2eevalTermF_lam48, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_t1_2439, heff_dup(v_vs_244)});
      V v_x2_24457 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_x41_2438, v_vs_244}));
      switch (heff_tag_of(v_x2_24457)) {
      case TAG_Nom: {
        V v_x_24458 = heff_field(v_x2_24457, 0);
        heff_take_n(v_x2_24457, 1ULL, 1);
        return heff_tail(v_f_24456, 1, (V[]){v_x_24458});
      }
      case TAG_Describe: {
        V v_x_24459 = heff_field(v_x2_24457, 0);
        heff_take_n(v_x2_24457, 1ULL, 1);
        return heff_tail(v_f_24456, 1, (V[]){v_x_24459});
      }
      case TAG_Become: {
        V v_x_24460 = heff_field(v_x2_24457, 0);
        V v_ru_24x2_24457_24Become = heff_take_reuse_n(v_x2_24457, 1ULL, 1);
        V v_x1_24461 = heff_tr(heff_apply(v_f_24456, 1, (V[]){v_x_24460}));
        V v_t_24465;
        switch (heff_tag_of(v_x1_24461)) {
        case TAG_Nom: {
          V v_x_24462 = heff_field(v_x1_24461, 0);
          heff_take_n(v_x1_24461, 1ULL, 1);
          v_t_24465 = v_x_24462;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24461, 0ULL, 1);
          v_t_24465 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24464 = heff_field(v_x1_24461, 0);
          heff_take_n(v_x1_24461, 1ULL, 1);
          v_t_24465 = v_x_24464;
          break;
        }
        default: heff_nomatch(v_x1_24461);
        }
        return heff_tag_at(v_ru_24x2_24457_24Become, TAG_Become, 1, (V[]){v_t_24465});
      }
      default: return heff_nomatch(v_x2_24457);
      }
    }
    default: return heff_nomatch(v_x41_2438);
    }
  }
  case TAG_SLam: {
    V v_dom_24466 = heff_field(v_x4_243, 0);
    V v_x42_24467 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24SLam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x42_24467)) {
    case TAG_MkAbs: {
      V v_x_24468 = heff_field(v_x42_24467, 0);
      V v_t_24469 = heff_field(v_x42_24467, 1);
      heff_take_n(v_x42_24467, 3ULL, 2);
      V v_x_24476 = heff_tag_at(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo(g_heff_2eeval_2eevalTermF_lam50, 1, 4, (V[]){heff_dup(v_r_240), heff_dup(v_g_241), v_dom_24466, heff_dup(v_vs_244)}), heff_tag(TAG_MkClo, 3, (V[]){v_x_24468, v_vs_244, heff_clo(g_heff_2eeval_2eevalTermF_lam51, 1, 4, (V[]){v_r_240, v_g_241, heff_dup(v_c_242), v_t_24469})})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag(TAG_Nom, 1, (V[]){v_x_24476});
      }
      case TAG_De: {
        return heff_tag(TAG_Describe, 1, (V[]){v_x_24476});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    case TAG_AbsConst: {
      V v_t_24477 = heff_field(v_x42_24467, 0);
      V v_ru_24x42_24467_24AbsConst = heff_take_reuse_n(v_x42_24467, 1ULL, 1);
      V v_t_24478 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 4, (V[]){heff_dup(v_g_241), heff_dup(v_c_242), v_t_24477, heff_dup(v_vs_244)}));
      V v_x_24484 = heff_tag_at(v_ru_24x4_243_24SLam, TAG_VLam, 2, (V[]){heff_clo(g_heff_2eeval_2eevalTermF_lam52, 1, 4, (V[]){v_r_240, v_g_241, v_dom_24466, v_vs_244}), heff_tag(TAG_CloConst, 1, (V[]){v_t_24478})});
      switch (heff_tag_of(v_c_242)) {
      case TAG_N: {
        return heff_tag_at(v_ru_24x42_24467_24AbsConst, TAG_Nom, 1, (V[]){v_x_24484});
      }
      case TAG_De: {
        return heff_tag_at(v_ru_24x42_24467_24AbsConst, TAG_Describe, 1, (V[]){v_x_24484});
      }
      default: return heff_nomatch(v_c_242);
      }
    }
    default: return heff_nomatch(v_x42_24467);
    }
  }
  case TAG_SCons: {
    V v_fields_24485 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SCons = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_xs_24486 = heff_get(heff_dup(v_fields_24485), LBL_values);
    V v_t_24489 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_24486)), heff_clo(g_heff_2eeval_2eevalTermF_lam53, 1, 5, (V[]){v_xs_24486, v_r_240, v_g_241, heff_dup(v_c_242), v_vs_244}));
    V v_t_24490 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_fields_24485), LBL_keys), heff_get(v_fields_24485, LBL_byName), v_t_24489});
    V v_x_24491 = heff_tag_at(v_ru_24x4_243_24SCons, TAG_VCons, 1, (V[]){v_t_24490});
    switch (heff_tag_of(v_c_242)) {
    case TAG_N: {
      return heff_tag(TAG_Nom, 1, (V[]){v_x_24491});
    }
    case TAG_De: {
      return heff_tag(TAG_Describe, 1, (V[]){v_x_24491});
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  case TAG_SProj: {
    V v_t_24492 = heff_field(v_x4_243, 0);
    V v_x_24493 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    heff_drop(v_c_242);
    V v_x2_24494 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24492, v_vs_244}));
    switch (heff_tag_of(v_x2_24494)) {
    case TAG_Nom: {
      V v_x_24495 = heff_field(v_x2_24494, 0);
      heff_take_n(v_x2_24494, 1ULL, 1);
      return (g_heff_2evalue_2eproj(v_x_24495, v_x_24493));
    }
    case TAG_Describe: {
      V v_x_24496 = heff_field(v_x2_24494, 0);
      heff_take_n(v_x2_24494, 1ULL, 1);
      return (g_heff_2evalue_2eproj(v_x_24496, v_x_24493));
    }
    case TAG_Become: {
      V v_x_24497 = heff_field(v_x2_24494, 0);
      V v_ru_24x2_24494_24Become = heff_take_reuse_n(v_x2_24494, 1ULL, 1);
      V v_x1_24498 = (g_heff_2evalue_2eproj(v_x_24497, v_x_24493));
      V v_t_24502;
      switch (heff_tag_of(v_x1_24498)) {
      case TAG_Nom: {
        V v_x_24499 = heff_field(v_x1_24498, 0);
        heff_take_n(v_x1_24498, 1ULL, 1);
        v_t_24502 = v_x_24499;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24498, 0ULL, 1);
        v_t_24502 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24501 = heff_field(v_x1_24498, 0);
        heff_take_n(v_x1_24498, 1ULL, 1);
        v_t_24502 = v_x_24501;
        break;
      }
      default: heff_nomatch(v_x1_24498);
      }
      return heff_tag_at(v_ru_24x2_24494_24Become, TAG_Become, 1, (V[]){v_t_24502});
    }
    default: return heff_nomatch(v_x2_24494);
    }
  }
  case TAG_STag: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_24507 = heff_field(v_x4_243, 0);
    V v_x_24508 = heff_field(v_x4_243, 1);
    V v_t_27_24509 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_x1_24510 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_t_24507, heff_dup(v_vs_244)}));
    V v_t_24514;
    switch (heff_tag_of(v_x1_24510)) {
    case TAG_Nom: {
      V v_x_24511 = heff_field(v_x1_24510, 0);
      heff_take_n(v_x1_24510, 1ULL, 1);
      v_t_24514 = v_x_24511;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24510, 0ULL, 1);
      v_t_24514 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24513 = heff_field(v_x1_24510, 0);
      heff_take_n(v_x1_24510, 1ULL, 1);
      v_t_24514 = v_x_24513;
      break;
    }
    default: heff_nomatch(v_x1_24510);
    }
    V v_x1_24515 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_27_24509, v_vs_244}));
    V v_t_24519;
    switch (heff_tag_of(v_x1_24515)) {
    case TAG_Nom: {
      V v_x_24516 = heff_field(v_x1_24515, 0);
      heff_take_n(v_x1_24515, 1ULL, 1);
      v_t_24519 = v_x_24516;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24515, 0ULL, 1);
      v_t_24519 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24518 = heff_field(v_x1_24515, 0);
      heff_take_n(v_x1_24515, 1ULL, 1);
      v_t_24519 = v_x_24518;
      break;
    }
    default: heff_nomatch(v_x1_24515);
    }
    return heff_tag(TAG_Nom, 1, (V[]){(g_heff_2evalue_2especialize(v_t_24514, v_x_24508, v_t_24519))});
  }
  case TAG_SIs: {
    V v_t_24520 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIs = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_24521 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_24520, v_vs_244}));
    V v_t_24525;
    switch (heff_tag_of(v_x1_24521)) {
    case TAG_Nom: {
      V v_x_24522 = heff_field(v_x1_24521, 0);
      heff_take_n(v_x1_24521, 1ULL, 1);
      v_t_24525 = v_x_24522;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24521, 0ULL, 1);
      v_t_24525 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24524 = heff_field(v_x1_24521, 0);
      heff_take_n(v_x1_24521, 1ULL, 1);
      v_t_24525 = v_x_24524;
      break;
    }
    default: heff_nomatch(v_x1_24521);
    }
    return heff_tag_at(v_ru_24x4_243_24SIs, TAG_Become, 1, (V[]){v_t_24525});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_243_24SRec = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24530 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 2ULL, 2);
    return heff_tail(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, v_c_242, v_e_24530, v_vs_244});
  }
  case TAG_SPrim: {
    V v_ru_24x4_243_24SPrim = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24532 = heff_field(v_x4_243, 0);
    V v_idxs_24533 = heff_field(v_x4_243, 1);
    V v_ty_24534 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_sp_24537 = (g_array_2efoldlFrom(heff_clo(g_heff_2eeval_2eevalTermF_lam54, 2, 1, (V[]){heff_dup(v_vs_244)}), MK_INT(0LL), NTAG(TAG_SpId), v_idxs_24533));
    V v_x1_24538 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_ty_24534, v_vs_244}));
    V v_ty_24542;
    switch (heff_tag_of(v_x1_24538)) {
    case TAG_Nom: {
      V v_x_24539 = heff_field(v_x1_24538, 0);
      heff_take_n(v_x1_24538, 1ULL, 1);
      v_ty_24542 = v_x_24539;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24538, 0ULL, 1);
      v_ty_24542 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24541 = heff_field(v_x1_24538, 0);
      heff_take_n(v_x1_24538, 1ULL, 1);
      v_ty_24542 = v_x_24541;
      break;
    }
    default: heff_nomatch(v_x1_24538);
    }
    V v_t_24544 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HMeta, 1, (V[]){v_m_24532}), v_sp_24537, heff_clo(g_heff_2eeval_2eevalTermF_lam55, 1, 1, (V[]){v_ty_24542}), NTAG(TAG_Nothing)));
    return heff_tag(TAG_Nom, 1, (V[]){v_t_24544});
  }
  case TAG_SLitInt: {
    V v_ru_24x4_243_24SLitInt = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_243_24SLitFloat = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_243_24SLitString = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitRune: {
    V v_ru_24x4_243_24SLitRune = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SLitRune, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat32: {
    V v_ru_24x4_243_24SLitFloat32 = heff_take_reuse_n(v_x4_243, 0ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SLitFloat32, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eeval_2eevalTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeval_2eevalTermF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eeval_2eevalTermF_lam0(V self, V *args) {
  V v_t_2411 = args[0];
  switch (heff_tag_of(v_t_2411)) {
  case TAG_VU: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VDecode: {
    V v_el_2417 = heff_field(v_t_2411, 4);
    heff_take_n(v_t_2411, 16ULL, 5);
    V f_ = v_el_2417;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VFunction: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VRecord: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VSum: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VPrimInt: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VPrimFloat: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VPrimString: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VPrimRune: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VPrimArray: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  case TAG_VFixed: {
    return heff_tag(TAG_VCode, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2eeval_2eevalTermF_lam2(V self, V *args) {
  V v_u_2442 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2442);
  V v_x1_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nom: {
    V v_x_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    return v_x_2444;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2443, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2446 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    return v_x_2446;
  }
  default: return heff_nomatch(v_x1_2443);
  }
}
V g_heff_2eeval_2eevalTermF_lam1(V self, V *args) {
  V v_f_2441 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_2441, heff_clo(g_heff_2eeval_2eevalTermF_lam2, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam4(V self, V *args) {
  V v_u_2459 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2459);
  V v_x1_2460 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_Nom: {
    V v_x_2461 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2461;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2460, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2463 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2463;
  }
  default: return heff_nomatch(v_x1_2460);
  }
}
V g_heff_2eeval_2eevalTermF_lam3(V self, V *args) {
  V v_f_2458 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_2458, heff_clo(g_heff_2eeval_2eevalTermF_lam4, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam6(V self, V *args) {
  V v_u_2476 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2476);
  V v_x1_2477 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_2477)) {
  case TAG_Nom: {
    V v_x_2478 = heff_field(v_x1_2477, 0);
    heff_take_n(v_x1_2477, 1ULL, 1);
    return v_x_2478;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2477, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2480 = heff_field(v_x1_2477, 0);
    heff_take_n(v_x1_2477, 1ULL, 1);
    return v_x_2480;
  }
  default: return heff_nomatch(v_x1_2477);
  }
}
V g_heff_2eeval_2eevalTermF_lam5(V self, V *args) {
  V v_f_2475 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_2475, heff_clo(g_heff_2eeval_2eevalTermF_lam6, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam8(V self, V *args) {
  V v_u_2494 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2494);
  V v_x1_2495 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_2495)) {
  case TAG_Nom: {
    V v_x_2496 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    return v_x_2496;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2495, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2498 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    return v_x_2498;
  }
  default: return heff_nomatch(v_x1_2495);
  }
}
V g_heff_2eeval_2eevalTermF_lam7(V self, V *args) {
  V v_f_2493 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_2493, heff_clo(g_heff_2eeval_2eevalTermF_lam8, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam9(V self, V *args) {
  V v_u_24113 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24113);
  V v_x1_24114 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24114)) {
  case TAG_Nom: {
    V v_x_24115 = heff_field(v_x1_24114, 0);
    heff_take_n(v_x1_24114, 1ULL, 1);
    return v_x_24115;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24114, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24117 = heff_field(v_x1_24114, 0);
    heff_take_n(v_x1_24114, 1ULL, 1);
    return v_x_24117;
  }
  default: return heff_nomatch(v_x1_24114);
  }
}
V g_heff_2eeval_2eevalTermF_lam11(V self, V *args) {
  V v_u_24120 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24120);
  V v_x1_24121 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24121)) {
  case TAG_Nom: {
    V v_x_24122 = heff_field(v_x1_24121, 0);
    heff_take_n(v_x1_24121, 1ULL, 1);
    return v_x_24122;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24121, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24124 = heff_field(v_x1_24121, 0);
    heff_take_n(v_x1_24121, 1ULL, 1);
    return v_x_24124;
  }
  default: return heff_nomatch(v_x1_24121);
  }
}
V g_heff_2eeval_2eevalTermF_lam10(V self, V *args) {
  V v_f_24119 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24119, heff_clo(g_heff_2eeval_2eevalTermF_lam11, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam13(V self, V *args) {
  V v_u_24137 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24137);
  V v_x1_24138 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24138)) {
  case TAG_Nom: {
    V v_x_24139 = heff_field(v_x1_24138, 0);
    heff_take_n(v_x1_24138, 1ULL, 1);
    return v_x_24139;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24138, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24141 = heff_field(v_x1_24138, 0);
    heff_take_n(v_x1_24138, 1ULL, 1);
    return v_x_24141;
  }
  default: return heff_nomatch(v_x1_24138);
  }
}
V g_heff_2eeval_2eevalTermF_lam12(V self, V *args) {
  V v_f_24136 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24136, heff_clo(g_heff_2eeval_2eevalTermF_lam13, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam15(V self, V *args) {
  V v_u_24155 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24155);
  V v_x1_24156 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24156)) {
  case TAG_Nom: {
    V v_x_24157 = heff_field(v_x1_24156, 0);
    heff_take_n(v_x1_24156, 1ULL, 1);
    return v_x_24157;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24156, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24159 = heff_field(v_x1_24156, 0);
    heff_take_n(v_x1_24156, 1ULL, 1);
    return v_x_24159;
  }
  default: return heff_nomatch(v_x1_24156);
  }
}
V g_heff_2eeval_2eevalTermF_lam14(V self, V *args) {
  V v_f_24154 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24154, heff_clo(g_heff_2eeval_2eevalTermF_lam15, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam17(V self, V *args) {
  V v_u_24173 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24173);
  V v_x1_24174 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24174)) {
  case TAG_Nom: {
    V v_x_24175 = heff_field(v_x1_24174, 0);
    heff_take_n(v_x1_24174, 1ULL, 1);
    return v_x_24175;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24174, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24177 = heff_field(v_x1_24174, 0);
    heff_take_n(v_x1_24174, 1ULL, 1);
    return v_x_24177;
  }
  default: return heff_nomatch(v_x1_24174);
  }
}
V g_heff_2eeval_2eevalTermF_lam16(V self, V *args) {
  V v_f_24172 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24172, heff_clo(g_heff_2eeval_2eevalTermF_lam17, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam19(V self, V *args) {
  V v_u_24191 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24191);
  V v_x1_24192 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24192)) {
  case TAG_Nom: {
    V v_x_24193 = heff_field(v_x1_24192, 0);
    heff_take_n(v_x1_24192, 1ULL, 1);
    return v_x_24193;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24192, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24195 = heff_field(v_x1_24192, 0);
    heff_take_n(v_x1_24192, 1ULL, 1);
    return v_x_24195;
  }
  default: return heff_nomatch(v_x1_24192);
  }
}
V g_heff_2eeval_2eevalTermF_lam18(V self, V *args) {
  V v_f_24190 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24190, heff_clo(g_heff_2eeval_2eevalTermF_lam19, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam21(V self, V *args) {
  V v_u_24210 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24210);
  V v_x1_24211 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24211)) {
  case TAG_Nom: {
    V v_x_24212 = heff_field(v_x1_24211, 0);
    heff_take_n(v_x1_24211, 1ULL, 1);
    return v_x_24212;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24211, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24214 = heff_field(v_x1_24211, 0);
    heff_take_n(v_x1_24211, 1ULL, 1);
    return v_x_24214;
  }
  default: return heff_nomatch(v_x1_24211);
  }
}
V g_heff_2eeval_2eevalTermF_lam20(V self, V *args) {
  V v_f_24209 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24209, heff_clo(g_heff_2eeval_2eevalTermF_lam21, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam23(V self, V *args) {
  V v_u_24227 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24227);
  V v_x1_24228 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24228)) {
  case TAG_Nom: {
    V v_x_24229 = heff_field(v_x1_24228, 0);
    heff_take_n(v_x1_24228, 1ULL, 1);
    return v_x_24229;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24228, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24231 = heff_field(v_x1_24228, 0);
    heff_take_n(v_x1_24228, 1ULL, 1);
    return v_x_24231;
  }
  default: return heff_nomatch(v_x1_24228);
  }
}
V g_heff_2eeval_2eevalTermF_lam22(V self, V *args) {
  V v_f_24226 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24226, heff_clo(g_heff_2eeval_2eevalTermF_lam23, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam25(V self, V *args) {
  V v_u_24243 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24243);
  V v_x1_24244 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24244)) {
  case TAG_Nom: {
    V v_x_24245 = heff_field(v_x1_24244, 0);
    heff_take_n(v_x1_24244, 1ULL, 1);
    return v_x_24245;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24244, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24247 = heff_field(v_x1_24244, 0);
    heff_take_n(v_x1_24244, 1ULL, 1);
    return v_x_24247;
  }
  default: return heff_nomatch(v_x1_24244);
  }
}
V g_heff_2eeval_2eevalTermF_lam24(V self, V *args) {
  V v_f_24242 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24242, heff_clo(g_heff_2eeval_2eevalTermF_lam25, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam27(V self, V *args) {
  V v_u_24259 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24259);
  V v_x1_24260 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24260)) {
  case TAG_Nom: {
    V v_x_24261 = heff_field(v_x1_24260, 0);
    heff_take_n(v_x1_24260, 1ULL, 1);
    return v_x_24261;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24260, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24263 = heff_field(v_x1_24260, 0);
    heff_take_n(v_x1_24260, 1ULL, 1);
    return v_x_24263;
  }
  default: return heff_nomatch(v_x1_24260);
  }
}
V g_heff_2eeval_2eevalTermF_lam26(V self, V *args) {
  V v_f_24258 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24258, heff_clo(g_heff_2eeval_2eevalTermF_lam27, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam29(V self, V *args) {
  V v_u_24276 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24276);
  V v_x1_24277 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24277)) {
  case TAG_Nom: {
    V v_x_24278 = heff_field(v_x1_24277, 0);
    heff_take_n(v_x1_24277, 1ULL, 1);
    return v_x_24278;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24277, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24280 = heff_field(v_x1_24277, 0);
    heff_take_n(v_x1_24277, 1ULL, 1);
    return v_x_24280;
  }
  default: return heff_nomatch(v_x1_24277);
  }
}
V g_heff_2eeval_2eevalTermF_lam28(V self, V *args) {
  V v_f_24275 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24275, heff_clo(g_heff_2eeval_2eevalTermF_lam29, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam31(V self, V *args) {
  V v_u_24294 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24294);
  V v_x1_24295 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24295)) {
  case TAG_Nom: {
    V v_x_24296 = heff_field(v_x1_24295, 0);
    heff_take_n(v_x1_24295, 1ULL, 1);
    return v_x_24296;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24295, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24298 = heff_field(v_x1_24295, 0);
    heff_take_n(v_x1_24295, 1ULL, 1);
    return v_x_24298;
  }
  default: return heff_nomatch(v_x1_24295);
  }
}
V g_heff_2eeval_2eevalTermF_lam30(V self, V *args) {
  V v_f_24293 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24293, heff_clo(g_heff_2eeval_2eevalTermF_lam31, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam33(V self, V *args) {
  V v_u_24312 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24312);
  V v_x1_24313 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24313)) {
  case TAG_Nom: {
    V v_x_24314 = heff_field(v_x1_24313, 0);
    heff_take_n(v_x1_24313, 1ULL, 1);
    return v_x_24314;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24313, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24316 = heff_field(v_x1_24313, 0);
    heff_take_n(v_x1_24313, 1ULL, 1);
    return v_x_24316;
  }
  default: return heff_nomatch(v_x1_24313);
  }
}
V g_heff_2eeval_2eevalTermF_lam32(V self, V *args) {
  V v_f_24311 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24311, heff_clo(g_heff_2eeval_2eevalTermF_lam33, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam35(V self, V *args) {
  V v_u_24329 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24329);
  V v_x1_24330 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24330)) {
  case TAG_Nom: {
    V v_x_24331 = heff_field(v_x1_24330, 0);
    heff_take_n(v_x1_24330, 1ULL, 1);
    return v_x_24331;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24330, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24333 = heff_field(v_x1_24330, 0);
    heff_take_n(v_x1_24330, 1ULL, 1);
    return v_x_24333;
  }
  default: return heff_nomatch(v_x1_24330);
  }
}
V g_heff_2eeval_2eevalTermF_lam34(V self, V *args) {
  V v_f_24328 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24328, heff_clo(g_heff_2eeval_2eevalTermF_lam35, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam37(V self, V *args) {
  V v_u_24348 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24348);
  V v_x1_24349 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24349)) {
  case TAG_Nom: {
    V v_x_24350 = heff_field(v_x1_24349, 0);
    heff_take_n(v_x1_24349, 1ULL, 1);
    return v_x_24350;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24349, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24352 = heff_field(v_x1_24349, 0);
    heff_take_n(v_x1_24349, 1ULL, 1);
    return v_x_24352;
  }
  default: return heff_nomatch(v_x1_24349);
  }
}
V g_heff_2eeval_2eevalTermF_lam36(V self, V *args) {
  V v_f_24347 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24347, heff_clo(g_heff_2eeval_2eevalTermF_lam37, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam39(V self, V *args) {
  V v_u_24365 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24365);
  V v_x1_24366 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24366)) {
  case TAG_Nom: {
    V v_x_24367 = heff_field(v_x1_24366, 0);
    heff_take_n(v_x1_24366, 1ULL, 1);
    return v_x_24367;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24366, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24369 = heff_field(v_x1_24366, 0);
    heff_take_n(v_x1_24366, 1ULL, 1);
    return v_x_24369;
  }
  default: return heff_nomatch(v_x1_24366);
  }
}
V g_heff_2eeval_2eevalTermF_lam38(V self, V *args) {
  V v_f_24364 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24364, heff_clo(g_heff_2eeval_2eevalTermF_lam39, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam41(V self, V *args) {
  V v_u_24382 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24382);
  V v_x1_24383 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24383)) {
  case TAG_Nom: {
    V v_x_24384 = heff_field(v_x1_24383, 0);
    heff_take_n(v_x1_24383, 1ULL, 1);
    return v_x_24384;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24383, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24386 = heff_field(v_x1_24383, 0);
    heff_take_n(v_x1_24383, 1ULL, 1);
    return v_x_24386;
  }
  default: return heff_nomatch(v_x1_24383);
  }
}
V g_heff_2eeval_2eevalTermF_lam40(V self, V *args) {
  V v_f_24381 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24381, heff_clo(g_heff_2eeval_2eevalTermF_lam41, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam43(V self, V *args) {
  V v_u_24399 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24399);
  V v_x1_24400 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24400)) {
  case TAG_Nom: {
    V v_x_24401 = heff_field(v_x1_24400, 0);
    heff_take_n(v_x1_24400, 1ULL, 1);
    return v_x_24401;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24400, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24403 = heff_field(v_x1_24400, 0);
    heff_take_n(v_x1_24400, 1ULL, 1);
    return v_x_24403;
  }
  default: return heff_nomatch(v_x1_24400);
  }
}
V g_heff_2eeval_2eevalTermF_lam42(V self, V *args) {
  V v_f_24398 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24398, heff_clo(g_heff_2eeval_2eevalTermF_lam43, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam45(V self, V *args) {
  V v_u_24416 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24416);
  V v_x1_24417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24417)) {
  case TAG_Nom: {
    V v_x_24418 = heff_field(v_x1_24417, 0);
    heff_take_n(v_x1_24417, 1ULL, 1);
    return v_x_24418;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24417, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24420 = heff_field(v_x1_24417, 0);
    heff_take_n(v_x1_24417, 1ULL, 1);
    return v_x_24420;
  }
  default: return heff_nomatch(v_x1_24417);
  }
}
V g_heff_2eeval_2eevalTermF_lam44(V self, V *args) {
  V v_f_24415 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24415, heff_clo(g_heff_2eeval_2eevalTermF_lam45, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam47(V self, V *args) {
  V v_u_24434 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24434);
  V v_x1_24435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24435)) {
  case TAG_Nom: {
    V v_x_24436 = heff_field(v_x1_24435, 0);
    heff_take_n(v_x1_24435, 1ULL, 1);
    return v_x_24436;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24435, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24438 = heff_field(v_x1_24435, 0);
    heff_take_n(v_x1_24435, 1ULL, 1);
    return v_x_24438;
  }
  default: return heff_nomatch(v_x1_24435);
  }
}
V g_heff_2eeval_2eevalTermF_lam46(V self, V *args) {
  V v_f_24433 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24433, heff_clo(g_heff_2eeval_2eevalTermF_lam47, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam49(V self, V *args) {
  V v_u_24451 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24451);
  V v_x1_24452 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, NTAG(TAG_N), v_t1_2439, v_vs_244}));
  switch (heff_tag_of(v_x1_24452)) {
  case TAG_Nom: {
    V v_x_24453 = heff_field(v_x1_24452, 0);
    heff_take_n(v_x1_24452, 1ULL, 1);
    return v_x_24453;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24452, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24455 = heff_field(v_x1_24452, 0);
    heff_take_n(v_x1_24452, 1ULL, 1);
    return v_x_24455;
  }
  default: return heff_nomatch(v_x1_24452);
  }
}
V g_heff_2eeval_2eevalTermF_lam48(V self, V *args) {
  V v_f_24450 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t1_2439 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2evalue_2eapp(v_f_24450, heff_clo(g_heff_2eeval_2eevalTermF_lam49, 1, 4, (V[]){v_r_240, v_g_241, v_t1_2439, v_vs_244})));
}
V g_heff_2eeval_2eevalTermF_lam50(V self, V *args) {
  V v_u_24470 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24466 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24470);
  V v_x1_24471 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24466, v_vs_244}));
  switch (heff_tag_of(v_x1_24471)) {
  case TAG_Nom: {
    V v_x_24472 = heff_field(v_x1_24471, 0);
    heff_take_n(v_x1_24471, 1ULL, 1);
    return v_x_24472;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24471, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24474 = heff_field(v_x1_24471, 0);
    heff_take_n(v_x1_24471, 1ULL, 1);
    return v_x_24474;
  }
  default: return heff_nomatch(v_x1_24471);
  }
}
V g_heff_2eeval_2eevalTermF_lam51(V self, V *args) {
  V v_vs2_24475 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_t_24469 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tail(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, v_c_242, v_t_24469, v_vs2_24475});
}
V g_heff_2eeval_2eevalTermF_lam52(V self, V *args) {
  V v_u_24479 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_dom_24466 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_24479);
  V v_x1_24480 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_dom_24466, v_vs_244}));
  switch (heff_tag_of(v_x1_24480)) {
  case TAG_Nom: {
    V v_x_24481 = heff_field(v_x1_24480, 0);
    heff_take_n(v_x1_24480, 1ULL, 1);
    return v_x_24481;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24480, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24483 = heff_field(v_x1_24480, 0);
    heff_take_n(v_x1_24480, 1ULL, 1);
    return v_x_24483;
  }
  default: return heff_nomatch(v_x1_24480);
  }
}
V g_heff_2eeval_2eevalTermF_lam53(V self, V *args) {
  V v_i_24487 = args[0];
  V v_xs_24486 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_vs_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24488 = heff_arrayIndex(v_xs_24486, v_i_24487);
  return heff_tail(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, v_c_242, v_t_24488, v_vs_244});
}
V g_heff_2eeval_2eevalTermF_lam54(V self, V *args) {
  V v_sp_24535 = args[0];
  V v_i_24536 = args[1];
  V v_vs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_SpApp, 2, (V[]){v_sp_24535, ({ V a_0 = v_vs_244; V a_1 = v_i_24536; V r_ = heff_tr(g_heff_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_244); r_; })});
}
V g_heff_2eeval_2eevalTermF_lam55(V self, V *args) {
  V v_u_24543 = args[0];
  V v_ty_24542 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24543);
  return v_ty_24542;
}
V g_heff_2eeval_2eevalTypeF_lam0(V self, V *args);
V g_heff_2eeval_2eevalTypeF_lam2(V self, V *args);
V g_heff_2eeval_2eevalTypeF_lam1(V self, V *args);
V g_heff_2eeval_2eevalTypeF_lam5(V self, V *args);
V g_heff_2eeval_2eevalTypeF_lam4(V self, V *args);
V g_heff_2eeval_2eevalTypeF_lam3(V self, V *args);
Clo g_heff_2eeval_2eevalTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTypeF_entry, 5, 0};

V g_heff_2eeval_2eevalTypeF(V v_r_240, V v_g_241, V v_c_242, V v_x4_243, V v_vs_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SU: {
    V v_u_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SU = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SU, TAG_Nom, 1, (V[]){heff_tag(TAG_VU, 1, (V[]){v_u_245})});
  }
  case TAG_SDecode: {
    V v_t_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SDecode = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 4, (V[]){v_g_241, v_c_242, v_t_246, v_vs_244}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nom: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      return heff_tag_at(v_ru_24x4_243_24SDecode, TAG_Nom, 1, (V[]){({ V a_0 = v_x_248; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_248); r_; })});
    }
    case TAG_Describe: {
      V v_x_249 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      switch (heff_tag_of(v_x_249)) {
      case TAG_VNeu: {
        heff_take_n(v_x_249, 0ULL, 5);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2415 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        return heff_tag_at(v_ru_24x4_243_24SDecode, TAG_Describe, 1, (V[]){v_a_2415});
      }
      case TAG_VLam: {
        heff_take_n(v_x_249, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_249, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x4_243_24SDecode, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    case TAG_Become: {
      V v_x_2419 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      return heff_tag_at(v_ru_24x4_243_24SDecode, TAG_Become, 1, (V[]){({ V a_0 = v_x_2419; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_2419); r_; })});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_SFunction: {
    V v_level_2420 = heff_field(v_x4_243, 0);
    V v_dom_2421 = heff_field(v_x4_243, 1);
    V v_cod_2422 = heff_field(v_x4_243, 2);
    V v_implicit_2423 = heff_field(v_x4_243, 3);
    V v_dflt_2424 = heff_field(v_x4_243, 4);
    V v_ru_24x4_243_24SFunction = heff_take_reuse_n(v_x4_243, 31ULL, 5);
    heff_drop(v_c_242);
    V v_x1_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 4, (V[]){heff_dup(v_g_241), NTAG(TAG_N), v_dom_2421, heff_dup(v_vs_244)}));
    V v_t_2429;
    switch (heff_tag_of(v_x1_2425)) {
    case TAG_Nom: {
      V v_x_2426 = heff_field(v_x1_2425, 0);
      heff_take_n(v_x1_2425, 1ULL, 1);
      v_t_2429 = v_x_2426;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2425, 0ULL, 1);
      v_t_2429 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2428 = heff_field(v_x1_2425, 0);
      heff_take_n(v_x1_2425, 1ULL, 1);
      v_t_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x1_2425);
    }
    V v_t_2435;
    switch (heff_tag_of(v_cod_2422)) {
    case TAG_MkAbs: {
      V v_x_2430 = heff_field(v_cod_2422, 0);
      V v_t_2431 = heff_field(v_cod_2422, 1);
      heff_take_n(v_cod_2422, 3ULL, 2);
      v_t_2435 = heff_tag(TAG_MkClo, 3, (V[]){v_x_2430, v_vs_244, heff_clo(g_heff_2eeval_2eevalTypeF_lam0, 1, 3, (V[]){v_r_240, v_g_241, v_t_2431})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2433 = heff_field(v_cod_2422, 0);
      V v_ru_24cod_2422_24AbsConst = heff_take_reuse_n(v_cod_2422, 1ULL, 1);
      V v_t_2434 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2433, v_vs_244}));
      v_t_2435 = heff_tag_at(v_ru_24cod_2422_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2434});
      break;
    }
    default: heff_nomatch(v_cod_2422);
    }
    return heff_tag(TAG_Nom, 1, (V[]){heff_tag_at(v_ru_24x4_243_24SFunction, TAG_VFunction, 5, (V[]){v_level_2420, v_t_2429, v_t_2435, v_implicit_2423, v_dflt_2424})});
  }
  case TAG_SRecord: {
    V v_level_2436 = heff_field(v_x4_243, 0);
    V v_fieldTypes_2437 = heff_field(v_x4_243, 1);
    V v_defaults_2438 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_242);
    V v_xs_2439 = heff_get(heff_dup(v_fieldTypes_2437), LBL_values);
    V v_t_2448 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2439)), heff_clo(g_heff_2eeval_2eevalTypeF_lam1, 1, 3, (V[]){v_xs_2439, v_r_240, v_g_241}));
    V v_t_2449 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_fieldTypes_2437), LBL_keys), heff_get(v_fieldTypes_2437, LBL_byName), v_t_2448});
    return heff_tag(TAG_Describe, 1, (V[]){heff_tag(TAG_VRecord, 4, (V[]){v_level_2436, v_vs_244, v_t_2449, v_defaults_2438})});
  }
  case TAG_SSum: {
    V v_st_2450 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SSum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_xs_2451 = heff_get(heff_dup(v_st_2450), LBL_values);
    V v_t_2461 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2451)), heff_clo(g_heff_2eeval_2eevalTypeF_lam3, 1, 4, (V[]){v_xs_2451, v_r_240, v_g_241, v_vs_244}));
    V v_t_2462 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_st_2450), LBL_keys), heff_get(v_st_2450, LBL_byName), v_t_2461});
    return heff_tag_at(v_ru_24x4_243_24SSum, TAG_Describe, 1, (V[]){heff_tag(TAG_VSum, 1, (V[]){v_t_2462})});
  }
  case TAG_SIsTy: {
    V v_t_2463 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SIsTy = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2464 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2463, v_vs_244}));
    V v_t_2468;
    switch (heff_tag_of(v_x1_2464)) {
    case TAG_Nom: {
      V v_x_2465 = heff_field(v_x1_2464, 0);
      heff_take_n(v_x1_2464, 1ULL, 1);
      v_t_2468 = v_x_2465;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2464, 0ULL, 1);
      v_t_2468 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2467 = heff_field(v_x1_2464, 0);
      heff_take_n(v_x1_2464, 1ULL, 1);
      v_t_2468 = v_x_2467;
      break;
    }
    default: heff_nomatch(v_x1_2464);
    }
    return heff_tag_at(v_ru_24x4_243_24SIsTy, TAG_Become, 1, (V[]){v_t_2468});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimRune: {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
  }
  case TAG_SPrimArray: {
    V v_a_2469 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SPrimArray = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_242);
    V v_x1_2470 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_a_2469, v_vs_244}));
    V v_t_2474;
    switch (heff_tag_of(v_x1_2470)) {
    case TAG_Nom: {
      V v_x_2471 = heff_field(v_x1_2470, 0);
      heff_take_n(v_x1_2470, 1ULL, 1);
      v_t_2474 = v_x_2471;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2470, 0ULL, 1);
      v_t_2474 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2473 = heff_field(v_x1_2470, 0);
      heff_take_n(v_x1_2470, 1ULL, 1);
      v_t_2474 = v_x_2473;
      break;
    }
    default: heff_nomatch(v_x1_2470);
    }
    return heff_tag_at(v_ru_24x4_243_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag(TAG_VPrimArray, 1, (V[]){v_t_2474})});
  }
  case TAG_SFixed: {
    V v_w_2475 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24SFixed = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_c_242);
    heff_drop(v_vs_244);
    return heff_tag_at(v_ru_24x4_243_24SFixed, TAG_Nom, 1, (V[]){heff_tag(TAG_VFixed, 1, (V[]){v_w_2475})});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eeval_2eevalTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeval_2eevalTypeF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eeval_2eevalTypeF_lam0(V self, V *args) {
  V v_vs2_2432 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tail(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2431, v_vs2_2432});
}
V g_heff_2eeval_2eevalTypeF_lam2(V self, V *args) {
  V v_vs2_2442 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2441, v_vs2_2442}));
  V v_t_2447;
  switch (heff_tag_of(v_x1_2443)) {
  case TAG_Nom: {
    V v_x_2444 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_t_2447 = v_x_2444;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2443, 0ULL, 1);
    v_t_2447 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2446 = heff_field(v_x1_2443, 0);
    heff_take_n(v_x1_2443, 1ULL, 1);
    v_t_2447 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_x1_2443);
  }
  return heff_tag(TAG_MkField, 2, (V[]){v_t_2447, NTAG(TAG_Nothing)});
}
V g_heff_2eeval_2eevalTypeF_lam1(V self, V *args) {
  V v_i_2440 = args[0];
  V v_xs_2439 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2441 = heff_arrayIndex(v_xs_2439, v_i_2440);
  return heff_clo(g_heff_2eeval_2eevalTypeF_lam2, 1, 3, (V[]){v_r_240, v_g_241, v_t_2441});
}
V g_heff_2eeval_2eevalTypeF_lam5(V self, V *args) {
  V v_u_2456 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_t_2455 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2456);
  V v_x1_2457 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 4, (V[]){v_g_241, NTAG(TAG_N), v_t_2455, v_vs_244}));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    return v_x_2458;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    return v_x_2460;
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2eeval_2eevalTypeF_lam4(V self, V *args) {
  V v_i_2454 = args[0];
  V v_xs_2453 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2455 = heff_arrayIndex(v_xs_2453, v_i_2454);
  return heff_clo(g_heff_2eeval_2eevalTypeF_lam5, 1, 4, (V[]){v_r_240, v_g_241, v_t_2455, v_vs_244});
}
V g_heff_2eeval_2eevalTypeF_lam3(V self, V *args) {
  V v_i_2452 = args[0];
  V v_xs_2451 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_vs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_xs_2453 = heff_arrayIndex(v_xs_2451, v_i_2452);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2453)), heff_clo(g_heff_2eeval_2eevalTypeF_lam4, 1, 4, (V[]){v_xs_2453, v_r_240, v_g_241, v_vs_244}));
}
V g_heff_2eeval_2eevaluator_lam0(V self, V *args); static Clo g_heff_2eeval_2eevaluator_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevaluator_lam0, 4, 0};
V g_heff_2eeval_2eevaluator_lam1(V self, V *args); static Clo g_heff_2eeval_2eevaluator_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevaluator_lam1, 4, 0};

static V g_heff_2eeval_2eevaluator_val;
static int g_heff_2eeval_2eevaluator_st;
static V g_heff_2eeval_2eevaluator_init(void) {
  return heff_rec(2, shape_el__ty, (V[]){((V)&g_heff_2eeval_2eevaluator_lam0_clo), ((V)&g_heff_2eeval_2eevaluator_lam1_clo)});
}
V g_heff_2eeval_2eevaluator_get(void) {
  if (g_heff_2eeval_2eevaluator_st == 2) return g_heff_2eeval_2eevaluator_val;
  if (g_heff_2eeval_2eevaluator_st == 1) heff_fail("defined by itself");
  g_heff_2eeval_2eevaluator_st = 1;
  g_heff_2eeval_2eevaluator_val = heff_tr(g_heff_2eeval_2eevaluator_init());
  g_heff_2eeval_2eevaluator_st = 2;
  return g_heff_2eeval_2eevaluator_val;
}
V g_heff_2eeval_2eevaluator_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_c_241 = args[1];
  V v_s_242 = args[2];
  V v_vs_243 = args[3];
  return (g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_s_242, v_vs_243));
}
V g_heff_2eeval_2eevaluator_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_s_246 = args[2];
  V v_vs_247 = args[3];
  return (g_heff_2eeval_2eevalTypeF(heff_dup(g_heff_2eeval_2eevaluator_get()), v_g_244, v_c_245, v_s_246, v_vs_247));
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam0(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam2(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam1(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam5(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam4(V self, V *args);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam3(V self, V *args);
Clo g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_entry, 4, 0};

V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SU, TAG_Nom, 1, (V[]){heff_tag(TAG_VU, 1, (V[]){v_u_244})});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SDecode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_x1_246 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), v_g_240, v_c_241, v_t_245, v_vs_243));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Nom, 1, (V[]){({ V a_0 = v_x_247; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_247); r_; })});
    }
    case TAG_Describe: {
      V v_x_248 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_x_248)) {
      case TAG_VNeu: {
        heff_take_n(v_x_248, 0ULL, 5);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2414 = heff_field(v_x_248, 0);
        heff_take_n(v_x_248, 1ULL, 1);
        return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Describe, 1, (V[]){v_a_2414});
      }
      case TAG_VLam: {
        heff_take_n(v_x_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_ru_24x4_242_24SDecode, 1);
        return heff_abandon();
      }
      default: return heff_nomatch(v_x_248);
      }
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      return heff_tag_at(v_ru_24x4_242_24SDecode, TAG_Become, 1, (V[]){({ V a_0 = v_x_2418; V r_ = (g_heff_2evalue_2edecodeN(a_0)); heff_drop(v_x_2418); r_; })});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_SFunction: {
    V v_level_2419 = heff_field(v_x4_242, 0);
    V v_dom_2420 = heff_field(v_x4_242, 1);
    V v_cod_2421 = heff_field(v_x4_242, 2);
    V v_implicit_2422 = heff_field(v_x4_242, 3);
    V v_dflt_2423 = heff_field(v_x4_242, 4);
    V v_ru_24x4_242_24SFunction = heff_take_reuse_n(v_x4_242, 31ULL, 5);
    heff_drop(v_c_241);
    V v_x1_2424 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(heff_dup(v_g_240), NTAG(TAG_N), v_dom_2420, heff_dup(v_vs_243)));
    V v_t_2428;
    switch (heff_tag_of(v_x1_2424)) {
    case TAG_Nom: {
      V v_x_2425 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 1);
      v_t_2428 = v_x_2425;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2424, 0ULL, 1);
      v_t_2428 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2427 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 1);
      v_t_2428 = v_x_2427;
      break;
    }
    default: heff_nomatch(v_x1_2424);
    }
    V v_t_2433;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkAbs: {
      V v_x_2429 = heff_field(v_cod_2421, 0);
      V v_t_2430 = heff_field(v_cod_2421, 1);
      heff_take_n(v_cod_2421, 3ULL, 2);
      v_t_2433 = heff_tag(TAG_MkClo, 3, (V[]){v_x_2429, v_vs_243, heff_clo(g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam0, 1, 2, (V[]){v_g_240, v_t_2430})});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2432 = heff_field(v_cod_2421, 0);
      V v_ru_24cod_2421_24AbsConst = heff_take_reuse_n(v_cod_2421, 1ULL, 1);
      v_t_2433 = heff_tag_at(v_ru_24cod_2421_24AbsConst, TAG_CloConst, 1, (V[]){(g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_240, NTAG(TAG_N), v_t_2432, v_vs_243))});
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    return heff_tag(TAG_Nom, 1, (V[]){heff_tag_at(v_ru_24x4_242_24SFunction, TAG_VFunction, 5, (V[]){v_level_2419, v_t_2428, v_t_2433, v_implicit_2422, v_dflt_2423})});
  }
  case TAG_SRecord: {
    V v_level_2434 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2435 = heff_field(v_x4_242, 1);
    V v_defaults_2436 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    heff_drop(v_c_241);
    V v_xs_2437 = heff_get(heff_dup(v_fieldTypes_2435), LBL_values);
    V v_t_2446 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2437)), heff_clo(g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam1, 1, 2, (V[]){v_xs_2437, v_g_240}));
    V v_t_2447 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_fieldTypes_2435), LBL_keys), heff_get(v_fieldTypes_2435, LBL_byName), v_t_2446});
    return heff_tag(TAG_Describe, 1, (V[]){heff_tag(TAG_VRecord, 4, (V[]){v_level_2434, v_vs_243, v_t_2447, v_defaults_2436})});
  }
  case TAG_SSum: {
    V v_st_2448 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_xs_2449 = heff_get(heff_dup(v_st_2448), LBL_values);
    V v_t_2459 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2449)), heff_clo(g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam3, 1, 3, (V[]){v_xs_2449, v_g_240, v_vs_243}));
    V v_t_2460 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_st_2448), LBL_keys), heff_get(v_st_2448, LBL_byName), v_t_2459});
    return heff_tag_at(v_ru_24x4_242_24SSum, TAG_Describe, 1, (V[]){heff_tag(TAG_VSum, 1, (V[]){v_t_2460})});
  }
  case TAG_SIsTy: {
    V v_t_2461 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIsTy = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2462 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_240, NTAG(TAG_N), v_t_2461, v_vs_243));
    V v_t_2466;
    switch (heff_tag_of(v_x1_2462)) {
    case TAG_Nom: {
      V v_x_2463 = heff_field(v_x1_2462, 0);
      heff_take_n(v_x1_2462, 1ULL, 1);
      v_t_2466 = v_x_2463;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2462, 0ULL, 1);
      v_t_2466 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2465 = heff_field(v_x1_2462, 0);
      heff_take_n(v_x1_2462, 1ULL, 1);
      v_t_2466 = v_x_2465;
      break;
    }
    default: heff_nomatch(v_x1_2462);
    }
    return heff_tag_at(v_ru_24x4_242_24SIsTy, TAG_Become, 1, (V[]){v_t_2466});
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimInt)});
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimFloat)});
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimString)});
  }
  case TAG_SPrimRune: {
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag(TAG_Nom, 1, (V[]){NTAG(TAG_VPrimRune)});
  }
  case TAG_SPrimArray: {
    V v_a_2467 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_c_241);
    V v_x1_2468 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_240, NTAG(TAG_N), v_a_2467, v_vs_243));
    V v_t_2472;
    switch (heff_tag_of(v_x1_2468)) {
    case TAG_Nom: {
      V v_x_2469 = heff_field(v_x1_2468, 0);
      heff_take_n(v_x1_2468, 1ULL, 1);
      v_t_2472 = v_x_2469;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2468, 0ULL, 1);
      v_t_2472 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2471 = heff_field(v_x1_2468, 0);
      heff_take_n(v_x1_2468, 1ULL, 1);
      v_t_2472 = v_x_2471;
      break;
    }
    default: heff_nomatch(v_x1_2468);
    }
    return heff_tag_at(v_ru_24x4_242_24SPrimArray, TAG_Nom, 1, (V[]){heff_tag(TAG_VPrimArray, 1, (V[]){v_t_2472})});
  }
  case TAG_SFixed: {
    V v_w_2473 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_c_241);
    heff_drop(v_vs_243);
    return heff_tag_at(v_ru_24x4_242_24SFixed, TAG_Nom, 1, (V[]){heff_tag(TAG_VFixed, 1, (V[]){v_w_2473})});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(a[0], a[1], a[2], a[3]);
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam0(V self, V *args) {
  V v_vs2_2431 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_240, NTAG(TAG_N), v_t_2430, v_vs2_2431));
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam2(V self, V *args) {
  V v_vs2_2440 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2441 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_240, NTAG(TAG_N), v_t_2439, v_vs2_2440));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_t_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  return heff_tag(TAG_MkField, 2, (V[]){v_t_2445, NTAG(TAG_Nothing)});
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam1(V self, V *args) {
  V v_i_2438 = args[0];
  V v_xs_2437 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_arrayIndex(v_xs_2437, v_i_2438);
  return heff_clo(g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam2, 1, 2, (V[]){v_g_240, v_t_2439});
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam5(V self, V *args) {
  V v_u_2454 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2453 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2454);
  V v_x1_2455 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(v_g_240, NTAG(TAG_N), v_t_2453, v_vs_243));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Nom: {
    V v_x_2456 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2456;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2455, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2458 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2458;
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam4(V self, V *args) {
  V v_i_2452 = args[0];
  V v_xs_2451 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2453 = heff_arrayIndex(v_xs_2451, v_i_2452);
  return heff_clo(g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam5, 1, 3, (V[]){v_g_240, v_t_2453, v_vs_243});
}
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam3(V self, V *args) {
  V v_i_2450 = args[0];
  V v_xs_2449 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2451 = heff_arrayIndex(v_xs_2449, v_i_2450);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2451)), heff_clo(g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_lam4, 1, 3, (V[]){v_xs_2451, v_g_240, v_vs_243}));
}