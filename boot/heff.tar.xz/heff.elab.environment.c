// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BDelayedBy 11524
#define TAG_BInserted 42142
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CanGuess 47396
#define TAG_Catch 6517
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_MkSt 48854
#define TAG_PartArg 21785
#define TAG_PartField 49319
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define LBL_aliases 1464806715
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_ctx 308385
#define LBL_infos 301706655
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_metas 305145640
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_part 9928890
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_selfKey 62480824
#define LBL_steps 311119681
#define LBL_tags 10047712
#define LBL_trace 311979359
static uint32_t shape_aliases__tags[] = {LBL_aliases, LBL_tags};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_len__names__locals__ctx__matched[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx, LBL_matched};
static uint32_t shape_part__tags__at[] = {LBL_part, LBL_tags, LBL_at};
static uint32_t shape_root__steps[] = {LBL_root, LBL_steps};
V g_heff_2eelab_2eenvironment_2eargPartsFrom(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2eargPartsFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eargPartsFrom_clo;
V g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars_clo;
V g_heff_2eelab_2eenvironment_2ebindAt(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ebindAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindAt_clo;
V g_heff_2eelab_2eenvironment_2ecanGuess(V, V);
V g_heff_2eelab_2eenvironment_2ecanGuess_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ecanGuess_clo;
V g_heff_2eelab_2eenvironment_2eemptyCore_get(void);
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
HeffT2 g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(V, V);
V g_heff_2eelab_2eenvironment_2ematchedTo(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ematchedTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ematchedTo_clo;
V g_heff_2eelab_2eenvironment_2emultiBind(V, V, V);
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2emultiBind_clo;
V g_heff_2eelab_2eenvironment_2enothingMatched_get(void);
V g_heff_2eelab_2eenvironment_2epartNamed(V, V);
V g_heff_2eelab_2eenvironment_2epartNamed_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2epartNamed_clo;
V g_heff_2eelab_2eenvironment_2epartOf(V, V);
V g_heff_2eelab_2eenvironment_2epartOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2epartOf_clo;
HeffT2 g_heff_2eelab_2eenvironment_2epartOf_24cpr(V, V);
V g_heff_2eelab_2eenvironment_2eruledOutAt(V, V, V, V);
V g_heff_2eelab_2eenvironment_2eruledOutAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eruledOutAt_clo;
V g_heff_2eelab_2eenvironment_2esamePartSteps(V, V);
V g_heff_2eelab_2eenvironment_2esamePartSteps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2esamePartSteps_clo;
V g_heff_2eelab_2eenvironment_2eseeArms(V, V, V);
V g_heff_2eelab_2eenvironment_2eseeArms_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eseeArms_clo;
V g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566(V, V, V);
V g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eenvironment_2ewithInserted(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithInserted_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithInserted_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_std_2eordmap_2eempty_get(void);
Clo g_heff_2eelab_2eenvironment_2esamePartSteps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2esamePartSteps_entry, 2, 0};

V g_heff_2eelab_2eenvironment_2esamePartSteps(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x1_240, 0);
    V v_ss_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_t_246 = heff_field(v_x2_241, 0);
      V v_ts_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_s_244)) {
      case TAG_PartField: {
        V v_f_248 = heff_field(v_s_244, 0);
        switch (heff_tag_of(v_t_246)) {
        case TAG_PartField: {
          V v_g_249 = heff_field(v_t_246, 0);
          if (heff_strEq_c_lent(v_f_248, v_g_249, 0)) {
            V t_0 = v_ss_245;
            V t_1 = v_ts_247;
            v_x1_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          } else {
            return NTAG(TAG_False);
          }
        }
        case TAG_PartArg: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      case TAG_PartArg: {
        V v_x_2412 = heff_field(v_s_244, 0);
        V v_i_2413 = heff_field(v_s_244, 1);
        switch (heff_tag_of(v_t_246)) {
        case TAG_PartField: {
          return NTAG(TAG_False);
        }
        case TAG_PartArg: {
          V v_y_2415 = heff_field(v_t_246, 0);
          V v_j_2416 = heff_field(v_t_246, 1);
          if ((heff_intEq_c_lent(v_i_2413, v_j_2416, 0) && heff_strEq_c_lent(v_x_2412, v_y_2415, 0))) {
            V t_0 = v_ss_245;
            V t_1 = v_ts_247;
            v_x1_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          } else {
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      default: return heff_nomatch(v_s_244);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2esamePartSteps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eenvironment_2esamePartSteps(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_REC_LIT(g_heff_2eelab_2eenvironment_2enothingMatched_lit0, 2, shape_aliases__tags, NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2eelab_2eenvironment_2enothingMatched_val;
static HEFF_ONCE g_heff_2eelab_2eenvironment_2enothingMatched_st;
static V g_heff_2eelab_2eenvironment_2enothingMatched_init(void) {
  return ((V)&g_heff_2eelab_2eenvironment_2enothingMatched_lit0);
}
V g_heff_2eelab_2eenvironment_2enothingMatched_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eenvironment_2enothingMatched_st)) return g_heff_2eelab_2eenvironment_2enothingMatched_val;
  return heff_global(&g_heff_2eelab_2eenvironment_2enothingMatched_val, &g_heff_2eelab_2eenvironment_2enothingMatched_st, g_heff_2eelab_2eenvironment_2enothingMatched_init);
}

static V g_heff_2eelab_2eenvironment_2eemptyScope_val;
static HEFF_ONCE g_heff_2eelab_2eenvironment_2eemptyScope_st;
static V g_heff_2eelab_2eenvironment_2eemptyScope_init(void) {
  return heff_rec_n(5, shape_len__names__locals__ctx__matched, (V[]){MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_LNil), NTAG(TAG_CEmpty), heff_dup(g_heff_2eelab_2eenvironment_2enothingMatched_get())});
}
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eenvironment_2eemptyScope_st)) return g_heff_2eelab_2eenvironment_2eemptyScope_val;
  return heff_global(&g_heff_2eelab_2eenvironment_2eemptyScope_val, &g_heff_2eelab_2eenvironment_2eemptyScope_st, g_heff_2eelab_2eenvironment_2eemptyScope_init);
}
Clo g_heff_2eelab_2eenvironment_2epartNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2epartNamed_entry, 2, 0};

V g_heff_2eelab_2eenvironment_2epartNamed(V v_x1_240, V v_l_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_root__steps, (V[]){v_l_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_m_244 = heff_field(v_x11_242, 0);
      V v_p_245 = heff_field(v_x11_242, 1);
      if (heff_intEq_c_lent(v_m_244, v_l_241, 0)) {
        heff_drop(v_l_241);
        return heff_dup(v_p_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_l_241;
        v_x1_240 = t_0;
        v_l_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2epartNamed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eenvironment_2epartNamed(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2eelab_2eenvironment_2epartOf_24cpr(V v_sc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_sc_240, 4)), 0, 2);
    V v_t_244 = heff_intSub(heff_get_n(v_sc_240, 0, 5), MK_INT(1LL));
    V v_t_245 = ({ V a_0 = v_t_243; V a_1 = heff_intSub(v_t_244, v_i_242); V r_ = (g_heff_2eelab_2eenvironment_2epartNamed(a_0, a_1)); heff_drop(v_t_243); r_; });
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_245}});
  }
  case TAG_SGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    V v_t_2413 = heff_field(v_x2_241, 0);
    V v_f_2414 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24SProj = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_2415 = (g_heff_2eelab_2eenvironment_2epartOf_24cpr(v_sc_240, v_t_2413));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_p_2418 = v_field_2417;
        V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24SProj, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartField, 1, (V[]){v_f_2414}), heff_dup(heff_rfield(v_p_2418, 1))});
        V v_f_2420 = ({ V rv_1 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_p_2418, 1ULL, 2, shape_root__steps, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
      } else {
        heff_drop(v_f_2414);
        heff_drop_cell(v_ru_24x2_241_24SProj, 2);
        heff_drop(v_field_2417);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_STag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_sc_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2eelab_2eenvironment_2epartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2epartOf_entry, 2, 0};

V g_heff_2eelab_2eenvironment_2epartOf(V v_sc_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2eenvironment_2epartOf_24cpr(v_sc_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2eenvironment_2epartOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2epartOf(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_part_244 = heff_dup(heff_rfield(v_t_242, 0));
    V v_tags_245 = heff_dup(heff_rfield(v_t_242, 1));
    V v_q_246 = v_part_244;
    V v_root_247 = heff_take_field(v_q_246, 0);
    V v_steps_248 = heff_get_n(v_q_246, 1, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_p_241, 0)), v_root_247)) {
      V v_t_249 = ({ V a_0 = heff_rfield(v_p_241, 1); V a_1 = v_steps_248; V r_ = (g_heff_2eelab_2eenvironment_2esamePartSteps(a_0, a_1)); heff_drop(v_steps_248); r_; });
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_t_249);
        V v_f_2410 = v_tags_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      } else {
        heff_drop(v_tags_245);
        heff_drop(v_t_249);
        V t_0 = v_rest_243;
        V t_1 = v_p_241;
        v_x1_240 = t_0;
        v_p_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_tags_245);
      heff_drop(v_steps_248);
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2eelab_2eenvironment_2ematchedTo_lam0(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2ematchedTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ematchedTo_entry, 4, 0};

V g_heff_2eelab_2eenvironment_2ematchedTo(V v_x1_240, V v_xs_241, V v_at_242, V v_sc_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_xs_241);
    heff_drop(v_at_242);
    return v_sc_243;
  }
  case TAG_Just: {
    V v_p_244 = heff_field(v_x1_240, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_sc_243, 4)), 1, 2);
    HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_dup(v_p_244); HeffT2 r_ = (g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2411;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_ys_249 = v_field_248;
        v_t_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2eelab_2eenvironment_2ematchedTo_lam0, 1, 1, (V[]){v_ys_249}), v_xs_241));
      } else {
        heff_drop(v_field_248);
        v_t_2411 = v_xs_241;
      }
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_sc_243, 4)), 0, 2);
      V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_sc_243, 4)), 1, 2);
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_part__tags__at, (V[]){heff_dup(v_p_244), v_t_2411, v_at_242}), v_t_2413});
      V v_k_2415 = heff_rec_n(2, shape_aliases__tags, (V[]){v_t_2412, v_t_2414});
      return ({ V rv_4 = v_k_2415; V rr_ = heff_rec_reuse_nf(v_sc_243, 15ULL, 5, shape_len__names__locals__ctx__matched, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2ematchedTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eenvironment_2ematchedTo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eenvironment_2ematchedTo_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ys_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2410; V a_1 = v_ys_249; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_2410); heff_drop(v_ys_249); r_; });
}
Clo g_heff_2eelab_2eenvironment_2eruledOutAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2eruledOutAt_entry, 4, 0};

V g_heff_2eelab_2eenvironment_2eruledOutAt(V v_x1_240, V v_p_241, V v_x_242, V v_found_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 2);
    return v_found_243;
  }
  case TAG_Cons: {
    V v_t_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_part_246 = heff_dup(heff_rfield(v_t_244, 0));
    V v_tags_247 = heff_dup(heff_rfield(v_t_244, 1));
    V v_at_248 = heff_dup(heff_rfield(v_t_244, 2));
    V v_q_249 = v_part_246;
    V v_root_2410 = heff_take_field(v_q_249, 0);
    V v_steps_2411 = heff_get_n(v_q_249, 1, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_p_241, 0)), v_root_2410)) {
      V v_t_2412 = ({ V a_0 = heff_rfield(v_p_241, 1); V a_1 = v_steps_2411; V r_ = (g_heff_2eelab_2eenvironment_2esamePartSteps(a_0, a_1)); heff_drop(v_steps_2411); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_x1_2413 = ({ V a_0 = v_x_242; V a_1 = v_tags_247; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_tags_247); r_; });
        if (!(heff_dup(v_x1_2413) == NTAG(TAG_True))) {
          heff_drop(v_found_243);
          heff_drop(v_x1_2413);
          V t_0 = v_rest_245;
          V t_1 = v_p_241;
          V t_2 = v_x_242;
          V t_3 = heff_tag_n(TAG_Just, 1, (V[]){v_at_248});
          v_x1_240 = t_0;
          v_p_241 = t_1;
          v_x_242 = t_2;
          v_found_243 = t_3;
          goto top;
        } else {
          heff_drop(v_at_248);
          heff_drop(v_x1_2413);
          V t_0 = v_rest_245;
          V t_1 = v_p_241;
          V t_2 = v_x_242;
          V t_3 = v_found_243;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          v_x_242 = t_2;
          v_found_243 = t_3;
          goto top;
        }
      } else {
        heff_drop(v_tags_247);
        heff_drop(v_at_248);
        heff_drop(v_t_2412);
        V t_0 = v_rest_245;
        V t_1 = v_p_241;
        V t_2 = v_x_242;
        V t_3 = v_found_243;
        v_x1_240 = t_0;
        v_p_241 = t_1;
        v_x_242 = t_2;
        v_found_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_tags_247);
      heff_drop(v_at_248);
      heff_drop(v_steps_2411);
      V t_0 = v_rest_245;
      V t_1 = v_p_241;
      V t_2 = v_x_242;
      V t_3 = v_found_243;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      v_x_242 = t_2;
      v_found_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2eruledOutAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2eenvironment_2eruledOutAt(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars_entry, 10, 0};

V g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars(V v_p_240, V v_x_241, V v_l_242, V v_i_243, V v_n_244, V v_len_245, V v_names_246, V v_locals_247, V v_ctx_248, V v_matched_249) {
top: ;
  if (heff_intLe_c_lent(v_n_244, v_i_243, 0)) {
    heff_drop_rec(v_p_240, 2);
    heff_drop(v_x_241);
    heff_drop(v_l_242);
    heff_drop(v_i_243);
    heff_drop(v_n_244);
    return heff_rec_n(5, shape_len__names__locals__ctx__matched, (V[]){v_len_245, v_names_246, v_locals_247, v_ctx_248, v_matched_249});
  } else {
    V v_l_2410 = heff_intAdd_lent(v_l_242, v_i_243, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartArg, 2, (V[]){heff_dup(v_x_241), heff_dup(v_i_243)}), heff_dup(heff_rfield(v_p_240, 1))});
    V v_t_2412 = heff_rec_n(2, shape_root__steps, (V[]){heff_dup(heff_rfield(v_p_240, 0)), v_t_2411});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2410, v_t_2412}), heff_take_field(v_matched_249, 0)});
    V v_k_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_matched_249, 2ULL, 2, shape_aliases__tags, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_p_240;
    V t_1 = v_x_241;
    V t_2 = v_l_242;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_n_244;
    V t_5 = v_len_245;
    V t_6 = v_names_246;
    V t_7 = v_locals_247;
    V t_8 = v_ctx_248;
    V t_9 = v_k_2414;
    v_p_240 = t_0;
    v_x_241 = t_1;
    v_l_242 = t_2;
    v_i_243 = t_3;
    v_n_244 = t_4;
    v_len_245 = t_5;
    v_names_246 = t_6;
    v_locals_247 = t_7;
    v_ctx_248 = t_8;
    v_matched_249 = t_9;
    goto top;
  }
}
V g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_heff_2eelab_2eenvironment_2eargPartsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2eargPartsFrom_entry, 6, 0};

V g_heff_2eelab_2eenvironment_2eargPartsFrom(V v_p_240, V v_x_241, V v_l_242, V v_i_243, V v_n_244, V v_sc_245) {
top: ;
  V v_len_246 = heff_take_field(v_sc_245, 0);
  V v_names_247 = heff_take_field(v_sc_245, 1);
  V v_locals_248 = heff_take_field(v_sc_245, 2);
  V v_ctx_249 = heff_take_field(v_sc_245, 3);
  V v_matched_2410 = heff_get_n(v_sc_245, 4, 5);
  return (g_heff_2eelab_2eenvironment_2eargPartsFrom_24scalars(v_p_240, v_x_241, v_l_242, v_i_243, v_n_244, v_len_246, v_names_247, v_locals_248, v_ctx_249, v_matched_2410));
}
V g_heff_2eelab_2eenvironment_2eargPartsFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2eargPartsFrom(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eenvironment_2ebindAt_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2ebindAt_lam1(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2ebindAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ebindAt_entry, 4, 0};

V g_heff_2eelab_2eenvironment_2ebindAt(V v_bm_240, V v_x_241, V v_a_242, V v_c_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_243, 0))});
  V v_v_246 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_244, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ebindAt_lam0, 1, 1, (V[]){heff_dup(v_a_242)}), NTAG(TAG_Nothing)));
  V v_t_247 = heff_intAdd(heff_take_field(v_c_243, 0), MK_INT(1LL));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, heff_take_field(v_c_243, 1)});
  V v_t_2410 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_243, 2), heff_clo_n(g_heff_2eelab_2eenvironment_2ebindAt_lam1, 1, 1, (V[]){v_v_246})});
  V v_t_2411 = heff_tag_n(TAG_CBind, 3, (V[]){heff_take_field(v_c_243, 3), v_bm_240, v_a_242});
  return ({ V rv_0 = v_t_247; V rv_1 = v_t_248; V rv_2 = v_t_2410; V rv_3 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_c_243, 16ULL, 5, shape_len__names__locals__ctx__matched, 768u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2eelab_2eenvironment_2ebindAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2ebindAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eenvironment_2ebindAt_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_drop(v_u_245);
  heff_clo_take(self, 1);
  return v_a_242;
}
V g_heff_2eelab_2eenvironment_2ebindAt_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_246 = heff_env(self)[0];
  heff_drop(v_u_249);
  heff_clo_take(self, 1);
  return v_v_246;
}
Clo g_heff_2eelab_2eenvironment_2emultiBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2emultiBind_entry, 3, 0};

V g_heff_2eelab_2eenvironment_2emultiBind(V v_x1_240, V v_x2_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_s_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_s_242;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_args_246 = heff_field(v_x2_241, 1);
      V v_t_247 = (g_heff_2eelab_2eenvironment_2ebindAt(heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), heff_dup(v_x_243), heff_dup(v_a_245), v_s_242));
      V t_0 = v_xs_244;
      V t_1 = v_args_246;
      V t_2 = v_t_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_s_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eenvironment_2emultiBind(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2ewithBound_lam1(V self, V *args);
V g_heff_2eelab_2eenvironment_2ewithBound_lam2(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2ewithBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ewithBound_entry, 6, 0};

V g_heff_2eelab_2eenvironment_2ewithBound(V v_x_240, V v_a_241, V v_c_242, V v_action_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_242, 0))});
  V v_t_248 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_246, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithBound_lam0, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_249 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_242, 0))});
  V v_v_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_249, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithBound_lam1, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_2412 = heff_intAdd(heff_take_field(v_c_242, 0), MK_INT(1LL));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_240, heff_take_field(v_c_242, 1)});
  V v_t_2415 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_242, 2), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithBound_lam2, 1, 1, (V[]){v_v_2411})});
  V v_t_2416 = heff_tag_n(TAG_CBind, 3, (V[]){heff_take_field(v_c_242, 3), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), v_a_241});
  V v_t_2417 = ({ V rv_0 = v_t_2412; V rv_1 = v_t_2413; V rv_2 = v_t_2415; V rv_3 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_c_242, 16ULL, 5, shape_len__names__locals__ctx__matched, 768u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  return heff_tail(v_action_243, 4, (V[]){v_t_248, v_t_2417, v_z_244, v_z_245});
}
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2ewithBound(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_drop(v_u_247);
  heff_clo_take(self, 1);
  return v_a_241;
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_drop(v_u_2410);
  heff_clo_take(self, 1);
  return v_a_241;
}
V g_heff_2eelab_2eenvironment_2ewithBound_lam2(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_2411 = heff_env(self)[0];
  heff_drop(v_u_2414);
  heff_clo_take(self, 1);
  return v_v_2411;
}
V g_heff_2eelab_2eenvironment_2ewithInserted_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2ewithInserted_lam1(V self, V *args);
V g_heff_2eelab_2eenvironment_2ewithInserted_lam2(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2ewithInserted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ewithInserted_entry, 6, 0};

V g_heff_2eelab_2eenvironment_2ewithInserted(V v_x_240, V v_a_241, V v_c_242, V v_action_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_242, 0))});
  V v_t_248 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_246, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithInserted_lam0, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_249 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_242, 0))});
  V v_v_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_249, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithInserted_lam1, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_2412 = heff_intAdd(heff_take_field(v_c_242, 0), MK_INT(1LL));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_240, heff_take_field(v_c_242, 1)});
  V v_t_2415 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_242, 2), heff_clo_n(g_heff_2eelab_2eenvironment_2ewithInserted_lam2, 1, 1, (V[]){v_v_2411})});
  V v_t_2416 = heff_tag_n(TAG_CBind, 3, (V[]){heff_take_field(v_c_242, 3), NTAG(TAG_BInserted), v_a_241});
  V v_t_2417 = ({ V rv_0 = v_t_2412; V rv_1 = v_t_2413; V rv_2 = v_t_2415; V rv_3 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_c_242, 16ULL, 5, shape_len__names__locals__ctx__matched, 768u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  return heff_tail(v_action_243, 4, (V[]){v_t_248, v_t_2417, v_z_244, v_z_245});
}
V g_heff_2eelab_2eenvironment_2ewithInserted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2ewithInserted(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eenvironment_2ewithInserted_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_drop(v_u_247);
  heff_clo_take(self, 1);
  return v_a_241;
}
V g_heff_2eelab_2eenvironment_2ewithInserted_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_drop(v_u_2410);
  heff_clo_take(self, 1);
  return v_a_241;
}
V g_heff_2eelab_2eenvironment_2ewithInserted_lam2(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_2411 = heff_env(self)[0];
  heff_drop(v_u_2414);
  heff_clo_take(self, 1);
  return v_v_2411;
}

static V g_heff_2eelab_2eenvironment_2eemptyCore_val;
static HEFF_ONCE g_heff_2eelab_2eenvironment_2eemptyCore_st;
static V g_heff_2eelab_2eenvironment_2eemptyCore_init(void) {
  return heff_rec_n(9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eenvironment_2eemptyCore_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eenvironment_2eemptyCore_st)) return g_heff_2eelab_2eenvironment_2eemptyCore_val;
  return heff_global(&g_heff_2eelab_2eenvironment_2eemptyCore_val, &g_heff_2eelab_2eenvironment_2eemptyCore_st, g_heff_2eelab_2eenvironment_2eemptyCore_init);
}

static V g_heff_2eelab_2eenvironment_2eemptySt_val;
static HEFF_ONCE g_heff_2eelab_2eenvironment_2eemptySt_st;
static V g_heff_2eelab_2eenvironment_2eemptySt_init(void) {
  return heff_tag_n(TAG_MkSt, 3, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyCore_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eenvironment_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eenvironment_2eemptySt_st)) return g_heff_2eelab_2eenvironment_2eemptySt_val;
  return heff_global(&g_heff_2eelab_2eenvironment_2eemptySt_val, &g_heff_2eelab_2eenvironment_2eemptySt_st, g_heff_2eelab_2eenvironment_2eemptySt_init);
}
V g_heff_2eelab_2eenvironment_2ecanGuess_lam0(V self, V *args); static Clo g_heff_2eelab_2eenvironment_2ecanGuess_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ecanGuess_lam0, 1, 0};
Clo g_heff_2eelab_2eenvironment_2ecanGuess_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2ecanGuess_entry, 2, 0};

V g_heff_2eelab_2eenvironment_2ecanGuess(V v_hd_240, V v_k2_241) {
top: ;
  V v_malg_242 = heff_take_field(v_hd_240, 2);
  V v_bind_243 = heff_get_n(v_hd_240, 1, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_CanGuess, 1, (V[]){((V)&g_heff_2eelab_2eenvironment_2ecanGuess_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(v_malg_242, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})}));
  return heff_tail(v_bind_243, 2, (V[]){v_t_246, v_k2_241});
}
V g_heff_2eelab_2eenvironment_2ecanGuess_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2ecanGuess(a[0], a[1]);
}
V g_heff_2eelab_2eenvironment_2ecanGuess_lam0(V self, V *args) {
  V v_b_244 = args[0];
  return v_b_244;
}
V g_heff_2eelab_2eenvironment_2etryE_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2etryE_lam1(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2etryE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2etryE_entry, 3, 0};

V g_heff_2eelab_2eenvironment_2etryE(V v_m_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_k_243 = heff_dup(heff_rfield(v_hd_241, 0));
  V v_t_245 = heff_tr(heff_call(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2eenvironment_2etryE_lam0, 1, 1, (V[]){v_k_243})}));
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2eenvironment_2etryE_lam1, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_249, v_k2_242});
}
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2etryE(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eenvironment_2etryE_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eenvironment_2etryE_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eenvironment_2eseeArms_lam0(V self, V *args);
V g_heff_2eelab_2eenvironment_2eseeArms_lam2(V self, V *args);
V g_heff_2eelab_2eenvironment_2eseeArms_lam1(V self, V *args);
Clo g_heff_2eelab_2eenvironment_2eseeArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2eseeArms_entry, 3, 0};

V g_heff_2eelab_2eenvironment_2eseeArms(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eenvironment_2eseeArms_lam0, 1, 1, (V[]){v_a_243})})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){v_t_248}));
    return heff_tail(heff_dup(heff_rfield(v_p_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eenvironment_2eseeArms_lam1, 1, 3, (V[]){v_p_241, v_rest_244, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2eseeArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2eseeArms(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eenvironment_2eseeArms_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, heff_take_field(v_c_245, 8)});
  return ({ V rv_8 = v_t_246; V rr_ = heff_rec_reuse_nf(v_c_245, 255ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2eenvironment_2eseeArms_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_drop(v_x_2414);
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2eenvironment_2eseeArms(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2eelab_2eenvironment_2eseeArms_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_p_241, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eenvironment_2eseeArms_lam2, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566_entry, 3, 0};

V g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566(V v_x1_240, V v_p_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tail(v_p_241, 2, (V[]){NTAG(TAG_MkUnit), v_z_242});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_c_248;
    switch (heff_tag_of(v_z_242)) {
    case TAG_MkSt: {
      V v_c_245 = heff_dup(heff_field(v_z_242, 0));
      v_c_248 = v_c_245;
      break;
    }
    default: heff_nomatch(v_z_242);
    }
    V v_t_2414;
    switch (heff_tag_of(v_z_242)) {
    case TAG_MkSt: {
      V v_d_2410 = heff_field(v_z_242, 1);
      V v_w_2411 = heff_field(v_z_242, 2);
      V v_ru_24z_242_24MkSt = heff_take_reuse_n(v_z_242, 6ULL, 3);
      V v_t_2412 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_a_243, heff_dup(heff_rfield(v_c_248, 8))});
      V v_t_2413 = ({ V rv_8 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_c_248, 255ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
      v_t_2414 = heff_tag_re_n(v_ru_24z_242_24MkSt, TAG_MkSt, 3, 6ULL, (V[]){v_t_2413, v_d_2410, v_w_2411});
      break;
    }
    default: heff_nomatch(v_z_242);
    }
    V t_0 = v_rest_244;
    V t_1 = v_p_241;
    V t_2 = v_t_2414;
    v_x1_240 = t_0;
    v_p_241 = t_1;
    v_z_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566(a[0], a[1], a[2]);
}